# Prosecution, round 7, run at the gate · registers kinematic, definitional (highest yield) · named targets: every passage the gate amendment rewrote (the frame's grade paragraph, Section 3.4, the grade lines of Sections 9 and 10, Section 11, Section 12's grade census, Table 3, Section 16, the provenance)
Read: audit_bfp/seeded_r7.md.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 8: "fifteen against seventeen" on the 32 divisors of 2310; the toggle of 2 pairs them, sixteen against sixteen, as fibre_balance decides. Arithmetic.
- K2. Section 7: "each pair is two records with one point" inverts registration, two points to one record. Drift.
- K3. Section 10: "The twin checks this in every degree" widens one executed degree, six, to all. Scope.

## Findings
F-22 · definitional · the Reader's Frame and Section 12, after the gate rewrite · claimed STRUCTURAL.
Mechanism alleged: with the paragraphs listing what the file leaves aside removed, a reader may take the value at the actual zero set as derived.
Minimal falsifier: a sentence of the rewritten text that states the value at a tier above premise.

F-23 · kinematic · Section 12, Carried forward · claimed STRUCTURAL.
Mechanism alleged: the parity law is cited from a kernel outside this file; its cone and its run are not in this file's receipts.
Minimal falsifier: the cited law fails to compile, or prints a cone other than empty, in the named file at the named version.

## Recomputed (no finding)
involution_parity, compiled in PhysOS 1.0.8p's Inescapable_Capstone.lean: does not depend on any axioms. The operating system booted in quick mode to SEAT EARNED, chain D3 92c771476606. The rewritten grade lines keep every grade they carried: premise for the act's field, structural for physical readings, derivation for the analytic identifications, theorem on the stated cones for the kernel.
