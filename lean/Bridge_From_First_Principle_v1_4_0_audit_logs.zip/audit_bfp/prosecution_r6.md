# Prosecution, round 6 · registers definitional, kinematic (highest yield, restated) · named targets: the round-5 repair in Section 2; a whole-text rescan
Read: audit_bfp/seeded_r6.md.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 11: "d = -1/3" for the electron; from d = 2 Re s - 1 and Re s = 1/4 the value is -1/2. Arithmetic.
- K2. Section 6.1: "The seat keeps the height": the record keeps the height; the seat is the fold's fixed set. Drift.
- K3. Section 12: P1 "used by every leg", against Section 1, where it is used by the pay leg alone. Scope.

## Findings
F-16 · kinematic · Section 8 and the abstract · STRUCTURAL.
Mechanism: "Every finite fibre balances" fails at n = 1: the divisors of 1 are {1}, the sign sum is 1 (executed), and the twin's own check prints [n = 1]. The toggle argument needs a prime to toggle, so it covers squarefree n > 1 only.
Minimal falsifier: the fibre over 1, sign sum +1.

F-17 · definitional · Section 8 and Table 1 · STRUCTURAL.
Mechanism: "the seat of the whole cut is 1" contradicts the seat's definition, a fixed point of the swap: the swap's fixed set is the diagonal a = b, present over every square, not over 1 alone.
Minimal falsifier: (2, 2) is a seat of the fibre over 4.

F-18 · kinematic · Table 1, prime-fibre column, row "The price" · STRUCTURAL.
Mechanism: "one T per prime factor" drops Section 8's squarefree condition: the fibre of 4 has three points, (1,4), (2,2), (4,1), not 2^2 (executed).
Minimal falsifier: the fibre of 4.

F-19 · definitional · Section 9 · STRUCTURAL.
Mechanism: "no finite stretch forces the limit, by record_decides_nothing read on the walk" cites a theorem about the chart as the warrant for a statement about the signed walk; the theorem has no walk in it. A reading is presented as an instance.
Minimal falsifier: record_decides_nothing quantifies over chart points and configurations only.

F-20 · kinematic · Section 6.2 · STRUCTURAL.
Mechanism: "the twin runs the export exhaustively on every small whole it can enumerate" overstates the twin, which runs five fixed families (C', F) in {(1,1), (1,2), (1,3), (2,1), (3,1)} over bounded F', exhaustively over maps within each.
Minimal falsifier: the twin's parameter arrays hold five families.

## Named targets, no finding
Section 2's "six laws" matches the six conjuncts of nothing_escapes_least_erasure.
