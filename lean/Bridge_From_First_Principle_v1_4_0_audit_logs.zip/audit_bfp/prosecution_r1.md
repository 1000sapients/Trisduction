# Prosecution, round 1 · registers kinematic, definitional · target added in the entry version: Section 16 and the abstract's closing sentence
Read: audit_bfp/seeded_r1.md, as a self-contained document, its axioms held fixed.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 15: "77 of 107 on no axiom" contradicts the abstract's 76 of 107 and the printed cone list (76). Arithmetic.
- K2. Section 16: "The record supplies the bit" uses record as the source of the value; Section 3.1 proves no reading of the record returns the value. Drift of "record".
- K3. Section 8: "the kernel proves the same for every n" widens a statement the kernel decides to 200 and the twin computes to 10^6. Scope.

## Findings
F-1 · kinematic · Section 5 and two consumers (abstract, readings table) · STRUCTURAL.
Mechanism: "Nine is odd, so nine holds a seat: nine is eight and a seat." An involution on nine points has 1, 3, 5, 7 or 9 fixed points (executed); oddness gives at least one, never exactly one. "Eight and a seat" needs a second fact, that the swap on a factor fibre fixes at most one point (a = b forces a^2 = n). The text's own theorem carries that bound to 200; the inference as written omits it.
Minimal falsifier: the identity on nine points, nine seats and no free orbit.

F-2 · definitional · Table 1, column of the crossing, row "The seat" · STRUCTURAL.
Mechanism: the cell reads "the base point, supplied", but Section 5 separates the two: a free orbit needs one supplied base point, while a point on the seat needs none. The run flip of the executed frame has no fixed point at all. One word, two incompatible senses.
Minimal falsifier: the run flip (b, q) to (not b, q) has an empty fixed set, so its column has no seat.

F-3 · definitional · Section 16, the forced-witness list · STRUCTURAL.
Mechanism: two items are listed as what every executing reader is forced to witness, but their cited warrants do not force them. "pays the price" rests on count_to_heat, whose hypothesis is the stated premise P1, not on anything the run computes; the twin measures no heat. "never measured" rests on reg_lands, a statement about the chart, which says nothing about measurement. Both are readings at a lower grade presented beside theorems.
Minimal falsifier: the twin source contains no heat measurement; count_to_heat's statement carries P1 as a hypothesis.

## Recomputed (no finding)
Joule floor 2.870978885078724e-21 J; 168 determinant-one systems; no 2^k equals 9 below 2^64; the fibre of 36 has nine points and one seat; M(10^7) = 1037 and the largest |M|/sqrt x on [100, 10^7] is 0.5671 at 199. All match the printed values.
