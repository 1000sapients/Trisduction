# Prosecution, round 5 · registers kinematic, limit (restated) · named targets: none outstanding
Read: audit_bfp/seeded_r5.md.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 2: "an integer equal to its own negation is zero or one"; one is not its own negation. Arithmetic.
- K2. Section 11: "the pair lands on the record as one seat" swaps record and seat against Sections 2 and 3. Drift.
- K3. Section 13: "It refutes P1 at every scale" widens a measurement at one scale to all scales. Scope.

## Findings
F-14 · kinematic · Section 2 · COSMETIC.
Mechanism: "The five laws together are nothing_escapes_least_erasure." The theorem binds six conjuncts (the involution, the cut, the registration triple, erases-nothing, the lost bit, least erasure as the value), counted from its statement.
Minimal falsifier: count the conjuncts of the theorem's statement: six.

F-15 · limit · Sections 13 and 16 · claimed STRUCTURAL.
Mechanism alleged: Section 16 says any counterexample is a computed witness and never a measured energy, while Section 13 lists F-Heat, a measured energy, as a falsifier.
Minimal falsifier: F-Heat is a measurement.

## Recomputed (no finding)
The six conjuncts of nothing_escapes_least_erasure, the five of reader_frame, the six registers, the fifteen listed conditional laws, the nine controls and the seven theta scales were counted from the statements and the sources; every other printed count matches.
