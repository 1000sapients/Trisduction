# Prosecution, round 3 · registers limit, symmetry · named targets: the round-2 additions (the Audit and Independence paragraphs; the listing sentences of Section 7)
Read: audit_bfp/seeded_r3.md.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 9: the largest |M(x)|/sqrt x on [100, 10^7] is printed 0.657; the executed value is 0.5671 at x = 199. Arithmetic.
- K2. Section 12: "P1, the record read as no-cessation": the record is the registration's image (Section 3.1), P1 is the no-cessation premise (Section 1). Drift of "record".
- K3. Section 3.4: "the empty cone certifies that the value holds unconditionally" contradicts the same section, where the cone certifies only that no axiom entered and the value rests on the supplied field. Scope widened.

## Findings
F-8 · symmetry · Section 11 · STRUCTURAL.
Mechanism: coordinate discipline. The notation fixes d = 2 Re s - 1. At resolution twelve the carrier is x = 6 + Q with Re s = x/12, so d = Q/6: the electron, Q = -3, sits at Re s = 1/4 and d = -1/2 (executed for Q = -3, 0, 3). The text writes "d = Q, the chart at resolution twelve", which conflates the integer chart the kernel carries (d = Q, unscaled) with the strip chart at resolution twelve. Equivariance survives, since the fold commutes with scaling; the stated coordinate does not.
Minimal falsifier: Q = -3 gives d = -1/2 on the strip chart, not -3.

F-9 · limit · Section 10 · STRUCTURAL.
Mechanism: "Two neighbouring real zeros at gap g push apart with a term 4/g ..., so a polynomial with every zero real keeps every zero real." The mutual term alone does not give the conclusion: the inference needs that every velocity is real while every zero is real, and that repulsion prevents the collision that would let a pair leave the axis. The step is a derivation stated in prose, carried neither by the kernel (which holds the quadratic) nor by the twin (which runs one degree-six instance forward), and its grade is unstated where the section states the grade of its other parts.
Minimal falsifier: the kernel carries no theorem on real-rootedness in degree above two; the section's grade line does not mention this step.

## Named targets, no finding
The Audit paragraph's six registers are complete at the close of this round; its three dispositions match the ledger's EARNED and SCOPED rows. The Independence paragraph's two independent checkers are the Lean kernel and the Fortran compiler, whose conduct the twin's section 0 probes. Section 7's listing sentences agree with price_counts_pairs (a length of the listed pairs) and leave price_zero_iff_value as stated.
