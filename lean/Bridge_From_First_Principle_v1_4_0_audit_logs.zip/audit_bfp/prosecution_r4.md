# Prosecution, round 4 · registers definitional, provenance (highest yield, restated) · named targets: the round-3 repairs in Sections 10 and 11
Read: audit_bfp/seeded_r4.md.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 10: "the discriminant rises by four per unit of time"; from b^2 - 4(c - 2t) the rise is 8t, which disc_flow states. Arithmetic.
- K2. Section 15: "The field is the record": the field is the supplied bit; the record is the registration's image. Drift.
- K3. Section 0.1: "Every clause, the act's supply included, is a theorem of the kernel" reads the premise-grade supply as a theorem. Scope.

## Findings
F-11 · provenance · Section 3.2 · claimed STRUCTURAL.
Mechanism alleged: weakest_forcing_premise is a tautology, P and V each implying the other, so "the value is the weakest premise that forces it" carries no content.
Minimal falsifier: the theorem's proof is the pair of its two hypotheses.

F-12 · definitional · Section 3.4 · claimed STRUCTURAL.
Mechanism alleged: printing value_from_the_act with an empty axiom cone invites the reading that the value is proved without assumption.
Minimal falsifier: a reader's report that the cone was read as unconditional proof.

F-13 · provenance · Section 16, the cosmic closure · claimed STRUCTURAL.
Mechanism alleged: "the actual universe occupies the zero-cost member of its record's fibre" cites record_carried_uniquely and price_zero_iff_value, which prove the zero-cost member exists and is unique, not that it is occupied.
Minimal falsifier: neither cited theorem mentions the actual configuration.

## Named targets, no finding
Section 10's repaired step names the missing premise (real velocities, no collision) and the carriers; Section 11's chart statement now matches the notation and states the scaling to the kernel's chart.
