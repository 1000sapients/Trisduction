# Prosecution, round 2 · registers parameter, provenance · named targets: the round-1 repairs in Sections 5 and 16, prosecuted against the spine
Read: audit_bfp/seeded_r2.md.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 12: "Proved on no axiom (78 theorems)" against 107 - 31 = 76 and the abstract's 76. Arithmetic.
- K2. Section 3.3: "extremal exactly when it has the fewest points of its fibre" uses extremal in a sense incompatible with its definition (an off-line point forces one in every same-record world). Drift.
- K3. Section 4: the discriminator is said to hold "on no axiom" while its proof decides by excluded middle; the printed cone list gives propext, Classical.choice, Quot.sound. Scope of the warrant widened.

## Findings
F-5 · parameter · Section 7 and its consumers (abstract, Table 1) · STRUCTURAL.
Mechanism: the erased count is a free parameter of the presentation, not a function of the configuration. Two presentations of one point set, pairs [(1,0)] and pairs [(1,0),(-1,0)], give erased 1 and 2 (executed in the kernel's own terms by evaluation, and by set comparison in a second channel). "Registering a finite configuration costs one T per off-line pair" therefore holds only for a presentation that lists each off-line orbit once. The zero, and with it the theorem that the price is zero exactly at the value, does not depend on the listing.
Minimal falsifier: erased of the two presentations, 2 against 1, on equal point sets.

F-6 · provenance · Section 12, Judged · STRUCTURAL.
Mechanism: "so no law of this file holds by an empty premise" generalises from the fifteen laws the harness lists to every law. Hypothesis-bearing statements outside the list are not inhabitation-checked: off_line_pair, pair_world_lacks_value, cannot_lie, cannot_deviate, nd_map, one_bit_arrives, the four two-adic lemmas, wall and flow_injective.
Minimal falsifier: the harness's list of conditional laws omits wall, whose hypotheses he and ho are never instantiated by any inhabitation theorem.

F-7 · provenance · Section 12 (Judged, Controlled) and the closing provenance paragraph · STRUCTURAL.
Mechanism: closed authorship not declared. The judgment, the controls, the twin and the harness are written by the same hand as the kernel; only the Lean kernel and the Fortran compiler are independent checkers. The text reports the harness results as evidence without separating independent checkers from the author's own instruments, and it states no audit history at all.
Minimal falsifier: the harness source and the kernel source carry the same authorship; nothing in the document names which checks are independent of it.

## Named targets, no finding
Section 5's repaired paragraph (oddness gives at least one seat; the swap's a = b gives at most one) agrees with odd_fibre_iff_seat and with the spine. Section 16's two relabelled readings agree with Section 12's structural readings and with P1's single use in Section 1.
