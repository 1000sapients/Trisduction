# Prosecution, cycle two, round 3 · registers limit, symmetry · named target: the round-2 repair in the Audit paragraph, read whole
Read: audit_bfp2/seeded_r3.md.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 9: M(10^7) = 1307 against the executed 1037. Arithmetic.
- K2. Section 2: "the two worlds share one seat"; they share one record, and only the registered world lies on the seat. Drift.
- K3. Section 4: "a halted carrier exists on every frame" contradicts halted_iff and the coherent denial on the two-point frame. Scope.

## Findings
H-1 · limit · Section 9, the counting wall · claimed STRUCTURAL. Alleged: wall_block_share counts floor units, so the "half" undercounts the block.
Minimal falsifier: the text claims a block holds less than a half.

H-2 · symmetry · Section 11, the carrier's two charts · claimed STRUCTURAL. Alleged: the kernel's statements hold on the integer chart d = Q, not on the strip chart d = Q/6.
Minimal falsifier: a statement of charge_carrier that fails under d -> d/6.

## Named target, no finding
The Audit paragraph reads whole: two cycles, plural pronouns, the first cycle's verdicts as recorded, the second's printed in its ledger.
## Limit and symmetry sweep of the whole text, no finding
Correspondence at s = 1 and at two units per bit, the quadratic's collision and backward slack, the fold's commutation with conjugation and with the carrier's scaling: each matches its theorem or its twin check.
