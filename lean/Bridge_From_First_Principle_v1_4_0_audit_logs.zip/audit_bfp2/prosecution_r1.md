# Prosecution, cycle two, round 1 · registers kinematic, definitional · the forged text read whole, consumers of every earlier scoping checked
Read: audit_bfp2/seeded_r1.md.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 3.4: "The four clauses" introduces a parenthesis listing five, and reader_frame binds five. Arithmetic.
- K2. Table 3: "the record supply" names the act's field a record; the record is the registration's image. Drift.
- K3. Section 11: the physical reading of the carrier called a theorem, against Section 12's structural grade for it. Scope.

## Findings
G-1 · definitional · the Reader's Frame · STRUCTURAL. "checks that every conditional law has a model of its hypotheses" is the unscoped form Section 12 narrows to the fifteen listed laws; consumer left behind.
Minimal falsifier: wall carries hypotheses and is on no list.

G-2 · definitional · Section 5 · STRUCTURAL. "The lock cascade has twelve gates because the rotation group acts simply on them" uses a term the file never defines and states a causal reading the theorem does not carry; the theorem is the torsor.
Minimal falsifier: the string "lock cascade" occurs once in the file.

G-3 · kinematic · Table 1, row Twin · STRUCTURAL. "exhaustive export" against Section 6.2's five families, exhaustive over maps within each.
Minimal falsifier: the twin's parameter arrays hold five families.

G-4 · kinematic · Table 2, row 9 · STRUCTURAL. "eight and a seat, never a reflection group" drops the factor-fibre condition Section 5 states; an involution on nine points may hold nine seats.
Minimal falsifier: the identity on nine points.

G-5 · definitional · Section 5 · STRUCTURAL. "not a reflection at all, of any kind" widens no_reflection_group_of_nine, a statement about groups of sign patterns, to reflections of every kind.
Minimal falsifier: the theorem's statement quantifies the number of axes of sign patterns only.

G-6 · definitional · Section 0.1 · STRUCTURAL. "Every clause is a theorem of the kernel" covers the clause on the actual zero set, whose field is supplied at premise grade; the theorem is value_from_the_act, which holds for every term of the type.
Minimal falsifier: value_from_the_act quantifies over every term of ActualZeros.

## Recomputed (no finding)
Counts against statements and sources: 107 theorems, 76 axiom-free, 31 on the standard axioms, 15 listed conditional laws, 9 controls, 30 twin checks, six conjuncts of the atom theorem, five of the reader's frame; M(10^7) = 1037, 0.5671 at 199; joule floor 2.870978885078724e-21.
