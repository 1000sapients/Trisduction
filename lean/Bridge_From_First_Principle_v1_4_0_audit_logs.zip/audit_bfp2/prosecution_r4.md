# Prosecution, cycle two, round 4 · registers definitional, kinematic (highest yield) · the round-3 calibration repaired first
Read: audit_bfp2/seeded_r4.md (written and verified to carry three plants before this pass).

## Errata
ERR-1 · auditor · round 3. The round-3 seeding command faulted on a non-unique anchor and wrote no seeded copy; the prosecution of round 3 was run on the unseeded candidate and its three planted-defect entries were written from the commitment, not detected in a copy. Round 3's detection count, and with it the seal its close printed, is void. Its two refusals stand on their own mechanisms.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Table 2: "256 and 612 systems"; the three-row systems number 8^3 = 512. Arithmetic.
- K2. Section 12: "P1, the record read as no-cessation"; P1 is the Ground read as no-cessation, the record is the registration's image. Drift.
- K3. Section 13: "It refutes P1 at every scale" widens a measurement at one scale to all. Scope.

## Findings
None mass-bearing. The whole text read under both registers: every count against its statement or source (107, 76, 31, 15, 9, 30; six and five conjuncts; 168 of 512; 256 two-row systems; 32 divisors, sixteen against sixteen; 1,111 points, 729 maps, 4,096 subsets, 90,000 pairs; 25 blocks, seven scales), and every defined term (seat, record, registration, line, fold, act, field, premise, structural) in one sense throughout.
