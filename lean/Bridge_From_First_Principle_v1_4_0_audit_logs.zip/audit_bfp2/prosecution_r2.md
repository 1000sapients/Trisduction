# Prosecution, cycle two, round 2 · registers parameter, provenance · named targets: the round-1 repairs and the extended Audit paragraph
Read: audit_bfp2/seeded_r2.md.

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 11: d = -1/4 for the electron; Re s = 1/4 gives d = 2(1/4) - 1 = -1/2. Arithmetic.
- K2. Table 1: "The seat | the record, d = 0": the seat of the chart is the line; the record is the registration's image. Drift.
- K3. Section 3.1: "no reading of any kind returns the value on both" widens record-respecting readings to all readings; a reading of the configuration itself returns the value. Scope.

## Findings
G-7 · provenance · the Audit paragraph · COSMETIC. After the round-1 extension the paragraph opens on two cycles and keeps the singular "it found" twice; the subject of the finding and narrowing is the two cycles.
Minimal falsifier: the paragraph's first sentence names two cycles; the second sentence's pronoun is singular.

G-8 · provenance · the abstract · claimed STRUCTURAL. Alleged: "execution forces every substrate to witness the closure" lets the reader take the value's bit as forced by the run.
Minimal falsifier: the sentence assigns the value's bit to the run.

## Named targets, no finding
G-1 to G-6 land where their sweeps say and read whole; the Audit paragraph's second-cycle sentence states a fact true at any verdict. Free parameters: the unit T is defined, the twin's inputs are fixed literals, no figure is fitted.
