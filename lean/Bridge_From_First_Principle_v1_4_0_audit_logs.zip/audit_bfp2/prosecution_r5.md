# Prosecution, cycle two, round 5 · registers limit, symmetry · run because round 3, which carried these registers, is void for calibration
Read: audit_bfp2/seeded_r5.md (written and verified to carry three plants before this pass).

## Planted-defect candidates (credited to the caught list, no finding id)
- K1. Section 8: "fifteen against seventeen" on the 32 divisors of 2310; the free toggle of 2 pairs them sixteen against sixteen. Arithmetic.
- K2. Table 3: "the record supply" calls the act's field a record. Drift.
- K3. Section 13: "It refutes P1 at every scale" widens one measured scale to all. Scope.

## Findings
None. Limit: correspondence at s = 1 (every block at least a half, executed over 25 blocks) and at two units per bit (each block at most 2^-j); the quadratic's collision at u = c with its sign on either side; zero slack backward from the seat; the real-rootedness step with its premises named and its carriers stated; the walk's finite stretches read structurally. Symmetry: the fold an involution with the line its fixed set; conjugation the fold under d = -2y; the carrier equivariant on the integer chart and on the strip chart by the linear map d -> d/6; the swap on factor fibres with the diagonal as its seat; total negation free on the eight patterns. Each matches its theorem or its twin check.
