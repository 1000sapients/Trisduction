"""Independent verifier. Own enumeration (3-prefix expansion, full unit check), own grade arithmetic.
Checks every certificate's multiset identity, piece grades, recursion, inflation and lift references,
and coverage of every Hodge (2,2) Galois orbit per level."""
import json, math, sys, hashlib
import numpy as np
from collections import Counter
def U(m): return [t for t in range(1, m) if math.gcd(t, m) == 1]
def grd(ms, m):
    vals = {sum((t * x) % m for x in ms) for t in U(m)}
    if len(vals) != 1: return None
    v = vals.pop(); return v // m if v % m == 0 else None
def orbits(m):
    T = 3 * m; units = np.array(U(m)); keys = []
    for a1 in range(1, m):
        for a2 in range(a1, m):
            if a1 + 5 * a2 > T: break
            g = np.arange(a2, m); A3, A4 = np.meshgrid(g, g, indexing="ij"); msk = A4 >= A3
            A3, A4 = A3[msk], A4[msk]; R = T - a1 - a2 - A3 - A4
            lo = np.maximum(A4, R - (m - 1)); hi = R // 2; cnt = np.maximum(hi - lo + 1, 0)
            if cnt.sum() == 0: continue
            rep = np.repeat(np.arange(len(A3)), cnt); off = np.arange(cnt.sum()) - np.repeat(np.cumsum(cnt) - cnt, cnt)
            A5 = lo[rep] + off; A6 = R[rep] - A5
            S = np.column_stack([np.full(len(A5), a1), np.full(len(A5), a2), A3[rep], A4[rep], A5, A6])
            ok = np.ones(len(S), bool)
            for t in units: ok &= ((S * t) % m).sum(1) == T
            H = S[ok]
            if len(H) == 0: continue
            best = None
            for t in units:
                Rr = np.sort((H * t) % m, axis=1); k = Rr[:, 0]
                for c in range(1, 6): k = k * m + Rr[:, c]
                best = k if best is None else np.minimum(best, k)
            keys.append(best)
    if not keys: return set()
    out = set()
    for k in np.unique(np.concatenate(keys)):
        k = int(k); v = []
        for _ in range(6): v.append(k % m); k //= m
        out.add(tuple(v[::-1]))
    return out
def canon(a, m): return min(tuple(sorted((t * x) % m for x in a)) for t in U(m))
def check(a, m, c, certs, depth=0):
    a = tuple(sorted(a)); ty = c["type"]
    if depth > 4: return False
    if ty == "JOIN":
        P, Q = c["pieces"]; return len(P) == 2 and (P[0] + P[1]) == m and grd(Q, m) == 2 and Counter(P) + Counter(Q) == Counter(a)
    if ty == "CURVES":
        T1, T2 = c["pieces"]; return len(T1) == 3 == len(T2) and sum(T1) % m == 0 and sum(T2) % m == 0 and Counter(T1) + Counter(T2) == Counter(a)
    if ty == "AOKI5":
        x = c["x"]; e = [(x + j * (m // 5)) % m for j in range(5)] + [(-5 * x) % m]
        return m % 5 == 0 and 0 not in e and tuple(sorted(e)) == a
    if ty == "DESCENT":
        lhs = Counter(a)
        for k in c["pairs"]: lhs.update([k, m - k])
        rhs = Counter()
        for P in c["pieces"]: rhs.update(P)
        if lhs != rhs: return False
        for P in c["pieces"]:
            if len(P) == 4:
                if grd(P, m) != 2: return False
            elif len(P) == 6:
                if grd(P, m) != 3 or tuple(sorted(P)) == a: return False
                key = canon(P, m); sub = certs.get(m, {}).get(key)
                if sub is None or not check(key, m, sub, certs, depth + 1): return False
            else: return False
        return True
    if ty == "INFL":
        e = c["e"]; base = tuple(c["base"])
        if m % e or any(x % e for x in a) or canon(tuple(x // e for x in a), m // e) != base: return False
        sub = certs.get(m // e, {}).get(base); return sub is not None and sub["type"] != "INFL" and check(base, m // e, sub, certs, depth + 1)
    if ty == "LIFT":
        e = c["e"]; b = tuple(sorted(e * x for x in a))
        return tuple(c["lifted"]) == b and grd(b, e * m) == 3 and check(b, e * m, c["cert"], certs, depth + 1)
    return False
if __name__ == "__main__":
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    raw = json.load(open("certs_all.json"))
    certs = {int(k): {tuple(json.loads(x)): v for x, v in d.items()} for k, d in raw.items()}
    for m in range(lo, hi + 1):
        orb = orbits(m); C = certs.get(m, {}); bad = [a for a, c in C.items() if not check(a, m, c, certs)]
        missing = sorted(orb - set(C)); extra = sorted(set(C) - orb)
        print(f"m={m:>3} orbits {len(orb):>5} certified {len(C):>5} failed {len(bad)} uncovered {missing} stray {len(extra)}", flush=True)
