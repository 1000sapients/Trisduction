Ancillary files for "A Proof of the Hodge Conjecture Derived from One Semiregular Witness Axiom"
census.py, census2.py, g2fast.py, stress.py : enumeration and search engines
cert_gen.py        : certificate generator, degrees 3..100 (run in chunks)
verify_certs.py    : independent verifier (own enumeration and grade arithmetic)
certs_all.json     : 47,686 certificates      sha256 d59d6840f68f
verify_all.txt     : verification transcript  sha256 3d9cebe1ff4a
spec_paper.lean    : one-premise dependency specification (Appendix A)
conservativity_schema.lean : Lean 4 core formalization behind Proposition 6
Reproduce: python3 verify_certs.py 3 100   (no randomness; exact integers)
