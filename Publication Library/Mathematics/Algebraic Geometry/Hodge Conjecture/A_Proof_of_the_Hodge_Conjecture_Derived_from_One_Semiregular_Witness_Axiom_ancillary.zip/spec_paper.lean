axiom Target   : Prop  -- HC for all X and p
axiom W        : Prop  -- semiregular witness
axiom Input_I1 : Prop  -- Cattani-Deligne-Kaplan
axiom Input_I2 : Prop  -- Bloch; Buchweitz-Flenner; Artin
axiom Input_I3 : Prop  -- GAGA; flat Chern classes
axiom Input_I4 : Prop  -- Hilbert schemes countable
axiom Input_I5 : Prop  -- very general curve
theorem target_from_W (w : W) (i1 : Input_I1)
    (i2 : Input_I2) (i3 : Input_I3)
    (i4 : Input_I4) (i5 : Input_I5) :
    Target := by sorry
