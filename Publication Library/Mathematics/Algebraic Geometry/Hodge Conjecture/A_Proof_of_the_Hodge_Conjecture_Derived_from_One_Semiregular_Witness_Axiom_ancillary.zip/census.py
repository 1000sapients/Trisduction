import numpy as np, math, itertools, hashlib, json, time, sys
U_ = {}
def units(m):
    if m not in U_: U_[m] = [t for t in range(1, m) if math.gcd(t, m) == 1]
    return U_[m]
def sextuples(m):
    A = np.arange(1, m, dtype=np.int16)[:, None]
    for _ in range(4):
        last = A[:, -1].astype(np.int64); cnt = m - last
        rep = np.repeat(np.arange(A.shape[0]), cnt)
        off = np.arange(cnt.sum()) - np.repeat(np.cumsum(cnt) - cnt, cnt)
        A = np.column_stack([A[rep], (np.repeat(last, cnt) + off).astype(np.int16)])
    a6 = (-A.astype(np.int64).sum(1)) % m
    keep = (a6 >= A[:, -1]) & (a6 > 0)
    return np.column_stack([A[keep].astype(np.int64), a6[keep]])
def hodge_orbits(m):
    S = sextuples(m); ok = np.ones(len(S), bool)
    for t in units(m):
        if 2 * t > m: break
        ok &= ((S * t) % m).sum(1) == 3 * m
    H = S[ok]
    if len(H) == 0: return []
    best = None
    for t in units(m):
        R = np.sort((H * t) % m, axis=1); k = R[:, 0]
        for c in range(1, 6): k = k * m + R[:, c]
        best = k if best is None else np.minimum(best, k)
    reps = []
    for k in np.unique(best):
        k = int(k); v = []
        for _ in range(6): v.append(k % m); k //= m
        reps.append(tuple(v[::-1]))
    return reps
def grade(ms, m):
    g = None
    for t in units(m):
        s = sum((t * x) % m for x in ms)
        if s % m: return None
        if g is None: g = s // m
        elif s // m != g: return None
    return g
def splits(a):
    for J in itertools.combinations(range(1, 6), 2):
        T1 = [a[0], a[J[0]], a[J[1]]]; T2 = [a[i] for i in range(1, 6) if i not in J]
        yield T1, T2
def VP(a, m): return any(a[i] + a[j] == m for i in range(6) for j in range(i + 1, 6))
def QD(a, m):
    for T1, T2 in splits(a):
        k = (-sum(T1)) % m
        if k and grade(T1 + [k], m) == 2 and grade(T2 + [m - k], m) == 2: return True
    return False
def STAR(a, m): return any(sum(T1) % m == 0 for T1, T2 in splits(a))
def sigma(p, x, m):
    if p == 2: e = [x, x + m // 2, m - 2 * x, m // 2]
    else: e = [x + j * (m // p) for j in range(p)] + [-p * x]
    e = [v % m for v in e]
    return None if 0 in e else sorted(e)
def STD5(a, m): return m % 5 == 0 and any(sigma(5, x, m) == list(a) for x in range(1, m))
def nu(ms, m):
    v = [0] * (m - 1)
    for x in ms: v[x - 1] += 1
    return v
LAT_ = {}
def lattice(m):
    if m in LAT_: return LAT_[m]
    rows = [nu([k, m - k], m) for k in range(1, m) if 2 * k <= m]
    for p in [q for q in range(2, m + 1) if m % q == 0 and all(q % r for r in range(2, int(q ** .5) + 1))]:
        for x in range(1, m):
            s = sigma(p, x, m)
            if s: rows.append(nu(s, m))
    basis = {}
    for r in rows:
        v = list(r)
        for c in range(m - 1):
            if v[c] == 0: continue
            if c not in basis:
                basis[c] = v if v[c] > 0 else [-z for z in v]; break
            b = basis[c]
            while v[c] != 0:
                q = b[c] // v[c]; b, v = v, [bi - q * vi for bi, vi in zip(b, v)]
            basis[c] = b if b[c] > 0 else [-z for z in b]
    LAT_[m] = basis; return basis
def LAT(a, m):
    B = lattice(m); t = nu(a, m)
    for c in range(m - 1):
        if t[c] == 0: continue
        if c not in B or t[c] % B[c][c]: return False
        q = t[c] // B[c][c]; t = [ti - q * bi for ti, bi in zip(t, B[c])]
    return True
def TWOPAIR(a, m):
    if m % 5: return False
    sig = [s for s in (sigma(5, x, m) for x in range(1, m)) if s]
    for k in range(1, m):
        for l in range(k, m):
            if 2 * k > m or 2 * l > m: continue
            ten = sorted(list(a) + [k, m - k, l, m - l])
            for s in sig:
                rest = list(ten)
                try:
                    for x in s: rest.remove(x)
                except ValueError: continue
                if grade(rest, m) == 2: return True
    return False
def LIFT(a, m):
    for e in (2, 3):
        b = sorted(e * x for x in a); M = e * m
        if VP(b, M) or QD(b, M) or STAR(b, M): return e
    return 0
PUB = [("VP", VP), ("QD", QD), ("STD5", STD5), ("LAT", LAT)]
PRE = [("STAR", STAR), ("TWOPAIR", TWOPAIR), ("LIFT", LIFT)]
def classify(a, m):
    for name, f in PUB:
        if f(a, m): return name, "published"
    for name, f in PRE:
        if f(a, m): return name, "preprint"
    return "SURVIVOR", "none"
if __name__ == "__main__":
    w33 = (1, 4, 16, 22, 25, 31); w39 = (1, 7, 16, 22, 34, 37); w45 = (1, 19, 20, 28, 30, 37)
    print("self-test")
    print("  w33 Hodge", grade(w33, 33) == 3, "VP", VP(w33, 33), "QD", QD(w33, 33), "LAT", LAT(w33, 33), "STAR", STAR(w33, 33), "LIFT e", LIFT(w33, 33))
    print("  da Silva rep ~ 7w", sorted((7 * x) % 33 for x in w33) == [7, 10, 13, 19, 22, 28])
    print("  w39 Hodge", grade(w39, 39) == 3, "VP", VP(w39, 39), "QD", QD(w39, 39), "LAT", LAT(w39, 39), "STAR", STAR(w39, 39))
    print("  w45 Hodge", grade(w45, 45) == 3, "VP", VP(w45, 45), "QD", QD(w45, 45), "STD5", STD5(w45, 45), "TWOPAIR", TWOPAIR(w45, 45))
    print("  sigma(5,1,45)", sigma(5, 1, 45), "grade", grade(sigma(5, 1, 45), 45))
