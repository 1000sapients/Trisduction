import numpy as np, itertools, json, time, hashlib, sys
from census import units, grade, VP, QD, STD5, LAT, STAR
def hodge_orbits_fast(m):
    T = 3 * m; half = [t for t in units(m) if 1 < t and 2 * t < m]; blocks = []
    for a1 in range(1, m):
        if 6 * a1 > T: break
        A = np.arange(a1, m, dtype=np.int64)[:, None]; S = a1 + A[:, 0]
        keep = S + 4 * A[:, 0] <= T; A, S = A[keep], S[keep]
        for depth in range(3):
            last = A[:, -1]; cnt = m - last
            rep = np.repeat(np.arange(len(A)), cnt)
            off = np.arange(cnt.sum()) - np.repeat(np.cumsum(cnt) - cnt, cnt)
            new = np.repeat(last, cnt) + off
            A = np.column_stack([A[rep], new]); S = S[rep] + new
            keep = S + (3 - depth) * new <= T; A, S = A[keep], S[keep]
        a6 = T - S; keep = (a6 >= A[:, -1]) & (a6 <= m - 1)
        B = np.column_stack([np.full(int(keep.sum()), a1), A[keep], a6[keep]])
        ok = np.ones(len(B), bool)
        for t in half: ok &= ((B * t) % m).sum(1) == T
        if ok.any(): blocks.append(B[ok])
    if not blocks: return []
    H = np.vstack(blocks); best = None
    for t in units(m):
        R = np.sort((H * t) % m, axis=1); k = R[:, 0]
        for c in range(1, 6): k = k * m + R[:, c]
        best = k if best is None else np.minimum(best, k)
    reps = []
    for k in np.unique(best):
        k = int(k); v = []
        for _ in range(6): v.append(k % m); k //= m
        reps.append(tuple(v[::-1]))
    return reps
def base_closed(S, m):
    for name, f in (("VP", VP), ("QD", QD), ("STD5", STD5), ("LAT", LAT), ("STAR", STAR)):
        if f(S, m): return name
    return None
def gen2p(a, m):
    pairs = [k for k in range(1, m) if 2 * k <= m]; A = tuple(sorted(a))
    for k, l in itertools.combinations_with_replacement(pairs, 2):
        ten = list(a) + [k, m - k, l, m - l]
        for Qi in itertools.combinations(range(10), 4):
            Q = tuple(sorted(ten[i] for i in Qi))
            if grade(Q, m) != 2: continue
            S = tuple(sorted(ten[i] for i in range(10) if i not in Qi))
            if S != A:
                how = base_closed(S, m)
                if how: return dict(pairs=[k, l], S=S, S_by=how, Q=Q)
    return None
def route(a, m):
    how = base_closed(a, m)
    if how: return dict(level=m, by=how)
    g = gen2p(a, m)
    if g: return dict(level=m, by="GEN2P", **g)
    for e in (2, 3):
        b = tuple(sorted(e * x for x in a)); M = e * m
        how = base_closed(b, M)
        if how: return dict(level=M, lift=e, by=how)
        g = gen2p(b, M)
        if g: return dict(level=M, lift=e, by="GEN2P", **g)
    return None
if __name__ == "__main__":
    lo, hi, step = map(int, sys.argv[1:4]); res = {}
    for m in range(lo, hi + 1, step):
        t0 = time.time(); reps = hodge_orbits_fast(m); tally = {}; certs = []; open_ = []
        for a in reps:
            r = route(a, m)
            key = "OPEN" if r is None else (r["by"] + ("@lift" if r.get("lift") else ""))
            tally[key] = tally.get(key, 0) + 1
            if r is None: open_.append(a)
            elif key not in ("VP", "QD", "STD5", "LAT"): certs.append(dict(a=a, **r))
        res[m] = dict(orbits=len(reps), tally=tally, certificates=certs, open=open_, secs=round(time.time() - t0, 1))
        print(f"m={m:>3} orbits {len(reps):>5} {tally} {'OPEN ' + str(open_) if open_ else ''} ({res[m]['secs']}s)", flush=True)
    json.dump(res, open(f"frontier_{lo}_{hi}_{step}.json", "w"), default=list)
    print("digest", hashlib.sha256(json.dumps(res, sort_keys=True, default=list).encode()).hexdigest()[:12])
