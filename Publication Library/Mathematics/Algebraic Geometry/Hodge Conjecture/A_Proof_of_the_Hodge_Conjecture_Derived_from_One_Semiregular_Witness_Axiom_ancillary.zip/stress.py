import itertools, time, sys
from collections import Counter
from census import grade, VP, QD, STD5, LAT, STAR
from census2 import base_closed, gen2p
def G2(m):
    out = []
    for q in itertools.combinations_with_replacement(range(1, m), 4):
        if sum(q) == 2 * m and grade(q, m) == 2: out.append(q)
    return out
def qcover(a, m, k, quads):
    """a (+) k vanishing pairs = union of (6+2k)/4 surface (grade-2) quadruples, pairs free."""
    q = (6 + 2 * k) // 4
    by = {}
    for Q in quads:
        for x in set(Q): by.setdefault(x, []).append(Q)
    need = Counter(a)
    def balanced(extra):
        return all(extra[x] == extra[m - x] for x in extra if 2 * x != m) and extra.get(m // 2, 0) % 2 == 0 if m % 2 == 0 else all(extra[x] == extra[m - x] for x in extra)
    def dfs(chosen, rem):
        if len(chosen) == q:
            if sum(rem.values()) == 0:
                tot = Counter()
                for Q in chosen: tot.update(Q)
                extra = tot - Counter(a)
                if sum(extra.values()) == 2 * k and all(extra[x] == extra[m - x] for x in list(extra) if 2 * x != m) and (m % 2 or extra[m // 2] % 2 == 0):
                    return list(chosen)
            return None
        if sum(rem.values()) == 0:
            cands = quads
        else:
            x0 = min(x for x in rem if rem[x] > 0); cands = by.get(x0, [])
        for Q in cands:
            if chosen and Q < chosen[-1] and sum(rem.values()) == 0: continue
            r2 = rem.copy(); r2.subtract(Counter(Q)); r2 = Counter({x: c for x, c in r2.items() if c > 0})
            got = dfs(chosen + [Q], r2)
            if got: return got
        return None
    return dfs([], need)
def gen2p_recursive(a, m):
    pairs = [k for k in range(1, m) if 2 * k <= m]; A = tuple(sorted(a))
    for k, l in itertools.combinations_with_replacement(pairs, 2):
        ten = list(a) + [k, m - k, l, m - l]
        for Qi in itertools.combinations(range(10), 4):
            Q = tuple(sorted(ten[i] for i in Qi))
            if grade(Q, m) != 2: continue
            S = tuple(sorted(ten[i] for i in range(10) if i not in Qi))
            if S != A and grade(S, m) == 3 and (base_closed(S, m) or gen2p(S, m)): return (k, l, S, Q)
    return None
a, m = (1, 20, 24, 42, 61, 62), 70
t0 = time.time(); quads = G2(m); print(f"surface quadruples at {m}: {len(quads)} ({time.time()-t0:.0f}s)", flush=True)
for k in (3, 5):
    t0 = time.time(); r = qcover(a, m, k, quads); print(f"  {k}-pair surface cover: {r} ({time.time()-t0:.0f}s)", flush=True)
t0 = time.time(); print(f"  recursive two-pair: {gen2p_recursive(a, m)} ({time.time()-t0:.0f}s)", flush=True)
calib = (1, 4, 16, 22, 25, 31)
print("  calibration: degree-33 witness 3-pair surface cover at 33:", qcover(calib, 33, 3, G2(33)))
