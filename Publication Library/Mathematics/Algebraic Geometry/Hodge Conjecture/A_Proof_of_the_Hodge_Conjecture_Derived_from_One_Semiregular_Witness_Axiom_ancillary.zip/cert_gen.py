import itertools, json, math, sys, time, hashlib
from collections import Counter
from census2 import hodge_orbits_fast
from census import units, grade
from g2fast import G2fast
def canon(a, m):
    return min(tuple(sorted((t * x) % m for x in a)) for t in units(m))
def join_cert(a, m):
    for i, j in itertools.combinations(range(6), 2):
        if a[i] + a[j] == m:
            Q = tuple(sorted(a[k] for k in range(6) if k not in (i, j)))
            if grade(Q, m) == 2: return dict(type="JOIN", pieces=[[a[i], a[j]], list(Q)])
def curves_cert(a, m):
    for J in itertools.combinations(range(1, 6), 2):
        T1 = [a[0], a[J[0]], a[J[1]]]
        if sum(T1) % m == 0: return dict(type="CURVES", pieces=[sorted(T1), sorted(a[i] for i in range(1, 6) if i not in J)])
def qd_cert(a, m):
    for J in itertools.combinations(range(1, 6), 2):
        T1 = [a[0], a[J[0]], a[J[1]]]; T2 = [a[i] for i in range(1, 6) if i not in J]; k = (-sum(T1)) % m
        if k and grade(T1 + [k], m) == 2 and grade(T2 + [m - k], m) == 2:
            return dict(type="DESCENT", pairs=[k], pieces=[sorted(T1 + [k]), sorted(T2 + [m - k])])
def aoki5_cert(a, m):
    if m % 5: return None
    for x in range(1, m):
        e = [(x + j * (m // 5)) % m for j in range(5)] + [(-5 * x) % m]
        if 0 not in e and sorted(e) == list(a): return dict(type="AOKI5", x=x)
def direct_base(a, m):
    return join_cert(a, m) or curves_cert(a, m) or qd_cert(a, m) or aoki5_cert(a, m)
def two_pair(a, m, closed):
    pairs = [k for k in range(1, m) if 2 * k <= m]; A = tuple(a)
    for k, l in itertools.combinations_with_replacement(pairs, 2):
        ten = list(a) + [k, m - k, l, m - l]
        for Qi in itertools.combinations(range(10), 4):
            Q = tuple(sorted(ten[i] for i in Qi))
            if grade(Q, m) != 2: continue
            S = tuple(sorted(ten[i] for i in range(10) if i not in Qi))
            if S != A and canon(S, m) in closed: return dict(type="DESCENT", pairs=[k, l], pieces=[list(S), list(Q)])
def pairs_of(extra, m):
    extra = Counter({x: c for x, c in extra.items() if c > 0}); out = []
    for x in sorted(extra):
        while extra[x] > 0:
            y = m - x
            if y == x:
                if extra[x] < 2: return None
                out.append(x); extra[x] -= 2
            else:
                if extra[y] <= 0: return None
                out.append(min(x, y)); extra[x] -= 1; extra[y] -= 1
    return out
def cover3(a, m, quads):
    from stress import qcover
    c = qcover(a, m, 3, quads)
    if c:
        u = Counter(); [u.update(Q) for Q in c]; u.subtract(Counter(a))
        pr = pairs_of(u, m)
        if pr is not None and len(pr) == 3: return dict(type="DESCENT", pairs=pr, pieces=[list(Q) for Q in c])
def certify_level(m, done, quad_cache):
    reps = hodge_orbits_fast(m); cert = {}
    for a in reps:
        c = direct_base(a, m)
        if c: cert[a] = c
    closed = set(cert)
    for a in reps:
        if a in cert: continue
        c = two_pair(a, m, closed)
        if not c:
            if m not in quad_cache: quad_cache[m] = G2fast(m)
            c = cover3(a, m, quad_cache[m])
        if not c:
            g = math.gcd(math.gcd(*a), m)
            if g > 1 and canon(tuple(x // g for x in a), m // g) in done.get(m // g, {}):
                c = dict(type="INFL", e=g, base=list(canon(tuple(x // g for x in a), m // g)))
        if not c:
            for e in (2, 3):
                b = tuple(sorted(e * x for x in a)); M = e * m
                sub = direct_base(b, M)
                if not sub:
                    if M not in quad_cache: quad_cache[M] = G2fast(M)
                    sub = cover3(b, M, quad_cache[M])
                if sub: c = dict(type="LIFT", e=e, lifted=list(b), cert=sub); break
        if c: cert[a] = c; closed.add(a)
    return reps, cert
if __name__ == "__main__":
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    done = {}
    try: done = {int(k): {tuple(json.loads(x)): v for x, v in d.items()} for k, d in json.load(open("certs_all.json")).items()}
    except Exception: pass
    qc = {}
    for m in range(lo, hi + 1):
        t0 = time.time(); reps, cert = certify_level(m, done, qc); done[m] = cert
        kinds = Counter(c["type"] for c in cert.values()); opn = [a for a in reps if a not in cert]
        print(f"m={m:>3} orbits {len(reps):>5} {dict(kinds)} {'OPEN ' + str(opn) if opn else ''} ({time.time()-t0:.1f}s)", flush=True)
        json.dump({str(k): {json.dumps(list(a)): v for a, v in d.items()} for k, d in done.items()}, open("certs_all.json", "w"))
    json.dump({str(k): {json.dumps(list(a)): v for a, v in d.items()} for k, d in done.items()}, open("certs_all.json", "w"))
