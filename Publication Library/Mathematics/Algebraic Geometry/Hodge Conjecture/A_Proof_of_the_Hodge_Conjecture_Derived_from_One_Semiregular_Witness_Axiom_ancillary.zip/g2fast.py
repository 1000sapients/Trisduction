import numpy as np
from census import units
def G2fast(m):
    T = 2 * m; half = [t for t in units(m) if 1 < t and 2 * t < m]; out = []
    for b1 in range(1, m):
        if 4 * b1 > T: break
        A = np.arange(b1, m, dtype=np.int64)[:, None]; S = b1 + A[:, 0]
        keep = S + 2 * A[:, 0] <= T; A, S = A[keep], S[keep]
        last = A[:, -1]; cnt = m - last
        rep = np.repeat(np.arange(len(A)), cnt); off = np.arange(cnt.sum()) - np.repeat(np.cumsum(cnt) - cnt, cnt)
        new = np.repeat(last, cnt) + off; A = np.column_stack([A[rep], new]); S = S[rep] + new
        keep = S + new <= T; A, S = A[keep], S[keep]
        b4 = T - S; keep = (b4 >= A[:, -1]) & (b4 <= m - 1)
        B = np.column_stack([np.full(int(keep.sum()), b1), A[keep], b4[keep]])
        ok = np.ones(len(B), bool)
        for t in half: ok &= ((B * t) % m).sum(1) == T
        out += [tuple(int(v) for v in r) for r in B[ok]]
    return out
