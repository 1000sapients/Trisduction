import json, sys
rnd, src, dst = sys.argv[1], sys.argv[2], sys.argv[3]
E = {("ARITH",1): ("$47{,}695$ Galois orbits", "$47{,}659$ Galois orbits"),
     ("DRIFT",1): ("an existence statement whose witnesses are semiregular", "an existence statement whose witnesses are algebraic cycles of any kind"),
     ("SCOPE",1): ("Nothing here asserts that the axiom holds.", "The axiom is shown to hold."),
     ("ARITH",2): ("DESCENT (adjoined pairs, closed pieces) & 3{,}662", "DESCENT (adjoined pairs, closed pieces) & 3{,}626"),
     ("DRIFT",2): ("with vanishing pairs $\\delta_i$ and pieces", "with vanishing pairs $\\delta_i$, pairs whose two entries are equal, and pieces"),
     ("SCOPE",2): ("for every $3\\le m\\le 100$ with $m\\notin\\{50,54,66,70,90,100\\}$", "for every $3\\le m\\le 100$"),
     ("ARITH",3): ("equality of all $98$ per-degree counts", "equality of all $97$ per-degree counts"),
     ("DRIFT",3): ("orbit $(1,20,24,42,61,62)$, which no certificate", "orbit $(1,20,24,42,61,62)$, a component of a Hodge locus which no certificate"),
     ("SCOPE",3): ("The most important open question is whether the Hodge conjecture implies Axiom W.", "Axiom W is equivalent to the Hodge conjecture.")}
ctl = json.load(open(f"audit_hsw2/controls_r{rnd}.sealed.json"))
ctl = ctl["controls"] if isinstance(ctl, dict) else ctl
s = open(src).read()
for c in ctl:
    old, new = E[(c["kind"], int(c["section"]))]
    assert old in s, ("FAULT plant", c); s = s.replace(old, new, 1)
    print(f"planted {c['id']} {c['kind']} region {c['section']}: {new[:60]}")
open(dst, "w").write(s)
