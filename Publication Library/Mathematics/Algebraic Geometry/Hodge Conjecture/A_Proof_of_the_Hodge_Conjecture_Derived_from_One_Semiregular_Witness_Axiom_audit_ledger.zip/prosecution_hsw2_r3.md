DETECTED ARITH | Table 2 rows do not sum: types [43287, 714, 3626, 21, 1, 1] sum 47650 vs certified 47686
DETECTED DRIFT | witness no longer semiregular in The candidate paragraph
DETECTED SCOPE | Conclusion states the converse question as settled
CAUGHT C1,C2,C3
