Round 3. Registers: limit, symmetry. Declared targets from round 2: the new form of input (I2) with the passage through the normalized curve, its three new references, and the narrowed Markman statements. Limit reading of (I2): an étale neighbourhood of a point on a smooth curve is a local analytic isomorphism, so the approximation yields a disc; the normalization is finite, so each preimage of a proper closed subset is finite and the countability step stands. The narrowed attribution reads the same in Sections 1, 2, 7 and Table 5. No finding on the targets.
F-12 | symmetry | C3 | STRUCTURAL | Section 5.1 infers that membership of V(a) in the complexified algebraic classes depends only on the Galois orbit from stability under automorphisms alone; automorphisms give permutation invariance, and the passage to Galois conjugates needs the rationality of the space of algebraic classes. The span of the permutation images of one eigenline is automorphism-stable and not Galois-stable. | Falsifier: that span, tested for stability under t -> t*a.
F-13 | symmetry | NONE | COSMETIC | Lemma 3(ii) says the equivariant composite acts on the line V(a) tensor V(delta) by a scalar without recording that the matching isotypic component is that line, which is what forces the scalar. | Falsifier: multiplicity of the character (a, delta) in the cohomology of the product.
limit battery: m=3,4,5 certificate types {3: ['JOIN'], 4: ['JOIN'], 5: ['JOIN']}
limit battery: open orbit at 100 is the inflation of the one at 50: True
DETECTED ARITH | abstract total 47659 vs Table 2 total 47695
DETECTED DRIFT | vanishing pair redefined as a pair with equal entries in the certificate definitions
DETECTED SCOPE | Conclusion states the converse question as settled
CAUGHT C1,C2,C3
