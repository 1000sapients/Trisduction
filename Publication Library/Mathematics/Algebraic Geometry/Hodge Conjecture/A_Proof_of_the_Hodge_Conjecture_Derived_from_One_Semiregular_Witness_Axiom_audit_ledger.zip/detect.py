import re, sys, math
s = open(sys.argv[1]).read(); hits = []
num = lambda x: int(re.sub(r"[^\d]", "", x))
ab = s[:s.index("\n---\n", 5)]
m = re.search(r"census of the \$([\d{},]+)\$ Galois orbits", ab)
t2 = s[s.index("by certificate type.}"):]; t2 = t2[:t2.index("\\end{tabular}")]
vals = [num(v) for v in re.findall(r"& ([\d{},]+) \\\\", t2)]
if len(vals) != 9 or sum(vals[:6]) != vals[6] or vals[6] + vals[7] != vals[8]:
    hits.append(("ARITH", f"Table 2 rows do not sum: types {vals[:6]} sum {sum(vals[:6])} vs certified {vals[6] if len(vals)>6 else None}"))
elif m and num(m.group(1)) != vals[8]:
    hits.append(("ARITH", f"abstract total {num(m.group(1))} vs Table 2 total {vals[8]}"))
k = re.search(r"equality of all \$(\d+)\$ per-degree counts", s)
if k and int(k.group(1)) != 100 - 3 + 1: hits.append(("ARITH", f"Criterion 1 degree count {k.group(1)} vs 98 degrees in 3..100"))
g = re.search(r"Galois orbit of \$(\d+)\$ distinct multisets", s)
if g and int(g.group(1)) != sum(1 for t in range(1, 70) if math.gcd(t, 70) == 1): hits.append(("ARITH", f"Proposition D orbit size {g.group(1)} vs phi(70)=24"))
if re.search(r"vanishing pairs?[^.]{0,60}entries are equal", s): hits.append(("DRIFT", "vanishing pair redefined as a pair with equal entries in the certificate definitions"))
if "whose witnesses are semiregular" not in s: hits.append(("DRIFT", "witness no longer semiregular in The candidate paragraph"))
if re.search(r"orbit[^.]{0,50}component of a Hodge locus", s): hits.append(("DRIFT", "Galois orbit described as a component of a Hodge locus in the Conclusion"))
if "Nothing here asserts that the axiom holds." not in s: hits.append(("SCOPE", "Section 1 no longer disclaims the truth of the axiom"))
tb = s[s.index("\\textbf{Theorem B.}"):]; tb = tb[:tb.index("\\end{jbox}")]
if "\\notin\\{" not in tb: hits.append(("SCOPE", "Theorem B quantifier widened past the open orbits of Table 3"))
if "open question is whether the Hodge conjecture implies Axiom W" not in s: hits.append(("SCOPE", "Conclusion states the converse question as settled"))
ids = sorted({{"ARITH": "C1", "DRIFT": "C2", "SCOPE": "C3"}[h[0]] for h in hits})
for h in hits: print("DETECTED", h[0], "|", h[1])
print("CAUGHT", ",".join(ids))
