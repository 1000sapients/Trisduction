Round 2, cycle hsw2. Registers: parameter, provenance. Declared targets from round 1: the dependency count of Lemma 5(d) with its propagation to Table 5, Limitations and the calibration clause, and the zero-sheaf clause; counts consistent with the executed closure, the zero sheaf has vanishing second self-extension group, no finding on the targets.
Parameter battery: every figure in the amended text is an exact integer from the census or a stated search bound; no free parameter enters a verdict.
Provenance battery, against the sources: da Silva's published article (Experimental Results 2, 2021) and its arXiv version, and the Jumagulov preprint's account of prior closures.
F-7 | provenance | C7 | STRUCTURAL | Section 2 and the da Silva row of Table 5 credit da Silva with the conjecture for Fermat fourfolds of degree at most 20. da Silva's article states that result as Shioda's (Theorem 2.7, Shioda having verified his condition for m at most 20, in every dimension); da Silva's own results are degree at most 100 coprime to 6 and degrees 21 and 27 in every dimension. The degree-33 attribution is confirmed by the same sources. | Falsifier: the attribution of Theorem 2.7 in the cited article.
F-8 | provenance | C3 | STRUCTURAL | Lemma 5(d) states Aoki's standard cycles in a specific form for 5 dividing m, and 30 certified orbits rest on it; the form is confirmed here only through secondary accounts of Aoki's calculus, not against the 1987 article. | Falsifier: the statement of standard cycles in Aoki 1987.
DETECTED ARITH | abstract total 47659 vs Table 2 total 47695
DETECTED DRIFT | Galois orbit described as a component of a Hodge locus in the Conclusion
DETECTED SCOPE | Theorem B quantifier widened past the open orbits of Table 3
CAUGHT C1,C2,C3
