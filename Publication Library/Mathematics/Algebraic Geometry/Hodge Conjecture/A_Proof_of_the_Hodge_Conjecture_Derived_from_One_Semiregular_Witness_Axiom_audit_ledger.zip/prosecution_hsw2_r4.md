Round 4, cycle hsw2. Registers: limit, symmetry, re-run because the round-3 batteries raised before executing (erratum ERR-1). Declared target: the Shioda attribution and da Silva's results from round 2.
Limit battery executed: 98 degrees parsed, 47695 orbits, 0 failed certificates; Shioda up to degree 20 all certified True; degree at most 100 coprime to 6 True; degrees 21 and 27 True; every odd degree up to 100 True; degrees 4 and 5 joins only True; uncertified degrees [50, 54, 66, 70, 90, 100].
Symmetry battery executed: dependency closure 30 orbits on canonical representatives, invariant under relabeling True; 9 of 9 dependents carry a standard sextuple as a direct piece.
No finding: every compatibility claim holds on the executed data, and all nine dependents carry a standard sextuple as a direct piece, as Section 5.3 states.
DETECTED ARITH | Criterion 1 degree count 97 vs 98 degrees in 3..100
DETECTED DRIFT | vanishing pair redefined as a pair with equal entries in the certificate definitions
DETECTED SCOPE | Section 1 no longer disclaims the truth of the axiom
CAUGHT C1,C2,C3
