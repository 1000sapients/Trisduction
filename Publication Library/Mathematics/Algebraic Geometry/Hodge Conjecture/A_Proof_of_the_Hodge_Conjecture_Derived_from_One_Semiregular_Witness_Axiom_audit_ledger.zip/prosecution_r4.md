Round 4. Registers: kinematic, definitional (highest historical yield). Declared targets from round 3: the rationality sentence in Section 5.1 and the isotypic-component clause in Lemma 3(ii); both prosecuted, both consistent, no finding. Kinematic battery on Proposition D re-executed below; consumer phrasings of every earlier repair swept across the whole paper.
F-14 | definitional | C1 | STRUCTURAL | Repeat of F-7 in consumer text: Section 1 states Bloch's result as deformation along every deformation, Section 2 says the cited results make representatives propagate, and the Bloch row of Table 4 says semiregular complete intersections deform along their Hodge loci, while input (I2) now gives the infinitesimal form and obtains actual deformations from existence and approximation theorems. | Falsifier: phrase count of the global form outside Section 4.
F-15 | definitional | NONE | COSMETIC | Section 1 cites Lemma 1 for "the conjecture implies both halves", but Lemma 1 proves the equivalence for a single class through the one-point family, not that the conjecture implies the variational statement for every family, which holds trivially and needs no lemma. | Falsifier: statement of Lemma 1 against the sentence citing it.
kin: degree 70 five-pair surface cover None
kin: degree 70 recursive two-pair None
kin: lift x2 level 140 three-pair surface cover None
kin: lift x3 level 210 three-pair surface cover None
kin: lift x5 level 350 three-pair surface cover None
DETECTED ARITH | Criterion 1 degree count 97 vs 98 degrees in 3..100
DETECTED DRIFT | witness no longer semiregular in The candidate paragraph
DETECTED SCOPE | Theorem B quantifier widened past the open orbits of Table 3
CAUGHT C1,C2,C3
