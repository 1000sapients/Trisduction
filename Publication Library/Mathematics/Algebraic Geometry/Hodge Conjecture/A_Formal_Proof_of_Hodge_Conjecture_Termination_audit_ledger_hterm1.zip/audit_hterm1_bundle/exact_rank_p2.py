import sys, json, time, numpy as np
sys.path.insert(0, "/home/claude/hodgeterm")
from hodge_chars import hodge_chars, comp_list
P2 = 1000000007
def build(d, coeffs):
    H = hodge_chars(d); cols = comp_list(d, 6, d-2); rows = comp_list(4*d-6, 6, d-2); ridx = {r: i for i, r in enumerate(rows)}
    A = np.zeros((len(rows), len(cols)), dtype=np.int64)
    for j, c in enumerate(cols):
        for k, b in enumerate(H):
            if all(ci + bi <= d-1 for ci, bi in zip(c, b)): A[ridx[tuple(ci+bi-1 for ci, bi in zip(c, b))], j] = coeffs[k]
    return A
def rank_mod(A, p):
    A = A % p; m, n = A.shape; r = 0
    for j in range(n):
        nz = np.nonzero(A[r:, j])[0]
        if nz.size == 0: continue
        piv = r + nz[0]
        if piv != r: A[[r, piv]] = A[[piv, r]]
        A[r, j:] = (A[r, j:] * pow(int(A[r, j]), p-2, p)) % p
        idx = r + 1 + np.nonzero(A[r+1:, j])[0]
        if idx.size: A[idx, j:] = (A[idx, j:] - (A[idx, j][:, None] * A[r, j:][None, :]) % p) % p
        r += 1
        if r == m: break
    return r
res = {}
for d in (6, 7, 8):
    t = time.time(); nH = len(hodge_chars(d)); A = build(d, np.random.default_rng(99000000 + d).integers(1, P2, size=nH, dtype=np.int64))
    res[d] = dict(rank=rank_mod(A, P2), cols=A.shape[1], secs=round(time.time()-t, 1)); print("second prime", d, res[d], flush=True)
json.dump(res, open("exact_rank_p2.json", "w"))
