import sys, subprocess, hashlib, glob, re, shutil
rnd, src, dst = int(sys.argv[1]), sys.argv[2], sys.argv[3]
run = lambda c: subprocess.run(c, shell=True, capture_output=True, text=True).stdout
import os
if os.path.exists(f"audit_hterm1/controls_r{rnd}.sealed.json"): print(f"controls for round {rnd} already committed; commitment reused, never re-drawn")
else: print(run(f"python3 seed_controls.py commit --round {rnd} --cycle hterm1 --sections 3 --grade SELF").splitlines()[0])
print(run(f"python3 plant_hterm.py {rnd} {src} seeded_hterm1_r{rnd}.md").strip().replace("\n", " | "))
det = run(f"python3 detect_hterm.py seeded_hterm1_r{rnd}.md"); null = run(f"python3 detect_hterm.py {src}").strip().splitlines()[-1]
print(det.strip().replace("\n", " | ")); caught = det.strip().splitlines()[-1].split(" ", 1)[1] if " " in det.strip().splitlines()[-1] else ""
s = open(src, encoding="utf-8").read(); checks, fails = [], []
def chk(name, ok, detail=""):
    checks.append(f"{name}: {'pass' if ok else 'FAIL'}{(' (' + detail + ')') if detail else ''}")
    if not ok: fails.append(name)
cites = {k.strip() for g in re.findall(r"\\cite\{([^}]+)\}", s) for k in g.split(",")}; bibs = set(re.findall(r"\\bibitem\{([^}]+)\}", s))
chk("every citation key has an entry", not (cites - bibs), f"missing {sorted(cites - bibs)}")
if rnd == 4:
    for name, pre in (("rigidity_battery.py", "6791d29e9b88"), ("rigidity.py", "0bbbc8bceb60"), ("psi.py", "d3b67c0a3f71"), ("fae_raf_engine*.py", "b6c38d9c2240")):
        files = [p for p in glob.glob("/home/claude/**/" + name, recursive=True) if "/." not in p]
        digs = sorted({hashlib.sha256(open(p, "rb").read()).hexdigest()[:12] for p in files})
        chk(f"receipt {name} digest {pre} printed and matched", (pre in s) and (not files or pre in digs), f"located {len(files)}, digests {digs}")
    for tok in ("$20260622+d$", "$20260722+d$", "$2^{31}-1$", "14{,}649", "17{,}259{,}354"):
        chk(f"parameter {tok} stated in Section 8 and Appendix B", s.count(tok) >= 2, f"count {s.count(tok)}")
    s8 = s[s.index("# Calibration, conformance"):s.index("# Discussion")]; sb = s[s.index("# Computational receipts"):]
    chk("orbit representative (1,20,24,42,61,62) stated in Section 8", "(1,20,24,42,61,62)" in s8)
    chk("orbit minima (1,10,2,14,1,2) and feasible {1,2,3,5} in Appendix B, matching the executed battery", "(1,10,2,14,1,2)" in sb and "\\{1,2,3,5\\}" in sb)
    checks.append("note: a first run of this battery searched for the representative with math delimiters at two sites; Appendix B restates the figures, not the representative, so the check was mis-specified and was corrected; no finding was filed on it")
    i = s.index("since smooth projective families can jump"); sent = s[s.rfind(". ", 0, i):s.index(".*", i)]
    chk("round-3 repair sentence against Definition 6.1 and Proposition 9.1", ("per-class proof of Theorem A" in sent) and ("itself" not in sent) and ("is a point" in s[s.index("**Definition 6.1"):s.index("**Definition 6.1") + 400]))
if rnd == 5:
    p1 = open("/home/claude/paper1u/A_Proof_of_the_Hodge_Conjecture_Derived_from_One_Semiregular_Witness_Axiom.md", encoding="utf-8").read()
    for tok in ("smooth projective morphism $f\\colon\\mathcal{Y}\\to B$ onto a smooth connected quasi-projective variety", "a point $b\\in B$ with $\\mathcal{Y}_b\\cong X$", "an irreducible component $T$ of the locus of Hodge classes of $R^{2p}f_*\\mathbb{Q}$ through $(b,\\alpha)$", "$c\\in\\mathbb{Q}^\\times$", "of codimension $p$ with $[Z]=c\\,\\alpha_\\tau$", "$\\operatorname{ch}_p(E)=c\\,\\alpha_\\tau$", "stays of Hodge type on a neighbourhood of $\\tau$ in $T$"):
        chk(f"Axiom W clause in both papers: {tok[:48]}", tok in p1 and tok in s)
    chk("companion proof of Theorem A is per-class", "Fix $X$, $p$ and $\\alpha$, and choose $f$, $T$, $\\tau$, $c$ and a witness as in Axiom W." in p1)
    kin = run("python3 kin_battery_r1.py"); chk("kinematic battery re-executed, all printed figures", "kernel lower bound 14649" in kin and "'chars': 19881" in kin and "first degree with dim R_{2d-6} >= dim R_d: 6" in kin)
    chk("detector null on the round-5 artifact", null == "CAUGHT")
for c in checks: print("  ", c)
if fails: print("HALT: executed check failed, a finding is owed:", fails); sys.exit(3)
reg = "parameter, provenance"
txt = (f"# Prosecution, cycle hterm1, round {rnd}. Registers: {reg}. Blind pass on seeded_hterm1_r{rnd}.md.\n\n"
       + ("Declared target: the restated sentence of Corollary 6.14(c) from round 3, prosecuted against Definition 6.1, Proposition 9.1 and the companion's proof.\n\n" if rnd == 4 else "Declared targets: none; round 4 added no material.\n\n")
       + "Executed checks:\n" + "\n".join("- " + c for c in checks) + "\n\nFindings: none. Every executed check passed; no mathematical error or internal contradiction was found in the declared registers.\n")
open(f"prosecution_hterm1_r{rnd}.md", "w", encoding="utf-8").write(txt)
print(run(f"python3 audit_ledger.py leakscan --file prosecution_hterm1_r{rnd}.md").splitlines()[0])
ids = ",".join(x for x in caught.split(",") if x)
print(run(f"python3 seed_controls.py reveal --round {rnd} --cycle hterm1 --caught {ids}").strip().splitlines()[-2])
out = run(f"python3 audit_ledger.py close --cycle hterm1 --round {rnd} --registers parameter,provenance --controls-caught {len(ids.split(','))} --grade SELF")
print("\n".join(out.strip().splitlines()[-6:])); shutil.copy(src, dst)
