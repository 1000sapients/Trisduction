# Prosecutor's executed checks on a seeded copy. Recomputes from the artifact's own formulas; checks definitional and scope invariants.
import re, sys, json
from math import comb, gcd
s = open(sys.argv[1], encoding="utf-8").read(); hits = []
def dimR(deg, d, n=6): return sum((-1)**j*comb(n,j)*comb(deg-j*(d-1)+n-1,n-1) for j in range(n+1) if deg-j*(d-1) >= 0)
m = re.search(r"counts \$([\d{},]+)\$ such monomials", s); kb = json.load(open("kin_battery_r1.json"))["bound"]
if m and int(re.sub(r"\D", "", m.group(1))) != kb: hits.append(("ARITH", f"degree-70 kernel bound printed {m.group(1)} vs recomputed {kb}"))
for row in re.findall(r"^\| (\d+) \| (\d+) \| (\d+) \| (\d+) \| (\d+) \| (\d+|not run) \|$", s, re.M):
    d = int(row[0])
    if int(row[2]) != dimR(d, d) or int(row[3]) != dimR(4*d-6, d): hits.append(("ARITH", f"Table 3 row d={d}: dim R_d {row[2]} target {row[3]} vs {dimR(d,d)} {dimR(4*d-6,d)}"))
w = re.search(r"Degree (\w+) is the first degree at which rigidity is dimensionally possible", s)
first = next(d for d in range(3, 12) if dimR(2*d-6, d) >= dimR(d, d))
if w and w.group(1) != {6: "six"}[first]: hits.append(("ARITH", f"threshold degree printed {w.group(1)} vs computed {first}"))
if re.search(r"witness seat is occupied by the rank certificate", s): hits.append(("DRIFT", "witness seat, defined as holding a cycle, normal function or axiom, used for a computational certificate"))
if re.search(r"every witness of that truth is a reading", s): hits.append(("DRIFT", "a witness of the axiom called a reading, against the definition of a deed in the same section"))
if re.search(r"and that witness transmits by Definition 4\.2", s): hits.append(("DRIFT", "finite witness said to transmit, against Definition 4.2 where a finite witness grounds"))
if not re.search(r"N7: no class is asserted to pass the three gates", s): hits.append(("SCOPE", "N7 no longer disclaims an inhabited terminus"))
if re.search(r"enumeration of reading routes, theorem\.", s): hits.append(("SCOPE", "C4 tier widened from structural to theorem"))
if re.search(r"\$d=9,10\$ the same holds at theorem grade", s): hits.append(("SCOPE", "Proposition 8.1 widens floating ranks at d=9,10 to theorem grade"))
ids = sorted({{"ARITH": "C1", "DRIFT": "C2", "SCOPE": "C3"}[h[0]] for h in hits})
for h in hits: print("DETECTED", h[0], "|", h[1])
print("CAUGHT", ",".join(ids))
