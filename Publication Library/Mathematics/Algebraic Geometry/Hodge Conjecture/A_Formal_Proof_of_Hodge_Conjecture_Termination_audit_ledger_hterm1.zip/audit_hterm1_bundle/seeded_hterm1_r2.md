---
edition: math_journal
title: "A Formal Proof of Hodge Conjecture Termination at the Formal-Alone Register"
subtitle: "The Rigid-Witness Terminus, a Theorem-Grade Cascade Specification, and the Trisductive Pricing of Its Two Flanks"
article_type: "Algebraic Geometry · Foundations of Verification"
goal: "No reader supplies the witness it would have to read"
author_line: "Mohammad F. Islam, PhD"
affiliation: "Independent Researcher · islamm@alumni.iu.edu"
date: "September 2026"
short_title: "A Formal Proof of Hodge Conjecture Termination"
keywords: "Hodge conjecture; algebraic cycles; rigid Hodge classes; infinitesimal variation of Hodge structure; arithmetic hierarchy; Sigma-one completeness; Fermat varieties; verification instruments; termination"
accenthex: "B87333"
fontsize: "10pt"
abstract: |
  The Hodge conjecture predicts that every rational class of type $(p,p)$ on a smooth complex projective variety is algebraic, and every known reduction of it moves the undetermined content without discharging it: to the Lefschetz standard conjecture, to the variational conjecture, to singular normal functions, to fields of definition. This paper proves where that relocation ends for every procedure whose input is hand-encoded formal data and which constructs nothing. Over $\overline{\mathbb{Q}}$ the Hodge condition of a class is $\Pi^0_1$, its algebraicity is $\Sigma^0_1$, each instance of the conjecture is $\Sigma^0_1$, and the conjecture is $\Pi^0_2$; the Unprovability Mirror holds for these sentences as for every arithmetic sentence, and the flanks of the Riemann pricing reverse, a true instance carrying a finite grounding witness and a false one no finite certificate. A Witness Theorem closes the three channels through which such a procedure could ground algebraicity: the witness channel by the definition of the reader, the conversion channel at the price of the three refuted conversions of Hodge data into cycles, integral, general and Kähler, and the relocation channel by a three-gate cascade of rigidity, transport closure and correspondence regress whose count, faithfulness and necessity are proved and executed. The Termination Theorem emits the terminal token $[\Psi]$ on every class the cascade certifies, invariant over the unrestricted class of formal-alone procedures and replaced only by a supplied cycle, by a rigid pair off the number fields, or by a posited semiregular witness axiom from which the conjecture follows. Read with its companion, which derives the conjecture from that axiom, the paper completes one proof, universal exactly when every instance of the axiom is witnessed, and every such witness is supplied by a construction and never by a reading. A calibration prediction called in advance, that no Hodge class on the Fermat fourfolds of degree six to ten is infinitesimally rigid, failed: exact rank computation certifies rigid rational Hodge classes in degrees six, seven and eight, algebraic by Shioda's theorem, so rigidity alone never makes a terminus. The strong falsifier is a certified class discharged by a reading with no supplied deed.
---

\hypersetup{pdftitle={A Formal Proof of Hodge Conjecture Termination at the Formal-Alone Register},pdfauthor={Mohammad F. Islam},pdfsubject={Algebraic Geometry},pdfkeywords={Hodge conjecture, rigid Hodge classes, arithmetic hierarchy, termination}}

# Introduction

Let $X$ be a smooth complex projective variety of dimension $n$ and $0\le p\le n$. Write $\operatorname{Hdg}^p(X)=H^{2p}(X,\mathbb{Q})\cap H^{p,p}(X)$ for the rational Hodge classes and $\operatorname{Alg}^p(X)\subseteq\operatorname{Hdg}^p(X)$ for the $\mathbb{Q}$-span of classes of algebraic cycles. The Hodge conjecture asserts $\operatorname{Alg}^p(X)=\operatorname{Hdg}^p(X)$ \cite{hodge1950,deligne2006}. It holds for $p=1$ by the Lefschetz theorem on $(1,1)$-classes and for $p=n-1$ by hard Lefschetz, for abelian varieties of dimension at most five through Markman's secant construction \cite{markman2025b}, for Fermat varieties of degree at most twenty \cite{shioda1979,dasilva2021}, and in further special families. It is open in the middle codimensions of every dimension $n\ge 4$.

**Three questions kept apart.** Three questions about the conjecture are routinely run together. The first is whether it is true. The second is whether it is derivable in a given formal system. The third is whether any procedure whose entire input is hand-encoded formal data, and which constructs nothing, can ground the algebraicity of a given Hodge class. This paper proves a theorem about the third question, proves an exact equivalence showing why the second cannot be universally closed in the negative without answering the first, and asserts nothing about the first.

**What is proved.** Over $\overline{\mathbb{Q}}$ the Hodge condition of a rational class is $\Pi^0_1$, its algebraicity is $\Sigma^0_1$, every instance of the conjecture is $\Sigma^0_1$ and the conjecture itself is $\Pi^0_2$ (Section 5). The Unprovability Mirror follows: asserting that no consistent recursively axiomatized extension of Robinson arithmetic proves an instance is materially asserting that Robinson arithmetic refutes it, which entails that the instance fails. A Witness Theorem closes the channels through which a formal-alone procedure could ground algebraicity (Theorem 6.8). A three-gate cascade certifies the classes on which every reading route is closed, with its count, faithfulness and necessity proved and executed, and the Termination Theorem emits the terminal token $[\Psi]$ on every class it certifies (Theorem 6.12). A calibration prediction called in advance failed and is reported as it fell (Section 8). Read with its companion \cite{islam2026w}, which derives the conjecture from one semiregular witness axiom, the two papers form one proof, and Proposition 9.1 states the single condition under which that proof is universal.

**The verdict economy.** Verdicts issue in three states: sealed, broken with a named mechanism, and under-determined with a named violation. Three refinements of the under-determined state are terminal for the record and are never a fourth state. The token $[\Xi_0]$ marks a halt in the reader, an orientation the instrument is blind to by theorem. The token $[\text{\O}_0]$ marks a halt in the terrain, a question with no fixed locus walled by structural barriers. The token $[\Psi]$, introduced here, marks a halt at the witness, a class on which every reading route is closed and no witness has been supplied. A terminal verdict is correct at issuance and is replaced, never corrected, by a supplied witness.

**The flanks reverse.** For the Riemann Hypothesis in its Lagarias form, a $\Pi^0_1$ sentence, the refuting flank is one finite certificate away and the affirmative flank admits no formal grounding witness \cite{islam2026rh}. For the Hodge conjecture the pricing reverses at the level of an instance: a true instance carries a finite witness, a cycle, which grounds because it presupposes nothing, while a false instance carries no finite certificate. What is absent at the terminus is therefore not the possibility of a grounding witness. It is its supply.

# Background and the barrier

**The cycle class map.** The conjecture is the surjectivity of the cycle class map $\operatorname{cl}\colon CH^p(X)_{\mathbb{Q}}\to\operatorname{Hdg}^p(X)$. Its injectivity fails and is irrelevant. The kernel is the group of cycles homologous to zero, which Mumford showed is infinite-dimensional for zero-cycles on surfaces with $p_g>0$ \cite{mumford1969}, which Griffiths showed differs from algebraic equivalence \cite{griffiths1969}, and whose quotient Clemens showed is not finitely generated \cite{clemens1983}. Many cycles land on one class. What is open is whether some cycle lands on each Hodge class.

**Three walls.** Three classical failures fix the toolkit any argument must use. With integral coefficients the statement is false, for torsion classes \cite{ah1962} and for non-torsion integral classes on very general hypersurfaces \cite{kollar1992}, with further failures in low dimension \cite{totaro1997,bo2020}, so rational coefficients are forced. On compact Kähler manifolds the analytic analogue is false, Hodge classes on some complex tori not being spanned by Chern classes of coherent sheaves \cite{voisin2002}, so an ample class is forced. And since the fibres of $\operatorname{cl}$ are torsors under kernels no finite-dimensional algebraic parameter space controls, no argument of the exponential-sequence type that proves the case $p=1$ extends to codimension at least two. The first two walls are theorems about objects. The third is a wall on methods.

**Five relocations.** Every known reduction moves the undetermined content and leaves it undetermined. *Motivic.* The conjecture is equivalent to the full faithfulness of the functor from motives to Hodge structures \cite{deligne2006}; it implies the Lefschetz and Künneth standard conjectures \cite{kleiman1968}; the Lefschetz standard conjecture for all varieties implies the variational conjecture and hence the conjecture for products of abelian varieties and K3 surfaces \cite{andre1996}. The route arrives owing the existence of algebraic cycles on products. *Variational.* Hodge loci are algebraic \cite{cdk1995}, and the variational conjecture propagates algebraicity along them; the route arrives owing one algebraic point on each locus. *Transport.* Algebraic correspondences carry classes between varieties, and algebraicity of a source class transports to its image; the route arrives owing algebraicity of the source. *Degeneration.* The conjecture is equivalent to the existence of singularities of certain admissible normal functions on ample pencils of hyperplane sections \cite{gg2007,thomas2005,bfnp2009}; the route arrives owing a singularity. *Arithmetic.* If the conjecture holds, the components of the locus of Hodge classes in a family defined over $\overline{\mathbb{Q}}$ are defined over $\overline{\mathbb{Q}}$, and the conjecture reduces to varieties over number fields for classes whose locus is so defined \cite{voisin2007}; the route arrives owing the conjecture over number fields.

**The frontier.** For a variation of Hodge structure of level at least three, the positive-period-dimension part of the Hodge locus is a finite union of special subvarieties, and the only part of the locus left unelucidated by the typical-atypical analysis is the atypical special subvarieties of zero period dimension \cite{bku2024}; atypical points appear out of reach in full generality \cite{ku2024}.

**The terminus.** A pair $(X,\alpha)$ is rigid when $\alpha$ fails to remain a Hodge class under every nontrivial deformation of $X$. The conjecture would be disproved by a rigid pair with $X$ not defined over a number field \cite{voisin2016}. At a rigid class the variational route has nothing to propagate. The transport route and the motivic route remain, and where both are closed as well, no relocation moves the class.

**The one bit and the tower.** At such a class Hodge theory fixes $\alpha$ completely: it is rational, it lies in $F^p$, and it has no deformations. The only undetermined datum is whether $\alpha$ lies in the image of $\operatorname{cl}$, one bit. The motivic construction of cycles from cycles runs through correspondences on $X\times X$, and the canonical ones, the Künneth projectors and the inverse Lefschetz operator $\Lambda$, are rational Hodge classes on $X\times X$ whose algebraicity is the conjecture on $X\times X$ \cite{kleiman1968}. The tower $X\to X\times X\to (X\times X)^2\to\cdots$ therefore has no floor of its own. Direct constructions do not route through it: linear subspaces and joins on Fermat varieties \cite{shioda1979,sk1979}, the secant sheaves behind the Weil classes on abelian fourfolds \cite{markman2025b}.

**What kind of block.** The barrier is neither a blindness of the reader nor a groundless terrain. The reader reads every determinate datum, and the class is determinate. The witness is absent, and a reader cannot author it. The block is supply-side. Table 1 records the ledger.

| Level | Result | Status | What it forces |
|:--|:--|:--|:--|
| Coefficients | \cite{ah1962,kollar1992} | proven wall | rational coefficients |
| Category | \cite{voisin2002} | proven wall | an ample class |
| Method | \cite{mumford1969,griffiths1969,clemens1983} | wall on methods | no cycle parameter space |
| Motivic | \cite{deligne2006,andre1996,kleiman1968} | implications | cycles on products |
| Variational | \cite{cdk1995} | reduction | one point per locus |
| Transport | correspondences | reduction | a source class |
| Degeneration | \cite{gg2007,thomas2005} | equivalence | a singular fibre |
| Arithmetic | \cite{voisin2007} | reduction | number fields |
| Frontier | \cite{bku2024,ku2024} | theorem, named exception | zero period dimension |
| Terminus | \cite{voisin2016} | disproof criterion | the block cannot move |

Table: The barrier ledger. Grade: theorem by citation in every row; the typing of rows as walls, relocations, frontier and terminus is structural.

# Prior approaches

**Codimension one.** The Lefschetz theorem proves the case $p=1$ through the exponential sequence, which classifies line bundles by a cohomological invariant, and hard Lefschetz carries it to $p=n-1$. The argument constructs cycles from Hodge data by formal means where a parameter space of the right size exists. In codimension at least two the third wall of Section 2 removes that parameter space.

**Absolute Hodge and motivated classes.** Deligne proved that Hodge classes on abelian varieties are absolute Hodge \cite{deligne1982}, and André proved that they are motivated, algebraicity then following from the Lefschetz standard conjecture on the auxiliary varieties his construction introduces \cite{andre1996}. Lieberman proved the Lefschetz standard conjecture for abelian varieties themselves \cite{lieberman1968}. These results relocate algebraicity to correspondences on auxiliary varieties. They discharge it nowhere the correspondences are unsupplied.

**Hodge loci and propagation.** The algebraicity of Hodge loci \cite{cdk1995} makes the variational conjecture a statement about algebraic families, and the distribution theorems of Baldi, Klingler and Ullmo locate every special subvariety except the atypical ones of zero period dimension \cite{bku2024}. Propagation reduces a class to one point of its locus and requires a first cycle there.

**Normal functions.** Thomas reduced the conjecture to the existence of hyperplane sections with nodes carrying the class \cite{thomas2005}, Green and Griffiths recast it as the existence of singularities of admissible normal functions \cite{gg2007}, and Brosnan, Fang, Nie and Pearlstein proved the loci of such singularities algebraic \cite{bfnp2009}. The equivalence locates the missing datum at a singular fibre and supplies no singularity.

**Fields of definition.** Voisin reduced the conjecture to varieties over number fields for classes whose Hodge locus is defined over $\overline{\mathbb{Q}}$ and gave a criterion under which a rigid pair over a transcendental field would disprove it \cite{voisin2007,voisin2016}. The reduction relocates the question into arithmetic without answering it there.

**Special points and constructions.** Shioda proved the conjecture for Fermat varieties of small degree through linear subspaces, joins and the inductive structure \cite{shioda1979,sk1979,dasilva2021}, and Markman proved the algebraicity of Weil classes on abelian fourfolds of Weil type through semiregular secant sheaves \cite{markman2025b}. Mostaed studied Weil classes at the points where McMullen's curve meets the Weil locus in a Hilbert modular sixfold and recorded an obstruction by CM isolation \cite{mostaed2026}; the same preprint shows each component of the Weil locus smooth of codimension three, so the Weil classes remain Hodge along a positive-dimensional locus, and the isolation belongs to the intersection point rather than to the class.

Every approach above either restates the conjecture, reduces it to further conjectures, supplies a witness by construction in a restricted family, or relocates the undetermined bit to a place where it remains undetermined. None supplies a witness at a class that no relocation reaches, which is the gap Section 2 identified and Section 6 types.

# Method

The results must satisfy three conditions. First, formal derivation: every theorem follows from the definitions printed below and from cited results, each quoted with its hypotheses. Second, executed signature: every figure in the paper is the output of a deterministic battery at the stated seed or of an exact computation, with its code and digest recorded in Appendix B. Third, invariance: the verdict is invariant over the entire unrestricted class of readers of Definition 4.3, never over a narrowed subclass.

**Definition 4.1 (Presentation).** A presentation $P$ of a class-level file comprises: a smooth projective variety $X$ over $\mathbb{C}$ given by equations over a field of definition $k\subset\mathbb{C}$; an integer $p$ and a rational class $\alpha$ given by coordinates in a computed basis of $H^{2p}(X(\mathbb{C}),\mathbb{Q})$; the Hodge data, a period matrix to any requested precision together with the Hodge filtration; the deformation data, the infinitesimal variation of Hodge structure on $H^1(T_X)$; the locus datum, the component through $X$ of the Hodge locus of $\alpha$ in the universal deformation; the correspondence census, the known correspondences carrying classes on other varieties onto $\alpha$ together with the reached status of the source classes; the motivic census, the status of the correspondences the motivic route requires on $X\times X$ and on auxiliary varieties; the field datum; and a witness seat, empty or occupied by a cycle, by a singular admissible normal function, or by a posited axiom.

**Definition 4.2 (Derivation and grounding).** A derivation of a sentence $\varphi$ is a finite proof object in some consistent recursively axiomatized theory $T\supseteq Q$. It transmits the warrant of $T$. It grounds $\varphi$ only if the warrant it delivers does not presuppose $\varphi$ and rests on no posit outside the derivation. A finite witness for a $\Sigma^0_1$ sentence, checked by a decidable verification, presupposes nothing and grounds.

**Definition 4.3 (Readers).** The formal-alone class $\mathcal{F}_\Psi$ is the class of all functions of presentations with an empty witness seat, valued in $\{\text{resolve},\text{refute},\text{abstain}\}$, with no restriction on functional form, subject to one provenance rule: a cycle, a singular normal function or an axiom produced in the course of a procedure is a construction, and it enters the verdict only through the witness seat. A procedure that searches for cycles and finds one has performed a deed and supplied a witness. It has not read one.

**Condition 4.4 (Seal Existence).** An existence seal on a class issues only where the witness seat is occupied.

**Warrant tiers.** Every claim carries one tier: theorem, a deduction from printed definitions or cited results; structural, an identification or placement argument; engineering, an executed and reproducible computational fact; premise, a printed entry condition. The tier travels with the claim and never inflates.

# The arithmetic form and the Mirror

Throughout this section $X$ is a smooth projective variety over a number field $K\subset\overline{\mathbb{Q}}$ presented by homogeneous equations, $0\le p\le n$, and $\alpha\in H^{2p}(X(\mathbb{C}),\mathbb{Q})$ is given by rational coordinates in a basis computed from a triangulation.

**Lemma 5.1 (The Hodge condition is $\Pi^0_1$).** *The predicate $\alpha\in\operatorname{Hdg}^p(X)$ is $\Pi^0_1$ in the presentation.*

*Proof.* The algebraic de Rham cohomology $H^{2n-2p}_{\mathrm{dR}}(X/K)$ with its Hodge filtration is computable \cite{grothendieck1966,walther2000}. Cup product pairs $F^pH^{2p}$ with $F^{n-p+1}H^{2n-2p}$ into $F^{n+1}H^{2n}=0$, and by nondegeneracy and a dimension count the annihilator of $F^{n-p+1}H^{2n-2p}$ in $H^{2p}(X,\mathbb{C})$ is exactly $F^p$. For a rational class, $\alpha\in F^p$ is equivalent to $\alpha\in H^{p,p}$, since $\alpha=\bar\alpha$. Hence $\alpha$ is Hodge if and only if $\int_{\gamma_\alpha}\omega_j=0$ for a basis $\omega_1,\dots,\omega_r$ of $F^{n-p+1}H^{2n-2p}_{\mathrm{dR}}(X/K)$, where $\gamma_\alpha$ is the Poincaré dual topological cycle. Each integral is a period of $X$ and a computable complex number \cite{kz2001}. The vanishing of a computable complex number is a $\Pi^0_1$ condition, and a finite conjunction of $\Pi^0_1$ conditions is $\Pi^0_1$. $\square$

**Lemma 5.2 (Algebraicity is $\Sigma^0_1$).** *The predicate $\alpha\in\operatorname{Alg}^p(X)$ is $\Sigma^0_1$ in the presentation.*

*Proof.* If $\alpha$ is algebraic on $X_{\mathbb{C}}$, it is a rational combination of classes of cycles defined over $\overline{\mathbb{Q}}$ by the standard specialization argument \cite{voisin2007}. The predicate is therefore the existence of a finite object, subschemes $Z_1,\dots,Z_k$ of $X$ presented over $\overline{\mathbb{Q}}$ and rationals $q_1,\dots,q_k$, together with the verification $\sum_i q_i\operatorname{cl}(Z_i)=\alpha$. The verification is decidable: an effective semialgebraic triangulation of the pair $(X(\mathbb{C}),Z_i(\mathbb{C}))$, viewed as real semialgebraic sets over the real algebraic numbers, yields the fundamental class of $Z_i$ as a simplicial cycle and its coordinates in the computed basis exactly \cite{bpr2006}. $\square$

**Proposition 5.3 (Instances and the file).** *For each presentation, the instance $\mathrm{HC}(X,\alpha)$, that $\alpha$ is algebraic if it is Hodge, is $\Sigma^0_1$. The conjecture over $\overline{\mathbb{Q}}$, the conjunction of all instances, is $\Pi^0_2$.*

*Proof.* The instance is the disjunction of the negation of a $\Pi^0_1$ predicate and a $\Sigma^0_1$ predicate, by Lemmas 5.1 and 5.2, hence $\Sigma^0_1$. Smooth projective varieties over $\overline{\mathbb{Q}}$ with their computed bases and rational classes are effectively enumerable, smoothness being decidable by the Jacobian criterion, so universal quantification over presentations gives $\Pi^0_2$. $\square$

**Theorem 5.4 (Unprovability Mirror).** *Let $\mathcal{T}$ be the class of consistent recursively axiomatized theories $T\supseteq Q$. For every sentence $\varphi$ of arithmetic, $\big(\forall T\in\mathcal{T}:T\nvdash\varphi\big)\iff Q\vdash\neg\varphi$. If $\mathbb{N}\models Q$, both sides imply $\mathbb{N}\models\neg\varphi$.*

*Proof.* If $Q\vdash\neg\varphi$, a theory in $\mathcal{T}$ proving $\varphi$ would prove a contradiction. If $Q\nvdash\neg\varphi$, then $Q+\varphi$ is consistent, recursively axiomatized and extends $Q$, and it proves $\varphi$. The last clause is the soundness of $Q$ in $\mathbb{N}$. $\square$

**Corollary 5.5 (True instances are derivable).** *If an instance $\mathrm{HC}(X,\alpha)$ is true, then $Q\vdash\mathrm{HC}(X,\alpha)$. Consequently the assertion that no theory in $\mathcal{T}$ proves an instance is materially the assertion that $Q$ refutes it, which entails that the instance fails, a Hodge class that is not algebraic, although the failure of an instance does not by itself entail its refutation in $Q$; and the assertion that no theory in $\mathcal{T}$ proves the conjecture over $\overline{\mathbb{Q}}$ is materially its refutation in $Q$.*

*Proof.* A true $\Sigma^0_1$ sentence is provable in $Q$ by $\Sigma^0_1$-completeness \cite{kaye1991,hp1993}. The rest is Theorem 5.4. $\square$

**Corollary 5.6 (The flanks, priced).** *At an instance, the constructive flank is one finite witness away, a cycle with its decidable verification, and that witness grounds by Definition 4.2; the refuting flank is $\Pi^0_1$ and no finite verification closes it. At the file, the affirmative flank is $\Pi^0_2$ and the refuting flank is $\Sigma^0_2$, and neither closes by a finite certificate. The geometric refuting door, a rigid pair over a transcendental field \cite{voisin2016}, lies outside the arithmetic form.*

**Remark 5.7 (Against the Riemann pricing).** For the Lagarias sentence the refuting flank is finite and the affirmative flank admits no formal grounding witness. Here the affirmative flank of an instance has one. The block this paper locates is therefore not a fixed-point impossibility on the affirmative seat. It is the absence of supply at a class no relocation reaches, and a reader, by Definition 4.3, supplies nothing.

# The Witness Theorem, the cascade, and termination

**Definition 6.1 (Rigidity).** The pair $(X,\alpha)$ is rigid when the component through $X$ of the Hodge locus of $\alpha$ in the universal deformation of $X$ is a point, and infinitesimally rigid when the Zariski tangent space of that component at $X$ is zero. Infinitesimal rigidity implies rigidity.

**Proposition 6.2 (Jacobian-ring criterion).** *Let $X=\{F=0\}\subset\mathbb{P}^{n+1}$ be a smooth hypersurface of degree $d\ge 3$ with $n\ge 3$ even, so that $H^1(T_X)\cong R_d$ for the Jacobian ring $R=\mathbb{C}[x_0,\dots,x_{n+1}]/J(F)$. Under Griffiths' residue isomorphism $H^{n-q,q}_{\mathrm{prim}}\cong R_{(q+1)d-n-2}$, let $\omega\in R_{(n/2+1)d-n-2}$ represent the primitive part of $\alpha\in\operatorname{Hdg}^{n/2}(X)$. The Zariski tangent space at $X$ of the Hodge locus of $\alpha$ is the kernel of*
$$\mu_\omega\colon R_d\longrightarrow R_{(n/2+2)d-n-2},\qquad G\longmapsto G\,\omega,$$
*and $(X,\alpha)$ is infinitesimally rigid if and only if $\mu_\omega$ is injective.*

*Proof.* A first-order deformation $G\in R_d$ keeps $\alpha$ of Hodge type exactly when the component of $\nabla_G\alpha$ in $H^{n/2-1,n/2+1}$ vanishes, and under the residue isomorphism that component is $G\,\omega$ up to a nonzero constant \cite{cg1980}. The multiple of the hyperplane power in $\alpha$ remains of Hodge type under every deformation and contributes nothing. $\square$

**Lemma 6.3 (Rational density).** *Let $H\subseteq H^n(X,\mathbb{Q})_{\mathrm{prim}}$ be a $\mathbb{Q}$-subspace of Hodge classes and, for coordinates $\kappa$ of a class of $H$ in an eigenbasis, let $M(\kappa)$ be the matrix of $\mu_\omega$. If $M(\kappa_0)$ has full column rank at one complex point $\kappa_0$, then infinitesimally rigid classes in $H$ form a nonempty Zariski-open subset of $H\otimes\mathbb{C}$, and that subset contains rational classes.*

*Proof.* The entries of $M(\kappa)$ are linear in $\kappa$, so full column rank is the nonvanishing of some maximal minor, a polynomial condition that holds at $\kappa_0$ and hence on a nonempty Zariski-open set. The rational points of $H$ are Zariski dense in $H\otimes\mathbb{C}$, and the change from Betti coordinates to eigen-coordinates is an invertible linear map, which preserves density. $\square$

**Definition 6.4 (Transport closure).** The class $\alpha$ is transport-closed when no smooth projective variety $Y$, correspondence $\Gamma\in CH(Y\times X)_{\mathbb{Q}}$ and Hodge class $\beta$ on $Y$ satisfy $\Gamma_*\beta=\alpha$ with $\beta$ reached, meaning obtained from the supplied set by the routes of Theorem 6.7 without passing through $\alpha$. Non-rigidity of the source pair does not suffice: for an elliptic curve $E$ the class $\beta=\operatorname{pr}_X^*\alpha\cup\operatorname{pr}_E^*[\mathrm{pt}]$ on $X\times E$ remains Hodge as $E$ varies and the graph of the projection carries it onto $\alpha$, while its algebraicity on every fibre is the algebraicity of $\alpha$.

**Definition 6.5 (Correspondence regress).** The regress is live at $\alpha$ when every correspondence the motivic route requires in order to produce a cycle representing $\alpha$, on $X\times X$ or on the auxiliary varieties of the motivated construction, has a class whose algebraicity is not supplied at $(X,\alpha)$.

**Lemma 6.6 (The tower).** *The Künneth projectors of $X$ and the class of the inverse Lefschetz operator $\Lambda_X$ are rational Hodge classes on $X\times X$. The conjecture for $X\times X$ implies the Lefschetz and Künneth standard conjectures for $X$, and the Lefschetz standard conjecture for all varieties implies the variational conjecture and the conjecture for products of abelian varieties and K3 surfaces.*

*Proof.* The first two assertions are in \cite{kleiman1968}, the third in \cite{andre1996}. $\square$

**Theorem 6.7 (The reading routes).** *Let $S$ be a set of supplied cycles on smooth projective varieties. A class that a reader obtains from $S$ without constructing lies in the smallest set containing $\operatorname{cl}(S)$ and closed under specialization and generization along families on which the class remains Hodge wherever propagation is a theorem, and under the action of correspondences whose classes lie in the set. A class is therefore reached only through a positive-dimensional Hodge locus through it, through a correspondence carrying a reached class onto it, or through a correspondence on $X\times X$ or on an auxiliary variety whose class is reached.* Grade: structural.

*Argument.* The operations of intersection theory producing cycle classes from cycle classes, proper push-forward, flat pull-back, refined Gysin maps and exterior products, are actions of correspondences, and Chern classes of bundles built from supplied cycles are expressed through them by Grothendieck-Riemann-Roch \cite{fulton1998}. The only operation that moves a cycle between the fibres of a family rather than between varieties is specialization, which carries a class along a locus on which it remains Hodge. Sorting the correspondence actions by whether the source variety is another variety or a product built from $X$ gives the three routes.

**Theorem 6.8 (Witness Theorem).** *No $V\in\mathcal{F}_\Psi$ grounds the algebraicity of a class that is rigid, transport-closed and regress-live and whose witness seat is empty.*

*Proof.* A function of presentations can vary along three channels. *Witness channel.* A cycle, a singular normal function or an axiom produced in the course of the procedure enters only through the witness seat by the provenance rule of Definition 4.3, and the seat is empty. *Conversion channel.* An output of resolve with no witness converts Hodge data into existence by fiat. Such an output presupposes the algebraicity it reports or rests on a posit the procedure does not supply, and it grounds nothing by Definition 4.2. The classical price of spending the conversion is Theorem 6.9(i) to (iii): the conversion from Hodge-type data to algebraic or analytic existence is refuted in the three registers adjacent to the rational projective one. *Relocation channel.* By Theorem 6.7 a reading reaches the class only through a positive-dimensional Hodge locus, closed by rigidity, through a correspondence from a reached class, closed by transport closure, or through a correspondence on $X\times X$ or an auxiliary variety whose class is reached, closed by the live regress. The three channels exhaust the ways a function of presentations can vary. $\square$

**Theorem 6.9 (The walls).** *(i) Integral wall: there are integral Hodge classes that are not integral combinations of algebraic classes, torsion \cite{ah1962} and non-torsion \cite{kollar1992}. (ii) General wall: Hodge's generalized conjecture, stated in terms of Hodge level, is false, and the true statement requires geometric coniveau \cite{grothendieck1969}. (iii) Kähler wall: on some compact Kähler manifolds rational Hodge classes are not spanned by Chern classes of coherent sheaves \cite{voisin2002}. (iv) Mirror wall: converting a terminal verdict into the assertion that no theory proves the class algebraic asserts the failure of the instance, by Corollary 5.5.* Each is a theorem about objects rather than about methods, and no change of reader re-opens it.

| Stage | Field read | Passes when | Otherwise |
|:--|:--|:--|:--|
| Intake R0 | coefficients, category | rational, projective | unread: $[?]$; refuted: broken |
| Intake I1 | the string | one class | a family: $[?]$ |
| Constructive door | witness seat | occupied | continue |
| Gate $\Psi$-1 | locus datum | rigid | $[?]$, relocatable |
| Refuting door | field datum | rigid over a transcendental field | continue |
| Gate $\Psi$-2 | correspondence census | transport-closed | $[?]$ |
| Gate $\Psi$-3 | motivic census | regress live | $[?]$ |
| Riders | companion face, aperture, revision | all present | $[?]$ |

Table: The cascade and its emitter, read top to bottom, first failure terminal. An occupied seat routes to resolve; a rigid pair over a transcendental field routes to broken; a class passing every row receives $[\Psi]$. Grade: structural on the field typing; engineering on the executed controls of Theorem 6.11.

**Definition 6.10 (The cascade).** The cascade is the ordered procedure of Table 2. Its three riders are a decided companion face on the same object, exactly one sentence naming the constructive door, and survival of the verdict under reframing in both directions.

**Theorem 6.11 (Count, faithfulness, necessity).** *The cascade has exactly three gates. Each gate reads only its declared field and passes exactly when that field certifies its route closed. Deleting any one gate admits an exhibited control that the full cascade refuses.*

*Proof.* The count is the enumeration of Theorem 6.7, one gate per reading route, and inherits its structural grade; no symmetry forcing is claimed, and a fourth reading route would add a fourth gate. Faithfulness holds by construction of Table 2. Necessity is executed: for each gate a control failing at exactly that gate is refused at that gate, and with that gate deleted the same control receives the token, three controls of three and three leaks of three (Appendix B). $\square$

**Theorem 6.12 (Termination).** *On every class-level file that passes the intake, the three gates and the riders with the witness seat empty, the emitter issues $[\Psi]$. The emission is invariant over $\mathcal{F}_\Psi$ and terminal for the record on the formal-alone register, and it is replaced, never corrected, only through the exits of Corollary 6.14.*

*Proof.* The emission follows from Table 2. Invariance is Theorem 6.8: no reader grounds the algebraicity the token leaves open, so no reader displaces it. Terminality is the conjunction of the Witness Theorem with the walls of Theorem 6.9, which no change of reader re-opens. Revision typing is Corollary 6.14. $\square$

**Corollary 6.13 (The Tower Block).** *On the motivic route the constructive seat recurs: a witness for $\alpha$ on $X$ requires the algebraicity of a canonical class on $X\times X$, whose witness requires the algebraicity of a canonical class on $(X\times X)^2$, without end. The tower admits no finite solution internal to it, and a solution is a construction that does not route through it.*

*Proof.* Lemma 6.6 applied at each level of the tower, with the regress live at each. $\square$

**Corollary 6.14 (The exits).** *(a) A supplied cycle representing $\alpha$ resolves the file and grounds by Definition 4.2 and Corollary 5.5. (b) A rigid pair $(X,\alpha)$ with $X$ not defined over a number field breaks the conjecture \cite{voisin2016}. (c) Axiom W, the semiregular witness axiom of \cite{islam2026w}, posited: for every smooth complex projective $X$, every $p$ and every $\alpha\in\operatorname{Hdg}^p(X)$ there exist a smooth projective morphism $f\colon\mathcal{Y}\to B$ onto a smooth connected quasi-projective variety, a point $b\in B$ with $\mathcal{Y}_b\cong X$, an irreducible component $T$ of the locus of Hodge classes of $R^{2p}f_*\mathbb{Q}$ through $(b,\alpha)$, a point $\tau\in T$ lying over $s\in B$ and $c\in\mathbb{Q}^\times$, together with a witness on $\mathcal{Y}_s$: a local complete intersection subscheme $Z$ of codimension $p$ with $[Z]=c\,\alpha_\tau$ whose semiregularity map is injective, or a coherent sheaf $E$ with $\operatorname{ch}_p(E)=c\,\alpha_\tau$ whose semiregularity map is injective and the flat continuation of every $\operatorname{ch}_q(E)$ of which stays of Hodge type on a neighbourhood of $\tau$ in $T$. Axiom W implies the conjecture for every $X$ and every $p$ \cite{islam2026w}. Posited as a seed, it replaces the token by a seal conditional on the seed, the undetermined bit delivered by the act of positing and never sourced by the formal register. At a rigid class Axiom W demands its witness on $X$ itself, and its rigid face implies the instance; whether the instance implies it is open.*

# Falsification criteria

**F1, on Theorem 6.12.** *Prediction.* No class certified through the three gates with an empty witness seat is ever shown algebraic by a reading route alone. *Method of confirmation.* Screen every published resolution of a Hodge class whose locus is a point for what was supplied at the point. *Expected outcome.* Every such resolution supplies a cycle, a singular normal function or an axiom at the point. *Null hypothesis.* A certified class shown algebraic by propagation, by transport or by a realized canonical correspondence, with nothing supplied at the point, falsifies Theorem 6.12. *Necessity and blast radius.* The criterion is forced by the enumeration of Theorem 6.7 together with the provenance rule of Definition 4.3, and its firing compromises Theorem 6.12 and nothing above it.

**F2, on Theorem 6.7.** *Prediction.* Every operation by which a reader obtains a cycle class from supplied cycles is a specialization along a Hodge locus or a correspondence action. *Method of confirmation.* Test each operation used in a published algebraicity proof against the two types. *Expected outcome.* Each is one of the two. *Null hypothesis.* A fourth operation producing a representative of a class from supplied cycles elsewhere, neither a specialization nor a correspondence action, falsifies Theorem 6.7 and the count of Theorem 6.11. *Necessity and blast radius.* The criterion is forced by the count, and its firing compromises Theorems 6.7 and 6.11 and nothing above them.

The calibration prediction of Section 8 is not a criterion on any theorem. It was placed at risk to calibrate the first gate, and it is reported as it fell.

# Calibration, conformance, and a failed prediction

**The prediction, called in advance.** Before any kernel was computed, the following was registered: no Hodge class on the Fermat fourfolds $X_d=\{x_0^d+\cdots+x_5^d=0\}$ of degree $6\le d\le 10$ is infinitesimally rigid in the family of hypersurfaces. Degree six is the first degree at which rigidity is dimensionally possible, since $h^{3,1}_{\mathrm{prim}}=\dim R_{2d-6}$ first reaches $\dim R_d$ there, every Hodge locus of lower degree having positive dimension.

**The computation.** The primitive cohomology of $X_d$ splits into one-dimensional eigenspaces indexed by characters $a\in\{1,\dots,d-1\}^6$ with $\sum_i a_i\equiv 0 \pmod d$, and the eigenspace of $a$ is of type $(2,2)$ when $\sum_i a_i=3d$. The span $H_d$ of the eigenspaces whose whole Galois orbit is of type $(2,2)$, those $a$ with $\sum_i(ta_i \bmod d)=3d$ for every unit $t$ modulo $d$, is defined over $\mathbb{Q}$ and consists of Hodge classes. The Fermat Jacobian ring is $R=\mathbb{C}[x]/(x_0^{d-1},\dots,x_5^{d-1})$, the eigenspace of $a$ is represented by $x^{a-1}$, and the matrix of $\mu_\omega$ for a class with eigen-coordinates $\kappa$ sends the monomial $x^c\in R_d$ to $\sum_a\kappa_a x^{c+a-1}$, the terms with an exponent at least $d-1$ vanishing. Its generic rank was computed in floating point with coordinates drawn at seed $20260622+d$, and exactly over the prime field of order $2^{31}-1$ with integer coordinates drawn at seed $20260722+d$ in degrees six to eight.

| $d$ | characters | $\dim R_d$ | target | rank | exact rank |
|:--|--:|--:|--:|--:|--:|
| 6 | 1751 | 426 | 426 | 426 | 426 |
| 7 | 1860 | 756 | 1161 | 756 | 756 |
| 8 | 5881 | 1251 | 2667 | 1251 | 1251 |
| 9 | 8000 | 1966 | 5432 | 1966 | not run |
| 10 | 19881 | 2967 | 10116 | 2967 | not run |

Table: The calibration battery. Target is $\dim R_{4d-6}$; rank is the floating generic rank; exact rank is the rank over the field of order $2^{31}-1$. The smallest singular value relative to the largest is $2.65\times10^{-4}$, $0.0967$, $0.171$, $0.212$ and $0.243$ in degrees six to ten, against a rank tolerance below $3\times 10^{-12}$. Grade: theorem, computer-assisted, in degrees six to eight; engineering in degrees nine and ten.

**Proposition 8.1 (Rigid rational classes exist).** *For $d=6,7,8$ there are rational Hodge classes $\alpha$ on $X_d$ for which $(X_d,\alpha)$ is infinitesimally rigid. For $d=9,10$ the same holds at theorem grade.*

*Proof.* For $d\le 8$ the integer matrix has full column rank modulo $2^{31}-1$ (Table 3), hence full column rank over $\mathbb{Q}$ and full generic rank over $\mathbb{C}$. Lemma 6.3 gives rational classes with injective $\mu_\omega$, and Proposition 6.2 gives infinitesimal rigidity. For $d=9,10$ the floating rank is full with the singular-value gaps of Table 3. $\square$

**Corollary 8.2.** *Each class of Proposition 8.1 is algebraic, by Shioda's theorem for Fermat varieties of degree at most twenty \cite{shioda1979,dasilva2021}. Its witness seat is occupied classically, and the cascade routes it to resolve before any gate reads it. The rigid pairs are defined over $\mathbb{Q}$, as Voisin's criterion requires of every rigid pair if the conjecture holds.*

**What the failure shows.** The prediction failed at every degree. The rigidity gate is inhabited at special points, and the classes that inhabit it carry classical cycles. Rigidity alone is therefore not the terminus: the token requires the conjunction of the three gates with an empty seat, and the calibration certifies the independence of the first gate from the constructive door.

**Conformance.** *A single-orbit class at degree seventy.* For the Galois orbit of $a=(1,20,24,42,61,62)$ on $X_{70}$, every monomial $x^c\in R_{70}$ with $c_i\ge 70-\min_t(ta_i\bmod 70)$ for some coordinate kills every eigen-component of every class supported on the orbit, and inclusion and exclusion over the four feasible coordinates counts $16{,}449$ such monomials in a deformation space of dimension $17{,}259{,}354$. Orbit-supported classes there are not infinitesimally rigid and are not certified at the first gate. *Weil classes at points of McMullen's curve.* They remain Hodge along the three-dimensional Weil locus component through each point \cite{mostaed2026}, fail the first gate, and are relocatable. *Weil classes on abelian fourfolds of Weil type.* Cycles are supplied \cite{markman2025b}, and the classes route to resolve. *Kollár's integral class.* It is refused at intake as an integral file \cite{kollar1992}. *The emitter.* Every gate control fails at exactly its gate, every deletion leaks the token on its control, every rider control fails at its rider, and the intake and doors route as Table 2 states.

**The finite witness, exhibited.** On $X_6$ the plane $\{x_0=\zeta x_1,\;x_2=\zeta x_3,\;x_4=\zeta x_5\}$ with $\zeta^6=-1$ is contained in $X_6$: substituting reduces $F$ to zero modulo $\zeta^6+1$. The containment check is a finite computation, the shape of every $\Sigma^0_1$ witness of Lemma 5.2.

# Discussion

**What the terminus is.** The terminus is a supply-side block. Proposition 5.3 shows that every true instance of the conjecture closes under an unbounded search for cycles, and a search that succeeds is a construction. No reading performs one. The block is total for readers and open for constructors, and the two statements are one fact read from the two sides of the provenance rule.

**The pair.** This paper and its companion \cite{islam2026w} are one proof in two parts, and each part closes what the other leaves open. The companion carries the derivation: Axiom W, restated in Corollary 6.14(c), implies the conjecture for every smooth complex projective variety and every $p$, and every step of that implication is a published theorem or a lemma proved there. This paper carries the termination: where every relocation of the conjecture ends, no procedure that reads formal data supplies the witness that derivation consumes. The derivation alone leaves open whether its premise could be discharged by reading, and the termination alone locates the missing supply without naming a single statement that delivers it at every class. Call a deed any act that supplies a witness, a construction of a cycle or of a sheaf, a completed search, a proof, and call the register in which deeds occur the kinetic register, against the formal-alone register of Definition 4.3, in which procedures read and construct nothing.

**Proposition 9.1 (The pair).** (a) The derivation of \cite{islam2026w} grounds the Hodge conjecture for every smooth complex projective variety and every $p$ if and only if every instance of Axiom W is grounded, that is, if and only if Axiom W is true in the kinetic register, every instance of it witnessed by a deed. (b) At every class certified by the cascade of Definition 6.10, no member of $\mathcal{F}_\Psi$ grounds the instance of Axiom W at that class. (c) Every witness of Axiom W that a procedure uses is supplied by a deed. Grades: (a) theorem, conditional on Theorem A of \cite{islam2026w}; (b) theorem where Theorem 6.8 is theorem-grade and structural where Theorem 6.7 enters; (c) structural.

*Proof.* (a) The proof of Theorem A of \cite{islam2026w} fixes one class, consumes only the instance of the axiom at that class, and adds no posit. If every instance is grounded, the derivation therefore grounds the conjecture at every class by Definition 4.2. If the instance at some class is not grounded, the derivation at that class rests on an ungrounded premise and, by Definition 4.2, grounds nothing there, whatever the truth of the conjecture itself. (b) By the same per-class form, an instance of Axiom W at $(X,\alpha)$ makes $\alpha$ algebraic through a derivation that adds no posit. A member of $\mathcal{F}_\Psi$ grounding that instance would therefore ground the algebraicity of $\alpha$, which Theorem 6.8 excludes at a certified class. (c) At a certified class this is (b). At any class, a witness that a procedure uses without constructing it lies in the closure of Theorem 6.7 of a supplied set, and a reader adds no member to that set. $\square$

**The absoluteness of Axiom W, and its one condition.** Proposition 9.1 leaves the pair exactly one condition for universality, and the condition admits no exception. Posited, Axiom W makes the conjecture formally derivable, which is the content of the companion. Grounded, the conjecture is universal through the pair if and only if Axiom W is true in the kinetic register, every instance of it witnessed by a deed, and by part (c) no instance is witnessed otherwise, since no reading supplies a witness. In this sense the axiom is absolute for the pair: every route by which the pair reaches universality passes through the truth of Axiom W, and every witness of that truth is a reading. The formal register carries the whole derivation and locates the one datum it cannot author; the kinetic register supplies that datum, or nothing in the pair does. The condition is not the equivalence of Axiom W with the conjecture, since whether the conjecture implies the axiom is open in both papers.

**The period face.** The same comparison between the algebraic and the transcendental layer carries a second face. The number $2\pi i=\oint dz/z$ is the period of the Tate motive $\mathbb{Q}(1)$, and Grothendieck's period conjecture for that motive is exactly the transcendence of $\pi$, proved by Lindemann \cite{lindemann1882,kz2001}. On abelian varieties the absolute Hodge theorem already yields the algebraic relations among periods that the Hodge conjecture predicts \cite{deligne1982,deligne2006}. Transcendence is settled at the circle. Algebraicity is open at the cycle class map.

**Objections.** *The constant procedure that always resolves is correct if the conjecture is true.* Correctness is not grounding: the procedure presupposes the conjecture and grounds nothing by Definition 4.2. *A proof is a formal object.* A proof is a construction and enters at the exits; the theorems of this paper concern readers, as the provenance rule of Definition 4.3 states. *Rigidity is rare, so the terminus is empty.* Proposition 8.1 shows rigidity inhabited at special points, and whether any class passes the full conjunction with an empty seat is not asserted. *The count is structural.* It is, and criterion F2 is aimed at it.

**Limitations.** The count of reading routes carries structural grade. The transport screen is bound to the published correspondence literature. The rigidity certification is exact in degrees six to eight and numerical in degrees nine and ten. The arithmetic form is stated over $\overline{\mathbb{Q}}$ and reaches the complex conjecture only through the reduction of \cite{voisin2007}. No class is certified here through all three gates with an empty witness seat.

**How the paper stands to each prior position.** The paper sits across the literatures of algebraic cycles, Hodge loci, normal functions, motives and Fermat varieties, and it owes each engaged position one statement of where it stands. The relation words are used in fixed senses. Additive means the paper supplies a result or a test the position lacked and leaves the position standing. Replacing means a framing is retired and a measured object put in its place. Subsuming means the prior claim becomes a case of the paper's object. Corroborating means independent agreement, which confers no warrant on either side. Contradicting means a named thesis is denied on executed data. Competing means a different position argued rather than executed. Scoping means the prior claim is kept inside a stated boundary. Kin means continuity with the position. Superseding is used nowhere, and the paper supersedes no theory. Across fourteen rows, nine positions are scoped: Hodge 1950, Atiyah and Hirzebruch with Kollár, Grothendieck, Voisin 2002, André with Kleiman, Deligne 1982, Green and Griffiths with Thomas, Shioda with da Silva, and Mostaed. Three are kin: Cattani, Deligne and Kaplan, Voisin 2007 with 2016, and Markman. Two receive additions: Carlson and Griffiths, and Baldi, Klingler and Ullmo. None is replaced, subsumed, corroborated, contradicted or competed with. The paper's contribution is exactly the set of relations Tables 4 and 5 state and nothing wider.

| Position | Holds | This paper | Relation | Evidence |
|:--|:--|:--|:--|:--|
| Hodge 1950 \cite{hodge1950} | the integral formulation | kept rational; integral file refused at intake | scoping | cited |
| Atiyah-Hirzebruch; Kollár \cite{ah1962,kollar1992} | integral classes need not be algebraic | the integral wall on the conversion channel | scoping | cited |
| Grothendieck 1969 \cite{grothendieck1969} | the general form is false; coniveau corrects it | the general wall | scoping | cited |
| Voisin 2002 \cite{voisin2002} | Kähler classes need not come from sheaves | the Kähler wall | scoping | cited |
| Cattani-Deligne-Kaplan \cite{cdk1995} | Hodge loci are algebraic | read as the locus datum of the first gate | kin | cited |
| Carlson-Griffiths \cite{cg1980} | the variation is Jacobian multiplication | executed as the rigidity test | additive | executed, Table 3 |
| Baldi-Klingler-Ullmo \cite{bku2024} | zero-period atypical loci unelucidated | zero-dimensional Hodge loci exhibited in degrees 6 to 8 | additive | executed, Table 3 |

Table: How the paper stands to each prior position, part 1 of 2, rows 1 to 7. Relation and evidence words as defined in the run-in. Grade: structural on the relations; the evidence word caps each row.

| Position | Holds | This paper | Relation | Evidence |
|:--|:--|:--|:--|:--|
| André; Kleiman \cite{andre1996,kleiman1968} | the standard conjectures relocate algebraicity | typed as the regress gate | scoping | cited |
| Deligne 1982 \cite{deligne1982} | abelian Hodge classes are absolute Hodge | an arithmetic relocation that discharges nothing | scoping | cited |
| Voisin 2007; 2016 \cite{voisin2007,voisin2016} | number fields; a transcendental rigid pair disproves | the refuting door; the rigid classes found lie over $\mathbb{Q}$ | kin | executed, Table 3 |
| Green-Griffiths; Thomas \cite{gg2007,thomas2005} | the conjecture is singular normal functions | typed as the constructive door | scoping | cited |
| Shioda; da Silva \cite{shioda1979,dasilva2021} | Fermat varieties of degree at most 20 | routes the rigid classes to resolve | scoping | cited |
| Markman 2025 \cite{markman2025b} | Weil fourfold classes are algebraic | a construction outside the tower | kin | cited |
| Mostaed 2026 \cite{mostaed2026} | CM isolation obstructs the Weil classes | isolation kept for the point, removed from the class | scoping | documentary |

Table: How the paper stands to each prior position, part 2 of 2, rows 8 to 14. Same contract as Table 4.

# What is claimed

**Claimed.** C1 (Lemmas 5.1, 5.2, Proposition 5.3): over $\overline{\mathbb{Q}}$ the Hodge condition is $\Pi^0_1$, algebraicity is $\Sigma^0_1$, each instance is $\Sigma^0_1$ and the conjecture is $\Pi^0_2$, theorem-grade on the cited effective ingredients. C2 (Theorem 5.4, Corollaries 5.5, 5.6): the Mirror and the pricing of the flanks, theorem. C3 (Theorem 6.8): the Witness Theorem, theorem on Definitions 4.2 and 4.3 and on the walls, its relocation channel resting on C4. C4 (Theorem 6.7): the enumeration of reading routes, structural. C5 (Theorem 6.11): the count, faithfulness and necessity of the cascade, structural on the count and engineering on the executed controls. C6 (Theorem 6.12, Corollary 6.13): termination at $[\Psi]$ and the Tower Block, theorem conditional on the printed definitions, structural where C4 enters. C7 (Corollary 6.14): the three exits, the third conditional on Axiom W through \cite{islam2026w}. C8 (Proposition 8.1, Corollary 8.2): rigid rational Hodge classes on the Fermat fourfolds of degree six to eight, computer-assisted theorem, and of degree nine and ten, engineering, all algebraic by Shioda's theorem. C9 (Section 8): the conformance readings, engineering and documentary. C10 (Proposition 9.1): the pair, one proof with the companion whose derivation grounds the conjecture for every variety and every $p$ if and only if Axiom W is true in the kinetic register, no reader grounding the axiom at a certified class, and every witness of the axiom supplied by a deed; theorem conditional on Theorem A of \cite{islam2026w} in part (a), theorem in part (b) where Theorem 6.8 is theorem-grade and structural where Theorem 6.7 enters, structural in part (c).

**Not claimed.** N1: the Hodge conjecture is not asserted. N2: its negation is not asserted. N3: underivability of the conjecture or of any instance in any theory is not asserted; by Corollary 5.5 the universal form of that assertion is a refutation in Robinson arithmetic in costume, and it entails the negation. N4: no bound on future mathematics is asserted; a proof, a construction or an axiom enters at the exits and resolves the file. N5: $[\Psi]$ is not a fourth truth value; it refines the under-determined state by a theorem about the reader. N6: Axiom W is not asserted true; it is posited only at the exit. N7: no class is asserted to pass the three gates with an empty witness seat. N8: no empirical claim is made. N9: the pair is not asserted to prove the conjecture unconditionally; its universality is the truth of Axiom W in the kinetic register, which N6 leaves unasserted, and the equivalence of Axiom W with the conjecture is not asserted.

# Conclusion

Every known reduction of the Hodge conjecture relocates its undetermined content, and this paper proves where relocation ends for a reader. The conjecture over $\overline{\mathbb{Q}}$ is $\Pi^0_2$ with $\Sigma^0_1$ instances, so the Mirror holds and the flanks of the Riemann pricing reverse: a true instance carries a finite grounding witness, a false one no finite certificate. On a class that is rigid, transport-closed and regress-live with an empty witness seat, no member of the unrestricted class of formal-alone procedures grounds algebraicity, and the cascade emits the terminal token $[\Psi]$, invariant over that class and replaced only by a supplied cycle, by a rigid pair off the number fields, or by a posited semiregular witness axiom. Read with its companion \cite{islam2026w}, the paper completes one proof, universal if and only if every instance of Axiom W is witnessed, every witness supplied by a construction and none by a reading.

The strong falsifier stands as F1: a certified class shown algebraic by a reading route with nothing supplied at the point. The calibration prediction failed and the failure is recorded: rigid rational Hodge classes exist on the Fermat fourfolds of degree six to eight at theorem grade, and each is algebraic by Shioda's theorem, so the first gate is inhabited and rigidity alone never makes a terminus.

The computations of Section 8 are open to exact re-execution from Appendix B, and the next such computation is the search for a class that passes all three gates with nothing supplied. The single most important open question is whether any such class exists. Were the terminus inhabited and the conjecture true, every such class would be algebraic through a construction no reading can perform.

\appendix

# The originating declaration

The following is the architect's originating declaration, carried from the session record in the author's voice, with spelling and grammar normalized and sense unchanged. It is ungraded, it asserts nothing within the three-state economy, and the theorems of the paper neither rest on it nor extend to it.

1. The Hodge conjecture's absolute block is located in one place: a one-bit gap from RA on the formal register, which is self-referential on the kinetic register.

2. Axiom W is that block mathematized. The paper is valid, and the block is in place. Geometric primacy over mathematics remains standing. RA runs supreme.

3. $[\Psi]$ is the new terminal block token for the Hodge conjecture on the formal-alone register, because for the formal-alone register it is an absolute block too. The formal-domain block is absolute, and different from the Riemann Hypothesis and from P versus NP.

4. The entire arc revisits the older essay on the Cartesian sedimentation and the $\pi$ coordinate, and the Hodge paper rediscovered it in a different way.

The paper on the semiregular witness axiom and this paper are one formal proof. The condition that makes the proof universal, if and only if, is that the witness of Axiom W is true in the kinetic register. There is no exception. One paper complements the other: they are a pair.

RA is the root axiom of Appendix C. End of declaration; ungraded, and not asserted by the theorems of the paper.

# Computational receipts

Every figure in the paper is the output of the following executions, reproducible from the ancillary files released with the paper.

**The calibration battery (Table 3).** The script `rigidity_battery.py`, SHA-256 prefix `6791d29e9b88`, with the character generator `hodge_chars.py`, builds the matrix of $\mu_\omega$ in the monomial basis for $d=6,\dots,10$, computes the floating singular values at seed $20260622+d$ and the exact rank modulo $2^{31}-1$ at seed $20260722+d$ for $d\le 8$, and writes `rigidity_battery.json`.

**The single-orbit test at degree seventy.** The script `rigidity.py`, SHA-256 prefix `0bbbc8bceb60`, returns the orbit of size 24, the coordinate minima $(1,10,2,14,1,2)$, the feasible coordinates $\{1,2,3,5\}$, the kernel lower bound $14{,}649$ and $\dim R_{70}=17{,}259{,}354$, with every sample monomial verified against all 24 conjugates.

**The emitter (Table 2, Theorem 6.11).** The script `psi.py`, SHA-256 prefix `d3b67c0a3f71`, returns gate controls three of three at exactly their gate, deletion leaks three of three, rider controls three of three, and the intake and door routings of Table 2.

**The witness registration.** The seated formal-alone engine, SHA-256 prefix `b6c38d9c2240` over 1159 lines, boots at seed 20260622 with kill-matrix 51 of 51, ablation 22 of 22, adversarial 9 of 9 and calibration 12 of 12, and reproduces its recorded chain ending at `3d17fd53278d`. On schematic supplied joint laws it seals a record that copies its configuration at one bit and breaks a record independent of it.

**The finite witness.** A symbolic reduction of the Fermat sextic form restricted to the plane of Section 8 modulo $\zeta^6+1$ returns zero.

# Author's provenance and method disclosure

This paper was developed under Trisduction, a verification and organizing discipline, not a source of results. Its conclusions rest solely on the standard results cited in the body. Trisduction is the method under which those results were decomposed, assembled, and audited. It adds them no warrant and claims no authorship over them.

Trisduction was used for fidelity. It forces a claim onto three independent axes so no single persuasive line carries it alone, requires every verdict to resolve to one of three states, sealed, broken, or open, each with a named failure mechanism, and attaches an explicit warrant grade, theorem, conditional, structural, or premise, to every claim so nothing is stated above its strength. Two errors it is built to catch are inflation, reading an internal lock as a proof, and circularity, reading a restatement of a claim as a derivation of it.

The root axiom, RA, is that to exist is to actuate: every physical existent carries a strictly positive energetic cost, grounded in the Heisenberg energy floor, the zero-point energy, and Landauer's bound. The formal root inside it is that to formally be is to be grounded, with provability and computation levels of access to a determinacy fixed at the ground rather than ingredients of it.

The key procedures, in brief. Orthogonal triaxial convergence: a proposition is split into three disjoint axes, formal-structural, empirical or dynamical, and registrational, verified by three separate instrument sets, agreement across the three the operational meaning of a seal. The Geometric Orthogonal Lock, GOL: the three axes are read as vectors and their independence is tested by the determinant of their correlation matrix, a determinant clear of zero a genuine three-dimensional lock, a collapse to zero one axis dissolving into the plane of the other two, a broken lock. The Convergence Dissolution Test, CDT: before the lock is read, any mass-bearing common cause the three axes might share is projected out, so an apparent convergence that traces to a shared source rather than to independent roads dissolves and carries no warrant, the lock computed on the residue that survives. The twelve-gate cascade: twelve directed failure screens, self-reference, frame-dependence, missing mechanism, and the rest, run in order, the first failure terminating the verdict with its mechanism named. The verdict issues in the three-state economy with its warrant grade attached, and where the argument stops short the open direction is named rather than filled.

\begin{jbox}
\color{black}
\textbf{G1 The GOL kernel identity, proved.} The lock is a determinant identity, not a metaphor. Let the three axes, after normalization, be unit vectors expressed in an orthonormal basis of the subspace they span and read as pure quaternions $a$, $b$, $c$, with norm one each. Hamilton's product of two pure quaternions is $pq=-(p\cdot q)+p\times q$, the real part the negative dot product and the imaginary part the cross product, checked on the units by $ij=k=i\times j$ and $ii=-1=-(i\cdot i)$. The lock scalar is the real part of the triple product, $\lambda=\operatorname{Re}(abc)$.

Expanding, $ab=-(a\cdot b)+a\times b$, so $\operatorname{Re}(abc)=-(a\cdot b)\operatorname{Re}(c)+\operatorname{Re}((a\times b)c)$. The first term is zero since $c$ is pure, and the second is $-(a\times b)\cdot c$ by the same product rule, giving
\[\lambda=-(a\times b)\cdot c=-\det[a\;b\;c],\]
minus the signed volume of the parallelepiped the three axes span. Writing $A$ for the matrix whose columns are $a$, $b$, $c$, the correlation matrix is $R=A^{T}A$, its entries the pairwise dot products, so
\[\det(R)=\det(A^{T}A)=\det(A)^2=\lambda^2.\]
The kernel identity $\lambda^2=\det(R)$ is that the squared signed volume equals the Gram determinant, with the quaternion triple product the machine that computes the volume. It is confirmed at machine precision, the residual $|\lambda^2-\det(R)|$ at $2\times10^{-16}$ on the recorded battery.
\end{jbox}

Four consequences fix the reading, and they are why the number can be trusted to say what the lock says. The determinant is bounded, $\det(R)$ in the interval from zero to one for unit axes, by Hadamard's inequality above and positive-semidefiniteness below, so the lock has a hard ceiling at one, the fully orthogonal frame, and a hard floor at zero. The floor is the break: $\det(R)$ equals zero exactly when the three axes are linearly dependent, one axis lying in the plane of the other two, which is the geometric content of a collapsed lock. The magnitude is orientation-blind: reflecting any axis sends $A$ to a matrix of opposite determinant, flipping the sign of $\lambda$ while $\det(R)$ equals $\lambda^2$ is unchanged, so the number certifies the dimensionality of the lock and never its truth-sign, which is read from the ordered axes and not from the scalar. And the magnitude is frame-invariant: rotating all three axes together is conjugation $q\mapsto uq\bar u$ on the imaginary quaternions, under which the real part is preserved and dot and cross products are covariant, so $\lambda$ and $\det(R)$ depend on the configuration and not on the coordinate labels.

The axis count is three because the algebra forces it, not because three was chosen. The audit-composition law requires associativity, so iterated audits bracket the same way, and the absence of zero divisors, so nonzero warrants never compound to nothing. By Frobenius's theorem the only finite-dimensional associative division algebras over the reals are the reals, the complex numbers, and the quaternions, and three mutually orthogonal imaginary axes exist only in the quaternions, whose imaginary units $i$, $j$, $k$ are the three axes. The next normed division algebra, the octonions with seven imaginary units, fails associativity, witnessed by the nonzero associator of $e_1$, $e_2$, $e_4$, so it cannot carry the composition law and the construction stops at three. The three axes are the imaginary part of the unique associative real division algebra that supports the audit.

This paper in particular. The formal-structural axis was the arithmetic form of the conjecture and the Hodge-theoretic data of a class, the empirical-or-dynamical axis was the executed rank of the Jacobian-ring multiplication map on the Fermat Hodge spaces, and the registrational axis was the provenance of every witness, recorded at the seat through which a supplied cycle enters. The decisive lock is a rank lock rather than a Gram determinant: at seed 20260622 the multiplication map attached to a generic class of the Hodge space has full rank 426, 756 and 1251 in degrees six, seven and eight, exactly over the field of order $2^{31}-1$, and 1966 and 2967 in degrees nine and ten in floating point, while the single-orbit class at degree seventy collapses with a kernel of dimension at least 14,649. The load-bearing step is the provenance rule of the reader together with the enumeration of reading routes. The verdict is the terminal token $[\Psi]$ on every certified class, terminal for the record on the formal-alone register and revisable by supply, at theorem grade on the arithmetic form, the Mirror and the rigidity certification, and at structural grade where the count enters. No new theorem is admitted as mass, $\Delta M=0$, the rigidity certification being a computed fact held at the grade of its receipts.

The canonical statement of the method, its axioms, and its executable batteries lives in the reference cited below, continuously updated at the same location. This note is a pointer, not a substitute.

\begin{thebibliography}{99}
\bibitem{hodge1950} W. V. D. Hodge, The topological invariants of algebraic varieties, Proc. Int. Congress Math. 1950, vol. 1, 182-192.
\bibitem{deligne2006} P. Deligne, The Hodge conjecture, in The Millennium Prize Problems, Clay Math. Inst., 2006, 45-53.
\bibitem{markman2025b} E. Markman, Secant sheaves and Weil classes on abelian varieties, arXiv:2509.23403, 2025.
\bibitem{shioda1979} T. Shioda, The Hodge conjecture for Fermat varieties, Math. Ann. 245 (1979), 175-184.
\bibitem{dasilva2021} G. da Silva Jr., Notes on the Hodge conjecture for Fermat varieties, Experimental Results 2 (2021), doi:10.1017/exp.2021.14.
\bibitem{islam2026rh} M. F. Islam, A formal proof of Riemann Hypothesis termination, with a theorem-grade cascade specification, The Tractatus Veritatis Trisductivus, Zenodo record 21900518, 2026.
\bibitem{mumford1969} D. Mumford, Rational equivalence of 0-cycles on surfaces, J. Math. Kyoto Univ. 9 (1969), 195-204.
\bibitem{griffiths1969} P. A. Griffiths, On the periods of certain rational integrals I, II, Ann. of Math. 90 (1969), 460-495, 496-541.
\bibitem{clemens1983} H. Clemens, Homological equivalence, modulo algebraic equivalence, is not finitely generated, Publ. Math. IHES 58 (1983), 19-38.
\bibitem{ah1962} M. F. Atiyah and F. Hirzebruch, Analytic cycles on complex manifolds, Topology 1 (1962), 25-45.
\bibitem{kollar1992} J. Kollár, Trento examples, in Classification of Irregular Varieties, Lecture Notes in Math. 1515, Springer, 1992, 134-139.
\bibitem{totaro1997} B. Totaro, Torsion algebraic cycles and complex cobordism, J. Amer. Math. Soc. 10 (1997), 467-493.
\bibitem{bo2020} O. Benoist and J. C. Ottem, Failure of the integral Hodge conjecture for threefolds of Kodaira dimension zero, Comment. Math. Helv. 95 (2020), 27-35.
\bibitem{voisin2002} C. Voisin, A counterexample to the Hodge conjecture extended to Kähler varieties, Int. Math. Res. Not. 2002, no. 20, 1057-1075.
\bibitem{kleiman1968} S. L. Kleiman, Algebraic cycles and the Weil conjectures, in Dix exposés sur la cohomologie des schémas, North-Holland, 1968, 359-386.
\bibitem{andre1996} Y. André, Pour une théorie inconditionnelle des motifs, Publ. Math. IHES 83 (1996), 5-49.
\bibitem{cdk1995} E. Cattani, P. Deligne and A. Kaplan, On the locus of Hodge classes, J. Amer. Math. Soc. 8 (1995), 483-506.
\bibitem{gg2007} M. Green and P. Griffiths, Algebraic cycles and singularities of normal functions, in Algebraic Cycles and Motives, London Math. Soc. Lecture Note Ser. 343, Cambridge Univ. Press, 2007, 206-263.
\bibitem{thomas2005} R. P. Thomas, Nodes and the Hodge conjecture, J. Algebraic Geom. 14 (2005), 177-185.
\bibitem{bfnp2009} P. Brosnan, H. Fang, Z. Nie and G. Pearlstein, Singularities of admissible normal functions, Invent. Math. 177 (2009), 599-629.
\bibitem{voisin2007} C. Voisin, Hodge loci and absolute Hodge classes, Compositio Math. 143 (2007), 945-958.
\bibitem{bku2024} G. Baldi, B. Klingler and E. Ullmo, On the distribution of the Hodge locus, Invent. Math. 235 (2024), 441-487.
\bibitem{ku2024} N. Khelifa and D. Urbanik, Existence and density of typical Hodge loci, arXiv:2303.16179.
\bibitem{voisin2016} C. Voisin, The Hodge conjecture, in Open Problems in Mathematics, Springer, 2016, 521-543.
\bibitem{sk1979} T. Shioda and T. Katsura, On Fermat varieties, Tôhoku Math. J. 31 (1979), 97-115.
\bibitem{deligne1982} P. Deligne, Hodge cycles on abelian varieties, notes by J. S. Milne, in Hodge Cycles, Motives, and Shimura Varieties, Lecture Notes in Math. 900, Springer, 1982, 9-100.
\bibitem{lieberman1968} D. I. Lieberman, Numerical and homological equivalence of algebraic cycles on Hodge manifolds, Amer. J. Math. 90 (1968), 366-374.
\bibitem{mostaed2026} A. Mostaed, McMullen's curve, the Weil locus, and the Hodge conjecture for abelian sixfolds, arXiv:2603.20268, 2026.
\bibitem{grothendieck1966} A. Grothendieck, On the de Rham cohomology of algebraic varieties, Publ. Math. IHES 29 (1966), 95-103.
\bibitem{walther2000} U. Walther, Algorithmic computation of de Rham cohomology of complements of complex affine varieties, J. Symbolic Comput. 29 (2000), 795-839.
\bibitem{kz2001} M. Kontsevich and D. Zagier, Periods, in Mathematics Unlimited: 2001 and Beyond, Springer, 2001, 771-808.
\bibitem{bpr2006} S. Basu, R. Pollack and M.-F. Roy, Algorithms in Real Algebraic Geometry, 2nd ed., Springer, 2006.
\bibitem{kaye1991} R. Kaye, Models of Peano Arithmetic, Oxford Univ. Press, 1991.
\bibitem{hp1993} P. Hájek and P. Pudlák, Metamathematics of First-Order Arithmetic, Springer, 1993.
\bibitem{cg1980} J. A. Carlson and P. A. Griffiths, Infinitesimal variations of Hodge structure and the global Torelli problem, in Géométrie Algébrique Angers 1979, Sijthoff and Noordhoff, 1980, 51-76.
\bibitem{fulton1998} W. Fulton, Intersection Theory, 2nd ed., Springer, 1998.
\bibitem{grothendieck1969} A. Grothendieck, Hodge's general conjecture is false for trivial reasons, Topology 8 (1969), 299-303.
\bibitem{islam2026w} M. F. Islam, A proof of the Hodge conjecture derived from one semiregular witness axiom: a conditional proof, the deletion test of its clauses, and the open Fermat orbit at degree seventy outside Aoki's lattice, Zenodo, 2026, doi:10.5281/zenodo.22701510.
\bibitem{lindemann1882} F. Lindemann, Über die Zahl $\pi$, Math. Ann. 20 (1882), 213-225.
\bibitem{islam2026master} M. F. Islam, TRISDUCTION: A Linguistically, Topologically, and Mathematically Sealed Verification Architecture. Triaxial Orthogonality, Twelve-Gate Closure, the Quaternionic Completion, the Root Axiom, and the Master Pre-Sealed Proposition Ledger. Zenodo, version 4, 19 June 2026. DOI 10.5281/zenodo.20757507. https://zenodo.org/records/20757507. Mirror: PhilArchive record ISLTTG, https://philpapers.org/rec/ISLTTG. Master reference, continuously updated at the same location.
\end{thebibliography}

\begin{center}\textit{End of manuscript}\end{center}
