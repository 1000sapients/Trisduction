import re, os, shutil, subprocess, hashlib, unicodedata, zipfile
N = "A_Formal_Proof_of_Hodge_Conjecture_Termination_at_the_Formal-Alone_Register"; H = "/home/claude/hterm"; B = f"{H}/build"; R = f"{B}/render"; OUT = "/mnt/user-data/outputs"
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()[:12]
LIG = {"\ufb00": "ff", "\ufb01": "fi", "\ufb02": "fl", "\ufb03": "ffi", "\ufb04": "ffl"}
def norm(t):
    for x, y in LIG.items(): t = t.replace(x, y)
    return "".join(c for c in unicodedata.normalize("NFKD", t) if not unicodedata.combining(c)).lower()
am = open(f"{H}/hterm_v7.md", encoding="utf-8").read(); pdf = f"{R}/out/{N}.pdf"
raw = re.sub(r"A Formal Proof of Hodge Conjecture Termination \| \d+", " ", subprocess.run(["pdftotext", pdf, "-"], capture_output=True, text=True).stdout)
flat = re.sub(r"[\W_]+", "", norm(re.sub(r"-\s*\n\s*", "", raw)))
fe = am.index("\n---\n", 4); fm = am[4:fe]; paras = [fm[fm.index("abstract: |") + 11:]] + re.split(r"\n\s*\n", am[fe + 5:]); wins, miss = 0, []
for p in paras:
    p = p.strip()
    if not p or p.startswith(("|", "Table:", "\\begin{jbox}", "\\hypersetup", "\\appendix", "\\color")): continue
    t = re.sub(r"\$\$.*?\$\$|\$[^$]*\$|\\cite\{[^}]*\}|\\\[.*?\\\]|\\[a-zA-Z]+\*?(\[[^\]]*\])?(\{[^{}]*\})?|[{}]", " \u00a6 ", p, flags=re.S)
    for r_ in t.split("\u00a6"):
        ws = re.findall(r"[^\W_]+", norm(r_))
        if len(ws) >= 6:
            for w in {"".join(ws[:6]), "".join(ws[-6:])}:
                wins += 1
                if w not in flat: miss.append(w)
unexpl = []
for s in miss:
    hit = None
    for cut in range(4, len(s) - 3):
        a, b = s[:cut], s[cut:]
        for m in re.finditer(re.escape(a), flat):
            j = flat.find(b, m.end(), m.end() + 6000)
            if j >= 0: hit = (cut, j - m.end(), flat[m.end():m.end() + 50]); break
        if hit: break
    print(f"  split window {s!r}: {'explained at char ' + str(hit[0]) + ', gap ' + str(hit[1]) + ' chars, interrupted by: ' + hit[2] if hit else 'UNEXPLAINED'}")
    if not hit: unexpl.append(s)
print(f"coverage: {wins - len(miss)}/{wins} direct, {len(miss) - len(unexpl)} split by float, glyph or page break, unexplained {len(unexpl)}")
bl = f"{B}/out/{N}.blog.md"; x = open(bl, encoding="utf-8").read()
ready = not unexpl and "restated in academic form" in x and not re.findall(r"\\[a-zA-Z]{2,}", x) and "Co-localization" in x
if ready:
    shutil.copy(pdf, OUT); shutil.copy(f"{R}/out/{N}.tex", OUT); shutil.copy(f"{H}/hterm_v7.md", f"{OUT}/{N}.md"); shutil.copy(bl, OUT)
    note = (f"# AMENDMENT after the hterm1 seal\nAt the author's instruction the ungraded originating declaration (Appendix A) was restated in academic form, and one reference was added (Zenodo 20805972, cited there).\n"
            f"Confinement verified mechanically: every changed line lies inside Appendix A or that reference. Sealed v6 sha {sha(H + '/hterm_v6.md')}; amended v7 sha {sha(H + '/hterm_v7.md')}.\n"
            "The hterm1 seal covers every graded claim, all unchanged in v7; Appendix A remains ungraded and is not asserted by the theorems.\n")
    open(f"{H}/AMENDMENT_hterm1_appendixA.md", "w", encoding="utf-8").write(note)
    zp = f"{OUT}/A_Formal_Proof_of_Hodge_Conjecture_Termination_audit_ledger_hterm1.zip"
    with zipfile.ZipFile(zp, "a", zipfile.ZIP_DEFLATED) as z:
        have = set(z.namelist())
        for f in ("AMENDMENT_hterm1_appendixA.md", "hterm_v7.md", "amend_declaration.py", "stage_v7.py"):
            if f"audit_hterm1_bundle/{f}" not in have: z.write(f"{H}/{f}", f"audit_hterm1_bundle/{f}")
    print("STAGED v7 edition:", {e: sha(f"{OUT}/{N}.{e}") for e in ("pdf", "tex", "md", "blog.md")}, "| ledger bundle files", len(zipfile.ZipFile(zp).namelist()))
else: print("NOT STAGED; outputs keep the verified v6 edition")
