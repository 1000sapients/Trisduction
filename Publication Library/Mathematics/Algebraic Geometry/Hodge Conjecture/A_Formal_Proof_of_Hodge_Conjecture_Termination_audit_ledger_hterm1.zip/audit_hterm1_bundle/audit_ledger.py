#!/usr/bin/env python3
"""audit_ledger.py v2 - append-only findings ledger, coverage tracker, and
termination evaluator for the Trisduction Audit Cycle.

Every finding exits into exactly one of five dispositions. Nothing is
discarded, nothing is silently downgraded, rounds close in sequence, closed
rounds are immutable, and the termination verdict is computed from the
ledger, never declared in prose.

All commands run from the cycle's working directory; files live under
./audit_<cycle>/: cycle.json, findings.jsonl, rounds.jsonl.

Usage:
  audit_ledger.py init      --cycle N --artifact PATH --claims "C1,C2"
  audit_ledger.py falsifier --cycle N --claim C1 --text "the check that kills it"
  audit_ledger.py add       --cycle N --round R --fid F-1 --register kinematic \\
                            --claim C1|NONE --severity LOAD-BEARING \\
                            --mechanism "..." --disposition EARNED \\
                            [--repaired] [--numeric] [--recomputed] \\
                            [--repeat-of F-0] [--tier-before T --tier-after T] \\
                            [--note "..."]
  audit_ledger.py demote    --cycle N --round R --claim C1 [--note "..."]
  audit_ledger.py leakscan  --file prosecution.md
  audit_ledger.py close     --cycle N --round R --registers "kinematic,definitional" \\
                            --controls-caught 3 [--controls-total 3] \\
                            [--grade EXTERNAL|SELF] [--leak] [--external-mass]
  audit_ledger.py status    --cycle N
"""
import argparse, json, os, re, sys

DISPOSITIONS = ["EARNED", "SCOPED", "REFUSED-STRUCTURAL",
                "REFUSED-MASSLESS", "APERTURE"]
TIERS = ["theorem", "theorem-conditional", "structural", "engineering",
         "corroboration", "premise", "operational"]
REG_CANON = ["kinematic", "definitional", "parameter", "provenance",
             "limit", "symmetry"]
MASS_BEARING = {"EARNED", "SCOPED"}
SEVERITIES = ["FATAL", "LOAD-BEARING", "STRUCTURAL", "COSMETIC"]
DEBT_SEV = {"FATAL", "LOAD-BEARING"}
NO_CLAIM = "NONE"
CLEAN_AFTER_DEBT = 2
FLOOR_ROUNDS = 3

LEAK_WORD = ["Trisduction", "MathDuction", "GOLf", "GOLn", "W_social",
             "barzakh"]
LEAK_SUB = ["RA-RAM", "APEX-PSP", "MD-PSP", "CN-PSP", "sPSP-", "Mosaic Seal",
            "Titanium Ruler", "Empty Throne", "chiral residence",
            "Impressed Plenum", "Seal L", "Seal G", "Seal M", "Fix(\u03c3)",
            "\u039e\u2080", "\u00d8\u2080", "\u27c0"]


def cdir(cycle):
    d = os.path.join(".", f"audit_{cycle}")
    os.makedirs(d, exist_ok=True)
    return d


def paths(cycle):
    d = cdir(cycle)
    return (os.path.join(d, "cycle.json"),
            os.path.join(d, "findings.jsonl"),
            os.path.join(d, "rounds.jsonl"))


def load_jsonl(p):
    if not os.path.exists(p):
        return []
    out = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def append_jsonl(p, rec):
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, sort_keys=True) + "\n")


def save_cycle(cj, cyc):
    with open(cj, "w", encoding="utf-8") as f:
        json.dump(cyc, f, indent=2)


def tier_rank(t):
    return TIERS.index(t)


def closed_set(rounds):
    return {r["round"] for r in rounds}


def cmd_init(a):
    cj, fj, rj = paths(a.cycle)
    if os.path.exists(cj):
        print(f"FAULT: cycle {a.cycle} already initialised. A cycle opens "
              f"once; a new artifact opens a new cycle."); return 2
    claims = [c.strip() for c in a.claims.split(",") if c.strip()]
    if not claims:
        print("FAULT: pre-registration requires at least one load-bearing "
              "claim. An unregistered cycle cannot score."); return 2
    save_cycle(cj, {"cycle": a.cycle, "artifact": a.artifact,
                    "prereg_claims": claims, "falsifiers": {}})
    open(fj, "a").close(); open(rj, "a").close()
    print(f"CYCLE {a.cycle} opened. artifact={a.artifact} "
          f"pre-registered load-bearing claims={len(claims)}: "
          f"{', '.join(claims)}")
    print("Register one falsifier per claim with the falsifier command; "
          "round 1 will not close without them.")
    return 0


def cmd_falsifier(a):
    cj, _, rj = paths(a.cycle)
    if not os.path.exists(cj):
        print("FAULT: cycle not initialised."); return 2
    cyc = json.load(open(cj, encoding="utf-8"))
    if load_jsonl(rj):
        print("FAULT: falsifiers lock once any round has closed. The "
              "pre-registration is fixed for the life of the cycle."); return 2
    if a.claim not in cyc["prereg_claims"]:
        print(f"FAULT: {a.claim} is not a pre-registered claim."); return 2
    if not a.text.strip():
        print("FAULT: an empty falsifier registers nothing."); return 2
    if a.claim in cyc["falsifiers"]:
        print(f"FAULT: {a.claim} already carries a falsifier; falsifiers "
              f"are write-once."); return 2
    cyc["falsifiers"][a.claim] = a.text.strip()
    save_cycle(cj, cyc)
    done = len(cyc["falsifiers"]); need = len(cyc["prereg_claims"])
    print(f"FALSIFIER registered for {a.claim} ({done}/{need}).")
    return 0


def cmd_add(a):
    cj, fj, rj = paths(a.cycle)
    if not os.path.exists(cj):
        print("FAULT: cycle not initialised."); return 2
    cyc = json.load(open(cj, encoding="utf-8"))
    rounds = load_jsonl(rj)
    if a.round in closed_set(rounds):
        print(f"FAULT: round {a.round} is closed. Closed rounds are "
              f"immutable; raise the finding in the open round."); return 2
    if a.disposition not in DISPOSITIONS:
        print(f"FAULT: disposition must be one of {DISPOSITIONS}"); return 2
    if a.severity not in SEVERITIES:
        print(f"FAULT: severity must be one of {SEVERITIES}. Section 5.5 "
              f"requires one per finding; an unsevered finding cannot be "
              f"weighed and the FATAL repair-attempt rule cannot bind."); return 2
    if a.claim != NO_CLAIM and a.claim not in cyc["prereg_claims"]:
        print(f"FAULT: --claim {a.claim} is not a pre-registered claim of "
              f"this cycle. Use NONE for a finding that threatens none of "
              f"them, or correct the id; an unmatched string reads as "
              f"non-prereg and the hit vanishes from the statistics."); return 2
    if a.claim == NO_CLAIM and a.severity in DEBT_SEV:
        print(f"FAULT: severity {a.severity} may not take --claim NONE. A "
              f"finding threatening no pre-registered claim is not "
              f"load-bearing by definition; name the claim it threatens or "
              f"lower the severity, and record which."); return 2
    for t in (a.tier_before, a.tier_after):
        if t and t not in TIERS:
            print(f"FAULT: unknown tier '{t}'. Tiers: {TIERS}"); return 2
    existing = {r["fid"] for r in load_jsonl(fj)}
    if a.fid in existing:
        print(f"FAULT: finding id {a.fid} already on the ledger. The ledger "
              f"is append-only and ids are unique."); return 2
    if a.repeat_of and a.repeat_of not in existing:
        print(f"FAULT: --repeat-of {a.repeat_of} names no ledger row.")
        return 2
    admissible = True
    flags = []
    if not a.mechanism.strip():
        admissible = False
        flags.append("INADMISSIBLE-NO-MECHANISM")
    if a.numeric and not a.recomputed:
        admissible = False
        flags.append("INADMISSIBLE-NO-RECOMPUTE")
    if a.disposition == "EARNED" and not a.repaired:
        admissible = False
        flags.append("INADMISSIBLE-EARNED-WITHOUT-REPAIR")
    if a.disposition == "SCOPED" and not (
            (a.tier_before and a.tier_after) or a.note.strip()):
        admissible = False
        flags.append("INADMISSIBLE-SCOPED-WITHOUT-DELTA")
    if a.tier_before and a.tier_after and \
            tier_rank(a.tier_after) < tier_rank(a.tier_before):
        flags.append("TIER-RAISED")
    rec = {"round": a.round, "fid": a.fid, "register": a.register,
           "claim": a.claim, "severity": a.severity,
           "prereg": a.claim in cyc["prereg_claims"],
           "mechanism": a.mechanism, "disposition": a.disposition,
           "repaired": bool(a.repaired), "numeric": bool(a.numeric),
           "recomputed": bool(a.recomputed),
           "repeat_of": a.repeat_of or None,
           "tier_before": a.tier_before or None,
           "tier_after": a.tier_after or None,
           "admissible": admissible, "flags": flags, "note": a.note or ""}
    append_jsonl(fj, rec)
    tag = "ADMITTED" if admissible else "INADMISSIBLE"
    print(f"{tag} {a.fid} r{a.round} [{a.disposition}] [{a.severity}] "
          f"claim={a.claim}"
          f"{' PREREG' if rec['prereg'] else ''}"
          f"{' flags=' + ','.join(flags) if flags else ''}")
    return 0


def cmd_demote(a):
    cj, fj, rj = paths(a.cycle)
    if not os.path.exists(cj):
        print("FAULT: cycle not initialised."); return 2
    cyc = json.load(open(cj, encoding="utf-8"))
    if a.claim not in cyc["prereg_claims"]:
        print(f"FAULT: {a.claim} is not pre-registered; only pre-registered "
              f"demotions auto-score."); return 2
    if a.round in closed_set(load_jsonl(rj)):
        print(f"FAULT: round {a.round} is closed."); return 2
    fid = f"AUTO-DEMOTE-{a.claim}-r{a.round}"
    if fid in {r["fid"] for r in load_jsonl(fj)}:
        print(f"FAULT: {fid} already logged."); return 2
    rec = {"round": a.round, "fid": fid, "register": "arbiter",
           "claim": a.claim, "severity": "LOAD-BEARING", "prereg": True,
           "mechanism": "pre-registered load-bearing claim demoted to "
                        "decoration mid-cycle; the demotion is itself the "
                        "finding", "disposition": "EARNED", "repaired": True,
           "numeric": False, "recomputed": False, "repeat_of": None,
           "tier_before": None, "tier_after": None, "admissible": True,
           "flags": ["AUTO-DEMOTION"], "note": a.note or ""}
    append_jsonl(fj, rec)
    print(f"ADMITTED {fid} r{a.round} [EARNED] AUTO-DEMOTION on {a.claim}. "
          f"This blocks termination for the round.")
    return 0


def cmd_leakscan(a):
    try:
        text = open(a.file, encoding="utf-8").read()
    except Exception as e:
        print(f"FAULT: cannot read {a.file}: {e}"); return 2
    hits = []
    for i, line in enumerate(text.split("\n"), 1):
        for t in LEAK_WORD:
            if re.search(rf"\b{re.escape(t)}\b", line):
                hits.append((i, t))
        for t in LEAK_SUB:
            if t in line:
                hits.append((i, t))
    if hits:
        for i, t in hits:
            print(f"LEAK line {i}: {t}")
        print(f"LEAK: {len(hits)} framework token(s) in the blind pass. "
              f"Close the round with --leak and re-run the prosecution.")
        return 1
    print("CLEAN: no framework tokens detected. The scanner is the floor; "
          "ambiguous words (RA, RAM, Ground, aperture, seal) are the "
          "Arbiter's judgment, the ceiling.")
    return 0


def round_stats(findings, rnd):
    rows = [f for f in findings if f["round"] == rnd and f["admissible"]]
    s = {d: 0 for d in DISPOSITIONS}
    for f in rows:
        s[f["disposition"]] += 1
    s["total"] = len(rows)
    s["inadmissible"] = len([f for f in findings
                             if f["round"] == rnd and not f["admissible"]])
    s["mass_bearing"] = s["EARNED"] + s["SCOPED"]
    s["prereg_hits"] = len([f for f in rows if f["prereg"]
                            and f["disposition"] in MASS_BEARING])
    s["fatal"] = len([f for f in rows if f.get("severity") == "FATAL"
                      and f["disposition"] in MASS_BEARING])
    s["debt"] = 1 if (s["prereg_hits"] or s["fatal"]) else 0
    s["repeats"] = len([f for f in rows if f["repeat_of"]])
    s["tier_raised"] = len([f for f in rows if "TIER-RAISED" in f["flags"]])
    return s


def cmd_close(a):
    cj, fj, rj = paths(a.cycle)
    if not os.path.exists(cj):
        print("FAULT: cycle not initialised."); return 2
    cyc = json.load(open(cj, encoding="utf-8"))
    findings = load_jsonl(fj)
    rounds = load_jsonl(rj)
    closed = sorted(closed_set(rounds))
    expected = (closed[-1] + 1) if closed else 1
    if a.round != expected:
        print(f"FAULT: rounds close in sequence; expected round {expected}, "
              f"got {a.round}."); return 2
    missing_f = [c for c in cyc["prereg_claims"]
                 if c not in cyc.get("falsifiers", {})]
    if missing_f:
        print(f"FAULT: pre-registered claims without a stated falsifier: "
              f"{', '.join(missing_f)}. Register them, then close. The "
              f"round stays open."); return 2
    regs = [r.strip() for r in a.registers.split(",") if r.strip()]
    bad = [r for r in regs if r not in REG_CANON]
    if not regs or bad:
        print(f"FAULT: --registers must name registers from {REG_CANON}; "
              f"got {regs}."); return 2
    s = round_stats(findings, a.round)
    verdict, why = evaluate(a, s, rounds, regs)
    rec = {"round": a.round, "registers": regs, "stats": s,
           "controls_caught": a.controls_caught,
           "controls_total": a.controls_total, "control_grade": a.grade,
           "leak": bool(a.leak), "external_mass": bool(a.external_mass),
           "verdict": verdict, "why": why}
    append_jsonl(rj, rec)
    print(f"ROUND {a.round} CLOSED  registers={'+'.join(regs)}")
    print(f"  findings admitted {s['total']}  inadmissible "
          f"{s['inadmissible']}")
    print(f"  EARNED {s['EARNED']}  SCOPED {s['SCOPED']}  "
          f"REFUSED-STRUCTURAL {s['REFUSED-STRUCTURAL']}  "
          f"REFUSED-MASSLESS {s['REFUSED-MASSLESS']}  "
          f"APERTURE {s['APERTURE']}")
    print(f"  FATAL {s.get('fatal', 0)}  debt "
          f"{'yes' if s.get('debt') else 'no'}")
    print(f"  mass-bearing {s['mass_bearing']}  prereg hits "
          f"{s['prereg_hits']}  repeats {s['repeats']}  tier raised "
          f"{s['tier_raised']}")
    print(f"  controls {a.controls_caught}/{a.controls_total} grade "
          f"{a.grade}  vocabulary leak {'YES' if a.leak else 'no'}")
    print(f"  VERDICT {verdict}: {why}")
    return 0


def evaluate(a, s, rounds, regs):
    if a.leak:
        return "VOID-LEAK", ("framework vocabulary appeared in the "
                             "framework-blind pass; re-run the round")
    if a.controls_total <= 0:
        return "VOID-UNCALIBRATED", ("no committed control set; a clean bill "
                                     "from an uncalibrated auditor is not "
                                     "evidence")
    if s["tier_raised"] and not a.external_mass:
        return "INFLATION-FAULT", ("a warrant tier rose with no admitted "
                                   "external mass; Non-Inflation Invariant "
                                   "breached, repair before continuing")
    if a.controls_caught < a.controls_total:
        return "VOID-UNDERPOWERED", (f"controls {a.controls_caught}/"
                                     f"{a.controls_total}; findings "
                                     f"retained, no seal may issue from "
                                     f"this round")
    prior = [r for r in rounds if not r["verdict"].startswith("VOID")]
    earned_hist = [r["stats"]["EARNED"] for r in prior] + [s["EARNED"]]
    if len(earned_hist) >= 3 and \
            earned_hist[-1] > earned_hist[-2] > earned_hist[-3]:
        return "HALT-DIVERGENT", ("earned corrections rose across two "
                                  "consecutive valid rounds; the artifact "
                                  "is not hardening, reconstruction is due")
    if s["mass_bearing"] and s["repeats"] == s["total"]:
        return "HALT-STALE", ("every mass-bearing finding repeats a "
                              "mechanism already dispositioned; the dispute "
                              "is looping, adjudicate it or send it to the "
                              "aperture list and close. Checked ahead of the "
                              "debt branch, so a loop on a pre-registered "
                              "claim halts here instead of recurring")
    if s["prereg_hits"] or s["fatal"]:
        return "CONTINUE-PREREG-BLOCK", (
            f"{s['prereg_hits']} mass-bearing finding(s) on a pre-registered "
            f"claim and {s['fatal']} mass-bearing FATAL; the round incurs "
            f"debt, and {CLEAN_AFTER_DEBT} consecutive clean valid rounds "
            f"are required before any seal issues")
    if s["mass_bearing"] == 0:
        valid_count = len(prior) + 1
        streak = 1
        for r in reversed(prior):
            if r["stats"]["mass_bearing"] == 0:
                streak += 1
            else:
                break
        if any(r["stats"].get("debt") for r in prior) and \
                streak < CLEAN_AFTER_DEBT:
            return "CONTINUE-DEBT", (f"a prior valid round incurred debt on "
                                     f"a pre-registered claim or a FATAL "
                                     f"finding; clean streak {streak}/"
                                     f"{CLEAN_AFTER_DEBT}, one further clean "
                                     f"round is required before a seal")
        if valid_count < FLOOR_ROUNDS:
            return "CONTINUE-FLOOR", (f"valid rounds {valid_count}/"
                                      f"{FLOOR_ROUNDS}; voided rounds do "
                                      f"not count toward the floor")
        covered = set(regs)
        for r in prior:
            covered.update(r.get("registers", []))
        missing = [r for r in REG_CANON if r not in covered]
        if missing:
            return "CONTINUE-COVERAGE", (f"registers not yet prosecuted: "
                                         f"{', '.join(missing)}; a seal "
                                         f"with unswept registers is not "
                                         f"a seal")
        grades = {r["control_grade"] for r in prior} | {a.grade}
        floor = "EXTERNAL" if grades == {"EXTERNAL"} else "SELF"
        why = ("zero mass-bearing findings, full control detection, round "
               "floor and six-register coverage met; control-grade floor "
               + floor)
        if floor == "SELF":
            why += ", single-substrate aperture open and stamped on the seal"
        return "SEALED-ROUND", why
    return "CONTINUE", "mass-bearing findings remain; run the next round"


def cmd_status(a):
    cj, fj, rj = paths(a.cycle)
    if not os.path.exists(cj):
        print("FAULT: cycle not initialised."); return 2
    cyc = json.load(open(cj, encoding="utf-8"))
    findings, rounds = load_jsonl(fj), load_jsonl(rj)
    print(f"CYCLE {cyc['cycle']}  artifact {cyc['artifact']}")
    for c in cyc["prereg_claims"]:
        f = cyc.get("falsifiers", {}).get(c)
        print(f"  {c}: falsifier "
              f"{'registered: ' + f[:60] if f else 'MISSING'}")
    print(f"findings on the ledger: {len(findings)}  rounds closed: "
          f"{len(rounds)}")
    covered = set()
    for r in rounds:
        st = r["stats"]
        if not r["verdict"].startswith("VOID"):
            covered.update(r.get("registers", []))
        print(f"  r{r['round']} [{'+'.join(r.get('registers', []))}]: "
              f"E{st['EARNED']} S{st['SCOPED']} "
              f"RS{st['REFUSED-STRUCTURAL']} RM{st['REFUSED-MASSLESS']} "
              f"A{st['APERTURE']} | controls {r['controls_caught']}/"
              f"{r['controls_total']} {r['control_grade']} | {r['verdict']}")
    missing = [r for r in REG_CANON if r not in covered]
    print(f"register coverage: {len(REG_CANON) - len(missing)}/"
          f"{len(REG_CANON)}"
          + (f"  missing: {', '.join(missing)}" if missing else "  complete"))
    ap = [f for f in findings if f["disposition"] == "APERTURE"
          and f["admissible"]]
    if ap:
        print(f"open apertures ({len(ap)}), each awaiting a supplied "
              f"external witness:")
        for f in ap:
            print(f"  {f['fid']} r{f['round']} claim={f['claim']}: "
                  f"{f['mechanism'][:70]}")
    if rounds and rounds[-1]["verdict"] == "SEALED-ROUND":
        print("CYCLE CLOSED at SEALED-ROUND. Emit the closing card.")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)

    i = sub.add_parser("init"); i.add_argument("--cycle", required=True)
    i.add_argument("--artifact", required=True)
    i.add_argument("--claims", required=True)

    fz = sub.add_parser("falsifier"); fz.add_argument("--cycle", required=True)
    fz.add_argument("--claim", required=True)
    fz.add_argument("--text", required=True)

    d = sub.add_parser("add")
    for f in ("cycle", "fid", "register", "claim", "mechanism",
              "disposition", "severity"):
        d.add_argument("--" + f, required=True)
    d.add_argument("--round", type=int, required=True)
    d.add_argument("--repaired", action="store_true")
    d.add_argument("--numeric", action="store_true")
    d.add_argument("--recomputed", action="store_true")
    d.add_argument("--repeat-of", dest="repeat_of", default="")
    d.add_argument("--tier-before", dest="tier_before", default="")
    d.add_argument("--tier-after", dest="tier_after", default="")
    d.add_argument("--note", default="")

    dm = sub.add_parser("demote"); dm.add_argument("--cycle", required=True)
    dm.add_argument("--round", type=int, required=True)
    dm.add_argument("--claim", required=True)
    dm.add_argument("--note", default="")

    lk = sub.add_parser("leakscan"); lk.add_argument("--file", required=True)

    c = sub.add_parser("close"); c.add_argument("--cycle", required=True)
    c.add_argument("--round", type=int, required=True)
    c.add_argument("--registers", required=True)
    c.add_argument("--controls-caught", dest="controls_caught", type=int,
                   required=True)
    c.add_argument("--controls-total", dest="controls_total", type=int,
                   default=3)
    c.add_argument("--grade", choices=["EXTERNAL", "SELF"], default="SELF")
    c.add_argument("--leak", action="store_true")
    c.add_argument("--external-mass", dest="external_mass",
                   action="store_true")

    st = sub.add_parser("status"); st.add_argument("--cycle", required=True)

    a = p.parse_args(argv)
    return {"init": cmd_init, "falsifier": cmd_falsifier, "add": cmd_add,
            "demote": cmd_demote, "leakscan": cmd_leakscan,
            "close": cmd_close, "status": cmd_status}[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
