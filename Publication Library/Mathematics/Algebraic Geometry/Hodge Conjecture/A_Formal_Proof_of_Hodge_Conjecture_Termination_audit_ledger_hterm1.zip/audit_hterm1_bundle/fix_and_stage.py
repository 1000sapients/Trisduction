import os, re, glob, shutil, subprocess, zipfile, hashlib
run = lambda c: subprocess.run(c, shell=True, capture_output=True, text=True, errors="replace")
B = "/home/claude/hterm/build"; N2 = "A_Formal_Proof_of_Hodge_Conjecture_Termination_at_the_Formal-Alone_Register"; OUT = "/mnt/user-data/outputs"
tpl = open(f"{B}/mathjournal.tex", encoding="utf-8").read()
if "\\oldarraybackslash" not in tpl:
    tpl = tpl.replace("\\usepackage{calc}", "\\usepackage{calc}\n% table cells: zero glue at cell start so the first word may hyphenate (quiets overfull first words)\n\\AtBeginDocument{\\let\\oldarraybackslash\\arraybackslash\\renewcommand{\\arraybackslash}{\\oldarraybackslash\\hspace{0pt}}}", 1)
    open(f"{B}/mathjournal.tex", "w", encoding="utf-8").write(tpl)
r = run(f"python3 /home/claude/paper1u/build_mathjournal_local.py {B}/{N2}.md {B}/out/{N2}.pdf"); print("REBUILD:", (r.stdout.strip().splitlines() or [r.stderr[-300:]])[-1])
log = open(sorted(glob.glob("/tmp/mathjournal_*/paper.log"), key=os.path.getmtime)[-1], errors="replace").read()
print("errors", len(re.findall(r"^! ", log, re.M)), "| overfull hbox", len(re.findall(r"Overfull \\hbox", log)), [m for m in re.findall(r"Overfull \\hbox \((\d+\.?\d*)pt too wide\)", log)][:6])
print("'undefined' lines:", [l.strip()[:110] for l in log.splitlines() if "undefined" in l][:3])
t = run(f"pdftotext '{B}/out/{N2}.pdf' -").stdout; flat = re.sub(r"\s+", "", re.sub(r"-\s*\n\s*", "", t)).lower()
print("pages", re.search(r"Pages:\s+(\d+)", run(f"pdfinfo '{B}/out/{N2}.pdf'").stdout).group(1), "| F-10 fragments:", {k: k in flat for k in ("smoothprojectivefamilies", "canjump", "placeitswitnessoff", "per-classproofoftheorema")}, "| end of manuscript:", "endofmanuscript" in flat)
bp = f"{B}/out/{N2}.blog.md"; b = open(bp, encoding="utf-8").read()
MORE = [("\\mathrmHC", "HC"), ("\\mathrmdR", "dR"), ("\\mathrmpt", "pt"), ("\\mathrmprim", "prim"), ("\\longmapsto", "⟼"), ("\\equiv", "≡"), ("\\pmod", "mod"), ("\\bmod", "mod"), ("\\Bigl", ""), ("\\Bigr", ""), ("\\bigl", ""), ("\\bigr", ""), ("\\Big", ""), ("\\big", ""),
        ("\\lambda", "λ"), ("\\det", "det"), ("\\cdots", "…"), ("\\cdot", "·"), ("\\times", "×"), ("\\sum", "∑"), ("\\neq", "≠"), ("\\leq", "≤"), ("\\geq", "≥"), ("\\le", "≤"), ("\\color{black}", ""), ("\\overline", ""), ("\\operatorname", ""), ("\\mathrm", ""), ("\\mathbb", ""), ("\\left", ""), ("\\right", ""), ("\\,", " "), ("\\;", " ")]
for a, c in MORE: b = b.replace(a, c)
b = re.sub(r"\\begin\{(jbox|center)\}|\\end\{(jbox|center)\}", "", b); b = re.sub(r"\\textit\{([^{}]*)\}", r"*\1*", b); b = re.sub(r"\\textbf\{([^{}]*)\}", r"**\1**", b); b = re.sub(r"\\emph\{([^{}]*)\}", r"*\1*", b)
left = re.findall(r"\\[a-zA-Z]{2,}", b); print("blog residual LaTeX after fix:", len(left), sorted(set(left))[:10], [b[max(0, m.start()-50):m.start()+40].replace("\n", " ") for m in list(re.finditer(r"\\[a-zA-Z]{2,}", b))[:3]])
open(bp, "w", encoding="utf-8").write(b)
print("blog: header", "audit cycle hterm1 closed at SEALED-ROUND" in b, "| em-dash", b.count("—"), "| pipes-table rows", b.count("\n|"), "| End of manuscript", "End of manuscript" in b)
# ---- stage deliverables ----
P = "/home/claude/paper1u"; N1 = "A_Proof_of_the_Hodge_Conjecture_Derived_from_One_Semiregular_Witness_Axiom"
for src in (f"{B}/out/{N2}.pdf", f"{B}/out/{N2}.tex", f"{B}/{N2}.md", bp, f"{P}/out/{N1}.pdf", f"{P}/out/{N1}.tex", f"{P}/{N1}.md", f"{P}/out/{N1}.blog.md"): shutil.copy(src, OUT)
shutil.copy(f"{P}/out/{N1}.zenodo.json", f"{OUT}/zenodo-publication/{N1}.zenodo.json")
card = """# AUDIT CYCLE hterm1 · Pre-Forge Digest and Closing Card
Artifact: A Formal Proof of Hodge Conjecture Termination at the Formal-Alone Register. Entry hterm_v1.md, final hterm_v6.md. FORGE pre-authorized in the triggering message.
Verdict: SEALED-ROUND at round 5. Controls 15/15 SELF; grade floor SELF; single-substrate aperture stamped. Coverage 6/6.
Rounds: r1 kinematic+definitional E4 | r2 parameter+provenance E2 S2 A1 | r3 limit+symmetry E1 | r4 parameter+provenance clean | r5 parameter+provenance clean.
Digest (reconciled: 80 change chunks, every chunk traced, every entry landed, no orphans):
1 R1 F-1 C2 Cor 5.5/Intro/N3/abstract: underivability of an instance is refutation in Q, which entails failure; equivalence withdrawn. MIXED.
2 R1 F-2 C6 Def 6.4 (+Def 4.1, Thm 6.8 proof): transport closure by reachability; the non-rigid-source definition was vacuous (X x E). STRENGTHENS.
3 R1 F-3 C7 Def 4.1: presentations over C with a recorded field of definition; exit (b) reachable. STRENGTHENS.
4 R1 F-4 C10 Prop 9.1(a) and consumers: grounds the conjecture everywhere iff every instance of Axiom W is grounded, its truth in the kinetic register. MIXED.
5 R2 F-5 C3 Thm 6.8 structural as a whole (theorem on witness and conversion channels); 9.1(b) structural. MIXED.
6 R2 F-6 C10 9.1(a) kinetic reading carried through (c) at structural. MIXED.
7 R2 F-7 C10 APERTURE: companion Theorem A unrefereed; disclosed in Limitations (A-3). STRENGTHENS the record.
8 R2 F-8 C1 Lemma 5.1 re-carried by E1 degeneration and Cech cohomology; out-of-scope citation removed. STRENGTHENS.
9 R2 F-9 NONE: 'called in advance' withdrawn for want of a dated receipt. MIXED.
10 R3 F-10 C7 Cor 6.14(c): fibres over T can jump; W may place its witness off X; instance implication via per-class Theorem A. MIXED.
Net: tier moves 3 down, 0 up, no external mass. Additions A-1, A-2, A-3. Open aperture F-7 (independent referee of companion Theorem A).
Outside the artifact: codex card RAF-PSP-HODGE-TERMINUS-01 (v3.34.0) likely carries the pre-repair transport-closure definition; erratum candidate for the architect.
Statement: held under all six registers, controls 15 of 15 SELF throughout: a vacuous transport gate and an overstated Mirror equivalence repaired, three tiers lowered, one unsupported priority claim withdrawn, one aperture open on the companion's Theorem A.
"""
open("CLOSING_CARD_hterm1.md", "w", encoding="utf-8").write(card)
zp = f"{OUT}/A_Formal_Proof_of_Hodge_Conjecture_Termination_audit_ledger_hterm1.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(glob.glob("audit_hterm1/*") + glob.glob("prosecution_hterm1_r*.md") + glob.glob("seeded_hterm1_r*.md") + glob.glob("hterm_v*.md") + glob.glob("*.py") + glob.glob("*.json") + ["boot_hterm1.txt", "CLOSING_CARD_hterm1.md"]):
        if os.path.isfile(f): z.write(f, f"audit_hterm1_bundle/{f}")
print("ledger bundle:", os.path.getsize(zp), "bytes,", len(zipfile.ZipFile(zp).namelist()), "files")
for f in sorted(os.listdir(OUT)):
    if f.startswith((N2, N1, "A_Formal_Proof_of_Hodge")): print(f"  {os.path.getsize(os.path.join(OUT, f)):>8}  {hashlib.sha256(open(os.path.join(OUT, f), 'rb').read()).hexdigest()[:12]}  {f}")
