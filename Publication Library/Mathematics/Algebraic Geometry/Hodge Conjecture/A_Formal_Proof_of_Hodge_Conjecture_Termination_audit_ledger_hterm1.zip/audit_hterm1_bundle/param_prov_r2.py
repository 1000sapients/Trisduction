import itertools, time, re, os, json
import numpy as np
from math import gcd
# ---- parameter battery: Table 3 floating singular values at the paper's own seeds (vectorized build, independent code) ----
def chars(d):
    units = [t for t in range(1, d) if gcd(t, d) == 1]
    g = np.array(list(itertools.product(range(1, d), repeat=6)), dtype=np.int64); ok = g.sum(1) == 3*d
    for t in units: ok &= ((t*g) % d).sum(1) == 3*d
    return g[ok]
def comps(total, cap, n=6):
    g = np.array(list(itertools.product(range(cap+1), repeat=n-1)), dtype=np.int64); last = total - g.sum(1); m = (last >= 0) & (last <= cap)
    return np.concatenate([g[m], last[m][:, None]], axis=1)
def build(d, coeffs):
    H = chars(d); C = comps(d, d-2); R = comps(4*d-6, d-2); base = d ** np.arange(6)
    rc = R @ base; order = np.argsort(rc); rs = rc[order]; A = np.zeros((len(R), len(C))); cidx = np.arange(len(C))
    for k, b in enumerate(H):
        m = np.all(C + b <= d-1, axis=1)
        if m.any():
            tc = (C[m] + b - 1) @ base; pos = np.searchsorted(rs, tc); assert np.all(rs[pos] == tc); A[order[pos], cidx[m]] = coeffs[k]
    return A
printed = {6: 2.65e-4, 7: 0.0967, 8: 0.171, 9: 0.212, 10: 0.243}; out = {}
for d in range(6, 11):
    t = time.time(); nH = len(chars(d)); A = build(d, np.random.default_rng(20260622 + d).standard_normal(nH))
    s = np.linalg.svd(A, compute_uv=False); tol = s.max()*max(A.shape)*np.finfo(float).eps
    out[d] = dict(rank=int((s > tol).sum()), cols=A.shape[1], s_min_rel=float(s.min()/s.max()), tol_rel=float(tol/s.max()), secs=round(time.time()-t, 1))
    print(f"d={d} rank {out[d]['rank']}/{out[d]['cols']} s_min_rel {out[d]['s_min_rel']:.4g} (printed {printed[d]}) match {abs(out[d]['s_min_rel']-printed[d])/printed[d] < 0.01} tol_rel {out[d]['tol_rel']:.3g} [{out[d]['secs']}s]", flush=True)
print("max tol_rel", max(v['tol_rel'] for v in out.values()), "< 3e-12:", max(v['tol_rel'] for v in out.values()) < 3e-12)
json.dump(out, open("param_battery_r2.json", "w"), indent=1)
# ---- provenance battery ----
card = "/mnt/user-data/outputs/RAF-PSP-HODGE-TERMINUS-01.md"; ct = open(card, encoding="utf-8").read()
hits = [m.start() for m in re.finditer(r"infinitesimally rigid|no Hodge class|prediction", ct, re.I)]
print("card prediction hits:", len(hits), "|", " || ".join(ct[max(0, h-90):h+110].replace("\n", " ") for h in hits[:2]))
for f in (card, "/home/claude/hodgeterm/hodge_chars.py", "/home/claude/hodgeterm/rigidity_battery.py", "/home/claude/hodgeterm/rigidity_battery.json"):
    print("  mtime", time.strftime("%H:%M:%S", time.localtime(os.path.getmtime(f))), f.split("/")[-1])
s = open("hterm_v2.md", encoding="utf-8").read()
cites = {k.strip() for g in re.findall(r"\\cite\{([^}]+)\}", s) for k in g.split(",")}; bibs = re.findall(r"\\bibitem\{([^}]+)\}", s)
print("cited without bibitem:", sorted(cites - set(bibs)), "| bibitems never cited:", sorted(set(bibs) - cites), "| 'called in advance' occurrences:", s.count("called in advance"), "| walther2000 occurrences:", s.count("walther2000"))
