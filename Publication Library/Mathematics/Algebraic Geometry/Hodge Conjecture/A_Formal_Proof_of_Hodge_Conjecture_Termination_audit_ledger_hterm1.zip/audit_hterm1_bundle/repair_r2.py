import json, re
s = open("hterm_v2.md", encoding="utf-8").read(); specs = {}
def rep(old, new):
    global s
    assert s.count(old) == 1, ("FAULT anchor", s.count(old), old[:100]); s = s.replace(old, new)
# F-5: Witness Theorem at structural grade as a whole
i = s.index("C3 (Theorem 6.8):"); j = s.index(" C4 (Theorem 6.7):", i); oldc3 = s[i:j]
s = s[:i] + "C3 (Theorem 6.8): the Witness Theorem, structural, since its relocation channel rests on C4; its witness and conversion channels are theorem-grade on Definitions 4.2 and 4.3 and on the walls." + s[j:]
assert s.count("Theorem 6.8 (Witness Theorem)") == 1
i = s.index("Theorem 6.8 (Witness Theorem)"); j = s.index("whose witness seat is empty.", i) + len("whose witness seat is empty.")
if s[j] == "*": j += 1
s = s[:j] + " Grade: structural, through Theorem 6.7 in the relocation channel; theorem in the witness and conversion channels." + s[j:]
rep("Grades: (a) theorem, conditional on Theorem A of \\cite{islam2026w}; (b) theorem where Theorem 6.8 is theorem-grade and structural where Theorem 6.7 enters; (c) structural.",
    "Grades: (a) theorem, conditional on Theorem A of \\cite{islam2026w}, as a statement about grounding, and structural in its reading as truth in the kinetic register, which rests on (c); (b) structural, through Theorem 6.8; (c) structural.")
rep("; theorem conditional on Theorem A of \\cite{islam2026w} in part (a), theorem in part (b) where Theorem 6.8 is theorem-grade and structural where Theorem 6.7 enters, structural in part (c).",
    "; theorem conditional on Theorem A of \\cite{islam2026w} in part (a) as a statement about grounding and structural in its reading as truth in the kinetic register, structural in parts (b) and (c).")
specs["F-5"] = dict(banned=["theorem where Theorem 6.8 is theorem-grade", oldc3[:75]], required=["the Witness Theorem, structural, since its relocation channel rests on C4", "Grade: structural, through Theorem 6.7 in the relocation channel", "(b) structural, through Theorem 6.8"])
# F-6: the kinetic reading of 9.1(a) carried through (c)
rep("if and only if every instance of Axiom W is grounded, that is, if and only if Axiom W is true in the kinetic register, every instance of it witnessed by a deed.",
    "if and only if every instance of Axiom W is grounded; by part (c) an instance is grounded only through a deed, so the condition is that Axiom W is true in the kinetic register, every instance of it witnessed by a deed.")
specs["F-6"] = dict(banned=["is grounded, that is, if and only if Axiom W is true in the kinetic register", "in part (a), theorem in part (b) where Theorem 6.8"], required=["by part (c) an instance is grounded only through a deed", "structural in its reading as truth in the kinetic register"])
# F-7 aperture disclosure, declared addition A-3
i = s.index("**Limitations.**"); j = s.index("\n", i)
s = s[:j] + " Proposition 9.1(a) inherits the status of Theorem A of \\cite{islam2026w}, whose proof has been audited under self-seeded controls and has not been refereed." + s[j:]
# F-8: Lemma 5.1 carried by its own argument; the out-of-scope citation removed
i = s.index("The algebraic de Rham cohomology"); j = s.index("walther2000}.", i) + len("walther2000}."); print("OLD 5.1 sentence:", s[i:j])
s = s[:i] + "The algebraic de Rham cohomology $H^{2n-2p}_{\\mathrm{dR}}(X/K)$ is the hypercohomology of the algebraic de Rham complex \\cite{grothendieck1966}; since the Hodge to de Rham spectral sequence of a smooth projective variety degenerates at $E_1$, its Hodge filtration is the image of the hypercohomology of the truncation $\\Omega^{\\ge q}_{X/K}$, and both are computable by Čech cohomology of coherent sheaves on a finite affine cover." + s[j:]
bi = s.index("\\bibitem{walther2000}"); be = s.index("\n", bi); ls = s.rfind("\n", 0, bi); print("REMOVED BIB:", s[ls+1:be][:90]); s = s[:ls] + s[be:]
assert s.count("walther2000") == 0
specs["F-8"] = dict(banned=["walther2000", "with its Hodge filtration is computable"], required=["degenerates at $E_1$", "Čech cohomology of coherent sheaves on a finite affine cover"])
# F-9: the unsupported temporal claim scoped away
rep("A calibration prediction called in advance, that", "A calibration prediction, that")
rep("A calibration prediction called in advance failed", "A calibration prediction failed")
i = s.index("The prediction, called in advance."); j = s.index("the following was registered:", i) + len("the following was registered:"); print("OLD 8 run-in:", s[i-2:j])
s = s[:i] + "The prediction.** The following was placed at risk:" + s[j:] if s[i-2:i] == "**" and s[i:j].count("**") == 1 else None
assert s is not None and s.count("called in advance") == 0
specs["F-9"] = dict(banned=["called in advance", "Before any kernel was computed, the following was registered"], required=["**The prediction.** The following was placed at risk:", "A calibration prediction, that no Hodge class"])
for k, v in specs.items(): json.dump(v, open(f"audit_hterm1/sweep_r2_{k}.json", "w"), ensure_ascii=False, indent=1)
from plant_hterm import E
print("control originals intact in v3:", all(s.count(o) == 1 for o, n in E.values()))
open("hterm_v3.md", "w", encoding="utf-8").write(s); print("v3 words", len(re.findall(r"\S+", s)), "| em-dash", s.count("—"))
def para(key):
    i = s.index(key); a = s.rfind("\n\n", 0, i) + 2; b = s.find("\n\n", i); return s[a:b]
for key in ("Theorem 6.8 (Witness Theorem)", "**Proposition 9.1 (The pair).**", "**Limitations.**"): print("=====", key, "\n", para(key), "\n")
for key, w in (("C3 (Theorem 6.8):", 330), ("C10 (Proposition 9.1):", 720), ("The algebraic de Rham cohomology", 520), ("**The prediction.**", 260), ("A calibration prediction, that", 160), ("A calibration prediction failed", 120)):
    i = s.index(key); print("=====", key, "\n", s[i:i+w], "\n")
