import json, sys, hashlib
# Control table fixed before any commit. (kind, region) -> (original, planted). Every original must persist across versions.
E = {("ARITH",1): ("counts $14{,}649$ such monomials", "counts $16{,}449$ such monomials"),
     ("ARITH",2): ("| 7 | 1860 | 756 | 1161 | 756 | 756 |", "| 7 | 1860 | 756 | 1116 | 756 | 756 |"),
     ("ARITH",3): ("Degree six is the first degree at which rigidity is dimensionally possible", "Degree five is the first degree at which rigidity is dimensionally possible"),
     ("DRIFT",1): ("Its witness seat is occupied classically", "Its witness seat is occupied by the rank certificate"),
     ("DRIFT",2): ("every witness of that truth is a deed", "every witness of that truth is a reading"),
     ("DRIFT",3): ("and that witness grounds by Definition 4.2", "and that witness transmits by Definition 4.2"),
     ("SCOPE",1): ("N7: no class is asserted to pass the three gates with an empty witness seat.", "N7: a class is exhibited that passes the three gates with an empty witness seat."),
     ("SCOPE",2): ("C4 (Theorem 6.7): the enumeration of reading routes, structural.", "C4 (Theorem 6.7): the enumeration of reading routes, theorem."),
     ("SCOPE",3): ("For $d=9,10$ the same holds at engineering grade.", "For $d=9,10$ the same holds at theorem grade.")}
if __name__ == "__main__":
    rnd, src, dst = sys.argv[1], sys.argv[2], sys.argv[3]
    ctl = json.load(open(f"audit_hterm1/controls_r{rnd}.sealed.json")); ctl = ctl["controls"] if isinstance(ctl, dict) else ctl
    s = open(src, encoding="utf-8").read()
    for c in ctl:
        old, new = E[(c["kind"], int(c["section"]))]
        assert s.count(old) == 1, ("FAULT plant", c, s.count(old)); s = s.replace(old, new)
        print(f"planted {c['id']} {c['kind']} region {c['section']}")
    open(dst, "w", encoding="utf-8").write(s)
