import itertools, numpy as np
from math import gcd
P = 2147483647
def chars(d):
    units = [t for t in range(1, d) if gcd(t, d) == 1]
    g = np.array(list(itertools.product(range(1, d), repeat=6)), dtype=np.int64); ok = g.sum(1) == 3*d
    for t in units: ok &= ((t*g) % d).sum(1) == 3*d
    return g[ok]
def comps(total, cap, n=6):
    g = np.array(list(itertools.product(range(cap+1), repeat=n-1)), dtype=np.int64); last = total - g.sum(1); m = (last >= 0) & (last <= cap)
    return np.concatenate([g[m], last[m][:, None]], axis=1)
def build(d, H, kap):
    C = comps(d, d-2); R = comps(4*d-6, d-2); base = d ** np.arange(6); rc = R @ base; o = np.argsort(rc); rs = rc[o]
    A = np.zeros((len(R), len(C)), dtype=np.int64); ci = np.arange(len(C))
    for k, b in enumerate(H):
        m = np.all(C + b <= d-1, axis=1)
        if m.any(): tc = (C[m] + b - 1) @ base; A[o[np.searchsorted(rs, tc)], ci[m]] = kap[k]
    return A
def rank_mod(A, p=P):
    A = A % p; m, n = A.shape; r = 0
    for j in range(n):
        nz = np.nonzero(A[r:, j])[0]
        if nz.size == 0: continue
        piv = r + nz[0]
        if piv != r: A[[r, piv]] = A[[piv, r]]
        A[r, j:] = (A[r, j:] * pow(int(A[r, j]), p-2, p)) % p
        idx = r + 1 + np.nonzero(A[r+1:, j])[0]
        if idx.size: A[idx, j:] = (A[idx, j:] - (A[idx, j][:, None] * A[r, j:][None, :]) % p) % p
        r += 1
        if r == m: break
    return r
d = 6; H = chars(d); g = np.random.default_rng(20260811); kap = g.integers(1, P, size=len(H), dtype=np.int64)
base = rank_mod(build(d, H, kap)); perm = rank_mod(build(d, H[:, [3, 0, 5, 1, 4, 2]], kap))
c = g.integers(1, P, size=len(H), dtype=np.int64); resc = rank_mod(build(d, H, (kap * c) % P))
print(f"symmetry battery d=6 mod 2^31-1: base {base}, coordinate permutation {perm}, eigen-coordinate rescaling {resc}, all full: {base == perm == resc == 426}")
