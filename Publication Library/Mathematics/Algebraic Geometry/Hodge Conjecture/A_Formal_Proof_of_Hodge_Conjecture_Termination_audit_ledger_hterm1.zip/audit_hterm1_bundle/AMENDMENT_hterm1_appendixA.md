# AMENDMENT after the hterm1 seal
At the author's instruction the ungraded originating declaration (Appendix A) was restated in academic form, and one reference was added (Zenodo 20805972, cited there).
Confinement verified mechanically: every changed line lies inside Appendix A or that reference. Sealed v6 sha cd9b6cc33d06; amended v7 sha 2a888431a8f5.
The hterm1 seal covers every graded claim, all unchanged in v7; Appendix A remains ungraded and is not asserted by the theorems.
