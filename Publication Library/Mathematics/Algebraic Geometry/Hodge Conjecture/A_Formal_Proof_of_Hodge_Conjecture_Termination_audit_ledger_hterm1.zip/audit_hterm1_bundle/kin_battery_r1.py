# Round-1 kinematic re-execution, second channel: fresh enumeration, closed forms, second prime, fresh coordinates.
import itertools, json, math, time, sys
import numpy as np
from math import comb, gcd
def dimR(deg, d, n=6):   # monomials of degree deg in n vars, exponents <= d-2: inclusion-exclusion
    return sum((-1)**j * comb(n, j) * comb(deg - j*(d-1) + n - 1, n - 1) for j in range(n+1) if deg - j*(d-1) >= 0)
def dimR_brute(deg, d, n=6):
    cnt = 0
    for c in itertools.product(range(0, d-1), repeat=n-1):
        r = deg - sum(c)
        if 0 <= r <= d-2: cnt += 1
    return cnt
def chars(d):             # a in {1..d-1}^6, sum 3d, every unit t: sum(t a mod d) = 3d ; numpy channel
    units = [t for t in range(1, d) if gcd(t, d) == 1]
    grid = np.array(list(itertools.product(range(1, d), repeat=6)), dtype=np.int64)
    ok = grid.sum(1) == 3*d
    for t in units: ok &= ((t*grid) % d).sum(1) == 3*d
    return grid[ok]
out = {}
for d in range(6, 11):
    H = chars(d); out[d] = dict(chars=len(H), dimRd=dimR(d, d), target=dimR(4*d-6, d), brute_dimRd=dimR_brute(d, d) if d <= 8 else None)
    print("d", d, out[d], flush=True)
first = next(d for d in range(3, 12) if dimR(2*d-6, d) >= dimR(d, d)); print("first degree with dim R_{2d-6} >= dim R_d:", first, [ (d, dimR(2*d-6,d), dimR(d,d)) for d in (3,4,5,6)])
# degree-70 orbit kernel bound, independent inclusion-exclusion
d, a = 70, (1, 20, 24, 42, 61, 62); units = [t for t in range(1, d) if gcd(t, d) == 1]
mins = [min((t*x) % d for t in units) for x in a]; thr = [d - m for m in mins]
feas = [i for i in range(6) if thr[i] <= d - 2]
def count_ge(S):          # monomials of degree 70, exps <= 68, with c_i >= thr_i for i in S
    base = d - sum(thr[i] for i in S)
    if base < 0: return 0
    caps = [ (d-2 - thr[i]) if i in S else (d-2) for i in range(6)]
    # count solutions sum y = base, 0<=y_i<=caps_i by inclusion-exclusion over caps
    tot = 0
    for mask in range(1 << 6):
        s = base; sign = 1
        for i in range(6):
            if mask >> i & 1: s -= caps[i] + 1; sign = -sign
        if s >= 0: tot += sign * comb(s + 5, 5)
    return tot
union = 0
for k in range(1, len(feas)+1):
    for S in itertools.combinations(feas, k): union += (-1)**(k+1) * count_ge(S)
print("orbit size", len(units), "| minima", mins, "| feasible", feas, "| kernel lower bound", union, "| dim R_70", dimR(70, 70))
json.dump(dict(out=out, first=first, orbit=len(units), mins=mins, feas=feas, bound=union, dimR70=dimR(70,70)), open("kin_battery_r1.json", "w"), indent=1)
