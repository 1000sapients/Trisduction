import json, re
s = open("hterm_v1.md", encoding="utf-8").read(); v1 = s
def rep(old, new):
    global s
    assert s.count(old) == 1, ("FAULT anchor", s.count(old), old[:100]); s = s.replace(old, new)
specs = {}
# F-1 Mirror: implication, not equivalence, at an instance
rep("is materially the assertion that the instance fails, a Hodge class that is not algebraic, and the assertion",
    "is materially the assertion that $Q$ refutes it, which entails that the instance fails, a Hodge class that is not algebraic, although the failure of an instance does not by itself entail its refutation in $Q$; and the assertion")
rep("is materially asserting that the instance fails.",
    "is materially asserting that Robinson arithmetic refutes it, which entails that the instance fails.")
rep("the universal form of that assertion is the negation in costume.",
    "the universal form of that assertion is a refutation in Robinson arithmetic in costume, and it entails the negation.")
rep("the Unprovability Mirror therefore holds unchanged, and the flanks",
    "the Unprovability Mirror holds for these sentences as for every arithmetic sentence, and the flanks")
specs["F-1"] = dict(banned=["is materially the assertion that the instance fails", "is materially asserting that the instance fails", "the universal form of that assertion is the negation in costume", "the Unprovability Mirror therefore holds unchanged"],
                    required=["materially the assertion that $Q$ refutes it", "materially asserting that Robinson arithmetic refutes it", "a refutation in Robinson arithmetic in costume", "holds for these sentences as for every arithmetic sentence"])
# F-2 transport closure by reachability
rep("The class $\\alpha$ is transport-closed when no smooth projective variety $Y$, correspondence $\\Gamma\\in CH(Y\\times X)_{\\mathbb{Q}}$ and Hodge class $\\beta$ on $Y$ whose pair is not rigid satisfy $\\Gamma_*\\beta=\\alpha$.",
    "The class $\\alpha$ is transport-closed when no smooth projective variety $Y$, correspondence $\\Gamma\\in CH(Y\\times X)_{\\mathbb{Q}}$ and Hodge class $\\beta$ on $Y$ satisfy $\\Gamma_*\\beta=\\alpha$ with $\\beta$ reached, meaning obtained from the supplied set by the routes of Theorem 6.7 without passing through $\\alpha$. Non-rigidity of the source pair does not suffice: for an elliptic curve $E$ the class $\\beta=\\operatorname{pr}_X^*\\alpha\\cup\\operatorname{pr}_E^*[\\mathrm{pt}]$ on $X\\times E$ remains Hodge as $E$ varies and the graph of the projection carries it onto $\\alpha$, while its algebraicity on every fibre is the algebraicity of $\\alpha$.")
n_rig = s.count("together with the rigidity status of the source classes"); n_nr = s.count("through a correspondence from a non-rigid class")
print("F-2 consumer pre-counts:", n_rig, n_nr)
if n_rig: rep("together with the rigidity status of the source classes", "together with the reached status of the source classes")
if n_nr: rep("through a correspondence from a non-rigid class", "through a correspondence from a reached class")
specs["F-2"] = dict(banned=["whose pair is not rigid satisfy"] + (["together with the rigidity status of the source classes"] if n_rig else []) + (["through a correspondence from a non-rigid class"] if n_nr else []),
                    required=["with $\\beta$ reached"] + (["reached status of the source classes"] if n_rig else []) + (["through a correspondence from a reached class"] if n_nr else []))
# F-3 presentations over C with a field datum
rep("a smooth projective variety $X$ over $\\overline{\\mathbb{Q}}$ given by equations;",
    "a smooth projective variety $X$ over $\\mathbb{C}$ given by equations over a field of definition $k\\subset\\mathbb{C}$;")
specs["F-3"] = dict(banned=["a smooth projective variety $X$ over $\\overline{\\mathbb{Q}}$ given by equations"], required=["over a field of definition $k\\subset\\mathbb{C}$"])
# F-4 the pair at the level of grounding
rep("(a) The derivation of \\cite{islam2026w} delivers the Hodge conjecture for every smooth complex projective variety and every $p$ if and only if Axiom W holds.",
    "(a) The derivation of \\cite{islam2026w} grounds the Hodge conjecture for every smooth complex projective variety and every $p$ if and only if every instance of Axiom W is grounded, that is, if and only if Axiom W is true in the kinetic register, every instance of it witnessed by a deed.")
rep("(a) If Axiom W holds, Theorem A of \\cite{islam2026w} gives the conjecture for every $X$ and every $p$. If it fails, the derivation rests on a false premise and, by Definition 4.2, delivers no warrant for the conjecture, whatever the truth of the conjecture itself. (b) The proof of Theorem A in \\cite{islam2026w} fixes one class and consumes only the instance of the axiom at that class, so an instance",
    "(a) The proof of Theorem A of \\cite{islam2026w} fixes one class, consumes only the instance of the axiom at that class, and adds no posit. If every instance is grounded, the derivation therefore grounds the conjecture at every class by Definition 4.2. If the instance at some class is not grounded, the derivation at that class rests on an ungrounded premise and, by Definition 4.2, grounds nothing there, whatever the truth of the conjecture itself. (b) By the same per-class form, an instance")
rep("Grounded, the conjecture is universal through the pair if and only if Axiom W is true, and by part (c) every witness of that truth is supplied in the kinetic register, since no reading supplies one.",
    "Grounded, the conjecture is universal through the pair if and only if Axiom W is true in the kinetic register, every instance of it witnessed by a deed, and by part (c) no instance is witnessed otherwise, since no reading supplies a witness.")
rep("whose derivation delivers the conjecture for every variety and every $p$ if and only if Axiom W holds,",
    "whose derivation grounds the conjecture for every variety and every $p$ if and only if Axiom W is true in the kinetic register,")
rep("the paper completes one proof, universal exactly when the axiom is true, and every witness of that truth is supplied by a construction and never by a reading.",
    "the paper completes one proof, universal exactly when every instance of the axiom is witnessed, and every such witness is supplied by a construction and never by a reading.")
rep("the paper completes one proof, universal if and only if Axiom W is true, every witness of that truth supplied by a construction and none by a reading.",
    "the paper completes one proof, universal if and only if every instance of Axiom W is witnessed, every witness supplied by a construction and none by a reading.")
rep("its universality is the truth of Axiom W, which N6 leaves unasserted,", "its universality is the truth of Axiom W in the kinetic register, which N6 leaves unasserted,")
specs["F-4"] = dict(banned=["delivers the Hodge conjecture for every smooth complex projective variety", "whose derivation delivers the conjecture", "universal exactly when the axiom is true", "universal if and only if Axiom W is true, every witness", "delivers no warrant for the conjecture"],
                    required=["if and only if every instance of Axiom W is grounded", "true in the kinetic register, every instance of it witnessed by a deed", "universal exactly when every instance of the axiom is witnessed", "universal if and only if every instance of Axiom W is witnessed"])
for k, v in specs.items(): json.dump(v, open(f"audit_hterm1/sweep_r1_{k}.json", "w"), ensure_ascii=False, indent=1)
from plant_hterm import E
lost = [k for k, (o, n) in E.items() if s.count(o) != 1]
print("control originals intact in v2:", not lost, lost)
open("hterm_v2.md", "w", encoding="utf-8").write(s)
print("v2 words", len(re.findall(r"\S+", s)), "| em-dash", s.count("—"))
