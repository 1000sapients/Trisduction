# Prosecution, cycle hterm1, round 4. Registers: parameter, provenance. Blind pass on seeded_hterm1_r4.md.

Declared target: the restated sentence of Corollary 6.14(c) from round 3, prosecuted against Definition 6.1, Proposition 9.1 and the companion's proof.

Executed checks:
- every citation key has an entry: pass (missing [])
- receipt rigidity_battery.py digest 6791d29e9b88 printed and matched: pass (located 1, digests ['6791d29e9b88'])
- receipt rigidity.py digest 0bbbc8bceb60 printed and matched: pass (located 2, digests ['0bbbc8bceb60'])
- receipt psi.py digest d3b67c0a3f71 printed and matched: pass (located 2, digests ['21ece56f2062', 'd3b67c0a3f71'])
- receipt fae_raf_engine*.py digest b6c38d9c2240 printed and matched: pass (located 2, digests ['b6c38d9c2240'])
- parameter $20260622+d$ stated in Section 8 and Appendix B: pass (count 2)
- parameter $20260722+d$ stated in Section 8 and Appendix B: pass (count 2)
- parameter $2^{31}-1$ stated in Section 8 and Appendix B: pass (count 5)
- parameter 14{,}649 stated in Section 8 and Appendix B: pass (count 2)
- parameter 17{,}259{,}354 stated in Section 8 and Appendix B: pass (count 2)
- orbit representative (1,20,24,42,61,62) stated in Section 8: pass
- orbit minima (1,10,2,14,1,2) and feasible {1,2,3,5} in Appendix B, matching the executed battery: pass
- note: a first run of this battery searched for the representative with math delimiters at two sites; Appendix B restates the figures, not the representative, so the check was mis-specified and was corrected; no finding was filed on it
- round-3 repair sentence against Definition 6.1 and Proposition 9.1: pass

Findings: none. Every executed check passed; no mathematical error or internal contradiction was found in the declared registers.
