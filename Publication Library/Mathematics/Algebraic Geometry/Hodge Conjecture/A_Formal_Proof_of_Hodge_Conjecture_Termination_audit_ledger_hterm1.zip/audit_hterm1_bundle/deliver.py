import os, re, glob, shutil, subprocess, hashlib, json, zipfile
OUT = "/mnt/user-data/outputs"; run = lambda c: subprocess.run(c, shell=True, capture_output=True, text=True, errors="replace")
def latest_log():
    return open(sorted(glob.glob("/tmp/mathjournal_*/paper.log"), key=os.path.getmtime)[-1], errors="replace").read()
def probe(pdf, tokens):
    t = run(f"pdftotext -layout '{pdf}' -").stdout; flat = re.sub(r"\s+", "", re.sub(r"-\s*\n\s*", "", t)).lower()
    pages = re.search(r"Pages:\s+(\d+)", run(f"pdfinfo '{pdf}'").stdout).group(1)
    return pages, {k: (re.sub(r"\s+", "", k).lower() in flat) for k in tokens}
FIX = [("\\overline{\\mathbb{Q}}", "ℚ̄"), ("\\overline{ℚ}", "ℚ̄"), ("\\overlineℚ", "ℚ̄"), ("\\nvdash", "⊬"), ("\\vdash", "⊢"), ("\\models", "⊨"), ("\\iff", "⟺"), ("\\forall", "∀"),
       ("\\exists", "∃"), ("\\neg", "¬"), ("\\Pi", "Π"), ("\\Psi", "Ψ"), ("\\Xi", "Ξ"), ("\\text{\\O}", "Ø"), ("\\mathcal{F}", "𝓕"), ("\\mathcal{T}", "𝒯"), ("\\Gamma", "Γ"),
       ("\\omega", "ω"), ("\\cup", "∪"), ("\\longrightarrow", "⟶"), ("\\qquad", "  "), ("\\quad", " "), ("\\mathbb{N}", "ℕ"), ("\\operatorname{pr}", "pr"), ("\\operatorname{cl}", "cl"),
       ("\\mathrm{HC}", "HC"), ("\\mathrm{dR}", "dR"), ("\\mathrm{pt}", "pt"), ("\\partial", "∂"), ("\\infty", "∞"), ("\\bar", ""), ("\\Omega", "Ω"), ("\\ge", "≥")]
def blog(src, dst, header_old, header_new):
    tmp = dst + ".tmp"; run(f"python3 /home/claude/paper/latex2blog_hsw2.py '{src}' '{tmp}'"); r = run(f"python3 /home/claude/paper/build_blog.py '{tmp}' '{dst}'")
    b = open(dst, encoding="utf-8").read(); os.remove(tmp)
    for a, c in FIX: b = b.replace(a, c)
    b = re.sub(r"\\text\{([^{}]*)\}", r"\1", b); b = re.sub(r"\\mathrm\{([^{}]*)\}", r"\1", b); b = re.sub(r"\\operatorname\{([^{}]*)\}", r"\1", b)
    if header_old in b: b = b.replace(header_old, header_new)
    open(dst, "w", encoding="utf-8").write(b)
    return len(re.findall(r"\\[a-zA-Z]{2,}", b)), sorted(set(re.findall(r"\\[a-zA-Z]{2,}", b)))[:12], b.count("\n|"), (header_new in b)
HSW = "*Blog edition of the sealed master: audit cycle hsw2 closed at SEALED-ROUND under SELF-grade controls on this text; it renders that master and adds no claim.*"
# ---------------- paper 2, sealed ----------------
N2 = "A_Formal_Proof_of_Hodge_Conjecture_Termination_at_the_Formal-Alone_Register"; B = "/home/claude/hterm/build"; os.makedirs(B + "/out", exist_ok=True)
shutil.copy("hterm_v6.md", f"{B}/{N2}.md"); tpl = open("/home/claude/hodgeterm/build/mathjournal.tex", encoding="utf-8").read()
assert tpl.count("\\usepackage{longtable}") == 1; open(f"{B}/mathjournal.tex", "w", encoding="utf-8").write(tpl.replace("\\usepackage{longtable}", "\\usepackage{longtable}\\usepackage{calc}"))
r = run(f"python3 /home/claude/paper1u/build_mathjournal_local.py {B}/{N2}.md {B}/out/{N2}.pdf"); print("PAPER 2 BUILD:", r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-400:])
if os.path.exists(f"{B}/out/{N2}.pdf"):
    log = latest_log(); pages, pr = probe(f"{B}/out/{N2}.pdf", ["End of manuscript", "Conclusion", "References", "Proposition 9.1", "kinetic register", "10116", "14,649", "since smooth projective families can jump"])
    print(f"  preflight: pages {pages} | errors {len(re.findall(r'^! ', log, re.M))} | overfull hbox {len(re.findall(r'Overfull .hbox', log))} | undefined refs {len(re.findall(r'undefined', log))} | probes {pr}")
    ob = re.findall(r"Overfull \\hbox \((\d+\.?\d*)pt too wide\)[^\n]*\n([^\n]{0,80})", log); print("  overfull detail:", ob[:6])
    res = blog(f"{B}/{N2}.md", f"{B}/out/{N2}.blog.md", HSW, "*Blog edition of the sealed master: audit cycle hterm1 closed at SEALED-ROUND under SELF-grade controls on this text, one aperture open; it renders that master and adds no claim.*")
    print(f"  blog: residual LaTeX {res[0]} {res[1]} | table rows left {res[2]} | header rewritten {res[3]}")
# ---------------- paper 1, prelude wording harmonized to the sealed pair ----------------
P = "/home/claude/paper1u"; N1 = "A_Proof_of_the_Hodge_Conjecture_Derived_from_One_Semiregular_Witness_Axiom"; s = open(f"{P}/{N1}.md", encoding="utf-8").read()
for a, c in [("so the two papers form one proof, universal exactly when the axiom is true.", "so the two papers form one proof, universal exactly when every instance of the axiom is witnessed, each witness supplied by a construction and none by a reading."),
             ("Read together, the derivation here is universal if and only if Axiom W is true, and every witness of that truth is supplied by a construction and none by a reading. This paper stands alone as a conditional theorem; the pair completes it as one proof whose single open condition is the truth of the axiom.",
              "Read together, the derivation here grounds the conjecture for every variety if and only if every instance of Axiom W is witnessed, which the companion calls the truth of the axiom in the kinetic register, and every such witness is supplied by a construction and none by a reading. This paper stands alone as a conditional theorem; the pair completes it as one proof whose single open condition is that witnessing."),
             ("so that a true instance carries a finite witness, and that at a class on which", "so that a true instance carries a finite witness, and, at structural grade through its enumeration of reading routes, that at a class on which"),
             ("and the proof is universal if and only if Axiom W is true, with every witness of that truth supplied by a construction.", "and the proof grounds the conjecture for every variety if and only if every instance of Axiom W is witnessed, every witness supplied by a construction."),
             ("so the derivation here is universal exactly when Axiom W is true.", "so the derivation here is universal exactly when every instance of Axiom W is witnessed.")]:
    assert s.count(a) == 1, ("FAULT paper1 anchor", a[:60]); s = s.replace(a, c)
open(f"{P}/{N1}.md", "w", encoding="utf-8").write(s)
pub = open(f"{P}/published_v1_backup/{N1}.md", encoding="utf-8").read()
pat = re.compile(r"Theorem [A-Z]\b|Lemma \d+|Proposition [A-Z]\b|\(I\d\)|\(W\d\)|\bF\d\b|\\bibitem\{[^}]+\}|^#{1,2} .+$|Table \d", re.M)
print("PAPER 1 L6 census: lost", sorted(set(pat.findall(pub)) - set(pat.findall(s))), "| added", sorted(set(pat.findall(s)) - set(pat.findall(pub))), "| 'universal exactly when the axiom is true' left:", s.count("when the axiom is true"), "| em-dash", s.count("—"))
r = run(f"python3 {P}/build_mathjournal_local.py {P}/{N1}.md {P}/out/{N1}.pdf"); print("PAPER 1 BUILD:", r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-300:])
log = latest_log(); pages, pr = probe(f"{P}/out/{N1}.pdf", ["Discussion", "Conclusion", "References", "first of a pair", "What the companion adds"])
print(f"  preflight: pages {pages} | errors {len(re.findall(r'^! ', log, re.M))} | overfull hbox {len(re.findall(r'Overfull .hbox', log))} | undefined refs {len(re.findall(r'undefined', log))} | probes {pr}")
res = blog(f"{P}/{N1}.md", f"{P}/out/{N1}.blog.md", HSW, "*Blog edition of the prelude edition of the master: audit cycle hsw2 closed at SEALED-ROUND under SELF-grade controls on the text of the first edition, and this edition adds, after that seal, the framing of the pair, passages that point to the companion paper, whose claims are proved and audited there under cycle hterm1.*")
print(f"  blog: residual LaTeX {res[0]} {res[1]} | header rewritten {res[3]}")
j = json.load(open(f"{P}/out/{N1}.zenodo.json")); j["metadata"]["description"] = j["metadata"]["description"].replace("universal exactly when Axiom W is true", "universal exactly when every instance of Axiom W is witnessed"); json.dump(j, open(f"{P}/out/{N1}.zenodo.json", "w"), ensure_ascii=False, indent=2)
print("  zenodo staging json version", j["metadata"]["version"], "| harmonized:", "every instance of Axiom W is witnessed" in j["metadata"]["description"])
print("SHA256 prefixes:", {os.path.basename(f): hashlib.sha256(open(f, "rb").read()).hexdigest()[:12] for f in [f"{B}/{N2}.md", f"{B}/out/{N2}.pdf", f"{P}/{N1}.md", f"{P}/out/{N1}.pdf"] if os.path.exists(f)})
