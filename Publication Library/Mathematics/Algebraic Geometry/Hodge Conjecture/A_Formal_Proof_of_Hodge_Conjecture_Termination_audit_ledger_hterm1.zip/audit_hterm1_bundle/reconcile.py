import difflib, re
v1 = open("hterm_v1.md", encoding="utf-8").read(); vf = open("hterm_v6.md", encoding="utf-8").read()
anchors = {
 "R1 F-1": ["materially the assertion that $Q$ refutes it", "materially asserting that Robinson arithmetic refutes it", "a refutation in Robinson arithmetic in costume", "holds for these sentences as for every arithmetic sentence"],
 "R1 F-2": ["with $\\beta$ reached", "Non-rigidity of the source pair does not suffice", "reached status of the source classes", "through a correspondence from a reached class"],
 "R1 F-3": ["over a field of definition $k\\subset\\mathbb{C}$"],
 "R1 F-4": ["if and only if every instance of Axiom W is grounded", "consumes only the instance of the axiom at that class, and adds no posit", "By the same per-class form, an instance", "universal through the pair if and only if Axiom W is true in the kinetic register", "whose derivation grounds the conjecture for every variety", "universal exactly when every instance of the axiom is witnessed", "universal if and only if every instance of Axiom W is witnessed", "its universality is the truth of Axiom W in the kinetic register"],
 "R2 F-5": ["the Witness Theorem, structural, since its relocation channel rests on C4", "Grade: structural, through Theorem 6.7 in the relocation channel", "(b) structural, through Theorem 6.8", "structural in parts (b) and (c)"],
 "R2 F-6": ["by part (c) an instance is grounded only through a deed", "structural in its reading as truth in the kinetic register"],
 "R2 F-7/A-3": ["whose proof has been audited under self-seeded controls"],
 "R2 F-8": ["degenerates at $E_1$", "Čech cohomology of coherent sheaves on a finite affine cover"],
 "R2 F-9": ["**The prediction.** The following was placed at risk:", "A calibration prediction, that no Hodge class", "A calibration prediction failed and is reported"],
 "R3 F-10": ["since smooth projective families can jump", "through the per-class proof of Theorem A"]}
missing = [(e, ph[:40]) for e, phs in anchors.items() for ph in phs if ph not in vf]
apos = [(m.start(), e) for e, phs in anchors.items() for ph in phs for m in re.finditer(re.escape(ph), vf)]
A, B = v1.split("\n"), vf.split("\n"); starts = [0]
for l in B: starts.append(starts[-1] + len(l) + 1)
chunks = []
for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, A, B, autojunk=False).get_opcodes():
    if op == "equal": continue
    ta = re.findall(r"\S+|\s+", "\n".join(A[i1:i2])); tb = re.findall(r"\S+|\s+", "\n".join(B[j1:j2])); offs = [0]
    for t in tb: offs.append(offs[-1] + len(t))
    for o, a1, a2, b1, b2 in difflib.SequenceMatcher(None, ta, tb, autojunk=False).get_opcodes():
        if o != "equal" and ("".join(ta[a1:a2]).strip() or "".join(tb[b1:b2]).strip()):
            chunks.append((starts[j1] + offs[b1], "".join(ta[a1:a2]), "".join(tb[b1:b2])))
counts = {e: 0 for e in anchors}; orphans = []
for pos, old, new in chunks:
    if "walther2000" in old: counts["R2 F-8"] += 1; continue
    d, e = min((abs(p - pos), e) for p, e in apos)
    (orphans.append((pos, old[:50], new[:50])) if d > 1200 else counts.__setitem__(e, counts[e] + 1))
print("DIGEST RECONCILIATION v1 -> v6 | change chunks", len(chunks), "| per entry", counts)
print("entries with no landed change:", [e for e, v in counts.items() if v == 0], "| orphan chunks:", len(orphans), orphans[:3], "| anchors missing:", missing)
print("words v1", len(re.findall(r"\S+", v1)), "-> v6", len(re.findall(r"\S+", vf)), "| em-dash", vf.count("—"))
