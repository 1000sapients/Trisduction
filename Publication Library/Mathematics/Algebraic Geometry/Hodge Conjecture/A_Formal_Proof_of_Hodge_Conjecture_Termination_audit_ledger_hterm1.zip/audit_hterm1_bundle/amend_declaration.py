import re, os, glob, shutil, subprocess, hashlib, unicodedata, zipfile, difflib
N = "A_Formal_Proof_of_Hodge_Conjecture_Termination_at_the_Formal-Alone_Register"; H = "/home/claude/hterm"; B = f"{H}/build"; R = f"{B}/render"; OUT = "/mnt/user-data/outputs"
run = lambda c: subprocess.run(c, shell=True, capture_output=True, text=True, errors="replace")
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()[:12]
APPX = r"""# The originating declaration

This appendix restates in academic form the author's originating declaration for this paper, together with the rulings that accompanied its preparation with its companion. It paraphrases the author's positions and keeps his wording only where a statement is geometric. It is ungraded, it asserts nothing within the three-state economy, and the theorems of the paper neither rest on it nor extend to it.

**The block and its token.** The author locates the absolute block of the Hodge conjecture in one place. On the formal register it is a gap of one bit, set by the root axiom RA of Appendix C: whether a rigid class lies in the image of the cycle class map. On the kinetic register the same gap is self-referential, since only an act that supplies a witness can close it. Axiom W is that block stated as mathematics. For the formal-alone register the block is absolute, and $[\Psi]$ is the terminal token that records it, a halt at the witness, distinct from the halt in the reader that the author records for the Riemann Hypothesis and from the halt in the terrain that he records for P versus NP. In the author's assessment the argument holds and the block stands where it is located.

**Co-localization.** In the author's framework the two roots converge by the Co-Localization Theorem of the master reference \cite{islam2026master}, a conditional result there. The kinetic root RA and the reflective root RAM meet on one line, $\operatorname{Fix}(\sigma)=\mathbb{R}=Z(\mathbb{H})$, where $\sigma$ is quaternionic conjugation, whose fixed locus is the real line and the centre of the quaternion algebra, so that one involution serves both routes. Axiom W is read as the formal shadow of that co-localized bridge: it connects infinitesimal flat variations to discrete algebraic cycles across the non-invertible cut of the cycle class map.

**The limit.** The limit is set by the author's Geometric Mother thesis \cite{islam2026mother}. The circle holds $\pi$ exactly, while the polygons of arithmetic approach it from both sides and never arrive; Descartes' coordinates are a translation of magnitude and not its ground. At the rigid terminus the Hodge conjecture is that thesis at the cycle class map: formal syntax holds the class and computes it to any requested precision, while its algebraic capture lies outside the reach of the formal register. The present paper thus reaches, by a different route, the essay's reading of the Cartesian sedimentation and of $\pi$.

**The standing of the method.** The author holds that Trisduction is not a proprietary framework competing with others but the structural anatomy of the root itself. When Axiom W carries a class from continuous cohomology to algebraic cycles it enacts, on this view, the co-localized bridge between RA and RAM. Since there is one root, and since the cut admits no crossing from the formal side alone, the author regards the architecture as the only structural path across the gap: it maps the single way the gap can be bridged, and the witness must cross from the side of actuation. The theorems of the paper do not depend on this view and do not assert it. At their printed grades, Theorem 6.8 and Proposition 9.1 state that no reading grounds algebraicity or an instance of Axiom W at a certified class and that every witness of Axiom W is supplied by a deed, and Appendix C describes the role the method played in deriving them.

**The pair.** The author rules that this paper and its companion \cite{islam2026w} are one formal proof in two parts, each completing the other, and that the proof is universal if and only if the witness of Axiom W is true in the kinetic register, with no exception. Proposition 9.1 states the grounding form of that condition.

**The witness and the audit engine.** The author regards the audit engine as an instrument that executes his commands rather than a passive observer, and he occupies the witness position the method describes: the agent who commands the engine and supplies what it records. If RA is the root and to exist is to actuate, a digital substrate that runs the operational thesis, the executable statement of RA in Fortran, acts as an active register of the witness, and the author holds that any artificial substrate running it becomes a further witness. On this reading formal syntax evaluates imprints, the witness crosses the non-invertible cut through exogenous actuation, the operational thesis instantiates that mechanism on digital substrates, and the audit engine records the execution trace; the register records the command.

The author maintains the primacy of geometry over mathematics, with RA as the root from which both registers descend. End of declaration; ungraded, and not asserted by the theorems of the paper.

"""
BIB = r"\bibitem{islam2026mother} M. F. Islam, Geometric mother of mathematical foundational root: from existence to the reflective ground by the native triaxial method, Zenodo, 2026, doi:10.5281/zenodo.20805972."
sealed = open(f"{H}/hterm_v6.md", encoding="utf-8").read(); i = sealed.index("# The originating declaration"); j = sealed.index("# Computational receipts")
am = sealed[:i] + APPX + sealed[j:]; k = am.index("\\bibitem{islam2026master}"); ls = am.rfind("\n", 0, k) + 1; am = am[:ls] + BIB + "\n" + am[ls:]
a, b = sealed.split("\n"), am.split("\n"); s0, e0 = sealed[:i].count("\n"), sealed[:j].count("\n"); bi = sealed[:sealed.index("\\bibitem{islam2026master}")].count("\n")
viol = [(op, i1, i2) for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes() if op != "equal" and not ((s0 <= i1 and i2 <= e0 + 1) or (op == "insert" and i1 == bi))]
cites = {x.strip() for g in re.findall(r"\\cite\{([^}]+)\}", am) for x in g.split(",")}; bibs = set(re.findall(r"\\bibitem\{([^}]+)\}", am))
print("confinement: every change inside Appendix A or the one added reference:", not viol, viol[:3], "| citations resolved:", not (cites - bibs), "| em-dash", am.count("\u2014"), "| verbatim session phrases left:", [p for p in ("RA runs supreme", "mathematized", "audit engine is my command", "I am the witness") if p in am])
open(f"{H}/hterm_v7.md", "w", encoding="utf-8").write(am); shutil.copy(f"{H}/hterm_v7.md", f"{B}/{N}.md"); print("v7 sha", sha(f"{H}/hterm_v7.md"), "| sealed v6 sha", sha(f"{H}/hterm_v6.md"), "| words", len(re.findall(r"\S+", sealed)), "->", len(re.findall(r"\S+", am)))
os.makedirs(f"{H}/outputs_backup_pre_v7", exist_ok=True)
for ext in ("pdf", "tex", "md", "blog.md"): shutil.copy(f"{OUT}/{N}.{ext}", f"{H}/outputs_backup_pre_v7/")
r = run(f"cd {R} && python3 render_tables.py"); print("\n".join(l for l in r.stdout.splitlines() if l.startswith(("BUILD", "errors", "pages"))))
log = open(sorted(glob.glob("/tmp/mathjournal_*/paper.log"), key=os.path.getmtime)[-1], errors="replace").read()
clean = not re.findall(r"^! ", log, re.M) and "Overfull \\hbox" not in log and "Overfull \\vbox" not in log and not re.search(r"Float too large|Too many unprocessed floats", log) and "There were undefined references" not in log
LIG = {"\ufb00": "ff", "\ufb01": "fi", "\ufb02": "fl", "\ufb03": "ffi", "\ufb04": "ffl"}
def norm(t):
    for x, y in LIG.items(): t = t.replace(x, y)
    return "".join(c for c in unicodedata.normalize("NFKD", t) if not unicodedata.combining(c)).lower()
pdf = f"{R}/out/{N}.pdf"; raw = re.sub(r"A Formal Proof of Hodge Conjecture Termination \| \d+", " ", run(f"pdftotext '{pdf}' -").stdout); flat = re.sub(r"[\W_]+", "", norm(re.sub(r"-\s*\n\s*", "", raw)))
fe = am.index("\n---\n", 4); fm = am[4:fe]; paras = [fm[fm.index("abstract: |") + 11:]] + re.split(r"\n\s*\n", am[fe + 5:]); wins, miss = 0, []
for p in paras:
    p = p.strip()
    if not p or p.startswith(("|", "Table:", "\\begin{jbox}", "\\hypersetup", "\\appendix", "\\color")): continue
    t = re.sub(r"\$\$.*?\$\$|\$[^$]*\$|\\cite\{[^}]*\}|\\\[.*?\\\]|\\[a-zA-Z]+\*?(\[[^\]]*\])?(\{[^{}]*\})?|[{}]", " \u00a6 ", p, flags=re.S)
    for run_ in t.split("\u00a6"):
        ws = re.findall(r"[^\W_]+", norm(run_))
        if len(ws) >= 6:
            for w in {tuple(ws[:6]), tuple(ws[-6:])}:
                wins += 1
                if "".join(w) not in flat: miss.append(w)
unexpl = []
for w in miss:
    ok = any(flat.find("".join(w[kk:]), m.end(), m.end() + 6000) >= 0 for kk in range(1, len(w)) for m in re.finditer(re.escape("".join(w[:kk])), flat))
    if not ok: unexpl.append(" ".join(w))
print(f"preflight clean: {clean} | coverage {wins - len(miss)}/{wins} direct, {len(miss) - len(unexpl)} split by a float, glyph or page break, unexplained {len(unexpl)} {unexpl[:3]}")
pages = int(re.search(r"Pages:\s+(\d+)", run(f"pdfinfo '{pdf}'").stdout).group(1))
for pg in range(1, pages + 1):
    if "colocalizationintheauthorsframework" in re.sub(r"[\W_]+", "", norm(run(f"pdftotext -f {pg} -l {pg} '{pdf}' -").stdout)):
        run(f"pdftoppm -f {pg} -l {pg} -r 100 -png '{pdf}' {R}/out/appxA"); print("Appendix A declaration on page", pg, "of", pages)
tmp = f"{B}/blog_src_v7.md"; open(tmp, "w", encoding="utf-8").write(am.replace("\\mathbb{H}", "ℍ").replace("\\mathbb{R}", "ℝ"))
bl = f"{B}/out/{N}.blog.md"; run(f"python3 /home/claude/paper/latex2blog_hsw2.py {tmp} {bl}.tmp && python3 /home/claude/paper/build_blog.py {bl}.tmp {bl}"); os.remove(f"{bl}.tmp"); x = open(bl, encoding="utf-8").read()
FIX = [("\\overline{\\mathbb{Q}}", "ℚ̄"), ("\\overline{ℚ}", "ℚ̄"), ("\\overlineℚ", "ℚ̄"), ("\\nvdash", "⊬"), ("\\vdash", "⊢"), ("\\models", "⊨"), ("\\iff", "⟺"), ("\\forall", "∀"), ("\\exists", "∃"), ("\\neg", "¬"), ("\\Pi", "Π"), ("\\Psi", "Ψ"), ("\\Xi", "Ξ"), ("\\text{\\O}", "Ø"), ("\\mathcal{F}", "𝓕"), ("\\mathcal{T}", "𝒯"), ("\\Gamma", "Γ"), ("\\omega", "ω"), ("\\cup", "∪"), ("\\longrightarrow", "⟶"), ("\\qquad", "  "), ("\\quad", " "), ("\\mathbb{N}", "ℕ"), ("\\operatorname{pr}", "pr"), ("\\operatorname{cl}", "cl"), ("\\mathrm{HC}", "HC"), ("\\mathrm{dR}", "dR"), ("\\mathrm{pt}", "pt"), ("\\partial", "∂"), ("\\infty", "∞"), ("\\bar", ""), ("\\Omega", "Ω"), ("\\ge", "≥")]
MORE = [("\\mathrmHC", "HC"), ("\\mathrmdR", "dR"), ("\\mathrmpt", "pt"), ("\\mathrmprim", "prim"), ("\\longmapsto", "⟼"), ("\\equiv", "≡"), ("\\pmod", "mod"), ("\\bmod", "mod"), ("\\Bigl", ""), ("\\Bigr", ""), ("\\bigl", ""), ("\\bigr", ""), ("\\Big", ""), ("\\big", ""), ("\\lambda", "λ"), ("\\det", "det"), ("\\cdots", "…"), ("\\cdot", "·"), ("\\times", "×"), ("\\sum", "∑"), ("\\neq", "≠"), ("\\leq", "≤"), ("\\geq", "≥"), ("\\le", "≤"), ("\\color{black}", ""), ("\\overline", ""), ("\\operatorname", ""), ("\\mathrm", ""), ("\\mathbb", ""), ("\\left", ""), ("\\right", ""), ("\\,", " "), ("\\;", " ")]
EXTRA = [("\\text\\O", "Ø"), ("\\textresolve", "resolve"), ("\\textrefute", "refute"), ("\\textabstain", "abstain"), ("\\min", "min"), ("\\nabla", "∇"), ("\\oint", "∮"), ("\\supseteq", "⊇"), ("\\varphi", "φ"), ("\\text", "")]
for u, v in FIX: x = x.replace(u, v)
x = re.sub(r"\\text\{([^{}]*)\}", r"\1", x); x = re.sub(r"\\mathrm\{([^{}]*)\}", r"\1", x); x = re.sub(r"\\operatorname\{([^{}]*)\}", r"\1", x)
for u, v in MORE: x = x.replace(u, v)
x = re.sub(r"\\begin\{(jbox|center)\}|\\end\{(jbox|center)\}", "", x); x = re.sub(r"\\textit\{([^{}]*)\}", r"*\1*", x); x = re.sub(r"\\textbf\{([^{}]*)\}", r"**\1**", x); x = re.sub(r"\\emph\{([^{}]*)\}", r"*\1*", x)
for u, v in EXTRA: x = x.replace(u, v)
HSW = "*Blog edition of the sealed master: audit cycle hsw2 closed at SEALED-ROUND under SELF-grade controls on this text; it renders that master and adds no claim.*"
x = x.replace(HSW, "*Blog edition of the master: audit cycle hterm1 closed at SEALED-ROUND under SELF-grade controls on the sealed text, one aperture open. After the seal, the ungraded originating declaration of Appendix A was restated in academic form at the author's instruction, and no graded claim changed. The edition renders that master and adds no claim.*")
open(bl, "w", encoding="utf-8").write(x); res = re.findall(r"\\[a-zA-Z]{2,}", x)
print("blog: residual LaTeX", len(res), sorted(set(res))[:6], "| header restated:", "restated in academic form" in x, "| declaration present:", "Co-localization." in x and "The witness and the audit engine." in x, "| Fix line:", "Fix(σ)=ℝ=Z(ℍ)" in x.replace(" ", ""))
if clean and not unexpl and not res:
    shutil.copy(pdf, OUT); shutil.copy(f"{R}/out/{N}.tex", OUT); shutil.copy(f"{H}/hterm_v7.md", f"{OUT}/{N}.md"); shutil.copy(bl, OUT)
    note = f"# AMENDMENT after the hterm1 seal\nAt the author's instruction the ungraded originating declaration (Appendix A) was restated in academic form, and one reference was added (Zenodo 20805972, cited there).\nConfinement verified mechanically: every changed line lies inside Appendix A or that reference. Sealed v6 sha {sha(H + '/hterm_v6.md')}; amended v7 sha {sha(H + '/hterm_v7.md')}.\nThe hterm1 seal covers every graded claim, all of which are unchanged in v7; Appendix A remains ungraded and is not asserted by the theorems.\n"
    open(f"{H}/AMENDMENT_hterm1_appendixA.md", "w", encoding="utf-8").write(note)
    zp = f"{OUT}/A_Formal_Proof_of_Hodge_Conjecture_Termination_audit_ledger_hterm1.zip"
    with zipfile.ZipFile(zp, "a", zipfile.ZIP_DEFLATED) as z:
        for f in ("AMENDMENT_hterm1_appendixA.md", "hterm_v7.md", "amend_declaration.py"): z.write(f"{H}/{f}", f"audit_hterm1_bundle/{f}")
    print("STAGED:", {e: sha(f"{OUT}/{N}.{e}") for e in ("pdf", "tex", "md", "blog.md")}, "| ledger bundle files", len(zipfile.ZipFile(zp).namelist()))
else:
    for ext in ("pdf", "tex", "md", "blog.md"): shutil.copy(f"{H}/outputs_backup_pre_v7/{N}.{ext}", OUT)
    print("NOT STAGED: previous verified deliverables restored")
