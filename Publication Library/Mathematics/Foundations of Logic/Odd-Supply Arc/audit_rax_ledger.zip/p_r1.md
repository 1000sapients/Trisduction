ROUND 1 PROSECUTION · registers kinematic, definitional · copy read: seeded_r1.md (the sweep bundle, seven artifacts)

P1-a (artifact 1, Navier-Stokes): "thirty-six theorems" against the kernel's thirty-five. Minimal falsifier: count the kernel.
P1-b (artifact 5, Poincare): a denial "is a record that instances it"; denial_reenacts_root takes the denial as an act of the self-grounding type. Drift. Minimal falsifier: read the theorem's statement.
P1-c (artifact 4, Goldbach): the root "decides the value by itself"; undeniable_root_forces_no_value proves it forces none. Widened. Minimal falsifier: read the theorem.

Kinematic re-execution: the four new theorems compile on no axiom in all six kernels, on Lean 4.19.0 and 4.22.0, exit 0 and no message; the printed counts match: 35, 44, 46, 62 with 57 free and the five propext theorems unchanged, 45, 56; every manifest round-trips and every SHA-256 in Appendix A matches its kernel; every new \thm name resolves in its kernel.

F-1 (definitional, the new existence paragraph and the new grade line in all six papers, target C2, STRUCTURAL): "It holds on every frame without condition" and "it holds on every frame without condition". undeniable_root_forces_no_value takes a self-grounding root and one act of it; the root holds once any act occurs, which is a condition, met by every examination but stated. The mini paper's "Holding in every world" carries the same reading. Minimal falsifier: read the theorem's hypotheses.
