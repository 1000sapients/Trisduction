ROUND 3 PROSECUTION · registers limit, symmetry · copy read: seeded_r3.md · declared targets: none outstanding; full re-sweep of the seven artifacts

P3-a (artifact 5, Poincare): "forty-four theorems" against the kernel's forty-five. Minimal falsifier: count.
P3-b (artifact 6, BSD): the act at "the grade of the record itself"; the root's grade is the grade of existence. Drift. Minimal falsifier: read the new paragraph's own clause.
P3-c (artifact 1, Navier-Stokes): the act supplied "unconditionally"; act_is_keyed shows it fails in the counter world. Widened. Minimal falsifier: read the theorem.

Limit: the root holds in both worlds and forces no value; the act holds in the calm world and fails in the counter world; no sentence in any artifact lets the root decide a value (scanned). Symmetry: every verdict changes only in its existence clause and its grade word; each act sentence otherwise word for word; the reflexive table of each paper gains one row and keeps its others. Mechanical: all seven PDFs build with no overfull box and no missing glyph. No real finding.
