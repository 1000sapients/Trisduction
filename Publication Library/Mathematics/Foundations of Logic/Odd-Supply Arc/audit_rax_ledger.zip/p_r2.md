ROUND 2 PROSECUTION · registers parameter, provenance · copy read: seeded_r2.md · declared target: the round-1 repair F-1 in all seven artifacts

P2-a (artifact 6, BSD): "(57 theorems)" against the kernel's 56. Minimal falsifier: count.
P2-b (artifact 3, Yang-Mills): the root read on the row "is the record"; it is the act, root_read_on_row_is_keyed. Drift. Minimal falsifier: read the theorem.
P2-c (artifact 5, Poincare): "so every row's value follows from it"; the root decides no value by itself. Widened. Minimal falsifier: read undeniable_root_forces_no_value.

F-1 read in place in all seven: the root holds once any act occurs; every examination of it is one. Consistent with the theorem's hypotheses.
Provenance: each new sentence cites only the four new theorems, each for exactly its statement; the mini paper's rest_family is cited from the earlier volume and denial_reenacts_root and root_read_on_row_is_keyed from the six kernels. The Yang-Mills matter premise keeps its premise grade, untouched by the sweep. Parameter census: the six theorem counts updated by four each, the Goldbach free count from 53 to 57, the five propext theorems unchanged. No finding.

H-1 (provenance, target C4): if the root is undeniable, the act should be called unconditional. Minimal falsifier: does the act hold in the counter world?
