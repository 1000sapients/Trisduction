ROUND 3 PROSECUTION · registers limit, symmetry · copy read: seeded_r3.md · declared target: the round-2 repair F-4

P3-a (Section 3): glueballs "near 2.7 GeV"; the cited lattice value is near 1.7 GeV. Minimal falsifier: read Morningstar and Peardon 1999.
P3-b (Section 4): the formal crossing "by Hamilton's offering"; the dated offering is Perelman's, 2002. Drift. Minimal falsifier: read row 7.
P3-c (Section 6): the formal channel "blocked by theorem on every row, Poincaré included"; Poincaré is crossed on it at full grade. Widened. Minimal falsifier: read row 7.

F-4 repair read in place: no sentence now claims the seven kernels on no axiom beyond what each paper reports. Limit: the kinetic channel holds on the actuated class only; the formal channel is blocked on every open row; Poincaré crossed formally; BSD crossed at orders 0-1. Symmetry: the two channels never contradict; the latest paper governs where it retypes a row; P versus NP's supersession of the dot is stated in the table and the text. No real finding.
