ROUND 4 PROSECUTION · registers definitional, kinematic · copy read: seeded_r4.md · declared targets: none outstanding; full re-sweep

P4-a (Section 5): F-World lists "two massless hadrons"; one refutes. Minimal falsifier: read the earlier ledger's falsifiers.
P4-b (Section 4): the traditional-route question answered by "the kinetic channel's answer"; it is the formal channel's. Drift. Minimal falsifier: read the paragraph's own next clause.
P4-c (Section 1): "every bit is a theorem of the register"; the hypothesis bit is hypothesis grade and the resolution bit is supplied by deed. Widened. Minimal falsifier: read Hypothesis 11.1 as quoted.

Kinematic: Table 1 has 25 entries, rows 1 to 23 with 3a, 3b, 23a and 23b, matching the earlier ledger's numbering; the PDF builds with no overfull box at the full width; every DOI in the table appears in the references. Definitional: every status word is one of crossed, blocked by theorem, or the remainder as the earlier ledger states it. No real finding.

H-1 (definitional, target C3): "nothing on the closure" on the open rows hides what the earlier ledger called owed. Minimal falsifier: does the ledger say nothing remains on the traditional route?
