ROUND 2 PROSECUTION · registers parameter, provenance · copy read: seeded_r2.md · declared targets: the round-1 repairs F-1, F-2, F-3 with every consumer

P2-a (Section 2): the recompilation "on Lean 4.19.0 and 4.21.0"; the receipts are 4.19.0 and 4.22.0. Minimal falsifier: read the receipts.
P2-b (Section 4): the root "derived once for every row"; the earlier ledger posits it (rest_family). Drift. Minimal falsifier: read the cited theorem's statement.
P2-c (Section 3): theorem grade claimed on Yang-Mills and pair correlation; Table 1 grades them observed and computed, and measured. Widened. Minimal falsifier: read Table 1.

F-4 (kinematic, Results and Discussion, target C1, STRUCTURAL): two consumers of the round-1 F-3 repair unreached. Results: "Every paper proves, in a kernel on no axiom"; Discussion: "checkable kernels on no axiom". The Goldbach kernel is not among the seven, but the seven include the Riemann and P versus NP kernels, whose cones were not re-probed here. Minimal falsifier: print their cones in this programme.

Provenance, each source against the cell it carries: the earlier ledger's Tables 1 and 2 for every row with no closure paper, its numbering, splits and tails; the seven closure papers and the Goldbach paper by DOI; Lee and Yang 1952; Morningstar and Peardon 1999; Friedan 1980; Odlyzko 1987; Aaronson 2005. Parameter census: none. Every other cell consistent.
