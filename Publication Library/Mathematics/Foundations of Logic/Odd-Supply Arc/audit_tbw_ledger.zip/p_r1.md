ROUND 1 PROSECUTION · registers kinematic, definitional · copy read: seeded_r1.md

P1-a (Section 5): F-World lists "two zeros off the line"; one zero refutes, as the earlier ledger's falsifiers say. Minimal falsifier: read the cited ledger.
P1-b (Section 1): the block stated with "an even target"; the block bars odd targets. Drift. Minimal falsifier: read Theorem 4.1 as quoted.
P1-c (Section 3): theorem grade claimed on "Navier-Stokes and Yang-Mills matter"; the Yang-Mills matter face is a record plus a premise, as Table 1 grades it. Widened. Minimal falsifier: read the Yang-Mills row.

F-1 (definitional, Table 1 caption, target C1, STRUCTURAL): "The block and hypothesis bits are complete on every row." The earlier ledger types rows 12, 17, 19 and 20 with a local seat only, no global seat exhibited; a located hypothesis bit at a global seat is not on record there. Minimal falsifier: read rows 12, 17, 19, 20 of the earlier Table 2.

F-2 (provenance, the disclosure, target C5, STRUCTURAL): "Each reported paper carries its own self-audit record at SELF grade." Self-audit cycles are on record in this programme for six of the papers; for the Riemann and P versus NP papers no cycle record was re-checked. Minimal falsifier: produce the two records.

F-3 (kinematic, Method and the abstract, target C1, STRUCTURAL): the Method sentence says every kernel compiled on Lean 4.19.0 and 4.22.0 with closing theorems printing no axiom; the Goldbach kernel carries five theorems on propext, two of them its statement's equivalence, and the toolchain receipts of the Riemann and P versus NP kernels were not re-run here. The abstract repeats the no-axiom clause for all seven. Minimal falsifier: print the Goldbach cones.
