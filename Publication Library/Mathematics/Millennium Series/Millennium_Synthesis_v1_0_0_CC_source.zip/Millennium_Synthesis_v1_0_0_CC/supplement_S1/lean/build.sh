#!/bin/bash
# Rebuild the hunt: each original compiled in its own environment, then the hunt kernel against them.
# Needs Lean 4.19.0 and a Lake project with Mathlib v4.19.0 (set MATHLIB_PROJECT to its directory).
set -e
HERE=$(cd "$(dirname "$0")" && pwd); OUT=$HERE/build; mkdir -p $OUT/Hunt
for m in PNPNF NS YM Hodge BSD PC; do lean -R $HERE -o $OUT/Hunt/$m.olean $HERE/Hunt/$m.lean; done
cd "${MATHLIB_PROJECT:?set MATHLIB_PROJECT to a Lake project carrying Mathlib v4.19.0}"
for m in RH PCBind NSBind BSDBind Perelmanification; do
  lake env bash -c "LEAN_PATH=$OUT:\$LEAN_PATH lean -R $HERE -o $OUT/Hunt/$m.olean $HERE/Hunt/$m.lean"
done
echo "hunt rebuilt: every pin passed (a failing #guard_msgs stops the build)"
