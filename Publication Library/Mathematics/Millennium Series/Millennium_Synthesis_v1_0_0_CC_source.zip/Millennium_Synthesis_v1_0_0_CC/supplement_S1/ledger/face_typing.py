#!/usr/bin/env python3
"""Per-face typing of the unified 1-bit posit (target face-split by row) on the universal-cascade engine.
Readings are hand-built at premise grade under the Honest Limits rule; the engine adjudicates and authors nothing.
Each reading follows the register's recorded calibration where one exists (RH, P vs NP, BSD, YM, Poincare) and is
built fresh for Navier-Stokes and Hodge, which the calibration ledger does not carry."""
import json, numpy as np, hashlib
import universal_cascade as uc
I2 = np.eye(2); REFL = np.array([[-1.,0.],[0.,1.]]); NEG = -np.eye(2)
faces = {}
def emit(name, rec): faces[name] = rec; print(f"{name:9} {rec['token']:12} gate={rec['gate']:<22} gclass={rec['gclass']:<5} flank={rec['flank']} content={rec['content']:<12} opens={rec['opens']}  | {rec['note']}")

# RH: native involution s -> 1 - conj(s) (functional equation), fixed line Re s = 1/2; Pi-0-1 (negation finitely witnessable)
c = uc.canonicity([dict(name="FE reflection s->1-conj s", M=REFL, definable=True, category="content")])
av = uc.availability((1,0), "orientation")
v = uc.eight(dict(gd=True, noind=True, blind=True, closed=av["Xi0"], roads=True, exhibit=True, faces=1, ap=True, rev=True, cap="premise"))
emit("RH", dict(token=v[0], gate=v[1], gclass=c["gclass"], flank=(1,0), content="orientation", opens=False,
     note="Xi0 available (catalog CLOSED, orientation); O0 barred off the (0,0) cell; constitutive block: the hunt does not open"))
# P vs NP: complementation fixed-point-free on content (no language equals its complement): Ground 0; Pi-0-2 vs Sigma-0-2: flank (0,0)
c = uc.canonicity([dict(name="complementation L->co-L (set map)", M=NEG, definable=True, category="content"),
                   dict(name="permutation-matrix linearization", M=np.array([[0.,1.],[1.,0.]]), definable=True, category="representation")])
walls = [dict(name="relativization (Baker-Gill-Solovay 1975), oracles A,B", scope="instance"),
         dict(name="natural proofs (Razborov-Rudich 1997), given PRFs", scope="instance"),
         dict(name="algebrization (Aaronson-Wigderson 2009)", scope="instance"),
         dict(name="kernel walls: keyless/record/SAT-uniform premises force nothing (P!=NP master, pinned)", scope="instance", bridge=True),
         dict(name="'barriers in general' (class-level heuristic)", scope="class")]
w = uc.bar(walls)
av = uc.availability((0,0), "construction")
v = uc.five(dict(gdim=0, resid=0.0, det=True, stripped=True, walls=len(w), typed=True, ap=True, faces=1, rel=True, rev=True, cap="premise"))
emit("PNP", dict(token=v[0], gate=v[1], gclass=c["gclass"], flank=(0,0), content="construction", opens=False,
     note=f"{len(w)} instance walls survive the bar (class wall stripped); refused census rows: {[r[0] for r in c['refused']]}; constitutive block: the hunt does not open"))
# Poincare: the seat, Perelman's offering, independent expositions, no open audit
s = uc.seat([dict(name="Perelman 2002-03", witness="arXiv math/0211159v1, math/0303109v1, math/0307245v1",
                  independent=True, artifact_hash="arXiv:math/0211159v1+0303109v1+0307245v1")], [])
emit("PC", dict(token="[seal]", gate="seat "+s[1][0][1], gclass="g?", flank=(0,0), content="construction", opens=False,
     note="sealed on the supplied witness, verifiers independent (Cao-Zhu 2006, Morgan-Tian 2007, Kleiner-Lott 2008), registry closed; positive mass Perelman's, the engine's zero; nothing to supply"))
# BSD: L-function reflection s->2-s, fixed line Re s = 1 (Ground 1); composite rank = order face-split by direction
c = uc.canonicity([dict(name="FE reflection s->2-conj s", M=REFL, definable=True, category="content")])
for fname, content, flank in (("BSD-ge", "construction", (0,0)), ("BSD-le", "magnitude", (0,0))):
    av = uc.availability(flank, content)
    v = uc.eight(dict(gd=True, noind=True, blind=False, closed=av["Xi0"], roads=True, exhibit=True, faces=1, ap=True, rev=True))
    emit(fname, dict(token=v[0], gate=v[1], gclass=c["gclass"], flank=flank, content=content, opens=(content in ("construction","exhibition")),
         note=("order r gives r independent rational points: exhibition of points, supply-shaped" if fname=="BSD-ge" else
               "rank bounded by the order: a count bound, magnitude row EMPTY (Magnitude Exclusion): not supply-shaped")))
# Yang-Mills: composite split (uniformity clause: the centre of SU(N) is an involution at N=2 only); faces A existence, B gap
c = uc.canonicity([dict(name="centre element -1 of SU(N) (N=2 only)", M=REFL, definable=True, category="content")])
for fname in ("YM-A", "YM-B"):
    av = uc.availability((0,0), "construction")
    v = uc.eight(dict(gd=True, noind=True, blind=False, closed=av["Xi0"], roads=True, exhibit=True, faces=1, ap=True, rev=True))
    emit(fname, dict(token=v[0], gate=v[1], gclass="SPLIT", flank=(0,0), content="construction", opens=True,
         note=("existence of the continuum theory on R^4 (OS/Wightman): construction" if fname=="YM-A" else "a positive gap for that theory: construction of the spectral floor")))
# Navier-Stokes: parity u(x)->-u(-x) native (definable from the equations), fixed set the odd fields; regularity is existence of a global smooth solution
c = uc.canonicity([dict(name="parity u(x)->-u(-x)", M=REFL, definable=True, category="content"),
                   dict(name="time reversal (broken by viscosity)", M=REFL, definable=False, category="content")])
av = uc.availability((0,0), "construction")
v = uc.eight(dict(gd=True, noind=True, blind=False, closed=av["Xi0"], roads=True, exhibit=True, faces=1, ap=True, rev=True))
emit("NS", dict(token=v[0], gate=v[1], gclass=c["gclass"], flank=(0,0), content="construction", opens=True,
     note="Fefferman (A): existence of a global smooth solution, construction; time reversal refused at canonicity (not definable: viscosity)"))
# Hodge: complex conjugation H^{p,q}->H^{q,p}; the (p,p) classes are self-conjugate (Ground 1); the content is existence of algebraic cycles
c = uc.canonicity([dict(name="complex conjugation on H^k(X,C)", M=REFL, definable=True, category="content")])
av = uc.availability((0,0), "construction")
v = uc.eight(dict(gd=True, noind=True, blind=False, closed=av["Xi0"], roads=True, exhibit=True, faces=1, ap=True, rev=True))
emit("Hodge", dict(token=v[0], gate=v[1], gclass=c["gclass"], flank=(0,0), content="construction", opens=True,
     note="every rational (p,p) class carries an algebraic cycle: exhibition of cycles, supply-shaped"))
dig = hashlib.sha256(json.dumps(faces, sort_keys=True, default=str).encode()).hexdigest()[:12]
json.dump(faces, open("face_typing.json","w"), indent=1, default=str)
print("typing digest", dig, "| faces opening the hunt:", [k for k,r in faces.items() if r["opens"]])
