import json, axiom_generator as ag
R = {
 "UNI":        dict(wellformed=True, refuted_by_base=False, equiv_to_target=True,  coupling_proof=True,  in_literature=False, breadth=0, grammar="qualitative_per_solution"),
 "SEVEN":      dict(wellformed=True, refuted_by_base=False, equiv_to_target=True,  coupling_proof=True,  in_literature=False, breadth=0, grammar="qualitative_per_solution"),
 "NS-EBA":     dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=True,  in_literature=False, breadth=2, grammar="data_uniform_effective"),
 "HODGE-EFF":  dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=True,  in_literature=False, breadth=1, grammar="data_uniform_effective"),
 "BSD-EFF":    dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=True,  in_literature=False, breadth=1, grammar="data_uniform_effective"),
 "YM-EFF":     dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=False, in_literature=False, breadth=1, grammar="offstring"),
 "LANDAUER":   dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=False, in_literature=True,  breadth=0, grammar="offstring"),
 "REFL":       dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=False, in_literature=True,  breadth=0, grammar=""),
 "OMEGA":      dict(wellformed=False),
 "PERELMAN-T": dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=False, in_literature=False, breadth=0, grammar=""),
}
out = {}
for k, r in R.items():
    st, gate = ag.axf(r); out[k] = (st, gate); print(f"{k:11} {st:20} {gate}")
an = ag.anchor(dict(shape_sealed=False, ground_dim=1))
print("ANCHOR on the open faces (shape face not sealed):", an)
json.dump(out, open("screen_r1.json", "w"), indent=1)
