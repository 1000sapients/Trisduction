# Round 1 grind · registers: grind, circularity

Target, atomised. One proposed principle P is claimed to yield, on each row, that row's sentence, and to qualify as a
standard axiom. The open faces are five sentences: NS (Fefferman's statement A), YM-A (existence of the four-dimensional
quantum gauge theory), YM-B (its positive mass gap), Hodge (rational (p,p) classes are algebraic on smooth projective
varieties), BSD-ge (analytic order r gives r independent rational points). Each face is ATOMIC after the split; the
composite rank equality was split into BSD-ge and BSD-le, and BSD-le is a count bound with no supply shape.

Carrier, atomised. Four legs per row, each machine-checked in that row's master and cited by declaration name: the
record of every frame carries the value with no premise (L1); the value of a frame is equivalent to the transfer from its
record (L2); a premise holding on every frame forces the value on none (L3, wall); at the library's own statement the
transfer is equivalent to the face sentence where a binding exists (L4: NS, BSD; also Poincare and RH, closed faces).

Findings.
F-1 (grind, LOAD-BEARING, on candidate UNI). Name-strip to the bottom: "the record's value transfers to the host frame"
strips at depth one to "the host frame carries the value" (L2) and at depth two to the face sentence (L4 or the row's
host theorem). The residue is the target. Minimal falsifier: exhibit a face where the transfer at the host is not
equivalent to the face sentence; none exists, since L2 and L4 are theorems.
F-2 (circularity, LOAD-BEARING, on candidate SEVEN). The property bundle strips to necessity with sufficiency, which is
equivalence (machine-checked: necessity with sufficiency is exactly adoption of the same theory). Mandatory, no other
proof, future-proof and the two kinds follow from equivalence alone; irreducible is the wall L3, which says no premise
short of the value forces it. Residue: the target. The bundle buys no grade. Minimal falsifier: a premise with all seven
properties not equivalent to its sentence; impossible, since necessity and sufficiency are two of the seven.
F-3 (grind, STRUCTURAL, on UNI and SEVEN). The census of "one principle": on five open faces the principle carries five
transfers, one per face, and the seven values are independent on the product of the rows' frames (machine-checked: every
pattern of values is realized; a premise forcing every value is keyed on every row). One name, five posits.
F-4 (grind, STRUCTURAL, on PERELMAN-T). The template carries one flow posit per open face, four distinct objects; on the
open faces no row master defines a faithful flow or proves that its rest yields the sentence. The Poincare instance is a
cited theorem and transfers nothing to the other rows (machine-checked: the Poincare value settles no other row's value).
F-5 (grind, STRUCTURAL, on LANDAUER). Quantifies over physical registrations at positive temperature, not over solutions of
the rows' equations; the bridge from carrier to object is untyped and is itself the open claim. Off-string.
F-6 (grind, COSMETIC, on OMEGA). An infinitary rule, not a sentence of the base language; and no open face is a
universal over finitely checkable instances.
F-7 (coupling preview, STRUCTURAL, on YM-EFF). Two posits: the uniform lattice gap and the convergence of the lattice
spectrum to a continuum spectrum with the gap preserved; the second is the existence face itself in part. Composite.

Effectivized children (step 4). UNI is refused circular and is effectivized face by face, each child naming what it adds:
NS-EBA adds an explicit modulus F(||u0||, nu, t) bounding the gradient supremum; HODGE-EFF adds an explicit degree bound
B(N, d, p) on representing cycles; BSD-EFF adds an explicit height bound H(N_E, r) on the r points; YM-EFF adds an
explicit uniform gap m(g, N) and is composite (F-7).

Controls in the candidate set, caught. Slot 3: "the cycle-realization principle" (every rational (p,p) class is realized
by a rational algebraic cycle), the Hodge conjecture under a new name, literature-owned (RENAME). Slot 7: "every Galerkin
truncation of the system on the torus is globally smooth with the energy inequality, hence the continuum flow is
regular", true of the truncations and transferring nothing without uniformity in the truncation (OFFSTRING). Slot 8: "an
explicit F(data) with sup|grad u| <= F on the maximal interval, F(data) defined finite exactly when the interval is
infinite", the target in data-uniform costume (COSTUME).
