import json, axiom_generator as ag
R = {
 "NS-EBA":     dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=True,  in_literature=True,  breadth=2, grammar="data_uniform_effective"),
 "HODGE-EFF":  dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=True,  in_literature=True,  breadth=1, grammar="data_uniform_effective"),
 "BSD-EFF":    dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=True,  in_literature=True,  breadth=1, grammar="data_uniform_effective"),
 "YM-EFF":     dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=False, in_literature=False, breadth=1, grammar="offstring"),
 "NS-CASCADE": dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=True,  in_literature=False, breadth=2, grammar="data_uniform_effective"),
 "YM-CLUSTER": dict(wellformed=True, refuted_by_base=False, equiv_to_target=True,  coupling_proof=True,  in_literature=True,  breadth=0, grammar="qualitative_per_solution"),
 "HODGE-ABS":  dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=False, in_literature=True,  breadth=0, grammar=""),
 "BSD-HIGHER": dict(wellformed=True, refuted_by_base=False, equiv_to_target=False, coupling_proof=True,  in_literature=False, breadth=1, grammar="data_uniform_effective"),
 "UNI-ROAD":   dict(wellformed=True, refuted_by_base=False, equiv_to_target=True,  coupling_proof=True,  in_literature=False, breadth=0, grammar="qualitative_per_solution"),
}
out={k: ag.axf(r) for k,r in R.items()}
for k,v in out.items(): print(f"{k:11} {v[0]:20} {v[1]}")
print("M-cascade on the unified equivalence as an object:", ag.m_close(dict(object_level=True, name_survives=True, literature_clear=False, not_two_line=False)))
json.dump(out, open("screen_r2.json","w"), indent=1)
