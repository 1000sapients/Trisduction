# Round 3 grind · registers: derivation, literature

Errata. ERR-1 (round 2, the orchestrating seat): the named targets NS-EBA, HODGE-EFF, BSD-EFF and YM-EFF were
re-disposed under their round-1 ids instead of being re-raised under new ids carrying their lineage; the ledger copied
their round-1 screen state into round 2, so three gate-passing rows stood without a round-2 search and the round closed
at CONTINUE-LIT. Repair: each is re-raised here under a new id with its lineage, and searched in this round.

Derivation. Every gate-passing chain is written as a specification with its seed as one axiom, its classical inputs by
citation, and its target (One_Bit_Hunt_Chain_Specifications_v1_0_0_CC.lean): NS-EBA (seed, Beale-Kato-Majda, local
well-posedness), NS-CASCADE (seed, envelope-to-critical-norm, Beale-Kato-Majda, local well-posedness), HODGE-EFF (seed
alone), BSD-EFF (seed, Neron-Tate positivity), BSD-HIGHER (seed, order r, nonzero regulator). The census prints exactly
one seed in each chain beside its inputs and its target. The unified posit's census is pinned in the hunt kernel: a
premise forcing all seven rows is keyed on all seven, the seven values are independent, so one name carries one posit
per row. Necessity test: no chain's seed is forced by its legs; every seed stays free once its bridge is granted.

Literature. Two fresh queries per gate-passing chain, the statement and the route, printed verbatim in the search table.
Each classifies owned or adjacent: the gradient modulus and the frequency envelope sit in the quantitative-regularity
program and the dissipation-wavenumber criterion; the degree bound sits beside the algebraicity of Hodge loci; the
height bound is Lang's conjecture with Hindry's estimates; the higher derivative formula sits on the function-field
seat (Yun-Zhang) and in the Stark-Heegner program.

Exhaustion. The live pool admits no untried one-posit reassembly: on NS, Hodge and BSD-ge every coupled one-posit child
is owned; on YM-A and YM-B every reassembly is circular (exponential clustering is the gap) or carries two posits (a
uniform lattice gap with spectral convergence; ultraviolet stability with infrared clustering); the unified posit is
circular and carries five posits on the open faces.

Controls in the candidate set, caught. COSTUME: "a gradient modulus F(data) set equal to the supremum over the solution's
own maximal interval", the target in dress. OFFSTRING: "every hyperdissipative regularization is globally smooth, hence
the equation is", true of the regularization and silent on the equation. RENAME: "the dissipation-range principle", the
published Kolmogorov-wavenumber regularity criterion renamed.
