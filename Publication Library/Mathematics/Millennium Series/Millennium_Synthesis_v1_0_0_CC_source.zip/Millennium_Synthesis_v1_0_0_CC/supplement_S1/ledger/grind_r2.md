# Round 2 grind · registers: coupling, discriminator

Named targets from round 1, ground again. NS-EBA: coupling written (gradient bound, then the vorticity continuation
criterion L8); discriminator PASSES (on the averaged equation, a cousin with finite-time blowup, the bound fails, so the
ground is not constant across the cousin); literature status already owned, so the screen now reads A4 and the child
stands conditional. HODGE-EFF: coupling trivial (the bound implies the face); discriminator PASSES (integral classes and
non-projective Kahler manifolds, where the answer differs, violate it); A4 conditional. BSD-EFF: coupling trivial;
discriminator SILENT; A4 conditional. YM-EFF: still two posits; the second, spectral convergence with the gap kept, is
not supplied by any cited leg; inert.

New candidates. NS-CASCADE adds an explicit frequency-envelope bound; coupling through a bounded critical norm and L8;
discriminator PASSES on the averaged equation and on the dyadic model, both of which cascade to infinite frequency in
finite time. YM-CLUSTER asserts exponential clustering of gauge-invariant correlations; by the cluster theorem a mass gap
gives exponential clustering and, for a Wightman theory, exponential clustering gives the gap back, so the candidate is
the face at surface depth: circular. HODGE-ABS carries two posits (Hodge implies absolute Hodge; absolute Hodge implies
algebraic); the first is a theorem only on abelian varieties (Deligne 1982); inert as one chain. BSD-HIGHER asserts a
higher derivative formula with explicit points; coupling: a nonzero regulator makes the r points independent, so the face
follows; one posit; discriminator SILENT, the function-field cousin agreeing. UNI-ROAD re-raises the unified
equivalence as an object to test the road disposition: depth two, both directions written (the normal forms and the
library readings), but each row's equivalence is already deposited by the claimant row by row and the bundle is their
conjunction, a two-line step; not literature-clear, so not a road.

Findings. F-8 (coupling, STRUCTURAL, YM-EFF): the continuum gap needs spectral convergence beyond the uniform lattice
bound; second posit confirmed. F-9 (discriminator, STRUCTURAL, NS-CASCADE): passes; the candidate is the cascade
picture stated as an a priori bound, and its route (a bounded dissipation wavenumber gives regularity) is in the
literature. F-10 (circularity, LOAD-BEARING, YM-CLUSTER): equivalent to the gap face by the cluster theorem.
F-11 (coupling, STRUCTURAL, HODGE-ABS): two posits under one name.

Controls in the candidate set, caught. COSTUME: "a cascade bound K(data) defined as the largest dyadic index the solution
reaches before its maximal time", the target in data-uniform dress. OFFSTRING: "the lattice theory at every fixed spacing
has a positive transfer-matrix gap, hence the continuum theory has one", true at fixed spacing and transferring nothing
without uniformity. RENAME: "the Heegner-height principle, the central derivative is a nonzero multiple of the height of
a Heegner point", the Gross-Zagier formula renamed.
