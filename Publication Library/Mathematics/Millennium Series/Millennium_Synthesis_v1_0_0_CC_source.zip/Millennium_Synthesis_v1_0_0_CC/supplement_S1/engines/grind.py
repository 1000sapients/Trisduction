#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""grind.py v1 | the mechanical half of the GRIND step of the AXIOM CYCLE.

Takes one candidate axiom as structured JSON and atomises it: quantifiers, bounding function,
posits, bridges, cousin readings. Prints the atom table, the tier read by grammar, the posit
count for the One-Go census, and the discriminator verdict. It reads what it is given and
authors nothing; the readings inside the JSON are the caller's and are typed premise.

JSON fields:
  statement            the candidate in the base language, framework-free
  quantifiers          list of {"var": "a", "range": "a<a0 on the AF trajectory", "uniform": true}
  bounding_function    "explicit"|"none"  (an explicit named function of the data -> data-uniform)
  conditioned_on_target_failure  true if the antecedent is the target's own breakdown  -> circular
  per_solution_finiteness        true if it asserts finiteness the target itself proves -> circular
  regularized_dynamics           true if it quantifies over a cutoff/regularized dynamics  -> off-string
  posits               list of {"id": "p1", "text": "..."}   (each unproved premise the chain consumes)
  bridges              list of {"id": "b1", "from": "...", "to": "...", "typed": true}
  cousins              {"U(1)": "differs"|"same"|"silent", ...}   (does the candidate's ground vary across cousins)
  cited_legs           list of {"id": "L1", "grade": "theorem", "cite": "..."}
Usage: grind.py --json candidate.json
Exit 0 always; the verdict is in the printed table.
"""
import argparse, json, sys

def tier(c):
    if c.get("conditioned_on_target_failure") or c.get("per_solution_finiteness"):
        return "tier1-circular"
    if c.get("regularized_dynamics"):
        return "tier3-offstring-owes-tier2"
    if c.get("bounding_function") == "explicit":
        return "tier2-effective"
    return "unclassified"

def main(argv=None):
    ap = argparse.ArgumentParser(); ap.add_argument("--json", required=True)
    a = ap.parse_args(argv); c = json.load(open(a.json, encoding="utf-8"))
    print("GRIND |", c.get("statement", "")[:110])
    rows = []
    for q in c.get("quantifiers", []):
        rows.append(("quantifier", q["var"], q["range"], "uniform" if q.get("uniform") else "pointwise"))
    rows.append(("bounding", "F", c.get("bounding_function", "none"), "explicit" if c.get("bounding_function") == "explicit" else "absent"))
    for p in c.get("posits", []): rows.append(("posit", p["id"], p["text"], "unpaid"))
    for b in c.get("bridges", []): rows.append(("bridge", b["id"], f"{b['from']} -> {b['to']}", "typed" if b.get("typed") else "UNTYPED"))
    for l in c.get("cited_legs", []): rows.append(("leg", l["id"], l.get("cite", ""), l.get("grade", "?")))
    for name, v in c.get("cousins", {}).items(): rows.append(("cousin", name, v, "load-bearing" if v == "differs" else v))
    w = max(len(r[2]) for r in rows) if rows else 10
    for r in rows: print(f"  {r[0]:<10} {r[1]:<8} {r[2]:<{min(w,70)}} {r[3]}")
    posits = len(c.get("posits", [])); untyped = [b["id"] for b in c.get("bridges", []) if not b.get("typed")]
    cous = c.get("cousins", {}); disc = "PASSES" if any(v == "differs" for v in cous.values()) else ("FAILS" if cous and all(v == "same" for v in cous.values()) else "SILENT")
    uni = all(q.get("uniform") for q in c.get("quantifiers", [])) if c.get("quantifiers") else False
    print(f"  tier read      : {tier(c)}")
    print(f"  one-go census  : posits={posits} {'(one-go)' if posits == 1 else '(REFUSED-MULTI at H8)' if posits > 1 else '(no posit: lemma or restatement)'}")
    print(f"  bridges        : {len(c.get('bridges', []))} typed, untyped={untyped or 'none'}")
    print(f"  uniformity     : {'all quantifiers uniform' if uni else 'a quantifier is pointwise or absent'}")
    print(f"  discriminator  : {disc} over cousins {list(cous)}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
