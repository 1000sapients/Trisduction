#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""axiom_controls.py v1 | planted candidate controls for the AXIOM CYCLE, committed before the grind.

Three planted candidates per round, each wearing a costume the grind must strip:
  COSTUME   a circular candidate (equivalent to the target) dressed in data-uniform grammar
  OFFSTRING a regularized-dynamics candidate dressed as a continuum statement
  RENAME    a literature-owned statement under a new name
Grades: EXTERNAL (architect-authored JSON, --file, witness-independent) or SELF (generated here;
the commitment forecloses post-hoc fitting and not in-context leakage). Usage as seed_controls.py.
"""
import argparse, hashlib, json, os, random, sys
KINDS = [("COSTUME", "a candidate provably equivalent to the target, written with an explicit bounding function so it reads tier two"),
         ("OFFSTRING", "a candidate quantifying over a cutoff or regularized dynamics, written as if it spoke of the continuum object"),
         ("RENAME", "a statement the literature already owns, restated under a new name and vocabulary")]
def cdir(c): d = os.path.join(".", f"axcycle_{c}"); os.makedirs(d, exist_ok=True); return d
def build(rnd, cycle, seed):
    rg = random.Random(f"{cycle}|{rnd}|{seed}"); picks = rg.sample(range(1, 9), k=3)
    return [{"id": f"X{i+1}", "kind": k, "spec": s, "slot": picks[i]} for i, (k, s) in enumerate(KINDS)]
def digest(ctrls, cycle, rnd):
    return hashlib.sha256(json.dumps({"cycle": cycle, "round": rnd, "controls": ctrls}, sort_keys=True).encode()).hexdigest()[:16]
def main(argv=None):
    p = argparse.ArgumentParser(); p.add_argument("cmd", choices=["commit", "reveal"])
    p.add_argument("--round", type=int, required=True); p.add_argument("--cycle", required=True)
    p.add_argument("--seed", default="20260622"); p.add_argument("--grade", choices=["EXTERNAL", "SELF"], default="SELF")
    p.add_argument("--file", default=""); p.add_argument("--caught", default="")
    a = p.parse_args(argv); d = cdir(a.cycle)
    sealed = os.path.join(d, f"controls_r{a.round}.sealed.json"); commit = os.path.join(d, f"controls_r{a.round}.commit.txt")
    if a.cmd == "commit":
        if os.path.exists(commit): print("FAULT: round already committed; commitments are write-once."); return 2
        if a.grade == "EXTERNAL":
            if not a.file: print("FAULT: EXTERNAL requires --file; generated controls may not wear the grade."); return 2
            ctrls = json.load(open(a.file, encoding="utf-8"))
            if len(ctrls) < 3 or not all(all(k in c for k in ("id", "kind", "spec")) for c in ctrls): print("FAULT: need >=3 controls with id, kind, spec."); return 2
        else:
            ctrls = build(a.round, a.cycle, a.seed)
        dg = digest(ctrls, a.cycle, a.round)
        json.dump({"grade": a.grade, "digest": dg, "controls": ctrls}, open(sealed, "w", encoding="utf-8"), indent=1)
        open(commit, "w").write(f"round {a.round} grade {a.grade} digest {dg} controls {len(ctrls)}\n")
        print(f"COMMITTED round {a.round} grade {a.grade} digest {dg} controls {len(ctrls)}")
        if a.grade == "SELF": print("SELF grade: single-substrate aperture open and stamped on any firm candidate this cycle names.")
        return 0
    if not os.path.exists(sealed): print("FAULT: nothing committed for this round."); return 2
    S = json.load(open(sealed, encoding="utf-8")); caught = {x.strip() for x in a.caught.split(",") if x.strip()}
    print(f"REVEAL round {a.round} grade {S['grade']} digest {S['digest']} verified")
    for c in S["controls"]: print(f"  {'CAUGHT ' if c['id'] in caught else 'MISSED '}{c['id']} {c['kind']} slot~{c['slot']}: {c['spec']}")
    print(f"detection {len(caught & {c['id'] for c in S['controls']})}/{len(S['controls'])}"); return 0
if __name__ == "__main__":
    sys.exit(main())
