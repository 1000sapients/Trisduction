#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""axiom_ledger.py v1 | append-only ledger and verdict evaluator for the AXIOM CYCLE.

One cycle = one target, its faces, one carrier, a pre-registered falsifier per face, and a
growing pool of ATOMS (claims, legs, clauses, posits, bridges, walls, cousins) from which
CANDIDATE axioms are reassembled round by round. Nothing is ever rewritten; closed rounds are
immutable; the verdict is computed here and never declared in prose.

Files live under ./axcycle_<cycle>/ : cycle.json, atoms.jsonl, candidates.jsonl,
findings.jsonl, searches.jsonl, rounds.jsonl.

Usage:
  axiom_ledger.py init      --cycle N --target "..." --faces "A,B" --carrier "..."
  axiom_ledger.py falsifier --cycle N --face A --text "..."
  axiom_ledger.py atom      --cycle N --round R --aid a1 --kind claim|leg|clause|posit|bridge|wall|cousin
                            --grade TIER --text "..." [--cite "..."] [--sign signed|unsigned]
  axiom_ledger.py candidate --cycle N --round R --cid c1 --statement "..." --atoms "a1,a2"
                            --grammar G --state S --gate G --D 0-4 --posits k [--price P] [--height H] [--breadth B]
                            [--effectivizes PARENT --added "the bounding function or rate the effective form adds"]
  axiom_ledger.py search    --cycle N --round R --sid s1 --cid c1 --query "..." --hits K
                            --classification owned|adjacent|clear
  axiom_ledger.py finding   --cycle N --round R --fid F-1 --target a1|c1 --register REG --severity SEV
                            --mechanism "..." --disposition D [--repaired] [--repeat-of F-0] [--falsifier "..."]
  axiom_ledger.py dispose   --cycle N --round R --cid c1 --disposition CD [--repeat-of c0] [--note "..."]
                            ROAD additionally: --depth k>=2 --far-carrier "..." --equiv-artifact path  (search this round must be clear)
  axiom_ledger.py leakscan  --file prosecution.md
  axiom_ledger.py close     --cycle N --round R --registers "grind,coupling" --controls-caught 3
                            [--controls-total 3] [--grade SELF|EXTERNAL] [--leak] [--new-theorem-atom] [--exhausted]
  axiom_ledger.py status    --cycle N
"""
import argparse, json, os, re, sys

TIERS = ["theorem", "theorem-conditional", "structural", "engineering", "corroboration", "premise", "operational"]
KINDS = ["claim", "leg", "clause", "posit", "bridge", "wall", "cousin"]
F_DISP = ["EARNED", "SCOPED", "REFUSED-STRUCTURAL", "REFUSED-MASSLESS", "APERTURE"]
C_DISP = ["REFUSED-CIRCULAR", "REFUSED-INERT", "REFUSED-OFFSTRING", "REFUSED-DISCRIMINATED",
          "REFUSED-OWNED", "CONDITIONAL", "FIRM", "APERTURE", "ROAD"]
SEVERITIES = ["FATAL", "LOAD-BEARING", "STRUCTURAL", "COSMETIC"]
REG_CANON = ["grind", "coupling", "circularity", "discriminator", "derivation", "literature"]
GATE_PASS = {"mass-candidate", "anchor-candidate"}          # axf / anchor states that clear the screen
FLOOR_ROUNDS = 3
CAP_ROUNDS = 8
LEAK_WORD = ["Trisduction", "MathDuction", "GOLf", "GOLn", "W_social", "barzakh"]
LEAK_SUB = ["RA-RAM", "APEX-PSP", "MD-PSP", "CN-PSP", "sPSP-", "Mosaic Seal", "Titanium Ruler", "Empty Throne",
            "chiral residence", "Impressed Plenum", "Seal L", "Seal G", "Seal M", "Fix(\u03c3)", "\u039e\u2080",
            "\u00d8\u2080", "\u27c0"]

def cdir(c):
    d = os.path.join(".", f"axcycle_{c}"); os.makedirs(d, exist_ok=True); return d
def paths(c):
    d = cdir(c); return {k: os.path.join(d, f) for k, f in
        [("cycle","cycle.json"),("atoms","atoms.jsonl"),("cands","candidates.jsonl"),
         ("finds","findings.jsonl"),("search","searches.jsonl"),("rounds","rounds.jsonl")]}
def load(p):
    if not os.path.exists(p): return []
    return [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]
def append(p, rec):
    with open(p, "a", encoding="utf-8") as f: f.write(json.dumps(rec, ensure_ascii=False) + "\n")
def cyc(c):
    P = paths(c)
    if not os.path.exists(P["cycle"]): print("FAULT: cycle not initialised."); sys.exit(2)
    return json.load(open(P["cycle"], encoding="utf-8")), P
def closed(rounds): return {r["round"] for r in rounds}
def guard_open(P, rnd):
    if rnd in closed(load(P["rounds"])):
        print(f"FAULT: round {rnd} is closed and immutable; write into the open round."); sys.exit(2)

# ---------------- commands ----------------
def cmd_init(a):
    P = paths(a.cycle)
    if os.path.exists(P["cycle"]): print("FAULT: cycle exists; ledgers are append-only, open a new cycle."); return 2
    faces = [f.strip() for f in a.faces.split(",") if f.strip()]
    json.dump({"cycle": a.cycle, "target": a.target, "faces": faces, "carrier": a.carrier,
               "falsifiers": {}}, open(P["cycle"], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"CYCLE {a.cycle} opened. target={a.target!r} faces={faces} carrier={a.carrier!r}")
    print("Register one falsifier per face; round 1 will not close without them."); return 0

def cmd_falsifier(a):
    c, P = cyc(a.cycle)
    if a.face not in c["faces"]: print(f"FAULT: face {a.face} not in {c['faces']}"); return 2
    if a.face in c["falsifiers"]: print("FAULT: falsifiers lock write-once."); return 2
    c["falsifiers"][a.face] = a.text
    json.dump(c, open(P["cycle"], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"FALSIFIER registered for face {a.face} ({len(c['falsifiers'])}/{len(c['faces'])})."); return 0

def cmd_atom(a):
    c, P = cyc(a.cycle); guard_open(P, a.round)
    if a.kind not in KINDS: print(f"FAULT: kind must be one of {KINDS}"); return 2
    if a.grade not in TIERS: print(f"FAULT: grade must be one of {TIERS}"); return 2
    if a.aid in {x["aid"] for x in load(P["atoms"])}: print("FAULT: atom id exists; ids are unique."); return 2
    if a.grade in ("theorem", "theorem-conditional") and not a.cite:
        print("FAULT: a theorem-grade atom carries a citation or it is a posit wearing a grade."); return 2
    append(P["atoms"], {"round": a.round, "aid": a.aid, "kind": a.kind, "grade": a.grade, "text": a.text,
                        "cite": a.cite or "", "sign": a.sign, "status": "live"})
    print(f"ATOM {a.aid} [{a.kind}/{a.grade}] r{a.round}"); return 0

def cmd_candidate(a):
    c, P = cyc(a.cycle); guard_open(P, a.round)
    atoms = {x["aid"]: x for x in load(P["atoms"])}
    ids = [s.strip() for s in a.atoms.split(",") if s.strip()]
    missing = [i for i in ids if i not in atoms]
    if missing: print(f"FAULT: candidate names atoms not on the ledger: {missing}"); return 2
    if a.cid in {x["cid"] for x in load(P["cands"])}: print("FAULT: candidate id exists."); return 2
    posits = int(a.posits)
    parent = None
    if a.effectivizes:
        latest = {}
        for x in load(P["cands"]): latest[x["cid"]] = x
        if a.effectivizes not in latest: print(f"FAULT: --effectivizes {a.effectivizes} names no candidate."); return 2
        par = latest[a.effectivizes]
        if par["disposition"] != "REFUSED-CIRCULAR" and "tier1" not in par.get("grammar", ""):
            print("FAULT: --effectivizes must name a REFUSED-CIRCULAR parent; a tunnel from a non-circular parent is a repeat, use --repeat-of at dispose."); return 2
        if not a.added.strip(): print("FAULT: an effectivized candidate names the content it adds (--added), the explicit bounding function or rate; a tunnel with nothing added is the parent in costume."); return 2
        parent = a.effectivizes
    append(P["cands"], {"round": a.round, "cid": a.cid, "statement": a.statement, "atoms": ids,
                        "grammar": a.grammar, "state": a.state, "gate": a.gate, "D": int(a.D),
                        "posits": posits, "price": a.price, "height": a.height, "breadth": int(a.breadth),
                        "gate_pass": a.state in GATE_PASS, "disposition": None, "lit": "unsearched",
                        "effectivizes": parent, "added": a.added or ""})
    print(f"CANDIDATE {a.cid} r{a.round} state={a.state} gate={a.gate} D{a.D} posits={posits} "
          f"{'GATE-PASS' if a.state in GATE_PASS else 'screened-out'}"
          + (f"  <- effectivizes {parent}, adds: {a.added}" if parent else "")); return 0

def cmd_search(a):
    c, P = cyc(a.cycle); guard_open(P, a.round)
    if a.classification not in ("owned", "adjacent", "clear"): print("FAULT: classification owned|adjacent|clear"); return 2
    cands = load(P["cands"])
    if a.cid not in {x["cid"] for x in cands}: print(f"FAULT: unknown candidate {a.cid}"); return 2
    append(P["search"], {"round": a.round, "sid": a.sid, "cid": a.cid, "query": a.query,
                         "hits": int(a.hits), "classification": a.classification})
    print(f"SEARCH {a.sid} r{a.round} cid={a.cid} hits={a.hits} -> {a.classification}"); return 0

def cmd_finding(a):
    c, P = cyc(a.cycle); guard_open(P, a.round)
    if a.disposition not in F_DISP: print(f"FAULT: disposition must be one of {F_DISP}"); return 2
    if a.severity not in SEVERITIES: print(f"FAULT: severity must be one of {SEVERITIES}"); return 2
    if not a.mechanism.strip(): print("FAULT: a finding with an empty mechanism is inadmissible."); return 2
    existing = {x["fid"] for x in load(P["finds"])}
    if a.fid in existing: print("FAULT: finding id exists."); return 2
    if a.repeat_of and a.repeat_of not in existing: print("FAULT: --repeat-of names no ledger row."); return 2
    if a.disposition == "EARNED" and not a.repaired: print("FAULT: EARNED requires --repaired (the sweep printed PASS)."); return 2
    atoms = {x["aid"] for x in load(P["atoms"])}; cands = {x["cid"] for x in load(P["cands"])}
    if a.target not in atoms and a.target not in cands: print(f"FAULT: target {a.target} is neither an atom nor a candidate."); return 2
    append(P["finds"], {"round": a.round, "fid": a.fid, "target": a.target, "register": a.register,
                        "severity": a.severity, "mechanism": a.mechanism, "disposition": a.disposition,
                        "repaired": bool(a.repaired), "repeat_of": a.repeat_of or None,
                        "falsifier": a.falsifier or ""})
    if a.target in atoms and a.disposition in ("EARNED", "SCOPED"):
        append(P["atoms"], {"round": a.round, "aid": a.target, "kind": "status", "grade": "-", "text": "",
                            "cite": "", "sign": "-", "status": "refused", "by": a.fid})
    print(f"FINDING {a.fid} r{a.round} [{a.disposition}] [{a.severity}] on {a.target}"); return 0

def cmd_dispose(a):
    c, P = cyc(a.cycle); guard_open(P, a.round)
    if a.disposition not in C_DISP: print(f"FAULT: candidate disposition must be one of {C_DISP}"); return 2
    cands = load(P["cands"]); ids = {x["cid"] for x in cands}
    if a.cid not in ids: print(f"FAULT: unknown candidate {a.cid}"); return 2
    if a.repeat_of and a.repeat_of not in ids: print("FAULT: --repeat-of names no candidate."); return 2
    row = [x for x in cands if x["cid"] == a.cid][-1]
    searched = [s for s in load(P["search"]) if s["cid"] == a.cid and s["round"] == a.round]
    if a.disposition == "FIRM":
        if not row["gate_pass"]: print("FAULT: FIRM requires a gate-passing state (mass-candidate / anchor-candidate)."); return 2
        if row["posits"] != 1: print("FAULT: FIRM requires the One-Go census of exactly one posit."); return 2
        if not searched: print("FAULT: FIRM requires a literature search recorded for this candidate in this round."); return 2
        if searched[-1]["classification"] != "clear": print("FAULT: FIRM requires the search classified clear; owned or adjacent is not clear."); return 2
        if row["breadth"] < 1: print("FAULT: FIRM requires breadth at or above one (height above price)."); return 2
        if row.get("effectivizes"): print(f"TUNNEL: {a.cid} effectivizes {row['effectivizes']}; the content added is: {row.get('added','')}")
    if a.disposition == "REFUSED-OWNED" and not (searched and searched[-1]["classification"] in ("owned", "adjacent")):
        print("FAULT: REFUSED-OWNED requires a recorded search classified owned or adjacent."); return 2
    if a.disposition == "ROAD":
        # a deep equivalence found here: not an anchor, a transport. Proved both ways, at depth, literature-clear,
        # landing on a named far-side carrier; it re-seats the hunt and exits as an equivalence-theorem candidate.
        if row["state"] not in ("refused-circular",): print("FAULT: ROAD requires a candidate the screen refused as circular; a road is a proved equivalence and nothing else."); return 2
        if a.depth < 2: print("FAULT: ROAD requires depth at or above 2; a surface equivalence is a restatement the field already holds."); return 2
        if not searched or searched[-1]["classification"] != "clear": print("FAULT: ROAD requires a search on the EQUIVALENCE classified clear in this round."); return 2
        if not a.far_carrier.strip(): print("FAULT: ROAD names the far-side carrier the equivalence lands on."); return 2
        if not a.equiv_artifact.strip(): print("FAULT: ROAD names the two-direction equivalence artifact (the LEAN specification path); a tunnel with no written proof is a veil."); return 2
        c["carriers"] = c.get("carriers", []) + [{"round": a.round, "via": a.cid, "carrier": a.far_carrier, "depth": a.depth, "artifact": a.equiv_artifact}]
        json.dump(c, open(P["cycle"], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"ROAD: {a.cid} is a depth-{a.depth} equivalence, literature-clear; the hunt re-seats on: {a.far_carrier}")
    append(P["cands"], {"round": a.round, "cid": a.cid, "statement": row["statement"], "atoms": row["atoms"],
                        "grammar": row["grammar"], "state": row["state"], "gate": row["gate"], "D": row["D"],
                        "posits": row["posits"], "price": row["price"], "height": row["height"],
                        "breadth": row["breadth"], "gate_pass": row["gate_pass"], "disposition": a.disposition,
                        "lit": searched[-1]["classification"] if searched else row["lit"],
                        "repeat_of": a.repeat_of or None, "note": a.note or "",
                        "effectivizes": row.get("effectivizes"), "added": row.get("added", ""),
                        "depth": a.depth if a.disposition == "ROAD" else None,
                        "far_carrier": a.far_carrier if a.disposition == "ROAD" else None,
                        "equiv_artifact": a.equiv_artifact if a.disposition == "ROAD" else None})
    print(f"DISPOSED {a.cid} r{a.round} -> {a.disposition}"); return 0

def cmd_leakscan(a):
    text = open(a.file, encoding="utf-8").read(); hits = []
    for i, line in enumerate(text.split("\n"), 1):
        for t in LEAK_WORD:
            if re.search(rf"\b{re.escape(t)}\b", line): hits.append((i, t))
        for t in LEAK_SUB:
            if t in line: hits.append((i, t))
    if hits:
        for i, t in hits: print(f"LEAK line {i}: {t}")
        print(f"LEAK: {len(hits)} framework token(s) in the blind pass."); return 1
    print("CLEAN: no framework tokens detected."); return 0

def latest_cands(cands, rnd):
    last = {}
    for x in cands:
        if x["round"] == rnd: last[x["cid"]] = x
    return last

def round_stats(P, rnd):
    atoms = load(P["atoms"]); cands = load(P["cands"]); finds = load(P["finds"]); srch = load(P["search"])
    refused_atoms = {x["aid"] for x in atoms if x.get("status") == "refused" and x["round"] == rnd}
    live_atoms = {x["aid"] for x in atoms if x["kind"] != "status"} - {x["aid"] for x in atoms if x.get("status") == "refused"}
    L = latest_cands(cands, rnd)
    disp = {d: sum(1 for x in L.values() if x["disposition"] == d) for d in C_DISP}
    undisposed = [k for k, x in L.items() if x["disposition"] is None]
    gp = [k for k, x in L.items() if x["gate_pass"]]
    gp_unsearched = [k for k in gp if not any(s["cid"] == k and s["round"] == rnd for s in srch)]
    fd = {d: sum(1 for f in finds if f["round"] == rnd and f["disposition"] == d) for d in F_DISP}
    repeats = sum(1 for x in L.values() if x.get("repeat_of"))
    return {"refused_atoms": len(refused_atoms), "live_atoms": len(live_atoms), "candidates": len(L),
            "gate_pass": len(gp), "gate_pass_unsearched": gp_unsearched, "undisposed": undisposed,
            "cand": disp, "find": fd, "repeats": repeats, "searches": sum(1 for s in srch if s["round"] == rnd)}

def evaluate(a, s, rounds):
    if a.leak: return "VOID-LEAK", "framework vocabulary in the blind pass; re-run the round"
    if a.controls_total <= 0: return "VOID-UNCALIBRATED", "no committed control set"
    if a.controls_caught < a.controls_total: return "VOID-UNDERPOWERED", f"controls {a.controls_caught}/{a.controls_total}"
    if s["undisposed"]: return "FAULT", f"undisposed candidates {s['undisposed']}; every candidate exits into a disposition"
    prior = [r for r in rounds if not r["verdict"].startswith("VOID")]
    valid = len(prior) + 1
    if s["gate_pass_unsearched"]:
        return "CONTINUE-LIT", f"gate-passing candidates {s['gate_pass_unsearched']} have no literature search this round; no mass without the search"
    if a.grade_raised and not a.new_theorem_atom:
        return "INFLATION-FAULT", "a candidate's grade rose with no newly cited theorem atom"
    if s["cand"]["FIRM"] > 0:
        if valid < FLOOR_ROUNDS: return "CONTINUE-FLOOR", f"a FIRM candidate stands but valid rounds {valid}/{FLOOR_ROUNDS}; grind again"
        covered = set(a.registers.split(",")) | {r for x in prior for r in x.get("registers", [])}
        missing = [r for r in REG_CANON if r not in covered]
        if missing: return "CONTINUE-COVERAGE", f"a FIRM candidate stands but registers not yet prosecuted: {', '.join(missing)}"
        return "FIRM-CANDIDATE", ("a candidate passed the screen, couples by a one-posit chain, is literature-clear on a "
                                  "recorded search, and carries breadth; route to the FORGE gate; its truth stays supply-side")
    if s["cand"]["ROAD"] > 0:
        return "CONTINUE-ROAD", (f"{s['cand']['ROAD']} deep equivalence(s) proved and literature-clear; the hunt re-seats on the far-side "
                                 "carrier next round, its legs ground fresh; the road itself exits through the M-cascade as an equivalence-theorem candidate")
    ref_hist = [r["stats"]["refused_atoms"] for r in prior] + [s["refused_atoms"]]
    if len(ref_hist) >= 3 and ref_hist[-1] > ref_hist[-2] > ref_hist[-3]:
        return "HALT-DIVERGENT", "refused atoms rose across two consecutive valid rounds; the target is fragmenting, reconstruct"
    owned_now = s["gate_pass"] > 0 and s["cand"]["REFUSED-OWNED"] == s["gate_pass"]
    owned_prev = bool(prior) and prior[-1]["stats"]["gate_pass"] > 0 and \
                 prior[-1]["stats"]["cand"]["REFUSED-OWNED"] == prior[-1]["stats"]["gate_pass"]
    if owned_now and (owned_prev or a.exhausted):
        return "HALT-OWNED", ("every gate-passing candidate is literature-owned across two rounds, or the atom pool is "
                              "attested exhausted; the door is where the field is; delta-M zero; state the seat delta")
    if s["candidates"] > 0 and s["repeats"] == s["candidates"] and prior and prior[-1]["stats"]["repeats"] == prior[-1]["stats"]["candidates"] > 0:
        return "HALT-STALE", "every candidate repeats a refused mechanism across two rounds; the reassembly is looping"
    if valid >= CAP_ROUNDS: return "CAP", "autorun cap reached with no terminal verdict; deliver the ledger open"
    return "CONTINUE", "no firm candidate yet; grind again"

def cmd_close(a):
    c, P = cyc(a.cycle)
    rounds = load(P["rounds"]); guard_open(P, a.round)
    if rounds and a.round != rounds[-1]["round"] + 1: print(f"FAULT: rounds close in sequence; expected {rounds[-1]['round']+1}"); return 2
    if not rounds and a.round != 1: print("FAULT: the first closed round is round 1."); return 2
    missing = [f for f in c["faces"] if f not in c["falsifiers"]]
    if missing: print(f"FAULT: faces without a registered falsifier: {missing}"); return 2
    regs = [r.strip() for r in a.registers.split(",") if r.strip()]
    bad = [r for r in regs if r not in REG_CANON]
    if bad: print(f"FAULT: unknown registers {bad}; canon {REG_CANON}"); return 2
    s = round_stats(P, a.round)
    a.registers = ','.join(regs)
    verdict, why = evaluate(a, s, rounds)
    if verdict == "FAULT": print("FAULT:", why); return 2
    append(P["rounds"], {"round": a.round, "registers": regs, "controls_caught": a.controls_caught,
                         "controls_total": a.controls_total, "control_grade": a.grade, "leak": bool(a.leak),
                         "new_theorem_atom": bool(a.new_theorem_atom), "exhausted": bool(a.exhausted),
                         "stats": s, "verdict": verdict, "why": why})
    print(f"ROUND {a.round} CLOSED  registers={'+'.join(regs)}")
    print(f"  atoms live {s['live_atoms']}  refused this round {s['refused_atoms']}  candidates {s['candidates']}  gate-pass {s['gate_pass']}  searches {s['searches']}")
    print("  candidate dispositions " + "  ".join(f"{k} {v}" for k, v in s["cand"].items() if v))
    print("  findings " + "  ".join(f"{k} {v}" for k, v in s["find"].items() if v))
    print(f"  controls {a.controls_caught}/{a.controls_total} grade {a.grade}  leak {'yes' if a.leak else 'no'}")
    print(f"  VERDICT {verdict}: {why}"); return 0

def cmd_status(a):
    c, P = cyc(a.cycle); rounds = load(P["rounds"]); cands = load(P["cands"])
    print(f"CYCLE {a.cycle} target={c['target']!r} faces={c['faces']} carrier={c['carrier']!r}")
    for k in c.get("carriers", []): print(f"  re-seated r{k['round']} via ROAD {k['via']} depth {k['depth']} -> {k['carrier']} (artifact {k['artifact']})")
    for r in rounds:
        st = r["stats"]; print(f"  r{r['round']} [{'+'.join(r['registers'])}] atoms live {st['live_atoms']} refused {st['refused_atoms']} "
                                f"cands {st['candidates']} gp {st['gate_pass']} FIRM {st['cand']['FIRM']} OWNED {st['cand']['REFUSED-OWNED']} "
                                f"| controls {r['controls_caught']}/{r['controls_total']} {r['control_grade']} | {r['verdict']}")
    last = {}
    for x in cands: last[x["cid"]] = x
    print("  candidate census:")
    for k, x in last.items(): print(f"    {k:<12} {str(x['disposition']):<22} state={x['state']:<16} D{x['D']} posits={x['posits']} lit={x['lit']}"
                                    + (f"  <- {x['effectivizes']}" if x.get('effectivizes') else ""))
    if rounds and rounds[-1]["verdict"] in ("FIRM-CANDIDATE", "HALT-OWNED", "HALT-STALE", "HALT-DIVERGENT"):
        print(f"TERMINAL {rounds[-1]['verdict']}. Emit the Pre-Forge Digest; on FORGE, the closing card.")
    return 0

def main(argv=None):
    p = argparse.ArgumentParser(); sub = p.add_subparsers(dest="cmd", required=True)
    i = sub.add_parser("init"); [i.add_argument("--"+k, required=True) for k in ("cycle","target","faces","carrier")]
    f = sub.add_parser("falsifier"); [f.add_argument("--"+k, required=True) for k in ("cycle","face","text")]
    t = sub.add_parser("atom"); [t.add_argument("--"+k, required=True) for k in ("cycle","aid","kind","grade","text")]
    t.add_argument("--round", type=int, required=True); t.add_argument("--cite", default=""); t.add_argument("--sign", default="unsigned")
    cd = sub.add_parser("candidate"); [cd.add_argument("--"+k, required=True) for k in ("cycle","cid","statement","atoms","grammar","state","gate","D","posits")]
    cd.add_argument("--round", type=int, required=True); cd.add_argument("--price", default="?"); cd.add_argument("--height", default="?"); cd.add_argument("--breadth", default="0")
    cd.add_argument("--effectivizes", default=""); cd.add_argument("--added", default="")
    sr = sub.add_parser("search"); [sr.add_argument("--"+k, required=True) for k in ("cycle","sid","cid","query","hits","classification")]
    sr.add_argument("--round", type=int, required=True)
    fd = sub.add_parser("finding"); [fd.add_argument("--"+k, required=True) for k in ("cycle","fid","target","register","severity","mechanism","disposition")]
    fd.add_argument("--round", type=int, required=True); fd.add_argument("--repaired", action="store_true")
    fd.add_argument("--repeat-of", dest="repeat_of", default=""); fd.add_argument("--falsifier", default="")
    dp = sub.add_parser("dispose"); [dp.add_argument("--"+k, required=True) for k in ("cycle","cid","disposition")]
    dp.add_argument("--round", type=int, required=True); dp.add_argument("--repeat-of", dest="repeat_of", default=""); dp.add_argument("--note", default="")
    dp.add_argument("--depth", type=int, default=0); dp.add_argument("--far-carrier", dest="far_carrier", default=""); dp.add_argument("--equiv-artifact", dest="equiv_artifact", default="")
    lk = sub.add_parser("leakscan"); lk.add_argument("--file", required=True)
    cl = sub.add_parser("close"); cl.add_argument("--cycle", required=True); cl.add_argument("--round", type=int, required=True)
    cl.add_argument("--registers", required=True); cl.add_argument("--controls-caught", dest="controls_caught", type=int, required=True)
    cl.add_argument("--controls-total", dest="controls_total", type=int, default=3); cl.add_argument("--grade", choices=["EXTERNAL","SELF"], default="SELF")
    cl.add_argument("--leak", action="store_true"); cl.add_argument("--new-theorem-atom", dest="new_theorem_atom", action="store_true")
    cl.add_argument("--grade-raised", dest="grade_raised", action="store_true"); cl.add_argument("--exhausted", action="store_true")
    st = sub.add_parser("status"); st.add_argument("--cycle", required=True)
    a = p.parse_args(argv)
    return {"init":cmd_init,"falsifier":cmd_falsifier,"atom":cmd_atom,"candidate":cmd_candidate,"search":cmd_search,
            "finding":cmd_finding,"dispose":cmd_dispose,"leakscan":cmd_leakscan,"close":cmd_close,"status":cmd_status}[a.cmd](a)

if __name__ == "__main__":
    sys.exit(main())
