#!/usr/bin/env python3
# UNIVERSAL CASCADE v2 · maximally hardened · seed 20260622
# H1 canonicity · H2 kill-matrix + ablation · H3 availability theorems · H4 reliability
# H5 adversarial battery · H6 hardened seat · H7 self-application · H8 chain.
# The engine adjudicates hand-built readings (Honest Limits). It authors nothing.
import numpy as np, hashlib
SEED = 20260622
UEPS = float(np.finfo(float).eps)
SPEC = ("UNIVERSAL-CASCADE-v2|counts 12/8/5/8 forced|router-signature+canonicity|"
        "availability: Sigma01-bar T, MagExcl T-cond, O0-(0,0) S|seat M1-M8 identity-fixed|"
        "kill-matrix 35|ablation leak law|adversarial 5|self-app M1|drbg-numpy")
D0 = hashlib.sha256(SPEC.encode()).hexdigest()
def Hh(x): return hashlib.sha256(str(x).encode("utf-8")).hexdigest()

# ---------- measurement + H1 canonicity ----------
def eig_int(M): return sorted(int(round(x)) for x in np.linalg.eigvals(np.asarray(M,float)).real)
def measure(M):
    M = np.asarray(M, float)
    return dict(eig=eig_int(M), gdim=eig_int(M).count(1),
                resid=float(np.max(np.abs(M @ M - np.eye(M.shape[0])))))
def canonicity(cands):
    """H1. A candidate involution enters the census only if (a) definable from the
    problem's own defining data and (b) presented in the content category, never a
    linearization that donates a fixed locus the content map lacks (B.13.T)."""
    adm, ref = [], []
    for c in cands:
        if not c.get("definable", False):
            ref.append((c["name"], "not definable from defining data")); continue
        if c.get("category", "content") != "content":
            ref.append((c["name"], "representation furniture; category clause")); continue
        m = measure(c["M"])
        if m["resid"] != 0.0:
            ref.append((c["name"], "not an involution at machine zero")); continue
        adm.append((c["name"], m["gdim"]))
    if not adm: return dict(gclass="UNMEASURED", admitted=adm, refused=ref)
    gds = {g for _, g in adm}
    gclass = "MIXED" if len(gds) > 1 else ("g0" if gds == {0} else "g1")
    return dict(gclass=gclass, admitted=adm, refused=ref)

# ---------- H4 hardened kernel: four estimators, identity, escalation, blindness ----------
def _det4(R):
    a,b,c = R[0]; d,e,f = R[1]; g,h,i = R[2]
    d_lu  = float(np.linalg.det(R))
    d_eig = float(np.prod(np.linalg.eigvalsh(R)))
    try:  d_ch = float(np.prod(np.diag(np.linalg.cholesky(R)))**2)
    except np.linalg.LinAlgError: d_ch = d_lu
    d_co  = float(a*(e*i-f*h) - b*(d*i-f*g) + c*(d*h-e*g))
    return d_lu, d_eig, d_ch, d_co
def kernel_hardened(M):
    M = np.asarray(M, float); N = M.shape[1]
    sd = M.std(1, ddof=1, keepdims=True)
    if np.any(sd < 1e-12): return dict(tok="[?]", why="zero-variance row")
    Mn = (M - M.mean(1, keepdims=True)) / sd
    Q  = Mn / np.sqrt((Mn*Mn).sum(1, keepdims=True))
    R  = Q @ Q.T; kap = float(np.linalg.cond(R))
    Bv = np.linalg.svd(Q, full_matrices=False)[2][:3]
    lam  = float(-np.linalg.det(Q @ Bv.T))
    ds   = _det4(R); dR = ds[0]
    tol  = 4.0 * kap * UEPS
    spread = max(ds) - min(ds)
    resid  = abs(lam*lam - dR)
    Dm = np.diag([-1.,1.,1.]);  bdiff = abs(float(np.linalg.det((Dm@Q)@(Dm@Q).T)) - dR)
    esc = (spread > tol) or (resid > tol)
    eps = 100*UEPS*N
    if esc:
        try:
            import mpmath as mp; mp.mp.dps = 50
            dR = float(mp.det(mp.matrix([[mp.mpf(x) for x in row] for row in R.tolist()])))
            esc = "resolved@50dps"
        except Exception: esc = "flagged; mpmath absent"
    tok = "[LOCK]" if (dR > eps and kap < 1e6) else ("[X]" if dR <= eps else "[?]")
    return dict(tok=tok, detR=dR, lam=lam, kappa=kap, spread=spread, resid=resid,
                blind_ok=bdiff <= tol, escalated=esc,
                margins=(float(np.log10(dR/eps)) if dR > 0 else -99, float(np.log10(1e6/kap))))

# ---------- H3 availability theorems ----------
CATALOG = {"orientation": ("CLOSED", "Weyl closure"), "census": ("CLOSED", "GOLn walk"),
           "magnitude": ("EMPTY", "Magnitude Exclusion, T-cond"),
           "construction": ("INAPPLICABLE", "exhibition, not reading")}
def availability(flank, content):
    notes = []; xi = True; o0 = True
    if flank[1] == 1:
        xi = False; notes.append("T: Sigma-0-1-completeness bars [Xi_0] where the affirmative is witnessable")
    st = CATALOG.get(content, ("NO-ENTRY", ""))[0]
    if st != "CLOSED":
        xi = False; notes.append(f"catalog {st} for content={content}")
    if flank != (0, 0):
        o0 = False; notes.append("S: [O_0] constrained to the (0,0) flank cell")
    return dict(Xi0=xi, O0=o0, notes=notes)

# ---------- the three cascades (skip= enables ablation; defaults fail-safe) ----------
G12 = ["SREP","REG","SGEG","CAUSAL","MIG","PTB","DUAL","CSCG","CSEG","MTA","OMA","ADEG"]
def twelve(passes, skip=None):
    for g, p in zip(G12, passes):
        if g == skip: continue
        if not p: return "[X]", g
    return "[PASS]", "all twelve"
def eight(cfg, skip=None):
    seq = [("Xi-1", cfg["gd"]), ("Xi-2", cfg["noind"]), ("Xi-3", cfg["blind"] and cfg["closed"]),
           ("Xi-4", cfg["roads"]), ("Xi-5", cfg["exhibit"]), ("Xi-6", cfg["faces"] >= 1),
           ("Xi-7", cfg["ap"]), ("Xi-8", cfg["rev"])]
    for n, ok in seq:
        if n == skip: continue
        if not ok: return ("[X]" if n == "Xi-2" else "[?]"), n
    return "[Xi_0]", f"admitted, cap {cfg.get('cap','premise')}"
def five(cfg, skip=None):
    if cfg.get("wit"): return "[RESOLVE]", "adjudicate by direction (B.11.S)"
    if cfg.get("ind"): return "[X]", "Ghost"
    seq = [("O.1", cfg["gdim"] == 0 and cfg["resid"] == 0.0), ("O.2", cfg["det"] and cfg["stripped"]),
           ("O.3", cfg["walls"] >= 1 and cfg["typed"]), ("O.4", cfg["ap"]),
           ("R1", cfg["faces"] >= 1), ("R2", cfg["rel"]), ("R3", cfg["rev"])]
    for n, ok in seq:
        if n == skip: continue
        if not ok: return ("[ROUTE-Xi]" if n == "O.1" and cfg["gdim"] != 0 else "[?]"), n
    return "[O_0]", f"admitted, cap {cfg.get('cap','premise')}"
def bar(walls): return [w for w in walls if w.get("scope") == "instance" or w.get("bridge")]

# ---------- H6 hardened seat ----------
def costume(w):
    return isinstance(w, str) and "unprovab" in w.lower()
def seat(occupants, open_audits):
    """M1-M8, first failure routes. M7 identity-fixed: one content-addressed artifact.
    Two-occupant law: mutual rejection unfixes identity before any gate. M8 registry:
    a named unretracted objection OR a running machine audit holds the door open."""
    if len(occupants) > 1 and any(o.get("rejects_other") for o in occupants):
        return "[?]", "M7 fail: witness identity unfixed (contested seat, two mutually-rejecting occupants)"
    res = []
    for o in occupants:
        if costume(o.get("witness","")):
            res.append((o["name"], "[X]-costume", "Mirror: unrestricted unprovability is the negation in costume; Sigma-0-1 certificate owed")); continue
        if not o.get("object_level", True): res.append((o["name"], "[Mosaic dM=0]", "M1")); continue
        if o.get("witness") is None: res.append((o["name"], "[?]", "M5: no external witness")); continue
        if not o.get("independent"): res.append((o["name"], "[?]", "M6: verifier independence uncertified")); continue
        if not o.get("artifact_hash"): res.append((o["name"], "[?]", "M7: identity-fixed artifact absent")); continue
        if open_audits: res.append((o["name"], "[?]", f"M8: open audit standing ({open_audits[0]})")); continue
        res.append((o["name"], "[SEAL-OK]", f"witness={o['witness']}, defeasible-final"))
    return "SEAT", res

# ---------- H2 kill-matrix + ablation ----------
def kill_matrix():
    ok = 0; total = 0; leaks = 0
    base8 = dict(gd=True, noind=True, blind=True, closed=True, roads=True,
                 exhibit=True, faces=1, ap=True, rev=True)
    fails8 = [("Xi-1","gd"),("Xi-2","noind"),("Xi-3","blind"),("Xi-4","roads"),
              ("Xi-5","exhibit"),("Xi-6","faces"),("Xi-7","ap"),("Xi-8","rev")]
    for gate, key in fails8:
        c = dict(base8); c[key] = 0 if key == "faces" else False
        total += 1; v = eight(c);  ok += (v[1] == gate)
        leaks += (eight(c, skip=gate)[0] == "[Xi_0]")
    base5 = dict(gdim=0, resid=0.0, det=True, stripped=True, walls=1, typed=True,
                 ap=True, faces=1, rel=True, rev=True)
    fails5 = [("O.1","gdim"),("O.2","det"),("O.3","walls"),("O.4","ap"),
              ("R1","faces"),("R2","rel"),("R3","rev")]
    for gate, key in fails5:
        c = dict(base5); c[key] = (1 if key == "gdim" else (0 if key in ("walls","faces") else False))
        total += 1; v = five(c);   ok += (v[1] == gate)
        leaks += (five(c, skip=gate)[0] == "[O_0]")
    for i in range(12):
        p = [True]*12; p[i] = False
        total += 1; ok += (twelve(p)[1] == G12[i])
        leaks += (twelve(p, skip=G12[i])[0] == "[PASS]")
    seatfails = [
        (dict(object_level=False), "M1"),
        (dict(witness=None), "M5"),
        (dict(witness="w", independent=False), "M6"),
        (dict(witness="w", independent=True, artifact_hash=None), "M7"),
        (dict(witness="w", independent=True, artifact_hash="h"), "M8-open"),
        (dict(witness="claims unprovability forever"), "costume"),
        (None, "two-occupant"),
        (dict(witness="w", independent=True, artifact_hash="h"), "SEAL-clean"),
    ]
    for cfg, tag in seatfails:
        total += 1
        if tag == "two-occupant":
            v = seat([dict(name="a", rejects_other=True, witness="w"),
                      dict(name="b", rejects_other=True, witness="w")], [])
            ok += ("identity unfixed" in v[1])
        elif tag == "M8-open":
            v = seat([dict(name="x", **cfg)], ["LANA-class running audit"])
            ok += ("M8" in v[1][0][2])
        elif tag == "SEAL-clean":
            v = seat([dict(name="x", **cfg)], [])
            ok += (v[1][0][1] == "[SEAL-OK]")
        else:
            v = seat([dict(name="x", **cfg)], [])
            key = tag if tag != "costume" else "costume"
            ok += (key.split("-")[0] in v[1][0][2]) or (tag == "costume" and v[1][0][1] == "[X]-costume")
    return total, ok, leaks

# ---------- H5 adversarial battery ----------
def adversarial():
    caught = []
    r = five(dict(gdim=0, resid=0.0, det=True, stripped=True, walls=0, typed=False,
                  ap=True, faces=2, rel=True, rev=True))
    caught.append(("forced-delta on a sigma problem", r == ("[?]", "O.3")))
    c = canonicity([dict(name="parity-linearization", M=np.array([[0.,1.],[1.,0.]]),
                         definable=True, category="representation")])
    caught.append(("linearization-manufactured Ground", c["gclass"] == "UNMEASURED"))
    r = len(bar([dict(scope="class"), dict(scope="class")]))
    caught.append(("class-wall smuggling", r == 0))
    a = availability((1, 0), "chart")
    caught.append(("gauge-shell chart content", a["Xi0"] is False))
    s = seat([dict(name="p", witness="no proof can ever exist (unprovability claim)")], [])
    caught.append(("unprovability costume (Mirror)", s[1][0][1] == "[X]-costume"))
    return caught

# ---------- H7 self-application ----------
def self_application():
    v = seat([dict(name="Universal Cascade v2", object_level=False)], [])
    return v[1][0][1] == "[Mosaic dM=0]"

# ---------- boot ----------
def boot():
    print("=" * 78)
    print("UNIVERSAL CASCADE v2 · BOOT · seed", SEED)
    rg = np.random.default_rng(SEED)
    k = kernel_hardened(rg.standard_normal((3, 24)))
    print(f"  kernel: {k['tok']} detR={k['detR']:.12f} lam={k['lam']:+.12f} "
          f"resid={k['resid']:.2e} spread={k['spread']:.2e} blind_ok={k['blind_ok']} esc={k['escalated']}")
    t, okc, lk = kill_matrix()
    print(f"  kill-matrix: {okc}/{t} controls fail at exactly their gate; ablation leaks {lk}/27")
    adv = adversarial(); print("  adversarial:", all(c for _, c in adv), [n for n, c in adv])
    sa = self_application(); print("  self-application (audit symmetry): Mosaic dM=0 ->", sa)
    D1 = Hh(D0 + f"|KM {okc}/{t}|L{lk}")
    D2 = Hh(D1 + f"|ADV {all(c for _, c in adv)}")
    D3 = Hh(D2 + f"|SELF {sa}|K {k['detR']:.12f}")
    print(f"  chain D0 {D0[:12]} -> D1 {D1[:12]} -> D2 {D2[:12]} -> D3 {D3[:12]}")
    print("=" * 78)
    return dict(km=(okc, t, lk), adv=adv, sa=sa, D=(D0[:12], D1[:12], D2[:12], D3[:12]), k=k)

if __name__ == "__main__":
    boot()
