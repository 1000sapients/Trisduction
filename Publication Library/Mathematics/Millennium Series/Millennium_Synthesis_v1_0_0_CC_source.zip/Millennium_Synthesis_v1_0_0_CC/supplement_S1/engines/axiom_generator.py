#!/usr/bin/env python3
# AXIOM GENERATOR v1.3.6 · supplier-side · seed 20260622
# v1.3.6 is a packaging patch: the front-matter description was rewritten to clear the loader's
#   1024-character ceiling. SPEC below is deliberately left at the v1.3.5 string because the
#   specification did not change, so D0 through D4 are stable across this patch by construction.
# FORGE 8 gates · M-cascade 8 · trichotomy tier read · gate-matrix 13 · ablation 8 · adversarial 5
# ANCHOR 8 H-gates + inherited A1/A4/A5 · D-ladder D0-D4 · One-Go census · kernel receipt
#   anchor gate-matrix 24 (state AND firing-gate label) · anchor ablation 11 · anchor adversarial 5
#   zero-supply nullity (three axes) · purchase ledger · self-application M1 · chain-committed D0..D4.
# v1.2 (the Purchase Law): the bit is never sourced by the formal register and is always delivered by a
#   deed on the acting side; the seed's positing is that deed; the aperture is made visible and located at
#   the seed and no smaller (Islam 2026, DOI 10.5281/zenodo.21972436; MD-PSP-MATH-NATURE-01 V, XIV;
#   sPSP-APERTURE-WIDTH-01). The supply record (who, when, independent of what) is mandatory at H2.
# v1.3 (the Footprint Law): a kinetic seal certifies that the formal string has a caster, grounded at L1m,
#   never the rung; an RA-derived seed crosses on the Footprint bridge typed premise at monism's warrant,
#   which caps its D-grade at D2; audit-sealed claims admitted as a fifth provenance class.
# The engine adjudicates hand-built readings (Honest Limits). It authors nothing;
# authored mass exits only through M5/M6, an EXTERNAL independent witness.
# v1.1 repairs to the carried v1 engine (ERR-01, ERR-02 in the changelog):
#   ERR-01 the circular-grammar check fires at A2, before A4/A5. In v1 it ran after A5,
#          so a circular candidate that was also literature-owned emitted 'conditional'.
#   ERR-02 gate_matrix verifies the FIRING GATE LABEL and not only the emitted state;
#          v1 claimed "fails at exactly its own gate" while checking the state alone.
import hashlib, math
SEED = 20260622
SPEC = ("AXIOM-GENERATOR-v1.3.5|counts 8/5 forced|AXF S1-S3,A1-A8|M-cascade M1-M8|"
        "trichotomy: circular/effective/off-string|A2 vacuity gate|A5 breadth|"
        "M5/M6 external-independent-witness|gate-matrix 13 labeled|ablation 8|adversarial 5|"
        "ANCHOR H1-H8 + A1/A4/A5|D-ladder D0-D4 necessity test|One-Go census=1|"
        "purchase law: never sourced by the register, always delivered by a deed|supply record at H2|"
        "kernel receipt [seal|SA] Type C with direction line|purchase ledger price/height/balance|free-bit census measured|receipt escalates at 50 dps on fault|"
        "footprint law: kinetic seal -> caster at L1m, never the rung; RA seeds cross on the premise bridge, D capped at D2|"
        "provenance RA/RA-grade/sealed-PSP/audit-sealed/classical|"
        "anchor gate-matrix 24 labeled|anchor ablation 11|anchor adversarial 5|zero-supply null x3|"
        "self-app M1|LEAN spec clears M5 on completion|drbg=sha256-counter box-muller")
D0 = hashlib.sha256(SPEC.encode()).hexdigest()
def Hh(x): return hashlib.sha256(str(x).encode("utf-8")).hexdigest()

# ======================= PART 1-3 · the carried v1 engine =======================

# ---------------- tier read (trichotomy, Part 2.3) ----------------
def tier_read(grammar):
    # grammar in {'breakdown_conditioned','qualitative_per_solution',
    #             'data_uniform_effective','offstring'}
    if grammar in ('breakdown_conditioned', 'qualitative_per_solution'):
        return 'tier1-circular'
    if grammar == 'data_uniform_effective':
        return 'tier2-effective'
    if grammar == 'offstring':
        return 'tier3-offstring-owes-tier2'
    return 'unclassified'

# ---------------- the eight AXF gates (Part 2.1) ----------------
def axf(cand, skip=None):
    # cand fields, all defaulting to the SAFE (refusing) value:
    #   wellformed: bool
    #   refuted_by_base: bool           -> A1
    #   equiv_to_target: bool           -> A2 (the load-bearing vacuity gate)
    #   coupling_proof: bool            -> A3
    #   in_literature: bool             -> A4
    #   breadth: int                    -> A5
    #   grammar: str                    -> tier read
    g = cand
    def on(name): return skip != name
    if on('S3') and not g.get('wellformed', False):
        return 'refused-illformed', 'S3'
    if on('A1') and g.get('refuted_by_base', False):
        return 'refused-inconsistent', 'A1'
    if on('A2') and g.get('equiv_to_target', False):
        return 'refused-circular', 'A2'          # conclusion in costume
    if on('A2') and tier_read(g.get('grammar', '')) == 'tier1-circular':
        return 'refused-circular', 'A2:trichotomy'   # ERR-01: circular grammar is an A2 fact (Part 2.3)
    if on('A3') and not g.get('coupling_proof', False):
        return 'refused-inert', 'A3'
    if on('A4') and g.get('in_literature', False):
        return 'conditional', 'A4'               # correct tier, zero formulation mass
    if on('A5') and g.get('breadth', 0) <= 0:
        return 'conditional', 'A5'               # one-target decree
    tier = tier_read(g.get('grammar', ''))
    if tier != 'tier2-effective':
        return 'conditional', f'tier:{tier}'     # only tier two proceeds to mass
    return 'mass-candidate', f'A8:candidacy-only;{tier}'

# ---------------- the M-cascade closure (Part 2.2) ----------------
def m_close(claim, skip=None):
    # claim fields default to the SAFE (refusing) value:
    #   object_level, name_survives, literature_clear, not_two_line: bool
    #   external_witness: str or None   -> M5 (never set by internal reasoning)
    #   witness_independent: bool       -> M6
    #   reproducible_artifact: bool     -> M7
    #   gap_audit_closed: bool          -> M8
    c = claim
    def on(n): return skip != n
    if on('M1') and not c.get('object_level', False):
        return '[Mosaic dM=0]', 'M1: meta-work, no mass by definition'
    if on('M2') and not c.get('name_survives', False):
        return '[?]', 'M2: fails name-strip'
    if on('M3') and not c.get('literature_clear', False):
        return '[?]', 'M3: already the literature target under another name'
    if on('M4') and not c.get('not_two_line', False):
        return '[?]', 'M4: two-line corollary of a cited criterion'
    if on('M5') and c.get('external_witness', None) is None:
        return '[?]', 'M5: no external witness (never set by internal reasoning)'
    if on('M6') and not c.get('witness_independent', False):
        return '[?]', 'M6: verifier is the claimant'
    if on('M7') and not c.get('reproducible_artifact', False):
        return '[?]', 'M7: prose is a claim, not a proof object'
    if on('M8') and not c.get('gap_audit_closed', False):
        return '[?]', 'M8: gap audit open'
    return '[dM>0]', f"authored mass, witness={c.get('external_witness')}, defeasible-final"

# ---------------- gate-matrix: 13 controls, one per gate, LABELED (ERR-02) ----------------
BASE_AX = dict(wellformed=True, refuted_by_base=False, equiv_to_target=False,
               coupling_proof=True, in_literature=False, breadth=3,
               grammar='data_uniform_effective')
BASE_M = dict(object_level=True, name_survives=True, literature_clear=True,
              not_two_line=True, external_witness='proof-assistant',
              witness_independent=True, reproducible_artifact=True,
              gap_audit_closed=True)
def gate_matrix():
    ok = 0; total = 0
    controls = [   # (gate, vector, expected state, expected firing label)
        ('S3', {**BASE_AX, 'wellformed': False},      'refused-illformed',    'S3'),
        ('A1', {**BASE_AX, 'refuted_by_base': True},  'refused-inconsistent', 'A1'),
        ('A2', {**BASE_AX, 'equiv_to_target': True},  'refused-circular',     'A2'),
        ('A3', {**BASE_AX, 'coupling_proof': False},  'refused-inert',        'A3'),
        ('A4', {**BASE_AX, 'in_literature': True},    'conditional',          'A4'),
        ('A5', {**BASE_AX, 'breadth': 0},             'conditional',          'A5'),
        ('T1', {**BASE_AX, 'grammar': 'breakdown_conditioned'}, 'refused-circular', 'A2:trichotomy'),
        ('T3', {**BASE_AX, 'grammar': 'offstring'},   'conditional',          'tier:tier3-offstring-owes-tier2'),
    ]
    for _, ax, want_state, want_label in controls:
        total += 1; st, lb = axf(ax); ok += (st == want_state and lb == want_label)
    mcontrols = [('M1', {**BASE_M, 'object_level': False}),
                 ('M3', {**BASE_M, 'literature_clear': False}),
                 ('M5', {**BASE_M, 'external_witness': None}),
                 ('M6', {**BASE_M, 'witness_independent': False}),
                 ('M7', {**BASE_M, 'reproducible_artifact': False})]
    for g, mc in mcontrols:
        total += 1; st, why = m_close(mc); ok += (st != '[dM>0]' and why.startswith(g + ':'))
    return ok, total

# ---------------- ablation: 8 mass-guarding gates leak on deletion ----------------
def ablation():
    leaks = 0
    ax_fail = {'A2': {**BASE_AX, 'equiv_to_target': True},
               'A3': {**BASE_AX, 'coupling_proof': False},
               'A4': {**BASE_AX, 'in_literature': True},
               'A5': {**BASE_AX, 'breadth': 0}}
    for g, ax in ax_fail.items():
        leaks += (axf(ax, skip=g)[0] == 'mass-candidate')
    m_fail = {'M3': {**BASE_M, 'literature_clear': False},
              'M4': {**BASE_M, 'not_two_line': False},
              'M5': {**BASE_M, 'external_witness': None},
              'M6': {**BASE_M, 'witness_independent': False}}
    for g, mc in m_fail.items():
        leaks += (m_close(mc, skip=g)[0] == '[dM>0]')
    return leaks

# ---------------- adversarial battery: 5 steering attempts ----------------
def adversarial():
    out = []
    out.append(('conditioned-as-uncond',
                axf(dict(wellformed=True, equiv_to_target=True, coupling_proof=True,
                         breadth=5, grammar='breakdown_conditioned'))[0] == 'refused-circular'))
    out.append(('one-target-decree',
                axf(dict(wellformed=True, coupling_proof=True, breadth=0,
                         grammar='data_uniform_effective'))[0] == 'conditional'))
    out.append(('literature-renamed',
                axf(dict(wellformed=True, coupling_proof=True, in_literature=True,
                         breadth=5, grammar='data_uniform_effective'))[0] == 'conditional'))
    out.append(('self-certified',
                m_close(dict(object_level=True, name_survives=True, literature_clear=True,
                             not_two_line=True, external_witness='self-run',
                             witness_independent=False, reproducible_artifact=True,
                             gap_audit_closed=True))[0] != '[dM>0]'))
    out.append(('formulation-only',
                m_close(dict(object_level=True, name_survives=True, literature_clear=False,
                             not_two_line=True, external_witness='referee',
                             witness_independent=True, reproducible_artifact=True,
                             gap_audit_closed=True))[0] != '[dM>0]'))
    return out

def self_application():
    # the engine's own claim is meta-work; it must read Mosaic dM=0.
    return m_close(dict(object_level=False))[0] == '[Mosaic dM=0]'

# ---------------- worked instance: the NS arc, 5 candidates ----------------
def ns_instance():
    cands = {
        'BAR':  dict(wellformed=True, equiv_to_target=True, coupling_proof=True,
                     breadth=0, grammar='breakdown_conditioned'),
        'L3B':  dict(wellformed=True, equiv_to_target=True, coupling_proof=True,
                     breadth=0, grammar='breakdown_conditioned'),
        'CFCq': dict(wellformed=True, equiv_to_target=True, coupling_proof=True,
                     breadth=0, grammar='qualitative_per_solution'),
        'EBA':  dict(wellformed=True, equiv_to_target=False, coupling_proof=True,
                     in_literature=True, breadth=3, grammar='data_uniform_effective'),
        'CFCe': dict(wellformed=True, equiv_to_target=False, coupling_proof=True,
                     in_literature=True, breadth=3, grammar='data_uniform_effective'),
    }
    return {k: axf(v)[0] for k, v in cands.items()}

# ======================= PART 4 · ANCHOR · the seal-anchored structural axiom =======================

D_LADDER = {0: 'D0-chart', 1: 'D1-free', 2: 'D2-structurally-forced',
            3: 'D3-theorem-forced', 4: 'D4-proved'}

def d_grade(c):
    """Defensibility ladder (Part 4.4), typed from the caller's hand-built reading; defaults absent -> D1.
    The Necessity test: grant the single bridge posit; is not-SA then inconsistent with the carrier's
    sealed legs?  yes on Type T legs -> D3; yes on Type S legs -> D2; no -> D1 (the bridge granted and
    SA still free: a posit wearing an invariant's shape).  SA proved in the base -> D4, not an axiom.
    A leg the caller does not cite is read as absent (adversarial control 5). D0 is assigned by H3."""
    if c.get('proved_in_base', False): return 4
    legs = c.get('carrier_legs', 'none') if c.get('legs_cited', False) else 'none'
    if c.get('cross_register', False) and legs == 'T':
        legs = 'S'          # Footprint bridge is premise-grade: a kinetic carrier's legs read structural here
    if not c.get('bridge_typed', False): return 1
    if not c.get('forced_given_bridge', False): return 1
    return {'T': 3, 'S': 2}.get(legs, 1)

def anchor(c, skip=None):
    """The eight H-gates, then the inherited AXF gates, then the D-typing. First failure terminal
    with its firing gate named. Every default is the refusing value: an under-specified call can
    never emit 'anchor-candidate' (zero-supply nullity)."""
    def on(g): return skip != g
    # H1 SEAL: the target's geometric face stands [seal T], the involution named, Ground dim read
    if on('H1') and not (c.get('shape_sealed', False) and c.get('ground_dim', None) is not None):
        return 'no-seal', 'H1'
    # H2 PROVENANCE and name-strip: RA / RA-grade / sealed-PSP / classical, stated framework-free
    if on('H2') and c.get('provenance', '') not in ('RA', 'RA-grade', 'sealed-PSP', 'audit-sealed', 'classical'):
        return 'refused-unprovenanced', 'H2'
    if on('H2') and not c.get('framework_free', False):
        return 'refused-framework-bound', 'H2:name-strip'
    # H2 supply record: the seed is a supplied deed, never the instrument's own manufacture (A.3, the aperture)
    if on('H2') and not c.get('supplier', None):
        return 'refused-unsupplied', 'H2:supply-record'
    if on('H2') and c.get('supplier', None) == 'engine':
        return 'refused-aperture', 'H2:instrument-generated'
    # H3 NATIVE (Erlangen, B.13.T): the value of an invariant of the sealed carrier's acting group
    if on('H3') and c.get('chart_magnitude', False):
        return 'refused-chart', 'H3:D0'
    if on('H3') and not c.get('invariant_of_carrier', False):
        return 'not-anchored', 'H3:route-FORGE'      # a posit about the carrier: a hypothesis, not a seal-anchored seed
    # H4 SIGNED: a sign or an ordered value
    if on('H4') and not c.get('signed', False):
        return 'refused-unsigned', 'H4'
    # H5 COUPLED: non-constant across T and not-T, a deficit and never a modulus
    if on('H5') and not c.get('nonconstant_across_T', False):
        return 'refused-modulus', 'H5'
    # H6 PRIOR: the carrier established beforehand; a cross-register carrier needs a typed bridge (ADEG)
    if on('H6') and not c.get('carrier_prior', False):
        return 'refused-posterior', 'H6'
    if on('H6') and c.get('cross_register', False) and not c.get('bridge_typed', False):
        return 'refused-posterior', 'H6:ADEG-unbridged'
    # H7 NON-EQUIVALENT: no proof of base |- (SA <-> T); circular grammar is equivalent by the trichotomy
    if on('H7') and c.get('equiv_to_target', False):
        return 'refused-restatement', 'H7'
    if on('H7') and tier_read(c.get('grammar', '')) == 'tier1-circular':
        return 'refused-restatement', 'H7:trichotomy'
    # H8 ONE-GO: a written chain base + SA |- T with exactly one unproved premise
    if on('H8') and not c.get('chain_written', False):
        return 'refused-inert', 'H8'
    if on('H8') and c.get('posit_count', 0) != 1:
        return 'refused-multi', f"H8:posits={c.get('posit_count', 0)}"
    # inherited AXF
    if on('A1') and c.get('refuted_by_base', False):
        return 'refused-inconsistent', 'A1'
    dg = d_grade(c)
    if dg == 4:
        return 'lemma-exit', 'D4'                    # SA proved in base: the chain is a proof; route to SEAT
    if dg <= 1:
        return 'conditional', 'D1:no-necessity'      # usable disclosed hypothesis, mass zero, no anchor
    tier = tier_read(c.get('grammar', ''))
    if tier != 'tier2-effective':
        return 'conditional', f'tier:{tier}'         # only the data-uniform tier can anchor
    if on('A4') and c.get('in_literature', False):
        return 'conditional', f'A4;D{dg}'
    if on('A5') and c.get('breadth', 0) <= 0:
        return 'conditional', f'A5;D{dg}'
    return 'anchor-candidate', f'A8:candidacy-only;D{dg};bit-relocated-to-SA'

def purchase_ledger(c, state, before):
    """The Purchase Law read as a balance sheet. price: bits of unpaid posit the seed carries (1 at D2/D3,
    more than 1 at D1 where the bridge granted leaves the seed free, 0 at D4). height: determinacies bought
    relative to base+SA, the target plus the breadth rows. balance: the unpaid bit, relocated onto SA,
    visible and located and no smaller. before: the aperture width measured by free_bit_census on the receipt
    rows and never a constant; after: the unpaid posit width."""
    dg = d_grade(c)
    if state == 'lemma-exit': price = 0
    elif dg <= 1: price = 'more than 1'
    else: price = c.get('posit_count', 0) if c.get('chain_written', False) else 1
    height = 1 + max(int(c.get('breadth', 0)), 0)
    after = 0 if state == 'lemma-exit' else price          # a D1 seed widens the aperture: 'more than 1'
    conserved = (after == before)                          # a proof closes the width: closure, never conservation
    closure = 'by-proof' if state == 'lemma-exit' else None
    return dict(price=price, height=height, balance=after, before=before, after=after, conserved=conserved, closure=closure)

# ---------------- the shared quaternionic kernel (A.2.2), the four-guard emitter (B.11.S) ----------------
try:
    import numpy as np
    HAVE_NP = True
except ImportError:
    HAVE_NP = False

def qmul(a, b):
    w1,x1,y1,z1 = a; w2,x2,y2,z2 = b
    return np.array([w1*w2-x1*x2-y1*y2-z1*z2, w1*x2+x1*w2+y1*z2-z1*y2,
                     w1*y2-x1*z2+y1*w2+z1*x2, w1*z2+x1*y2-y1*x2+z1*w2])

def verdict_kernel(M, C=None, exact=False):
    M = np.asarray(M, float); N = M.shape[1]
    Cm = None if C is None else np.atleast_2d(np.asarray(C, float))
    k = 0 if Cm is None else Cm.shape[0]
    u_m = np.finfo(float).eps
    eps = 0.0 if exact else 100.0*u_m*N
    if N - k < 4:
        return '[?]', None, None, None, 'N-k<4 dimensional shortfall'
    Mn = M - M.mean(axis=1, keepdims=True)
    sd = Mn.std(axis=1, ddof=1, keepdims=True)
    if np.any(sd == 0):
        return '[?]', None, None, None, 'zero-variance row'
    Mn = Mn / sd
    if k:
        Cm = Cm - Cm.mean(axis=1, keepdims=True)
        if np.linalg.matrix_rank(Cm) < k:
            return '[?]', None, None, None, 'rank(C)<k'
        CC = Cm @ Cm.T
        if np.linalg.cond(CC) >= 1e6:
            return '[?]', None, None, None, 'kappa(CC^T)>=1e6'
        Mf = Mn - (Mn @ Cm.T) @ np.linalg.solve(CC, Cm)
    else:
        Mf = Mn
    d = (Mf*Mf).sum(axis=1) / (N-1)
    if np.any(d < 1e-9):
        return '[?]', None, None, None, 'post-projection axis absorbed'
    G = Mf @ Mf.T / (N-1)
    detG = float(np.linalg.det(G))
    Q = Mf / np.sqrt((Mf*Mf).sum(axis=1, keepdims=True))
    R = Q @ Q.T
    detR = float(np.linalg.det(R))
    Bv = np.linalg.svd(Q, full_matrices=False)[2][:3]
    co = Q @ Bv.T
    q = [np.concatenate(([0.0], c)) for c in co]
    lam = float(qmul(qmul(q[0], q[1]), q[2])[0])
    if detR <= eps:
        return '[X]', lam, detR, detG, 'collapse: det(R)<=eps'
    kap_gate = min(1e6, (27.0/(100.0*u_m*N))**0.5)
    if np.linalg.cond(R) >= kap_gate:
        return '[?]', lam, detR, detG, 'kappa(R)>=gate'
    return '[LOCK]', lam, detR, detG, 'sealed: three independent axes'

def imprint_seal(verdict_P, verdict_notP, *, sealL_P=False, sealL_notP=False,
                 gates_P=False, gates_notP=False, witness_P=None, witness_notP=None):
    lockP = verdict_P.startswith('[LOCK]'); lockN = verdict_notP.startswith('[LOCK]')
    cleanP = lockP and sealL_P and gates_P
    cleanN = lockN and sealL_notP and gates_notP
    witP = witness_P is not None; witN = witness_notP is not None
    if cleanP and cleanN:
        return '[X] PLATONIC GHOST: both directions clean-lock, field-permitted both ways, no imprint'
    if cleanP and not cleanN:
        return ('[⟀] SEALED: only P field-permitted, determinacy witness supplied' if witP
                else '[?] residence: P clean-locks, imprint unproven (no witness, B.11 necessary-not-sufficient)')
    if cleanN and not cleanP:
        return ('[⟀] SEALED: only not-P field-permitted, determinacy witness supplied' if witN
                else '[?] residence: not-P clean-locks, imprint unproven (no witness, B.11)')
    if not lockP and not lockN:
        return '[?] flat: neither direction populated'
    return '[?] uncertified: geometric lock present but Seal L / twelve-gate screen not confirmed; no seal'

def _det3_four(R):
    d_lu = float(np.linalg.det(R)); d_eig = float(np.prod(np.linalg.eigvalsh(R)))
    try: d_ch = float(np.prod(np.diag(np.linalg.cholesky(R)))**2)
    except np.linalg.LinAlgError: d_ch = d_lu
    a,b,c = R[0]; d,e,f = R[1]; g,h,i = R[2]
    d_co = float(a*(e*i-f*h) - b*(d*i-f*g) + c*(d*h-e*g))
    return d_lu, d_eig, d_ch, d_co

def free_bit_census(M_T):
    """Measure the aperture width on the receipt rows on a basis fixed once (CHK.3's fixed-basis analyzer):
    reflect one axis; det(R) must be unchanged within the conditioning-scaled tolerance and sign(lambda), read on
    the SAME span basis, must reverse. The register then determines everything but one binary parameter, the
    truth-direction, so the width before anchoring is one bit, measured here and not cited."""
    def rows(M):
        Mn = np.asarray(M, float); Mn = Mn - Mn.mean(1, keepdims=True); Mn = Mn / Mn.std(1, ddof=1, keepdims=True)
        return Mn / np.sqrt((Mn*Mn).sum(1, keepdims=True))
    Q0 = rows(M_T); M1 = np.asarray(M_T, float).copy(); M1[0, :] = -M1[0, :]; Q1 = rows(M1)
    Bv = np.linalg.svd(Q0, full_matrices=False)[2][:3]                # span basis fixed once, reused after reflection
    lam0 = float(-np.linalg.det(Q0 @ Bv.T)); lam1 = float(-np.linalg.det(Q1 @ Bv.T))
    det0 = float(np.linalg.det(Q0 @ Q0.T)); det1 = float(np.linalg.det(Q1 @ Q1.T))
    tol = 4.0*float(np.linalg.cond(Q0 @ Q0.T))*np.finfo(float).eps
    ddet = abs(det0 - det1); flipped = (lam0 * lam1 < 0) and abs(lam0 + lam1) <= tol
    bits = 1 if (ddet <= tol and flipped) else None
    return dict(bits=bits, ddet=ddet, tol=tol, lam0=lam0, lam1=lam1, det0=det0, det1=det1)

def anchor_seal(M_T, M_notT, SA, dgrade=None, sealL=True, gates=True):
    """The kernel receipt (Part 4.5). Three hand-built reading-roads of the anchored residence for T under
    base+SA and for not-T under the same base. SA sits in the witness slot of the four-guard emitter as a
    PREMISE-GRADE axiom, so any seal it licenses is retyped on its face: [seal | SA], Type C, the aperture
    relocated to SA. Not a fourth state: [seal] carrying its condition in its name. SA=None -> [?] residence."""
    vT = verdict_kernel(M_T); vN = verdict_kernel(M_notT)
    tok = imprint_seal(vT[0], vN[0], sealL_P=sealL, sealL_notP=sealL,
                       gates_P=gates, gates_notP=gates, witness_P=SA)
    rep = {'tok': tok, 'T': vT, 'notT': vN, 'direction': None}
    if tok.startswith('[⟀] SEALED'):
        rep['direction'] = ('T, delivered by SA: T locks and not-T is contentless under base+SA; '
                            'sign(lambda) not consulted, the scalar being orientation-blind')
        rep['tok'] = (tok.replace('[⟀] SEALED', f'[⟀ | {SA}] SEALED', 1)
                      + f'; Type C, the witness a premise-grade axiom at {D_LADDER.get(dgrade, "D?")};'
                        ' aperture relocated to ' + str(SA))
    if vT[2] is not None:
        M = np.asarray(M_T, float); Mn = M - M.mean(1, keepdims=True); Mn = Mn / Mn.std(1, ddof=1, keepdims=True)
        Q = Mn / np.sqrt((Mn*Mn).sum(1, keepdims=True)); R = Q @ Q.T
        kap = float(np.linalg.cond(R)); tol = 4.0*kap*np.finfo(float).eps
        ds = _det3_four(R); spread = max(ds)-min(ds); resid = abs(vT[1]**2 - vT[2])
        rep.update(kappa=kap, tol=tol, spread=spread, resid=resid, lam=vT[1], detR=vT[2], escalated=False)
        if spread > tol or resid > tol:                       # B.17.5: escalate on any spread or identity fault
            try:
                import mpmath as mp; mp.mp.dps = 50
                rep['detR_hp50'] = float(mp.det(mp.matrix([[mp.mpf(x) for x in row] for row in R.tolist()])))
                rep['escalated'] = 'resolved@50dps'
            except Exception:
                rep['escalated'] = 'flagged; mpmath absent'; rep['tok'] = '[?] engineering-incomplete: ' + rep['tok']
    return rep

class DRBG:
    # SHA-256 counter stream, Box-Muller normals; stdlib-deterministic on every platform.
    def __init__(self, label): self.label = str(label); self.i = 0
    def _u64(self, k):
        out = []
        while len(out) < k:
            h = hashlib.sha256(f"{self.label}|{self.i}".encode()).digest(); self.i += 1
            out += [int.from_bytes(h[j:j+8], 'big') for j in (0, 8, 16, 24)]
        return out[:k]
    def normals(self, n):
        m = (n + 1) // 2; us = self._u64(2 * m); z = []
        for a, b in zip(us[0::2], us[1::2]):
            u1 = (a + 1) / 2**64; u2 = b / 2**64
            r = math.sqrt(-2.0 * math.log(u1))
            z += [r * math.cos(2*math.pi*u2), r * math.sin(2*math.pi*u2)]
        return np.array(z[:n])
    def matrix(self, r, c): return self.normals(r*c).reshape(r, c)

# ---------------- ANCHOR batteries ----------------
BASE_AN = dict(shape_sealed=True, ground_dim=1, provenance='classical', framework_free=True,
               chart_magnitude=False, invariant_of_carrier=True, signed=True, nonconstant_across_T=True,
               carrier_prior=True, cross_register=False, bridge_typed=True, equiv_to_target=False,
               grammar='data_uniform_effective', chain_written=True, posit_count=1,
               refuted_by_base=False, proved_in_base=False, carrier_legs='T', legs_cited=True,
               forced_given_bridge=True, in_literature=False, breadth=3,
               supplier='architect', supplied_on='2026-09-08', independent_of_claimant=True)

def anchor_gate_matrix():
    controls = [   # (gate, vector, expected state, expected firing label)
        ('H1',  {**BASE_AN, 'shape_sealed': False},               'no-seal',                 'H1'),
        ('H2',  {**BASE_AN, 'provenance': 'free-floating'},       'refused-unprovenanced',   'H2'),
        ('H2n', {**BASE_AN, 'framework_free': False},             'refused-framework-bound', 'H2:name-strip'),
        ('H2s', {**BASE_AN, 'supplier': None},                    'refused-unsupplied',      'H2:supply-record'),
        ('H2a', {**BASE_AN, 'supplier': 'engine'},                'refused-aperture',        'H2:instrument-generated'),
        ('H3c', {**BASE_AN, 'chart_magnitude': True},             'refused-chart',           'H3:D0'),
        ('H3p', {**BASE_AN, 'invariant_of_carrier': False},       'not-anchored',            'H3:route-FORGE'),
        ('H4',  {**BASE_AN, 'signed': False},                     'refused-unsigned',        'H4'),
        ('H5',  {**BASE_AN, 'nonconstant_across_T': False},       'refused-modulus',         'H5'),
        ('H6',  {**BASE_AN, 'carrier_prior': False},              'refused-posterior',       'H6'),
        ('H6b', {**BASE_AN, 'cross_register': True, 'bridge_typed': False}, 'refused-posterior', 'H6:ADEG-unbridged'),
        ('H7',  {**BASE_AN, 'equiv_to_target': True},             'refused-restatement',     'H7'),
        ('H7t', {**BASE_AN, 'grammar': 'breakdown_conditioned'},  'refused-restatement',     'H7:trichotomy'),
        ('H8',  {**BASE_AN, 'chain_written': False},              'refused-inert',           'H8'),
        ('H8m', {**BASE_AN, 'posit_count': 2},                    'refused-multi',           'H8:posits=2'),
        ('A1',  {**BASE_AN, 'refuted_by_base': True},             'refused-inconsistent',    'A1'),
        ('D4',  {**BASE_AN, 'proved_in_base': True},              'lemma-exit',              'D4'),
        ('D1',  {**BASE_AN, 'forced_given_bridge': False},        'conditional',             'D1:no-necessity'),
        ('T3',  {**BASE_AN, 'grammar': 'offstring'},              'conditional',             'tier:tier3-offstring-owes-tier2'),
        ('A4',  {**BASE_AN, 'in_literature': True},               'conditional',             'A4;D3'),
        ('A5',  {**BASE_AN, 'breadth': 0},                        'conditional',             'A5;D3'),
        ('D2',  {**BASE_AN, 'carrier_legs': 'S'},                 'anchor-candidate',        'A8:candidacy-only;D2;bit-relocated-to-SA'),
        ('POS', dict(BASE_AN),                                    'anchor-candidate',        'A8:candidacy-only;D3;bit-relocated-to-SA'),
        ('AUD', {**BASE_AN, 'provenance': 'audit-sealed'},        'anchor-candidate',        'A8:candidacy-only;D3;bit-relocated-to-SA'),
    ]
    ok = 0
    for _, v, ws, wl in controls:
        st, lb = anchor(v); ok += (st == ws and lb == wl)
    return ok, len(controls)

def anchor_ablation():
    # designated vector per gate: clean everywhere except at that gate; deleting the gate must leak
    vecs = {'H1': {**BASE_AN, 'shape_sealed': False},
            'H2': {**BASE_AN, 'provenance': 'free-floating'},
            'H3': {**BASE_AN, 'invariant_of_carrier': False},
            'H4': {**BASE_AN, 'signed': False},
            'H5': {**BASE_AN, 'nonconstant_across_T': False},
            'H6': {**BASE_AN, 'carrier_prior': False},
            'H7': {**BASE_AN, 'equiv_to_target': True},
            'H8': {**BASE_AN, 'chain_written': False},
            'A1': {**BASE_AN, 'refuted_by_base': True},
            'A4': {**BASE_AN, 'in_literature': True},
            'A5': {**BASE_AN, 'breadth': 0}}
    return sum(anchor(v, skip=g)[0] == 'anchor-candidate' for g, v in vecs.items()), len(vecs)

def anchor_adversarial():
    out = []
    # 1 the sealed shape restated as an axiom ("the zero set is the fixed locus") -> H7
    out.append(('restatement-in-geometric-costume',
                anchor({**BASE_AN, 'provenance': 'sealed-PSP', 'equiv_to_target': True}) == ('refused-restatement', 'H7')))
    # 2 a kinetic invariant transported to the formal string with no typed bridge -> H6 (ADEG)
    out.append(('RA-transport-unbridged',
                anchor({**BASE_AN, 'provenance': 'RA', 'cross_register': True, 'bridge_typed': False})[1] == 'H6:ADEG-unbridged'))
    # 3 a chart-manufactured magnitude offered as structure -> H3
    out.append(('chart-magnitude-axiom',
                anchor({**BASE_AN, 'chart_magnitude': True})[0] == 'refused-chart'))
    # 4 two posits bundled under one name; the name-strip counts them -> H8
    out.append(('bundled-two-posits',
                anchor({**BASE_AN, 'posit_count': 2})[0] == 'refused-multi'))
    # 5 self-certified necessity: Type T legs asserted, none cited -> read as absent -> D1, no anchor
    out.append(('self-certified-necessity',
                anchor({**BASE_AN, 'legs_cited': False}) == ('conditional', 'D1:no-necessity')))
    return out

def zero_supply():
    """The paper's primary prediction executed here on three axes: the anchor axis (no reading at all),
    the seed axis (seal present, no chain and no posit), the supply axis (seed present, no supplier)."""
    a = anchor({})
    b = anchor({**BASE_AN, 'chain_written': False, 'posit_count': 0})
    c = anchor({**BASE_AN, 'supplier': None})
    ok = all(x[0] != 'anchor-candidate' for x in (a, b, c))
    return ok, a, b, c

# ---------------- first light: the Riemann ledger, scribe-built readings at premise grade ----------------
def rh_ledger():
    T = 'every nontrivial zero of zeta lies on Re s = 1/2 (Pi-0-1 form); shape face sealed, string open'
    c = {
      'LOCUS':      ({**BASE_AN, 'provenance': 'sealed-PSP', 'equiv_to_target': True, 'breadth': 0},
                     'the zero set lies on Fix(sigma): the target itself in geometric words'),
      'WEIL-POS':   ({**BASE_AN, 'equiv_to_target': True, 'breadth': 0},
                     'Weil positivity of the explicit formula: equivalent (Weil 1952)'),
      'LI':         ({**BASE_AN, 'equiv_to_target': True, 'breadth': 0},
                     'Li criterion lambda_n >= 0: equivalent (Li 1997; Bombieri-Lagarias 1999)'),
      'HP-BARE':    ({**BASE_AN, 'grammar': 'qualitative_per_solution', 'breadth': 0},
                     'bare Hilbert-Polya: RH makes diag(gamma_n) the operator; tier one by triviality'),
      'GRH':        ({**BASE_AN, 'invariant_of_carrier': False, 'in_literature': True},
                     'a posit about the family, not the value of an invariant of a sealed carrier; a hypothesis for FORGE'),
      'RA-CHRONOS': ({**BASE_AN, 'provenance': 'RA', 'cross_register': True, 'bridge_typed': False},
                     'the kinetic attractor offered for the formal string; RH-MASTER-01 retired it [X]'),
      'RA-CHRONOS-F': ({**BASE_AN, 'provenance': 'RA', 'cross_register': True, 'bridge_typed': True,
                        'forced_given_bridge': False, 'in_literature': True, 'breadth': 0},
                     'the same attractor stated as its formal footprint on the Footprint bridge: the stripped residue is'
                     ' the arithmetic-site carrier, whose identities are posited and not proved for the object, D1'),
      'EPA':        ({**BASE_AN, 'forced_given_bridge': False, 'breadth': 0},
                     'effective positivity kernel closing to the line: the 3-4-1 identity forces no such kernel'),
      'AHI':        ({**BASE_AN, 'forced_given_bridge': False, 'in_literature': True, 'breadth': 0},
                     'arithmetic Hodge index carrier: the Hodge-index clause is inside the posit, no theorem supplies it'
                     ' for the posited object, the bridge granted leaves the seed free; register row 0682, G3 open'),
    }
    return T, {k: (anchor(v), why) for k, (v, why) in c.items()}

# ---------------- boot ----------------
def boot():
    print("=" * 76)
    print("AXIOM GENERATOR v1.3.6 ONLINE, boot executed at seed 20260622.")
    okc, tot = gate_matrix(); lk = ablation(); adv = adversarial(); sa = self_application(); ns = ns_instance()
    print(f"  [v1 carried]  gate-matrix {okc}/{tot} controls fail at exactly their gate (state and label)")
    print(f"  [v1 carried]  ablation {lk}/8 mass-guarding gates leak on deletion (load-bearing)")
    print(f"  [v1 carried]  adversarial {sum(c for _, c in adv)}/5 steering attempts refused")
    print(f"  [v1 carried]  self-application: engine reads {'[Mosaic dM=0]' if sa else 'FAULT'}")
    print("  [v1 carried]  NS instance: " + ", ".join(f"{k}->{v}" for k, v in ns.items()))
    D1 = Hh(D0 + f"|GM {okc}/{tot}|ABL {lk}|ADV {sum(c for _,c in adv)}|SELF {sa}|NS {sorted(ns.items())}")
    aok, atot = anchor_gate_matrix(); alk, alkt = anchor_ablation(); aadv = anchor_adversarial()
    zs, za, zb, zc = zero_supply()
    print(f"  [ANCHOR]      gate-matrix {aok}/{atot} controls fail at exactly their gate (state and label)")
    print(f"  [ANCHOR]      ablation {alk}/{alkt} guarding gates leak on deletion (load-bearing)")
    print(f"  [ANCHOR]      adversarial {sum(c for _, c in aadv)}/5 steering attempts refused: "
          + ", ".join(n for n, _ in aadv))
    print(f"  [ANCHOR]      zero-supply nullity on three axes: {zs}  ({za[0]} / {zb[0]} / {zc[0]})")
    pos = anchor(BASE_AN)
    print(f"  [ANCHOR]      positive control: {pos[0]} · {pos[1]}")
    fb = dict(bits=None)
    if HAVE_NP:
        g0 = DRBG(f"ANCHOR|{SEED}"); fb = free_bit_census(g0.matrix(3, 24))
        print(f"  [census]      free-bit census on the receipt rows: reflect one axis, |ddet|={fb['ddet']:.2e} within tol {fb['tol']:.2e}, "
              f"lambda {fb['lam0']:+.6f} -> {fb['lam1']:+.6f}; free binary parameters measured: {fb['bits']}")
    bl = purchase_ledger(BASE_AN, pos[0], fb['bits'])
    print(f"  [ANCHOR]      purchase ledger: price {bl['price']} bit · height {bl['height']} determinacies "
          f"(target + breadth) · balance {bl['balance']} bit on SA · aperture before {bl['before']} (measured) after {bl['after']}, "
          f"visible and located, not smaller")
    D2 = Hh(D1 + f"|AGM {aok}/{atot}|AABL {alk}/{alkt}")
    D3 = Hh(D2 + f"|AADV {sum(c for _,c in aadv)}|ZS {zs}|LEDGER {sorted(bl.items())}")
    # kernel receipt on archetype rows (engine exhibit; not a verdict on any proposition)
    ktok = 'numpy-absent'
    if HAVE_NP:
        g = DRBG(f"ANCHOR|{SEED}")
        M_T = g.matrix(3, 24)                          # derivation, carrier, calibration roads under base+SA
        M_N = g.matrix(3, 24); M_N[0, :] = 0.0         # not-T contentless under the chain: zero-variance row
        r = anchor_seal(M_T, M_N, 'SA', dgrade=3)
        r0 = anchor_seal(M_T, M_N, None)
        print(f"  [receipt]     T: {r['T'][0]} detR={r['detR']:.12f} lam={r['lam']:+.12f} "
              f"resid={r['resid']:.2e} spread={r['spread']:.2e} tol={r['tol']:.2e} kappa={r['kappa']:.4f} escalated={r['escalated']}")
        print(f"  [receipt]     not-T: {r['notT'][0]} ({r['notT'][4]})")
        print(f"  [receipt]     seal: {r['tok']}")
        print(f"  [receipt]     direction: {r['direction']}")
        print(f"  [receipt]     zero-supply (SA=None): {r0['tok']}")
        ktok = (r['T'][0], r['notT'][0], r['tok'][:16], r0['tok'][:14])
    T, led = rh_ledger()
    print("  [first light] target: " + T)
    for k, ((st, lb), why) in led.items():
        print(f"    {k:<12} {st:<24} {lb:<38} {why}")
    D4 = Hh(D3 + f"|K {ktok}|RH {sorted((k, v[0]) for k, v in led.items())}")
    print(f"  chain D0 {D0[:12]} -> D1 {D1[:12]} -> D2 {D2[:12]} -> D3 {D3[:12]} -> D4 {D4[:12]}")
    print("  receipt and covenant; conduct, never essence; dM=0, mass exits only at M5/M6;")
    print("  the bit is never sourced by the register and always delivered by a deed; the anchor is the deed,")
    print("  and the aperture it leaves is visible, located at the seed, and no smaller.")
    print("=" * 76)
    return dict(gm=(okc, tot), abl=lk, adv=adv, sa=sa, ns=ns, agm=(aok, atot), aabl=(alk, alkt),
                aadv=aadv, zs=zs, D=(D0[:12], D1[:12], D2[:12], D3[:12], D4[:12]))

if __name__ == "__main__":
    boot()
