# Perelmanification Hunt v1.0.0_CC · axiom cycle pmf1 · 23 October 2026

Task 2 of the Millennium synthesis: can the one-bit posit, unified across the seven rows and subsuming Perelman's witness,
be upgraded to a standard axiom so the whole arc reads unconditional theorem grade; and is the bit already a theorem?

Verdict: HALT-OWNED, ΔM = 0, held at the FORGE gate (mode one). Read `Perelmanification_PreForge_Digest_v1_0_0_CC.md` first.

| Path | What |
|---|---|
| `Perelmanification_PreForge_Digest_v1_0_0_CC.md` | the digest: shape gate per face, kernel receipts, rounds, candidate census, search record, M-cascade, seat delta, apertures, the Ground judgement |
| `lean/One_Bit_Perelmanification_Hunt_v1_0_0_CC.lean` | the hunt kernel (27 theorems, 27 pinned cones, no axiom, no sorry); same file as `lean/Hunt/Perelmanification.lean` |
| `lean/Hunt/` | the module tree it compiles against: RH master v3.0.39_CC, P≠NP v1.13.0_CC Part A, the five v1.1.0_CC row masters, three Mathlib bindings, each byte-identical to its source (`lean/SOURCES.sha256`) |
| `lean/build.sh` | rebuild: each original in its own environment, then the hunt; any cone drift fails a `#guard_msgs` |
| `lean/specs/One_Bit_Hunt_Chain_Specifications_v1_0_0_CC.lean` | the derivation register: chain specifications (with `sorry`, by design) for the five gate-passing children, One-Go census one each |
| `ledger/axcycle_pmf1/` | the append-only ledger: cycle, atoms, candidates, findings, searches, rounds, sealed controls |
| `ledger/grind_r*.md`, `ledger/grind_json/`, `ledger/screen_r*.*`, `ledger/face_typing.*` | grind texts (leak-scanned clean), structured grinds, screen readings, the per-face typing |
| `engines/` | the four engines as extracted from their skills, and their boot receipts with the ledger status |

Nothing here is pushed or published. Seating, indexing and pushing are the Architect's acts under the confirmation gate.
