# The Millennium Problems · Synthesis v1.0.0_CC · 23 October 2026

One paper, one master Lean, one method, one supplement. Nothing here is pushed or published; seating, indexing and
pushing are the Architect's acts under the confirmation gate (see `PUSH_NOTES.md`).

**The paper.** *The Millennium Problems: Unconditional Proof of the Form by Theorem, the Value by the Act.* Seven
Questions Closed to One Bit Each, One Normal Form Proved Once over All Seven, Every Bit Pinned to Its Library Statement,
Seven Bits on One Footing in the Kernel, the Poincaré Precedent Claimed for All Seven; Bound in One Master in Lean 4.
Math Journal, two columns, 288 pages: the paper in 23, with eight figures and nine tables, the method of the series
proved as one theorem and run on the rows in its Section 4, and Appendix M, the whole master printed, all eighteen
files, root first and then every module in build order, in 265.

**The master.** `Millennium_Grand_Master_v1_0_0_CC.lean` and its tree of seventeen modules: the eight original masters
of the series (RH v3.0.39_CC, P ≠ NP v1.13.0_CC, the six v1.1.0_CC row masters NS, YM, Hodge, BSD, Poincaré, Goldbach),
the four v1.1.0_CC Mathlib bindings, the three kernels of Appendix R, the shared fTOE module and the hunt kernel.
2,967 theorems, 2,778 cones pinned by `#guard_msgs`, no axiom declared, no `sorry`. Nineteen provenance certificates,
all passing from the bytes; the nineteenth certifies that the root's Part S.8 carries the method's Part M verbatim.

**The method.** *The One-Bit Method* v1.0.0_CC, Math Journal, 8 pages, with its executable form
`One_Bit_Method_v1_0_0_CC.lean` (core Lean, no import, 29 theorems, every cone empty and pinned). Its Part M is carried
verbatim in the master's root, which runs it on the rows; the paper's Section 4 carries the method's force whole.

**Supplement S1.** The Perelmanification hunt: Pre-Forge digest, append-only ledger of cycle pmf1, hunt kernel, engines.
Verdict HALT-OWNED, ΔM = 0.

| Path | What |
|---|---|
| `paper/Millennium_Synthesis_v1_0_0_CC.pdf` | the paper, Math Journal edition |
| `paper/Millennium_Synthesis_v1_0_0_CC.md` | its Markdown master; carries all eighteen files of the master's tree at their paths, `certify.py`, the certificate and the manifest in a machine-readable block at its foot (`mkdir -p Millennium`, then the one-line `awk` extraction in the block's header, rebuilds the exact tree) |
| `paper/figs/` | the eight figures, SVG with subset fonts embedded, PDF and PNG |
| `method/One_Bit_Method_v1_0_0_CC.pdf`, `.md`, `.lean` | the method, its Markdown master, its executable form |
| `lean/src/` | the master's tree: `Millennium/*.lean` (seventeen modules) and the root |
| `lean/build.sh` | compile the tree against a Lake project pinned to Lean 4.19.0 and Mathlib v4.19.0 |
| `lean/certify.py`, `lean/originals/`, `lean/cert/` | the certificates, the seventeen originals they read (the sixteen masters and kernels, and the method's executable form), and their output (`CERTIFICATE.txt`, `census.json`, `assembly.json`) |
| `lean/BUILD_RECEIPT_fresh_extract.txt` | the build of this tree from a fresh extract of this bundle: every module exit 0, BUILD PASS |
| `supplement_S1/` | the Perelmanification hunt, as delivered |
| `tools/` | the figure builder, the index builder, the Markdown and PDF builders, the template, the render checks and the name check |
| `MANIFEST.sha256` | SHA-256 of every file in this folder |

**Verify.** `sha256sum -c MANIFEST.sha256`. Then, with a Mathlib v4.19.0 project at `$ML`:
`bash lean/build.sh $ML` (about 12 minutes; the RH master takes 7) and `python3 lean/certify.py lean/src lean/originals lean/cert`.
The method compiles alone: `lean method/One_Bit_Method_v1_0_0_CC.lean` (under a second, silent).

**Receipts, this build.** Every module exit 0, no error, no warning; RH prints its own 259 unpinned axiom reports, every
other module and the root compile silent. Root: 39 theorems, 30 on no axiom and 9 on Lean's standard axioms, 53 pins.
Certificates: 19 of 19 PASS. Fresh extract of this bundle: BUILD PASS, certificates 19 of 19. Paper: 288 pages; render probe end, conclusion and references present, no missing glyph,
no overfull box, no bleed, no ink outside the text block; 238 distinct theorem names, every one a declaration of the
tree with a pinned cone. Method: 8 pages, same probe, all pass.
