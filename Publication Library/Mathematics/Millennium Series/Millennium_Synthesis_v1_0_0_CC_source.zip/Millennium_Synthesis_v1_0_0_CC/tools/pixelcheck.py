#!/usr/bin/env python3
"""pixelcheck.py PDF [PDF ...] · the rendered page, read as ink: no mark in the margins outside the running foot, and no
mark in the column gutter outside a full-width float. Catches what a text scan cannot: rules, glyph overhang, graphics.
Reports page, region and the extent of the ink; exit 1 if any."""
import sys
import numpy as np
import pymupdf

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from bleedcheck import regions, L, R, T, B, C1R, C2L

DPI = 144
S = DPI / 72.0


def ink(gray, x0, x1, y0, y1):
    a = gray[int(y0 * S):int(y1 * S), int(x0 * S):int(x1 * S)]
    if a.size == 0:
        return None
    m = a < 150
    if not m.any():
        return None
    ys, xs = np.nonzero(m)
    return (round(x0 + xs.min() / S, 1), round(x0 + xs.max() / S, 1), round(y0 + ys.min() / S, 1),
            round(y0 + ys.max() / S, 1))


def check(path):
    doc = pymupdf.open(path)
    out = []
    for pno, page in enumerate(doc, 1):
        pix = page.get_pixmap(dpi=DPI, colorspace=pymupdf.csGRAY)
        g = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width)
        W, H = page.rect.width, page.rect.height
        for name, box in (("LEFT", (0, L - 1.0, 0, H)), ("RIGHT", (R + 1.0, W, 0, H)),
                          ("TOP", (0, W, 0, T - 12.0)), ("BOTTOM", (0, W, B + 4.5, 748.0))):
            hit = ink(g, *box)
            if hit:
                out.append((pno, name, hit))
        figs, tables = regions(page)
        # gutter rows not covered by a full-width float or a full-width table
        rows = np.ones(int(H * S), dtype=bool)
        for r in figs:
            rows[max(0, int((r.y0 - 2) * S)):int((r.y1 + 2) * S)] = False
        for a, b in tables:
            rows[max(0, int(a * S)):int(b * S)] = False
        if pno == 1:  # the title block and the abstract span the page down to the first line of column two
            starts = [ln["bbox"][1] for blk in page.get_text("dict")["blocks"] for ln in blk.get("lines", [])
                      if C2L - 0.5 <= ln["bbox"][0] <= C2L + 30]
            if starts:
                rows[:int((min(starts) - 2) * S)] = False
        gx0, gx1 = int((C1R + 1.0) * S), int((C2L - 1.0) * S)
        band = g[:, gx0:gx1] < 150
        band[~rows[:band.shape[0]], :] = False
        band[:int(T * S), :] = False
        band[int(B * S + 6):, :] = False
        if band.any():
            ys, xs = np.nonzero(band)
            out.append((pno, "GUTTER", (round(C1R + 1 + xs.min() / S, 1), round(C1R + 1 + xs.max() / S, 1),
                                        round(ys.min() / S, 1), round(ys.max() / S, 1))))
    return out


if __name__ == "__main__":
    bad = 0
    for p in sys.argv[1:]:
        res = check(p)
        print(f"{p.split('/')[-1]}: {len(res)} ink outside the text block")
        for r in res:
            print("   ", r)
        bad += len(res)
    sys.exit(1 if bad else 0)
