#!/usr/bin/env python3
"""rowfigs.py · the seven figures of each Millennium-row paper, edition 1.1.0_CC.

Usage: rowfigs.py ROW [n ...]   (ROW in GB PC BSD YM NS HODGE; the row's text lives in cfg_<row>.py)

Carried from the RH v1.3.0_CC and P ≠ NP v1.13.0_CC figure builders. Every monospace identifier is resolved against the
index of the row's master v1.1.0_CC and its Mathlib binding and colored by its pinned cone: green = theorem on no axiom,
teal = theorem on propext or on propext and Quot.sound, blue = theorem on Lean's standard axioms, slate = definition or
structure. An unresolved name, an ambiguous name, or a theorem without a pinned cone halts the build. Each figure is a
self-contained SVG with subset fonts embedded, 1100 px wide."""
import base64, importlib, io, json, os, re, string, sys
from html import escape
from PIL import ImageFont
from fontTools import subset
from fontTools.ttLib import TTFont
import logging
logging.getLogger("fontTools").setLevel(logging.ERROR)

HERE = os.path.dirname(os.path.abspath(__file__))
ROW = 'SYNTH'
CFG = dict(ns='MillenniumGrandMaster', record_ns='PerelmanHunt', binding_ns='BoundChainMathlib', header_right='MILLENNIUM SYNTHESIS · v1.0.0_CC',
           short='The Millennium Problems', stem='Millennium_Synthesis')
IDX = json.load(open(f'{HERE}/index_SYNTH.json', encoding='utf-8'))
OUTDIR = f'{HERE}/out_SYNTH'

FD = "/usr/share/fonts/truetype/dejavu/"
FONTFILE = {("s", 400): FD + "DejaVuSans.ttf", ("s", 700): FD + "DejaVuSans-Bold.ttf",
            ("m", 400): FD + "DejaVuSansMono.ttf", ("m", 700): FD + "DejaVuSansMono-Bold.ttf"}
FAMILY = {"s": "RowSans, 'DejaVu Sans', Verdana, Arial, sans-serif",
          "m": "RowMono, 'DejaVu Sans Mono', Menlo, Consolas, monospace"}
_PIL = {k: ImageFont.truetype(v, 100) for k, v in FONTFILE.items()}

NAVY, NAVY2, SUB = "#0e2a47", "#1d4066", "#c8d8e8"
BG, INK, BODY, GREY, ARROW, LINE = "#f7f9fa", "#10222e", "#24333d", "#5a6a76", "#33475b", "#c3d2dc"
G, G_T, G_D = "#177e6c", "#e7f4f0", "#0f5c4e"
B, B_T, B_D = "#2f5aa8", "#e9f0fb", "#1e447c"
R, R_T, R_D = "#b3261e", "#fdecea", "#7f1d17"
A, A_T, A_D = "#b7791f", "#fdf3e0", "#7a4a12"
V, V_T, V_2, V_D = "#5b4bc4", "#f1edfd", "#d9d2f7", "#3c3550"
T, T_T, T_D = "#0e7490", "#e4f3f7", "#0b5468"
SLATE, WHITE, GOLD = "#33566e", "#ffffff", "#ffd98a"

W, M = 1100, 22
CW = W - 2 * M
E, USED, CHECKED = [], {}, {}
NB = " "
NEW_NS = CFG['ns'] + '.'
REC_NS = CFG['record_ns'] + '.'
BIND_NS = (CFG.get('binding_ns') or '##') + '.'


# ---------------------------------------------------------------- names and cones
def resolve(name):
    short = name.split(".")[-1]
    ds = IDX["decl"].get(short) or []
    if "." in name:
        ds = [d for d in ds if d[0] == name or d[0].endswith("." + name)]
    if not ds:
        raise SystemExit(f"[{ROW}] NOT A DECLARATION OF THE MASTER OR THE BINDING: {name}")
    for pref in (NEW_NS, REC_NS, BIND_NS):
        tier = [d for d in ds if d[0].startswith(pref)]
        if tier:
            if len({d[0] for d in tier}) > 1:
                raise SystemExit(f"[{ROW}] AMBIGUOUS NAME {name}: {[d[0] for d in tier]}")
            ds = tier
            break
    if len({d[0] for d in ds}) > 1:
        raise SystemExit(f"[{ROW}] AMBIGUOUS NAME {name}: {[d[0] for d in ds]}")
    full, line_, kind, where = ds[0]
    cone = IDX["cone"].get(full)
    CHECKED[name] = (full, kind, cone, line_, where)
    return full, kind, cone


def id_color(name):
    full, kind, cone = resolve(name)
    if kind not in ("theorem", "lemma"):
        return SLATE
    if cone is None:
        raise SystemExit(f"[{ROW}] THEOREM WITHOUT A PINNED CONE: {full}")
    return {"∅": G, "p": T, "pQ": T, "std": B}[cone]


# ---------------------------------------------------------------- text
def tw(s, fam="s", wt=400, size=13.0):
    return _PIL[(fam, wt)].getlength(s) * size / 100.0


def glue(s):
    s = re.sub(r"\((−?\d+), (−?\d+)\)", lambda m: "(" + m.group(1) + "," + NB + m.group(2) + ")", s)
    s = re.sub(r" (≠|∉|∈|≥|≤|<|>|=|\+|→|↔|∧|×) ", lambda m: NB + m.group(1) + NB, s)
    s = re.sub(r"(Part|Parts|Step|Steps|Gate|Figure|Section|order|dimension|degree) (\d)",
               lambda m: m.group(1) + NB + m.group(2), s)
    return s


def wrap(s, maxw, fam="s", wt=400, size=13.0, ls=0.0):
    words, lines, cur = glue(s).split(" "), [], ""
    width = lambda t: tw(t, fam, wt, size) + ls * len(t)
    for w_ in words:
        t = (cur + " " + w_) if cur else w_
        if width(t) <= maxw or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = w_
    if cur:
        lines.append(cur)
    for l in lines:
        if width(l) > maxw + 0.5:
            raise SystemExit(f"[{ROW}] UNWRAPPABLE LINE ({width(l):.0f} > {maxw:.0f}): {l}")
    return lines


def id_lines(ids, maxw, size=11.2, wt=400):
    sep = " · "
    lines, cur, curw = [], [], 0.0
    for n in ids:
        col = id_color(n)
        shown = n.split(".")[-1]
        wpiece = tw(shown, "m", wt, size)
        if wpiece > maxw + 0.5:
            raise SystemExit(f"[{ROW}] IDENTIFIER WIDER THAN ITS BOX: {n}")
        wsep = tw(sep, "m", wt, size) if cur else 0.0
        if cur and curw + wsep + wpiece > maxw:
            lines.append(cur)
            cur, curw, wsep = [], 0.0, 0.0
        if cur:
            cur.append((sep, GREY))
        cur.append((shown, col))
        curw += wsep + wpiece
    if cur:
        lines.append(cur)
    return lines


def note(fam, wt, s):
    USED.setdefault((fam, wt), set()).update(s)


def rect(x, y, w, h, fill, stroke="none", sw=0, rx=0, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    E.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx}" fill="{fill}" '
             f'stroke="{stroke}" stroke-width="{sw}"{d}/>')


def line(x1, y1, x2, y2, stroke=ARROW, sw=2, marker=None, dash=None):
    mk = f' marker-end="url(#{marker})"' if marker else ""
    d = f' stroke-dasharray="{dash}"' if dash else ""
    E.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{stroke}" '
             f'stroke-width="{sw}"{mk}{d}/>')


def circle(cx, cy, r, fill, stroke="none", sw=0):
    E.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')


def text(x, y, s, fam="s", wt=400, size=13.0, fill=BODY, anchor="start", ls=None):
    note(fam, wt, s)
    wd = tw(s, fam, wt, size) + (float(ls) * len(s) if ls else 0.0)
    lo = {"start": x, "middle": x - wd / 2, "end": x - wd}[anchor]
    if lo < M - 1.5 or lo + wd > W - M + 1.5:
        raise SystemExit(f"[{ROW}] TEXT CROSSES THE FIGURE MARGIN ({lo:.0f}..{lo + wd:.0f}): {s[:60]}")
    l = f' letter-spacing="{ls}"' if ls else ""
    E.append(f'<text x="{x:.1f}" y="{y:.1f}" font-family="{FAMILY[fam]}" font-size="{size}" font-weight="{wt}" '
             f'fill="{fill}" text-anchor="{anchor}"{l}>{escape(s)}</text>')


def rich(x, y, runs, size=13.0, anchor="start"):
    parts = []
    for s, fam, wt, fill in runs:
        note(fam, wt, s)
        parts.append(f'<tspan font-family="{FAMILY[fam]}" font-weight="{wt}" fill="{fill}">{escape(s)}</tspan>')
    E.append(f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" xml:space="preserve">'
             f'{"".join(parts)}</text>')


def ids_draw(x, y, lines, size=11.2, lh=15.2, wt=400, anchor="start"):
    for i, ln in enumerate(lines):
        rich(x, y + i * lh, [(s, "m", wt, c) for s, c in ln], size=size, anchor=anchor)


def pill(cx, y, label, fill, tx, size=10.0, h=20):
    wpx = tw(label, "s", 700, size) + 20 + 0.4 * len(label)
    x = cx - wpx / 2
    rect(x, y, wpx, h, fill, rx=h / 2)
    text(x + wpx / 2, y + h / 2 + size * 0.36, label, "s", 700, size, tx, "middle", ls="0.4")
    return wpx


def section_title(y, s, col=INK, size=13.0):
    tl = wrap(s, CW, "s", 700, size, ls=0.8)
    for j, l in enumerate(tl):
        text(M, y + 16 + j * (size + 5), l, "s", 700, size, col, ls="0.8")
    return 22 + (len(tl) - 1) * (size + 5)


# ---------------------------------------------------------------- blocks
class Block:
    def __init__(self, h, fn):
        self.h, self.fn = h, fn

    def draw(self, x, y, h=None):
        self.fn(x, y, self.h if h is None else h)


def card(w, title, body, ids, accent, fill=WHITE, tcol=INK, tsize=13.0, bsize=12.0, lh=16.0, isize=10.8,
         ilh=14.6, kicker=None, kcol=None, strike=False):
    pad_l, pad_r, top = 16, 12, 11
    tl = wrap(title, w - pad_l - pad_r, "s", 700, tsize)
    bl = wrap(body, w - pad_l - pad_r, "s", 400, bsize) if body else []
    il = id_lines(ids, w - pad_l - pad_r, isize) if ids else []
    kl = 1 if kicker else 0
    h = top + kl * 15 + len(tl) * (tsize + 4) + (3 + len(bl) * lh if bl else 0) + (5 + len(il) * ilh if il else 0) + 9

    def fn(x, y, hh):
        rect(x, y, w, hh, fill, LINE, 1, rx=7)
        rect(x, y, 5, hh, accent)
        cy = y + top
        if kicker:
            text(x + pad_l, cy + 9, kicker, "s", 700, 9.6, kcol or accent, ls="0.7")
            cy += 15
        for i, t in enumerate(tl):
            yy = cy + tsize - 1 + i * (tsize + 4)
            text(x + pad_l, yy, t, "s", 700, tsize, tcol)
            if strike:
                line(x + pad_l - 2, yy - tsize * 0.33, x + pad_l + tw(t, "s", 700, tsize) + 2, yy - tsize * 0.33,
                     R, 2.2)
        cy += len(tl) * (tsize + 4)
        if bl:
            cy += 3
            for i, t in enumerate(bl):
                text(x + pad_l, cy + bsize - 1 + i * lh, t, "s", 400, bsize, BODY)
            cy += len(bl) * lh
        if il:
            cy += 5
            ids_draw(x + pad_l, cy + isize - 1, il, isize, ilh)

    return Block(h, fn)


def grid(cards, cols, x, y, w, gap=12, vgap=12):
    cw = (w - gap * (cols - 1)) / cols
    rows = [cards[i:i + cols] for i in range(0, len(cards), cols)]
    cy = y
    for r in rows:
        blocks = [c(cw) for c in r]
        rh = max(b.h for b in blocks)
        for j, b in enumerate(blocks):
            b.draw(x + j * (cw + gap), cy, rh)
        cy += rh + vgap
    return cy - vgap - y


def band(y, label, right, color, tint, content_h, draw_fn, pad=14, hh=40):
    total = hh + pad + content_h + pad
    rect(M, y, CW, total, tint, color, 1.4, rx=9)
    rect(M, y, CW, hh, color, rx=9)
    rect(M, y + hh - 9, CW, 9, color)
    lsz = 15.0
    rw = (tw(right, "m", 700, 11) + 40) if right else 0
    while tw(label, "s", 700, lsz) + 0.5 * len(label) + rw > CW - 36 and lsz > 10.5:
        lsz -= 0.5
    ty = y + hh / 2 + 6
    text(M + 18, ty, label, "s", 700, lsz, WHITE, ls="0.5")
    if right:
        for nm in right.split(" · "):
            resolve(nm)
        text(W - M - 16, ty - 0.5, right, "m", 700, 11, WHITE, "end")
    draw_fn(y + hh + pad)
    return total


def fig_header(num, title):
    h = 54
    rect(0, 0, W, h, NAVY)
    rect(0, h - 4, W, 4, V)
    text(M, 22, f"FIGURE {num}", "s", 700, 11, GOLD, ls="1.2")
    tsz = 17.0
    while tw(title, "s", 700, tsz) + 0.4 * len(title) > CW - 10 and tsz > 12:
        tsz -= 0.5
    text(M, 42, title, "s", 700, tsz, WHITE, ls="0.4")
    rt = CFG['header_right']
    text(W - M, 22, rt, "s", 400, 10, SUB, "end", ls="0.6")
    return h


def legend(y):
    h = 30
    rect(M, y, CW, h, WHITE, LINE, 1, rx=7)
    lx = M + 14
    text(lx, y + 19.5, "READING", "s", 700, 10.4, INK, ls="0.8")
    lx += tw("READING", "s", 700, 10.4) + 22
    labs = [(G, "theorem on no axiom at all")]
    if any(c in ("p", "pQ") for c in IDX["cone"].values()):
        labs.append((T, "binding theorem on propext (with Quot.sound)"))
    if CFG.get('binding_ns'):
        labs.append((B, "binding theorem on Lean's standard axioms"))
    labs.append((SLATE, "definition or structure"))
    for col, lab in labs:
        rect(lx, y + 9, 12, 12, col, rx=2)
        text(lx + 18, y + 19.5, lab, "s", 400, 10.6, BODY)
        lx += 18 + tw(lab, "s", 400, 10.6) + 22
    note_ = "names shown by their last component"
    if lx + tw(note_, "s", 400, 10.2) + 10 < W - M - 14:
        text(W - M - 14, y + 19.5, note_, "s", 400, 10.2, GREY, "end")
    return h


def bit_band(y, kicker, formula, sub):
    fsz = 21.0
    while tw(formula, "m", 700, fsz) > CW - 70 - tw(kicker, "s", 700, 16) - 1.0 * len(kicker) and fsz > 12:
        fsz -= 0.5
    sl = wrap(sub, CW - 40, "s", 400, 12.4)
    h = 62 + len(sl) * 17
    rect(M, y, CW, h, NAVY2, NAVY, 1.4, rx=9)
    text(M + 22, y + 36, kicker, "s", 700, 16, GOLD, ls="1.0")
    text(M + 40 + tw(kicker, "s", 700, 16) + 0.8 * len(kicker), y + 37, formula, "m", 700, fsz, WHITE)
    for j, l in enumerate(sl):
        text(M + 22, y + 60 + j * 17, l, "s", 400, 12.4, "#dbe6f1")
    return h


