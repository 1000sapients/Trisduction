# ---------------------------------------------------------------- build
def font_face(key, famname, weight):
    chars = "".join(sorted(USED.get(key, set()))) + " "
    tt = TTFont(FONTFILE[key])
    opts = subset.Options()
    opts.flavor = "woff2"
    opts.layout_features = ["kern", "liga"]
    opts.notdef_outline = True
    sub = subset.Subsetter(opts)
    sub.populate(text=chars)
    sub.subset(tt)
    buf = io.BytesIO()
    tt.flavor = "woff2"
    tt.save(buf)
    return (f"@font-face{{font-family:'{famname}';font-weight:{weight};font-style:normal;"
            f"src:url(data:font/woff2;base64,{base64.b64encode(buf.getvalue()).decode()}) format('woff2');}}")


FIGS = [(1, "THE TEN STEPS AND THE SEAL", fig1),
        (2, CFG.get('f2_title', "CLAY CANNOT STAY OPEN: CLOSED BY THEOREM TO ONE BIT"), fig2),
        (3, "THE NORMAL FORM AND THE HOST, PROVED", fig3),
        (4, CFG['f4_header'], fig4),
        (5, "THE WALLS: NOTHING ESCAPES THE BIT", fig6),
        (6, "THE BIT DELIVERED TWICE: TWO KINDS AND NO THIRD", fig5),
        (7, "THE KERNEL, THE RECEIPTS AND THE TWO-LAYER CLOSURE", fig7)]

if __name__ == "__main__":
    os.makedirs(OUTDIR, exist_ok=True)
    only = {int(a) for a in sys.argv[2:]} if len(sys.argv) > 2 else None
    allchecked = {}
    for num, title, body in FIGS:
        if only and num not in only:
            continue
        E.clear(); USED.clear(); CHECKED.clear()
        E.append("BG")
        y = fig_header(num, title) + 12
        y = body(y) + 12
        y += legend(y) + 12
        H = int(round(y))
        E[0] = f'<rect x="0" y="0" width="{W}" height="{H}" fill="{BG}"/>'
        faces = [font_face(("s", 400), "RowSans", 400), font_face(("s", 700), "RowSans", 700),
                 font_face(("m", 400), "RowMono", 400), font_face(("m", 700), "RowMono", 700)]
        defs = ('<defs>'
                f'<marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
                f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{ARROW}"/></marker>'
                f'<style>{"".join(faces)}</style></defs>')
        ttl = f"{CFG['short']} · Figure {num} · {string.capwords(title.lower())}"
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" '
               f'aria-label="{escape(ttl)}">\n<title>{escape(ttl)}</title>\n{defs}\n' + "\n".join(E) + "\n</svg>\n")
        fn = f"{OUTDIR}/{CFG['stem']}_Figure_{num}_v1_1_0_CC.svg"
        open(fn, "w", encoding="utf-8").write(svg)
        allchecked.update(CHECKED)
        print(f"[{ROW}] Figure {num}: {W}x{H}, {len(CHECKED)} names checked")
    json.dump({k: list(v) for k, v in allchecked.items()}, open(f"{OUTDIR}/checked_ids.json", "w"), indent=0,
              ensure_ascii=False)
