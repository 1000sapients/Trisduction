#!/usr/bin/env python3
"""check_names.py MD [INDEX_JSON] · every \\thm{name} of the paper is a declaration of the Millennium Grand Master tree
(any suffix of a fully qualified name), a structure field of a module of the tree, a module of the tree, or the name of
a carried or shipped file. Prints the unknown names, and every theorem named without a pinned cone; exits 1 if any
name is unknown."""
import glob, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.dirname(os.path.dirname(HERE))
MD = sys.argv[1]
IDX = json.load(open(sys.argv[2] if len(sys.argv) > 2 else os.path.join(SP, "synth", "figs", "index_SYNTH.json")))
known, kind_of, cone_of = set(), {}, {}
for short, lst in IDX["decl"].items():
    for full, line, kind, mod in lst:
        parts = full.split(".")
        for i in range(len(parts)):
            suf = ".".join(parts[i:])
            known.add(suf)
            kind_of.setdefault(suf, set()).add(kind)
            if kind in ("theorem", "lemma"):
                cone_of.setdefault(suf, set()).add(IDX["cone"].get(full))
        known.add(mod)
extra = sys.argv[3:]  # further directories whose .lean files contribute structure fields
for f in glob.glob(os.path.join(SP, "master", "src", "**", "*.lean"), recursive=True) + \
        [g for d in extra for g in glob.glob(os.path.join(d, "**", "*.lean"), recursive=True)]:
    for m in re.finditer(r"^\s{2,}([A-Za-z_][A-Za-z_0-9₀-₉']*)\s*:", open(f, encoding="utf-8").read(), re.M):
        known.add(m.group(1))
text = open(MD, encoding="utf-8").read().split("\n<!--\nMACHINE-READABLE")[0]
names = re.findall(r"\\thm\{([^}]*)\}", text)
files = re.compile(r".*\.(lean|py|md|txt|json|sha256)$")
unknown = sorted({n for n in names if n not in known and not files.match(n)})
unpinned = sorted({n for n in names if n in cone_of and None in cone_of[n] and len(cone_of[n]) == 1})
print(f"{len(names)} theorem references, {len(set(names))} distinct; unknown: {unknown}; theorems without a pinned "
      f"cone: {unpinned}")
sys.exit(1 if unknown else 0)
