#!/usr/bin/env python3
"""overlapcheck.py PDF ... · no two lines of text print over each other: any two text lines on a page whose boxes
overlap by more than 3 pt vertically and 4 pt horizontally are reported (figure-internal text excluded). Exit 1 if any."""
import sys
import pymupdf
sys.path.insert(0, __file__.rsplit("/", 1)[0])
from bleedcheck import regions


def check(path):
    doc = pymupdf.open(path)
    out = []
    for pno, page in enumerate(doc, 1):
        figs, _ = regions(page)
        figs = [pymupdf.Rect(r.x0, r.y0, r.x1, r.y1 - 34) for r in figs]  # the graphic itself, not its caption
        lines = []
        for blk in page.get_text("dict")["blocks"]:
            for ln in blk.get("lines", []):
                t = "".join(s["text"] for s in ln["spans"]).strip()
                if not t:
                    continue
                r = pymupdf.Rect(ln["bbox"])
                if any(f.contains(r) for f in figs):
                    continue
                lines.append((r, t))
        for i in range(len(lines)):
            a, ta = lines[i]
            for j in range(i + 1, len(lines)):
                b, tb = lines[j]
                dx = min(a.x1, b.x1) - max(a.x0, b.x0)
                dy = min(a.y1, b.y1) - max(a.y0, b.y0)
                if dx > 4 and dy > 3:
                    out.append((pno, round(a.y0, 1), round(b.y0, 1), ta[:40], tb[:40]))
    return out


if __name__ == "__main__":
    bad = 0
    for p in sys.argv[1:]:
        res = check(p)
        print(f"{p.split('/')[-1]}: {len(res)} overlapping lines")
        for r in res[:20]:
            print("   ", r)
        bad += len(res)
    sys.exit(1 if bad else 0)
