#!/usr/bin/env python3
"""build_pdf.py MD OUTDIR [FIGDIR]

Builds the two-column Math Journal PDF of one paper from its Markdown master:
  1. extracts the machine-readable files carried at the foot of the master (kernels, manifest, exhibits);
  2. widens every raw LaTeX table to the full text width (table -> table*, \\columnwidth -> \\textwidth);
  3. maps every non-ASCII character the main font lacks onto a font that has it (newunicodechar);
  4. pandoc -> LaTeX with the template and the box filter; xelatex twice;
  5. the render-completeness probe: the PDF must end on the end-of-manuscript line, carry the Conclusion and the
     References, and the log must report no missing character.
"""
import os, re, shutil, subprocess, sys
from fontTools.ttLib import TTFont

HERE = os.path.dirname(os.path.abspath(__file__))
MD, OUT = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
FIGDIR = os.path.abspath(sys.argv[3]) if len(sys.argv) > 3 else None
os.makedirs(OUT, exist_ok=True)
stem = os.path.splitext(os.path.basename(MD))[0]
src = open(MD, encoding="utf-8").read()

# 1 · carried files
for m in re.finditer(r"^~~~~~[a-z0-9]+ file=([A-Za-z0-9_./]+)\n(.*?)^~~~~~$", src, re.S | re.M):
    name = m.group(1)
    if ".." in name or name.startswith("/"):
        raise SystemExit("unsafe carried name " + name)
    path = os.path.join(OUT, name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write(m.group(2))
if FIGDIR:
    os.makedirs(os.path.join(OUT, "figs"), exist_ok=True)
    for f in os.listdir(FIGDIR):
        if f.endswith(".pdf"):
            shutil.copy(os.path.join(FIGDIR, f), os.path.join(OUT, "figs", f))

body = src.split("\n<!--\nMACHINE-READABLE")[0]


# 2 · full-width tables
def widen(m):
    blk = m.group(0)
    if "\\begin{table}" not in blk:
        return blk
    blk = blk.replace("\\begin{table}[htbp]", "\\begin{table*}[tp]").replace("\\begin{table}", "\\begin{table*}")
    blk = blk.replace("\\end{table}", "\\end{table*}").replace("\\columnwidth", "\\textwidth")
    return blk


body = re.sub(r"```\{=latex\}\n.*?\n```", widen, body, flags=re.S)
# a 64-digit digest in the prose breaks where the column ends
body = re.sub(r"(?<![0-9a-f{])([0-9a-f]{64})(?![0-9a-f}])", r"\\nolinkurl{\1}", body)

# 3 · characters the main font lacks
main = TTFont("/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyrepagella-regular.otf").getBestCmap()
sym = TTFont("/usr/share/fonts/truetype/freefont/FreeSerif.ttf").getBestCmap()
dvs = TTFont("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf").getBestCmap()
prose = re.sub(r"\\thm\{[^}]*\}|`[^`]*`|```.*?```", "", body, flags=re.S)
need = {c for c in prose if ord(c) > 127 and ord(c) not in main}
# characters of the printed kernels that the listing font lacks
mono = TTFont("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf").getBestCmap()
for lst in re.findall(r"\\kernellisting\{([^}]+)\}", body):
    lp = os.path.join(OUT, lst)
    if os.path.exists(lp):
        need |= {c for c in open(lp, encoding="utf-8").read() if ord(c) > 127 and ord(c) not in mono}
need = sorted(need)
maps = []
for c in need:
    if ord(c) in sym:
        maps.append("\\newunicodechar{%s}{{\\symfont %s}}" % (c, c))
    elif ord(c) in dvs:
        maps.append("\\newunicodechar{%s}{{\\fontspec{DejaVu Sans}%s}}" % (c, c))
    else:
        print("NO FONT HAS", repr(c), hex(ord(c)))
hdr = "\\usepackage{newunicodechar}\n" + "\n".join(maps)
front_end = body.index("\n---\n", 4)
yaml = body[:front_end]
yaml += "\nheader-includes: |\n" + "\n".join("  " + l for l in hdr.split("\n"))
body = yaml + body[front_end:]
open(os.path.join(OUT, stem + ".md"), "w", encoding="utf-8").write(body)

# 4 · pandoc and xelatex
subprocess.run(["pandoc", stem + ".md", "-f", "markdown+raw_tex+raw_attribute+fenced_divs-implicit_figures",
                "-t", "latex", "--template", os.path.join(HERE, "mj_template.tex"), "--shift-heading-level-by=-1",
                "--lua-filter", os.path.join(HERE, "box.lua"), "-o", stem + ".tex"], cwd=OUT, check=True)
tex_path = os.path.join(OUT, stem + ".tex")
tex = open(tex_path, encoding="utf-8").read()
tex, nd = re.subn(r"(?<!\\)\\\[(.+?)(?<!\\)\\\]", lambda m: "\\[\\fitmath{" + m.group(1) + "}\\]", tex, flags=re.S)
open(tex_path, "w", encoding="utf-8").write(tex)
for i in range(2):
    r = subprocess.run(["xelatex", "-interaction=nonstopmode", "-halt-on-error", stem + ".tex"], cwd=OUT,
                       capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-3000:])
        raise SystemExit("XELATEX FAILED")

# 5 · the probe
log = open(os.path.join(OUT, stem + ".log"), encoding="utf-8", errors="replace").read()
missing = sorted(set(re.findall(r"Missing character: There is no (.) in font ([^!]*)!", log)))
pdf = os.path.join(OUT, stem + ".pdf")
txt = subprocess.run(["pdftotext", "-layout", pdf, "-"], capture_output=True, text=True).stdout
pages = int(re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout).group(1))
ok_end = "End of manuscript" in txt[-4000:]
ok_conc = bool(re.search(r"Conclusion", txt, re.I)) and bool(re.search(r"References", txt, re.I))
over = re.findall(r"Overfull \\[hv]box \((\d+\.\d+)pt too [a-z]+\) (?:in paragraph at lines|detected at line|has occurred while \\output is active)? ?([0-9-]*)", log)
bc = subprocess.run([sys.executable, os.path.join(HERE, "bleedcheck.py"), pdf], capture_output=True, text=True)
pc = subprocess.run([sys.executable, os.path.join(HERE, "pixelcheck.py"), pdf], capture_output=True, text=True)
print(f"{stem}: pages {pages} · end {ok_end} · conclusion+refs {ok_conc} · missing {missing[:12]} · overfull {over} · "
      f"displays fitted {nd}")
print(bc.stdout.strip())
print(pc.stdout.strip())
if missing or not ok_end or not ok_conc or over or bc.returncode != 0 or pc.returncode != 0:
    raise SystemExit("PROBE FAILED")
