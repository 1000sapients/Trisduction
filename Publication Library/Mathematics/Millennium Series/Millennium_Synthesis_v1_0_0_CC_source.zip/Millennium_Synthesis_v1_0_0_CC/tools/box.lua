-- ::: {.box title="..."} ... :::  ->  \begin{jbox}{title} ... \end{jbox}
function Div(el)
  if el.classes:includes("box") then
    local t = el.attributes["title"] or ""
    local blocks = { pandoc.RawBlock("latex", "\\begin{jbox}[" .. t .. "]") }
    for _, b in ipairs(el.content) do table.insert(blocks, b) end
    table.insert(blocks, pandoc.RawBlock("latex", "\\end{jbox}"))
    return blocks
  end
end

-- pipe tables -> xtabular, which breaks across the two columns and keeps its place in the text
local function cell_latex(cell)
  local s = pandoc.write(pandoc.Pandoc(cell.contents), "latex")
  s = s:gsub("%s+$", ""):gsub("\n\n+", "\\par ")
  return s
end

function Table(tbl)
  local ncol = #tbl.colspecs
  local width = 0.97 / ncol
  local spec = "@{}"
  for i = 1, ncol do
    local w = tbl.colspecs[i][2]
    local frac = (type(w) == "number" and w > 0) and (w * 0.97) or width
    spec = spec .. ">{\\raggedright\\arraybackslash}p{" .. string.format("%.3f", frac) .. "\\columnwidth}"
  end
  spec = spec .. "@{}"
  local head = {}
  if tbl.head and tbl.head.rows and #tbl.head.rows > 0 then
    for _, c in ipairs(tbl.head.rows[1].cells) do table.insert(head, "\\textbf{" .. cell_latex(c) .. "}") end
  end
  local rows = {}
  for _, body in ipairs(tbl.bodies) do
    for _, r in ipairs(body.body) do
      local cs = {}
      for _, c in ipairs(r.cells) do table.insert(cs, cell_latex(c)) end
      table.insert(rows, table.concat(cs, " & ") .. "\\\\[2pt]")
    end
  end
  local out = "{\\scriptsize\\renewcommand{\\arraystretch}{1.08}\\setlength{\\tabcolsep}{3pt}\n"
  if #head > 0 then
    out = out .. "\\tablefirsthead{\\toprule " .. table.concat(head, " & ") .. "\\\\\\midrule}\n"
    out = out .. "\\tablehead{\\toprule " .. table.concat(head, " & ") .. "\\\\\\midrule}\n"
  end
  out = out .. "\\tabletail{}\\tablelasttail{\\bottomrule}\n"
  out = out .. "\\begin{xtabular}{" .. spec .. "}\n" .. table.concat(rows, "\n") .. "\n\\end{xtabular}}\\par\n"
  return pandoc.RawBlock("latex", out)
end
