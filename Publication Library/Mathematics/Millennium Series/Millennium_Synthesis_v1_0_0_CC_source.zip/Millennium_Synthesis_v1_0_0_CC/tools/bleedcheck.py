#!/usr/bin/env python3
"""bleedcheck.py PDF [PDF ...] · every glyph of every page against the page geometry of the two-column Math Journal.

Letter paper, margins 0.85 in (61.2 pt), column separation 0.28 in: the text block is x in [61.2, 550.8], y in
[61.2, 730.8]; column one [61.2, 295.92], column two [316.08, 550.8]. Reported, with a 0.5 pt tolerance:
  RIGHT  a line ending past the right edge of the text block
  LEFT   a line starting before the left edge of the text block
  BOTTOM a line below the text block that is not the running foot
  TOP    a line above the text block
  GUTTER a column-one line crossing into the gutter where column two carries text at the same height
  INGUT  a column-one line ending inside the gutter (reviewed by eye: a short full-width line may end there)
Lines inside full-width figures and between full-width rules (tables, abstract) are exempt from the gutter checks.
Exit 1 when any RIGHT, LEFT, BOTTOM, TOP or GUTTER item is found."""
import sys
import pymupdf

L, R, T, B = 61.2, 550.8, 61.2, 730.8
C1R, C2L = 295.92, 316.08
TOL = 0.5


def regions(page):
    figs, rules = [], []
    for d in page.get_drawings():
        r = d["rect"]
        if r.width >= 480 and r.height >= 80:
            figs.append(pymupdf.Rect(r.x0, r.y0, r.x1, r.y1 + 34))  # the figure and its caption
        elif r.width >= 480 and r.height < 3:
            rules.append(r.y0)
    # images placed full width
    for info in page.get_image_info():
        r = pymupdf.Rect(info["bbox"])
        if r.width >= 480:
            figs.append(r)
    rules.sort()
    tables = []
    i = 0
    while i < len(rules):
        j = i
        while j + 1 < len(rules) and rules[j + 1] - rules[j] < 400:
            j += 1
        if j > i:
            tables.append((rules[i] - 2, rules[j] + 26))  # the table and its caption, two lines
        i = j + 1
    return figs, tables


def check(path):
    doc = pymupdf.open(path)
    hard, soft = [], []
    for pno, page in enumerate(doc, 1):
        figs, tables = regions(page)
        lines = []
        for blk in page.get_text("dict")["blocks"]:
            for ln in blk.get("lines", []):
                txt = "".join(s["text"] for s in ln["spans"]).strip()
                if not txt:
                    continue
                x0, y0, x1, y1 = ln["bbox"]
                base = max(sp["origin"][1] for sp in ln["spans"])
                lines.append((x0, y0, x1, y1, txt, base))

        def exempt(y0, y1, x0, x1):
            for r in figs:
                if r.y0 - 1 <= y0 and y1 <= r.y1 + 1 and r.x0 - 1 <= x0 and x1 <= r.x1 + 1:
                    return True
            for a, b in tables:
                if a <= y0 and y1 <= b:
                    return True
            return False

        col2 = [(y0, y1) for x0, y0, x1, y1, t, b in lines if C2L - 0.5 <= x0 <= C2L + 30 and not exempt(y0, y1, x0, x1)]
        for x0, y0, x1, y1, t, base in lines:
            tag = None
            if x1 > R + TOL:
                tag = "RIGHT"
            elif x0 < L - TOL:
                tag = "LEFT"
            elif B + 1.0 < base < 750:
                tag = "BOTTOM"
            elif base < T:
                tag = "TOP"
            if tag:
                hard.append((pno, tag, round(x0, 1), round(x1, 1), round(y0, 1), t[:70]))
                continue
            if x0 < C1R and x1 > C1R + TOL and not exempt(y0, y1, x0, x1):
                if any(a < y1 - 1 and y0 + 1 < b for a, b in col2):
                    hard.append((pno, "GUTTER", round(x0, 1), round(x1, 1), round(y0, 1), t[:70]))
                elif x1 < C2L:
                    soft.append((pno, "INGUT", round(x0, 1), round(x1, 1), round(y0, 1), t[:70]))
    return hard, soft


if __name__ == "__main__":
    bad = 0
    for p in sys.argv[1:]:
        hard, soft = check(p)
        name = p.split("/")[-1]
        print(f"{name}: {len(hard)} bleed, {len(soft)} to review")
        for h in hard:
            print("   ", h)
        for s in soft:
            print("   ?", s)
        bad += len(hard)
    sys.exit(1 if bad else 0)
