#!/usr/bin/env python3
"""build_method_md.py · the Markdown master of The One-Bit Method, edition 1.0.0_CC: src/*.md assembled, the SHA-256
of the executable form filled in, and the executable form appended as the machine-readable carrier."""
import glob, hashlib, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
MD = "One_Bit_Method_v1_0_0_CC.md"
LEAN = os.path.join(HERE, "One_Bit_Method_v1_0_0_CC.lean")
body = "\n".join(open(p, encoding="utf-8").read().rstrip("\n") + "\n" for p in sorted(glob.glob(os.path.join(HERE, "src", "*.md"))))
h = hashlib.sha256(open(LEAN, "rb").read()).hexdigest()
body = body.replace("@SHAFULL@", h)
left = re.findall(r"@[A-Z]+@", body)
if left:
    raise SystemExit(f"unfilled: {left}")
text = open(LEAN, encoding="utf-8").read()
if "\n~~~~~" in text or "-->" in text:
    raise SystemExit("unsafe carried file")
blk = ["<!--", "MACHINE-READABLE KERNEL AND MANIFEST (not rendered). Extract with:",
       "awk '{sub(/\\r$/,\"\")} /^~~~~~[a-z0-9]+ file=[A-Za-z0-9_.]+$/{sub(/.*file=/,\"\");f=$0;next} "
       "/^~~~~~$/{if(f!=\"\"){close(f);f=\"\"};next} f!=\"\"{print > f}' " + MD,
       "", "~~~~~sha256 file=MANIFEST.sha256", "%s  One_Bit_Method_v1_0_0_CC.lean" % h, "~~~~~", "",
       "~~~~~lean file=One_Bit_Method_v1_0_0_CC.lean", text.rstrip("\n"), "~~~~~", "", "-->"]
out = body.rstrip("\n") + "\n\n" + "\n".join(blk) + "\n"
os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
open(os.path.join(HERE, "out", MD), "w", encoding="utf-8").write(out)
print(f"{MD}: body {len(body.split())} words · executable form sha256 {h[:16]}")
