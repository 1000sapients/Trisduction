#!/usr/bin/env python3
"""synthfigs.py · the seven figures of the Millennium synthesis, edition 1.0.0_CC.

Usage: synthfigs.py [n ...]
Built on the primitives of the row figure builder (figprim.py, extracted verbatim from rowfigs.py). Every monospace
identifier is resolved against the index of the Millennium Grand Master tree (index_SYNTH.json: every module, every
declaration, every pinned cone) and colored by its pinned cone: green = no axiom, teal = propext or propext and
Quot.sound, blue = Lean's standard axioms, slate = definition or structure. An unresolved name or a theorem without a
pinned cone halts the build."""
import os, sys, json, string, collections
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
exec(open(os.path.join(HERE, "figprim.py"), encoding="utf-8").read())

ROWS = ["RH", "P≠NP", "NS", "YM", "Hodge", "BSD", "Poincaré"]


def legend(y):
    h = 30
    rect(M, y, CW, h, WHITE, LINE, 1, rx=7)
    lx = M + 14
    text(lx, y + 19.5, "READING", "s", 700, 10.4, INK, ls="0.8")
    lx += tw("READING", "s", 700, 10.4) + 22
    for col, lab in [(G, "theorem on no axiom"), (T, "on propext (and Quot.sound)"),
                     (B, "on Lean's standard axioms"), (SLATE, "definition or structure")]:
        rect(lx, y + 9, 12, 12, col, rx=2)
        text(lx + 18, y + 19.5, lab, "s", 400, 10.6, BODY)
        lx += 18 + tw(lab, "s", 400, 10.6) + 22
    n_ = "names shown by their last component"
    if lx + tw(n_, "s", 400, 10.2) + 10 < W - M - 14:
        text(W - M - 14, y + 19.5, n_, "s", 400, 10.2, GREY, "end")
    return h


def idband(y, label, ids, color=NAVY2, body=None):
    il = id_lines(ids, CW - 36, 11.2)
    bl = wrap(body, CW - 36, "s", 400, 12.2) if body else []
    h = 40 + len(bl) * 17 + (8 + len(il) * 15.2 if il else 0) + 8
    rect(M, y, CW, h, WHITE, color, 1.4, rx=9)
    rect(M, y, CW, 30, color, rx=9)
    rect(M, y + 21, CW, 9, color)
    text(M + 18, y + 20, label, "s", 700, 12.4, WHITE, ls="0.7")
    cy = y + 30 + 6
    for j, l in enumerate(bl):
        text(M + 18, cy + 12 + j * 17, l, "s", 400, 12.2, BODY)
    cy += len(bl) * 17
    if il:
        ids_draw(M + 18, cy + 18, il, 11.2, 15.2)
    return h


# ---------------------------------------------------------------- figure 1 · seven questions, one normal form
def fig1(y):
    y += bit_band(y, "ONE NORMAL FORM", "Transfer R F  ↔  R.Value F",
                  "The bit of a frame, its record's value carried to the frame, is exactly the frame's value. Proved once "
                  "on no axiom and recovered as each row's own normal form by exact type; at four rows the bit is pinned "
                  "to the library's own statement of the problem.") + 12
    cards = [
        ("RH · THE ZEROS", "Least erasure transfers from the record to the zeros; at Mathlib's zeta zeros the value is "
         "Mathlib's RiemannHypothesis.", ["BoundChainMathlib.zeta_ra_loop",
                                          "MillenniumGrandMaster.rh_value_at_the_zeros_is_RiemannHypothesis"], B),
        ("P ≠ NP · EVERY MACHINE", "Least escape transfers from the SAT record to every Turing machine; the core "
         "machine model, no library binding.", ["PNP.NORMALFORM.sep_normal_form",
                                                "MillenniumGrandMaster.pnp_normal_form_is_the_one"], B),
        ("NAVIER–STOKES · EVERY FLOW", "Every flow finite at every time; the transfer at the library's host is "
         "Fefferman's statement (A).", ["NS.NORMALFORM.normal_form", "MillenniumGrandMaster.ns_normal_form_is_the_one",
                                        "PerelmanHunt.ns_upgrade_is_adopting_FeffermanA"], G),
        ("YANG–MILLS · EVERY THEORY", "Every theory exists with a positive floor; read at the kernel's host.",
         ["YM.NORMALFORM.normal_form", "MillenniumGrandMaster.ym_normal_form_is_the_one"], G),
        ("HODGE · EVERY CLASS", "Every rational (p,p) class is algebraic in the middle range; read at the kernel's "
         "host.", ["HODGE.NORMALFORM.normal_form", "MillenniumGrandMaster.hodge_normal_form_is_the_one"], G),
        ("BSD · EVERY CURVE", "The rank equals the order above order one; the transfer at the library's curves is "
         "the rank statement on Mathlib's E(Q).", ["BSD.NORMALFORM.normal_form",
                                                   "MillenniumGrandMaster.bsd_normal_form_is_the_one",
                                                   "PerelmanHunt.bsd_upgrade_is_adopting_BSDRank"], G),
        ("POINCARÉ · EVERY MANIFOLD", "Every closed simply connected 3-manifold is the sphere; pinned to the "
         "library's statement, held in Mathlib as proof_wanted; accepted as unconditional by the Clay Institute.",
         ["PC.NORMALFORM.normal_form", "MillenniumGrandMaster.pc_normal_form_is_the_one",
          "PerelmanHunt.pc_upgrade_is_adopting_PoincareThree"], G),
    ]
    mk = lambda t, b, ids, acc, isz=10.8: (lambda w: card(w, t, b, ids, acc, tsize=12.4, bsize=11.6, lh=15.4, isize=isz))
    y += grid([mk(*c) for c in cards[:3]], 3, M, y, CW) + 12
    y += grid([mk(*c, isz=10.0) for c in cards[3:]], 4, M, y, CW) + 12
    y += idband(y, "BOUND IN ONE THEOREM", ["MillenniumGrandMaster.normal_form_once",
                                            "MillenniumGrandMaster.the_floor_verdict",
                                            "MillenniumGrandMaster.the_grand_verdict"],
                body="The one normal form, the five rows' final forms on no axiom, and the grand verdict over all seven "
                     "terminal theorems, nothing before the colon.") + 6
    return y


# ---------------------------------------------------------------- figure 2 · the ten steps across the seven rows
STEPS = ["1 · The floor", "2 · The basis", "3 · The domain", "4 · The record", "5 · Self-recursion, halted",
         "6 · Two worlds, one record", "7 · The axis: bit iff value", "8 · The real part", "9 · Every route passes the bit",
         "10 · The bit, delivered twice"]


def fig2(y):
    lab_w = 250
    cw = (CW - lab_w) / 7
    rh = 30
    # header
    rect(M, y, CW, 34, NAVY, rx=7)
    text(M + 14, y + 22, "STEP", "s", 700, 11.6, GOLD, ls="0.8")
    for j, r in enumerate(ROWS):
        text(M + lab_w + j * cw + cw / 2, y + 22, r, "s", 700, 12, WHITE, "middle")
    y += 40
    kinds = {}
    for i in range(10):
        for j, r in enumerate(ROWS):
            if i <= 6 or i == 8:
                k = ("theorem", G if r not in ("RH", "P≠NP") else B)
            elif i == 7:
                k = ("theorem", B) if r in ("RH", "P≠NP") else ("over a cited field", SLATE)
            else:
                k = ("accepted · Clay", V) if r == "Poincaré" else ("premise, twice", A)
            kinds[(i, j)] = k
    for i, s in enumerate(STEPS):
        yy = y + i * (rh + 6)
        rect(M, yy, lab_w - 8, rh, WHITE, LINE, 1, rx=6)
        text(M + 12, yy + 19.5, s, "s", 700, 11.6, INK)
        for j in range(7):
            lab, col = kinds[(i, j)]
            x = M + lab_w + j * cw
            tint = {G: G_T, B: B_T, SLATE: "#e8eef2", A: A_T, V: V_T}[col]
            rect(x + 3, yy, cw - 6, rh, tint, col, 1.2, rx=6)
            text(x + cw / 2, yy + 19, lab, "s", 700, 10.2, col, "middle")
    y += 10 * (rh + 6) + 2
    kx = M + 14
    rect(M, y, CW, 28, WHITE, LINE, 1, rx=6)
    text(kx, y + 18.5, "CELLS", "s", 700, 10.2, INK, ls="0.8")
    kx += tw("CELLS", "s", 700, 10.2) + 18
    for col, lab in [(G, "theorem on no axiom"), (B, "theorem on Lean's standard axioms"),
                     (SLATE, "theorem over a cited published result"), (A, "the bit: premise, delivered twice"),
                     (V, "delivery accepted as unconditional")]:
        rect(kx, y + 8, 12, 12, col, rx=2)
        text(kx + 17, y + 18.5, lab, "s", 400, 10.2, BODY)
        kx += 17 + tw(lab, "s", 400, 10.2) + 16
    y += 36
    y += idband(y, "EACH ROW'S TEN STEPS, BY EXACT TYPE", ["TerminalVerdict.the_terminal_verdict",
                                                           "PNP.TONGUE.the_terminal_paper_closure",
                                                           "NS.TERMINAL.the_ten_steps", "YM.TERMINAL.the_ten_steps",
                                                           "HODGE.TERMINAL.the_ten_steps",
                                                           "BSD.TERMINAL.the_ten_steps", "PC.TERMINAL.the_ten_steps"],
                body="A cell carries the cone of the row's bound ten-step theorem, named below in row order. Steps 1 to 9 are theorems on every "
                     "row; at five rows Step 8 takes the published real part as a structure field. Step 10 proves that "
                     "either kind of delivery yields the sentence, the delivery itself a premise on all seven rows; the "
                     "Poincaré delivery was accepted as unconditional by the Clay Institute.") + 6
    return y


# ---------------------------------------------------------------- figure 3 · the walls
def fig3(y):
    cards = [
        ("RH", "Two fold-closed worlds share one record and split on the hypothesis; no reading of the record decides it.",
         ["PrimeFreedom.keyless_forces_nothing", "PrimeFreedom.record_decides_nothing",
          "PrimeFreedom.sentence_separates_record_does_not"]),
        ("P ≠ NP", "The closed world and the stage world share the record; no record principle decides; twenty-two "
         "walls in the master.", ["PNP.NORMALFORM.keyless_forces_nothing", "PNP.NORMALFORM.no_record_principle_decides",
                                  "PNP.NORMALFORM.stage_fails_closure"]),
        ("NAVIER–STOKES", "Every dyadic cascade passes every bound c·E·T: no doubling cascade keeps to the speed limit.",
         ["NS.NORMALFORM.keyless_forces_nothing", "NS.WALLS.dyadic_cascade_is_cut",
          "NS.WALLS.doubling_breaks_the_speed_limit", "NS.WALLS.the_walls"]),
        ("YANG–MILLS", "Two transfer matrices with one trace and one diagonal split on the gap: the trace reads no gap.",
         ["YM.NORMALFORM.keyless_forces_nothing", "YM.WALLS.trace_reads_no_gap", "YM.WALLS.the_walls"]),
        ("HODGE", "No odd weight carries a seat; integrality does not transfer.",
         ["HODGE.NORMALFORM.keyless_forces_nothing", "HODGE.WALLS.odd_weights_carry_no_seat", "HODGE.WALLS.the_walls"]),
        ("BSD", "The sign reads the parity and never the order or the rank.",
         ["BSD.NORMALFORM.keyless_forces_nothing", "BSD.WALLS.sign_reads_no_order", "BSD.WALLS.sign_reads_no_rank",
          "BSD.WALLS.the_walls"]),
        ("POINCARÉ", "The degree record and the homotopy record decide nothing: a chain and a cycle share them.",
         ["PC.NORMALFORM.keyless_forces_nothing", "PC.WALLS.degree_record_decides_nothing",
          "PC.WALLS.homotopy_record_decides_nothing", "PC.WALLS.the_walls"]),
    ]
    mk = lambda t, b, ids: (lambda w: card(w, t, b, ids, R, tsize=12.6, bsize=11.6, lh=15.4))
    y += grid([mk(*c) for c in cards[:4]], 4, M, y, CW) + 12
    y += grid([mk(*c) for c in cards[4:]], 3, M, y, CW) + 12
    y += idband(y, "WHAT EVERY FRAME SHARES FORCES NOTHING, ON ALL SEVEN ROWS",
                ["PerelmanHunt.the_rows_own_walls", "PerelmanHunt.seven_keys", "MillenniumGrandMaster.seven_closed_to_one_bit"],
                color=R_D, body="Each kernel proves its own keyless wall; bound together, one principle that forces all "
                                "seven values carries a key on every row.") + 6
    return y


# ---------------------------------------------------------------- figure 4 · delivered twice
def fig4(y):
    rows = [("RH", "the cargo loop, local computation", "the physical carrier, the heat of registration",
             "RememberedOffered.two_kinds_of_witness_and_no_third"),
            ("P ≠ NP", "the formal cargo at the SAT machine", "the physical witness, machines that run",
             "PNP.SUPPLY.the_two_kinds_are_one_bit"),
            ("NAVIER–STOKES", "the formal cargo at the host", "matter through the speed limit and the cascade",
             "NS.SUPPLY.two_kinds_and_no_third"),
            ("YANG–MILLS", "the formal cargo at the host", "the record of confinement with the colour premise",
             "YM.SUPPLY.two_kinds_and_no_third"),
            ("HODGE", "the formal cargo at the host", "the witness carried by the register of the Riemann row",
             "HODGE.SUPPLY.two_kinds_and_no_third"),
            ("BSD", "the formal cargo at the host", "the physical witness of the rank",
             "BSD.SUPPLY.two_kinds_and_no_third"),
            ("POINCARÉ", "the formal cargo; the 2002–03 offering one inhabitant", "the physical witness, a relaxing flow",
             "PC.SUPPLY.two_kinds_and_no_third")]
    lab_w, cw = 150, (CW - 150 - 300) / 2
    rect(M, y, CW, 34, NAVY, rx=7)
    text(M + 14, y + 22, "ROW", "s", 700, 11.6, GOLD, ls="0.8")
    text(M + lab_w + cw / 2, y + 22, "FIRST KIND · FORMAL CARGO", "s", 700, 11.4, WHITE, "middle")
    text(M + lab_w + cw + cw / 2, y + 22, "SECOND KIND · PHYSICAL WITNESS", "s", 700, 11.4, WHITE, "middle")
    text(M + lab_w + 2 * cw + 150, y + 22, "TWO KINDS, NO THIRD", "s", 700, 11.4, WHITE, "middle")
    y += 40
    for r, a, b, nm in rows:
        al = wrap(a, cw - 24, "s", 400, 11.4)
        bl = wrap(b, cw - 24, "s", 400, 11.4)
        il = id_lines([nm], 300 - 20, 10.4)
        hh = max(len(al), len(bl), len(il)) * 15 + 16
        rect(M, y, lab_w - 6, hh, WHITE, LINE, 1, rx=6)
        text(M + 12, y + 20, r, "s", 700, 11.2, INK)
        rect(M + lab_w, y, cw - 6, hh, G_T, G, 1.1, rx=6)
        for k, l in enumerate(al):
            text(M + lab_w + 12, y + 20 + k * 15, l, "s", 400, 11.4, BODY)
        rect(M + lab_w + cw, y, cw - 6, hh, A_T, A, 1.1, rx=6)
        for k, l in enumerate(bl):
            text(M + lab_w + cw + 12, y + 20 + k * 15, l, "s", 400, 11.4, BODY)
        rect(M + lab_w + 2 * cw, y, 300, hh, WHITE, LINE, 1, rx=6)
        ids_draw(M + lab_w + 2 * cw + 10, y + 20, il, 10.4, 14)
        y += hh + 6
    y += 6
    y += idband(y, "EVERY ROUTE IS A DELIVERY OF BOTH KINDS", ["MillenniumGrandMaster.seven_two_kinds",
                                                               "MillenniumGrandMaster.seven_routes_pass_the_bit",
                                                               "MillenniumGrandMaster.seven_nothing_escapes"],
                color=A_D, body="Whatever yields a row's sentence yields its bit and both kinds of its delivery; one "
                                "refuter refutes both kinds at once.") + 6
    return y


# ---------------------------------------------------------------- figure 5 · the grade ledger
def fig5(y):
    cnt = collections.defaultdict(collections.Counter)
    for short, lst in IDX["decl"].items():
        for full, line_, kind, mod in lst:
            if kind not in ("theorem", "lemma"):
                continue
            c = IDX["cone"].get(full)
            if c is None:
                continue
            cnt[mod][{"p": "pq", "pQ": "pq"}.get(c, c)] += 1
    mods = [("RH", "Millennium.RH"), ("P≠NP", "Millennium.PNP"), ("NS", "Millennium.NS"), ("YM", "Millennium.YM"),
            ("Hodge", "Millennium.Hodge"), ("BSD", "Millennium.BSD"), ("Poincaré", "Millennium.PC")]
    mx = max(sum(cnt[m].values()) for _, m in mods)
    lab_w, bar_w = 120, CW - 120 - 230
    y += section_title(y, "THEOREMS WITH A PINNED CONE, BY ROW MASTER, AND THE GRADE OF EACH BIT") + 6
    for r, m in mods:
        c = cnt[m]
        tot = sum(c.values())
        rect(M, y, CW, 34, WHITE, LINE, 1, rx=6)
        text(M + 12, y + 22, r, "s", 700, 12, INK)
        x = M + lab_w
        for key, col in (("∅", G), ("pq", T), ("std", B)):
            wd = bar_w * c[key] / mx
            if wd > 0:
                rect(x, y + 8, wd, 18, col, rx=3)
            x += wd
        text(M + lab_w + bar_w + 14, y + 22, f"{tot}: {c['∅']} · {c['pq']} · {c['std']}", "s", 400, 11.4, BODY)
        y += 40
    rect(M, y, CW, 34, A_T, A, 1.2, rx=6)
    text(M + 12, y + 22, "THE BIT", "s", 700, 12, A_D)
    text(M + lab_w, y + 22, "premise on all seven rows in the kernel; the Poincaré delivery accepted as unconditional "
         "by the Clay Institute", "s", 400, 11.6, BODY)
    y += 44
    y += idband(y, "ONE FOOTING IN THE KERNEL", ["MillenniumGrandMaster.one_footing_in_the_kernel",
                                                "MillenniumGrandMaster.every_bit_is_printed_as_a_premise",
                                                "MillenniumGrandMaster.formGrade", "MillenniumGrandMaster.kernelBitGrade"],
                body="Counts read each module's own pins: on no axiom, on propext with Quot.sound, on Lean's standard "
                     "axioms. The five v1.1.0 rows rest wholly on no axiom; the RH master reaches Lean's standard "
                     "axioms through Mathlib's analysis, the P ≠ NP master through classical reasoning over machines.") + 6
    return y


# ---------------------------------------------------------------- figure 6 · two domains and the Poincaré precedent
def fig6(y):
    cols = ["THE KERNEL · LEAN 4", "THE RECORD · ACCEPTANCE", "LEAN WITH THE BIT ADOPTED"]
    lab_w = 150
    cw = (CW - lab_w) / 3
    rect(M, y, CW, 34, NAVY, rx=7)
    text(M + 14, y + 22, "ROW", "s", 700, 11.6, GOLD, ls="0.8")
    for j, c in enumerate(cols):
        text(M + lab_w + j * cw + cw / 2, y + 22, c, "s", 700, 11.4, WHITE, "middle")
    y += 40
    for r in ROWS:
        rh_ = 48
        rect(M, y, lab_w - 6, rh_, WHITE, LINE, 1, rx=6)
        text(M + 12, y + 29, r, "s", 700, 12, INK)
        pc = r == "Poincaré"
        cells = [(["form proved", "bit a premise"], B_T, B),
                 ((["delivery accepted as unconditional", "Clay Institute, 2010"] if pc else
                   ["delivered twice", "qualifies for the same standing"]), (V_T if pc else A_T), (V if pc else A)),
                 (["theorem"], G_T, G)]
        for j, (tl_, tint, col) in enumerate(cells):
            x = M + lab_w + j * cw
            rect(x + 3, y, cw - 6, rh_, tint, col, 1.2, rx=6)
            y0 = y + (rh_ - 15 * len(tl_)) / 2 + 11
            for k, t in enumerate(tl_):
                text(x + cw / 2, y0 + k * 15, t, "s", 700, 11, col, "middle")
        y += rh_ + 6
    y += 4
    y += idband(y, "THE POINCARÉ PRECEDENT, IN THE KERNEL",
                ["MillenniumGrandMaster.the_poincare_precedent", "MillenniumGrandMaster.four_rows_one_shape_at_the_library",
                 "MillenniumGrandMaster.the_witness_is_a_strict_subtype",
                 "MillenniumGrandMaster.the_offering_is_strictly_inside_the_bit",
                 "MillenniumGrandMaster.the_bit_is_the_minimal_premise", "PerelmanHunt.upgrade_is_adoption"],
                color=V_D, body="In Lean the Poincaré bit is a premise like the other six and is the library's statement "
                                "exactly as theirs are; the record accepted its delivery as unconditional. The 2002 "
                                "functional is a downstream strict subtype of the bridge, Perelman's offering one "
                                "inhabitant strictly inside the bit, its faithful route strictly stronger than the "
                                "sentence; the bit is the minimal premise. The six bits stand where the "
                                "Poincaré bit stands, minimal and delivered twice, and qualify for the same standing on "
                                "the stronger case.") + 6
    return y


# ---------------------------------------------------------------- figure 7 · seven bits, seven keys
def fig7(y):
    y += section_title(y, "THE 128 PATTERNS OF THE SEVEN VALUES, EACH REALIZED ON THE PRODUCT OF THE ROWS' OWN FRAMES") + 6
    cols, rows_ = 16, 8
    cell = (CW - 2 * 14) / cols
    hgt = 30
    rect(M, y, CW, rows_ * (hgt + 4) + 20, WHITE, LINE, 1, rx=8)
    for k in range(128):
        r_, c_ = divmod(k, cols)
        x = M + 14 + c_ * cell
        yy = y + 10 + r_ * (hgt + 4)
        bits = format(k, "07b")
        full = k == 127
        pc_only = bits == "0000001"
        fill, col = ((GOLD, NAVY) if full else ((V_T, V) if pc_only else (BG, LINE)))
        rect(x + 2, yy, cell - 4, hgt, fill, col, 1.2 if (full or pc_only) else 0.8, rx=4)
        text(x + cell / 2, yy + 19, bits, "m", 700 if full else 400, 9.6, NAVY if full else (V if pc_only else GREY), "middle")
    y += rows_ * (hgt + 4) + 20 + 10
    y += idband(y, "SEVEN BITS, SEVEN KEYS, EACH DELIVERED ON ITS OWN ROW",
                ["PerelmanHunt.the_seven_values_are_independent", "PerelmanHunt.seven_keys",
                 "PerelmanHunt.a_unified_principle_rejects_every_counter_pattern", "PerelmanHunt.poincare_settles_no_other"],
                color=NAVY2, body="Bits read RH, P ≠ NP, NS, YM, Hodge, BSD, Poincaré from left to right; gold is all "
                                  "seven, violet is Poincaré alone. Every pattern is realized, so the seven bits are "
                                  "independent: a principle delivering all seven rejects the other 127 patterns and "
                                  "carries a key on every row, and the Poincaré bit settles no other.") + 6
    return y


# ---------------------------------------------------------------- figure 5 · the method in one theorem
def figM(y):
    lw, mw = 330, 250
    rw = CW - lw - mw - 40
    xl, xm, xr = M, M + lw + 20, M + lw + 20 + mw + 20
    inputs = [("A ROW OF THE NORMAL FORM", "frames, the value, the record of each frame, the record carrying the value "
               "with no premise", ["MillenniumGrandMaster.NRow", "MillenniumGrandMaster.Closure"]),
              ("A HOST", "a frame whose value is exactly the row's sentence", []),
              ("A CALM FRAME", "a frame where the value holds", []),
              ("A COUNTER FRAME", "a frame where the value fails", [])]
    outs = [("the sentence is the bit", "MillenniumGrandMaster.Closure.sentence_is_the_bit"),
            ("the record decides nothing", "MillenniumGrandMaster.Closure.record_decides_nothing"),
            ("no keyless premise forces the value", "MillenniumGrandMaster.Closure.the_wall_on_the_row"),
            ("the bit has no uniform answer", "MillenniumGrandMaster.Closure.no_uniform_answer"),
            ("every route passes the bit", "MillenniumGrandMaster.Closure.every_route_passes_the_bit"),
            ("either delivery gives the sentence", "MillenniumGrandMaster.Closure.delivered_twice"),
            ("the upgrade of the bit is adopting the sentence",
             "MillenniumGrandMaster.Closure.upgrade_is_adopting_the_sentence")]
    # left: four inputs
    rect(xl, y, lw, 30, NAVY, rx=7)
    text(xl + 14, y + 20, "FOUR INPUTS · WHAT A ROW BUILDS", "s", 700, 11.4, GOLD, ls="0.6")
    cy = y + 38
    for t, b, ids in inputs:
        bl = wrap(b, lw - 30, "s", 400, 11.2)
        il = id_lines(ids, lw - 30, 10.4)
        hh = 24 + len(bl) * 14.5 + len(il) * 14 + 6
        rect(xl, cy, lw, hh, WHITE, LINE, 1, rx=6)
        rect(xl, cy, 5, hh, B)
        text(xl + 16, cy + 17, t, "s", 700, 11.2, INK)
        for k, l in enumerate(bl):
            text(xl + 16, cy + 33 + k * 14.5, l, "s", 400, 11.2, BODY)
        ids_draw(xl + 16, cy + 33 + len(bl) * 14.5, il, 10.4, 14)
        cy += hh + 8
    left_bottom = cy
    # right: seven conclusions
    rect(xr, y, rw, 30, NAVY, rx=7)
    text(xr + 14, y + 20, "SEVEN CONCLUSIONS · ON NO AXIOM", "s", 700, 11.4, GOLD, ls="0.6")
    cy2 = y + 38
    for t, nm in outs:
        il = id_lines([nm], rw - 30, 10.4)
        hh = 22 + len(il) * 14 + 4
        rect(xr, cy2, rw, hh, G_T, G, 1.1, rx=6)
        text(xr + 14, cy2 + 16, t, "s", 700, 11.2, G_D)
        ids_draw(xr + 14, cy2 + 31, il, 10.4, 14)
        cy2 += hh + 6
    bottom = max(left_bottom, cy2)
    # middle: the theorem
    mh = 150
    my = y + (bottom - y) / 2 - mh / 2
    rect(xm, my, mw, mh, NAVY2, NAVY, 1.4, rx=10)
    text(xm + mw / 2, my + 32, "ONE THEOREM", "s", 700, 13, GOLD, "middle", ls="1.0")
    il = id_lines(["MillenniumGrandMaster.Closure.the_method"], mw - 20, 12.4, 700)
    rect(xm + 40, my + 45, mw - 80, 26, WHITE, rx=7)
    ids_draw(xm + mw / 2, my + 62, il, 12.4, 16, 700, "middle")
    for k, l in enumerate(wrap("nothing before its colon beyond the four inputs", mw - 30, "s", 400, 11)):
        text(xm + mw / 2, my + 92 + k * 14, l, "s", 400, 11, "#dbe6f1", "middle")
    line(xl + lw + 2, my + mh / 2, xm - 4, my + mh / 2, ARROW, 2.2, "arr")
    line(xm + mw + 4, my + mh / 2, xr - 4, my + mh / 2, ARROW, 2.2, "arr")
    y = bottom + 6
    y += idband(y, "RUN ON THE ROWS, AT EVERY HOST",
                ["MillenniumGrandMaster.the_method_on_the_rows", "MillenniumGrandMaster.no_record_predicate_decides_on_four_rows",
                 "MillenniumGrandMaster.the_closure_on_its_toy_row", "MillenniumGrandMaster.Closure.record_predicate_decides_nothing"],
                color=G_D, body="The master builds the four inputs on Navier–Stokes, Yang–Mills, Hodge, BSD and Poincaré at every host, "
                                "and on Goldbach, and the method returns all seven conclusions on each; where the calm and "
                                "the counter frame share one record, no predicate of the record decides the value.") + 6
    return y


FIGS = [(1, "SEVEN QUESTIONS, ONE NORMAL FORM", fig1),
        (2, "THE TEN STEPS ACROSS THE SEVEN ROWS", fig2),
        (3, "THE WALLS: WHAT EVERY FRAME SHARES FORCES NOTHING", fig3),
        (4, "THE BIT DELIVERED TWICE, SEVEN TIMES", fig4),
        (5, "THE METHOD IN ONE THEOREM, RUN ON THE ROWS", figM),
        (6, "THE GRADE LEDGER: ONE FOOTING IN THE KERNEL", fig5),
        (7, "TWO DOMAINS AND THE POINCARÉ PRECEDENT", fig6),
        (8, "SEVEN BITS, SEVEN KEYS", fig7)]

exec(open(os.path.join(HERE, "figtail_ref.py"), encoding="utf-8").read().split("FIGS = [")[0])

if __name__ == "__main__":
    os.makedirs(OUTDIR, exist_ok=True)
    only = {int(a) for a in sys.argv[1:]} if len(sys.argv) > 1 else None
    allchecked = {}
    for num, title, body in FIGS:
        if only and num not in only:
            continue
        E.clear(); USED.clear(); CHECKED.clear()
        E.append("BG")
        y = fig_header(num, title) + 12
        y = body(y) + 12
        y += legend(y) + 12
        H = int(round(y))
        E[0] = f'<rect x="0" y="0" width="{W}" height="{H}" fill="{BG}"/>'
        faces = [font_face(("s", 400), "RowSans", 400), font_face(("s", 700), "RowSans", 700),
                 font_face(("m", 400), "RowMono", 400), font_face(("m", 700), "RowMono", 700)]
        defs = ('<defs>'
                f'<marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
                f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{ARROW}"/></marker>'
                f'<style>{"".join(faces)}</style></defs>')
        ttl = f"{CFG['short']} · Figure {num} · {string.capwords(title.lower())}"
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" '
               f'aria-label="{escape(ttl)}">\n<title>{escape(ttl)}</title>\n{defs}\n' + "\n".join(E) + "\n</svg>\n")
        fn = f"{OUTDIR}/{CFG['stem']}_Figure_{num}_v1_0_0_CC.svg"
        open(fn, "w", encoding="utf-8").write(svg)
        allchecked.update(CHECKED)
        print(f"[SYNTH] Figure {num}: {W}x{H}, {len(CHECKED)} names checked")
    json.dump({k: list(v) for k, v in allchecked.items()}, open(f"{OUTDIR}/checked_ids.json", "w"), indent=0,
              ensure_ascii=False)
