#!/usr/bin/env python3
"""build_index.py · index of every declaration of the Millennium Grand Master tree (module, FQN, kind, line) with the
cone each module pins for it. Usage: build_index.py SRC_DIR OUT_JSON"""
import re, sys, json, os, glob
SRC, OUT = sys.argv[1], sys.argv[2]
DECL = re.compile(r"^(?:@\[[^\]]*\]\s*)?(?:(?:private|protected|noncomputable|partial|unsafe)\s+)*"
                  r"(theorem|lemma|def|abbrev|structure|inductive|class|instance|axiom|opaque)\s+([^\s:({\[]+)")
PIN = re.compile(r"/--\s*info:\s*(.*?)-/\s*#guard_msgs\s+in\s+#print\s+axioms\s+(\S+)", re.S)
def cone_of(msg):
    m = re.sub(r"\s+", " ", msg)
    if "does not depend on any axioms" in m: return "∅"
    ax = re.search(r"depends on axioms: \[([^\]]*)\]", m)
    if not ax: return None
    s = {a.strip() for a in ax.group(1).split(",")}
    if s <= {"propext"}: return "p"
    if s <= {"propext", "Quot.sound"}: return "pQ"
    if s <= {"propext", "Quot.sound", "Classical.choice"}: return "std"
    return "other:" + ",".join(sorted(s))
idx = {"decl": {}, "cone": {}, "module": {}}
files = sorted(glob.glob(SRC + "/Millennium/*.lean")) + sorted(glob.glob(SRC + "/*.lean"))
for f in files:
    mod = os.path.relpath(f, SRC)[:-5].replace("/", ".")
    src = open(f, encoding="utf-8").read()
    lines = src.split("\n"); stack = []; depth = 0
    for i, ln in enumerate(lines, 1):
        if depth > 0:
            depth += ln.count("/-") - ln.count("-/"); continue
        if ln.startswith("/-") and not ln.startswith("/--"):
            d = ln.count("/-") - ln.count("-/")
            if d > 0: depth = d
            continue
        if not ln[:1] or ln[:1].isspace(): continue
        m = re.match(r"namespace\s+(\S+)", ln)
        if m: stack.append(m.group(1)); continue
        if re.match(r"section\b", ln): stack.append(""); continue
        if re.match(r"end\b", ln) and not re.match(r"end\w", ln):
            if stack: stack.pop()
            continue
        m = DECL.match(ln)
        if m:
            kind, name = m.group(1), m.group(2)
            ns = ".".join(x for x in stack if x)
            full = name[7:] if name.startswith("_root_.") else ((ns + "." + name) if ns else name)
            short = full.split(".")[-1]
            idx["decl"].setdefault(short, []).append([full, i, kind, mod])
            idx["module"][full] = mod
    for m in PIN.finditer(src):
        msg, nm = m.group(1), m.group(2)
        mm = re.search(r"'([^']+)'", msg)
        full = mm.group(1) if mm else nm
        c = cone_of(msg)
        if c: idx["cone"][full] = c
json.dump(idx, open(OUT, "w"), ensure_ascii=False)
print(f"{sum(len(v) for v in idx['decl'].values())} declarations, {len(idx['cone'])} pinned cones, {len(files)} modules")
