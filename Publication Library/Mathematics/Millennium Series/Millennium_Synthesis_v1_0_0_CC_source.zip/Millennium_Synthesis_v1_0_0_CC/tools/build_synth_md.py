#!/usr/bin/env python3
"""build_synth_md.py · the Markdown master of the Millennium synthesis paper, edition 1.0.0_CC.

Assembles src/*.md in order; replaces [[FIG:n]] by the full-width figure; fills every @...@ receipt from the master's
census (cert/census.json); halts on any unfilled placeholder or any figure out of order; and appends the
machine-readable carrier: the manifest, the root file, the hunt module, the certificate script and the certificate."""
import glob, hashlib, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.dirname(os.path.dirname(HERE))
MASTER = os.path.join(SP, "master")
OUT = os.path.join(HERE, "out")
MD = "Millennium_Synthesis_v1_0_0_CC.md"
os.makedirs(OUT, exist_ok=True)

CAP = {
    1: "Seven questions, one normal form: the bit of a frame is exactly its value, proved once on no axiom and recovered "
       "as each row's own normal form by exact type; at four rows the bit is the library's own statement. Every name is "
       "a declaration of the master, colored by its pinned cone.",
    2: "The ten steps across the seven rows: Steps 1 to 9 theorems on every row, Step 8 over the cited published real part "
       "at five rows, Step 10 the bit, a premise on all seven, delivered twice; the Poincaré delivery accepted as "
       "unconditional.",
    3: "The walls: on every row two frames share the record and split on the value, so a premise shared by every frame "
       "forces nothing; bound together, one principle forcing all seven values carries a key on every row.",
    4: "The bit delivered twice, seven times: the formal cargo and the physical witness on every row, two kinds and no "
       "third, one refuter refuting both.",
    5: "The method in one theorem: four inputs a row builds, seven conclusions the method returns on no axiom, and the "
       "method run on Navier–Stokes, Yang–Mills, Hodge, BSD and Poincaré at every host and on Goldbach.",
    6: "The grade ledger: theorems with a pinned cone in each row master, by cone, and the grade of the bit, a premise on "
       "all seven rows in the kernel.",
    7: "Two domains and the Poincaré precedent: in the kernel the seven bits stand on one footing; in the record the "
       "Poincaré delivery was accepted as unconditional; the 2002 functional is a downstream strict subtype of the bridge, "
       "Perelman's offering one inhabitant strictly inside the bit, and the bit the minimal premise.",
    8: "Seven bits, seven keys: every one of the 128 patterns of the seven values is realized on the product of the rows' "
       "own frames; the bits are independent, each delivered on its own row.",
}


def fig(m):
    n = int(m.group(1))
    return ("```{=latex}\n\\begin{figure*}[tp]\n\\centering\n"
            "\\includegraphics[width=\\textwidth]{figs/Millennium_Synthesis_Figure_%d_v1_0_0_CC.pdf}\\\\[5pt]\n"
            "\\begin{minipage}{\\textwidth}\\footnotesize{\\color{deep}\\textbf{Figure %d}}\\ \\textbar\\ %s\\end{minipage}\n"
            "\\end{figure*}\n```" % (n, n, CAP[n]))


parts = sorted(glob.glob(os.path.join(HERE, "src", "*.md")))
body = "\n".join(open(p, encoding="utf-8").read().rstrip("\n") + "\n" for p in parts)
figs = [int(x) for x in re.findall(r"\[\[FIG:(\d)\]\]", body)]
if sorted(figs) != list(range(1, 9)) or len(figs) != 8:
    raise SystemExit(f"figures: {figs}")
first = [figs.index(n) for n in range(1, 9)]
body = re.sub(r"\[\[FIG:(\d)\]\]", fig, body)

census = json.load(open(os.path.join(MASTER, "cert", "census.json"), encoding="utf-8"))
if not census.get("all_pass"):
    raise SystemExit("census: certificates do not all pass")
rows = {r["file"]: r for r in census["rows"]}


def src_path(f):
    return os.path.join(MASTER, "src", f)


def nlines(f):
    return open(src_path(f), encoding="utf-8").read().count("\n")


def fill(m):
    kind, f = m.group(1), m.group(2)
    r = rows[f]
    return {"SHA": r["sha256"][:16], "BYTES": "{:,}".format(r["bytes"]), "THM": str(r["theorems"]),
            "PIN": str(r["pins"]), "LINES": "{:,}".format(nlines(f))}[kind]


body = re.sub(r"@(SHA|BYTES|THM|PIN|LINES):([A-Za-z0-9_./]+)@", fill, body)
body = body.replace("@LINESTOTAL@", "{:,}".format(sum(nlines(f) for f in rows)))
body = body.replace("@THMTOTAL@", "{:,}".format(census["total_theorems"])).replace("@PINTOTAL@",
                                                                                    "{:,}".format(census["total_pins"]))
left = re.findall(r"@[A-Z]+[:@]|\[\[[A-Z]+:", body)
if left:
    raise SystemExit(f"unfilled: {left[:5]}")
# the receipts stated in prose must match the census
for n, what in ((census["total_theorems"], "theorems"), (census["total_pins"], "pins")):
    if "{:,}".format(n) not in body:
        raise SystemExit(f"prose does not state the census {what}: {n}")

# carrier
carry = [(r["file"], "lean", src_path(r["file"])) for r in census["rows"]]
extra = [("certify.py", "python", os.path.join(MASTER, "certify.py")),
         ("CERTIFICATE.txt", "text", os.path.join(MASTER, "cert", "CERTIFICATE.txt"))]
man = ["%s  %s" % (r["sha256"], r["file"]) for r in census["rows"]]
carry += extra
for name, lang, path in extra:
    man.append("%s  %s" % (hashlib.sha256(open(path, "rb").read()).hexdigest(), name))
blk = ["<!--", "MACHINE-READABLE KERNELS AND MANIFEST (not rendered). Extract with:",
       "awk '{sub(/\\r$/,\"\")} /^~~~~~[a-z0-9]+ file=[A-Za-z0-9_.\\/]+$/{sub(/.*file=/,\"\");f=$0;next} "
       "/^~~~~~$/{if(f!=\"\"){close(f);f=\"\"};next} f!=\"\"{print > f}' " + MD,
       "Run `mkdir -p Millennium` first: every file of the master's tree is carried at its path in the tree, so the",
       "extraction rebuilds the exact tree that compiles, the root beside the folder Millennium/.",
       "", "~~~~~sha256 file=MANIFEST.sha256"] + man + ["~~~~~", ""]
for name, lang, path in carry:
    text = open(path, encoding="utf-8").read()
    if "\n~~~~~" in text or "-->" in text:
        raise SystemExit("unsafe carried file " + name)
    blk += ["~~~~~%s file=%s" % (lang, name), text.rstrip("\n"), "~~~~~", ""]
blk.append("-->")
out = body.rstrip("\n") + "\n\n" + "\n".join(blk) + "\n"
open(os.path.join(OUT, MD), "w", encoding="utf-8").write(out)
words = len(out.split("\n<!--\nMACHINE-READABLE")[0].split())
print(f"{MD}: body {words} words · figures at first use order {first} · census {census['total_theorems']} theorems, "
      f"{census['total_pins']} pins")
