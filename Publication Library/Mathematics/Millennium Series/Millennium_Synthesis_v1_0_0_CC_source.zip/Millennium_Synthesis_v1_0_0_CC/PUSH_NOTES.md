# Push plan · Millennium Synthesis v1.0.0_CC (nothing has been pushed)

Every step below waits for the Architect's explicit yes to this printed plan (L1). Credentials are supplied by
environment reference at push time only: never echoed, never written to disk or to git. No force push. Filing paths
were read from the live shelf of `1000sapients/Trisduction` (origin/main, 23 October 2026), not from memory.

## Push A · git, public repository `1000sapients/Trisduction`

First act: the index check of the root `INDEX.md` (L7). Then one artifact commit, all paths new (`_CC` files, nothing
replaced, nothing deleted):

| From this bundle | To the repository |
|---|---|
| `paper/Millennium_Synthesis_v1_0_0_CC.pdf`, `.md` | `Publication Library/Mathematics/Millennium Series/` |
| `paper/figs/*` (8 figures × SVG, PDF, PNG) | `Publication Library/Mathematics/Millennium Series/Millennium_Synthesis_Figures/` |
| `method/One_Bit_Method_v1_0_0_CC.pdf`, `.md`, `.lean` | `Publication Library/Mathematics/Millennium Series/` |
| `supplement_S1/Perelmanification_PreForge_Digest_v1_0_0_CC.md` | `Publication Library/Mathematics/Millennium Series/` |
| the whole bundle, zipped | `Publication Library/Mathematics/Millennium Series/Millennium_Synthesis_v1_0_0_CC_source.zip` |
| `lean/src/Millennium_Grand_Master_v1_0_0_CC.lean`, `lean/src/Millennium/*.lean`, `lean/build.sh`, `lean/certify.py`, `lean/cert/*` | `FINAL_BINDING/Grand Master/` (the tree kept as is, so it compiles where it lands) |

Thirteen of the seventeen modules are byte-identical to files already under `FINAL_BINDING/`; git stores identical
bytes once, so the tree costs only its new files. The sixteen originals in `lean/originals/` are already in the
repository and are not pushed again; `certify.py` reads them from wherever they stand.

Then the second component (L7): one SNAPSHOT line in `INDEX.md` naming the artifact commit's hash, and the MAP
regenerated from a full read of the tree. Before the push, the subtractive check: the parent's path set minus the staged
path set must be empty (L9). After the push, read back paths the commit did not touch.

## Push B · Zenodo, two new records (new concepts; nothing existing is replaced)

1. *The Millennium Problems: Unconditional Proof of the Form by Theorem, the Value by the Act*, v1.0.0_CC. Files: the PDF,
   the Markdown master, the source zip. Description: the abstract. Related identifiers: the eight row records (NS
   22670344, Hodge 22701510, Yang–Mills 23162231, Goldbach 23162238, Poincaré 23162240, BSD 23164992, RH 23440382,
   P ≠ NP 23528398) as references.
2. *The One-Bit Method*, v1.0.0_CC. Files: the PDF, the Markdown master, `One_Bit_Method_v1_0_0_CC.lean`. Related
   identifier: record 1 as the work it accompanies.

## Push C · Internet Archive (optional)

One mirror item per work, the PDF and the Markdown master; PDFs re-serialized without object streams first if the
archive's classifier refuses them.

## Push D · ledger

Two new work keys in `publication/trisduction_ledger.json` (`millennium_synthesis`, `one_bit_method`), with the git
paths, then the two DOIs once Push B returns them, written in the same push as the artifacts they record.

## Gates before any push

- `sha256sum -c MANIFEST.sha256` passes on this folder.
- `bash lean/build.sh <Mathlib v4.19.0 project>` reports BUILD PASS; `python3 lean/certify.py lean/src lean/originals lean/cert`
  reports 19 PASS, 2,967 theorems, 2,778 pins; `lean method/One_Bit_Method_v1_0_0_CC.lean` compiles silent.
- The Architect has read the paper and the method and answers yes to this plan.
