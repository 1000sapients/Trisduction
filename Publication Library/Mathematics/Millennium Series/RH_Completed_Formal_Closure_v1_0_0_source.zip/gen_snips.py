# -*- coding: utf-8 -*-
"""Extract Lean excerpts from the master file and render them with pygments to LaTeX
(fancyvrb/fvextra Verbatim) with line numbers equal to the master file's own line numbers."""
import re, pathlib
from pygments import highlight
from pygments.lexers import Lean4Lexer
from pygments.formatters import LatexFormatter
from pygments.style import Style
from pygments.token import Keyword, Name, Comment, String, Number, Operator, Punctuation, Text, Generic

SRC = pathlib.Path('../fc.lean').read_text(encoding='utf-8').splitlines()

class HouseStyle(Style):
    default_style = ''
    styles = {
        Text: '#171717', Punctuation: '#171717', Operator: '#171717',
        Keyword: 'bold #8A5523', Keyword.Type: '#1F3A66',
        Name: '#171717', Name.Function: '#171717', Name.Class: '#1F3A66', Name.Builtin: '#171717',
        Name.Decorator: '#8A5523', Name.Constant: '#171717', Name.Variable: '#171717',
        Comment: 'italic #6f6f6f', Comment.Multiline: 'italic #6f6f6f', Comment.Single: 'italic #6f6f6f',
        String: '#1F5C3D', String.Doc: 'italic #6f6f6f', Number: '#171717', Generic: '#171717',
    }

EXCERPTS = [
 ('defs', 345, 408, 'The complex chart: the translation dictionary and the definitions of Part X'),
 ('reading', 459, 477, 'The reading and the identification'),
 ('record', 479, 536, 'The record, the act, the transport measure, the cargo'),
 ('fixedpoint', 538, 565, 'Set-level idempotence and the fixed-point characterization (X-a)'),
 ('fiber', 592, 684, 'Fiber invariance and the barred refuter (X-c)'),
 ('toe0', 60, 87, 'The self-grounding root (Part I)'),
 ('faces', 567, 590, 'Analytic faces (X-b)'),
 ('loop', 686, 765, 'The self-grounding recursion and the five-way loop (X-d)'),
 ('binding', 767, 802, 'The eleven-part binding and the transfer status (X-d)'),
 ('strip', 804, 873, 'Strip equivalence and functional-equation closure (X-e)'),
 ('orbit', 875, 947, 'Retraction injectivity and orbit collapse (X-f)'),
 ('chart', 949, 979, 'The discrete-to-complex chart homomorphism (X-g)'),
 ('schwarz', 980, 1095, 'Schwarz reflection for zeta and its two auxiliaries (X-h)'),
 ('nonvanish', 1097, 1173, 'Non-vanishing at the negative odd integers; the zeros avoid the nonpositive integers (X-h)'),
 ('zclosed', 1175, 1251, 'The zeros closed under s to 1-s, conjugation and the fold; the orbit collapse at the zeros; strip confinement (X-h)'),
 ('socket', 1417, 1458, 'The pins of X-h and the socket at the zeros (X-h)'),
 ('cone', 1460, 1518, 'The cone over the four readings of the bit (X-k)'),
 ('pause', 1520, 1567, 'The impossibility over $\mathbb{C}$, the pause and the unconditional forward pass (X-l)'),
 ('seal', 1569, 1632, 'The look back, the unconditional retrospective seal and the step to the hypothesis (X-l)'),
 ('canonical', 1634, 1661, 'The canonical apex: the canonical record hypothesis, unconditional, and the property off the line (X-l)'),
 ('monism', 1663, 1718, 'The Monism witness over $\mathbb{C}$ and the canonical normal-form bridge (X-l)'),
 ('target', 1720, 1793, 'The Euler product boundary and the analytic target reduction (X-l)'),
 ('roundtwo', 1795, 1873, 'Round 2: the least erasure of the record as a self-grounding root, the halt, the residual monism, and the delivery of the bit by every route (X-l)'),
 ('sealed', 1875, 1901, 'The analytic route sealed (X-l)'),
 ('gol', 1903, 1990, 'The complex three-axis lock, the Ground-On-Line locus and its loop (X-l)'),
 ('band', 1992, 2099, 'The strict strip, the completed zeros, and the zero-free band (X-l)'),
 ('selfrec', 2101, 2166, 'The self-recognition of the zeros and the self-recognition closure (X-l)'),
]

fmt0 = LatexFormatter(style=HouseStyle)
pathlib.Path('snips/pygstyle.tex').write_text(fmt0.get_style_defs(), encoding='utf-8')
meta = []
for name, a, b, title in EXCERPTS:
    code = '\n'.join(SRC[a-1:b])
    fmt = LatexFormatter(style=HouseStyle, linenos=True, linenostart=a, envname='Verbatim',
                         verboptions=r'breaklines,breaksymbolleft={},breakindent=1.2em,breakafter={_.},breakaftersymbolpre={},breakaftersymbolpost={},fontsize=\leancodesize,numbersep=4pt,xleftmargin=1.9em,baselinestretch=1.0')
    if name=='pins':
        fmt = LatexFormatter(style=HouseStyle, linenos=True, linenostart=a, envname='Verbatim', verboptions=r'breaklines,breakanywhere,breaksymbolleft={},breakanywheresymbolpre={},breakindent=1.2em,fontsize=\leancodesize,numbersep=4pt,xleftmargin=1.9em,baselinestretch=1.0')
    out = highlight(code, Lean4Lexer(stripnl=False), fmt)
    pathlib.Path(f'snips/{name}.tex').write_text(out, encoding='utf-8')
    meta.append((name, a, b, title, b-a+1))
    print(f'{name:10s} {a:>6}-{b:<6} {b-a+1:>4} lines  {title}')
pathlib.Path('snips/meta.txt').write_text('\n'.join(f'{m[0]}\t{m[1]}\t{m[2]}\t{m[3]}' for m in meta))
