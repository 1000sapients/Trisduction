Build: xelatex paper.tex (twice). Requires TeX Gyre Pagella, DejaVu Sans Mono, fontspec, fvextra, multicol, needspace, pygments (Lean4Lexer).
Regenerate listings from the deposited file:  python3 gen_snips.py   (reads ../fc.lean = RH_Formal_Closure_v1_0_0_CC.lean, SHA-256 4af02e33...aab3)
Regenerate Appendix D:                        python3 gen_fullfile.py
Markdown master:                              python3 gen_md.py   (pandoc, gfm; reads paper.aux for cross-references); audit edition: python3 gen_md.py --no-fullfile
