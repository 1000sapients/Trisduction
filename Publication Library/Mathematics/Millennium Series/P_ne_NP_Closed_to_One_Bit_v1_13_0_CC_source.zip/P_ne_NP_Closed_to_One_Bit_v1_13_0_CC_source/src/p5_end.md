# Nothing escapes: our way or no way {#sec-escape}

Part X of the kernel codifies the outside of the record and the two kinds that fill it.

**[[T:the_record_closes_at_tmsat]]** (`the_record_closes_at_tmsat`, `the_undecided_is_the_bit`, no axiom). *The record of the SAT machine has least escape, and what it leaves undecided, whether $\mathrm{TMSAT}$ itself closes, is exactly the bit.*

**[[T:nothing_outside_the_record_is_the_bit]]** (`nothing_outside_the_record_is_the_bit`, no axiom). *Read as a law of every machine, "nothing is outside the record" is false, since the stage world's record closes and the machine does not; read at $\mathrm{TMSAT}$, it is the bit.*

A block needs an outside ([[R:block_needs_an_outside]]): if the target is a function of the record, no record-preserving involution flips it. At $\mathrm{TMSAT}$ the outside is the supply.

**[[T:the_outside_is_the_supply]]** (`the_outside_is_the_supply`, classical). *The formal cargo is the bit, an inhabited physical witness is the bit, and every physical witness is a formal cargo.*

**[[T:every_route_is_both_kinds]]** (`every_route_is_both_kinds`, classical). *Whatever premise, in whatever vocabulary, gives $\mathrm{SAT} \notin \mathbf{P}$ delivers the formal cargo and a physical witness, with nothing cited.*

**[[T:every_delivery_is_both_kinds]]** (`every_delivery_is_both_kinds`, classical). *With the hardness half cited, whatever premise, in whatever vocabulary, gives $\mathbf{P} \neq \mathbf{NP}$ delivers the formal cargo and a physical witness.*

An offering that crosses the row, a proof from the standard axioms among them, is a delivery of the cargo, never a bypass of it.

**[[T:our_way_or_no_way]]** (`our_way_or_no_way`, classical). *With the hardness half cited, every so-called other way to $\mathbf{P} \neq \mathbf{NP}$ is our way in different vocabulary: it delivers the formal cargo and a physical witness, and if the bit failed, it would fail with it.*

**[[T:nothing_escapes]]** (`nothing_escapes`, classical). *With nothing before the colon: the record of $\mathrm{TMSAT}$ closes; what it leaves undecided is the bit; no law of every machine puts everything inside the record; the outside is the supply in its two kinds; every route to $\mathrm{SAT} \notin \mathbf{P}$, and with the hardness half cited every delivery of $\mathbf{P} \neq \mathbf{NP}$, is a delivery of both kinds; either kind delivers $\mathbf{P} \neq \mathbf{NP}$; and every so-called other way is our way in different vocabulary.*

**[[T:the_capstone]]** (`the_capstone`, classical). *With nothing before the colon: our way or no way; either kind walks it to $\mathbf{P} \neq \mathbf{NP}$; no keyless premise forces anything; to shut every true route to the bit is to assert $\mathbf{P} = \mathbf{NP}$; and the twelve formal gates pass.*

Figure 7 draws the capstone.

[[FIG:7]]

# Conclusion {#sec-conclusion}

The gap was a missing form. The question of P versus NP had barriers against techniques and no formal statement of what any technique must produce. The kernel attached to this paper produces it on the real object: Turing machines with finite control and a tape, deciding the language of encoded satisfiable formulas, with the classes defined. The separation, stated over every Turing machine as $\neg\,\mathrm{SATinP}$, is one implication, the transfer of least escape from the record of the SAT machine to the SAT machine, the record's half proved with no axiom, and the implication keyed on the algorithms alone, unreachable from anything shared by all machines or by all algorithm models of SAT, delivered by every route as one object, and seated on no fixed point. $\mathrm{SAT} \in \mathbf{NP}$ is built in the kernel, degrees zero and one are constructed, and the residue is exactly the Diagonal Target from degree two, where the crossing count and the self-tableau are walled. The implication gives the sentence $\mathbf{P} \neq \mathbf{NP}$ with nothing cited, and [[S:supply]] supplies the implication by the act, delivered twice, by the formal cargo and by the physical witness. [[S:closure]] closes the question as a form: with the hardness half of Cook and Levin cited, $\mathbf{P} \neq \mathbf{NP}$ and the implication are one proposition, so the word *open* refers to the value of that implication, which no uniform premise fixes and which the act supplies. [[S:escape]] proves that nothing escapes: every route to the sentence, in any vocabulary, is a delivery of both kinds, our way or no way.

The seal reads in three faces. The form, at theorem grade. The walls, twenty-two at theorem grade in the kernel and seven carried from the Mother Codex at the grades their authors proved them. The value, $\mathbf{P} \neq \mathbf{NP}$, at premise grade, supplied by the act and delivered twice. The tuple does not compress, and the question stands at the Sealed halt, [Ø$_0$].

The primary falsifier is the silent build. Recompile the attached file under Lean 4.19.0 with warnings fatal; the paper stands or falls on exit code 0 and no output. The community is asked for that one execution, which any reader performs in about two minutes; the verifier the earlier edition asked for is built ([[S:np]]). The question that was open is now a type: the transfer, keyed, printed, assumed nowhere, and supplied by the act.

The reframing is this: the question is no longer which technique can prove the separation but which keyed fact delivers one implication on one machine, and every technique reads as a carrier of that fact, delivering it in both kinds, or as a wall. Figure 8 states the verdict with its receipts.

[[FIG:8]]

\renewcommand{\dblfloatpagefraction}{0.2}
\clearpage
\appendix
\raggedbottom

# The kernel {#sec-kernel}

The file `PNP_Normal_Form_Paper_v1_13_0_CC.lean`, 10,358 lines, as compiled, set in two columns with its line numbers; a line longer than the column continues on the next line without a number. Its SHA-256 digest:

\begin{center}\small\ttfamily 98329a52b0e225f1 7488ad5f2710b7fd\\ 284269582877f037 30da94509cf8c415\end{center}

Parts A to G form the first edition of the file, whose header comment opens the listing; every later Part is additive and opens with its own header. Each Part's cones follow it as `#guard_msgs` lines.

\kernellisting{PNP_Normal_Form_Paper_v1_13_0_CC.lean}

# The compile receipt {#sec-receipt}

Lean 4.19.0 (commit 6caaee842e94) compiles the file on one core with no network, in [[RECEIPT:SECONDS]] seconds, by the one command

```
lean -DwarningAsError=true \
  PNP_Normal_Form_Paper_v1_13_0_CC.lean
```

The exit code is 0, and nothing is printed on standard output or on standard error. The fourteen executable checks and the 610 `#guard_msgs` pins are closed inside this compile and print nothing; each pin is the exact text the compiler produced for `#print axioms` on its constant, and it stands in Appendix A beneath the Part that proves the constant. A textual screen of the comment-stripped source counts zero occurrences of each of `sorry`, `admit`, `native_decide`, `axiom`, `unsafe`, `opaque`, `partial`, `noncomputable`, `@[extern`, `implemented_by` and `import`.

\begin{table}[h]
\footnotesize
\noindent{\color{deep}\textbf{Table 2}}\ \textbar\ The cones of the 610 pins.\\[3pt]
\begin{tabular*}{\columnwidth}{@{\extracolsep{\fill}}lr@{}}
\toprule
\textbf{Cone} & \textbf{Pins}\\
\midrule
no axiom & 258\\
\texttt{propext}, \texttt{Classical.choice}, \texttt{Quot.sound} & 126\\
\texttt{propext}, \texttt{Quot.sound} & 123\\
\texttt{propext} & 101\\
\texttt{Classical.choice} & 2\\
\midrule
total & 610\\
\bottomrule
\end{tabular*}
\end{table}

Seven controls of record, each a copy of the file with one change, are each refused by the compiler with exit code 1, Table 3. The first refusal is the bit itself: the record's closure offered where the machine's is required.

\begin{table}[h]
\footnotesize
\noindent{\color{deep}\textbf{Table 3}}\ \textbar\ The seven controls of record and the compiler's refusals.\\[3pt]
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.12in}>{\raggedright\arraybackslash}p{1.33in}>{\raggedright\arraybackslash}p{1.45in}@{}}
\toprule
& \textbf{The change} & \textbf{The refusal}\\
\midrule
1 & $\neg\,\mathrm{SATinP}$ planted with the identity map passed as the transfer. & Type mismatch: \texttt{NothingEscapes (Rec TMSAT)} offered for \texttt{NothingEscapes TMSAT}.\\
2 & The check on the string $\#$ altered to claim it is in SAT. & \texttt{decide} proved that \texttt{satLang [Sym.sep] = true} is false.\\
3 & A two-state machine accepting everything in zero steps, planted as a witness of $\mathrm{SATinP}$. & \texttt{verdictAt alwaysAccept w 0 = satLang w} is not closed by reflexivity.\\
4 & The pin of \texttt{sep\_normal\_form} altered to read no axiom. & \texttt{\#guard\_msgs}: the docstring does not match the generated cone.\\
5 & $\mathbf{P} \neq \mathbf{NP}$ asserted by \texttt{sorry}. & Declaration uses \texttt{sorry}, an error under the flag.\\
6 & The pin of \texttt{the\_two\_kinds\_are\_one\_bit} altered to read no axiom. & \texttt{\#guard\_msgs}: the docstring does not match the generated cone.\\
7 & $\mathbf{P} \neq \mathbf{NP} \leftrightarrow \mathrm{FormalCargo}$ with the hardness half used and not taken as a hypothesis. & Unknown identifier \texttt{hHard}.\\
\bottomrule
\end{tabular}
\end{table}

# Author's Provenance and Method Disclosure {-}

This paper was developed under Trisduction, a verification and organizing discipline whose method and executable batteries are stated in full in [19]. The kernel of Appendix A carries the register's `_CC` mark: it was coded and compiled by the author's AI scribe, Claude, under the author's direction and specification, and its correctness rests on the Lean 4 kernel alone, which checked every theorem, closed every executable check and matched every pinned cone. The eight figures were generated from the kernel's declaration index: every identifier they print resolves to a declaration of the file and is colored by its pinned cone.

# References {-}

\begingroup\raggedright

1. Cook, S. A. 1971. The complexity of theorem-proving procedures. *Proceedings of the Third Annual ACM Symposium on Theory of Computing*, 151–158.
2. Levin, L. A. 1973. Universal sequential search problems. *Problems of Information Transmission* 9(3): 265–266.
3. Karp, R. M. 1972. Reducibility among combinatorial problems. In *Complexity of Computer Computations*, R. E. Miller and J. W. Thatcher, eds., Plenum, 85–103.
4. Baker, T., Gill, J., and Solovay, R. 1975. Relativizations of the P =? NP question. *SIAM Journal on Computing* 4(4): 431–442.
5. Razborov, A. A., and Rudich, S. 1997. Natural proofs. *Journal of Computer and System Sciences* 55(1): 24–35.
6. Aaronson, S., and Wigderson, A. 2009. Algebrization: a new barrier in complexity theory. *ACM Transactions on Computation Theory* 1(1): 2:1–2:54.
7. Williams, R. 2014. Nonuniform ACC circuit lower bounds. *Journal of the ACM* 61(1): 2:1–2:32.
8. Fortnow, L. 2009. The status of the P versus NP problem. *Communications of the ACM* 52(9): 78–86.
9. Impagliazzo, R. 1995. A personal view of average-case complexity. *Proceedings of the Tenth Annual IEEE Structure in Complexity Theory Conference*, 134–147.
10. Sipser, M. 1992. The history and status of the P versus NP question. *Proceedings of the Twenty-Fourth Annual ACM Symposium on Theory of Computing*, 603–618.
11. Arora, S., and Barak, B. 2009. *Computational Complexity: A Modern Approach*. Cambridge University Press.
12. de Moura, L., and Ullrich, S. 2021. The Lean 4 theorem prover and programming language. *Automated Deduction, CADE 28*, Lecture Notes in Computer Science 12699, Springer, 625–635.
13. Sipser, M. 2013. *Introduction to the Theory of Computation*, third edition. Cengage Learning.
14. Islam, M. F. 2026. The Formal Closure of Computational Separation: P ≠ NP Closed on Existence Itself, Read on Computation. Zenodo, version 3.2.1, 4 October 2026. DOI 10.5281/zenodo.23133632. Register `1000sapients/Trisduction`, `Publication Library/Mathematics/Complexity Theory/P versus NP/`, with the kernels `PNP_Fortification.lean`, `PNP_Least_Escape.lean`, `PNP_Frontier_II.lean` and `PNP_Root.lean`.
15. Islam, M. 2026. MathOS^T^, Formal-Alone, edition 1.0.5, carrying the formal master `RH_Both_Sides_Formal_Master`, with the theorems `zeta_ra_loop`, `record_has_least_erasure`, `rh_from_the_cargo_loop`, `every_route_passes_the_bit` and `self_verifying_iff_true`. Register `1000sapients/Trisduction`, path `MathOS/MathOS_v1_0_5_Formal.md`, SHA-256 `f6cbfbaf1b89ddf7 b5a8fa00334f5c1f af206781f2125e95 2eeea8839f4ba0a0`.
16. Hartmanis, J., and Stearns, R. E. 1965. On the computational complexity of algorithms. *Transactions of the American Mathematical Society* 117: 285–306.
17. Cook, S. A., and Reckhow, R. A. 1979. The relative efficiency of propositional proof systems. *Journal of Symbolic Logic* 44(1): 36–50.
18. Mulmuley, K. D., and Sohoni, M. 2001. Geometric complexity theory I: an approach to the P vs. NP and related problems. *SIAM Journal on Computing* 31(2): 496–526.
19. Islam, M. TRISDUCTION: A Linguistically, Topologically, and Mathematically Sealed Verification Architecture. Triaxial Orthogonality, Twelve-Gate Closure, the Quaternionic Completion, the Root Axiom, and the Master Pre-Sealed Proposition Ledger. Zenodo, version 4, 19 June 2026. DOI 10.5281/zenodo.20757507. https://zenodo.org/records/20757507. Mirror: PhilArchive record ISLTTG, https://philpapers.org/rec/ISLTTG. Master reference, continuously updated at the same location.
20. Gäher, L., and Kunze, F. 2021. Mechanising complexity theory: the Cook–Levin theorem in Coq. *12th International Conference on Interactive Theorem Proving (ITP 2021)*, Leibniz International Proceedings in Informatics 193, 20:1–20:18.
21. Balbach, F. J. 2023. The Cook–Levin theorem. *Archive of Formal Proofs*, January 2023.
22. Landauer, R. 1961. Irreversibility and heat generation in the computing process. *IBM Journal of Research and Development* 5(3): 183–191.
23. Bérut, A., Arakelyan, A., Petrosyan, A., Ciliberto, S., Dillenschneider, R., and Lutz, E. 2012. Experimental verification of Landauer's principle linking information and thermodynamics. *Nature* 483: 187–189.
24. lean-dojo. 2025. Formalization of the Millennium Problems in Lean 4: `Problems/PVersusNP/Millennium.lean`. Reservoir package `@lean-dojo/problems`, repository <https://github.com/lean-dojo/LeanMillenniumPrizeProblems>.
25. Hennie, F. C. 1965. One-tape, off-line Turing machine computations. *Information and Control* 8(6): 553–578.
26. Razborov, A. A. 1995. Unprovability of lower bounds on circuit size in certain fragments of bounded arithmetic. *Izvestiya: Mathematics* 59(1): 205–227.
27. Bürgisser, P., Ikenmeyer, C., and Panova, G. 2016. No occurrence obstructions in geometric complexity theory. *57th Annual IEEE Symposium on Foundations of Computer Science (FOCS 2016)*; journal version, *Journal of the American Mathematical Society* 32 (2019): 163–193.
28. Chen, L., Hirahara, S., Oliveira, I. C., Pich, J., Rajgopal, N., and Santhanam, R. 2020. Beyond natural proofs: hardness magnification and locality. *11th Innovations in Theoretical Computer Science Conference (ITCS 2020)*, Leibniz International Proceedings in Informatics 151, 70:1–70:48; journal version, *Journal of the ACM*, 2022.
29. Islam, M. F. 2026. Trisduction: The Master Codex, the Unabridged Register of Record (the Geometric Mother Codex), version 3.48.0, coordinates APEX-PSP-BARRIER-MASTER-01 and APEX-PSP-ABSOLUTE-PNP-BARRIERS-01. Register `1000sapients/Trisduction`, path `master/TRISDUCTION_Master_Codex_Unabridged_v3_48_0.md`, SHA-256 `f24f2c70514533da a1f759ee5bcb2c66 1124f49b3ec451cc 6962928fc0979e50`.
30. Islam, M. F. 2026. Why the Structural Verdict on P versus NP Is the Only One Left Standing: Mathematics Proves That Mathematics Cannot Rule Here. Zenodo, version 2, 15 July 2026. DOI 10.5281/zenodo.21368936; concept DOI 10.5281/zenodo.20588699.

\endgroup

*End of manuscript.*
