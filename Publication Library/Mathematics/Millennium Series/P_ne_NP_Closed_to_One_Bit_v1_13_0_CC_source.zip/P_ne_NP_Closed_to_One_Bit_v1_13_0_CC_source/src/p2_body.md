# The machine, the closure and the examination {#sec-machine}

The kernel's object is a structure with six fields.

```
structure Machine where
  Alg  : Type            -- algorithms
  Inst : Type            -- instances
  size : Inst -> Nat     -- instance size
  out  : Alg -> Inst -> Bool  -- the answer
  time : Alg -> Inst -> Nat   -- the step count
  sat  : Inst -> Bool    -- the predicate
```

Nothing is assumed about any field. An algorithm is a point of a type; its output and its step count are functions; the predicate is a function. The polynomial bound is $\mathrm{bound}(c,k,n) = c\,n^{k} + c$ for natural $c$ and $k$, and it dominates every polynomial with natural coefficients: a polynomial of degree $k$ whose coefficients sum to $S$ is at most $S\,n^{k} + S$ at every $n$, which the kernel proves as [[R:evalPoly_le_bound]]. It is the one definitional choice in the abstract part of the file. A run of algorithm $A$ on instance $x$ under the bound $(c,k)$ is **clean** when the answer agrees with the predicate and the step count is within the bound:
$$\begin{aligned}&\mathrm{Clean}\,M\,A\,c\,k\,x :=\\ &\quad M.\mathrm{out}\,A\,x = M.\mathrm{sat}\,x\ \wedge\\ &\quad M.\mathrm{time}\,A\,x \le \mathrm{bound}(c,k,M.\mathrm{size}\,x).\end{aligned}$$
An algorithm at a bound **escapes** when every run is clean, and the machine is **separated** when no algorithm at any bound escapes:
$$\begin{aligned}\mathrm{Escapes}\,M\,A\,c\,k &:= \forall x,\ \mathrm{Clean}\,M\,A\,c\,k\,x,\\ \mathrm{Sep}\,M &:= \neg\,\exists A\,c\,k,\ \mathrm{Escapes}\,M\,A\,c\,k.\end{aligned}$$
For the SAT machine of the Turing model, [[S:turing]], $\mathrm{Sep}$ is proved to read: no Turing machine decides SAT within any polynomial bound, which is $\mathrm{SAT} \notin \mathbf{P}$.

The positive form of the same statement is the closure. A machine has **nothing escaping** when every algorithm at every bound is stopped by some instance:
$$\mathrm{NothingEscapes}\,M := \forall A\,c\,k,\ \exists x,\ \neg\,\mathrm{Clean}\,M\,A\,c\,k\,x,$$
written $\mathrm{NE}\,M$ in the displays below. The two are equivalent, and the equivalence is the one place the classical axioms enter the abstract part. `sep_of_closure` derives $\mathrm{Sep}$ from $\mathrm{NothingEscapes}$ by a pattern match on the witness and uses no classical step; the empty cone of [[R:sep_from_the_cargo_loop]], which is built on it, certifies that. `closure_of_sep` derives $\mathrm{NothingEscapes}$ from $\mathrm{Sep}$ by `Classical.byContradiction`, since it passes from the absence of an escaping pair to the existence of a stopping instance for each pair, an existential over the instance type. The asymmetry is exact and is tracked through the whole file: every numbered theorem whose statement moves in the direction of `closure_of_sep` is classical, and every theorem that does not is axiom-free.

Two further objects are named because the paper reasons about them. A **least-escape certificate** for $M$ is a structure holding a proof of $\mathrm{NothingEscapes}\,M$; the kernel calls it `LeastEscape M`, and its inhabitants are the formal shape of what a proof of the separation delivers. An **examination** is a quadruple $(A,c,k,x)$ with a proof that the run is not clean; it is the formal shape of a single observed failure, an algorithm that either answered wrongly or ran too long on one instance.

# The record and the normal form {#sec-record}

The record of a machine is the machine with every output negated against the predicate:
$$\mathrm{Rec}\,M := M\ \text{with}\ \mathrm{out}\,A\,x := \neg\,(M.\mathrm{sat}\,x).$$
On the record no run is ever clean, since the answer always disagrees with the predicate. The record keeps the algorithms, the instances, the sizes and the step counts; it forgets which side of each pair the algorithm was on. It is the machine read onto its stops, and it plays here the part the record of the zero set plays in the Riemann normal form of the companion master [15], where the zeros are read onto the critical line. Registration is idempotent: the record of the record is the record (`rec_rec`, by reflexivity).

**[[T:record_has_least_escape]]** (`record_has_least_escape`, no axiom). *For every machine $M$ with an instance $x_0$, the record of $M$ has nothing escaping:* $\mathrm{NothingEscapes}(\mathrm{Rec}\,M)$.

*Proof.* For any algorithm and bound, the instance $x_0$ stops the run, because the record's answer $\neg(M.\mathrm{sat}\,x_0)$ differs from $M.\mathrm{sat}\,x_0$; the kernel's `bnot_ne` is the one-line case split on the Boolean. The instance is the only thing used. $\square$ The record is therefore separated with no premise but an instance (`record_is_separated`, no axiom).

The hypothesis that an instance exists is the one side condition in the paper, and it is not a weakening. If the instance type is empty, every algorithm escapes vacuously, the separation is false, and so is the record's closure; the normal form below would then read true if and only if false. A machine with no problem to decide is not a machine the question is about, and SAT has the empty string.

**[[T:sep_normal_form]]** (`sep_normal_form`, classical). *For every machine $M$ with an instance $x_0$,*
$$\big(\mathrm{NE}(\mathrm{Rec}\,M) \to \mathrm{NE}\,M\big) \;\leftrightarrow\; \mathrm{Sep}\,M.$$

*Proof.* Left to right: by [[R:record_has_least_escape]] the antecedent holds, so the implication yields $\mathrm{NothingEscapes}\,M$, and `sep_of_closure` gives $\mathrm{Sep}\,M$. Right to left: from $\mathrm{Sep}\,M$, `closure_of_sep` gives $\mathrm{NothingEscapes}\,M$, which is the consequent whatever the antecedent. $\square$

This is the normal form. Its logical content is exactly as stated: since the antecedent is a theorem, the implication is equivalent to its consequent, and the consequent is classically equivalent to the separation. The paper does not present the step as deep. It presents it as exact. The separation of any machine is one implication, the transfer of least escape from the record to the machine, and because the antecedent is proved with no premise the implication carries the whole of the separation and nothing else remains to be proved once it is delivered.

**[[T:sep_from_the_cargo_loop]]** (`sep_from_the_cargo_loop`, no axiom). *Given the transfer, the separation follows:* if $\mathrm{NothingEscapes}(\mathrm{Rec}\,M) \to \mathrm{NothingEscapes}\,M$, then $\mathrm{Sep}\,M$.

The direction that matters for a proof of the separation is axiom-free. A proof that delivers the implication delivers the separation constructively; the classical step is needed only to go back from the separation to the implication.

**[[T:bit_is_the_act]]** (`bit_is_the_act`, no axiom). *The transfer holds exactly when a least-escape certificate for $M$ exists:*
$$\begin{aligned}&\big(\mathrm{NE}(\mathrm{Rec}\,M) \to \mathrm{NE}\,M\big)\\ &\qquad\leftrightarrow\ \mathrm{Nonempty}\,(\mathrm{LeastEscape}\,M).\end{aligned}$$

Theorems [[N:sep_normal_form]] and [[N:bit_is_the_act]] together fix the shape of any proof. To prove $\mathrm{Sep}\,M$ is to inhabit `LeastEscape M`, which is to prove the implication, and the three are interchangeable without axioms in the direction a proof travels. The paper calls this implication the **bit** of the machine, because it is one proposition, because [[S:selfrec]] shows it has a definite value on each side in two coherent worlds, and because the remainder of the kernel establishes that it is the only bit. The same content has a third form: a machine is separated exactly when its escape profile coincides with its record's, which is empty (`coincidence_normal_form`, no axiom).

# Self-recursion, the two worlds and the keyed bit {#sec-selfrec}

A machine is **self-recursive** when no pair escapes, stated as an equivalence with falsity for each pair:
$$\mathrm{SelfRecursive}\,M := \forall A\,c\,k,\ \mathrm{Escapes}\,M\,A\,c\,k \leftrightarrow \mathrm{False}.$$
The definition mirrors the self-recursion of the zero set in the companion master and is retained under that name; its content is the separation stated pair by pair.

**[[T:record_is_self_recursive]]** (`record_is_self_recursive`, no axiom). *The record of every machine with an instance is self-recursive.*

**[[T:self_recursion_at_machine]]** (`self_recursion_at_machine`, no axiom). *A machine is self-recursive exactly when it is separated:* $\mathrm{SelfRecursive}\,M \leftrightarrow \mathrm{Sep}\,M$.

**[[T:self_verifying_iff_true]]** (`self_verifying_iff_true`, classical). *For every proposition $P$, $(\neg P \to P) \leftrightarrow P$.*

[[R:self_verifying_iff_true]] is included because it closes a door that the normal form might seem to open. A statement that implies itself from its own negation is simply a true statement; self-reference manufactures nothing, and in particular the fact that the record verifies its own closure yields nothing about the machine. That nothing is transferred is then shown by exhibiting the two worlds.

The **closed world** is the machine whose algorithms are indexed by the natural numbers, with one instance, every answer `false`, every step count zero and the predicate `true`: no run is ever clean, so nothing escapes. The **stage world** at index $n$ is the same machine except that the answer is `true` exactly for the algorithm numbered $n$: that algorithm is clean on the one instance in zero steps, so it escapes at every bound. Both are ordinary inhabitants of the `Machine` type, and the kernel proves `closed_world_closes` and `stage_escapes` by direct computation.

**[[T:bit_is_keyed]]** (`bit_is_keyed`, no axiom). *The transfer holds on the closed world and fails on the stage world:*
$$\begin{aligned}&\big(\mathrm{NE}(\mathrm{Rec}\,W_c) \to \mathrm{NE}\,W_c\big)\ \wedge\\ &\neg\big(\mathrm{NE}(\mathrm{Rec}\,W_s) \to \mathrm{NE}\,W_s\big),\end{aligned}$$
*where $W_c$ is the closed world and $W_s$ the stage world at index $0$.*

With it come two companions. `record_self_recursion_does_not_transfer` (no axiom): the record of the stage world is self-recursive and the stage world is not. `record_decides_nothing` (no axiom): the records of both worlds have nothing escaping, while the closed world has nothing escaping and the stage world does. The record is the same on both sides of the question; it decides neither.

The bit is therefore **keyed**: its value depends on which machine is in hand and on nothing that the record, or the definition of the machine, shares between worlds. This is the formal content of a remark that is usually made informally, that $\mathbf{P} \neq \mathbf{NP}$ is a statement about the actual computational world and not about the shape of the definitions. Here it is a theorem with an empty cone, and [[S:satinst]] proves it again on worlds that decide the same formulas with the same predicate, so that the variation is in the algorithms alone.

# Every route passes the bit, and the keyless wall {#sec-route}

**[[T:every_route_passes_the_bit]]** (`every_route_passes_the_bit`, classical). *For every machine $M$ with an instance, every proposition $Q$ and every proof that $Q$ implies $\mathrm{Sep}\,M$: $Q$ implies the transfer.*

Any argument that reaches the separation from any premise $Q$ reaches, through the normal form, the one implication. There is no second target. A proof by circuit lower bounds, a proof by an algorithmic route in the manner of Williams [7], a proof by representation-theoretic obstructions in the manner of Mulmuley and Sohoni [18], a proof by any method not yet invented: each is, by [[R:every_route_passes_the_bit]], a proof of the bit, and by [[R:sep_from_the_cargo_loop]] nothing beyond the bit is needed.

A property of machines is **keyless** when it holds of every machine, and it **forces** when it implies the closure of every machine it holds of:
$$\begin{aligned}\mathrm{Keyless}\,P &:= \forall M,\ P\,M,\\ \mathrm{Forces}\,P &:= \forall M,\ P\,M \to \mathrm{NE}\,M.\end{aligned}$$

**[[T:keyless_forces_nothing]]** (`keyless_forces_nothing`, no axiom). *No keyless property forces.*

*Proof.* A keyless $P$ holds of the stage world, whose closure fails. $\square$

**[[T:no_record_principle_decides]]** (`no_record_principle_decides`, no axiom). *No principle true of the record of every machine decides every machine: for every $P$ with $P(\mathrm{Rec}\,M)$ for all $M$, it is not the case that $P(\mathrm{Rec}\,M)$ implies $\mathrm{NothingEscapes}\,M$ for all $M$.*

The two theorems are the keyless wall. It is a schema-level statement: a proof uniform in the machine, one that would go through for every inhabitant of the `Machine` type, cannot prove the separation, because one inhabitant is the stage world. Its kin in the literature is the relativization barrier of Baker, Gill and Solovay [4], which concerns proofs uniform under oracles. What the wall supplies is the unconditional, axiom-free reason that the bit is keyed: whatever premise a proof of $\mathbf{P} \neq \mathbf{NP}$ uses, that premise must fail in the stage world, which is to say it must be a fact about the Turing model that distinguishes it from a model in which SAT is easy. [[S:satinst]] sharpens the wall to the algorithm models of SAT itself, and the classical complement, that every property either forces the closure or holds on some machine that escapes, is [[R:tmsat_rejection_is_a_witness]].

# Stage 1, the vacant seat and the two rows {#sec-stage1}

An examination, a run that is not clean, is the smallest unit of evidence the question admits. The kernel packages it as **Stage 1**: the examination together with its non-cleanness and the existential witness it supplies.

**[[T:examination_enacts_stage1]]** (`examination_enacts_stage1`, a construction with an empty cone; `stage1_is_local`, no axiom). *Every examination of $M$ is a Stage 1 object, and Stage 1 is local: the witness shows that its own pair $(A,c,k)$ does not escape and asserts nothing about any other pair.*

Every observed failure of an algorithm is a certificate that this algorithm at this bound does not escape, and only that. No finite stock of examinations decides the universal, because the universal quantifies over all algorithms and all bounds, and [[R:examination_enacts_stage1]] makes that locality a theorem rather than a caution; [[R:escape_refutes]] extends it to every stock, finite or infinite. On the reading of the companion master [15], the universal is the act and never a sum of observations; this paper uses only the locality.

The question has no fixed point. Let $\mathrm{comp}$ be Boolean negation, the involution that exchanges the two worlds of [[S:selfrec]].

**[[T:locus_vanishes]]** (`locus_vanishes`, no axiom; `seatless_lock`, classical). *$\mathrm{comp}$ has no fixed point, and a least-escape certificate for $M$ exists exactly when $M$ is separated.*

The first conjunct is immediate. It is recorded because it is the exact point of difference from the Riemann normal form, where the fold $s \mapsto 1 - \bar s$ fixes the critical line and the zeros on it are their own images, so that the line serves as a seat on which the closure is read. Here the involution fixes nothing: there is no self-dual world, no line, and the lock of the second conjunct closes on whichever world is in hand and on nothing in between. In the vocabulary of the register this is the row's ground dimension zero, and it is why the P versus NP question has no analogue of a finite verification to height $T$.

**[[T:two_rows_two_bits]]** (`two_rows_two_bits`, no axiom). *The record of the stage world has nothing escaping, and the stage world has an escape.*

The theorem fixes the relation between this paper and the Riemann normal form in one line. Both rows have the same shape: a record that has the property unconditionally, an object whose possession of the property is the question, and a bit that is the transfer from the one to the other. [[R:two_rows_two_bits]] shows that the shape is not the bit: the record's closure, which is the antecedent of both normal forms, is available on a world where the consequent fails. One shape, two bits, and neither record supplies the other row.

**[[T:pnp_normal_form_complete]]** (`pnp_normal_form_complete`, classical). *For every machine $M$ with an instance, the conjunction of Theorems [[N:record_has_least_escape]], [[N:sep_normal_form]], [[N:bit_is_the_act]], [[N:self_recursion_at_machine]], [[N:every_route_passes_the_bit]] (as a universal over $Q$), the identification of the posit with the bit ([[S:residue]]), and the vacancy of the seat.*

The capstone carries the machine and one instance before the colon and nothing else. Separation occurs in it only inside biconditionals and inside the hypothesis of a route; it is never a conjunct.

# The SAT instance in every algorithm model, and the wall on the formulas {#sec-satinst}

Part B of the kernel replaces the abstract predicate by satisfiability. A literal is a pair of a natural-number variable and a sign, a clause is a list of literals, a formula is a list of clauses in conjunctive normal form, and an assignment is a function from the naturals to the Booleans. Evaluation is the usual: a literal is true when the assignment gives its variable its sign, a clause when some literal is true, a formula when every clause is true. Satisfiability is the predicate
$$\mathrm{Satisfiable}\,f := \exists a,\ \mathrm{evalCNF}\,a\,f = \mathrm{true}.$$

The decision procedure is exhaustion. The variables occurring in $f$ are listed, every assignment to that list is enumerated with the variables outside it fixed to `false`, and `satB f` is `true` exactly when some enumerated assignment satisfies $f$.

**[[T:satB_iff]]** (`satB_iff`, no axiom). *For every formula $f$: $\mathrm{satB}\,f = \mathrm{true}$ if and only if $f$ is satisfiable.*

*Proof.* Soundness: a witness is extracted from the enumeration by structural recursion (`any_true_of`). Completeness: given a satisfying assignment $a$, its restriction to the occurring variables agrees with $a$ on every occurring variable (`restrict_agrees`), evaluation depends only on the occurring variables (`evalCNF_congr`), and the enumeration reaches the restriction (`any_assignments`), so the restriction is found. No membership predicate and no library lemma is used; the file's own `All` predicate carries the agreement. $\square$

The procedure is exponential, as exhaustion is, and that is the point: the predicate is the mathematical predicate, not a promise about efficiency.

The SAT machine over an algorithm model is
$$\begin{aligned}&\mathrm{SAT}(\mathrm{Alg}, \mathrm{out}, \mathrm{time}) :=\\ &\qquad\langle \mathrm{Alg},\ \mathrm{CNF},\ \mathrm{size},\ \mathrm{out},\ \mathrm{time},\ \mathrm{satB}\rangle,\end{aligned}$$
where `size` counts clauses and literals together and the model, the type of algorithms with its output and step-count functions, is a free parameter. The empty formula is an instance and is satisfiable (`empty_satisfiable`), which discharges the one side condition of Part A.

**[[T:sat_record_has_least_escape]]** (`sat_record_has_least_escape`, no axiom; `sat_normal_form`, classical). *In every algorithm model, the record of SAT has nothing escaping, and the separation of SAT is exactly the transfer of least escape from its record to SAT.*

**[[T:sat_bit_is_the_act]]** (`sat_bit_is_the_act`, `sat_self_recursion`, no axiom; `sat_every_route_passes_the_bit`, `sat_posit_is_the_bit`, `sat_normal_form_complete`, classical). *Theorems [[N:bit_is_the_act]], [[N:record_is_self_recursive]], [[N:self_recursion_at_machine]], [[N:every_route_passes_the_bit]], [[N:pnp_normal_form_complete]] and the identification of [[S:residue]], instantiated on the SAT machine in every algorithm model.*

The reader should hold the quantifier in mind. These theorems are about every model, including models in which satisfiability is trivially decided within the bound. In such a model the separation is false and the transfer fails; the theorems still hold, because they are equivalences and walls, not values. Two such models are now built on the formulas themselves. The **closed SAT world** has the naturals as algorithms, every answer `false` in no time, instances the formulas, size the clause-and-literal count, predicate `satB`; nothing escapes, since the empty formula is satisfiable and every algorithm answers it wrongly. The **stage SAT world** at index $n$ is the same except that algorithm $n$ answers `satB` itself in no time; it escapes at every bound. The two worlds differ in their algorithms only.

**[[T:sat_bit_is_keyed]]** (`sat_bit_is_keyed`, `sat_keyless_forces_nothing`, `sat_no_record_principle_decides`, `sat_record_decides_nothing`, no axiom). *The transfer holds on the closed SAT world and fails on the stage SAT world. No property shared by every algorithm model of SAT forces the closure of any; no principle true of the record of every algorithm model of SAT decides any; the records of both SAT worlds close, one world closes and the other escapes.*

This is the wall on the formulas. A reviewer who grants [[R:keyless_forces_nothing]] may say that it varies the predicate and the instance type and so blocks only arguments uniform across arbitrary problems. [[R:sat_bit_is_keyed]] fixes the problem: the instances are the formulas, the predicate is satisfiability, and still no fact shared by every algorithm model of that problem forces the separation. What a proof of $\mathrm{SAT} \notin \mathbf{P}$ uses must distinguish the Turing model from a model in which one algorithm answers satisfiability in no time, and that is a statement about the algorithms of the actual model. The stage SAT world is an algorithm model whose time function is free. The wall bars premises uniform over algorithm models of SAT; a premise keyed to Turing machines is, by [[R:tmsat_record_has_least_escape]], a supply of the bit.

**[[T:sat_premise_trichotomy]]** (`sat_premise_trichotomy`, classical). *For every property $P$ of machines, either some algorithm model of SAT satisfies $P$ and does not close; or $P$ forces the closure on every algorithm model of SAT it holds of, and then either the separation returns $P$ on every model, so that $P$ is the separation, or on some separated model $P$ fails, so that $P$ is strictly stronger than the separation.*

The trichotomy places every candidate premise. A premise that cannot force is refuted by a world. A premise that forces and is returned by the separation is the bit under another name. A premise that forces and is not returned is a strict strengthening, and a proof from it proves more than the separation, which is to say it proves the bit and something besides.

# The Turing model: real machines deciding real SAT, and the classes {#sec-turing}

Part C of the kernel builds the model. It has five pieces: an encoding of formulas as strings with a decoder proved to invert it, the machines and their step semantics, the running time, the SAT machine of the model together with the proposition $\mathrm{SAT} \in \mathbf{P}$ stated over every Turing machine, and the classes.

**The encoding.** The input alphabet $\Sigma$ has three symbols, the binary digits $0$ and $1$ and a separator $\#$. A variable index $n$ is written as the binary digits of $n+1$, least significant first, which is never the empty string, followed by $\#$; a literal is its index followed by one digit for its sign; a clause is its literals followed by $\#$; a formula is the concatenation of its clauses. The digits are produced by halving and parity defined by two-step recursion in the file, with the recomposition $(\text{digit}) + 2 \cdot \mathrm{half}(n) = n$ proved by the same recursion (`digit_spec`), so that no division operator and no library lemma about division is used anywhere. The decoder reads digits up to a separator (`parseBits`), a literal (`parseLit`), a clause as literals until a separator stands where a literal would start (`parseClause`), and a formula as clauses until the string ends (`parseCNF`), each recursion bounded by a fuel that the length of the string supplies.

**[[T:decode_encode]]** (`decode_encode`, `encode_injective`, no axiom). *For every formula $f$, $\mathrm{decode}(\mathrm{encode}\,f) = \mathrm{some}\,f$; hence distinct formulas have distinct strings.*

The language is then defined on all strings: $\mathrm{satLang}\,w$ is `satB` of the formula $w$ decodes to, and `false` when $w$ decodes to nothing. $\mathrm{SAT} \subseteq \Sigma^{*}$ is the set of strings with $\mathrm{satLang}\,w = \mathrm{true}$, so a malformed string is outside the language, as in the textbook definition.

**[[T:satLang_encode_iff]]** (`satLang_encode_iff`, no axiom). *For every formula $f$, $\mathrm{satLang}(\mathrm{encode}\,f) = \mathrm{true}$ if and only if $f$ is satisfiable.*

**The machines.** A Turing machine is a structure with a number $q$ of states, a number $s$ of work symbols, a total transition function $\delta : \mathrm{Fin}\,q \to \mathrm{Fin}\,{(s+4)} \to \mathrm{Fin}\,q \times \mathrm{Fin}\,{(s+4)} \times \{L, R\}$, and three designated states, start, accept and reject. The tape alphabet $\mathrm{Fin}\,(s+4)$ has the blank at $0$, the three input symbols at $1$, $2$ and $3$, and $s$ further work symbols. A configuration is a state, a head position in $\mathbb{Z}$ and a tape, a function from $\mathbb{Z}$ to the tape alphabet; the initial configuration has the input written from cell $0$ rightward, blanks elsewhere, the head at $0$ and the start state. One step reads the scanned cell, writes, moves one cell and changes state, and a configuration in the accept or reject state is fixed by the step. The run on input $w$ is the iteration of the step from the initial configuration; $\mathrm{HaltsAt}\,M\,w\,t$ says the configuration after $t$ steps is in a halting state, and $\mathrm{verdictAt}\,M\,w\,t$ is `true` exactly when that configuration is in the accept state. The finiteness of the state set is load-bearing and is why the states are a `Fin` type and not a natural number: a machine with infinitely many states could carry the input into its state and decide SAT in linear time, and a model that allowed it would make the separation false for a reason that has nothing to do with computation.

**[[T:haltsAt_of_le]]** (`haltsAt_of_le`, `verdict_of_le`, no axiom). *A machine halted at step $t$ is halted at every later step, and its verdict at every later step is its verdict at $t$.* The proof is an induction on the inequality $t \le u$ itself, which is why no subtraction and no library lemma enters.

**The running time.** `firstHalt M w n` is the first halting step at or below $n$, or $n$ when none is found. A **decider** is a machine together with a clock, a function from strings to naturals, and a proof that the machine is halted at the clock's value on every input. The running time of a decider on $w$ is `firstHalt` run up to the clock, and its output is the verdict at that step. The clock certifies and does not time:

**[[T:time_halts]]** (`time_halts`, `time_least`, no axiom). *The decider is halted at its running time, and its running time is at most every step at which it is halted.* So the running time is the first halting step of the run, whatever clock certified the halting, and the output is the verdict the run itself delivers.

**The SAT machine of the Turing model, the classes and the bridge.** The machine is
$$\mathrm{TMSAT} := \langle \mathrm{Decider},\ \Sigma^{*},\ \mathrm{length},\ \mathrm{out},\ \mathrm{time},\ \mathrm{satLang}\rangle.$$
A language is a function from strings to Booleans. A language $L$ is **in P** when some Turing machine halts on every input within $c\,n^{k} + c$ steps, $n$ the length of the input, in the accept state exactly on the strings of $L$:
$$\begin{aligned}\mathrm{InP}\,L :=\ &\exists M\,c\,k,\ \forall w,\ \exists t,\\ &t \le \mathrm{bound}(c,k,|w|)\\ &\wedge\ \mathrm{HaltsAt}\,M\,w\,t\\ &\wedge\ \mathrm{verdictAt}\,M\,w\,t = L\,w,\end{aligned}$$
and $\mathrm{SATinP} := \mathrm{InP}\,\mathrm{satLang}$, over every Turing machine, with no decider and no clock in it. A language $L$ is **in NP** when some Turing machine, the verifier, accepts within $c\,n^{k} + c$ steps the string made of a binary certificate of length at most $c\,n^{k} + c$, the separator, and the input, exactly when the input is in $L$; the certificate carries no separator, so the first separator on the tape delimits it:
$$\begin{aligned}\mathrm{InNP}\,L :=\ &\exists M\,c\,k,\ \forall w,\ \big(L\,w = \mathrm{true} \leftrightarrow\\ &\exists u : \{0,1\}^{*},\ |u| \le \mathrm{bound}(c,k,|w|)\ \wedge\\ &\exists t \le \mathrm{bound}(c,k,|w|),\ \mathrm{HaltsAt}\,M\,(u\,\#\,w)\,t\\ &\wedge\ \mathrm{verdictAt}\,M\,(u\,\#\,w)\,t = \mathrm{true}\big),\end{aligned}$$
and the sentence is $\mathbf{P} \neq \mathbf{NP} := \exists L,\ \mathrm{InNP}\,L \wedge \neg\,\mathrm{InP}\,L$, the kernel's `P_ne_NP`. These are the textbook definitions on the kernel's model, and all five constants, $\mathrm{TMSAT}$, $\mathrm{InP}$, $\mathrm{InNP}$, $\mathbf{P} \neq \mathbf{NP}$ and $\mathrm{SATinP}$, have empty cones of their own, pinned in the kernel, Appendix A.

**[[T:sep_tmsat_iff]]** (`sep_tmsat_iff`, no axiom). *$\mathrm{Sep}\,\mathrm{TMSAT} \leftrightarrow \neg\,\mathrm{SATinP}$.*

*Proof.* Left to right: a machine $M$ witnessing $\mathrm{SATinP}$ with bound $(c,k)$ is a decider when clocked by that bound, since by [[R:haltsAt_of_le]] it is halted at the bound; its running time is at most the witnessing step by [[R:time_halts]] and hence within the bound, and its output is the verdict at the witnessing step by Theorems [[N:haltsAt_of_le]] and [[N:time_halts]], which is $\mathrm{satLang}\,w$; so it escapes, against $\mathrm{Sep}$. Right to left: a decider that escapes witnesses $\mathrm{SATinP}$ with its own running time as the step. $\square$

**[[T:evalPoly_le_bound]]** (`evalPoly_le_bound`, `SATinP_of_poly`, no axiom). *Every polynomial with natural coefficients, evaluated by Horner's rule, is at most $S\,n^{k} + S$ with $S$ its coefficient sum and $k$ its length; hence a machine deciding SAT within any such polynomial witnesses $\mathrm{SATinP}$.* Nothing is lost in the kernel's form of the bound, and the bound is itself a polynomial, so $\mathrm{SATinP}$ is polynomial time in the ordinary sense.

**[[T:pnp_normal_form_turing]]** (`pnp_normal_form_turing`, classical). *On the Turing model,*
$$\big(\mathrm{NE}(\mathrm{Rec}\,\mathrm{TMSAT}) \to \mathrm{NE}\,\mathrm{TMSAT}\big) \;\leftrightarrow\; \neg\,\mathrm{SATinP}.$$

This is the normal form of P versus NP on real machines deciding real SAT. The left side is one implication whose antecedent is a theorem (`tmsat_record_has_least_escape`, no axiom). The right side quantifies over every Turing machine and every polynomial bound.

**[[T:tmsat_record_has_least_escape]]** (`tmsat_record_has_least_escape`, `tmsat_bit_is_the_act`, `tmsat_self_recursion`, `tmsat_coincidence`, no axiom; `tmsat_every_route_passes_the_bit`, `tmsat_posit_is_the_bit`, `tmsat_normal_form_complete`, classical). *Theorems [[N:record_has_least_escape]], [[N:bit_is_the_act]], [[N:record_is_self_recursive]], [[N:self_recursion_at_machine]], [[N:every_route_passes_the_bit]], [[N:pnp_normal_form_complete]], the coincidence form and the identification of [[S:residue]], on the Turing model, with $\mathrm{Sep}$ replaced throughout by $\neg\,\mathrm{SATinP}$.*

In particular every route to $\mathrm{SAT} \notin \mathbf{P}$, from any premise, passes the bit, and the capstone on the Turing model has nothing before the colon at all: it is a closed statement about the model, with $\mathrm{SATinP}$ occurring only inside biconditionals and inside the hypothesis of a route.

**[[T:tmsat_racomp_iff_not_inP]]** (`tmsat_racomp_iff_not_inP`, `the_posit_is_every_exit`, no axiom; `every_exit_is_the_posit`, classical). *The reading of the root on computation, that every decider at every bound fails to escape, is exactly $\mathrm{SAT} \notin \mathbf{P}$ on the Turing model. Any proof of $\mathrm{SAT} \notin \mathbf{P}$, by any route, including one built from facts about Turing machines, yields all three names of the one posit: the transfer $\mathrm{NE}(\mathrm{Rec}\,\mathrm{TMSAT}) \to \mathrm{NE}\,\mathrm{TMSAT}$, a least-escape certificate, and $\mathrm{RAcomp}\,\mathrm{TMSAT}$. And each of the three names gives $\mathrm{SAT} \notin \mathbf{P}$ back, on no axiom.*

So no independent proof exists. Nothing reaches $\mathrm{SAT} \notin \mathbf{P}$ except through least escape on the Turing SAT machine, and least escape gives $\mathrm{SAT} \notin \mathbf{P}$ back; nothing sits between the posit and the conclusion. The one return that is classical is the return from a proof to the transfer, since it passes through the closure; the three returns from the names to the conclusion are axiom-free. The first conjunct is the register's bridge test run inside the kernel: the earlier paper's `ra_comp_is_sep` on the abstract machine becomes, on the Turing model, $\mathrm{RAcomp}\,\mathrm{TMSAT} \leftrightarrow \neg\,\mathrm{SATinP}$ with an empty cone.

**[[T:racomp_cargo_iff_not_inP]]** (`racomp_cargo_iff_not_inP`, `every_route_spends_the_bit_free`, no axiom). *The transfer in its constructive form, the record's closure carried to the statement that no decider escapes at any bound, is exactly $\mathrm{SAT} \notin \mathbf{P}$; and every premise that gives $\mathrm{SAT} \notin \mathbf{P}$ delivers it.*

Read constructively, the bit needs no axiom in either direction: the identification of the posit with $\mathrm{SAT} \notin \mathbf{P}$, carried to the transfer, has an empty cone.

**[[T:p_ne_np_of_not_inP]]** (`p_ne_np_of_not_inP`, no axiom). *If $\mathrm{SAT} \in \mathbf{NP}$ and $\mathrm{SAT} \notin \mathbf{P}$, then $\mathbf{P} \neq \mathbf{NP}$.*

The theorem is one line, because the classes were defined on one schema, and its content is exactly that: the sentence $\mathbf{P} \neq \mathbf{NP}$ of the kernel is reached from $\mathrm{SAT} \notin \mathbf{P}$ by naming one hypothesis, $\mathrm{InNP}\,\mathrm{satLang}$, and nothing else. That hypothesis is the membership half of Cook and Levin's theorem, a verifier machine that evaluates an encoded formula under a certificate assignment in polynomial time, and [[S:np]] builds it on the kernel's own model, so that the sentence follows from $\mathrm{SAT} \notin \mathbf{P}$ with nothing cited ([[R:p_ne_np_of_the_one_bit]]).

**[[T:certificate_unique]]** (`certificate_unique`, no axiom). *Any two least-escape certificates of the SAT machine are the same object, and any two proofs of $\mathrm{SAT} \notin \mathbf{P}$ are the same proof.* By the proof irrelevance of Lean's propositions and the eta rule for structures, every route delivers one object and not a family.

**The defense.** Three statements are classical and three are not.

**[[T:tmsat_rejection_is_a_witness]]** (`tmsat_rejection_is_a_witness`, `tmsat_every_pair_lands`, `forces_or_has_a_twin`, classical). *A rejection of $\mathrm{SAT} \notin \mathbf{P}$ is a witness, a decider and a bound with every run clean. Every decider at every bound either is stopped by some string or escapes. Every property of machines either forces the closure or holds on some machine that escapes.*

**[[T:escape_refutes]]** (`escape_refutes`, `act_leaves_no_escape`, `extend_escapes`, `no_record_decides`, `tmsat_no_record_decides`, no axiom). *An escape refutes the closure; the closure leaves no escape; and every stock of examinations of a machine with an instance, indexed by any type, finite or infinite, is a stock of stops both on the machine's extension by one algorithm that answers the predicate in no time, where that algorithm escapes, and on the machine's record, where nothing escapes.*

[[R:escape_refutes]] is the generalization of Stage 1's locality from one observation to all of them. Whatever stops have been observed, there is a machine agreeing with every one of them on which SAT is easy and a machine agreeing with every one of them on which nothing escapes. Observed stops decide nothing; the universal is never a sum. The machine consistent with every stock is `extendM TMSAT`, the SAT machine with one algorithm added, and its record is `Rec TMSAT`.

**What the model fixes.** The machine is single-tape, two-way infinite, with a three-symbol input alphabet; the textbook classes are stated for one-way tapes, several tapes, or a binary input alphabet, and polynomial time is the same under every one of these variants by the standard simulations, which cost a polynomial factor and are proved in Sipser [13, Theorem 7.8] and Arora and Barak [11, Section 1.3], and are cited here. The encoding of formulas is one of the usual ones, with indices in binary, and polynomial time is the same under every encoding computable in polynomial time from this one and back, as all the usual encodings are. The classes are defined on the kernel's model; their identification with the classes of the textbooks is the robustness just cited. These citations are the whole distance between [[R:p_ne_np_of_not_inP]] and the sentence $\mathbf{P} \neq \mathbf{NP}$ as a complexity theorist writes it, and each is a settled theorem of the field rather than a premise of this paper.

**Executable checks.** Fourteen examples, closed by `decide` inside the compile, run the model: a three-state machine that accepts exactly when the first input symbol is $1$ is not halted at step $0$, halts after one step with the right verdict on `[1]` and on `[0]`, halts on the empty input, and keeps its verdict at step $5$ on `[1,0]`; the encoding of the one-literal formula $x_0$ is the string $1\#1\#$, which decodes back to it; the string $11$ decodes to nothing; the empty string is in SAT (the empty formula), the string $\#$ is not (one empty clause), the formula $x_0$ is, the formula $x_0 \wedge \neg x_0$ is not, and $(x_1 \vee \neg x_0) \wedge \neg x_1$ is. Altering the expected value of any of them stops the compile, and Appendix B records the compiler's refusal for one of them.
