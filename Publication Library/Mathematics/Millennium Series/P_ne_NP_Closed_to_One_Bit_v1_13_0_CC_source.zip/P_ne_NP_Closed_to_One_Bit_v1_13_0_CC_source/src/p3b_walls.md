# The walls, complete {#sec-walls}

Sections [[SN:selfrec]] to [[SN:residue]] proved the walls that bar uniform premises. Part U of the kernel ran the method that walked degree one at degree two, and Parts V and X bound every wall, old and new, with the mirror that governs them all. Each wall below binds every method its quantifier covers, born or unborn.

**[[T:count_falls_short]]** (`count_falls_short`, `pigeon_ceiling`, classical; `count_ceiling`, propext and Quot.sound). *For every decider, every pad length, every exponent and every crossing length the pigeonhole can force, the time the crossing count certifies over the pad is at most $n^{2} + 1$ at the family's own length $n$: the count cannot witness the Diagonal Target at degree two.*

The reason is information: the count measures the bits that must cross a cut, there are at most $n$ of them, and at a quadratic budget a crossing sequence is long enough to carry them. The method that walked degree one stops exactly where the residue begins.

**[[T:self_tableau_block]]** (`self_tableau_block`, propext and Quot.sound). *Every formula has fewer clauses than its own budget $c\,n^{k} + c$ has steps, at every degree $k \ge 1$ and constant $c \ge 1$: a diagonal formula that described its decider's run within the budget, one clause per step, would be longer than itself.*

**[[T:no_total_wall]]** (`no_total_wall`, `total_wall_iff_negation`, no axiom). *For every proposition $B$, no wall bars every premise from $B$, since $B$ forces itself; and to bar every true premise from $B$ is to deny $B$.*

**[[T:shut_door_is_collapse]]** (`shut_door_is_collapse`, classical). *With the hardness half of Cook and Levin cited, the proclamation that every true route to the bit is shut is exactly* $\neg(\mathbf{P} \neq \mathbf{NP})$.

This is the kernel's reading of the Unprovability Mirror of the register's Mother Codex [29], corollary C5: a wall total on the routes to the bit is the collapse in costume. Every wall of this paper binds on its own quantifier, and no wall is total.

**[[T:no_language_is_its_complement]]** (`no_language_is_its_complement`, `sixteen_languages_eight_two_cycles`, `the_diagonal_blindspot`, `both_fates_are_resolutions`, no axiom; `square_is_sign_blind`, propext). *No language is its own complement, and complementation moves all sixteen languages over four words in eight two-cycles; no listing of predicates contains its own diagonal; shutting every true route to $B$ is denying $B$, and shutting every true route to $\neg B$ is denying $\neg B$; and a squared integer reads a value and its reflection alike.*

These are the type-indexed rows of the Mother Codex, Rows II.1, II.2 and III.1, run in the kernel: no residence argument finds a fixed set of complementation, no squared invariant reads the truth-sign, no catalogue certifies its own completeness, and both fate-pronouncements are resolutions.

**[[T:physical_discharge_is_the_bit]]** (`physical_discharge_is_the_bit`, no axiom; `bridge_premise_is_the_conjecture`, classical). *An inhabited physical witness is exactly the bit; and with the hardness half cited, the no-shortcut premise $\neg\,\mathrm{SATinP}$ is exactly $\mathbf{P} \neq \mathbf{NP}$.*

These are Theorems 1 and 2 of the structural-verdict paper [30], run in the kernel: every physical discharge of the bit is a proof of the bit, and every bridge from the physical asymmetry to the separation is the conjecture itself.

**[[T:block_needs_an_outside]]** (`block_needs_an_outside`, no axiom). *If a target is a function of a record, no involution that preserves the record flips the target.*

A block that flips the bit therefore stands on something the record leaves out; at `TMSAT` that outside is the supply, in its two kinds ([[S:escape]]).

**[[T:the_blocks]]** (`the_blocks`, `the_attempt_at_two`, classical). *With nothing before the colon: the keyless wall, the record wall, the SAT-keyless wall, no uniform answer across the algorithm models of SAT, the vacant seat, the crossing ceiling at degree two, and the self-tableau wall.*

Seven walls of the literature stand beside them, carried from the Mother Codex v3.48.0 [29] at the grades their authors proved them: relativization [4], natural proofs [5], algebrization [6], locality [28], the occurrence-obstruction and rank wing of geometric complexity [27], lower-bound proofs inside named fragments of bounded arithmetic [26], and the register's Rows II.3 to II.8. Figure 4 sets the complete list beside the walls of Figure 3.

[[FIG:4]]
