# The frontier, formal alone {#sec-frontier}

Part D carries, from the register's earlier kernel on this row, the two frontier results that are pure mathematics and need no physics and no root: an axiom-free pigeonhole bound on black-box search, and the white-box contrast that marks where the bound stops.

**[[T:pigeon]]** (`pigeon`, `black_box_bound`, `black_box_no_savings`, no axiom). *A list of naturals that contains every number below $K$ has at least $K$ entries. A fixed list of tests that decides, for every candidate function $f : \mathbb{N} \to \{\mathrm{true},\mathrm{false}\}$, whether some candidate below $K$ satisfies $f$, by answering `true` exactly when some tested candidate does, has length at least $K$; over $2^{N}$ candidates it is never shorter than $2^{N}$.*

The procedure is a fixed list of queries, and its verdict is the disjunction of the answers: the test-only procedure on the all-false path of the standard adversary argument, where adaptivity collapses because every answer is `false`. On $2^{n}$ truth assignments the bound is exponential, and it is a theorem on no axiom.

**[[T:reader_solves]]** (`reader_solves`, `reader_poly`, `fails_when_descriptions_reveal`, `missing_object_is_keyed`, no axiom). *The black-box adversary family is the family of point functions. Handed over as descriptions, each is solved by a reader of its description in one step, in constant time. Hence the white-box object, that every algorithm deciding the problem from its description runs in super-polynomial time, fails on the model where descriptions reveal, and holds on every model where no algorithm decides: it is keyed.*

The two theorems together say where the frontier is. Black-box bounds are exponential and unconditional, and they stop at the description: the Turing machine reads the formula, and the object that reaches $\mathrm{SAT} \notin \mathbf{P}$ is a lower bound against readers of the description, keyed exactly as the bit is. This is the formal-alone content of the frontier the register's earlier paper carried with physics beside it; here the physics enters once, in [[S:supply]], as the carrier premise of the witness, and nowhere in the form.

Figure 3 gathers the walls proved so far, Sections [[SN:selfrec]] to [[SN:frontier]]. Each binds every method its quantifier covers, born or unborn, and each stands on the keyed bit of [[S:satinst]].

[[FIG:3]]

# The residue {#sec-residue}

Part E of the kernel prints what remains.

**[[T:separation_of_the_act]]** (`separation_of_the_act`, no axiom). *For every machine $M$ with an instance, given the transfer* $\mathrm{NothingEscapes}(\mathrm{Rec}\,M) \to \mathrm{NothingEscapes}\,M$, *the separation* $\mathrm{Sep}\,M$ *follows.*

**[[T:sat_separation_of_the_act]]** (`sat_separation_of_the_act`, no axiom). *In every algorithm model, given the transfer on the SAT machine, SAT is separated in that model.*

**[[T:sat_not_in_P_of_the_act]]** (`sat_not_in_P_of_the_act`, no axiom). *Given the transfer on the SAT machine of the Turing model,* $\neg\,\mathrm{SATinP}$: *no Turing machine decides SAT within any polynomial bound.*

**[[T:p_ne_np_of_residue]]** (`p_ne_np_of_residue`, no axiom). *Given $\mathrm{SAT} \in \mathbf{NP}$ and the transfer on the SAT machine of the Turing model,* $\mathbf{P} \neq \mathbf{NP}$.

The hypothesis of [[R:sat_not_in_P_of_the_act]] is the residue of P versus NP in this paper. It is assumed nowhere in the file, as the reader can confirm by searching Appendix A for `axiom`, and it is the only thing standing between the theorems above and $\mathrm{SAT} \notin \mathbf{P}$; with $\mathrm{SAT} \in \mathbf{NP}$ built ([[S:np]]), it is the only thing standing between them and the sentence $\mathbf{P} \neq \mathbf{NP}$ ([[R:p_ne_np_of_the_one_bit]]). Sections [[SN:machine]] to [[SN:discussion]] carry the form with no posit; [[S:supply]] supplies the value, at premise grade.

**[[T:residue_is_keyed]]** (`residue_is_keyed`, no axiom). *No keyless property forces the closure of every machine; no principle true of every record decides every machine; no property shared by every algorithm model of SAT forces the closure of any.*

[[R:residue_is_keyed]] restates the wall on the residue. The hypothesis of [[R:sat_not_in_P_of_the_act]] cannot be supplied by anything shared by all machines, by anything true of every record, or by anything shared by all algorithm models of satisfiability itself. What supplies it is a fact about the Turing model that fails in a world where one algorithm answers satisfiability in no time. The register this paper is drawn from [14] reads that fact as an act and identifies the reading of its root principle on computation with the transfer; the kernel carries that identification as `the_posit_is_the_bit` and `tmsat_posit_is_the_bit`, which prove that the statement *every machine at every bound fails to escape*, the register's own form of the principle, is exactly the transfer. The form of Sections [[SN:machine]] to [[SN:discussion]] rests on no posit; the reading is the posit of [[S:supply]]. In the paper's own terms the residue is a type, printed, and supplied in [[S:supply]], and the guard sentence of the register reads: everything except the bit is proved with no posit, the constructive parts on no axiom at all and the classical return from the separation to the closure on Lean's standard axioms alone; and the bit, the transfer of least escape from the record of the SAT machine to the SAT machine, equivalent to $\mathrm{SAT} \notin \mathbf{P}$ over every Turing machine and, with $\mathrm{SAT} \in \mathbf{NP}$ built, to $\mathbf{P} \neq \mathbf{NP}$, is all that remains, at premise grade.

The scope of the wall is exact: it bars every route that holds on both coherent worlds. [[S:walls]] adds the walls that bar the methods which read the Turing model's own content at degree two, and the mirror that governs every wall: a wall against every route to the bit is the bit's negation ([[R:no_total_wall]]), and at P versus NP, with the hardness half cited, it is the assertion $\mathbf{P} = \mathbf{NP}$ ([[R:shut_door_is_collapse]]). The bit of the closed world is a theorem on no axiom (`closed_world_closes`), so the bit of a machine can be a theorem; at `TMSAT` this paper closes it by supply, at premise grade, with the refuter named.

The two defenses of the row follow from Theorems [[N:sep_tmsat_iff]] and [[N:pnp_normal_form_turing]] and are stated once. Nothing passes for the separation but the transfer, since the normal form is an equivalence. Nothing passes against it but an escape, a Turing machine, a bound and every run clean, since by [[R:tmsat_rejection_is_a_witness]] the rejection of $\neg\,\mathrm{SATinP}$ is exactly that existential. The one refuter of the residue is therefore the familiar one: a polynomial-time Turing machine for satisfiability. The kernel's theorems are refuted by nothing of the kind, because they hold in the world where such a machine exists as well as in the world where it does not.

The residue has ten faces, and the kernel proves them one proposition.

**[[T:ten_faces_of_the_one_bit]]** (`ten_faces_of_the_one_bit`, classical; `face_closure`, `face_physical`, no axiom). *With nothing before the colon, each of ten propositions is exactly the bit: SAT separates $\mathbf{P}$ from $\mathbf{NP}$ at satLang; $\neg\,\mathrm{SATinP}$; $\mathrm{Sep}\,\mathrm{TMSAT}$; $\mathrm{NothingEscapes}\,\mathrm{TMSAT}$; the self-recursion of TMSAT; the coincidence of TMSAT's escapes with its record's; an inhabited fertile machine at TMSAT; an inhabited selected machine; an inhabited physical witness; and the Diagonal Target at every degree $k \ge 2$.*

Whatever vocabulary a proof speaks, separation, closure, self-recursion, coincidence, selection, physics or degree, it speaks of this one bit.
