# SAT ∈ NP, built {#sec-np}

Part N of the kernel builds the verifier that the membership half of Cook and Levin calls for, on the kernel's own one-tape model. The machine `vM` has 5,120 control states and a tape alphabet of nineteen symbols. It reads a certificate of one bit per literal, the separator, and the input, and runs four phases: it checks that the input is a written formula, the strings the decoder accepts being exactly the written formulas (`decode_inv`, `p0_iff`); it writes the certificate bits onto the signs in reading order; it checks that every clause has a sign meeting its bit; and it checks, digit by digit with marks, that any two literals naming one variable carry one bit (`cmp_decide`). The run is computed on zippers (`vRel_run`), and every phase is a theorem on lists with an explicit step count.

**[[T:satLang_in_NP]]** (`verifier_sound`, `verifier_complete`, `satLang_in_NP`, classical; `vtime_le`, propext and Quot.sound). *A run of the verifier in the accept state certifies that the input is in SAT; on a satisfiable input, the certificate of the values of a satisfying assignment makes the verifier accept within $5000\,n^{4} + 5000$ steps; hence* $\mathrm{SAT} \in \mathbf{NP}$ *on the kernel's model.*

The membership half of Cook and Levin is therefore a theorem of the file and enters no statement as a citation. With it, the bit reaches the sentence directly.

**[[T:p_ne_np_of_the_one_bit]]** (`p_ne_np_of_the_one_bit`, `barrier_implies_p_ne_np`, classical). *The bit gives $\mathbf{P} \neq \mathbf{NP}$ with nothing before the colon but the bit itself, and so does the Barrier, the Diagonal Target from degree two.*

# The inequality by degree: degrees 0 and 1 constructed {#sec-degree}

The bit is a universal over degrees. Write the Diagonal Target at degree $k$ for the statement that every decider at every constant $c$ meets a string on which it is wrong or runs past $c\,n^{k} + c$:
$$\begin{aligned}\mathrm{DT}_k :=\ &\forall A\,c,\ \exists x,\\ &\mathrm{out}\,A\,x \neq \mathrm{satLang}\,x\\ &\vee\ c\,|x|^{k} + c < \mathrm{time}\,A\,x.\end{aligned}$$
A witness family at a higher degree gives one at every lower degree from one (`dt_mono`), and Parts L and M of the kernel construct the first two degrees on the kernel's own model, encoding and running time.

**[[T:sat_not_in_P_at_degree_zero]]** (`sat_not_in_P_at_degree_zero`, `diagonal_target_at_zero`, propext and Quot.sound). *No Turing machine decides SAT within a constant number of steps, and $\mathrm{DT}_0$ holds with a computed witness.*

The engine is locality, proved once for every machine (`run_local`): after $t \le m$ steps the state, the head and every cell left of $m$ are fixed by the input cells left of $m$, so two inputs that agree on $m$ cells and differ in verdict cost more than $m$ steps on one of them (`prefix_forces_time`). SAT supplies the pair at every $m$ on its own encoding: $m$ unit clauses $x_0$, satisfiable, and the same clauses with the empty clause appended, unsatisfiable.

**[[T:diagonal_target_at_one]]** (`diagonal_target_at_one`, `sat_not_in_P_at_degree_one`, classical). *For every decider and every constant $c$ there is an input on which the decider is wrong or runs more than $c\,n + c$ steps: no one-tape Turing machine decides SAT within a linear budget.*

The proof is Hennie's crossing-sequence method [25], run on the kernel's one-tape model. The crossing sequence of a run at a boundary is the list of states the machine enters as its head crosses that boundary; two halting runs that leave the same crossing sequence at a boundary can be cut and pasted (`cut_paste`), and a step crosses at most one boundary. The fooling family is SAT's own: for bit lists $a$ and $b$ of one length, unit clauses fixing $a$, a pad, and unit clauses fixing $b$ form a formula that is satisfiable exactly when $a = b$ (`fool_sat`, `fool_unsat`). A decider right on the family therefore leaves distinct crossing sequences on distinct diagonal strings (`fool_cs_inj`), and by pigeonhole and averaging some diagonal string runs past $c\,n + c$ (`fool_long`).

**[[T:unconditional_real_part_separation]]** (`unconditional_real_part_separation`, classical). *With nothing before the colon: $\mathrm{SAT} \in \mathbf{NP}$; no Turing machine decides SAT in constant time; no one-tape Turing machine decides SAT in linear time; and the bit is exactly $\forall k \ge 2,\ \mathrm{DT}_k$.*

**[[T:the_inequality_from_degree_two]]** (`the_inequality_from_degree_two`, `gate_7_dual`, classical). *The bit is exactly the Diagonal Target at every degree $k \ge 2$, and for every $m \ge 1$ it is exactly the Diagonal Target at every degree $k \ge m$.*

The residue is therefore exactly its tail from degree two, and it does not depend on where the ladder is cut. Figure 2 collects what Sections [[SN:machine]] to [[SN:degree]] prove unconditionally.

[[FIG:2]]
