#!/usr/bin/env python3
"""Validate the assembled paper against the kernel.

1. Every theorem label (**Theorem N** (`names`, cone; ...)): each name is a declaration of the kernel, and its pinned
   cone equals the cone the label states. Unpinned names are listed for a #print axioms check.
2. Every backticked identifier in the prose is a declaration of the kernel, or a listed non-identifier.
3. Theorem numbers are defined once and in order; every reference points to a defined number.
4. Every reference [n] cited in the text exists in the list, and every listed reference is cited.
5. No em dash and no en dash outside the reference list; no stale counts.
"""
import json
import re
import sys

K = json.load(open(sys.argv[2]))
DECL, CONE = K["decl"], K["cone"]
text = open(sys.argv[1], encoding="utf-8").read()
body, _, refs = text.partition("# References {-}")
# the prose: drop fenced code blocks
prose = re.sub(r"```.*?```", "", body, flags=re.S)

CONES = {"no axiom": "∅", "classical": "propext, Classical.choice, Quot.sound",
         "propext and Quot.sound": "propext, Quot.sound", "propext": "propext",
         "Classical.choice": "Classical.choice", "a construction with an empty cone": "∅"}
errors, unpinned = [], set()


def lookup(n):
    return DECL.get(n.split(".")[-1], [])


# 1. theorem labels
labels = re.findall(r"\*\*Theorem (\d+)\*\* \(([^()]*)\)", prose)
nums = [int(n) for n, _ in labels]
if nums != list(range(1, len(nums) + 1)):
    errors.append(f"theorem numbers not consecutive: {nums}")
for n, inner in labels:
    for grp in inner.split(";"):
        names = re.findall(r"`([^`]+)`", grp)
        rest = re.sub(r"`[^`]+`", "", grp).replace(" to ", " ").strip(" ,")
        cone = rest.strip(" ,")
        if cone not in CONES:
            errors.append(f"Theorem {n}: unknown cone label '{cone}' in ({inner})")
            continue
        want = CONES[cone]
        for nm in names:
            ds = lookup(nm)
            if not ds:
                errors.append(f"Theorem {n}: `{nm}` is not a declaration of the kernel")
                continue
            got = {CONE.get(full, "UNPINNED") for full, _, _ in ds}
            if want in got:
                continue
            if got == {"UNPINNED"}:
                unpinned.add((ds[0][0], want))
            else:
                errors.append(f"Theorem {n}: `{nm}` pinned {got}, label says {want}")
print(f"theorem labels checked: {len(labels)}")

# 2. backticked identifiers in prose
NONID = {"_CC", "sorry", "admit", "native_decide", "axiom", "unsafe", "opaque", "partial", "noncomputable",
         "@[extern", "implemented_by", "import", "#guard_msgs", "#print axioms", "decide", "true", "false",
         "[propext, Classical.choice, Quot.sound]", "[propext, Quot.sound]", "[propext]", "[Classical.choice]",
         "lean -DwarningAsError=true", "Machine", "example"}
seen = set()
CORE = {"propext", "Classical.choice", "Quot.sound", "Classical.byContradiction", "Fin", "Nat", "Bool", "Prop"}
for tok in re.findall(r"`([^`\n]+)`", prose):
    if tok in NONID or tok.endswith(".lean") or tok.endswith(".md") or " " in tok and ":" in tok:
        continue
    if re.fullmatch(r"[0-9a-f]{16}( [0-9a-f]{16}){3}", tok) or tok.startswith("1000sapients") or "/" in tok:
        continue
    if re.fullmatch(r"\[[0-9,]*\]", tok):
        continue
    parts = tok.split()
    if len(parts) > 1:
        heads = [p for p in parts if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.']*", p) and len(p) > 1]
        for p in heads:
            if not lookup(p) and p not in CORE:
                errors.append(f"`{p}` (in `{tok}`) is not a declaration of the kernel")
        continue
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.']*", tok):
        errors.append(f"unrecognized code token: `{tok}`")
        continue
    if tok in seen or tok in CORE:
        continue
    seen.add(tok)
    if not lookup(tok):
        errors.append(f"`{tok}` is not a declaration of the kernel")
    else:
        if all(CONE.get(f, "UNPINNED") == "UNPINNED" for f, _, kind in lookup(tok)) and \
                any(kind in ("theorem", "lemma") for _, _, kind in lookup(tok)):
            unpinned.add((lookup(tok)[0][0], "?"))
print(f"backticked identifiers checked: {len(seen)}")

# 3. references to theorem numbers
maxn = len(labels)
for m in re.finditer(r"Theorems? ((?:\d+(?:, | and |,? and ))*\d+)", prose):
    for k in re.findall(r"\d+", m.group(1)):
        if int(k) > maxn:
            errors.append(f"reference to undefined Theorem {k}")

# 4. bibliography
listed = [int(n) for n in re.findall(r"^(\d+)\. ", refs, flags=re.M)]
cited = set()
prose_nc = re.sub(r"`[^`\n]*`", "", prose)
for m in re.finditer(r"\[(\d+(?:, ?\d+)*)(?:, [^\]]*)?\]", prose_nc):
    for k in re.findall(r"\d+", m.group(1)):
        cited.add(int(k))
cited |= {int(k) for k in re.findall(r"in \[(\d+)\]", prose_nc)}
if listed != list(range(1, len(listed) + 1)):
    errors.append(f"reference list not consecutive: {listed}")
for c in sorted(cited):
    if c not in listed:
        errors.append(f"cited [{c}] is not in the reference list")
for r in listed:
    if r not in cited:
        errors.append(f"reference [{r}] is never cited")
print(f"references listed {len(listed)}, cited {len(cited & set(listed))}")

# 5. dashes and stale counts
for ch, name in (("—", "em dash"), ("–", "en dash")):
    if ch in body:
        for ln in body.split("\n"):
            if ch in ln:
                errors.append(f"{name} in body: {ln[:90]}")
for stale in ("v1_4_0", "98 pinned", "1,774", "74 read", "24 read", "Three limitations", "citation grade"):
    if stale in prose:
        errors.append(f"stale text: {stale}")

for e in errors:
    print("ERROR", e)
print("unpinned names to check by #print axioms:", len(unpinned))
json.dump(sorted(unpinned), open(sys.argv[3], "w"))
print("VALID" if not errors else f"{len(errors)} ERRORS")
