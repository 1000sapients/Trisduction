import sys, re, glob, os
from playwright.sync_api import sync_playwright
files = sys.argv[1:]
with sync_playwright() as p:
    b = p.chromium.launch(args=["--disable-gpu"])
    for svg in files:
        head = open(svg, encoding="utf-8").read(400)
        W, H = map(int, re.search(r'width="(\d+)" height="(\d+)"', head).groups())
        html = (f'<html><head><style>@page{{size:{W}px {H}px;margin:0}}html,body{{margin:0;padding:0}}'
                f'img{{display:block;width:{W}px;height:{H}px}}</style></head><body><img src="file://{svg}"></body></html>')
        hp = svg[:-4] + ".html"
        open(hp, "w").write(html)
        pg = b.new_page(viewport={"width": W, "height": H}, device_scale_factor=1.5)
        pg.goto("file://" + hp); pg.wait_for_load_state("networkidle"); pg.wait_for_timeout(400)
        pg.screenshot(path=svg[:-4] + ".png", full_page=True, timeout=120000)
        pg.pdf(path=svg[:-4] + ".pdf", width=f"{W}px", height=f"{H}px", print_background=True,
               margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
        pg.close(); os.remove(hp)
        print("ok", os.path.basename(svg), W, H)
    b.close()
