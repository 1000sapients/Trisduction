import sys, re
from playwright.sync_api import sync_playwright
svg = sys.argv[1]; out = sys.argv[2]; scale = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0
head = open(svg, encoding="utf-8").read(400)
m = re.search(r'width="(\d+)" height="(\d+)"', head)
W, H = int(m.group(1)), int(m.group(2))
html = f'<html><head><style>html,body{{margin:0;padding:0;background:#fff}}img{{display:block;width:{W}px;height:{H}px}}</style></head><body><img src="file://{svg}"></body></html>'
open(out + ".html", "w").write(html)
with sync_playwright() as p:
    b = p.chromium.launch(args=["--disable-gpu"])
    pg = b.new_page(viewport={"width": W, "height": 1000}, device_scale_factor=scale)
    pg.goto("file://" + out + ".html")
    pg.wait_for_load_state("networkidle")
    pg.wait_for_timeout(800)
    pg.screenshot(path=out, full_page=True, timeout=120000)
    b.close()
print("rendered", out, W, H, scale)
