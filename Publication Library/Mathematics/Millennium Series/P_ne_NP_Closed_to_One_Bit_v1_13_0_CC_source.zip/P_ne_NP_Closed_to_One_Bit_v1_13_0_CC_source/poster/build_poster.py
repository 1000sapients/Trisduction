#!/usr/bin/env python3
"""Build the P != NP: Form by Theorem, Value by the Act infographic (v1.13.0 kernel) as a self-contained SVG.

Every monospace identifier is resolved against the kernel index; its color is read from the pinned cone:
green = theorem on no axiom, blue = theorem on Lean's standard axioms, slate = definition.
"""
import base64, io, json, re, sys
from html import escape
from PIL import ImageFont
from fontTools import subset
from fontTools.ttLib import TTFont

SP = "/tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad"
OUT = SP + "/infog/P_ne_NP_Closed_to_One_Bit_Infographic_v1_13_0_CC.svg"
IDX = json.load(open(SP + "/infog/kernel_index.json"))
FD = "/usr/share/fonts/truetype/dejavu/"
FONTFILE = {("s", 400): FD + "DejaVuSans.ttf", ("s", 700): FD + "DejaVuSans-Bold.ttf",
            ("m", 400): FD + "DejaVuSansMono.ttf", ("m", 700): FD + "DejaVuSansMono-Bold.ttf"}
FAMILY = {"s": "PNPSans, 'DejaVu Sans', Verdana, Arial, sans-serif",
          "m": "PNPMono, 'DejaVu Sans Mono', Menlo, Consolas, monospace"}
_PIL = {k: ImageFont.truetype(v, 100) for k, v in FONTFILE.items()}
USED = {k: set() for k in FONTFILE}

# ---------------------------------------------------------------- palette
NAVY, NAVY2, NAVY_ST, PILL_TX, SUB = "#0e2a47", "#1d4066", "#3f6186", "#dcebfb", "#c8d8e8"
BG, INK, BODY, GREY, ARROW, LINE = "#f7f9fa", "#10222e", "#24333d", "#5a6a76", "#33475b", "#c3d2dc"
G, G_T, G_D = "#177e6c", "#e7f4f0", "#0f5c4e"
B, B_T, B_D = "#2f5aa8", "#e9f0fb", "#1e447c"
R, R_T, R_D = "#b3261e", "#fdecea", "#7f1d17"
A, A_T, A_D = "#b7791f", "#fdf3e0", "#7a4a12"
V, V_T, V_2, V_D = "#5b4bc4", "#f1edfd", "#d9d2f7", "#3c3550"
SLATE, WHITE = "#33566e", "#ffffff"

W, M = 1680, 56
CW = W - 2 * M

# ---------------------------------------------------------------- kernel resolution
PREF = ["PNP.TM.", "PNP.LOCALITY.", "PNP.NORMALFORM."]
CHECKED = {}


def resolve(name):
    """Return (full_name, kind, cone) for a short identifier, or raise."""
    ds = IDX["decl"].get(name)
    if not ds:
        raise SystemExit("NOT A DECLARATION OF v1.13.0: " + name)
    pick = ds[0]
    if len(ds) > 1:
        for p in PREF:
            for d in ds:
                if d[0].startswith(p):
                    pick = d
                    break
            else:
                continue
            break
    full, line, kind = pick
    cone = IDX["cone"].get(full)
    CHECKED[name] = (full, kind, cone)
    return full, kind, cone


def id_color(name):
    full, kind, cone = resolve(name)
    if kind != "theorem":
        return SLATE
    if cone is None:
        raise SystemExit("THEOREM WITHOUT A PINNED CONE: " + full)
    return G if cone == "∅" else B


# ---------------------------------------------------------------- metrics
def tw(s, fam="s", wt=400, size=13.0):
    return _PIL[(fam, wt)].getlength(s) * size / 100.0


NB = " "


def glue(s):
    """Keep short formulas on one line: P ≠ NP, SAT ∉ P, c·n + c, k ≥ 2, P = NP."""
    s = re.sub(r" (≠|∉|∈|≥|=|\+|→) ", lambda m: NB + m.group(1) + NB, s)
    s = re.sub(r"(degree|degrees|Parts|Part|seed|grade) (\d)", lambda m: m.group(1) + NB + m.group(2), s)
    return s


def wrap(s, maxw, fam="s", wt=400, size=13.0):
    words, lines, cur = glue(s).split(" "), [], ""
    for w_ in words:
        t = (cur + " " + w_) if cur else w_
        if tw(t, fam, wt, size) <= maxw or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = w_
    if cur:
        lines.append(cur)
    return lines


def id_lines(ids, maxw, size=11.6, wt=400):
    """Wrap a list of identifiers joined by ' · ' into lines of (token, color) runs."""
    sep = " · "
    lines, cur, curw = [], [], 0.0
    for i, n in enumerate(ids):
        col = id_color(n)
        piece = n
        wpiece = tw(piece, "m", wt, size)
        wsep = tw(sep, "m", wt, size) if cur else 0.0
        if cur and curw + wsep + wpiece > maxw:
            lines.append(cur)
            cur, curw = [], 0.0
            wsep = 0.0
        if cur:
            cur.append((sep, GREY))
        cur.append((piece, col))
        curw += wsep + wpiece
    if cur:
        lines.append(cur)
    return lines


# ---------------------------------------------------------------- svg primitives
E = []


def note(fam, wt, s):
    USED[(fam, wt)].update(s)


def rect(x, y, w, h, fill, stroke="none", sw=0, rx=0, op=1, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    o = f' opacity="{op}"' if op != 1 else ""
    E.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx}" fill="{fill}" '
             f'stroke="{stroke}" stroke-width="{sw}"{d}{o}/>')


def line(x1, y1, x2, y2, stroke=ARROW, sw=2, marker=None, dash=None):
    mk = f' marker-end="url(#{marker})"' if marker else ""
    d = f' stroke-dasharray="{dash}"' if dash else ""
    E.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{stroke}" '
             f'stroke-width="{sw}"{mk}{d}/>')


def path(d, fill="none", stroke="none", sw=0, marker=None):
    mk = f' marker-end="url(#{marker})"' if marker else ""
    E.append(f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{mk}/>')


def text(x, y, s, fam="s", wt=400, size=13.0, fill=BODY, anchor="start", ls=None):
    note(fam, wt, s)
    l = f' letter-spacing="{ls}"' if ls else ""
    E.append(f'<text x="{x:.1f}" y="{y:.1f}" font-family="{FAMILY[fam]}" font-size="{size}" '
             f'font-weight="{wt}" fill="{fill}" text-anchor="{anchor}"{l}>{escape(s)}</text>')


def rich(x, y, runs, size=13.0, anchor="start"):
    """runs: list of (s, fam, wt, fill)."""
    parts = []
    for s, fam, wt, fill in runs:
        note(fam, wt, s)
        parts.append(f'<tspan font-family="{FAMILY[fam]}" font-weight="{wt}" fill="{fill}">{escape(s)}</tspan>')
    E.append(f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" '
             f'xml:space="preserve">{"".join(parts)}</text>')


def ids_draw(x, y, lines, size=11.6, lh=16.0, wt=400, anchor="start"):
    for i, ln in enumerate(lines):
        rich(x, y + i * lh, [(s, "m", wt, c) for s, c in ln], size=size, anchor=anchor)


def pill(cx, y, label, fill, tx, size=11.0, stroke="none", h=22, anchor="middle"):
    wpx = tw(label, "s", 700, size) + 22
    x = cx - wpx / 2 if anchor == "middle" else cx
    rect(x, y, wpx, h, fill, stroke, 1 if stroke != "none" else 0, rx=h / 2)
    text(x + wpx / 2, y + h / 2 + size * 0.36, label, "s", 700, size, tx, "middle", ls="0.4")
    return wpx


# ---------------------------------------------------------------- composite builders
class Block:
    """A measured block: height h, and draw(x, y, h_override) callback."""

    def __init__(self, h, fn):
        self.h, self.fn = h, fn

    def draw(self, x, y, h=None):
        self.fn(x, y, self.h if h is None else h)


def card(w, title, body, ids, accent, fill=WHITE, tcol=INK, icon=None, tsize=13.6, bsize=12.8, lh=17.2,
         isize=11.4, ilh=15.6, stroke=None, kicker=None, kcol=None):
    pad_l, pad_r, top = 18, 14, 12
    tx_w = w - pad_l - pad_r - (22 if icon else 0)
    tl = wrap(title, tx_w, "s", 700, tsize)
    bl = wrap(body, w - pad_l - pad_r, "s", 400, bsize) if body else []
    il = id_lines(ids, w - pad_l - pad_r, isize) if ids else []
    kl = 1 if kicker else 0
    h = top + kl * 16 + len(tl) * (tsize + 4) + (4 + len(bl) * lh if bl else 0) + (6 + len(il) * ilh if il else 0) + 10

    def fn(x, y, hh):
        rect(x, y, w, hh, fill, stroke or LINE, 1, rx=8)
        rect(x, y, 6, hh, accent, rx=0)
        cy = y + top
        if kicker:
            text(x + pad_l, cy + 10, kicker, "s", 700, 10.2, kcol or accent, ls="0.8")
            cy += 16
        ix = x + pad_l
        if icon:
            text(ix, cy + tsize - 1, icon, "s", 700, tsize + 1, accent)
            ix += 22
        for i, t in enumerate(tl):
            text(ix, cy + tsize - 1 + i * (tsize + 4), t, "s", 700, tsize, tcol)
        cy += len(tl) * (tsize + 4)
        if bl:
            cy += 4
            for i, t in enumerate(bl):
                text(x + pad_l, cy + bsize - 1 + i * lh, t, "s", 400, bsize, BODY)
            cy += len(bl) * lh
        if il:
            cy += 6
            ids_draw(x + pad_l, cy + isize - 1, il, isize, ilh)

    return Block(h, fn)


def grid(cards, cols, x, y, w, gap=14, vgap=14, draw=True):
    cw = (w - gap * (cols - 1)) / cols
    rows = [cards[i:i + cols] for i in range(0, len(cards), cols)]
    cy = y
    for r in rows:
        rh = max(c(cw).h for c in r)
        for j, c in enumerate(r):
            if draw:
                c(cw).draw(x + j * (cw + gap), cy, rh)
        cy += rh + vgap
    return cy - vgap - y


def band_header(y, label, right, color, h=44):
    rect(M, y, CW, h, color, rx=10)
    rect(M, y + h - 10, CW, 10, color)
    text(M + 22, y + 29, label, "s", 700, 18.5, WHITE, ls="0.6")
    if right:
        text(W - M - 20, y + 28, right, "m", 700, 12.2, WHITE, "end")
    return h


def band(y, label, right, color, tint, content_h_fn, content_draw_fn, pad=18):
    hh = 44
    ch = content_h_fn()
    total = hh + pad + ch + pad
    rect(M, y, CW, total, tint, color, 1.6, rx=10)
    band_header(y, label, right, color, hh)
    content_draw_fn(y + hh + pad)
    return total


# ================================================================ CONTENT
y = 0
rect(0, 0, W, 10000, BG)  # trimmed at the end
BGI = len(E) - 1

# ---------------------------------------------------------------- header
HEAD_H = 214
rect(0, 0, W, HEAD_H, NAVY)
rect(0, HEAD_H - 6, W, 6, V)
text(M, 64, "P ≠ NP: FORM BY THEOREM, VALUE BY THE ACT · OUR WAY OR NO WAY", "s", 700, 32, WHITE, ls="0.3")
sub = ("The unconditional normal form of the separation of SAT on Turing machines · twenty-two walls at theorem "
       "grade · the one keyed bit, supplied by the act and delivered twice · nothing escapes")
for i, t in enumerate(wrap(sub, CW, "s", 400, 16.2)):
    text(M, 98 + i * 22, t, "s", 400, 16.2, SUB)
pills = ["PNP_Normal_Form_Paper_v1_13_0_CC.lean · 10,358 LINES · 687 THEOREMS",
         "LEAN 4.19.0 · CORE · NO IMPORT · 0 SORRY · 0 AXIOMS DECLARED · SILENT BUILD",
         "610 PINNED CONES · 258 ON NO AXIOM · 352 ON LEAN'S STANDARD AXIOMS"]
psz = 12.0
while sum(tw(p, "m", 700, psz) + 34 for p in pills) > CW - 60:
    psz -= 0.2
pw = [tw(p, "m", 700, psz) + 34 for p in pills]
gap = (CW - sum(pw)) / 2
px = M
for p, w_ in zip(pills, pw):
    rect(px, 150, w_, 32, NAVY2, NAVY_ST, 1, rx=16)
    text(px + w_ / 2, 171, p, "m", 700, psz, PILL_TX, "middle")
    px += w_ + gap
y = HEAD_H + 26

# ---------------------------------------------------------------- the seal equation
text(M, y + 14, "THE SEAL  ·  WHAT THE LEAN PROVES UNCONDITIONALLY  +  THE BIT DELIVERED  +  EVERY BLOCKER, OLD AND NEW",
     "s", 700, 14.5, INK, ls="0.5")
y += 30
OPW = 50
TW_ = (CW - 4 * OPW) / 5
tiles = [
    ("I · PROVEN UNCONDITIONALLY", G, G_T,
     "The form: SAT ∈ NP built, degrees 0 and 1 constructed, the bit isolated, every route through it.",
     "THEOREM", ["proven_unconditionally"]),
    ("II · THE BIT DELIVERED", A, A_T,
     "Supplied by the act. Two kinds, one bit: the formal cargo and the physical witness, each giving P ≠ NP.",
     "PREMISE · SUPPLIED BY THE ACT", ["the_delivery"]),
    ("III · THE WALLS", R, R_T,
     "Every blocker, old and new: twenty-two proved in the kernel, seven carried from the Mother Codex.",
     "THEOREM IN THE KERNEL", ["the_blocks"]),
    ("THE SEAL", NAVY, "#e6edf5",
     "Eight links in one theorem, nothing before the colon. The tuple does not compress: every face keeps its grade.",
     "ONE CERTIFICATE", ["the_block_chain"]),
    ("OUR WAY OR NO WAY", V, V_T,
     "Every so-called other way to P ≠ NP is our way in different vocabulary: it delivers both kinds, and if the bit "
     "failed it would fail with it.",
     "THEOREM", ["our_way_or_no_way", "the_capstone"]),
]
ops = ["+", "+", "=", "⇒"]
tile_bl = [wrap(t[3], TW_ - 28, "s", 400, 13.2) for t in tiles]
tile_il = [id_lines(t[5], TW_ - 28, 11.6) for t in tiles]
TH = 40 + max(len(b) for b in tile_bl) * 18 + 12 + 24 + 10 + max(len(i) for i in tile_il) * 16 + 14
for k, (title, col, tint, body, grade, ids) in enumerate(tiles):
    x = M + k * (TW_ + OPW)
    rect(x, y, TW_, TH, tint, col, 1.8, rx=10)
    rect(x, y, TW_, 36, col, rx=10)
    rect(x, y + 26, TW_, 10, col)
    text(x + TW_ / 2, y + 24, title, "s", 700, 13.6, WHITE, "middle", ls="0.5")
    cy = y + 36 + 22
    for i, t in enumerate(tile_bl[k]):
        text(x + 14, cy + i * 18, t, "s", 400, 13.2, BODY)
    cy += max(len(b) for b in tile_bl) * 18 + 4
    pill(x + TW_ / 2, cy, grade, col, WHITE, 10.6)
    cy += 24 + 12 + 10
    ids_draw(x + TW_ / 2, cy, tile_il[k], 11.6, 16, anchor="middle")
    if k < 4:
        ox = x + TW_ + OPW / 2
        E.append(f'<circle cx="{ox:.1f}" cy="{y + TH / 2:.1f}" r="19" fill="{WHITE}" stroke="{ARROW}" stroke-width="2"/>')
        text(ox, y + TH / 2 + 8.5, ops[k], "s", 700, 24, ARROW, "middle")
y += TH + 22

# ---------------------------------------------------------------- the one bit strip
OB_H = 64
rect(M, y, CW, OB_H, NAVY2, NAVY, 1.4, rx=10)
text(M + 22, y + 26, "THE ONE BIT", "s", 700, 15, "#ffd98a", ls="1")
text(M + 22, y + 47, "TheInequality", "m", 700, 13, PILL_TX)
bit = "NothingEscapes (Rec TMSAT) → NothingEscapes TMSAT"
text(M + 196, y + 41, bit, "m", 700, 21, WHITE)
rt = "printed as a type · assumed nowhere · supplied by the act · delivered twice"
text(W - M - 22, y + 39, rt, "s", 400, 14, SUB, "end")
y += OB_H + 18

# ---------------------------------------------------------------- THE ONE BIT · 7 UNIQUE PROPERTIES
SEVEN_U = [
    ("NECESSARY",
     "SAT ∉ P cannot hold without the transfer, and with the hardness half cited neither can P ≠ NP. Whatever "
     "proves either proves the bit first.",
     ["pnp_normal_form_turing", "form_closed"]),
    ("SUFFICIENT",
     "The bit alone, the one explicit premise, gives SAT ∉ P in one step and P ≠ NP with nothing cited.",
     ["sat_not_in_P_of_the_act", "p_ne_np_of_the_one_bit"]),
    ("IRREDUCIBLE",
     "Nothing the two worlds share supplies it: no premise of every machine, of every SAT model or of every record. "
     "The bit is keyed and seatless.",
     ["residue_is_keyed", "sat_bit_is_keyed", "no_uniform_answer", "seatless_lock"]),
    ("MANDATORY",
     "Every route from any premise delivers the bit. Every exit is the posit, and the posit is every exit.",
     ["tmsat_every_route_passes_the_bit", "every_exit_is_the_posit", "the_posit_is_every_exit"]),
    ("FUTURE-PROOF",
     "Any future proof, from any premise, arrives as this bit in both kinds. Any two certificates are one object, "
     "any two proofs one proof.",
     ["every_route_is_both_kinds", "certificate_unique"]),
    ("NO OTHER PROOF",
     "Every so-called other way to P ≠ NP is our way in different vocabulary: it delivers both kinds, and if the bit "
     "failed it would fail with it.",
     ["our_way_or_no_way", "every_delivery_is_both_kinds", "nothing_escapes"]),
    ("TWO KINDS OF ACT, BOTH SUPPLIED",
     "The formal cargo and the physical witness: one bit, each delivering P ≠ NP, both supplied by the act.",
     ["the_two_kinds_are_one_bit", "both_kinds_deliver", "formal_kind_delivers", "physical_kind_delivers"]),
]
su_cards = [(lambda k, t, b, ids: (lambda w: card(w, t, b, ids, V, tcol=V_D, kicker=f"PROPERTY {k} OF 7", kcol=V,
                                                  tsize=14.6)))(k + 1, t, b, ids)
            for k, (t, b, ids) in enumerate(SEVEN_U)]
su_cards.append(lambda w: card(w, "GRADE · THEOREM FOR ALL SEVEN",
                               "The bit they govern is supplied by the act and delivered twice; it has ten faces, one proposition, "
                             "and each face delivers P ≠ NP.",
                               ["the_one_bit_delivers_p_ne_np", "ten_faces_of_the_one_bit"], NAVY, fill=V_2,
                               tcol=NAVY, kicker="THE SEVEN, BOUND", kcol=NAVY, stroke=V, tsize=14.6))
y += band(y, "THE ONE BIT · 7 UNIQUE PROPERTIES · EACH A THEOREM", "the_one_bit_delivers_p_ne_np", V, V_T,
          lambda: grid(su_cards, 4, M + 18, 0, CW - 36, draw=False),
          lambda yy: grid(su_cards, 4, M + 18, yy, CW - 36)) + 26
resolve("the_one_bit_delivers_p_ne_np")

# ---------------------------------------------------------------- BAND I · proven unconditionally
P_CARDS = [
    ("SAT ∈ NP, BUILT IN THE KERNEL",
     "A 5,120-state one-tape verifier over nineteen tape symbols accepts every satisfiable formula, given its "
     "certificate, within 5000·n⁴ + 5000 steps, and accepts no unsatisfiable one. The membership half of Cook and "
     "Levin is a theorem.",
     ["satLang_in_NP", "verifier_sound", "verifier_complete", "vtime_le"]),
    ("DEGREE 0 · CONSTANT TIME FAILS",
     "No Turing machine decides SAT within a constant budget. Locality is proved once for every machine, and a "
     "computed witness defeats every decider at every constant.",
     ["sat_not_in_P_at_degree_zero", "diagonal_target_at_zero", "witness0_spec", "run_local", "prefix_forces_time"]),
    ("DEGREE 1 · LINEAR TIME FAILS",
     "No one-tape Turing machine decides SAT within c·n + c steps, at any c: Hennie's crossing sequences, run on "
     "SAT's own fooling family.",
     ["sat_not_in_P_at_degree_one", "diagonal_target_at_one", "cut_paste", "fool_cs_inj", "fool_long"]),
    ("THE REAL-PART SEPARATION",
     "SAT ∈ NP, SAT outside constant and linear one-tape time, and the bit equal to the Diagonal Target from "
     "degree 2, in one theorem with nothing before the colon.",
     ["unconditional_real_part_separation", "the_final_witness_capstone"]),
    ("THE NORMAL FORM",
     "Over every Turing machine, SAT ∉ P is exactly one implication: least escape carried from the record of the "
     "SAT machine to the machine.",
     ["pnp_normal_form_turing", "sep_tmsat_iff", "sep_normal_form", "coincidence_normal_form"]),
    ("THE RECORD CLOSES",
     "The record answers every run wrongly, so it has least escape on no axiom. At TMSAT it is a fixed point "
     "carrying separation, self-recursion and a fertile machine.",
     ["record_has_least_escape", "tmsat_record_has_least_escape", "the_record_closes_at_tmsat",
      "record_locus_fixed_point_unconditional"]),
    ("THE BIT ON NO AXIOM",
     "The transfer in its constructive form, landing on “no decider escapes”, is exactly SAT ∉ P on an empty cone: "
     "no propext, no choice, no quotient.",
     ["racomp_cargo_iff_not_inP", "every_route_spends_the_bit_free"]),
    ("EVERY ROUTE PASSES THE BIT",
     "Any proof of SAT ∉ P, from any premise, is a proof of the bit. Every exit is the posit and the posit every "
     "exit. One certificate, one proof.",
     ["tmsat_every_route_passes_the_bit", "every_exit_is_the_posit", "the_posit_is_every_exit",
      "certificate_unique"]),
    ("TEN FACES, ONE PROPOSITION",
     "SAT ∉ P, the separation at SAT, Sep, closure, self-recursion, record coincidence, the fertile machine, the "
     "selected machine, the physical witness and the degree tail: one bit.",
     ["ten_faces_of_the_one_bit", "face_formal", "face_physical", "face_diagonal", "face_closure"]),
    ("THE RESIDUE, EXACT",
     "The bit is the Diagonal Target at every degree k ≥ 2, and equally the tail from any degree m ≥ 1. The "
     "ladder may be cut anywhere.",
     ["the_inequality_from_degree_two", "barrier_from_degree_two", "gate_7_dual", "the_inequality_iff_cofinal"]),
    ("THE BIT DELIVERS P ≠ NP",
     "With SAT ∈ NP built, the bit and every one of its faces give P ≠ NP with nothing cited.",
     ["p_ne_np_of_the_one_bit", "barrier_implies_p_ne_np", "the_one_bit_delivers_p_ne_np_unconditional"]),
    ("THE MODEL, BUILT",
     "Finite-control Turing machines on one two-way tape, running time as the first halting step, a binary "
     "encoding with its decoder proved inverse, SAT as a language, P and NP as definitions.",
     ["TM", "run", "firstHalt", "time_least", "decode_encode", "satLang", "InP", "InNP", "P_ne_NP"]),
]


def mk_pcard(t, b, ids):
    return lambda w: card(w, t, b, ids, G, icon="✓")


pc = [mk_pcard(*c) for c in P_CARDS]
y += band(y, "I · PROVEN UNCONDITIONALLY · THEOREM GRADE · NOTHING BEFORE THE COLON",
          "proven_unconditionally · unconditional_real_part_separation", G, G_T,
          lambda: grid(pc, 4, M + 18, 0, CW - 36, draw=False),
          lambda yy: grid(pc, 4, M + 18, yy, CW - 36)) + 26
resolve("proven_unconditionally"); resolve("unconditional_real_part_separation")

# ---------------------------------------------------------------- BAND II · the bit delivered
KEY = [("THE WALL STANDS", "A premise every world shares forces nothing.", ["the_wall_stands"]),
       ("THE KEY FORCES", "A reading forces what it reads.", ["the_key_forces"]),
       ("THE KEY IS KEYED", "Not shared by every world: the wall is passed, not broken.", ["the_key_is_keyed"]),
       ("THE KEY IS THE BIT", "At TMSAT the reading is exactly the bit.", ["the_key_at_the_row"]),
       ("THE KEY DELIVERS", "The key at TMSAT gives P ≠ NP.", ["the_key_delivers"])]
KINDS = [("KIND 1 · THE FORMAL CARGO",
          "The bit as a type: the record's closure carried to the machine.",
          ["cargo_arrives", "formal_kind_delivers", "face_formal"]),
         ("KIND 2 · THE PHYSICAL WITNESS",
          "The bit carried by a witness holding the Diagonal Target in its own field.",
          ["witness_closes", "physical_kind_delivers", "face_physical"])]
FORM = [("P ≠ NP AND THE BIT ARE ONE PROPOSITION", "and so is every face of the bit.",
         ["millennium_sentence_iff_one_bit_hNP_free", "the_proof"]),
        ("THE DENIAL IS THE BIT'S DENIAL", "P = NP is exactly the failure of the transfer.",
         ["denial_is_the_bits_denial"]),
        ("P ≠ NP IS THE BARRIER", "the Diagonal Target from degree 2, under the hardness half alone.",
         ["p_ne_np_iff_barrier"]),
        ("EVERY ROUTE TO P ≠ NP SPENDS THE BIT", "on an empty cone.", ["every_pnp_route_spends_the_bit_free"]),
        ("A PREMISE THAT GIVES P ≠ NP WHILE THE BIT FAILS IS FALSE", "",
         ["form_closed", "demand_for_p_ne_np_without_bit_illegal_free"]),
        ("THE QUESTION IS CLOSED TO ONE BIT", "", ["question_closed_to_one_bit"])]
FACES = [("THE BIT", ["p_ne_np_of_the_one_bit"]),
         ("THE FORMAL CARGO · THE PHYSICAL WITNESS", ["both_kinds_deliver"]),
         ("THE KEY AT TMSAT", ["the_key_delivers"]),
         ("THE BARRIER", ["barrier_implies_p_ne_np"]),
         ("THE SEPARATION AT SAT", ["sat_separates_gives_p_ne_np"]),
         ("THE DIAGONAL TARGET · THE FERTILE MACHINE · THE SELECTED MACHINE · THE DEGREE TAIL FROM 2",
          ["the_one_bit_delivers_p_ne_np_unconditional"])]


def delivery_layout(y0, draw):
    x0, w0 = M + 18, CW - 36
    cy = y0
    # key flow
    n = len(KEY)
    chev = 26
    kw = (w0 - (n - 1) * chev) / n
    kb = [wrap(b, kw - 28, "s", 400, 12.8) for _, b, _ in KEY]
    kh = 16 + 18 + max(len(b) for b in kb) * 17 + 8 + 16 + 12
    if draw:
        text(x0, cy + 12, "THE KEY PASSES THE WALL", "s", 700, 13.5, A_D, ls="0.8")
    cy += 22
    for i, (t, b, ids) in enumerate(KEY):
        x = x0 + i * (kw + chev)
        if draw:
            rect(x, cy, kw, kh, WHITE, A, 1.5, rx=8)
            text(x + kw / 2, cy + 24, t, "s", 700, 13.4, A_D, "middle")
            for j, l in enumerate(kb[i]):
                text(x + kw / 2, cy + 46 + j * 17, l, "s", 400, 12.8, BODY, "middle")
            ids_draw(x + kw / 2, cy + kh - 14, id_lines(ids, kw - 20, 11.6), 11.6, anchor="middle")
            if i < n - 1:
                ax = x + kw + 3
                path(f"M{ax:.1f},{cy + kh / 2 - 9:.1f} L{ax + chev - 6:.1f},{cy + kh / 2:.1f} "
                     f"L{ax:.1f},{cy + kh / 2 + 9:.1f} z", fill=A)
    cy += kh + 18
    # three panels
    pw_ = (w0 - 2 * 16) / 3
    # panel 1: two kinds
    def kinds_block(draw_at=None):
        h = 0
        blocks = [card(pw_ - 24, t, b, ids, V, fill=V_T, tcol=V_D, stroke=V_2) for t, b, ids in KINDS]
        h += 30
        for bl in blocks:
            h += bl.h + 10
        tail = wrap("The physical kind is the formal kind, and each gives P ≠ NP.", pw_ - 24, "s", 400, 12.8)
        tail_ids = id_lines(["the_two_kinds_are_one_bit", "p_ne_np_delivered_twice", "both_kinds_deliver"],
                            pw_ - 24, 11.4)
        h += len(tail) * 17 + 6 + len(tail_ids) * 15.6 + 8
        refb = card(pw_ - 24, "THE ONE REFUTER",
                    "One polynomial-time Turing machine for SAT, every run clean, refutes both kinds at once, denies "
                    "the sentence, and leaves every theorem of the kernel standing.",
                    ["the_one_refuter", "refuter_denies_the_sentence"], A, fill=A_T, tcol=A_D, stroke="#e8c98f")
        h += 8 + refb.h
        if draw_at:
            xx, yy, hh = draw_at
            rect(xx, yy, pw_, hh, WHITE, V, 1.5, rx=10)
            text(xx + 12, yy + 22, "TWO KINDS, ONE BIT", "s", 700, 13.5, V_D, ls="0.8")
            by = yy + 30
            for bl in blocks:
                bl.draw(xx + 12, by)
                by += bl.h + 10
            for j, l in enumerate(tail):
                text(xx + 12, by + 13 + j * 17, l, "s", 400, 12.8, BODY)
            by += len(tail) * 17 + 6
            ids_draw(xx + 12, by + 11, tail_ids, 11.4, 15.6)
            by += len(tail_ids) * 15.6 + 8 + 8
            refb.draw(xx + 12, by)
        return h + 6

    def form_block(draw_at=None):
        h = 30
        items = []
        for t, b, ids in FORM:
            tl = wrap(t, pw_ - 24, "s", 700, 12.8)
            bl = wrap(b, pw_ - 24, "s", 400, 12.6) if b else []
            il = id_lines(ids, pw_ - 24, 11.4)
            ih = len(tl) * 17 + len(bl) * 17 + len(il) * 15.6 + 12
            items.append((tl, bl, il, ih))
            h += ih
        foot = wrap("Cited as a hypothesis wherever used: the NP-hardness half of Cook and Levin, SATHard.",
                    pw_ - 24, "s", 400, 11.8)
        h += len(foot) * 15.5 + 8
        if draw_at:
            xx, yy, hh = draw_at
            rect(xx, yy, pw_, hh, WHITE, B, 1.5, rx=10)
            text(xx + 12, yy + 22, "THE FORM CLOSED", "s", 700, 13.5, B_D, ls="0.8")
            by = yy + 34
            for tl, bl, il, ih in items:
                for j, l in enumerate(tl):
                    text(xx + 12, by + 12 + j * 17, l, "s", 700, 12.8, INK)
                by2 = by + len(tl) * 17
                for j, l in enumerate(bl):
                    text(xx + 12, by2 + 12 + j * 17, l, "s", 400, 12.6, BODY)
                by2 += len(bl) * 17
                ids_draw(xx + 12, by2 + 11, il, 11.4, 15.6)
                by += ih
            for j, l in enumerate(foot):
                text(xx + 12, yy + hh - 14 - (len(foot) - 1 - j) * 15.5, l, "s", 400, 11.8, GREY)
        return h + 8

    def faces_block(draw_at=None):
        h = 34
        items = []
        for t, ids in FACES:
            tl = wrap(t + " → P ≠ NP", pw_ - 24, "s", 700, 12.6)
            il = id_lines(ids, pw_ - 24, 11.4)
            ih = len(tl) * 17 + len(il) * 15.6 + 12
            items.append((tl, il, ih))
            h += ih
        foot = wrap("SAT ∈ NP is built in the kernel, so no face needs a citation to reach the sentence.", pw_ - 24,
                    "s", 400, 12.2)
        foot_ids = id_lines(["satLang_in_NP"], pw_ - 24, 11.4)
        h += 6 + len(foot) * 16 + len(foot_ids) * 15.6 + 8
        if draw_at:
            xx, yy, hh = draw_at
            rect(xx, yy, pw_, hh, WHITE, G, 1.5, rx=10)
            text(xx + 12, yy + 22, "EVERY FACE DELIVERS P ≠ NP · NOTHING CITED", "s", 700, 13.5, G_D, ls="0.4")
            by = yy + 34
            for tl, il, ih in items:
                for j, l in enumerate(tl):
                    text(xx + 12, by + 12 + j * 17, l, "s", 700, 12.6, INK)
                ids_draw(xx + 12, by + 12 + len(tl) * 17, il, 11.4, 15.6)
                by += ih
            fy = yy + hh - 14 - (len(foot_ids) - 1) * 15.6 - len(foot) * 16
            for j, l in enumerate(foot):
                text(xx + 12, fy + j * 16, l, "s", 400, 12.2, G_D)
            ids_draw(xx + 12, fy + len(foot) * 16, foot_ids, 11.4, 15.6)
        return h + 4

    ph = max(kinds_block(), form_block(), faces_block())
    if draw:
        kinds_block((x0, cy, ph))
        form_block((x0 + pw_ + 16, cy, ph))
        faces_block((x0 + 2 * (pw_ + 16), cy, ph))
    cy += ph
    return cy - y0


y += band(y, "II · THE BIT DELIVERED · SUPPLIED BY THE ACT · TWO KINDS, ONE BIT, DELIVERED TWICE",
          "the_delivery · p_ne_np_delivered_twice", A, A_T,
          lambda: delivery_layout(0, False), lambda yy: delivery_layout(yy, True)) + 26
resolve("the_delivery"); resolve("p_ne_np_delivered_twice")

# ---------------------------------------------------------------- BAND III · the walls
WALLS = [
    ("KEYLESS WALL", "Bars every premise true of every machine.", ["keyless_forces_nothing", "the_wall_stands"]),
    ("SAT-KEYLESS WALL", "Bars every premise shared by every algorithm model of SAT.", ["sat_keyless_forces_nothing"]),
    ("NO UNIFORM ANSWER", "The kernel's relativization wall. Bars every argument uniform across the algorithm models "
     "of SAT, black-box self-reference included.", ["no_uniform_answer"]),
    ("RECORD WALL", "Bars every principle true of every record.", ["no_record_principle_decides",
                                                                 "record_decides_nothing"]),
    ("THE FINITE RECORD", "Bars the record of either SAT world: both records close, one world escapes.",
     ["sat_record_decides_nothing"]),
    ("STOCKS OF STOPS", "Bars every stock of stops, finite or infinite: each stop certifies its own pair.",
     ["tmsat_no_record_decides", "stage1_is_local"]),
    ("BLACK-BOX SEARCH", "Bars every fixed test list: over 2^N candidates none is shorter than 2^N.",
     ["black_box_no_savings", "missing_object_is_keyed"]),
    ("SELF-VERIFICATION", "Bars self-certification: a statement self-verifies exactly when it is true.",
     ["self_verifying_iff_true"]),
    ("THE RECORD'S SELF-RECURSION", "Bars its transfer: the stage record is self-recursive, the stage world is not.",
     ["record_self_recursion_does_not_transfer"]),
    ("THE VACANT SEAT", "Bars every fixed point of complementation on the bit.", ["locus_vanishes", "seatless_lock"]),
    ("THE CROSSING CEILING", "Bars the degree-1 count at degree 2: it certifies no more than n² + 1, on every pad.",
     ["count_falls_short", "pigeon_ceiling", "count_ceiling"]),
    ("THE SELF-TABLEAU WALL", "Bars a diagonal formula carrying its own budgeted run: the budget outgrows the formula "
     "at every k ≥ 1.", ["self_tableau_block"]),
    ("NO LANGUAGE IS ITS OWN COMPLEMENT", "Mother II.1. Bars every residence argument: sixteen languages, eight "
     "two-cycles, no fixed set.", ["no_language_is_its_complement", "sixteen_languages_eight_two_cycles"]),
    ("THE SIGN-BLIND SQUARE", "Mother II.2. Bars every squared invariant as a reader of the truth-sign.",
     ["square_is_sign_blind"]),
    ("THE DIAGONAL BLINDSPOT", "Mother III.1. Bars every catalogue that certifies its own completeness.",
     ["the_diagonal_blindspot"]),
    ("NO PHYSICAL DISCHARGE BUT THE BIT", "Bars every physical argument that does not prove the bit.",
     ["physical_discharge_is_the_bit"]),
    ("THE BRIDGE IS THE CONJECTURE", "Bars every bridge from the physical asymmetry smaller than P ≠ NP.",
     ["bridge_premise_is_the_conjecture"]),
    ("NO TOTAL WALL", "Bars a wall against every premise at once: the bit forces itself.", ["no_total_wall"]),
    ("THE SHUT DOOR IS THE COLLAPSE", "Bars the proclamation that every road is shut: that proclamation is P = NP.",
     ["shut_door_is_collapse", "total_wall_iff_negation"]),
    ("BOTH FATES ARE RESOLUTIONS", "Bars either fate-pronouncement as anything but a resolution.",
     ["both_fates_are_resolutions"]),
    ("A BLOCK NEEDS AN OUTSIDE", "Bars every flip read off the record alone: no record-preserving involution flips "
     "a target the record determines.", ["block_needs_an_outside"]),
    ("THE ILLEGAL DEMAND", "Bars every demand for P ≠ NP that denies the bit: the premise is refuted.",
     ["demand_for_p_ne_np_without_bit_illegal", "demand_for_p_ne_np_without_bit_illegal_free"]),
]
WALL_SUM = [
    ("EVERY ROAD PASSES THE BIT", "Every road to SAT ∉ P passes the bit; the walls bar every method of supplying it "
     "that their quantifiers cover, born or unborn.", ["tmsat_every_route_passes_the_bit", "residue_is_keyed"]),
    ("THE WALLS IN ONE THEOREM", "Keyless, record, SAT-keyless, uniform, the vacant seat, the crossing ceiling and the "
     "self-tableau wall, bound together.", ["the_blocks", "the_attempt_at_two"]),
]
MOTHER = [
    ("I.1 · RELATIVIZATION", "Relativizing arguments", "Baker, Gill and Solovay 1975"),
    ("I.2 · NATURAL PROOFS", "Constructive, large lower-bound proofs", "Razborov and Rudich 1997"),
    ("I.3 · ALGEBRIZATION", "Arithmetization with oracle access", "Aaronson and Wigderson 2009"),
    ("I.4 · LOCALITY", "Local reductions and hardness magnification", "The locality barrier, 2020 and 2022"),
    ("I.5 · THE COUSIN WING", "Occurrence obstructions, rank methods, algebraic natural proofs",
     "Bürgisser, Ikenmeyer and Panova 2016, with kin"),
    ("I.6 · PROOF SYSTEMS", "Lower-bound proofs inside named fragments of bounded arithmetic", "Razborov 1995"),
    ("II.3 TO II.8", "Floor and arrow, misattribution, every metatheory rung, access, jurisdiction, soundness",
     "ABSOLUTE-PNP-BARRIERS-01, JURISDICTION-BARRIER-01"),
]


def walls_layout(y0, draw):
    x0, w0 = M + 18, CW - 36
    cy = y0
    root = ("THE BIT IS KEYED. True on the closed SAT world, false on the stage SAT world, same formulas, same "
            "predicate. A resource that holds on both worlds answers both alike, so it decides neither: the root of "
            "every uniform wall.")
    rl = wrap(root, w0 - 36, "s", 400, 13.4)
    rids = id_lines(["sat_bit_is_keyed", "bit_is_keyed", "two_rows_two_bits", "record_decides_nothing"],
                    w0 - 36, 11.6)
    rh = 16 + len(rl) * 18 + 4 + len(rids) * 16 + 10
    if draw:
        rect(x0, cy, w0, rh, R_T, R, 1.4, rx=8)
        for j, l in enumerate(rl):
            if j == 0:
                head = "THE BIT IS KEYED."
                rest = l[len(head):] if l.startswith(head) else l
                rich(x0 + 18, cy + 22, [(head, "s", 700, R_D), (rest, "s", 400, BODY)], 13.4)
            else:
                text(x0 + 18, cy + 22 + j * 18, l, "s", 400, 13.4, BODY)
        ids_draw(x0 + 18, cy + 22 + len(rl) * 18 + 2, rids, 11.6)
    cy += rh + 16
    if draw:
        text(x0, cy + 12, "PROVED IN THE KERNEL · THEOREM GRADE · EACH BINDS EVERY METHOD ITS QUANTIFIER COVERS, "
                          "BORN OR UNBORN", "s", 700, 13.2, R_D, ls="0.6")
    cy += 24
    wc = [(lambda t, b, ids, k: (lambda w: card(w, t, b, ids, R, icon="✕", kicker=f"WALL {k:02d}", kcol=R)))(
        t, b, ids, k + 1) for k, (t, b, ids) in enumerate(WALLS)]
    wc += [(lambda t, b, ids: (lambda w: card(w, t, b, ids, R_D, fill=R_T, kicker="BOUND", kcol=R_D)))(t, b, ids)
           for t, b, ids in WALL_SUM]
    gh = grid(wc, 4, x0, cy, w0, draw=draw)
    cy += gh + 18
    if draw:
        text(x0, cy + 12, "CARRIED FROM THE MOTHER CODEX v3.48.0 · BARRIER-MASTER-01 · ABSOLUTE-PNP-BARRIERS-01 · "
                          "CITED AT THEIR OWN GRADES", "s", 700, 13.2, R_D, ls="0.6")
    cy += 24
    n = len(MOTHER)
    gap_ = 12
    mw = (w0 - gap_ * (n - 1)) / n
    mtl = [wrap(t, mw - 20, "s", 700, 12.4) for t, _, _ in MOTHER]
    mbl = [wrap(b, mw - 20, "s", 400, 12.0) for _, b, _ in MOTHER]
    mal = [wrap(a, mw - 20, "s", 400, 11.2) for _, _, a in MOTHER]
    mh = 14 + max(len(t) for t in mtl) * 16 + 4 + max(len(b) for b in mbl) * 15.5 + 6 + max(
        len(a) for a in mal) * 14.5 + 10
    for i in range(n):
        x = x0 + i * (mw + gap_)
        if draw:
            rect(x, cy, mw, mh, WHITE, R, 1.2, rx=8, dash="5 3")
            yy = cy + 14
            for j, l in enumerate(mtl[i]):
                text(x + 10, yy + 11 + j * 16, l, "s", 700, 12.4, R_D)
            yy += max(len(t) for t in mtl) * 16 + 4
            for j, l in enumerate(mbl[i]):
                text(x + 10, yy + 11 + j * 15.5, l, "s", 400, 12.0, BODY)
            yy += max(len(b) for b in mbl) * 15.5 + 6
            for j, l in enumerate(mal[i]):
                text(x + 10, yy + 11 + j * 14.5, l, "s", 400, 11.2, GREY)
    cy += mh + 14
    foot = ("Every wall binds on its own quantifier. A total wall on the bit's routes is the bit's negation "
            "(total_wall_iff_negation), so the walls stand on their quantifiers and the bit is delivered.")
    fl = wrap(foot, w0, "s", 400, 12.6)
    if draw:
        for j, l in enumerate(fl):
            text(x0, cy + 12 + j * 17, l, "s", 400, 12.6, R_D)
    cy += len(fl) * 17
    return cy - y0


y += band(y, "III · THE WALLS · EVERY BLOCKER, OLD AND NEW · 22 PROVED IN THE KERNEL · 7 FROM THE MOTHER CODEX",
          "the_blocks · the_block_chain", R, "#fbf3f2",
          lambda: walls_layout(0, False), lambda yy: walls_layout(yy, True)) + 26
resolve("the_blocks"); resolve("total_wall_iff_negation")

# ---------------------------------------------------------------- BAND IV · the chain
CHAIN = [
    ("PROVEN UNCONDITIONALLY", "SAT ∈ NP, degrees 0 and 1, the bit as SAT ∉ P, every route through it, the residue "
     "from degree 2.", ["proven_unconditionally"]),
    ("THE DELIVERY", "The key at TMSAT is the bit; the key, the bit and both kinds give P ≠ NP.", ["the_delivery"]),
    ("THE FORM CLOSED", "P ≠ NP is the bit; every route to it spends the bit; the one refuter denies it.",
     ["form_closed"]),
    ("THE BLOCKS", "Keyless, record, SAT-keyless and uniform walls, the vacant seat, the crossing ceiling, the "
     "self-tableau wall.", ["the_blocks"]),
    ("THE KEY PASSES", "The reading forces what it reads, and it is no keyless premise.", ["the_key_passes"]),
    ("NO TOTAL WALL", "No wall bars every premise: the bit forces itself.", ["no_total_wall"]),
    ("THE SHUT DOOR IS THE COLLAPSE", "Barring every true route to the bit is asserting P = NP.",
     ["shut_door_is_collapse"]),
    ("THE ROWS AND THE BRIDGE", "The bridge is the conjecture; every physical discharge is the bit; the type-indexed "
     "rows hold.", ["bridge_premise_is_the_conjecture", "physical_discharge_is_the_bit",
                    "no_language_is_its_complement", "square_is_sign_blind", "the_diagonal_blindspot",
                    "both_fates_are_resolutions"]),
]


def chain_layout(y0, draw):
    x0, w0 = M + 18, CW - 36
    cols, gap_ = 4, 34
    cw_ = (w0 - gap_ * (cols - 1)) / cols
    blocks = [card(cw_, t, b, ids, NAVY, kicker=f"LINK {k + 1}", kcol=NAVY2) for k, (t, b, ids) in enumerate(CHAIN)]
    rows = [blocks[0:4], blocks[4:8]]
    cy = y0
    for r_i, r in enumerate(rows):
        rh = max(b.h for b in r)
        for j, b in enumerate(r):
            x = x0 + j * (cw_ + gap_)
            if draw:
                b.draw(x, cy, rh)
                if j < cols - 1:
                    # chain link glyph
                    lx = x + cw_ + 4
                    ly = cy + rh / 2
                    E.append(f'<ellipse cx="{lx + 8:.1f}" cy="{ly:.1f}" rx="9" ry="6" fill="none" stroke="{NAVY}" '
                             f'stroke-width="2.4"/>')
                    E.append(f'<ellipse cx="{lx + 18:.1f}" cy="{ly:.1f}" rx="9" ry="6" fill="none" stroke="{NAVY2}" '
                             f'stroke-width="2.4"/>')
        cy += rh + (30 if r_i == 0 else 0)
        if draw and r_i == 0:
            # link row 1 end to row 2 start: an elbow through the gap between the rows
            yb, ym = cy - 30, cy - 15
            path(f"M{x0 + w0 - cw_ / 2:.1f},{yb:.1f} L{x0 + w0 - cw_ / 2:.1f},{ym:.1f} "
                 f"L{x0 + cw_ / 2:.1f},{ym:.1f} L{x0 + cw_ / 2:.1f},{cy - 3:.1f}", stroke=NAVY, sw=2.2,
                 marker="arrN")
    foot = ("A reader checks one declaration and holds all eight links. Links 1 to 3 close the form; links 4 and 8 "
            "seat every kernel wall; link 5 passes the key; links 6 and 7 seal the walls against overreach in both "
            "directions.")
    fl = wrap(foot, w0, "s", 400, 12.8)
    cy += 14
    if draw:
        for j, l in enumerate(fl):
            text(x0, cy + 12 + j * 17, l, "s", 400, 12.8, BODY)
    cy += len(fl) * 17
    return cy - y0


y += band(y, "IV · THE CHAIN · EIGHT LINKS · ONE THEOREM · NOTHING BEFORE THE COLON", "the_block_chain", NAVY,
          "#eef2f7", lambda: chain_layout(0, False), lambda yy: chain_layout(yy, True)) + 26
resolve("the_block_chain")

# ---------------------------------------------------------------- BAND V · the twelve gates
GATES = [("SREP", "The form stands with no hypothesis.", "gate_1_srep"),
         ("REG", "Ten reading contexts, one proposition.", "gate_2_reg"),
         ("SGEG", "No face drifts: formal, physical, diagonal, separation and closure are each the bit.",
          "gate_3_sgeg"),
         ("CAUSAL", "The native involution fixes nothing, on a bit or on a language.", "gate_4_causal"),
         ("MIG", "Two machines whose records both close split on closure: the record fixes no residence.",
          "gate_5_mig"),
         ("PTB", "The fixed-point reading belongs to the chosen reflection, never to the bit.", "gate_6_ptb"),
         ("DUAL", "The bit is the tail of the Diagonal Target from any degree m ≥ 1.", "gate_7_dual"),
         ("CSCG", "The bit extends the proved degrees 0 and 1.", "gate_8_cscg"),
         ("CSEG", "No join stands above its weakest face; every face keeps its grade.", "gate_9_cseg"),
         ("MTA", "A squared scalar reads a value and its reflection alike.", "gate_10_mta"),
         ("OMA", "The supply enters as the delivery's hypothesis, keyed, never keyless.", "gate_11_oma"),
         ("ADEG", "Every transport is typed: the bridge is the conjecture, the physical discharge the bit.",
          "gate_12_adeg")]


def gates_layout(y0, draw):
    x0, w0 = M + 18, CW - 36
    cols, gap_ = 6, 12
    gw = (w0 - gap_ * (cols - 1)) / cols
    gl = [wrap(b, gw - 20, "s", 400, 12.2) for _, b, _ in GATES]
    gh = 14 + 20 + 8 + max(len(g) for g in gl) * 16 + 8 + 16 + 12
    cy = y0
    for i, (code, b, thm) in enumerate(GATES):
        r_, c_ = divmod(i, cols)
        x = x0 + c_ * (gw + gap_)
        yy = cy + r_ * (gh + 12)
        if draw:
            rect(x, yy, gw, gh, WHITE, B, 1.4, rx=8)
            text(x + 12, yy + 30, f"{i + 1}", "s", 700, 22, B_D)
            text(x + 12 + tw(f"{i + 1}", "s", 700, 22) + 9, yy + 29, code, "s", 700, 15, INK, ls="0.6")
            pill(x + gw - 12 - (tw("PASS", "s", 700, 10.4) + 22), yy + 13, "PASS", G, WHITE, 10.4, anchor="start")
            for j, l in enumerate(gl[i]):
                text(x + 12, yy + 56 + j * 16, l, "s", 400, 12.2, BODY)
            ids_draw(x + 12, yy + gh - 13, id_lines([thm], gw - 20, 11.4), 11.4)
    cy += 2 * gh + 12 + 14
    foot = ("Each gate is a proposition and a theorem. The twelve passes are bound with nothing before the colon in "
            "the_formal_run and again inside the_capstone.")
    fl = wrap(foot, w0, "s", 400, 12.8)
    if draw:
        for j, l in enumerate(fl):
            text(x0, cy + 12 + j * 17, l, "s", 400, 12.8, BODY)
    cy += len(fl) * 17
    return cy - y0


y += band(y, "V · THE TWELVE FORMAL GATES · RUN IN THE KERNEL · ALL TWELVE PASS", "the_formal_run · the_capstone",
          B, B_T, lambda: gates_layout(0, False), lambda yy: gates_layout(yy, True)) + 26
resolve("the_formal_run"); resolve("the_capstone")

# ---------------------------------------------------------------- BAND VI · capstone
CAP = [("THE RECORD CLOSES AT TMSAT", "", ["the_record_closes_at_tmsat"]),
       ("WHAT IT LEAVES UNDECIDED IS THE BIT", "", ["the_undecided_is_the_bit"]),
       ("AT TMSAT, “NOTHING IS OUTSIDE THE RECORD” IS THE BIT ITSELF", "",
        ["nothing_outside_the_record_is_the_bit"]),
       ("A BLOCK NEEDS AN OUTSIDE", "If the target is a function of the record, no record-preserving involution "
        "flips it.", ["block_needs_an_outside"]),
       ("THE OUTSIDE IS THE SUPPLY", "In its two kinds: the formal cargo and the physical witness, one bit.",
        ["the_outside_is_the_supply"]),
       ("EVERY ROUTE IS BOTH KINDS", "Every route to SAT ∉ P, in any vocabulary, delivers both kinds, nothing cited.",
        ["every_route_is_both_kinds"]),
       ("EVERY DELIVERY IS BOTH KINDS", "Every route to P ≠ NP, in any vocabulary, delivers both kinds, the "
        "hardness half of Cook and Levin cited.", ["every_delivery_is_both_kinds"]),
       ("NOTHING ESCAPES", "The Part bound in one theorem, nothing before the colon.", ["nothing_escapes"])]


def capstone_layout(y0, draw):
    x0, w0 = M + 18, CW - 36
    lw = 780
    rx_ = x0 + lw + 24
    rw = w0 - lw - 24
    cy = y0
    # ---- left: the flow
    fx, fw = x0, lw
    yy = cy
    dcx, dw, dh = fx + 250, 172, 52
    if draw:
        rect(dcx - 250, yy, 500, 52, NAVY, rx=10)
        text(dcx, yy + 22, "ANY ROUTE Q TO P ≠ NP", "s", 700, 15, WHITE, "middle", ls="0.8")
        text(dcx, yy + 41, "in any vocabulary · from any premise · by any method, born or unborn", "s", 400,
             12.4, SUB, "middle")
        line(dcx, yy + 52, dcx, yy + 80, ARROW, 2.6, "arr")
    yy += 82
    dcy = yy + 52
    if draw:
        path(f"M{dcx:.1f},{dcy - dh:.1f} L{dcx + dw:.1f},{dcy:.1f} L{dcx:.1f},{dcy + dh:.1f} "
             f"L{dcx - dw:.1f},{dcy:.1f} z", fill=A_T, stroke=A, sw=2)
        text(dcx, dcy - 4, "Does Q reach P ≠ NP", "s", 700, 14, A_D, "middle")
        text(dcx, dcy + 15, "around the bit?", "s", 700, 14, A_D, "middle")
        # route the top arrow to diamond
        # YES branch to the right
        line(dcx + dw, dcy, fx + fw - 306, dcy, R, 2.6, "arrR")
        text(dcx + dw + 10, dcy - 9, "YES", "s", 700, 13, R)
    # refuted box
    rbx, rbw = fx + fw - 300, 300
    rl = wrap("A premise that gives P ≠ NP while the bit fails is false. The demand is refuted.", rbw - 24, "s", 400,
              12.6)
    rids = id_lines(["demand_for_p_ne_np_without_bit_illegal", "form_closed"], rbw - 24, 11.4)
    rbh = 34 + len(rl) * 17 + len(rids) * 15.6 + 12
    if draw:
        rect(rbx, dcy - rbh / 2, rbw, rbh, R_T, R, 2, rx=10)
        text(rbx + 12, dcy - rbh / 2 + 22, "✕ REFUTED BY THEOREM", "s", 700, 13.6, R_D)
        for j, l in enumerate(rl):
            text(rbx + 12, dcy - rbh / 2 + 42 + j * 17, l, "s", 400, 12.6, BODY)
        ids_draw(rbx + 12, dcy - rbh / 2 + 42 + len(rl) * 17 + 0, rids, 11.4, 15.6)
        line(dcx, dcy + dh, dcx, dcy + dh + 34, V, 2.6, "arrP")
        text(dcx + 10, dcy + dh + 22, "NO", "s", 700, 13, V)
    yy = dcy + dh + 36
    # our way box
    ow_x, ow_w = fx, fw
    owl = wrap("Q is our way in different vocabulary. It delivers the formal cargo and the physical witness, and if "
               "the bit failed, Q would fail with it.", ow_w - 40, "s", 400, 13.6)
    owids = id_lines(["our_way_or_no_way", "every_delivery_is_both_kinds", "every_route_is_both_kinds"], ow_w - 40,
                     11.8)
    owh = 40 + len(owl) * 19 + 6 + len(owids) * 16 + 12
    if draw:
        rect(ow_x, yy, ow_w, owh, V, rx=12)
        text(ow_x + 20, yy + 30, "OUR WAY", "s", 700, 21, WHITE, ls="1.4")
        for j, l in enumerate(owl):
            text(ow_x + 20, yy + 54 + j * 19, l, "s", 400, 13.6, "#ece8ff")
        yi = yy + 54 + len(owl) * 19 + 2
        for i_, ln in enumerate(owids):
            rich(ow_x + 20, yi + i_ * 16, [(s, "m", 700, "#ffffff" if c != GREY else "#c9c2f2") for s, c in ln],
                 11.8)
    yy += owh + 14
    # two kinds and P != NP
    kw_ = (fw - 60) / 2
    kh_ = 64
    if draw:
        line(fx + kw_ / 2, yy - 14, fx + kw_ / 2, yy, V, 2.4, None)
        line(fx + fw - kw_ / 2, yy - 14, fx + fw - kw_ / 2, yy, V, 2.4, None)
        for k_, (t, ids) in enumerate([("KIND 1 · FORMAL CARGO", ["face_formal", "formal_kind_delivers"]),
                                       ("KIND 2 · PHYSICAL WITNESS", ["face_physical", "physical_kind_delivers"])]):
            kx = fx + k_ * (kw_ + 60)
            rect(kx, yy, kw_, kh_, V_T, V, 1.6, rx=10)
            text(kx + kw_ / 2, yy + 26, t, "s", 700, 14, V_D, "middle")
            ids_draw(kx + kw_ / 2, yy + 48, id_lines(ids, kw_ - 20, 11.4), 11.4, anchor="middle")
    yy += kh_
    if draw:
        line(fx + kw_ / 2, yy, fx + fw / 2 - 70, yy + 34, V, 2.4, "arrP")
        line(fx + fw - kw_ / 2, yy, fx + fw / 2 + 70, yy + 34, V, 2.4, "arrP")
    yy += 36
    if draw:
        rect(fx + fw / 2 - 150, yy, 300, 56, NAVY, rx=12)
        text(fx + fw / 2, yy + 31, "P ≠ NP", "s", 700, 24, "#ffd98a", "middle")
        text(fx + fw / 2, yy + 49, "both_kinds_deliver", "m", 700, 11.4, PILL_TX, "middle")
        note("m", 700, "both_kinds_deliver")
        resolve("both_kinds_deliver")
    yy += 56
    left_h = yy - cy
    # ---- right: statements
    ry = cy
    if draw:
        text(rx_, ry + 14, "NOTHING ESCAPES · THE OUTSIDE IS THE SUPPLY", "s", 700, 13.6, V_D, ls="0.6")
    ry += 26
    for t, b, ids in CAP:
        tl = wrap(t, rw - 26, "s", 700, 12.8)
        bl = wrap(b, rw - 26, "s", 400, 12.4) if b else []
        il = id_lines(ids, rw - 26, 11.4)
        ih = len(tl) * 17 + len(bl) * 16 + len(il) * 15.6 + 10
        if draw:
            E.append(f'<circle cx="{rx_ + 6:.1f}" cy="{ry + 8:.1f}" r="4.5" fill="{V}"/>')
            for j, l in enumerate(tl):
                text(rx_ + 20, ry + 12 + j * 17, l, "s", 700, 12.8, INK)
            for j, l in enumerate(bl):
                text(rx_ + 20, ry + 12 + len(tl) * 17 + j * 16, l, "s", 400, 12.4, BODY)
            ids_draw(rx_ + 20, ry + 12 + len(tl) * 17 + len(bl) * 16, il, 11.4, 15.6)
        ry += ih
    # the rule
    rule = ("Every so-called other way to P ≠ NP is our way in different vocabulary. An offering that crosses the "
            "row, such as a proof from the standard axioms, is a delivery of the cargo, never a bypass of it.")
    rul = wrap(rule, rw - 28, "s", 700, 13.6)
    ruh = 38 + len(rul) * 19 + 16 + 16
    ry += 6
    if draw:
        rect(rx_, ry, rw, ruh, V_2, V, 2, rx=10)
        text(rx_ + 14, ry + 26, "THE RULE · OUR WAY OR NO WAY", "s", 700, 15, V_D, ls="0.8")
        for j, l in enumerate(rul):
            text(rx_ + 14, ry + 50 + j * 19, l, "s", 700, 13.6, V_D)
        ids_draw(rx_ + 14, ry + 50 + len(rul) * 19 + 2, id_lines(["our_way_or_no_way", "the_capstone"], rw - 28,
                                                                  11.8), 11.8)
    ry += ruh
    right_h = ry - cy
    return max(left_h, right_h)


y += band(y, "VI · THE CAPSTONE · NOTHING ESCAPES · OUR WAY OR NO WAY", "the_capstone · our_way_or_no_way", V,
          V_T, lambda: capstone_layout(0, False), lambda yy: capstone_layout(yy, True)) + 26

# ---------------------------------------------------------------- BAND VII · the verdict
SEALROWS = [("FORM", "P versus NP is one bit; every route passes it; the residue is the Diagonal Target from degree 2.",
             "THEOREM", G),
            ("WALLS", "Twenty-two walls proved in the kernel, seven carried from the Mother Codex, each on its "
                      "quantifier.", "THEOREM IN THE KERNEL", R),
            ("VALUE", "The bit, supplied by the act and delivered twice, giving P ≠ NP.", "PREMISE · THE ACT", A),
            ("THE TUPLE", "The three faces read side by side.", "DOES NOT COMPRESS", NAVY)]
COMPOSITE = [("FACE 1 · THE PHYSICAL FIELD", "SEALED", "Its formal shadow is the bit.",
              ["physical_discharge_is_the_bit"], G),
             ("FACE 2 · THE GEOMETRIC SHAPE", "SEALED", "No fixed set; complementation fixes nothing.",
              ["no_language_is_its_complement", "locus_vanishes"], G),
             ("FACE 3 · THE FORMAL STRING", "[Ø₀] SEALED HALT", "Proved to the bit; the bit delivered by the act.",
              ["the_block_chain", "the_capstone"], NAVY),
             ("BESIDE · THE NAMED INFLATIONS", "BROKEN", "Permanent immunity and final completeness.",
              ["both_fates_are_resolutions", "the_diagonal_blindspot"], R),
             ("BESIDE · THE COINCIDENCE CLAIM P = NP", "BROKEN", "Its one road is SAT ∈ P.",
              ["refusal_collapse", "refuter_denies_the_sentence"], R)]
NOTMEAN = [("“A proof is waiting.”", "A true route to the bit is the bit itself.", ["refusal_waiting"]),
           ("“No proof can ever exist.”", "At P versus NP that sentence is P = NP.",
            ["refusal_no_proof_at_the_bit", "shut_door_is_collapse"]),
           ("“The file is incomplete.”", "The form is closed by theorem; every wall is typed on its quantifier.",
            ["the_block_chain", "the_formal_run"]),
           ("“Try the walled methods again.”", "Each wall binds every method its quantifier covers, born or unborn.",
            ["the_blocks", "the_attempt_at_two"])]


def verdict_layout(y0, draw):
    x0, w0 = M + 18, CW - 36
    cy = y0
    # banner
    bh = 74
    if draw:
        rect(x0, cy, w0, bh, NAVY, rx=12)
        text(x0 + 26, cy + 47, "[Ø₀]", "s", 700, 34, "#ffd98a")
        text(x0 + 128, cy + 33, "THE CLAY QUESTION STANDS AT [Ø₀], THE SEALED HALT", "s", 700, 19, WHITE, ls="0.6")
        text(x0 + 128, cy + 57, "The form sealed by theorem · the walls sealed on their quantifiers · the value sealed "
                                "by the act", "s", 400, 14.2, SUB)
    cy += bh + 16
    c1w = 500
    c2w = 500
    c3w = w0 - c1w - c2w - 32
    # col 1: seal face by face
    c1x, c2x, c3x = x0, x0 + c1w + 16, x0 + c1w + c2w + 32
    h1 = 30
    rows1 = []
    for f, d, g, col in SEALROWS:
        dl = wrap(d, c1w - 24 - 120, "s", 400, 12.6)
        rh = max(len(dl) * 17 + 14, 34) + 26
        rows1.append((f, dl, g, col, rh))
        h1 += rh
    h2 = 30
    rows2 = []
    for f, v, d, ids, col in COMPOSITE:
        dl = wrap(d, c2w - 24, "s", 400, 12.2)
        il = id_lines(ids, c2w - 24, 11.2)
        rh = 20 + len(dl) * 16 + len(il) * 15 + 12
        rows2.append((f, v, dl, il, col, rh))
        h2 += rh
    h3 = 30
    rows3 = []
    for q, d, ids in NOTMEAN:
        dl = wrap(d, c3w - 44, "s", 400, 12.4)
        il = id_lines(ids, c3w - 44, 11.2)
        rh = 20 + len(dl) * 16 + len(il) * 15 + 12
        rows3.append((q, dl, il, rh))
        h3 += rh
    what = "What it is: [Ø₀], the Sealed halt."
    h3 += 34 + 14
    hh = max(h1, h2, h3) + 10
    if draw:
        # col 1
        rect(c1x, cy, c1w, hh, WHITE, NAVY, 1.4, rx=10)
        text(c1x + 12, cy + 22, "THE SEAL, FACE BY FACE", "s", 700, 13.5, NAVY, ls="0.8")
        yy = cy + 34
        for f, dl, g, col, rh in rows1:
            text(c1x + 12, yy + 16, f, "s", 700, 13.4, col)
            for j, l in enumerate(dl):
                text(c1x + 120, yy + 16 + j * 17, l, "s", 400, 12.6, BODY)
            pill(c1x + 120, yy + rh - 32, g, col, WHITE, 10.2, anchor="start")
            if f != "THE TUPLE":
                line(c1x + 12, yy + rh - 4, c1x + c1w - 12, yy + rh - 4, LINE, 1)
            yy += rh
        # col 2
        rect(c2x, cy, c2w, hh, WHITE, NAVY, 1.4, rx=10)
        text(c2x + 12, cy + 22, "THE COMPOSITE · TABLE 5 OF THE STRUCTURAL VERDICT", "s", 700, 13.0, NAVY,
             ls="0.4")
        yy = cy + 34
        for f, v, dl, il, col, rh in rows2:
            text(c2x + 12, yy + 14, f, "s", 700, 12.4, INK)
            vw = tw(v, "s", 700, 10.4) + 22
            pill(c2x + c2w - 12 - vw, yy + 1, v, col, WHITE, 10.4, anchor="start")
            for j, l in enumerate(dl):
                text(c2x + 12, yy + 32 + j * 16, l, "s", 400, 12.2, BODY)
            ids_draw(c2x + 12, yy + 32 + len(dl) * 16, il, 11.2, 15)
            yy += rh
        # col 3
        rect(c3x, cy, c3w, hh, WHITE, R, 1.4, rx=10)
        text(c3x + 12, cy + 22, "WHAT “CLAY OPEN” CANNOT MEAN", "s", 700, 13.5, R_D, ls="0.8")
        text(c3x + 12, cy + 39, "each reading refused by theorem", "s", 400, 11.8, GREY)
        yy = cy + 48
        for q, dl, il, rh in rows3:
            text(c3x + 12, yy + 15, "✕", "s", 700, 15, R)
            text(c3x + 34, yy + 14, q, "s", 700, 13.0, INK)
            for j, l in enumerate(dl):
                text(c3x + 34, yy + 32 + j * 16, l, "s", 400, 12.4, BODY)
            ids_draw(c3x + 34, yy + 32 + len(dl) * 16, il, 11.2, 15)
            yy += rh
        rect(c3x + 12, cy + hh - 44, c3w - 24, 32, NAVY, rx=8)
        text(c3x + c3w / 2, cy + hh - 23, what, "s", 700, 13.6, "#ffd98a", "middle")
    cy += hh
    return cy - y0


y += band(y, "VII · THE VERDICT · THE CLAY QUESTION AT [Ø₀], THE SEALED HALT", "the_block_chain · the_capstone",
          NAVY, "#eef2f7", lambda: verdict_layout(0, False), lambda yy: verdict_layout(yy, True)) + 26

# ---------------------------------------------------------------- legend + footer
LEG_H = 44
rect(M, y, CW, LEG_H, WHITE, LINE, 1, rx=10)
lx = M + 18
text(lx, y + 27, "READING THE POSTER", "s", 700, 12.6, INK, ls="0.8")
lx += tw("READING THE POSTER", "s", 700, 12.6) + 18 * 0.8 + 30
for col, lab in [(G, "theorem name on no axiom at all"), (B, "theorem name on Lean's standard axioms"),
                 (SLATE, "definition"), (R, "✕ a wall: binds every method its quantifier covers"),
                 (A, "the act: supplies the bit")]:
    rect(lx, y + 15, 14, 14, col, rx=3)
    text(lx + 22, y + 27, lab, "s", 400, 12.2, BODY)
    lx += 22 + tw(lab, "s", 400, 12.2) + 26
y += LEG_H + 20

FOOT = [
    ("WHAT IS PROVED · ", "every theorem of Parts A to X, on no axiom or on Lean's standard axioms: the form closed to "
     "one bit on real Turing machines deciding real SAT; SAT ∈ NP built; degrees 0 and 1 constructed; twenty-two walls "
     "at theorem grade; the twelve gates passed; our way or no way."),
    ("WHAT IS CITED · ", "the NP-hardness half of Cook and Levin, SATHard, a hypothesis wherever it is used; the "
     "seven Mother Codex walls, at the grades their authors proved them."),
    ("WHAT IS SUPPLIED · ", "the value, the one bit, by the act at premise grade: printed as a type, assumed "
     "nowhere, delivered twice, by the formal cargo and by the physical witness."),
    ("FALSIFIERS · ", "F1 the silent build: lean -DwarningAsError=true, exit 0, no output, 610 pins compared by the "
     "compiler. F2 the finite battery: 45 machines at seed 20260622, 12 checks passed, 3 planted failures caught, and "
     "the model's checks closed by decide inside the compile. F3 the one refuter: one polynomial-time Turing machine "
     "for SAT refutes both kinds at once and leaves every theorem standing."),
    ("SEAT · ", "PNP_Normal_Form_Paper_v1_13_0_CC.lean · sha256 98329a52b0e225f17488ad5f2710b7fd284269582877f03730da"
     "94509cf8c415 · 10,358 lines · 687 theorems · 610 pins (258 on no axiom, 352 on the standard axioms) · Lean "
     "4.19.0, core, no import · silent build"),
    ("PAPER · ", "P ≠ NP: Unconditional Proof of the Form by Theorem, the Value by the Act "
     "· Mohammad F. Islam, PhD · Zenodo 10.5281/zenodo.23528399 · ΔM = 0"),
]
fl_all = []
for head, body in FOOT:
    first_w = CW - 48 - tw(head, "s", 700, 12.4)
    words = body.split(" ")
    lines_, cur = [], ""
    limit = first_w
    for w_ in words:
        t = (cur + " " + w_) if cur else w_
        if tw(t, "s", 400, 12.4) <= limit or not cur:
            cur = t
        else:
            lines_.append(cur)
            cur = w_
            limit = CW - 48
    if cur:
        lines_.append(cur)
    fl_all.append((head, lines_))
FH = 34 + sum(len(l) for _, l in fl_all) * 18 + (len(fl_all) - 1) * 6 + 14
rect(0, y, W, FH, NAVY)
yy = y + 34
for head, lines_ in fl_all:
    for j, l in enumerate(lines_):
        if j == 0:
            rich(M + 24, yy, [(head, "s", 700, "#ffd98a"), (l, "s", 400, "#dbe6f1")], 12.4)
        else:
            text(M + 24, yy, l, "s", 400, 12.4, "#dbe6f1")
        yy += 18
    yy += 6
H = int(y + FH)
E[BGI] = f'<rect x="0" y="0" width="{W}" height="{H}" fill="{BG}"/>'

# ---------------------------------------------------------------- fonts: subset + embed
def font_face(key, famname, weight):
    chars = "".join(sorted(USED[key])) + " "
    tt = TTFont(FONTFILE[key])
    opts = subset.Options()
    opts.flavor = "woff2"
    opts.layout_features = ["kern", "liga"]
    opts.name_IDs = ["*"]
    opts.notdef_outline = True
    sub = subset.Subsetter(opts)
    sub.populate(text=chars)
    sub.subset(tt)
    buf = io.BytesIO()
    tt.flavor = "woff2"
    tt.save(buf)
    b64 = base64.b64encode(buf.getvalue()).decode()
    return (f"@font-face{{font-family:'{famname}';font-weight:{weight};font-style:normal;"
            f"src:url(data:font/woff2;base64,{b64}) format('woff2');}}")


faces = [font_face(("s", 400), "PNPSans", 400), font_face(("s", 700), "PNPSans", 700),
         font_face(("m", 400), "PNPMono", 400), font_face(("m", 700), "PNPMono", 700)]

defs = (
    '<defs>'
    f'<marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
    f'<path d="M0,0 L10,5 L0,10 z" fill="{ARROW}"/></marker>'
    f'<marker id="arrR" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
    f'<path d="M0,0 L10,5 L0,10 z" fill="{R}"/></marker>'
    f'<marker id="arrP" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
    f'<path d="M0,0 L10,5 L0,10 z" fill="{V}"/></marker>'
    f'<marker id="arrN" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
    f'<path d="M0,0 L10,5 L0,10 z" fill="{NAVY}"/></marker>'
    f'<style>{"".join(faces)}</style>'
    '</defs>')
title = "P ≠ NP: Form by Theorem, Value by the Act · The Seal · Our Way or No Way · v1.13.0 kernel"
svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" '
       f'role="img" aria-label="{escape(title)}">\n<title>{escape(title)}</title>\n{defs}\n' + "\n".join(E) + "\n</svg>\n")
open(OUT, "w", encoding="utf-8").write(svg)
json.dump({k: list(v) for k, v in CHECKED.items()}, open(SP + "/infog/checked_ids.json", "w"), indent=0)
print("WROTE", OUT, W, H, len(svg), "bytes;", len(CHECKED), "identifiers resolved")
