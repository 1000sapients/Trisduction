import json, sys
K = json.load(open("/tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad/infog/kernel_index.json"))
for n in sys.argv[1:]:
    ds = K["decl"].get(n)
    if not ds:
        print(f"{n:45s} MISSING"); continue
    for full, line, kind in ds:
        print(f"{n:45s} {full:60s} L{line:<6} {kind:8s} {K['cone'].get(full, 'UNPINNED')}")
