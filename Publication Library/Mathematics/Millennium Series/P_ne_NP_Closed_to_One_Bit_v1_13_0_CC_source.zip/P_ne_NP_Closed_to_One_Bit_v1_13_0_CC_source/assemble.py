#!/usr/bin/env python3
"""Assemble the paper source: resolve section, theorem, figure and receipt placeholders in order of appearance.

[[T:key]]  defines the next theorem number and prints "Theorem N"
[[R:key]]  prints "Theorem N" of a defined key
[[N:key]]  prints the bare number N
[[S:key]]  prints "Section N" (or "Appendix X" after \\appendix)
[[SN:key]] prints the bare section number
[[FIG:n]]  places Figure n as a full-width float with its caption
[[RECEIPT:SECONDS]] the measured compile time
Any unresolved placeholder, duplicate definition, unknown key or out-of-order figure raises.
"""
import re
import sys

SRC = ["p1_front.md", "p2_body.md", "p3a_np_degree.md", "p3_residue.md", "p3b_walls.md", "p4_body.md", "p5_end.md"]
CAPTIONS = {
    1: "The seal: what the kernel proves unconditionally, the bit delivered by the act, and every blocker, bound in "
       "one certificate, with the seven unique properties of the bit.",
    2: "Proven unconditionally: SAT $\\in$ NP built, degrees 0 and 1 constructed, the bit isolated, and every route "
       "through it.",
    3: "The uniform walls: every premise shared by all machines, by all algorithm models of SAT or by all records, "
       "barred by theorem.",
    4: "The walls, complete: twenty-two proved in the kernel and seven carried from the Mother Codex, each on its own "
       "quantifier.",
    5: "The bit delivered: the key, the two kinds, the form closed, and every face of the bit giving P $\\neq$ NP.",
    6: "The chain of the seal in one theorem, and the twelve formal gates run in the kernel.",
    7: "Nothing escapes: every route, in any vocabulary, is a delivery of both kinds. Our way or no way.",
    8: "The verdict, with the receipts of the build.",
}


def main(srcdir, out, seconds):
    text = "\n\n".join(open(f"{srcdir}/{f}", encoding="utf-8").read().rstrip("\n") for f in SRC) + "\n"
    # sections
    sec, num, app, letter = {}, 0, False, 0
    for line in text.split("\n"):
        if line.strip() == "\\appendix":
            app = True
            continue
        m = re.match(r"^# (.*)$", line)
        if not m:
            continue
        head = m.group(1)
        if "{-}" in head:
            continue
        k = re.search(r"\{#sec-([a-z0-9]+)\}", head)
        if not k:
            raise SystemExit(f"numbered heading without id: {head}")
        if app:
            sec[k.group(1)] = ("Appendix", chr(ord("A") + letter))
            letter += 1
        else:
            num += 1
            sec[k.group(1)] = ("Section", str(num))
    # theorems, in order of definition
    thm = {}
    for m in re.finditer(r"\[\[T:([A-Za-z0-9_]+)\]\]", text):
        if m.group(1) in thm:
            raise SystemExit(f"theorem defined twice: {m.group(1)}")
        thm[m.group(1)] = len(thm) + 1

    def need(d, k, kind):
        if k not in d:
            raise SystemExit(f"unknown {kind} key: {k}")
        return d[k]

    text = re.sub(r"\[\[T:([A-Za-z0-9_]+)\]\]", lambda m: f"Theorem {thm[m.group(1)]}", text)
    text = re.sub(r"\[\[R:([A-Za-z0-9_]+)\]\]", lambda m: f"Theorem {need(thm, m.group(1), 'theorem')}", text)
    text = re.sub(r"\[\[N:([A-Za-z0-9_]+)\]\]", lambda m: str(need(thm, m.group(1), 'theorem')), text)
    text = re.sub(r"\[\[S:([a-z0-9]+)\]\]", lambda m: " ".join(need(sec, m.group(1), "section")), text)
    text = re.sub(r"\[\[SN:([a-z0-9]+)\]\]", lambda m: need(sec, m.group(1), "section")[1], text)
    figs = [int(n) for n in re.findall(r"\[\[FIG:(\d+)\]\]", text)]
    if figs != list(range(1, 9)):
        raise SystemExit(f"figures out of order: {figs}")

    def fig(m):
        n = int(m.group(1))
        return ("\\begin{figure*}[tp]\n\\centering\n"
                f"\\includegraphics[width=\\textwidth]{{figs/P_ne_NP_Figure_{n}_v1_13_0_CC.pdf}}\\\\[5pt]\n"
                "\\begin{minipage}{\\textwidth}\\footnotesize{\\color{deep}\\textbf{Figure " + str(n) + "}}\\ \\textbar\\ "
                + CAPTIONS[n] + "\\end{minipage}\n\\end{figure*}")
    text = re.sub(r"\[\[FIG:(\d+)\]\]", fig, text)
    text = text.replace("[[RECEIPT:SECONDS]]", seconds)
    # the four short sentences never break across a line: grouped in math, glued by no-break spaces in the front matter
    for a in (r"\mathbf{P} \neq \mathbf{NP}", r"\mathrm{SAT} \notin \mathbf{P}", r"\mathrm{SAT} \in \mathbf{NP}",
              r"\mathbf{P} = \mathbf{NP}"):
        text = text.replace("{" + a + "}", a).replace(a, "{" + a + "}")
    front, sep, rest = text.partition("\n---\n")
    for a in ("P ≠ NP", "SAT ∉ P", "SAT ∈ NP", "P = NP", "in Core Lean 4"):
        front = front.replace(a, a.replace(" ", "\u00a0"))
    text = front + sep + rest
    left = re.findall(r"\[\[[A-Z]+:[^\]]*\]\]", text)
    if left:
        raise SystemExit(f"unresolved: {left[:5]}")
    text = re.sub(r"\n(# [^\n]+)\n", lambda m: "\n\\Needspace*{6\\baselineskip}\n\n" + m.group(1) + "\n", text)
    open(out, "w", encoding="utf-8").write(text)
    print(f"sections {num} + appendices {letter}; theorems {len(thm)}; figures {len(figs)}")
    for k, v in sec.items():
        print(f"  {v[0]} {v[1]:>2}  {k}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
