import sys, pymupdf
doc = pymupdf.open(sys.argv[1])
L, R, T, B = 61.2, 612 - 61.2, 61.2, 792 - 61.2
PUNCT = set(",.-;:’”)‘“(—–!?'\"·")
bad, protr, footer_low, maxover = [], 0, 0, 0.0
for pno, page in enumerate(doc, 1):
    d = page.get_text("rawdict")
    for b in d["blocks"]:
        if b.get("type") != 0:
            x0, y0, x1, y1 = b["bbox"]
            if x0 < L - 0.5 or x1 > R + 0.5 or y0 < T - 0.5 or y1 > B + 0.5:
                bad.append((pno, "IMAGE", [round(v, 1) for v in b["bbox"]]))
            continue
        for ln in b["lines"]:
            for sp in ln["spans"]:
                for ch in sp["chars"]:
                    cx0, cy0, cx1, cy1 = ch["bbox"]
                    c = ch["c"]
                    if not c.strip():
                        continue
                    over = max(L - cx0, cx1 - R, T - cy0 - 2.4)
                    if over > 0.6:
                        if c in PUNCT and over <= 2.2:
                            protr += 1
                            continue
                        maxover = max(maxover, over)
                        bad.append((pno, c, round(cx0, 1), round(cx1, 1), round(cy0, 1), round(over, 2),
                                    "".join(x["c"] for x in sp["chars"])[:50]))
                    if cy1 > B + 0.6:
                        footer_low = max(footer_low, cy1)
    for dr in page.get_drawings():
        x0, y0, x1, y1 = dr["rect"]
        if x0 < L - 0.6 or x1 > R + 0.6 or y0 < T - 0.6:
            bad.append((pno, "DRAW", [round(v, 1) for v in dr["rect"]]))
print(f"pages {len(doc)}; margin protrusion of punctuation (microtype, <= 2.2pt): {protr}; "
      f"other glyphs, images or rules outside the text block: {len(bad)}; lowest footer glyph {footer_low:.1f}/792")
for x in bad[:40]:
    print(x)
