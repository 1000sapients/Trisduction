#!/usr/bin/env python3
"""Cut the v1.13.0 infographic into eight page-sized figures for the paper.

Each figure is a self-contained SVG (subset fonts embedded) drawn at 1100 px width, so that at the paper's text width
(6.8 in) the smallest type prints near 5 pt. Every monospace identifier is resolved against the kernel index and colored
by its pinned cone: green = theorem on no axiom, blue = theorem on Lean's standard axioms, slate = definition.
"""
import base64, io, json, re, sys
from html import escape
from PIL import ImageFont
from fontTools import subset
from fontTools.ttLib import TTFont

SP = "/tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad"
OUTDIR = SP + "/paper113/figs"
IDX = json.load(open(SP + "/infog/kernel_index.json"))
FD = "/usr/share/fonts/truetype/dejavu/"
FONTFILE = {("s", 400): FD + "DejaVuSans.ttf", ("s", 700): FD + "DejaVuSans-Bold.ttf",
            ("m", 400): FD + "DejaVuSansMono.ttf", ("m", 700): FD + "DejaVuSansMono-Bold.ttf"}
FAMILY = {"s": "PNPSans, 'DejaVu Sans', Verdana, Arial, sans-serif",
          "m": "PNPMono, 'DejaVu Sans Mono', Menlo, Consolas, monospace"}
_PIL = {k: ImageFont.truetype(v, 100) for k, v in FONTFILE.items()}

NAVY, NAVY2, NAVY_ST, PILL_TX, SUB = "#0e2a47", "#1d4066", "#3f6186", "#dcebfb", "#c8d8e8"
BG, INK, BODY, GREY, ARROW, LINE = "#f7f9fa", "#10222e", "#24333d", "#5a6a76", "#33475b", "#c3d2dc"
G, G_T, G_D = "#177e6c", "#e7f4f0", "#0f5c4e"
B, B_T, B_D = "#2f5aa8", "#e9f0fb", "#1e447c"
R, R_T, R_D = "#b3261e", "#fdecea", "#7f1d17"
A, A_T, A_D = "#b7791f", "#fdf3e0", "#7a4a12"
V, V_T, V_2, V_D = "#5b4bc4", "#f1edfd", "#d9d2f7", "#3c3550"
SLATE, WHITE, GOLD = "#33566e", "#ffffff", "#ffd98a"

W, M = 1100, 22
CW = W - 2 * M
E, USED = [], {}
CHECKED = {}
PREF = ["PNP.TM.", "PNP.LOCALITY.", "PNP.NORMALFORM."]
NB = " "


def resolve(name):
    ds = IDX["decl"].get(name)
    if not ds:
        raise SystemExit("NOT A DECLARATION OF v1.13.0: " + name)
    pick = ds[0]
    if len(ds) > 1:
        for p in PREF:
            hit = [d for d in ds if d[0].startswith(p)]
            if hit:
                pick = hit[0]
                break
    full, line_, kind = pick
    cone = IDX["cone"].get(full)
    CHECKED[name] = (full, kind, cone)
    return full, kind, cone


def id_color(name):
    full, kind, cone = resolve(name)
    if kind != "theorem":
        return SLATE
    if cone is None:
        raise SystemExit("THEOREM WITHOUT A PINNED CONE: " + full)
    return G if cone == "∅" else B


def tw(s, fam="s", wt=400, size=13.0):
    return _PIL[(fam, wt)].getlength(s) * size / 100.0


def glue(s):
    s = re.sub(r" (≠|∉|∈|≥|=|\+|→) ", lambda m: NB + m.group(1) + NB, s)
    s = re.sub(r"(degree|degrees|Parts|Part|seed|grade|Figure|Section|Theorem) (\d)",
               lambda m: m.group(1) + NB + m.group(2), s)
    return s


def wrap(s, maxw, fam="s", wt=400, size=13.0):
    words, lines, cur = glue(s).split(" "), [], ""
    for w_ in words:
        t = (cur + " " + w_) if cur else w_
        if tw(t, fam, wt, size) <= maxw or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = w_
    if cur:
        lines.append(cur)
    for l in lines:
        if tw(l, fam, wt, size) > maxw + 0.5:
            raise SystemExit(f"UNWRAPPABLE LINE ({tw(l, fam, wt, size):.0f} > {maxw:.0f}): {l}")
    return lines


def id_lines(ids, maxw, size=11.2, wt=400):
    sep = " · "
    lines, cur, curw = [], [], 0.0
    for n in ids:
        col = id_color(n)
        wpiece = tw(n, "m", wt, size)
        if wpiece > maxw + 0.5:
            raise SystemExit(f"IDENTIFIER WIDER THAN ITS BOX: {n}")
        wsep = tw(sep, "m", wt, size) if cur else 0.0
        if cur and curw + wsep + wpiece > maxw:
            lines.append(cur)
            cur, curw, wsep = [], 0.0, 0.0
        if cur:
            cur.append((sep, GREY))
        cur.append((n, col))
        curw += wsep + wpiece
    if cur:
        lines.append(cur)
    return lines


def note(fam, wt, s):
    USED.setdefault((fam, wt), set()).update(s)


def rect(x, y, w, h, fill, stroke="none", sw=0, rx=0, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    E.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx}" fill="{fill}" '
             f'stroke="{stroke}" stroke-width="{sw}"{d}/>')


def line(x1, y1, x2, y2, stroke=ARROW, sw=2, marker=None):
    mk = f' marker-end="url(#{marker})"' if marker else ""
    E.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{stroke}" stroke-width="{sw}"{mk}/>')


def path(d, fill="none", stroke="none", sw=0, marker=None):
    mk = f' marker-end="url(#{marker})"' if marker else ""
    E.append(f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{mk}/>')


def text(x, y, s, fam="s", wt=400, size=13.0, fill=BODY, anchor="start", ls=None):
    note(fam, wt, s)
    l = f' letter-spacing="{ls}"' if ls else ""
    E.append(f'<text x="{x:.1f}" y="{y:.1f}" font-family="{FAMILY[fam]}" font-size="{size}" font-weight="{wt}" '
             f'fill="{fill}" text-anchor="{anchor}"{l}>{escape(s)}</text>')


def rich(x, y, runs, size=13.0, anchor="start"):
    parts = []
    for s, fam, wt, fill in runs:
        note(fam, wt, s)
        parts.append(f'<tspan font-family="{FAMILY[fam]}" font-weight="{wt}" fill="{fill}">{escape(s)}</tspan>')
    E.append(f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" xml:space="preserve">'
             f'{"".join(parts)}</text>')


def ids_draw(x, y, lines, size=11.2, lh=15.2, wt=400, anchor="start"):
    for i, ln in enumerate(lines):
        rich(x, y + i * lh, [(s, "m", wt, c) for s, c in ln], size=size, anchor=anchor)


def pill(cx, y, label, fill, tx, size=10.0, h=20, anchor="middle"):
    wpx = tw(label, "s", 700, size) + 20 + 0.4 * len(label)
    x = cx - wpx / 2 if anchor == "middle" else cx
    rect(x, y, wpx, h, fill, rx=h / 2)
    text(x + wpx / 2, y + h / 2 + size * 0.36, label, "s", 700, size, tx, "middle", ls="0.4")
    return wpx


class Block:
    def __init__(self, h, fn):
        self.h, self.fn = h, fn

    def draw(self, x, y, h=None):
        self.fn(x, y, self.h if h is None else h)


def card(w, title, body, ids, accent, fill=WHITE, tcol=INK, icon=None, tsize=13.0, bsize=12.4, lh=16.6,
         isize=11.0, ilh=15.0, stroke=None, kicker=None, kcol=None):
    pad_l, pad_r, top = 16, 12, 11
    tx_w = w - pad_l - pad_r - (20 if icon else 0)
    tl = wrap(title, tx_w, "s", 700, tsize)
    bl = wrap(body, w - pad_l - pad_r, "s", 400, bsize) if body else []
    il = id_lines(ids, w - pad_l - pad_r, isize) if ids else []
    kl = 1 if kicker else 0
    h = top + kl * 15 + len(tl) * (tsize + 4) + (3 + len(bl) * lh if bl else 0) + (5 + len(il) * ilh if il else 0) + 9

    def fn(x, y, hh):
        rect(x, y, w, hh, fill, stroke or LINE, 1, rx=7)
        rect(x, y, 5, hh, accent)
        cy = y + top
        if kicker:
            text(x + pad_l, cy + 9, kicker, "s", 700, 9.6, kcol or accent, ls="0.7")
            cy += 15
        ix = x + pad_l
        if icon:
            text(ix, cy + tsize - 1, icon, "s", 700, tsize + 1, accent)
            ix += 20
        for i, t in enumerate(tl):
            text(ix, cy + tsize - 1 + i * (tsize + 4), t, "s", 700, tsize, tcol)
        cy += len(tl) * (tsize + 4)
        if bl:
            cy += 3
            for i, t in enumerate(bl):
                text(x + pad_l, cy + bsize - 1 + i * lh, t, "s", 400, bsize, BODY)
            cy += len(bl) * lh
        if il:
            cy += 5
            ids_draw(x + pad_l, cy + isize - 1, il, isize, ilh)

    return Block(h, fn)


def grid(cards, cols, x, y, w, gap=12, vgap=12, draw=True):
    cw = (w - gap * (cols - 1)) / cols
    rows = [cards[i:i + cols] for i in range(0, len(cards), cols)]
    cy = y
    for r in rows:
        rh = max(c(cw).h for c in r)
        for j, c in enumerate(r):
            if draw:
                c(cw).draw(x + j * (cw + gap), cy, rh)
        cy += rh + vgap
    return cy - vgap - y


def band(y, label, right, color, tint, h_fn, draw_fn, pad=14, hh=40):
    ch = h_fn()
    total = hh + pad + ch + pad
    rect(M, y, CW, total, tint, color, 1.4, rx=9)
    rect(M, y, CW, hh, color, rx=9)
    rect(M, y + hh - 9, CW, 9, color)
    lsz = 16.0
    while tw(label, "s", 700, lsz) + 0.5 * len(label) + (tw(right, "m", 700, 11) + 40 if right else 0) > CW - 36 \
            and lsz > 11:
        lsz -= 0.5
    text(M + 18, y + 26, label, "s", 700, lsz, WHITE, ls="0.5")
    if right:
        text(W - M - 16, y + 25.5, right, "m", 700, 11, WHITE, "end")
    draw_fn(y + hh + pad)
    return total


def panel_title(x, y, w, title, col, size=12.2, draw=True):
    tl = wrap(title, w - 0.5 * len(title), "s", 700, size)
    if draw:
        for j, l in enumerate(tl):
            text(x, y + 20 + j * 15.5, l, "s", 700, size, col, ls="0.5")
    return 30 + (len(tl) - 1) * 15.5


def fig_header(num, title):
    h = 54
    rect(0, 0, W, h, NAVY)
    rect(0, h - 4, W, 4, V)
    text(M, 22, f"FIGURE {num}", "s", 700, 11, GOLD, ls="1.2")
    text(M, 42, title, "s", 700, 17, WHITE, ls="0.4")
    rt = "P ≠ NP: FORM BY THEOREM, VALUE BY THE ACT · KERNEL v1.13.0 · EVERY NAME CHECKED"
    text(W - M, 22, rt, "s", 400, 10, SUB, "end", ls="0.6")
    return h


def legend(y):
    h = 30
    rect(M, y, CW, h, WHITE, LINE, 1, rx=7)
    lx = M + 14
    text(lx, y + 19.5, "READING", "s", 700, 10.4, INK, ls="0.8")
    lx += tw("READING", "s", 700, 10.4) + 22
    for col, lab in [(G, "theorem on no axiom at all"), (B, "theorem on Lean's standard axioms"),
                     (SLATE, "definition")]:
        rect(lx, y + 9, 12, 12, col, rx=2)
        text(lx + 18, y + 19.5, lab, "s", 400, 10.6, BODY)
        lx += 18 + tw(lab, "s", 400, 10.6) + 22
    return h


# ================================================================ CONTENT (shared with the poster)
TILES = [
    ("I · PROVEN UNCONDITIONALLY", G, G_T,
     "The form: SAT ∈ NP built, degrees 0 and 1 constructed, the bit isolated, every route through it.",
     "THEOREM", ["proven_unconditionally"]),
    ("II · THE BIT DELIVERED", A, A_T,
     "Supplied by the act. Two kinds, one bit: the formal cargo and the physical witness, each giving P ≠ NP.",
     "PREMISE · THE ACT", ["the_delivery"]),
    ("III · THE WALLS", R, R_T,
     "Every blocker, old and new: twenty-two proved in the kernel, seven carried from the Mother Codex.",
     "THEOREM IN THE KERNEL", ["the_blocks"]),
    ("THE SEAL", NAVY, "#e6edf5",
     "Eight links in one theorem, nothing before the colon. The tuple does not compress: every face keeps its grade.",
     "ONE CERTIFICATE", ["the_block_chain"]),
    ("OUR WAY OR NO WAY", V, V_T,
     "Every so-called other way to P ≠ NP is our way in different vocabulary: it delivers both kinds, and if the bit "
     "failed it would fail with it.", "THEOREM", ["our_way_or_no_way", "the_capstone"]),
]
SEVEN_U = [
    ("NECESSARY",
     "SAT ∉ P cannot hold without the transfer, and with the hardness half cited neither can P ≠ NP. Whatever "
     "proves either proves the bit first.", ["pnp_normal_form_turing", "form_closed"]),
    ("SUFFICIENT",
     "The bit alone, the one explicit premise, gives SAT ∉ P in one step and P ≠ NP with nothing cited.",
     ["sat_not_in_P_of_the_act", "p_ne_np_of_the_one_bit"]),
    ("IRREDUCIBLE",
     "Nothing the two worlds share supplies it: no premise of every machine, of every SAT model or of every record. "
     "The bit is keyed and seatless.", ["residue_is_keyed", "sat_bit_is_keyed", "no_uniform_answer", "seatless_lock"]),
    ("MANDATORY",
     "Every route from any premise delivers the bit. Every exit is the posit, and the posit is every exit.",
     ["tmsat_every_route_passes_the_bit", "every_exit_is_the_posit", "the_posit_is_every_exit"]),
    ("FUTURE-PROOF",
     "Any future proof, from any premise, arrives as this bit in both kinds. Any two certificates are one object, "
     "any two proofs one proof.", ["every_route_is_both_kinds", "certificate_unique"]),
    ("NO OTHER PROOF",
     "Every so-called other way to P ≠ NP is our way in different vocabulary: it delivers both kinds, and if the bit "
     "failed it would fail with it.", ["our_way_or_no_way", "every_delivery_is_both_kinds", "nothing_escapes"]),
    ("TWO KINDS OF ACT, BOTH SUPPLIED",
     "The formal cargo and the physical witness: one bit, each delivering P ≠ NP, both supplied by the act.",
     ["the_two_kinds_are_one_bit", "both_kinds_deliver", "formal_kind_delivers", "physical_kind_delivers"]),
]
P_CARDS = [
    ("SAT ∈ NP, BUILT IN THE KERNEL",
     "A 5,120-state one-tape verifier over nineteen tape symbols accepts every satisfiable formula, given its "
     "certificate, within 5000·n⁴ + 5000 steps, and accepts no unsatisfiable one. The membership half of Cook and "
     "Levin is a theorem.", ["satLang_in_NP", "verifier_sound", "verifier_complete", "vtime_le"]),
    ("DEGREE 0 · CONSTANT TIME FAILS",
     "No Turing machine decides SAT within a constant budget. Locality is proved once for every machine, and a "
     "computed witness defeats every decider at every constant.",
     ["sat_not_in_P_at_degree_zero", "diagonal_target_at_zero", "witness0_spec", "run_local", "prefix_forces_time"]),
    ("DEGREE 1 · LINEAR TIME FAILS",
     "No one-tape Turing machine decides SAT within c·n + c steps, at any c: Hennie's crossing sequences, run on "
     "SAT's own fooling family.",
     ["sat_not_in_P_at_degree_one", "diagonal_target_at_one", "cut_paste", "fool_cs_inj", "fool_long"]),
    ("THE REAL-PART SEPARATION",
     "SAT ∈ NP, SAT outside constant and linear one-tape time, and the bit equal to the Diagonal Target from "
     "degree 2, in one theorem with nothing before the colon.",
     ["unconditional_real_part_separation", "the_final_witness_capstone"]),
    ("THE NORMAL FORM",
     "Over every Turing machine, SAT ∉ P is exactly one implication: least escape carried from the record of the "
     "SAT machine to the machine.",
     ["pnp_normal_form_turing", "sep_tmsat_iff", "sep_normal_form", "coincidence_normal_form"]),
    ("THE RECORD CLOSES",
     "The record answers every run wrongly, so it has least escape on no axiom. At TMSAT it is a fixed point "
     "carrying separation, self-recursion and a fertile machine.",
     ["record_has_least_escape", "tmsat_record_has_least_escape", "the_record_closes_at_tmsat",
      "record_locus_fixed_point_unconditional"]),
    ("THE BIT ON NO AXIOM",
     "The transfer in its constructive form, landing on “no decider escapes”, is exactly SAT ∉ P on an empty cone: "
     "no propext, no choice, no quotient.", ["racomp_cargo_iff_not_inP", "every_route_spends_the_bit_free"]),
    ("EVERY ROUTE PASSES THE BIT",
     "Any proof of SAT ∉ P, from any premise, is a proof of the bit. Every exit is the posit and the posit every "
     "exit. One certificate, one proof.",
     ["tmsat_every_route_passes_the_bit", "every_exit_is_the_posit", "the_posit_is_every_exit", "certificate_unique"]),
    ("TEN FACES, ONE PROPOSITION",
     "SAT ∉ P, the separation at SAT, Sep, closure, self-recursion, record coincidence, the fertile machine, the "
     "selected machine, the physical witness and the degree tail: one bit.",
     ["ten_faces_of_the_one_bit", "face_formal", "face_physical", "face_diagonal", "face_closure"]),
    ("THE RESIDUE, EXACT",
     "The bit is the Diagonal Target at every degree k ≥ 2, and equally the tail from any degree m ≥ 1. The ladder "
     "may be cut anywhere.",
     ["the_inequality_from_degree_two", "barrier_from_degree_two", "gate_7_dual", "the_inequality_iff_cofinal"]),
    ("THE BIT DELIVERS P ≠ NP",
     "With SAT ∈ NP built, the bit and every one of its faces give P ≠ NP with nothing cited.",
     ["p_ne_np_of_the_one_bit", "barrier_implies_p_ne_np", "the_one_bit_delivers_p_ne_np_unconditional"]),
    ("THE MODEL, BUILT",
     "Finite-control Turing machines on one two-way tape, running time as the first halting step, a binary encoding "
     "with its decoder proved inverse, SAT as a language, P and NP as definitions.",
     ["TM", "run", "firstHalt", "time_least", "decode_encode", "satLang", "InP", "InNP", "P_ne_NP"]),
]
WALLS = [
    ("KEYLESS WALL", "Bars every premise true of every machine.", ["keyless_forces_nothing", "the_wall_stands"]),
    ("SAT-KEYLESS WALL", "Bars every premise shared by every algorithm model of SAT.", ["sat_keyless_forces_nothing"]),
    ("NO UNIFORM ANSWER", "The kernel's relativization wall. Bars every argument uniform across the algorithm models "
     "of SAT, black-box self-reference included.", ["no_uniform_answer"]),
    ("RECORD WALL", "Bars every principle true of every record.", ["no_record_principle_decides",
                                                                 "record_decides_nothing"]),
    ("THE FINITE RECORD", "Bars the record of either SAT world: both records close, one world escapes.",
     ["sat_record_decides_nothing"]),
    ("STOCKS OF STOPS", "Bars every stock of stops, finite or infinite: each stop certifies its own pair.",
     ["tmsat_no_record_decides", "stage1_is_local"]),
    ("BLACK-BOX SEARCH", "Bars every fixed test list: over 2^N candidates none is shorter than 2^N.",
     ["black_box_no_savings", "missing_object_is_keyed"]),
    ("SELF-VERIFICATION", "Bars self-certification: a statement self-verifies exactly when it is true.",
     ["self_verifying_iff_true"]),
    ("THE RECORD'S SELF-RECURSION", "Bars its transfer: the stage record is self-recursive, the stage world is not.",
     ["record_self_recursion_does_not_transfer"]),
    ("THE VACANT SEAT", "Bars every fixed point of complementation on the bit.", ["locus_vanishes", "seatless_lock"]),
    ("THE CROSSING CEILING", "Bars the degree-1 count at degree 2: it certifies no more than n² + 1, on every pad.",
     ["count_falls_short", "pigeon_ceiling", "count_ceiling"]),
    ("THE SELF-TABLEAU WALL", "Bars a diagonal formula carrying its own budgeted run: the budget outgrows the formula "
     "at every k ≥ 1.", ["self_tableau_block"]),
    ("NO LANGUAGE IS ITS OWN COMPLEMENT", "Mother II.1. Bars every residence argument: sixteen languages, eight "
     "two-cycles, no fixed set.", ["no_language_is_its_complement", "sixteen_languages_eight_two_cycles"]),
    ("THE SIGN-BLIND SQUARE", "Mother II.2. Bars every squared invariant as a reader of the truth-sign.",
     ["square_is_sign_blind"]),
    ("THE DIAGONAL BLINDSPOT", "Mother III.1. Bars every catalogue that certifies its own completeness.",
     ["the_diagonal_blindspot"]),
    ("NO PHYSICAL DISCHARGE BUT THE BIT", "Bars every physical argument that does not prove the bit.",
     ["physical_discharge_is_the_bit"]),
    ("THE BRIDGE IS THE CONJECTURE", "Bars every bridge from the physical asymmetry smaller than P ≠ NP.",
     ["bridge_premise_is_the_conjecture"]),
    ("NO TOTAL WALL", "Bars a wall against every premise at once: the bit forces itself.", ["no_total_wall"]),
    ("THE SHUT DOOR IS THE COLLAPSE", "Bars the proclamation that every road is shut: that proclamation is P = NP.",
     ["shut_door_is_collapse", "total_wall_iff_negation"]),
    ("BOTH FATES ARE RESOLUTIONS", "Bars either fate-pronouncement as anything but a resolution.",
     ["both_fates_are_resolutions"]),
    ("A BLOCK NEEDS AN OUTSIDE", "Bars every flip read off the record alone: no record-preserving involution flips "
     "a target the record determines.", ["block_needs_an_outside"]),
    ("THE ILLEGAL DEMAND", "Bars every demand for P ≠ NP that denies the bit: the premise is refuted.",
     ["demand_for_p_ne_np_without_bit_illegal", "demand_for_p_ne_np_without_bit_illegal_free"]),
]
MOTHER = [
    ("I.1 · RELATIVIZATION", "Relativizing arguments", "Baker, Gill and Solovay 1975"),
    ("I.2 · NATURAL PROOFS", "Constructive, large lower-bound proofs", "Razborov and Rudich 1997"),
    ("I.3 · ALGEBRIZATION", "Arithmetization with oracle access", "Aaronson and Wigderson 2009"),
    ("I.4 · LOCALITY", "Local reductions and hardness magnification", "The locality barrier, 2020 and 2022"),
    ("I.5 · THE COUSIN WING", "Occurrence obstructions, rank methods, algebraic natural proofs",
     "Bürgisser, Ikenmeyer and Panova 2016, with kin"),
    ("I.6 · PROOF SYSTEMS", "Lower-bound proofs inside named fragments of bounded arithmetic", "Razborov 1995"),
    ("II.3 TO II.8", "Floor and arrow, misattribution, every metatheory rung, access, jurisdiction, soundness",
     "ABSOLUTE-PNP-BARRIERS-01, JURISDICTION-BARRIER-01"),
]
KEY = [("THE WALL STANDS", "A premise every world shares forces nothing.", ["the_wall_stands"]),
       ("THE KEY FORCES", "A reading forces what it reads.", ["the_key_forces"]),
       ("THE KEY IS KEYED", "Not shared by every world: the wall is passed, not broken.", ["the_key_is_keyed"]),
       ("THE KEY IS THE BIT", "At TMSAT the reading is exactly the bit.", ["the_key_at_the_row"]),
       ("THE KEY DELIVERS", "The key at TMSAT gives P ≠ NP.", ["the_key_delivers"])]
KINDS = [("KIND 1 · THE FORMAL CARGO", "The bit as a type: the record's closure carried to the machine.",
          ["cargo_arrives", "formal_kind_delivers", "face_formal"]),
         ("KIND 2 · THE PHYSICAL WITNESS", "The bit carried by a witness holding the Diagonal Target in its own field.",
          ["witness_closes", "physical_kind_delivers", "face_physical"])]
FORM = [("P ≠ NP AND THE BIT ARE ONE PROPOSITION", "and so is every face of the bit.",
         ["millennium_sentence_iff_one_bit_hNP_free", "the_proof"]),
        ("THE DENIAL IS THE BIT'S DENIAL", "P = NP is exactly the failure of the transfer.",
         ["denial_is_the_bits_denial"]),
        ("P ≠ NP IS THE BARRIER", "the Diagonal Target from degree 2, under the hardness half alone.",
         ["p_ne_np_iff_barrier"]),
        ("EVERY ROUTE TO P ≠ NP SPENDS THE BIT", "on an empty cone.", ["every_pnp_route_spends_the_bit_free"]),
        ("A PREMISE THAT GIVES P ≠ NP WHILE THE BIT FAILS IS FALSE", "",
         ["form_closed", "demand_for_p_ne_np_without_bit_illegal_free"]),
        ("THE QUESTION IS CLOSED TO ONE BIT", "", ["question_closed_to_one_bit"])]
FACES = [("THE BIT", ["p_ne_np_of_the_one_bit"]),
         ("THE FORMAL CARGO · THE PHYSICAL WITNESS", ["both_kinds_deliver"]),
         ("THE KEY AT TMSAT", ["the_key_delivers"]),
         ("THE BARRIER", ["barrier_implies_p_ne_np"]),
         ("THE SEPARATION AT SAT", ["sat_separates_gives_p_ne_np"]),
         ("THE DIAGONAL TARGET · THE FERTILE MACHINE · THE SELECTED MACHINE · THE DEGREE TAIL FROM 2",
          ["the_one_bit_delivers_p_ne_np_unconditional"])]
CHAIN = [
    ("PROVEN UNCONDITIONALLY", "SAT ∈ NP, degrees 0 and 1, the bit as SAT ∉ P, every route through it, the residue "
     "from degree 2.", ["proven_unconditionally"]),
    ("THE DELIVERY", "The key at TMSAT is the bit; the key, the bit and both kinds give P ≠ NP.", ["the_delivery"]),
    ("THE FORM CLOSED", "P ≠ NP is the bit; every route to it spends the bit; the one refuter denies it.",
     ["form_closed"]),
    ("THE BLOCKS", "Keyless, record, SAT-keyless and uniform walls, the vacant seat, the crossing ceiling, the "
     "self-tableau wall.", ["the_blocks"]),
    ("THE KEY PASSES", "The reading forces what it reads, and it is no keyless premise.", ["the_key_passes"]),
    ("NO TOTAL WALL", "No wall bars every premise: the bit forces itself.", ["no_total_wall"]),
    ("THE SHUT DOOR IS THE COLLAPSE", "Barring every true route to the bit is asserting P = NP.",
     ["shut_door_is_collapse"]),
    ("THE ROWS AND THE BRIDGE", "The bridge is the conjecture; every physical discharge is the bit; the type-indexed "
     "rows hold.", ["bridge_premise_is_the_conjecture", "physical_discharge_is_the_bit",
                    "no_language_is_its_complement", "square_is_sign_blind", "the_diagonal_blindspot",
                    "both_fates_are_resolutions"]),
]
GATES = [("SREP", "The form stands with no hypothesis.", "gate_1_srep"),
         ("REG", "Ten reading contexts, one proposition.", "gate_2_reg"),
         ("SGEG", "No face drifts: formal, physical, diagonal, separation and closure are each the bit.",
          "gate_3_sgeg"),
         ("CAUSAL", "The native involution fixes nothing, on a bit or on a language.", "gate_4_causal"),
         ("MIG", "Two machines whose records both close split on closure: the record fixes no residence.",
          "gate_5_mig"),
         ("PTB", "The fixed-point reading belongs to the chosen reflection, never to the bit.", "gate_6_ptb"),
         ("DUAL", "The bit is the tail of the Diagonal Target from any degree m ≥ 1.", "gate_7_dual"),
         ("CSCG", "The bit extends the proved degrees 0 and 1.", "gate_8_cscg"),
         ("CSEG", "No join stands above its weakest face; every face keeps its grade.", "gate_9_cseg"),
         ("MTA", "A squared scalar reads a value and its reflection alike.", "gate_10_mta"),
         ("OMA", "The supply enters as the delivery's hypothesis, keyed, never keyless.", "gate_11_oma"),
         ("ADEG", "Every transport is typed: the bridge is the conjecture, the physical discharge the bit.",
          "gate_12_adeg")]
CAP = [("THE RECORD CLOSES AT TMSAT", "", ["the_record_closes_at_tmsat"]),
       ("WHAT IT LEAVES UNDECIDED IS THE BIT", "", ["the_undecided_is_the_bit"]),
       ("AT TMSAT, “NOTHING IS OUTSIDE THE RECORD” IS THE BIT ITSELF", "",
        ["nothing_outside_the_record_is_the_bit"]),
       ("A BLOCK NEEDS AN OUTSIDE", "If the target is a function of the record, no record-preserving involution "
        "flips it.", ["block_needs_an_outside"]),
       ("THE OUTSIDE IS THE SUPPLY", "In its two kinds: the formal cargo and the physical witness, one bit.",
        ["the_outside_is_the_supply"]),
       ("EVERY ROUTE IS BOTH KINDS", "Every route to SAT ∉ P, in any vocabulary, delivers both kinds, nothing cited.",
        ["every_route_is_both_kinds"]),
       ("EVERY DELIVERY IS BOTH KINDS", "Every route to P ≠ NP, in any vocabulary, delivers both kinds, the "
        "hardness half of Cook and Levin cited.", ["every_delivery_is_both_kinds"]),
       ("NOTHING ESCAPES", "The Part bound in one theorem, nothing before the colon.", ["nothing_escapes"])]
SEALROWS = [("FORM", "P versus NP is one bit; every route passes it; the residue is the Diagonal Target from degree 2.",
             "THEOREM", G),
            ("WALLS", "Twenty-two walls proved in the kernel, seven carried from the Mother Codex, each on its "
                      "quantifier.", "THEOREM IN THE KERNEL", R),
            ("VALUE", "The bit, supplied by the act and delivered twice, giving P ≠ NP.", "PREMISE · THE ACT", A),
            ("TUPLE", "The three faces read side by side.", "DOES NOT COMPRESS", NAVY)]
COMPOSITE = [("FACE 1 · THE PHYSICAL FIELD", "SEALED", "Its formal shadow is the bit.",
              ["physical_discharge_is_the_bit"], G),
             ("FACE 2 · THE GEOMETRIC SHAPE", "SEALED", "No fixed set; complementation fixes nothing.",
              ["no_language_is_its_complement", "locus_vanishes"], G),
             ("FACE 3 · THE FORMAL STRING", "[Ø₀] SEALED HALT", "Proved to the bit; the bit delivered by the act.",
              ["the_block_chain", "the_capstone"], NAVY),
             ("BESIDE · THE NAMED INFLATIONS", "BROKEN", "Permanent immunity and final completeness.",
              ["both_fates_are_resolutions", "the_diagonal_blindspot"], R),
             ("BESIDE · THE COINCIDENCE CLAIM P = NP", "BROKEN", "Its one road is SAT ∈ P.",
              ["refusal_collapse", "refuter_denies_the_sentence"], R)]
NOTMEAN = [("“A proof is waiting.”", "A true route to the bit is the bit itself.", ["refusal_waiting"]),
           ("“No proof can ever exist.”", "At P versus NP that sentence is P = NP.",
            ["refusal_no_proof_at_the_bit", "shut_door_is_collapse"]),
           ("“The file is incomplete.”", "The form is closed by theorem; every wall is typed on its quantifier.",
            ["the_block_chain", "the_formal_run"]),
           ("“Try the walled methods again.”", "Each wall binds every method its quantifier covers, born or unborn.",
            ["the_blocks", "the_attempt_at_two"])]
FOOT = [
    ("WHAT IS PROVED · ", "every theorem of Parts A to X, on no axiom or on Lean's standard axioms: the form closed to "
     "one bit on real Turing machines deciding real SAT; SAT ∈ NP built; degrees 0 and 1 constructed; twenty-two walls "
     "at theorem grade; the twelve gates passed; our way or no way."),
    ("WHAT IS CITED · ", "the NP-hardness half of Cook and Levin, SATHard, a hypothesis wherever it is used; the "
     "seven Mother Codex walls, at the grades their authors proved them."),
    ("WHAT IS SUPPLIED · ", "the value, the one bit, by the act at premise grade: printed as a type, assumed "
     "nowhere, delivered twice, by the formal cargo and by the physical witness."),
    ("SEAT · ", "PNP_Normal_Form_Paper_v1_13_0_CC.lean · sha256 98329a52b0e225f17488ad5f2710b7fd284269582877f03730da"
     "94509cf8c415 · 10,358 lines · 687 theorems · 610 pins (258 on no axiom, 352 on the standard axioms) · Lean "
     "4.19.0, core, no import · silent build"),
]


# ================================================================ FIGURE BODIES
def fig_seal(y):
    text(M, y + 12, "THE SEAL  ·  PROVEN UNCONDITIONALLY  +  THE BIT DELIVERED  +  EVERY BLOCKER, OLD AND NEW", "s",
         700, 12.6, INK, ls="0.5")
    y += 24
    OPW = 30
    TW_ = (CW - 4 * OPW) / 5
    tl = [wrap(t[0], TW_ - 16, "s", 700, 11.6) for t in TILES]
    bl = [wrap(t[3], TW_ - 22, "s", 400, 12.0) for t in TILES]
    il = [id_lines(t[5], TW_ - 16, 10.6) for t in TILES]
    hh = 12 + max(len(t) for t in tl) * 15 + 6
    TH = hh + 12 + max(len(b) for b in bl) * 16.2 + 10 + 20 + 10 + max(len(i) for i in il) * 14.4 + 10
    for k, (title, col, tint, body, grade, ids) in enumerate(TILES):
        x = M + k * (TW_ + OPW)
        rect(x, y, TW_, TH, tint, col, 1.6, rx=9)
        rect(x, y, TW_, hh, col, rx=9)
        rect(x, y + hh - 9, TW_, 9, col)
        for j, l in enumerate(tl[k]):
            text(x + TW_ / 2, y + 12 + 11 + j * 15, l, "s", 700, 11.6, WHITE, "middle", ls="0.4")
        cy = y + hh + 12 + 11
        for j, l in enumerate(bl[k]):
            text(x + 11, cy + j * 16.2, l, "s", 400, 12.0, BODY)
        cy += max(len(b) for b in bl) * 16.2
        pill(x + TW_ / 2, cy, grade, col, WHITE, 9.4)
        cy += 20 + 10 + 10
        ids_draw(x + TW_ / 2, cy, il[k], 10.6, 14.4, anchor="middle")
        if k < 4:
            ox = x + TW_ + OPW / 2
            E.append(f'<circle cx="{ox:.1f}" cy="{y + TH / 2:.1f}" r="13" fill="{WHITE}" stroke="{ARROW}" '
                     f'stroke-width="1.8"/>')
            text(ox, y + TH / 2 + 6.5, ["+", "+", "=", "⇒"][k], "s", 700, 18, ARROW, "middle")
    y += TH + 14
    # the one bit
    OB = 70
    rect(M, y, CW, OB, NAVY2, NAVY, 1.2, rx=9)
    text(M + 16, y + 30, "THE ONE BIT", "s", 700, 14, GOLD, ls="1")
    text(M + 150, y + 31, "NothingEscapes (Rec TMSAT) → NothingEscapes TMSAT", "m", 700, 18.5, WHITE)
    rich(M + 16, y + 55, [("TheInequality", "m", 700, PILL_TX),
                          ("   printed as a type · assumed nowhere · supplied by the act · delivered twice", "s", 400,
                           SUB)], 12.6)
    y += OB + 14
    su = [(lambda k, t, b, ids: (lambda w: card(w, t, b, ids, V, tcol=V_D, kicker=f"PROPERTY {k} OF 7", kcol=V,
                                                tsize=13.4, bsize=12.0, lh=16.0)))(k + 1, t, b, ids)
          for k, (t, b, ids) in enumerate(SEVEN_U)]
    su.append(lambda w: card(w, "GRADE · THEOREM FOR ALL SEVEN",
                             "The bit they govern is supplied by the act and delivered twice; it has ten faces, one "
                             "proposition, and each face delivers P ≠ NP.",
                             ["the_one_bit_delivers_p_ne_np", "ten_faces_of_the_one_bit"], NAVY, fill=V_2, tcol=NAVY,
                             kicker="THE SEVEN, BOUND", kcol=NAVY, stroke=V, tsize=13.4, bsize=12.0, lh=16.0))
    y += band(y, "THE ONE BIT · 7 UNIQUE PROPERTIES · EACH A THEOREM", "the_one_bit_delivers_p_ne_np", V, V_T,
              lambda: grid(su, 4, M + 14, 0, CW - 28, draw=False),
              lambda yy: grid(su, 4, M + 14, yy, CW - 28))
    return y


def fig_proven(y):
    pc = [(lambda t, b, ids: (lambda w: card(w, t, b, ids, G, icon="✓")))(*c) for c in P_CARDS]
    y += band(y, "PROVEN UNCONDITIONALLY · THEOREM GRADE · NOTHING BEFORE THE COLON",
              "proven_unconditionally · unconditional_real_part_separation", G, G_T,
              lambda: grid(pc, 3, M + 14, 0, CW - 28, draw=False),
              lambda yy: grid(pc, 3, M + 14, yy, CW - 28))
    resolve("proven_unconditionally"); resolve("unconditional_real_part_separation")
    return y


def wall_cards(rng):
    return [(lambda t, b, ids, k: (lambda w: card(w, t, b, ids, R, icon="✕", kicker=f"WALL {k:02d}", kcol=R)))(
        WALLS[k - 1][0], WALLS[k - 1][1], WALLS[k - 1][2], k) for k in rng]


def strip(y, head, rest, ids, col, tint, draw):
    x0, w0 = M + 14, CW - 28
    extra = tw(head, "s", 700, 12.6) - tw(head, "s", 400, 12.6)
    rl = wrap(head + " " + rest, w0 - 28 - extra, "s", 400, 12.6)
    il = id_lines(ids, w0 - 28, 11.0)
    h = 14 + len(rl) * 17 + 3 + len(il) * 15 + 9
    if draw:
        rect(x0, y, w0, h, tint, col, 1.3, rx=7)
        for j, l in enumerate(rl):
            if j == 0 and l.startswith(glue(head)):
                rich(x0 + 14, y + 20, [(glue(head), "s", 700, col if col != R else R_D),
                                       (l[len(glue(head)):], "s", 400, BODY)], 12.6)
            else:
                text(x0 + 14, y + 20 + j * 17, l, "s", 400, 12.6, BODY)
        ids_draw(x0 + 14, y + 20 + len(rl) * 17 + 1, il, 11.0, 15)
    return h


def fig_walls1(y):
    def lay(y0, draw):
        cy = y0
        cy += strip(cy, "THE BIT IS KEYED.", "True on the closed SAT world, false on the stage SAT world, same "
                    "formulas, same predicate. A resource that holds on both worlds answers both alike, so it decides "
                    "neither: the root of every uniform wall.",
                    ["sat_bit_is_keyed", "bit_is_keyed", "two_rows_two_bits", "record_decides_nothing"], R, R_T,
                    draw) + 12
        cards = wall_cards(range(1, 11))
        cards.append(lambda w: card(w, "EVERY ROAD PASSES THE BIT", "Every road to SAT ∉ P passes the bit; the walls "
                                    "bar every method of supplying it that their quantifiers cover, born or unborn.",
                                    ["tmsat_every_route_passes_the_bit", "residue_is_keyed"], R_D, fill=R_T,
                                    kicker="BOUND", kcol=R_D))
        cy += grid(cards, 3, M + 14, cy, CW - 28, draw=draw)
        return cy - y0
    y += band(y, "THE UNIFORM WALLS · PROVED IN THE KERNEL · THEOREM GRADE", "residue_is_keyed · the_blocks", R,
              "#fbf3f2", lambda: lay(0, False), lambda yy: lay(yy, True))
    return y


def fig_walls2(y):
    def lay(y0, draw):
        cy = y0
        cy += grid(wall_cards(range(11, 23)), 3, M + 14, cy, CW - 28, draw=draw) + 12
        cy += strip(cy, "THE WALLS IN ONE THEOREM.", "Keyless, record, SAT-keyless and uniform walls, the vacant "
                    "seat, the crossing ceiling and the self-tableau wall, bound together; each binds every method its "
                    "quantifier covers, born or unborn.", ["the_blocks", "the_attempt_at_two"], R, R_T, draw) + 14
        if draw:
            text(M + 14, cy + 11, "CARRIED FROM THE MOTHER CODEX v3.48.0 · BARRIER-MASTER-01 · "
                                  "ABSOLUTE-PNP-BARRIERS-01 · CITED AT THEIR OWN GRADES", "s", 700, 11.4, R_D, ls="0.4")
        cy += 22
        cols, gap_ = 4, 10
        w0 = CW - 28
        mw = (w0 - gap_ * (cols - 1)) / cols
        rows = [MOTHER[0:4], MOTHER[4:7]]
        for r in rows:
            mtl = [wrap(t, mw - 18, "s", 700, 11.6) for t, _, _ in r]
            mbl = [wrap(b, mw - 18, "s", 400, 11.4) for _, b, _ in r]
            mal = [wrap(a, mw - 18, "s", 400, 10.6) for _, _, a in r]
            mh = 12 + max(len(t) for t in mtl) * 15 + 3 + max(len(b) for b in mbl) * 14.6 + 5 + max(
                len(a) for a in mal) * 13.6 + 8
            for i in range(len(r)):
                x = M + 14 + i * (mw + gap_)
                if draw:
                    rect(x, cy, mw, mh, WHITE, R, 1.1, rx=7, dash="5 3")
                    yy = cy + 12
                    for j, l in enumerate(mtl[i]):
                        text(x + 9, yy + 10 + j * 15, l, "s", 700, 11.6, R_D)
                    yy += max(len(t) for t in mtl) * 15 + 3
                    for j, l in enumerate(mbl[i]):
                        text(x + 9, yy + 10 + j * 14.6, l, "s", 400, 11.4, BODY)
                    yy += max(len(b) for b in mbl) * 14.6 + 5
                    for j, l in enumerate(mal[i]):
                        text(x + 9, yy + 10 + j * 13.6, l, "s", 400, 10.6, GREY)
            cy += mh + 10
        fl = wrap("Every wall binds on its own quantifier. A total wall on the bit's routes is the bit's negation "
                  "(total_wall_iff_negation), so the walls stand on their quantifiers and the bit is delivered.",
                  w0, "s", 400, 11.8)
        if draw:
            for j, l in enumerate(fl):
                text(M + 14, cy + 11 + j * 15.5, l, "s", 400, 11.8, R_D)
        resolve("total_wall_iff_negation")
        cy += len(fl) * 15.5
        return cy - y0
    y += band(y, "THE WALLS, COMPLETE · DEGREE TWO, THE MIRROR, THE ROWS, THE OUTSIDE", "the_blocks · the_block_chain",
              R, "#fbf3f2", lambda: lay(0, False), lambda yy: lay(yy, True))
    return y


def fig_delivered(y):
    def lay(y0, draw):
        x0, w0 = M + 14, CW - 28
        cy = y0
        n = len(KEY)
        chev = 18
        kw = (w0 - (n - 1) * chev) / n
        kb = [wrap(b, kw - 18, "s", 400, 11.8) for _, b, _ in KEY]
        kt = [wrap(t, kw - 14, "s", 700, 12.0) for t, _, _ in KEY]
        kh = 12 + max(len(t) for t in kt) * 15 + 6 + max(len(b) for b in kb) * 15.4 + 8 + 14 + 10
        if draw:
            text(x0, cy + 11, "THE KEY PASSES THE WALL", "s", 700, 12.2, A_D, ls="0.8")
        cy += 20
        for i, (t, b, ids) in enumerate(KEY):
            x = x0 + i * (kw + chev)
            if draw:
                rect(x, cy, kw, kh, WHITE, A, 1.4, rx=7)
                for j, l in enumerate(kt[i]):
                    text(x + kw / 2, cy + 22 + j * 15, l, "s", 700, 12.0, A_D, "middle")
                yb = cy + 22 + len(kt[i]) * 15 + 6
                for j, l in enumerate(kb[i]):
                    text(x + kw / 2, yb + j * 15.4, l, "s", 400, 11.8, BODY, "middle")
                ids_draw(x + kw / 2, cy + kh - 12, id_lines(ids, kw - 16, 10.8), 10.8, anchor="middle")
                if i < n - 1:
                    ax = x + kw + 2
                    path(f"M{ax:.1f},{cy + kh / 2 - 8:.1f} L{ax + chev - 4:.1f},{cy + kh / 2:.1f} "
                         f"L{ax:.1f},{cy + kh / 2 + 8:.1f} z", fill=A)
        cy += kh + 14
        pw_ = (w0 - 2 * 12) / 3

        def kinds_block(at=None):
            blocks = [card(pw_ - 20, t, b, ids, V, fill=V_T, tcol=V_D, stroke=V_2, tsize=12.4, bsize=11.8, lh=15.6)
                      for t, b, ids in KINDS]
            tail = wrap("The physical kind is the formal kind, and each gives P ≠ NP.", pw_ - 20, "s", 400, 11.8)
            tids = id_lines(["the_two_kinds_are_one_bit", "p_ne_np_delivered_twice", "both_kinds_deliver"],
                            pw_ - 20, 10.8)
            refb = card(pw_ - 20, "THE ONE REFUTER",
                        "One polynomial-time Turing machine for SAT, every run clean, refutes both kinds at once, "
                        "denies the sentence, and leaves every theorem of the kernel standing.",
                        ["the_one_refuter", "refuter_denies_the_sentence"], A, fill=A_T, tcol=A_D, stroke="#e8c98f",
                        tsize=12.4, bsize=11.8, lh=15.6)
            th = panel_title(0, 0, pw_ - 20, "TWO KINDS, ONE BIT", V_D, draw=False)
            h = th + sum(b.h + 8 for b in blocks) + len(tail) * 15.6 + 4 + len(tids) * 14.6 + 10 + refb.h + 10
            if at:
                xx, yy, hh = at
                rect(xx, yy, pw_, hh, WHITE, V, 1.4, rx=9)
                panel_title(xx + 10, yy, pw_ - 20, "TWO KINDS, ONE BIT", V_D)
                by = yy + th
                for b in blocks:
                    b.draw(xx + 10, by)
                    by += b.h + 8
                for j, l in enumerate(tail):
                    text(xx + 10, by + 11 + j * 15.6, l, "s", 400, 11.8, BODY)
                by += len(tail) * 15.6 + 4
                ids_draw(xx + 10, by + 10, tids, 10.8, 14.6)
                by += len(tids) * 14.6 + 10
                refb.draw(xx + 10, by)
            return h

        def form_block(at=None):
            items = []
            for t, b, ids in FORM:
                tl = wrap(t, pw_ - 20, "s", 700, 11.8)
                bl = wrap(b, pw_ - 20, "s", 400, 11.6) if b else []
                il = id_lines(ids, pw_ - 20, 10.8)
                items.append((tl, bl, il, len(tl) * 15.4 + len(bl) * 15 + len(il) * 14.6 + 10))
            foot = wrap("Cited as a hypothesis wherever used: the NP-hardness half of Cook and Levin, SATHard.",
                        pw_ - 20, "s", 400, 11.0)
            th = panel_title(0, 0, pw_ - 20, "THE FORM CLOSED", B_D, draw=False) + 2
            h = th + sum(i[3] for i in items) + len(foot) * 14 + 12
            if at:
                xx, yy, hh = at
                rect(xx, yy, pw_, hh, WHITE, B, 1.4, rx=9)
                panel_title(xx + 10, yy, pw_ - 20, "THE FORM CLOSED", B_D)
                by = yy + th
                for tl, bl, il, ih in items:
                    for j, l in enumerate(tl):
                        text(xx + 10, by + 11 + j * 15.4, l, "s", 700, 11.8, INK)
                    b2 = by + len(tl) * 15.4
                    for j, l in enumerate(bl):
                        text(xx + 10, b2 + 11 + j * 15, l, "s", 400, 11.6, BODY)
                    b2 += len(bl) * 15
                    ids_draw(xx + 10, b2 + 10, il, 10.8, 14.6)
                    by += ih
                for j, l in enumerate(foot):
                    text(xx + 10, yy + hh - 12 - (len(foot) - 1 - j) * 14, l, "s", 400, 11.0, GREY)
            return h

        def faces_block(at=None):
            items = []
            for t, ids in FACES:
                tl = wrap(t + " → P ≠ NP", pw_ - 20, "s", 700, 11.8)
                il = id_lines(ids, pw_ - 20, 10.8)
                items.append((tl, il, len(tl) * 15.4 + len(il) * 14.6 + 10))
            foot = wrap("SAT ∈ NP is built in the kernel, so no face needs a citation to reach the sentence.",
                        pw_ - 20, "s", 400, 11.4)
            fids = id_lines(["satLang_in_NP"], pw_ - 20, 10.8)
            ttl = "EVERY FACE DELIVERS P ≠ NP · NOTHING CITED"
            th = panel_title(0, 0, pw_ - 20, ttl, G_D, draw=False) + 2
            h = th + sum(i[2] for i in items) + 6 + len(foot) * 15 + len(fids) * 14.6 + 10
            if at:
                xx, yy, hh = at
                rect(xx, yy, pw_, hh, WHITE, G, 1.4, rx=9)
                panel_title(xx + 10, yy, pw_ - 20, ttl, G_D)
                by = yy + th
                for tl, il, ih in items:
                    for j, l in enumerate(tl):
                        text(xx + 10, by + 11 + j * 15.4, l, "s", 700, 11.8, INK)
                    ids_draw(xx + 10, by + 11 + len(tl) * 15.4, il, 10.8, 14.6)
                    by += ih
                fy = yy + hh - 12 - (len(fids) - 1) * 14.6 - len(foot) * 15
                for j, l in enumerate(foot):
                    text(xx + 10, fy + j * 15, l, "s", 400, 11.4, G_D)
                ids_draw(xx + 10, fy + len(foot) * 15, fids, 10.8, 14.6)
            return h

        ph = max(kinds_block(), form_block(), faces_block())
        if draw:
            kinds_block((x0, cy, ph))
            form_block((x0 + pw_ + 12, cy, ph))
            faces_block((x0 + 2 * (pw_ + 12), cy, ph))
        cy += ph
        return cy - y0
    y += band(y, "THE BIT DELIVERED · SUPPLIED BY THE ACT · TWO KINDS, ONE BIT, DELIVERED TWICE",
              "the_delivery", A, A_T, lambda: lay(0, False), lambda yy: lay(yy, True))
    resolve("the_delivery")
    return y


def fig_chain_gates(y):
    def chain(y0, draw):
        x0, w0 = M + 14, CW - 28
        cols, gap_ = 4, 26
        cw_ = (w0 - gap_ * (cols - 1)) / cols
        blocks = [card(cw_, t, b, ids, NAVY, kicker=f"LINK {k + 1}", kcol=NAVY2, tsize=12.4, bsize=11.8, lh=15.6,
                       isize=10.4, ilh=14.2)
                  for k, (t, b, ids) in enumerate(CHAIN)]
        cy = y0
        for r_i, r in enumerate([blocks[0:4], blocks[4:8]]):
            rh = max(b.h for b in r)
            for j, b in enumerate(r):
                x = x0 + j * (cw_ + gap_)
                if draw:
                    b.draw(x, cy, rh)
                    if j < cols - 1:
                        lx, ly = x + cw_ + 3, cy + rh / 2
                        E.append(f'<ellipse cx="{lx + 7:.1f}" cy="{ly:.1f}" rx="7.5" ry="5" fill="none" '
                                 f'stroke="{NAVY}" stroke-width="2"/>')
                        E.append(f'<ellipse cx="{lx + 15:.1f}" cy="{ly:.1f}" rx="7.5" ry="5" fill="none" '
                                 f'stroke="{NAVY2}" stroke-width="2"/>')
            cy += rh + (26 if r_i == 0 else 0)
            if draw and r_i == 0:
                yb, ym = cy - 26, cy - 13
                path(f"M{x0 + w0 - cw_ / 2:.1f},{yb:.1f} L{x0 + w0 - cw_ / 2:.1f},{ym:.1f} L{x0 + cw_ / 2:.1f},"
                     f"{ym:.1f} L{x0 + cw_ / 2:.1f},{cy - 3:.1f}", stroke=NAVY, sw=1.8, marker="arrN")
        fl = wrap("A reader checks one declaration and holds all eight links. Links 1 to 3 close the form; links 4 "
                  "and 8 seat every kernel wall; link 5 passes the key; links 6 and 7 seal the walls against "
                  "overreach in both directions.", w0, "s", 400, 11.8)
        cy += 10
        if draw:
            for j, l in enumerate(fl):
                text(x0, cy + 11 + j * 15.5, l, "s", 400, 11.8, BODY)
        cy += len(fl) * 15.5
        return cy - y0

    def gates(y0, draw):
        x0, w0 = M + 14, CW - 28
        cols, gap_ = 4, 10
        gw = (w0 - gap_ * (cols - 1)) / cols
        gl = [wrap(b, gw - 18, "s", 400, 11.8) for _, b, _ in GATES]
        gh = 12 + 22 + 6 + max(len(g) for g in gl) * 15.4 + 6 + 14 + 10
        rows = (len(GATES) + cols - 1) // cols
        for i, (code, b, thm) in enumerate(GATES):
            r_, c_ = divmod(i, cols)
            x = x0 + c_ * (gw + gap_)
            yy = y0 + r_ * (gh + 10)
            if draw:
                rect(x, yy, gw, gh, WHITE, B, 1.3, rx=7)
                text(x + 11, yy + 29, f"{i + 1}", "s", 700, 20, B_D)
                text(x + 11 + tw(f"{i + 1}", "s", 700, 20) + 8, yy + 28, code, "s", 700, 14, INK, ls="0.5")
                pw0 = tw("PASS", "s", 700, 9.4) + 20 + 1.6
                pill(x + gw - 11 - pw0, yy + 13, "PASS", G, WHITE, 9.4, anchor="start")
                for j, l in enumerate(gl[i]):
                    text(x + 11, yy + 52 + j * 15.4, l, "s", 400, 11.8, BODY)
                ids_draw(x + 11, yy + gh - 12, id_lines([thm], gw - 18, 10.8), 10.8)
        cy = y0 + rows * gh + (rows - 1) * 10 + 10
        fl = wrap("Each gate is a proposition and a theorem. The twelve passes are bound with nothing before the colon "
                  "in the_formal_run and again inside the_capstone.", w0, "s", 400, 11.8)
        if draw:
            for j, l in enumerate(fl):
                text(x0, cy + 11 + j * 15.5, l, "s", 400, 11.8, BODY)
        cy += len(fl) * 15.5
        return cy - y0

    y += band(y, "THE CHAIN · EIGHT LINKS · ONE THEOREM · NOTHING BEFORE THE COLON", "the_block_chain", NAVY,
              "#eef2f7", lambda: chain(0, False), lambda yy: chain(yy, True)) + 14
    y += band(y, "THE TWELVE FORMAL GATES · RUN IN THE KERNEL · ALL TWELVE PASS", "the_formal_run · the_capstone", B,
              B_T, lambda: gates(0, False), lambda yy: gates(yy, True))
    resolve("the_block_chain"); resolve("the_formal_run"); resolve("the_capstone")
    return y


def fig_capstone(y):
    def lay(y0, draw):
        x0, w0 = M + 14, CW - 28
        lw = 560
        rx_ = x0 + lw + 20
        rw = w0 - lw - 20
        fx, fw = x0, lw
        cy = y0
        dcx, dw, dh = fx + 150, 100, 52
        yy = cy
        if draw:
            rect(fx, yy, 300, 50, NAVY, rx=9)
            text(dcx, yy + 21, "ANY ROUTE Q TO P ≠ NP", "s", 700, 13.4, WHITE, "middle", ls="0.6")
            text(dcx, yy + 39, "any vocabulary · any premise · any method", "s", 400, 10.6, SUB, "middle")
            line(dcx, yy + 50, dcx, yy + 72, ARROW, 2.2, "arr")
        yy += 74
        dcy = yy + dh
        rbx = fx + 290
        rbw = fx + fw - rbx
        rl = wrap("A premise that gives P ≠ NP while the bit fails is false. The demand is refuted.", rbw - 20, "s",
                  400, 11.6)
        rids = id_lines(["demand_for_p_ne_np_without_bit_illegal", "form_closed"], rbw - 20, 10.6)
        rbh = 30 + len(rl) * 15.2 + len(rids) * 14 + 10
        if draw:
            path(f"M{dcx:.1f},{dcy - dh:.1f} L{dcx + dw:.1f},{dcy:.1f} L{dcx:.1f},{dcy + dh:.1f} L{dcx - dw:.1f},"
                 f"{dcy:.1f} z", fill=A_T, stroke=A, sw=1.8)
            text(dcx, dcy - 12, "Does Q reach", "s", 700, 11.6, A_D, "middle")
            text(dcx, dcy + 3, "P ≠ NP around", "s", 700, 11.6, A_D, "middle")
            text(dcx, dcy + 18, "the bit?", "s", 700, 11.6, A_D, "middle")
            line(dcx + dw, dcy, rbx - 4, dcy, R, 2.2, "arrR")
            text((dcx + dw + rbx) / 2 - 2, dcy - 7, "YES", "s", 700, 11.0, R, "middle")
            rect(rbx, dcy - rbh / 2, rbw, rbh, R_T, R, 1.8, rx=9)
            text(rbx + 10, dcy - rbh / 2 + 19, "✕ REFUTED BY THEOREM", "s", 700, 12.2, R_D)
            for j, l in enumerate(rl):
                text(rbx + 10, dcy - rbh / 2 + 37 + j * 15.2, l, "s", 400, 11.6, BODY)
            ids_draw(rbx + 10, dcy - rbh / 2 + 37 + len(rl) * 15.2, rids, 10.6, 14)
            line(dcx, dcy + dh, dcx, dcy + dh + 28, V, 2.2, "arrP")
            text(dcx + 8, dcy + dh + 19, "NO", "s", 700, 11.4, V)
        yy = max(dcy + dh + 30, dcy + rbh / 2 + 10)
        owl = wrap("Q is our way in different vocabulary. It delivers the formal cargo and the physical witness, and "
                   "if the bit failed, Q would fail with it.", fw - 30, "s", 400, 12.6)
        owids = id_lines(["our_way_or_no_way", "every_delivery_is_both_kinds", "every_route_is_both_kinds"], fw - 30,
                         10.8)
        owh = 36 + len(owl) * 17 + 4 + len(owids) * 14.6 + 10
        if draw:
            rect(fx, yy, fw, owh, V, rx=10)
            text(fx + 16, yy + 27, "OUR WAY", "s", 700, 18, WHITE, ls="1.2")
            for j, l in enumerate(owl):
                text(fx + 16, yy + 48 + j * 17, l, "s", 400, 12.6, "#ece8ff")
            yi = yy + 48 + len(owl) * 17 + 2
            for i_, ln in enumerate(owids):
                rich(fx + 16, yi + i_ * 14.6, [(s, "m", 700, WHITE if c != GREY else "#c9c2f2") for s, c in ln], 10.8)
        yy += owh + 12
        kw_ = (fw - 40) / 2
        kh_ = 54
        if draw:
            line(fx + kw_ / 2, yy - 12, fx + kw_ / 2, yy, V, 2)
            line(fx + fw - kw_ / 2, yy - 12, fx + fw - kw_ / 2, yy, V, 2)
            for k_, (t, ids) in enumerate([("KIND 1 · FORMAL CARGO", ["face_formal", "formal_kind_delivers"]),
                                           ("KIND 2 · PHYSICAL WITNESS", ["face_physical", "physical_kind_delivers"])]):
                kx = fx + k_ * (kw_ + 40)
                rect(kx, yy, kw_, kh_, V_T, V, 1.4, rx=9)
                text(kx + kw_ / 2, yy + 22, t, "s", 700, 12.4, V_D, "middle")
                ids_draw(kx + kw_ / 2, yy + 41, id_lines(ids, kw_ - 16, 10.4), 10.4, anchor="middle")
        yy += kh_
        if draw:
            line(fx + kw_ / 2, yy, fx + fw / 2 - 60, yy + 28, V, 2, "arrP")
            line(fx + fw - kw_ / 2, yy, fx + fw / 2 + 60, yy + 28, V, 2, "arrP")
        yy += 30
        if draw:
            rect(fx + fw / 2 - 120, yy, 240, 50, NAVY, rx=10)
            text(fx + fw / 2, yy + 27, "P ≠ NP", "s", 700, 21, GOLD, "middle")
            text(fx + fw / 2, yy + 43, "both_kinds_deliver", "m", 700, 10.4, PILL_TX, "middle")
            resolve("both_kinds_deliver")
        yy += 50
        left_h = yy - cy
        ry = cy
        if draw:
            text(rx_, ry + 12, "NOTHING ESCAPES · THE OUTSIDE IS THE SUPPLY", "s", 700, 12.2, V_D, ls="0.5")
        ry += 22
        for t, b, ids in CAP:
            tl = wrap(t, rw - 22, "s", 700, 11.8)
            bl = wrap(b, rw - 22, "s", 400, 11.4) if b else []
            il = id_lines(ids, rw - 22, 10.6)
            ih = len(tl) * 15.4 + len(bl) * 14.8 + len(il) * 14 + 8
            if draw:
                E.append(f'<circle cx="{rx_ + 5:.1f}" cy="{ry + 7:.1f}" r="4" fill="{V}"/>')
                for j, l in enumerate(tl):
                    text(rx_ + 16, ry + 11 + j * 15.4, l, "s", 700, 11.8, INK)
                for j, l in enumerate(bl):
                    text(rx_ + 16, ry + 11 + len(tl) * 15.4 + j * 14.8, l, "s", 400, 11.4, BODY)
                ids_draw(rx_ + 16, ry + 11 + len(tl) * 15.4 + len(bl) * 14.8, il, 10.6, 14)
            ry += ih
        rul = wrap("Every so-called other way to P ≠ NP is our way in different vocabulary. An offering that crosses "
                   "the row, such as a proof from the standard axioms, is a delivery of the cargo, never a bypass of "
                   "it.", rw - 24, "s", 700, 12.2)
        rids2 = id_lines(["our_way_or_no_way", "the_capstone"], rw - 24, 10.8)
        ruh = 32 + len(rul) * 16.6 + 4 + len(rids2) * 14.6 + 10
        ry += 4
        if draw:
            rect(rx_, ry, rw, ruh, V_2, V, 1.8, rx=9)
            text(rx_ + 12, ry + 22, "THE RULE · OUR WAY OR NO WAY", "s", 700, 13.4, V_D, ls="0.7")
            for j, l in enumerate(rul):
                text(rx_ + 12, ry + 42 + j * 16.6, l, "s", 700, 12.2, V_D)
            ids_draw(rx_ + 12, ry + 42 + len(rul) * 16.6 + 2, rids2, 10.8)
        ry += ruh
        return max(left_h, ry - cy)
    y += band(y, "NOTHING ESCAPES · OUR WAY OR NO WAY · THE CAPSTONE", "the_capstone · our_way_or_no_way", V, V_T,
              lambda: lay(0, False), lambda yy: lay(yy, True))
    return y


def fig_verdict(y):
    def lay(y0, draw):
        x0, w0 = M + 14, CW - 28
        cy = y0
        bh = 64
        if draw:
            rect(x0, cy, w0, bh, NAVY, rx=10)
            text(x0 + 18, cy + 42, "[Ø₀]", "s", 700, 29, GOLD)
            text(x0 + 104, cy + 28, "THE CLAY QUESTION STANDS AT [Ø₀], THE SEALED HALT", "s", 700, 15.6, WHITE,
                 ls="0.5")
            text(x0 + 104, cy + 49, "The form sealed by theorem · the walls sealed on their quantifiers · the value "
                                    "sealed by the act", "s", 400, 12.0, SUB)
        cy += bh + 12
        cwid = (w0 - 2 * 12) / 3
        c1x, c2x, c3x = x0, x0 + cwid + 12, x0 + 2 * (cwid + 12)
        rows1 = []
        for f, d, g, col in SEALROWS:
            dl = wrap(d, cwid - 20 - 66, "s", 400, 11.6)
            rows1.append((f, dl, g, col, len(dl) * 15 + 8 + 20 + 12))
        rows2 = []
        for f, v, d, ids, col in COMPOSITE:
            vw = tw(v, "s", 700, 9.2) + 20 + 0.4 * len(v)
            fl = wrap(f, cwid - 20 - vw - 8, "s", 700, 11.4)
            dl = wrap(d, cwid - 20, "s", 400, 11.2)
            il = id_lines(ids, cwid - 20, 10.4)
            rows2.append((fl, v, vw, dl, il, col, 6 + len(fl) * 14.4 + 4 + len(dl) * 14.4 + len(il) * 13.8 + 12))
        rows3 = []
        for q, d, ids in NOTMEAN:
            dl = wrap(d, cwid - 40, "s", 400, 11.4)
            il = id_lines(ids, cwid - 40, 10.4)
            rows3.append((q, dl, il, 18 + len(dl) * 14.6 + len(il) * 13.8 + 10))
        h1 = 34 + sum(r[4] for r in rows1)
        h2 = 34 + sum(r[6] for r in rows2)
        h3 = 48 + sum(r[3] for r in rows3) + 40
        hh = max(h1, h2, h3) + 6
        if draw:
            rect(c1x, cy, cwid, hh, WHITE, NAVY, 1.3, rx=9)
            text(c1x + 10, cy + 20, "THE SEAL, FACE BY FACE", "s", 700, 12.2, NAVY, ls="0.7")
            yy = cy + 32
            for f, dl, g, col, rh in rows1:
                text(c1x + 10, yy + 14, f, "s", 700, 12.2, col)
                for j, l in enumerate(dl):
                    text(c1x + 76, yy + 14 + j * 15, l, "s", 400, 11.6, BODY)
                pill(c1x + 76, yy + 14 + len(dl) * 15 - 4, g, col, WHITE, 9.2, anchor="start")
                if f != "TUPLE":
                    line(c1x + 10, yy + rh - 3, c1x + cwid - 10, yy + rh - 3, LINE, 1)
                yy += rh
            rect(c2x, cy, cwid, hh, WHITE, NAVY, 1.3, rx=9)
            text(c2x + 10, cy + 20, "THE COMPOSITE · TABLE 5", "s", 700, 12.2, NAVY, ls="0.7")
            yy = cy + 32
            for fl, v, vw, dl, il, col, rh in rows2:
                for j, l in enumerate(fl):
                    text(c2x + 10, yy + 13 + j * 14.4, l, "s", 700, 11.4, INK)
                pill(c2x + cwid - 10 - vw, yy + 1, v, col, WHITE, 9.2, anchor="start")
                for j, l in enumerate(dl):
                    text(c2x + 10, yy + 13 + len(fl) * 14.4 + 4 + j * 14.4, l, "s", 400, 11.2, BODY)
                ids_draw(c2x + 10, yy + 13 + len(fl) * 14.4 + 4 + len(dl) * 14.4, il, 10.4, 13.8)
                if v != COMPOSITE[-1][1] or fl[0] != wrap(COMPOSITE[-1][0], cwid - 20 - vw - 8, "s", 700, 11.4)[0]:
                    line(c2x + 10, yy + rh - 5, c2x + cwid - 10, yy + rh - 5, LINE, 1)
                yy += rh
            rect(c3x, cy, cwid, hh, WHITE, R, 1.3, rx=9)
            text(c3x + 10, cy + 20, "WHAT “CLAY OPEN” CANNOT MEAN", "s", 700, 12.2, R_D, ls="0.6")
            text(c3x + 10, cy + 36, "each reading refused by theorem", "s", 400, 10.8, GREY)
            yy = cy + 46
            for q, dl, il, rh in rows3:
                text(c3x + 10, yy + 14, "✕", "s", 700, 13, R)
                text(c3x + 28, yy + 13, q, "s", 700, 12.0, INK)
                for j, l in enumerate(dl):
                    text(c3x + 28, yy + 30 + j * 14.6, l, "s", 400, 11.4, BODY)
                ids_draw(c3x + 28, yy + 30 + len(dl) * 14.6, il, 10.4, 13.8)
                yy += rh
            rect(c3x + 10, cy + hh - 38, cwid - 20, 28, NAVY, rx=7)
            text(c3x + cwid / 2, cy + hh - 19, "What it is: [Ø₀], the Sealed halt.", "s", 700, 12.2, GOLD, "middle")
        cy += hh
        return cy - y0
    y += band(y, "THE VERDICT · THE CLAY QUESTION AT [Ø₀], THE SEALED HALT", "the_block_chain · the_capstone", NAVY,
              "#eef2f7", lambda: lay(0, False), lambda yy: lay(yy, True))
    return y


def receipts(y):
    lines_all = []
    for head, body in FOOT:
        first_w = CW - 36 - tw(head, "s", 700, 11.4)
        out, cur, limit = [], "", first_w
        for w_ in body.split(" "):
            t = (cur + " " + w_) if cur else w_
            if tw(t, "s", 400, 11.4) <= limit or not cur:
                cur = t
            else:
                out.append(cur)
                cur, limit = w_, CW - 36
        if cur:
            out.append(cur)
        lines_all.append((head, out))
    h = 18 + sum(len(l) for _, l in lines_all) * 16 + (len(lines_all) - 1) * 5 + 12
    rect(M, y, CW, h, NAVY, rx=9)
    yy = y + 24
    for head, out in lines_all:
        for j, l in enumerate(out):
            if j == 0:
                rich(M + 18, yy, [(head, "s", 700, GOLD), (l, "s", 400, "#dbe6f1")], 11.4)
            else:
                text(M + 18, yy, l, "s", 400, 11.4, "#dbe6f1")
            yy += 16
        yy += 5
    return h


# ================================================================ BUILD
def font_face(key, famname, weight):
    chars = "".join(sorted(USED.get(key, set()))) + " "
    tt = TTFont(FONTFILE[key])
    opts = subset.Options()
    opts.flavor = "woff2"
    opts.layout_features = ["kern", "liga"]
    opts.notdef_outline = True
    sub = subset.Subsetter(opts)
    sub.populate(text=chars)
    sub.subset(tt)
    buf = io.BytesIO()
    tt.flavor = "woff2"
    tt.save(buf)
    return (f"@font-face{{font-family:'{famname}';font-weight:{weight};font-style:normal;"
            f"src:url(data:font/woff2;base64,{base64.b64encode(buf.getvalue()).decode()}) format('woff2');}}")


FIGS = [
    (1, "THE SEAL · THE ONE BIT · ITS SEVEN UNIQUE PROPERTIES", fig_seal, True, False),
    (2, "PROVEN UNCONDITIONALLY", fig_proven, True, False),
    (3, "THE UNIFORM WALLS", fig_walls1, True, False),
    (4, "THE WALLS, COMPLETE", fig_walls2, True, False),
    (5, "THE BIT DELIVERED", fig_delivered, True, False),
    (6, "THE CHAIN AND THE TWELVE FORMAL GATES", fig_chain_gates, True, False),
    (7, "NOTHING ESCAPES · OUR WAY OR NO WAY", fig_capstone, True, False),
    (8, "THE VERDICT AND THE RECEIPTS", fig_verdict, True, True),
]

if __name__ == "__main__":
    report = []
    allchecked = {}
    for num, title, body, with_legend, with_receipts in FIGS:
        E.clear(); USED.clear(); CHECKED.clear()
        E.append("BG")
        y = fig_header(num, title) + 12
        y = body(y) + 12
        if with_receipts:
            y += receipts(y) + 10
        if with_legend:
            y += legend(y) + 12
        H = int(round(y))
        E[0] = f'<rect x="0" y="0" width="{W}" height="{H}" fill="{BG}"/>'
        faces = [font_face(("s", 400), "PNPSans", 400), font_face(("s", 700), "PNPSans", 700),
                 font_face(("m", 400), "PNPMono", 400), font_face(("m", 700), "PNPMono", 700)]
        defs = ('<defs>'
                f'<marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
                f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{ARROW}"/></marker>'
                f'<marker id="arrR" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
                f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{R}"/></marker>'
                f'<marker id="arrP" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
                f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{V}"/></marker>'
                f'<marker id="arrN" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
                f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{NAVY}"/></marker>'
                f'<style>{"".join(faces)}</style></defs>')
        ttl = f"P ≠ NP: Form by Theorem, Value by the Act · Figure {num} · {title.title()}"
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" '
               f'aria-label="{escape(ttl)}">\n<title>{escape(ttl)}</title>\n{defs}\n' + "\n".join(E) + "\n</svg>\n")
        fn = f"{OUTDIR}/P_ne_NP_Figure_{num}_v1_13_0_CC.svg"
        open(fn, "w", encoding="utf-8").write(svg)
        allchecked.update(CHECKED)
        report.append((num, H, len(svg), len(CHECKED)))
    json.dump({k: list(v) for k, v in allchecked.items()}, open(OUTDIR + "/checked_ids.json", "w"), indent=0)
    for r in report:
        print(f"Figure {r[0]}: 1100 x {r[1]} px, {r[2]} bytes, {r[3]} names resolved")
    print("total distinct names:", len(allchecked))
