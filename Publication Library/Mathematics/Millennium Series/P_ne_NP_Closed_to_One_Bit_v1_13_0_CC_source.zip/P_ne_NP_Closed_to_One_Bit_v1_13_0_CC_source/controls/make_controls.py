src = open("../PNP_Normal_Form_Paper_v1_13_0_CC.lean", encoding="utf-8").read()
C = {}
C[1] = src + "\ntheorem plant1 : ¬ PNP.TM.SATinP := PNP.RESIDUE.sat_not_in_P_of_the_act id\n"
a = "example : satLang [Sym.sep] = false := by decide"
assert src.count(a) == 1
C[2] = src.replace(a, "example : satLang [Sym.sep] = true := by decide")
C[3] = src + """
namespace PNP.TM
def alwaysAccept : TM :=
  { q := 2, s := 0, δ := fun _ a => (⟨0, by decide⟩, a, Dir.R),
    start := ⟨0, by decide⟩, accept := ⟨0, by decide⟩, reject := ⟨1, by decide⟩ }
theorem plant3 : SATinP :=
  ⟨alwaysAccept, 1, 0, fun w => ⟨0, Nat.zero_le _, Or.inl rfl, rfl⟩⟩
end PNP.TM
"""
b = "/-- info: 'PNP.NORMALFORM.sep_normal_form' depends on axioms: [propext, Classical.choice, Quot.sound] -/"
assert src.count(b) == 1
C[4] = src.replace(b, "/-- info: 'PNP.NORMALFORM.sep_normal_form' does not depend on any axioms -/")
C[5] = src + "\ntheorem plant5 : PNP.TM.P_ne_NP := sorry\n"
c = "/-- info: 'PNP.SUPPLY.the_two_kinds_are_one_bit' depends on axioms: [propext, Classical.choice, Quot.sound] -/"
assert src.count(c) == 1
C[6] = src.replace(c, "/-- info: 'PNP.SUPPLY.the_two_kinds_are_one_bit' does not depend on any axioms -/")
C[7] = src + """
theorem plant7 : PNP.TM.P_ne_NP ↔ PNP.SUPPLY.FormalCargo :=
  ⟨fun hP => PNP.TM.pnp_normal_form_turing.mpr (fun hs => hHard hs hP),
   fun h => PNP.TM.p_ne_np_of_not_inP PNP.VERIFIER.satLang_in_NP (PNP.TM.pnp_normal_form_turing.mp h)⟩
"""
for k, v in C.items():
    open(f"control{k}.lean", "w", encoding="utf-8").write(v)
print("written", sorted(C))
