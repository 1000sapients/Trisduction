#!/bin/bash
cd "$(dirname "$0")"
run() { ~/.elan/bin/lean -DwarningAsError=true control$1.lean > out$1.txt 2>&1; echo "exit $?" >> out$1.txt; }
for k in 1 2 3 4; do run $k & done; wait
for k in 5 6 7; do run $k & done; wait
echo ALLDONE
