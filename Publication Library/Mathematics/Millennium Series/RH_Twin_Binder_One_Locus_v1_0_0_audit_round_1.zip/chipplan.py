import json, collections
res=json.load(open('chip_resolution.json'))
heads=collections.OrderedDict()
for o in res: heads.setdefault(o['texline'],[]).append(o)
cm={'':'\\cE','propext':'\\cP','propext, Quot.sound':'\\cPQ','propext, Classical.choice, Quot.sound':'\\cPCQ'}
plan=[]
for ln,items in heads.items():
    st=[]
    for o in items:
        if o['pinned']: st.append(('pinned',cm[o['pin_cone']]))
        elif o['bound']=='empty': st.append(('forced',"\\cE"))
        elif o['bound']=='pcq': st.append(('bounded','\\cPCQ'))
        else: st.append(('global','\\cPCQ'))
    kinds={k for k,_ in st}
    if kinds<={'pinned','forced'}:
        cones=sorted({c for _,c in st},key=lambda c:['\\cE','\\cP','\\cPQ','\\cPCQ'].index(c))
        new=('chip',' / '.join(cones))
    else:
        new=('chipB','\\cPCQ')
    plan.append(dict(texline=ln,chip=items[0]['chip'],new=new,ids=[(o['full'],k,c) for o,(k,c) in zip(items,st)]))
json.dump(plan,open('chip_plan.json','w'),indent=1)
cnt=collections.Counter(k for p in plan for _,k,_ in p['ids'])
print(dict(cnt),'heads to chipB:',sum(1 for p in plan if p['new'][0]=='chipB'),'of',len(plan))
