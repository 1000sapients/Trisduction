# -*- coding: utf-8 -*-
"""Round-1 repairs: paper_v1.tex -> ../build/paper.tex (candidate v2). Every replacement asserts a unique match."""
import re, json, pathlib
SRC = pathlib.Path('paper_v1.tex').read_text(encoding='utf-8')
s = SRC

def tt(name):
    """house form of a Lean identifier"""
    return '\\texttt{' + name.replace('_', '\\_\\allowbreak{}').replace('.', '.\\allowbreak{}') + '}'

R = []  # (finding, old, new)
def rep(fid, old, new):
    R.append((fid, old, new))

# ---- F-9 / F-10 (C7): the two counts
rep('F-9/F-10', '11{,}734 lines, 834 theorems, 564 compiler-pinned axiom cones', '11{,}734 lines, 833 theorems, 563 compiler-pinned axiom cones')
rep('F-9/F-10', 'It declares 834 theorems, 352 definitions, 52 structures and 6 inductive types across 21 namespaces, and pins 564 axiom cones',
    'It declares 833 theorems, 352 definitions, 52 structures and 6 inductive types across 21 namespaces, and pins 563 axiom cones')
# ---- F-11
rep('F-11', 'The 820 theorems of the discrete charts therefore describe', 'The 778 theorems of Parts I to IX therefore describe')
# ---- F-5: zeta_binding is a conjunction, not a condition equivalent to RH (Reading Protocol (i) and A.3)
rep('F-5', "(i)~Mathlib's \\texttt{RiemannHypothesis} is equivalent to the five fixed-point conditions of " + tt('zeta_ra_loop') + " and to the eleven-part binding " + tt('zeta_binding') + ".",
    "(i)~Mathlib's \\texttt{RiemannHypothesis} is equivalent to each of the five fixed-point conditions of " + tt('zeta_ra_loop') + ", and is bound with ten further results into the eleven-part conjunction " + tt('zeta_binding') + ".")
rep('F-5', "Mathlib's \\texttt{RiemannHypothesis} is equivalent to the five fixed-point conditions of " + tt('zeta_ra_loop') + " and to the eleven-part binding " + tt('zeta_binding') + " (Section~6);",
    "Mathlib's \\texttt{RiemannHypothesis} is equivalent to each of the five fixed-point conditions of " + tt('zeta_ra_loop') + ", and is bound with ten further results into the eleven-part conjunction " + tt('zeta_binding') + " (Section~6);")
# ---- F-6: three keyed-input theorems
rep('F-6', 'with an empty axiom cone, the bridge being the one premise proved keyed.',
    'with an empty axiom cone, the reading and the bridge being the premises proved keyed by witness and the bound deciding nothing alone.')
rep('F-6', 'the bridge being the one keyed premise (' + tt('the_bridge_is_keyed') + ') (Section~9).',
    'the reading and the bridge being the premises proved keyed (' + tt('the_reading_is_keyed') + ', ' + tt('the_bridge_is_keyed') + ') (Section~9).')
# ---- F-2: the bit, locus-explicit
rep('F-2', 'The architecture reduces the hypothesis to one bit, least erasure at the read zero set: $\\LE(\\Zz)$ is \\texttt{RiemannHypothesis} by ' + tt('h_id_proved') + '. At the record $\\Rec(\\Zz)$ the bit is a theorem (' + tt('cargo_at_zeros') + '). ' + tt('transport_zeta') + ' proves that carrying it from the record to the zeros by forward implication is the value of the zeros itself, and ',
    'The architecture reduces the hypothesis to one bit, least erasure of the zero set, read at a locus: at the read zeros, $\\LE(\\Zz)$ is \\texttt{RiemannHypothesis} by ' + tt('h_id_proved') + '; at the record, $\\LE(\\Rec\\,\\Zz)$ is a theorem (' + tt('cargo_at_zeros') + '). ' + tt('transport_zeta') + ' proves that carrying least erasure from the record to the zeros by forward implication is the value of the zeros itself, and ')
# ---- F-7: the block at its class, with the charts named (Reading Protocol, Rule 1, Canonical summary)
rep('F-7', 'prove that no principle shared by every reflection-closed configuration, no inhabited premise, and no record-invariant predicate carries it. The unconditional route, a derivation from what every closed configuration shares, is blocked by theorem.',
    'prove that no principle shared by every reflection-closed configuration, no inhabited premise and no record-invariant predicate forces the value on every reflection-closed configuration, the first and the last natively over $\\mathbb{C}$, the middle two on the discrete chart of Part~IX. The unconditional route, a derivation valid for every closed configuration from what they share, is blocked by theorem, and the block is stated at that class and at no wider one.')
rep('F-7', 'prove that no principle shared by every reflection-closed configuration, no inhabited premise, and no record-invariant predicate supplies it. The block is stated at exactly the class the theorems name, routes from what every closed configuration shares;',
    'prove that no principle shared by every reflection-closed configuration, no inhabited premise and no record-invariant predicate forces the value on every reflection-closed configuration, the first and the last over $\\mathbb{C}$, the middle two on the discrete chart of Part~IX. The block is stated at exactly the class the theorems name, routes valid for every closed configuration from what they share;')
rep('F-7', 'and that no shared reflection law, inhabited premise or record-invariant predicate supplies it (',
    'and that no shared reflection law, inhabited premise or record-invariant predicate forces the value on every reflection-closed configuration (')
# ---- F-21: the antecedent, and the demand named at its type
rep('F-21', '\\textbf{Rule 1, no category error.} Do not report the absence of such a derivation as a flaw or a doubt.',
    '\\textbf{Rule 1, no category error.} Do not report the absence of a forward derivation of $\\LE(\\Zz)$ from $\\LE(\\Rec\\,\\Zz)$ as a flaw or a doubt.')
rep('F-21', 'A demand for the transport is a demand for the hypothesis as a lemma of its own proof. Evaluate the printed theorems at their tiers and cones.',
    'A demand for that transport as a lemma is a demand for the hypothesis as a lemma of its own proof (' + tt('mathlib_transfer_status') + '). Evaluate the printed theorems at their tiers and cones.')
rep('F-21', 'The second reports the absence of such a proof as a flaw; that report demands the transport of ' + tt('transport_zeta') + ', the hypothesis in fixed-point form, as a lemma of its own proof, and ignores the theorem-grade block on the unconditional route.',
    'The second reports the absence of such a proof as a flaw in the formal closure; that report demands the transport of ' + tt('transport_zeta') + ', which is the hypothesis in fixed-point form, as a lemma of the closure\'s own proof, and ignores the theorem-grade block on the unconditional route.')
# ---- F-4: the master closure binds what it binds
rep('F-4', 'A master closure binds every division into one theorem with cone [\\texttt{propext}, \\texttt{Classical.\\allowbreak{}choice}, \\texttt{Quot.\\allowbreak{}sound}].}',
    'A master closure binds the shared foundation, the apparatus cargo, the discrete arch and the eleven-part complex binding into one theorem with cone [\\texttt{propext}, \\texttt{Classical.\\allowbreak{}choice}, \\texttt{Quot.\\allowbreak{}sound}]; the physical capstones stand beside it, pinned at the empty cone.}')
rep('F-4', 'and the file pins it. Every division of the file is bound into this one theorem.',
    'and the file pins it. Each of the four divisions of Table~1 enters by at least one conjunct: the shared foundation by its root, its forcing premise and its discrete block; the physical side by the apparatus cargo of Part~VIII-b, its capstones of Parts~VII and VIII standing beside the master theorem as separately pinned theorems with empty cones; the formal side by the discrete arch and the complex binding; and the united locus is the theorem itself.')
rep('F-4', 'and the master closure of every division at the cone of Lean\'s three standard axioms.',
    'and the master closure binding the foundation, the cargo and the formal arch at the cone of Lean\'s three standard axioms.')
rep('F-4', 'The formal architecture of this paper is bound into one machine-checked theorem of the deposited file, and the two boxes below state that theorem and the positions open to a reader who rejects it.',
    'The formal closure, the discrete foundation and the apparatus cargo of this paper are bound into one machine-checked theorem of the deposited file, the physical capstones standing beside it as separately pinned theorems; the two boxes below state that theorem and the positions open to a reader who rejects it.')
# ---- F-3 / F-19 / F-22: one locus, the line; the record on it; the discrete schema and the complex reading
rep('F-3', 'Both closures terminate on one locus, the registered record of the zeros on the critical line, where the physical least-erasure bit and the formal least-erasure bit fall together.',
    'Both closures terminate on one locus, the critical line, the neutral sector of the carrier on the physical side and the registered record of the zeros on the formal side, where the physical least-erasure bit and the formal least-erasure bit fall together.')
rep('F-3', 'Both closures terminate on one object. Write', 'Both closures terminate on one locus. Write')
rep('F-3', 'The locus is $\\Rec(\\Zz)$, the registered record of the nontrivial zeros. On the physical side',
    'The locus is the critical line: $d = 0$ on the discrete chart of the physical closure, $\\operatorname{Re} s = 1/2$ on the complex chart of the formal closure, the two identified by the chart homomorphism of Section~7.3; on it stands $\\Rec(\\Zz)$, the registered record of the nontrivial zeros. On the physical side')
rep('F-3', 'and the reading $\\mathrm{ClassicalRH} \\leftrightarrow \\Val(Z_\\zeta)$ is the one identification the reader grants; over $\\mathbb{C}$ Section~3 proves it for Mathlib\'s sentence.',
    'and the reading $\\mathrm{ClassicalRH} \\leftrightarrow \\Val(Z_\\zeta)$ is the one identification the reader grants, entered as the printed premise $h_{\\mathrm{read}}$ of a theorem schema in $\\mathrm{ClassicalRH}$ and $Z_\\zeta$. Over $\\mathbb{C}$, Section~3 proves the corresponding reading for Mathlib\'s sentence as ' + tt('h_read_proved') + ', a theorem of the complex chart that the discrete schema does not consume; the chart homomorphism of Section~7.3 carries the discrete line onto $\\operatorname{Re} s = 1/2$.')
rep('F-22', 'the record $\\Rec(\\Zz)$ is a self-verifying fixed point, and the hypothesis is locked',
    'the record $\\Rec(\\Zz)$ is a fixed point of the registration whose least erasure is self-verifying, and the hypothesis is locked')
# ---- F-14: carry, hashes, Part IX
rep('F-14', 'carried verbatim and compiled in core Lean with no import. It runs the same calculus',
    'carried into the master with the two recursion theorems of Section~8.2 appended in v3.0.7, as the file header records, and using nothing from Mathlib. It runs the same calculus')
rep('F-14', 'Parts I, II, III, IV-b, IV-c and IX are earlier files carried verbatim, each with the SHA-256 of its source recorded in the header; their internal theorems compile in core Lean with no import.',
    'Parts I, II, III, IV-b and IV-c are earlier files carried verbatim, each with the leading sixteen hexadecimal digits of its source\'s SHA-256 recorded in the header, and Part IX is an earlier file carried with two theorems appended in v3.0.7; their theorems use nothing from Mathlib.')
rep('F-14', 'each earlier file enters as a part, unchanged, with its SHA-256 in the header, and new law is appended after it',
    'each earlier file enters as a part, unchanged, with the leading digits of its SHA-256 in the header, and new law is appended after it')
# ---- F-15
rep('F-15', 'The last theorem is the only one of the physical closure whose cone is not empty, because the step from a failed universal to its witness is classical.',
    'The last theorem is the only one of the physical closure as stated in this section whose cone is not empty, because the step from a failed universal to its witness is classical, as it is in the file\'s bound bundles ' + tt('the_hardened_closure') + ' and ' + tt('the_physico_formal_closure') + ', which this paper does not state and the capstones do not consume.')
# ---- F-16
rep('F-16', 'each premise printed in a theorem signature, none carried by a structure.',
    'each premise printed in a theorem signature, the measurement entering as the certificate field of the bound structure the signature takes.')
# ---- F-17
rep('F-17', 'that an off-line zero is realized as a charged state, that its annihilation erases one label',
    'that the carrier of an off-line zero is charged, realization itself remaining the printed premise $h_{\\mathrm{realize}}$, that its annihilation erases one label')
# ---- F-23
rep('F-23', 'because Mathlib\'s sentence and $\\Val(\\Zz)$ are the same sentence.', 'because Mathlib\'s sentence and $\\Val(\\Zz)$ are the same sentence up to currying.')
# ---- F-24: listing ranges and label
rep('F-24', '\\listing{loop}{The self-grounding recursion and the five-way loop (X-d)}{11299}{11398}', '\\listing{loop}{The self-grounding recursion and the five-way loop (X-d)}{11299}{11401}')
rep('F-24', '\\listing{bound}{The certified bound, the detection gap, the signal floor (Part VIII-e)}{10023}{10048}', '\\listing{bound}{The certified bound, the detection gap, the signal floor (Part VIII-e)}{10023}{10053}')
rep('F-24', '\\listing{exit}{The one exit is a second register (Part VIII-f)}{10215}{10232}', '\\listing{exit}{The one exit is a second register (Part VIII-h)}{10215}{10232}')
# ---- F-25: Table 1 namespaces
rep('F-25', 'Shared foundation & I to VI & \\texttt{TOE0}, \\texttt{PrimeFreedom}, \\texttt{RememberedOffered}, \\texttt{Hinge}, \\texttt{ForceWitness}, \\texttt{TimeLocus}, \\texttt{ArrowSide}, \\texttt{Charts}, \\texttt{BothSides} &',
    'Shared foundation & I to VI & \\texttt{TOE0}, \\texttt{PrimeFreedom} (with \\texttt{HeatFlow}, \\texttt{Liouville}, \\texttt{Carrier} nested), \\texttt{RememberedOffered}, \\texttt{RHUnicorn}, \\texttt{Hinge}, \\texttt{ForceWitness}, \\texttt{TimeLocus}, \\texttt{Judge}, \\texttt{ArrowSide}, \\texttt{Charts}, \\texttt{BothSides} &')
# ---- F-26: the charts of the discrete parts
rep('F-26', 'Parts I to IX work on the discrete offset chart $\\mathbb{Z}\\times\\mathbb{Z}$, a point $(d,t)$ being offset $d$ from the line at height $t$, with $\\fold(d,t) = (-d,t)$, $\\reg(d,t) = (0,t)$ and $\\mathrm{onLine}(d,t) \\leftrightarrow d = 0$.',
    'Parts III, IV-b, VII, VIII and IX work on the discrete offset chart $\\mathbb{Z}\\times\\mathbb{Z}$, a point $(d,t)$ being offset $d$ from the line at height $t$, with $\\fold(d,t) = (-d,t)$, $\\reg(d,t) = (0,t)$ and $\\mathrm{onLine}(d,t) \\leftrightarrow d = 0$; Part I carries no chart, and the other discrete parts place their line at other abscissae with their own folds.')
# ---- F-27
rep('F-27', 'witnessed by the nonzero associator of $e_1, e_2, e_4$,', 'witnessed, in the Cayley--Dickson labeling with $e_1 e_2 = e_3$, $e_1 e_4 = e_5$ and $e_2 e_4 = e_6$, by the associator of $e_1, e_2, e_4$, which is $2e_7$,')
# ---- F-28
rep('F-28', 'the hypothesis forces the line and is the weakest forcing premise on the prime-side chart (' + tt('PrimeFreedom.rh_is_the_weakest_forcing_premise') + ');',
    'the hypothesis forces the line on the prime-side chart, the forcing half of ' + tt('PrimeFreedom.rh_is_the_weakest_forcing_premise') + ';')
# ---- F-29
rep('F-29', 'the scribe attempts to build the closed term from the loop and records the goal the kernel returns;',
    'the scribe attempts to build the closed term from the loop and records the goal the kernel returns, as the file header does at lines 119 to 129 for the attempt named ' + tt('rh_from_the_cargo_loop') + ', a failed attempt being recordable only as a comment in a file that compiles;')
# ---- F-30
rep('F-30', 'and $T_0 = 2725$\\,mK:', 'and the kernel\'s CMB constant \\texttt{cmb\\_\\allowbreak{}mK} $= 2725$\\,mK:')
# ---- M3 precision: the Mathlib release
rep('M3', 'compiled under Lean 4.19.0 with the Mathlib release compatible with that toolchain, exit code 0,', 'compiled under Lean 4.19.0 with Mathlib v4.19.0, the release the file\'s terminal block names, exit code 0,')
rep('M3', 'the file compiles under Lean 4.19.0 with the Mathlib release compatible with that toolchain, exit code 0,', 'the file compiles under Lean 4.19.0 with Mathlib v4.19.0, the release the file\'s terminal block names, exit code 0,')
# ---- F-8: the chip legend, the pin sentences
rep('F-8', 'and the axiom cone that the compiler printed and the file pins under \\texttt{\\#guard\\_msgs}: \\cE{} for a proof using no axiom at all, \\cP{} for [\\texttt{propext}], \\cPQ{} for [\\texttt{propext}, \\texttt{Quot.\\allowbreak{}sound}], and \\cPCQ{} for [\\texttt{propext}, \\texttt{Classical.\\allowbreak{}choice}, \\texttt{Quot.\\allowbreak{}sound}], the three axioms of Lean\'s own standard library and nothing else.',
    'and the axiom cone: \\cE{} for a proof using no axiom at all, \\cP{} for [\\texttt{propext}], \\cPQ{} for [\\texttt{propext}, \\texttt{Quot.\\allowbreak{}sound}], and \\cPCQ{} for [\\texttt{propext}, \\texttt{Classical.\\allowbreak{}choice}, \\texttt{Quot.\\allowbreak{}sound}], the three axioms of Lean\'s core and nothing else. A cone is printed exact when the identifier is pinned under \\texttt{\\#guard\\_msgs} in the file, or when a pinned theorem with an empty cone consumes it, which forces its cone empty; a head none of whose identifiers carries such a receipt shows cone $\\subseteq$ \\cPCQ{}, the bound every theorem of the file satisfies by its compile with no \\texttt{sorry} and no declared axiom; and an identifier that is not pinned carries a dagger. Appendix~A.3 lists every daggered identifier with its receipt.')
rep('F-8', 'Second, the pin discipline: every theorem the paper cites has its axiom cone printed by the compiler and pinned under \\texttt{\\#guard\\_msgs}, so that the cone is a compiler assertion rather than a claim, and a cone that moves breaks the build;',
    'Second, the pin discipline: every capstone the paper cites has its axiom cone printed by the compiler and pinned under \\texttt{\\#guard\\_msgs}, 563 pins in all, so that a pinned cone is a compiler assertion rather than a claim, and a cone that moves breaks the build; of the ninety-one theorem identifiers this paper cites, thirty-eight are pinned, and Appendix~A.3 states the receipt of each of the rest;')
rep('F-8', 'zero user-declared axioms, and every cited cone is pinned under \\texttt{\\#guard\\_msgs}. Second,',
    'zero user-declared axioms, every cited capstone cone is pinned under \\texttt{\\#guard\\_msgs}, and the receipt of each unpinned identifier is the one Appendix~A.3 states. Second,')

for fid, old, new in R:
    n = s.count(old)
    assert n == 1, (fid, n, old[:90])
    s = s.replace(old, new)

# ---- F-8: chips and daggers on the heads, from chip_plan.json
plan = json.load(open('chip_plan.json'))
s = s.replace('\\newcommand{\\chip}[2]{', '\\newcommand{\\dg}{\\textsuperscript{\\textdagger}}\n\\newcommand{\\chipB}[2]{{\\normalfont\\scriptsize\\color{accent}[\\textsc{tier}\\,#1\\;\\textperiodcentered\\;\\textsc{cone}\\,$\\subseteq$\\,#2]}}\n\\newcommand{\\chip}[2]{', 1)
lines = s.split('\n')
# tex line numbers in the plan refer to paper_v1.tex; the macro insertion added 2 lines above every head, replacements above never add lines
off = 2
def norm(x): return x.replace('\\_\\allowbreak{}', '_').replace('.\\allowbreak{}', '.')
for p in plan:
    i = p['texline'] - 1 + off
    line = lines[i]
    assert line.lstrip().startswith('\\begin{'), (p['texline'], line[:60])
    for full, kind, cone in p['ids']:
        if kind == 'pinned': continue
        short = full.split('.')[-1]
        pat = re.compile(r'(\\texttt\{(?:[^{}]|\{\})*\})')
        done = False
        def sub(m):
            global done
            if done: return m.group(1)
            inner = norm(m.group(1)[8:-1])
            if inner == short or inner.endswith('.' + short):
                done = True; return m.group(1) + '\\dg{}'
            return m.group(1)
        line = pat.sub(sub, line)
        assert done, (p['texline'], short)
    if p['new'][0] == 'chipB':
        line, k = re.subn(r'\\chip\{(\w)\}\{[^}]*\}', lambda m: '\\chipB{' + m.group(1) + '}{\\cPCQ}', line)
        assert k == 1, (p['texline'], k)
    lines[i] = line
s = '\n'.join(lines)

# ---- F-8: Appendix A.3 receipts paragraph, inserted before "Verification in one minute"
res = json.load(open('chip_resolution.json'))
forced = [o for o in res if not o['pinned'] and o['bound'] == 'empty']
bounded = [o for o in res if not o['pinned'] and o['bound'] == 'pcq']
glob = [o for o in res if not o['pinned'] and o['bound'] is None]
def nm(full): return tt(full.split('.', 1)[1] if full.count('.') else full)
def by(o): return tt(o['bound_by'].split('.', 1)[1])
para = ('\\paragraph{Receipts of the unpinned identifiers.} Of the ninety-one theorem identifiers cited in theorem heads, thirty-eight are pinned under \\texttt{\\#guard\\_msgs} and the head prints the pinned cone. '
        'For the rest the receipt is one of three, by the kernel\'s dependency rule that a theorem\'s cone contains the cone of every constant its proof uses. '
        'Forced empty by a pinned consumer with an empty cone: ' + '; '.join(nm(o['full']) + ' by ' + by(o) for o in forced) + '. '
        'Bounded within \\cPCQ{} by a pinned consumer: ' + '; '.join(nm(o['full']) + ' by ' + by(o) for o in bounded) + '. '
        'Bounded within \\cPCQ{} by the compile alone, no pinned theorem consuming them: ' + ', '.join(nm(o['full']) for o in glob) + '. '
        'The namespaces are those of the sections that cite them, \\texttt{BoundChainMathlib} for Sections 2 to 7 and the physical namespaces of Table~1 for Section 9. A pin for each of these fifty-three identifiers is a one-line addition to the file; this paper states their cones at the receipts the deposited version carries.\n\n')
anchor = '\\Needspace*{3.5\\baselineskip}\\subsection{Verification in one minute}'
assert s.count(anchor) == 1
s = s.replace(anchor, para + anchor)
pathlib.Path('../build/paper.tex').write_text(s, encoding='utf-8')
pathlib.Path('paper_v2_candidate.tex').write_text(s, encoding='utf-8')
print('replacements', len(R), 'heads processed', len(plan), 'unpinned', len(forced), len(bounded), len(glob))

# ---- sweep specs, phrase-level, on the Markdown rendering
specs = {
 'F-9_F-10': {'banned': ['834 theorems', '564 compiler-pinned', 'pins 564', '564 axiom cones'], 'required': ['833 theorems', '563 compiler-pinned']},
 'F-11': {'banned': ['820 theorems'], 'required': ['778 theorems of Parts I to IX']},
 'F-5': {'banned': ['and to the eleven-part binding'], 'required': ['bound with ten further results into the eleven-part conjunction']},
 'F-6': {'banned': ['the one premise proved keyed', 'the one keyed premise'], 'required': ['premises proved keyed']},
 'F-2': {'banned': ['the bit is a theorem (`cargo_at_zeros`)'], 'required': ['is a theorem (`cargo_at_zeros`)']},
 'F-7': {'banned': ['record-invariant predicate carries it', 'record-invariant predicate supplies it'], 'required': ['forces the value on every reflection-closed configuration']},
 'F-21': {'banned': ['absence of such a derivation', 'A demand for the transport is a demand'], 'required': ['A demand for that transport as a lemma']},
 'F-4': {'banned': ['binds every division', 'Every division of the file is bound', 'master closure of every division', 'The formal architecture of this paper is bound'], 'required': ['enters by at least one conjunct']},
 'F-3_F-19': {'banned': ['Both closures terminate on one object', 'The locus is $\\mathrm{Rec}(\\mathrm{ZetaZeros})$, the registered record', 'proves it for Mathlib'], 'required': ['The locus is the critical line']},
 'F-22': {'banned': ['is a self-verifying fixed point'], 'required': ['whose least erasure is self-verifying']},
 'F-14': {'banned': ['carried verbatim and compiled in core Lean with no import', 'each with the SHA-256 of its source recorded', 'with its SHA-256 in the header'], 'required': ['leading sixteen hexadecimal digits']},
 'F-15': {'banned': ['the only one of the physical closure whose cone is not empty'], 'required': ['as stated in this section whose cone is not empty']},
 'F-16': {'banned': ['none carried by a structure'], 'required': ['certificate field of the bound structure']},
 'F-17': {'banned': ['an off-line zero is realized as a charged state'], 'required': ['the carrier of an off-line zero is charged']},
 'F-23': {'banned': ['are the same sentence.'], 'required': ['the same sentence up to currying']},
 'F-24': {'banned': ['(Part VIII-f)** (master lines 10215', 'master lines 11299 to 11398', 'master lines 10023 to 10048'], 'required': ['master lines 11299 to 11401', 'master lines 10023 to 10053', '(Part VIII-h)']},
 'F-25': {'banned': [], 'required': ['`RHUnicorn`', '`Judge`', '`HeatFlow`']},
 'F-26': {'banned': ['Parts I to IX work on the discrete offset chart'], 'required': ['Parts III, IV-b, VII, VIII and IX work on the discrete offset chart']},
 'F-27': {'banned': ['witnessed by the nonzero associator'], 'required': ['which is $2e_7$']},
 'F-28': {'banned': ['forces the line and is the weakest forcing premise'], 'required': ['the forcing half of']},
 'F-29': {'banned': ['records the goal the kernel returns;'], 'required': ['lines 119 to 129']},
 'F-30': {'banned': ['$T_0 = 2725$'], 'required': ['`cmb_mK` $= 2725$'] },
 'F-8': {'banned': ['every theorem the paper cites has its axiom cone printed by the compiler and pinned', 'every cited cone is pinned', 'the axiom cone that the compiler printed and the file pins'], 'required': ['Receipts of the unpinned identifiers', 'carries a dagger']},
 'M3': {'banned': ['the Mathlib release compatible with that toolchain'], 'required': ['Mathlib v4.19.0']},
}
for k, v in specs.items():
    json.dump(v, open(f'audit_twinbinder/sweep_r1_{k}.json', 'w'), indent=1)
print('sweep specs written', len(specs))
