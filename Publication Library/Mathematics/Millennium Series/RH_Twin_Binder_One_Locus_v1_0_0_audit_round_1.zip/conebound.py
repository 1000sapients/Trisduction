import re, json
F=open('RH_Both_Sides_Formal_Master_v3.0.8.lean',encoding='utf-8').read().splitlines()
N=len(F)
# namespace tracking (stack) and declarations
decl_re=re.compile(r'^\s*(?:@\[[^\]]*\]\s*)?(?:private |protected )?(?:noncomputable )?(theorem|lemma|def|abbrev|structure|inductive|instance|example)\s+([\w.₀\'!?]+)')
decls=[]  # (full, short, kind, start)
ns=[]
depth_comment=0
for i,l in enumerate(F,1):
    s=l.strip()
    # crude block-comment tracking
    if depth_comment==0:
        m=re.match(r'^namespace\s+([\w.]+)',s)
        if m: ns.append(m.group(1)); continue
        m=re.match(r'^end\s+([\w.]+)',s)
        if m and ns and ns[-1]==m.group(1): ns.pop(); continue
        m=decl_re.match(l)
        if m:
            short=m.group(2); full='.'.join(ns+[short]) if ns else short
            decls.append([full,short,m.group(1),i])
    depth_comment+=l.count('/-')-l.count('-/')
    if depth_comment<0: depth_comment=0
for k in range(len(decls)):
    decls[k].append(decls[k+1][3]-1 if k+1<len(decls) else N)
by_full={d[0]:d for d in decls}
# pins
pins={}
for i,l in enumerate(F,1):
    m=re.match(r"/-- info: '([\w.₀]+)' (?:does not depend on any axioms|depends on axioms: \[(.*?)\]) -/",l)
    if m: pins[m.group(1)]=(m.group(2) or '',i)
# body words
def strip_comments(lines):
    out=[]; depth=0
    for l in lines:
        res=''; i=0
        while i<len(l):
            if depth==0 and l.startswith('--',i): break
            if l.startswith('/-',i): depth+=1; i+=2; continue
            if l.startswith('-/',i) and depth>0: depth-=1; i+=2; continue
            if depth==0: res+=l[i]
            i+=1
        out.append(res)
    return out
def body(d):
    return ' '.join(strip_comments(F[d[3]-1:d[4]]))
word=re.compile(r"[A-Za-z_][\w₀'!?.]*")
refs={}
for d in decls:
    ws=set(word.findall(body(d)))
    cand=set()
    nsname=d[0].rsplit('.',1)[0] if '.' in d[0] else ''
    for w0 in ws:
        parts=w0.split('.')
        for k in range(1,len(parts)+1):
            w='.'.join(parts[:k])
            if w in by_full and w!=d[0]: cand.add(w)
            q=(nsname+'.'+w) if nsname else w
            if q in by_full and q!=d[0]: cand.add(q)
    refs[d[0]]=cand
# transitive closure of references from each pinned theorem
import functools
def closure(start):
    seen=set(); stack=[start]
    while stack:
        x=stack.pop()
        for y in refs.get(x,()):
            if y not in seen: seen.add(y); stack.append(y)
    return seen
cones={'':0,'propext':1,'propext, Quot.sound':2,'propext, Classical.choice, Quot.sound':3}
bound={}  # full -> (min cone, by which pinned theorem)
for p,(cone,ln) in pins.items():
    if p not in by_full: continue
    for y in closure(p):
        c=cones.get(cone,9)
        if y not in bound or c<bound[y][0]: bound[y]=(c,p)
json.dump(dict(bound={k:v for k,v in bound.items()},pins=pins),open('conebound.json','w'))
inv={0:'empty',1:'propext',2:'propext, Quot.sound',3:'pcq'}
chk=json.load(open('chipcheck.json'))
# resolve chipped identifiers to full names by section: tex line thresholds
tex=open('paper_v1.tex',encoding='utf-8').read().splitlines()
sec8=next(i for i,l in enumerate(tex,1) if 'section{The Discrete Arch' in l)
sec9=next(i for i,l in enumerate(tex,1) if 'section{The Physical Closure' in l)
sec10=next(i for i,l in enumerate(tex,1) if 'section{The Master Closure' in l)
out=[]
for r in chk['rows']:
    if not r['chip']: continue
    for ident in r['ids']:
        short=ident.split('.')[-1]
        cands=[d[0] for d in decls if d[1]==short and d[2] in ('theorem','def','abbrev','instance')]
        if '.' in ident: cands=[c for c in cands if c.endswith(ident)] or cands
        ln=r['line']
        if ln<sec8: pref='BoundChainMathlib'
        elif ln<sec9: pref='BoundChain'
        elif ln<sec10: pref=None
        else: pref=None
        if pref: c2=[c for c in cands if c.startswith(pref+'.')] 
        else: c2=[c for c in cands if not c.startswith('BoundChain')]
        full=(c2 or cands or [ident])[0]
        pinned=full in pins
        b=bound.get(full)
        out.append(dict(ident=ident,full=full,texline=ln,chip=r['chip'],pinned=pinned,pin_cone=pins[full][0] if pinned else None,bound=inv[b[0]] if b else None,bound_by=b[1] if b else None))
json.dump(out,open('chip_resolution.json','w'),indent=1)
unp=[o for o in out if not o['pinned']]
print('chipped',len(out),'pinned',len(out)-len(unp),'unpinned',len(unp))
for o in unp: print(f"  {o['full']:55s} chip {o['chip']:6s} bound {str(o['bound']):22s} by {o['bound_by']}")
