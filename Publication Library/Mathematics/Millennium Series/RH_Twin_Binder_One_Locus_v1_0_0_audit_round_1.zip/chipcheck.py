import re, json, sys
tex=open(sys.argv[1] if len(sys.argv)>1 else 'paper_v1.tex',encoding='utf-8').read()
F=open('RH_Both_Sides_Formal_Master_v3.0.8.lean',encoding='utf-8').read().splitlines()
pins={}
for i,l in enumerate(F,1):
    m=re.match(r"/-- info: '([\w.₀]+)' (?:does not depend on any axioms|depends on axioms: \[(.*?)\]) -/",l)
    if m:
        full=m.group(1); cone=m.group(2) or ''
        pins.setdefault(full.split('.')[-1],[]).append((full,cone,i))
def norm(s): return s.replace('\\_\\allowbreak{}','_').replace('.\\allowbreak{}','.').replace('\\_','_').replace('\\allowbreak{}','')
heads=[]
for m in re.finditer(r'\\begin\{(theorem|definition|proposition|corollary)\}\[',tex):
    j=m.end(); depth=0
    while j<len(tex):
        c=tex[j]
        if c=='{': depth+=1
        elif c=='}': depth-=1
        elif c==']' and depth==0: break
        j+=1
    opt=norm(tex[m.end():j]); heads.append((m.group(1),opt,m.start()))
cm={'\\cE':'','\\cP':'propext','\\cPQ':'propext, Quot.sound','\\cPCQ':'propext, Classical.choice, Quot.sound'}
rows=[]
for env,opt,pos in heads:
    ids=re.findall(r'\\texttt\{([A-Za-z_][\w.₀]*)\}',opt)
    chip=re.search(r'\\chip\{(\w)\}\{(.*?)\}',opt)
    rows.append(dict(env=env,ids=ids,tier=chip.group(1) if chip else None,chip=chip.group(2).strip() if chip else None,line=tex[:pos].count('\n')+1))
unp=[];mis=[];okc=0;tot=0
for r in rows:
    for ident in r['ids']:
        tot+=1; short=ident.split('.')[-1]
        if short in pins:
            got=[c for _,c,_ in pins[short]]
            chip=r['chip']
            if chip in cm:
                if cm[chip] in got: okc+=1
                else: mis.append((ident,chip,got,r['line']))
            else: okc+=1
        else: unp.append((ident,r['chip'],r['line']))
print('heads',len(heads),'identifiers chipped',tot,'pinned',okc,'mismatch',len(mis),mis)
print('unpinned',len(unp))
for u in unp: print('  ',u)
json.dump(dict(rows=rows,unpinned=unp),open('chipcheck.json','w'))
