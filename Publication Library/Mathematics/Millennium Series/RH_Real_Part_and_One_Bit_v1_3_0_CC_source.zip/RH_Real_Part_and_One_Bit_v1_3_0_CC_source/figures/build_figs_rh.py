#!/usr/bin/env python3
"""The eight page-size figures of RH_Real_Part_and_One_Bit v1.3.0_CC, one per stage of the paper's spine.

Each figure is a self-contained SVG (subset fonts embedded) drawn at 1100 px width, so that at the paper's text width
the smallest type prints near 5 pt. Every monospace identifier is resolved against the index of the master
v3.0.39_CC and colored by its cone; an unresolved name, an ambiguous name or a theorem without a known cone halts.
Usage: python3 build_figs_rh.py
"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad/fig39")
from prims import *  # noqa: F401,F403
import prims

SEAT = {"lines": "15,563", "theorems": "995", "pins": "826", "p0": "426", "p1": "34", "p2": "134", "p3": "232",
        "sha": "d72ef02af72432c7da312eabd6d61c7667f4e7b8bb444c164d00e37b826897cf", "secs": "452"}


def fig_header(num, title):
    h = 54
    rect(0, 0, W, h, NAVY)
    rect(0, h - 4, W, 4, V)
    text(M, 22, f"FIGURE {num}", "s", 700, 11, GOLD, ls="1.2")
    text(M, 42, title, "s", 700, 17, WHITE, ls="0.4")
    rt = "RH: THE REAL PART AND ONE BIT · MASTER v3.0.39_CC · EVERY NAME CHECKED"
    text(W - M, 22, rt, "s", 400, 10, SUB, "end", ls="0.6")
    return h


def legend(y):
    h = 30
    rect(M, y, CW, h, WHITE, LINE, 1, rx=7)
    lx = M + 14
    text(lx, y + 19.5, "READING", "s", 700, 10.4, INK, ls="0.8")
    lx += tw("READING", "s", 700, 10.4) + 18
    for col, lab in [(G, "theorem on no axiom"), (T, "on propext, or propext and Quot.sound"),
                     (B, "on Lean's three standard axioms"), (SLATE, "definition")]:
        rect(lx, y + 9, 12, 12, col, rx=2)
        text(lx + 17, y + 19.5, lab, "s", 400, 10.4, BODY)
        lx += 17 + tw(lab, "s", 400, 10.4) + 18
    text(W - M - 14, y + 19.5, "names shown by their last component", "s", 400, 10.0, GREY, "end")
    return h


def two_col(y, x0, w0, cols, draw, gap=12, tsize=12.2, bsize=11.8, lh=15.4, isize=10.6, ilh=14.4):
    """cols: list of (kicker, color, body, ids). Equal-height side-by-side panels; returns height."""
    n = len(cols)
    cw_ = (w0 - gap * (n - 1)) / n
    blocks = []
    for kick, col, body, ids in cols:
        bl = wrap(body, cw_ - 26, "s", 400, bsize)
        il = id_lines(ids, cw_ - 26, isize) if ids else []
        h = 12 + 14 + 6 + len(bl) * lh + (6 + len(il) * ilh if il else 0) + 10
        blocks.append((kick, col, bl, il, h))
    hh = max(b[4] for b in blocks)
    if draw:
        for j, (kick, col, bl, il, h) in enumerate(blocks):
            x = x0 + j * (cw_ + gap)
            rect(x, y, cw_, hh, WHITE, LINE, 1, rx=7)
            rect(x, y, 4, hh, col)
            text(x + 14, y + 12 + 10, kick, "s", 700, 10.0, col, ls="0.7")
            cy = y + 12 + 14 + 6
            for i, l in enumerate(bl):
                text(x + 14, cy + bsize - 1 + i * lh, l, "s", 400, bsize, BODY)
            cy += len(bl) * lh
            if il:
                ids_draw(x + 14, cy + 6 + isize - 1, il, isize, ilh)
    return hh


def step_band(y, num, title, grade, color, tint, formal, physical, ids_f, ids_p, extra=None, extra_w=0, below=None):
    """One step of the closure table: two readings side by side, an optional drawn panel on the right or below."""
    def lay(y0, draw):
        x0, w0 = M + 14, CW - 28
        wcols = w0 - (extra_w + 12 if extra else 0)
        h = two_col(y0, x0, wcols, [("FORMAL-ALONE", G_D, formal, ids_f), ("PHYSICO-FORMAL", V_D, physical, ids_p)],
                    draw)
        if extra:
            h = max(h, extra(x0 + wcols + 12, y0, extra_w, h, draw))
        if below:
            h += 10 + below(x0, y0 + h + 10, w0, draw)
        h2 = h + 8 + 16
        if draw:
            text(x0 + 2, y0 + h + 8 + 11, "GRADE · " + grade, "s", 700, 10.4, color, ls="0.5")
        return h2
    return band(y, f"STEP {num} · {title}", "", color, tint, lambda: lay(0, False), lambda yy: lay(yy, True),
                pad=12, hh=36)


# ================================================================ FIGURE 1 · THE TEN STEPS AND THE SEAL
STEPS = [
    ("1", "FOUNDATION", "the floor proved; the route blocked", G),
    ("2", "PRIME SIDE", "a free basis; the sign not picked", G),
    ("3", "THE STRIP", "zeros fold-closed in 0 < Re s < 1", G),
    ("4", "THE RECORD", "lossless, self-recursive; B′ proved", G),
    ("5", "UNIDUCTION", "prime and zero sides halt at one bit", G),
    ("6", "HEAT FLOW", "t = 0 remembers; the zone closed", G),
    ("7", "NORMAL FORM", "(B′ → B) ↔ RH; five faces, one bit", G),
    ("8", "REAL PART", "every computed height; finite form", G),
    ("9", "THE WALL", "every zero-bit route refuted", R),
    ("10", "TWO STAGES", "the bit delivered twice", A),
]
TILES = [
    ("I · PROVEN AROUND THE BIT", G, G_T,
     "Steps 1 to 7 and 9: the floor, the prime basis, the strip, the record, the uniduction, the timeless zone and "
     "the normal form, with no premise.", "THEOREM", ["final_formal_closure_complete"]),
    ("II · THE REAL PART", G, G_T,
     "Unconditional at every computed height: a certificate at T gives the real part at T, and at the true zeros "
     "RH is a certificate at every height.", "EVERY COMPUTED HEIGHT",
     ["RHUnicorn.real_part_of_certificate", "rh_iff_certificates"]),
    ("III · THE WALL", R, R_T,
     "Symmetry, the record, computation, existence and the Euler product taken alone: every zero-bit route refuted, "
     "the demand illegal.", "THEOREM", ["RHUnicorn.unicorn_block", "TerminalVerdict.the_open_framing_is_refuted"]),
    ("IV · THE BIT DELIVERED", A, A_T,
     "Supplied by the act, twice: local computation through the cargo loop, and external physics as grand witness.",
     "PREMISE · THE ACT", ["rh_from_the_cargo_loop", "RememberedOffered.physical_kind_delivers"]),
    ("THE FINAL FORM", NAVY, "#e6edf5",
     "The barrier, the finite form at the true zeros and the one bit by height, in one theorem, nothing before "
     "the colon.", "ONE THEOREM", ["the_final_form"]),
]
SEVEN = [
    ("NECESSARY", "RH cannot hold without the bridge; the bridge is RH, and RH is the one bit.",
     ["zeta_ra_loop", "bit_face_identity"]),
    ("SUFFICIENT", "The bridge alone, the one printed premise, gives RH in one kernel step; so does the conservation "
     "field.", ["rh_from_the_cargo_loop", "rh_of_conservation_seat"]),
    ("IRREDUCIBLE", "Nothing the two worlds of one record share decides it: no symmetry, record, computation or "
     "existence.", ["RememberedOffered.the_unconditional_route_is_blocked", "TerminalVerdict.the_open_framing_is_refuted"]),
    ("MANDATORY", "Every route to RH, from any premise, delivers the zero-free half-strip, LookBack and the root read "
     "twice.", ["every_route_passes_the_bit"]),
    ("FUTURE-PROOF", "Any proof of the value, from any premise, is a supply of the act's field; any two are one.",
     ["RememberedOffered.accepting_rh_forces_the_atomic_proof", "RememberedOffered.the_atomic_necessity"]),
    ("NO OTHER PROOF", "Every witness of the value is of both kinds; over ℂ every proof yields the formal kind.",
     ["RememberedOffered.two_kinds_of_witness_and_no_third", "Hardening.no_third_position"]),
    ("TWO KINDS OF ACT", "Local computation, the cargo delivered; external physics, the grand witness: each delivers "
     "the value.", ["RememberedOffered.formal_kind_delivers", "RememberedOffered.physical_kind_delivers"]),
]


def fig1(y):
    # the ten steps
    text(M, y + 12, "THE TEN STEPS OF THE CLOSURE TABLE · EACH READ FORMAL-ALONE AND PHYSICO-FORMAL", "s", 700, 12.6,
         INK, ls="0.5")
    y += 22
    cols, gap = 5, 10
    cw_ = (CW - gap * (cols - 1)) / cols
    ch = 62
    for k, (n, t, d, col) in enumerate(STEPS):
        r, c = divmod(k, cols)
        x, yy = M + c * (cw_ + gap), y + r * (ch + 10)
        rect(x, yy, cw_, ch, WHITE, col, 1.3, rx=7)
        rect(x, yy, 34, ch, col, rx=7)
        rect(x + 26, yy, 8, ch, col)
        text(x + 17, yy + ch / 2 + 7, n, "s", 700, 18 if len(n) == 1 else 15, WHITE, "middle")
        text(x + 44, yy + 22, t, "s", 700, 12.0, INK, ls="0.4")
        for j, l in enumerate(wrap(d, cw_ - 52, "s", 400, 10.8)):
            text(x + 44, yy + 39 + j * 13.8, l, "s", 400, 10.8, BODY)
    y += 2 * ch + 10 + 16
    # the seal
    text(M, y + 12, "THE SEAL  ·  PROVEN  +  THE REAL PART  +  THE WALL  +  THE BIT DELIVERED  =  THE FINAL FORM", "s",
         700, 12.6, INK, ls="0.5")
    y += 24
    OPW = 30
    TW_ = (CW - 4 * OPW) / 5
    tl = [wrap(t[0], TW_ - 16, "s", 700, 11.6) for t in TILES]
    bl = [wrap(t[3], TW_ - 22, "s", 400, 11.8) for t in TILES]
    il = [id_lines(t[5], TW_ - 16, 9.6) for t in TILES]
    hh = 12 + max(len(t) for t in tl) * 15 + 6
    TH = hh + 12 + max(len(b) for b in bl) * 15.8 + 10 + 20 + 10 + max(len(i) for i in il) * 13.6 + 10
    for k, (title, col, tint, body, grade, ids) in enumerate(TILES):
        x = M + k * (TW_ + OPW)
        rect(x, y, TW_, TH, tint, col, 1.6, rx=9)
        rect(x, y, TW_, hh, col, rx=9)
        rect(x, y + hh - 9, TW_, 9, col)
        for j, l in enumerate(tl[k]):
            text(x + TW_ / 2, y + 12 + 11 + j * 15, l, "s", 700, 11.6, WHITE, "middle", ls="0.4")
        cy = y + hh + 12 + 11
        for j, l in enumerate(bl[k]):
            text(x + 11, cy + j * 15.8, l, "s", 400, 11.8, BODY)
        cy += max(len(b) for b in bl) * 15.8
        pill(x + TW_ / 2, cy, grade, col, WHITE, 9.2)
        cy += 20 + 10 + 10
        ids_draw(x + TW_ / 2, cy, il[k], 9.6, 13.6, anchor="middle")
        if k < 4:
            ox = x + TW_ + OPW / 2
            E.append(f'<circle cx="{ox:.1f}" cy="{y + TH / 2:.1f}" r="13" fill="{WHITE}" stroke="{ARROW}" '
                     f'stroke-width="1.8"/>')
            text(ox, y + TH / 2 + 6.5, ["+", "+", "+", "="][k], "s", 700, 18, ARROW, "middle")
    y += TH + 14
    # the one bit
    OB = 74
    rect(M, y, CW, OB, NAVY2, NAVY, 1.2, rx=9)
    text(M + 16, y + 30, "THE ONE BIT", "s", 700, 14, GOLD, ls="1")
    text(M + 150, y + 31, "LeastErasure (Rec ZetaZeros) → LeastErasure ZetaZeros", "m", 700, 18.0, WHITE)
    rich(M + 16, y + 57, [("TheOneBit", "m", 700, PILL_TX),
                          ("   least erasure at the zeros · the bridge B′ → B · printed as a premise, assumed nowhere · "
                           "supplied by the act · delivered twice", "s", 400, SUB)], 12.2)
    resolve("TheOneBit")
    y += OB + 14
    su = [(lambda k, t, b, ids: (lambda w: card(w, t, b, ids, V, tcol=V_D, kicker=f"PROPERTY {k} OF 7", kcol=V,
                                                tsize=13.0, bsize=11.8, lh=15.6, isize=10.0, ilh=13.8)))(k + 1, t, b, ids)
          for k, (t, b, ids) in enumerate(SEVEN)]
    su.append(lambda w: card(w, "FIVE FACES, ONE PROPOSITION",
                             "RH, the made-zero seat, a holding selector, the record's coincidence and the "
                             "conservation field: one bit.", ["the_bit_is_the_proof", "the_barrier_is_one_bit"], NAVY,
                             fill=V_2, tcol=NAVY, kicker="GRADE · THEOREM FOR ALL SEVEN", kcol=NAVY, stroke=V,
                             tsize=13.0, bsize=11.8, lh=15.6, isize=10.0, ilh=13.8))
    y += band(y, "THE ONE BIT · 7 UNIQUE PROPERTIES · EACH A THEOREM", "the_bit_is_the_proof", V, V_T,
              lambda: grid(su, 4, M + 14, 0, CW - 28, draw=False),
              lambda yy: grid(su, 4, M + 14, yy, CW - 28))
    return y


# ================================================================ FIGURE 2 · RIEMANN'S DIVISION MADE EXACT
CLAUSES = [
    ("THE COUNT", "etwa so viel reelle Wurzeln innerhalb dieser Grenzen",
     "about as many real roots within these bounds", "THE REAL PART",
     "counted in 1859; proved here at every computed height, now or in the future", G),
    ("THE PROBABILITY", "es ist sehr wahrscheinlich, dass alle Wurzeln reell sind",
     "it is very probable that all the roots are real", "THE UNICORN PART",
     "the remainder graded probable: no off-line zero above the height", A),
    ("THE PROOF SET ASIDE", "ein strenger Beweis zu wünschen … bei Seite gelassen",
     "a rigorous proof would be desirable; its search set aside", "THE ZERO-BIT ROUTE",
     "the proof from symmetry, the record and computation: closed by theorem", R),
]


def cut_diagram(x, y, w, h):
    """The strip with the line, a cut at height T, the counted zeros below on the line, the unicorn region above."""
    rect(x, y, w, h, WHITE, LINE, 1, rx=8)
    text(x + 14, y + 22, "THE CUT AT HEIGHT T", "s", 700, 11.6, INK, ls="0.6")
    sx0, sx1 = x + 50, x + w - 150
    sy0, sy1 = y + 46, y + h - 40
    rect(sx0, sy0, sx1 - sx0, sy1 - sy0, "#f2f6f8", ARROW, 1.0)
    lx = (sx0 + sx1) / 2
    line(lx, sy0, lx, sy1, G, 2.4)
    text(sx0, sy1 + 16, "Re s = 0", "s", 400, 10.4, GREY, "middle")
    text(sx1, sy1 + 16, "Re s = 1", "s", 400, 10.4, GREY, "middle")
    text(lx, sy1 + 16, "Re s = 1/2", "s", 700, 10.4, G_D, "middle")
    ty = sy0 + (sy1 - sy0) * 0.47
    line(sx0 - 18, ty, sx1 + 12, ty, NAVY, 2.0)
    text(sx1 + 16, ty + 4, "height T", "s", 700, 11, NAVY)
    # below the cut: zeros on the line
    for k in range(7):
        zy = ty + 18 + k * ((sy1 - ty - 26) / 7)
        E.append(f'<circle cx="{lx:.1f}" cy="{zy:.1f}" r="4.2" fill="{G}"/>')
    rect(sx0 + 8, ty + 10, (lx - sx0) - 24, 52, G_T, G, 1, rx=6)
    text(sx0 + 16, ty + 28, "REAL PART AT T", "s", 700, 10.4, G_D, ls="0.4")
    text(sx0 + 16, ty + 43, "finitely many zeros, each", "s", 400, 10.2, BODY)
    text(sx0 + 16, ty + 56, "checked on the line", "s", 400, 10.2, BODY)
    # above the cut: the unicorn region with an off-line pair, dashed
    rect(sx0 + 1, sy0 + 1, sx1 - sx0 - 2, ty - sy0 - 2, A_T)
    line(lx, sy0, lx, ty, G, 2.4)
    py = sy0 + (ty - sy0) * 0.42
    off = (sx1 - sx0) * 0.17
    for px in (lx - off, lx + off):
        E.append(f'<circle cx="{px:.1f}" cy="{py:.1f}" r="5.2" fill="{WHITE}" stroke="{R}" stroke-width="1.8" '
                 f'stroke-dasharray="3 2"/>')
    E.append(f'<path d="M{lx - off + 7:.1f},{py:.1f} L{lx + off - 7:.1f},{py:.1f}" stroke="{R}" stroke-width="1.2" '
             f'stroke-dasharray="4 3" fill="none"/>')
    text(lx, py - 12, "s   and   1 − s̄", "s", 700, 10.4, R_D, "middle")
    text(lx, py + 22, "the denial's object, never exhibited", "s", 400, 10.2, R_D, "middle")
    text(sx0 + 10, sy0 + 18, "UNICORN PART AT T", "s", 700, 10.4, A_D, ls="0.4")
    text(sx0 + 10, sy0 + 33, "no zero above T off the line", "s", 400, 10.2, BODY)
    # the arrow: raising T moves zeros to the real side
    ax = sx1 + 40
    path(f"M{ax:.1f},{ty + 120:.1f} L{ax:.1f},{ty + 26:.1f}", stroke=NAVY, sw=2, marker="arrN")
    for j, l in enumerate(["raise T: zeros", "move to the", "real side,", "never back"]):
        text(ax + 8, ty + 50 + j * 13, l, "s", 400, 9.8, NAVY)
    return h


def fig2(y):
    # the three clauses
    def lay(y0, draw):
        x0, w0 = M + 14, CW - 28
        n = 3
        gap = 14
        cw_ = (w0 - gap * 2) / n
        items = []
        for head, de, en, part, gloss, col in CLAUSES:
            dl = wrap("“" + de + "”", cw_ - 24, "s", 400, 11.4)
            el = wrap(en, cw_ - 24, "s", 400, 11.4)
            gl = wrap(gloss, cw_ - 24, "s", 400, 11.4)
            items.append((head, dl, el, part, gl, col, 12 + 14 + 6 + len(dl) * 14.6 + 4 + len(el) * 14.6 + 8 + 22 + 6
                          + len(gl) * 14.6 + 10))
        hh = max(i[6] for i in items)
        if draw:
            for j, (head, dl, el, part, gl, col, h) in enumerate(items):
                x = x0 + j * (cw_ + gap)
                rect(x, y0, cw_, hh, WHITE, col, 1.3, rx=8)
                text(x + 12, y0 + 22, head, "s", 700, 10.4, col, ls="0.7")
                cy = y0 + 32
                for i, l in enumerate(dl):
                    text(x + 12, cy + 11 + i * 14.6, l, "s", 400, 11.4, INK)
                cy += len(dl) * 14.6 + 4
                for i, l in enumerate(el):
                    text(x + 12, cy + 11 + i * 14.6, l, "s", 400, 11.4, GREY)
                cy += len(el) * 14.6 + 8
                pill(x + 12, cy, part, col, WHITE, 9.4, anchor="start")
                cy += 22 + 6
                for i, l in enumerate(gl):
                    text(x + 12, cy + 11 + i * 14.6, l, "s", 400, 11.4, BODY)
                if j < n - 1:
                    pass
        return hh
    y += band(y, "RIEMANN, NOVEMBER 1859 · ONE SENTENCE, THREE CLAUSES, THREE KINDS", "Wilkins's transcription, p. 4",
              NAVY, "#eef2f7", lambda: lay(0, False), lambda yy: lay(yy, True), pad=12, hh=36, rfam="s")
    y += 14
    # the cut, drawn, and the theorems beside it
    dw = 560
    cards = [
        card(CW - dw - 14, "THE CUT", "At every height T, RH is exactly its real part and its unicorn part: nothing "
             "lost, nothing added, for every zero set with natural heights.", ["RHUnicorn.rh_iff_real_and_unicorn"],
             G, tsize=12.8, bsize=11.8, lh=15.4, isize=10.6),
        card(CW - dw - 14, "MATHLIB'S READING", "RiemannHypothesis holds exactly when every nontrivial zero of "
             "riemannZeta lies on Re s = 1/2.", ["h_read_proved"], B, tsize=12.8, bsize=11.8, lh=15.4, isize=10.6),
        card(CW - dw - 14, "THE TWO PARTS ARE TWO", "At every height a fold-closed world agrees with the line up to "
             "T and carries an off-line pair above it; the offset chart shows it at 3·10¹².",
             ["PrimeFreedom.certified_height_never_forces", "Charts.the_faithful_model_on_the_offset_chart"], A,
             tsize=12.8, bsize=11.8, lh=15.4, isize=10.6),
        card(CW - dw - 14, "NO BYPASS", "Given the real part at T, RH is exactly the unicorn part at T: no route "
             "reaches the whole by aiming at it.", ["RHUnicorn.unicorn_no_bypass"], R, tsize=12.8, bsize=11.8,
             lh=15.4, isize=10.6),
    ]
    ch_ = sum(c.h for c in cards) + 10 * (len(cards) - 1)
    dh = max(ch_, 470)
    cut_diagram(M, y, dw, dh)
    cy = y
    for c in cards:
        c.draw(M + dw + 14, cy)
        cy += c.h + 10
    y += dh + 14
    # the fusion law
    def flay(y0, draw):
        x0, w0 = M + 14, CW - 28
        tags = [("PROVED", G), ("∧", None), ("OPEN", A), ("=", None), ("OPEN", A)]
        if draw:
            xx = x0
            for t, col in tags:
                if col is None:
                    text(xx + 14, y0 + 23, t, "s", 700, 18, ARROW, "middle")
                    xx += 28
                else:
                    wpx = pill(xx, y0 + 8, t, col, WHITE, 10.4, h=22, anchor="start")
                    xx += wpx + 8
            text(xx + 18, y0 + 24, "the real part fused with the unicorn part stands open", "s", 400, 12.0, BODY)
        bl = wrap("A conjunction stands only as high as its weaker part. Every proof of the fused statement contains a "
                  "proof of the unicorn part, and fusion lowers the proved real part to open. Kept apart, the real part "
                  "is asserted exactly as proved and borrows nothing; the remainder is located, not dissolved.",
                  w0 - 8, "s", 400, 12.0)
        if draw:
            for i, l in enumerate(bl):
                text(x0 + 2, y0 + 52 + i * 16, l, "s", 400, 12.0, BODY)
            text(x0 + 2, y0 + 52 + len(bl) * 16 + 8, "GRADE · theorem, on no axiom, in the volume file "
                 "RH_Gold_And_Lead.lean (1.4)", "s", 700, 10.4, A_D, ls="0.4")
        return 40 + len(bl) * 16 + 6 + 22
    y += band(y, "THE FUSION LAW · KEEP THE PARTS APART", "", A, A_T,
              lambda: flay(0, False), lambda yy: flay(yy, True), pad=12, hh=36)
    return y


# ================================================================ FIGURE 3 · STEPS 1 TO 3
def strip_geometry(x, y, w, h, draw):
    if not draw:
        return 0
    rect(x, y, w, h, WHITE, LINE, 1, rx=7)
    text(x + 12, y + 20, "THE FOLD AND REGISTRATION", "s", 700, 10.0, V_D, ls="0.6")
    sx0, sx1 = x + 26, x + w - 26
    sy0, sy1 = y + 34, y + h - 44
    rect(sx0, sy0, sx1 - sx0, sy1 - sy0, "#f2f6f8", ARROW, 1)
    lx = (sx0 + sx1) / 2
    line(lx, sy0, lx, sy1, G, 2.2)
    text(lx, sy1 + 15, "Re s = 1/2", "s", 700, 9.6, G_D, "middle")
    py = sy0 + (sy1 - sy0) * 0.45
    off = (sx1 - sx0) * 0.30
    sxp, fxp = lx + off, lx - off
    E.append(f'<circle cx="{sxp:.1f}" cy="{py:.1f}" r="4.6" fill="{R}"/>')
    E.append(f'<circle cx="{fxp:.1f}" cy="{py:.1f}" r="4.6" fill="{R}"/>')
    E.append(f'<circle cx="{lx:.1f}" cy="{py:.1f}" r="5" fill="{G}"/>')
    path(f"M{sxp - 6:.1f},{py - 8:.1f} Q{lx:.1f},{py - 46:.1f} {fxp + 6:.1f},{py - 8:.1f}", stroke=V, sw=1.6,
         marker="arrP")
    path(f"M{sxp - 6:.1f},{py + 9:.1f} L{lx + 8:.1f},{py + 9:.1f}", stroke=NAVY, sw=1.6, marker="arrN")
    text(sxp + 4, py + 26, "s", "s", 700, 11, R_D, "middle")
    text(fxp - 4, py + 26, "1 − s̄", "s", 700, 11, R_D, "middle")
    text(lx + 30, py - 40, "fold", "s", 700, 10.2, V_D, "start")
    text(lx + 18, py + 24, "reg", "s", 700, 10.2, NAVY, "start")
    text(x + w / 2, sy1 + 27, "reg s = (s + fold s)/2 lies on the line", "s", 400, 9.6, NAVY, "middle")
    return h


def fig3(y):
    y += step_band(y, 1, "FOUNDATION · INDEPENDENCE BLOCKED, THE FLOOR PROVED",
                   "theorem, unconditional; floor, placement, non-crossing and ledger ∅, the sealing rules std", G, G_T,
                   "A Σ₁-complete sound theory proves what computation settles, and a Π⁰₁ hypothesis it cannot refute "
                   "is sealed true. The root holds on the world on the line and on the world off it, so it does not "
                   "cross the line; the six-route ledger is computed from three bits.",
                   "The floor is the self-grounding root: every act re-enacts it, it is a theorem on the constructed "
                   "domain, and freedom, the identity arrow, is inhabited. A universal floor stands on both worlds of "
                   "the bit, so it forces no value.",
                   ["PrimeFreedom.placement", "PrimeFreedom.cant_refute_seals", "PrimeFreedom.independence_forces_truth",
                    "PrimeFreedom.root_does_not_cross_the_line", "PrimeFreedom.route_ledger_is_computed"],
                   ["TOE0.the_master_seal", "TOE0.root_on_the_constructed_domain", "BoundChain.freedom_root_inhabited",
                    "TOE0.the_floor_is_universal"]) + 12
    y += step_band(y, 2, "THE PRIME SIDE · A FREE BASIS AND A MULTIPLICATIVE ARROW",
                   "theorem, unconditional; the aperture ∅, the arithmetic and its keylessness pQ", G, G_T,
                   "Every prime is a two-state fibre of multiplication; Euclid's lemma by least-witness descent; two "
                   "completely additive functions agreeing at the primes agree everywhere, and every assignment "
                   "extends uniquely: the primes are a free basis. λ is completely multiplicative.",
                   "Prime freedom and the arrows force nothing: the basis holds on an explicit formula with positive "
                   "Weil functional and on one without. The aperture opens one bit wide, and it does not spend the "
                   "sign.",
                   ["PrimeFreedom.prime_fibre", "PrimeFreedom.freedom_is_exactly_two", "PrimeFreedom.euclid_lemma",
                    "PrimeFreedom.determined_by_primes", "PrimeFreedom.primes_admit_every_assignment",
                    "PrimeFreedom.liouvilleAll_mul"],
                   ["PrimeFreedom.prime_freedom_forces_nothing", "PrimeFreedom.arrow_forces_nothing",
                    "PrimeFreedom.freedom_does_not_pick_the_sign", "PrimeFreedom.aperture_one_bit_wide"]) + 12
    y += step_band(y, 3, "THE CRITICAL-LINE HINGE AND THE STRIP",
                   "theorem, unconditional, on Lean's standard axioms, which Mathlib's ℂ carries", G, G_T,
                   "From Mathlib's analysis alone: ζ has no zero on Re s ≥ 1, and the reflection carries the bound "
                   "across, so every nontrivial zero lies in 0 < Re s < 1. The zeros are fold-closed and equal to the "
                   "completed zeros; an off-line zero has a twin in the band 1/2 < Re s < 1, so RH is exactly the "
                   "zero-free band.",
                   "Registration is the midpoint of a point and its fold image. Every zero's pair has its midpoint in "
                   "the record; each zero coinciding with its midpoint is exactly RH, and so is Re s ≤ 1/2 at every "
                   "zero. The carrier embeds in ℂ: conjugation to the fold, annihilation to registration.",
                   ["zeta_zeros_in_open_strip", "zeta_zeros_closed", "zeta_zeros_iff_completed",
                    "off_line_zero_has_band_twin", "rh_iff_band_zero_free"],
                   ["reg_eq_midpoint_fold", "zeta_zero_orbit_midpoint", "midpoint_coincidence_iff_rh",
                    "complex_prime_bound_halts", "carrier_embeds_in_complex"],
                   extra=strip_geometry, extra_w=230)
    return y


# ================================================================ FIGURE 4 · STEPS 4 TO 7
def faces_row(x, y, w, draw):
    """TheOneBit as a hub, its five faces in a row, each proved to be it; the_bit_is_the_proof binds them."""
    h = 132
    if not draw:
        return h
    rect(x, y, w, h, WHITE, V, 1.3, rx=8)
    text(x + 14, y + 20, "THE ONE BIT, SEATED · FIVE FACES, ONE PROPOSITION", "s", 700, 10.6, V_D, ls="0.6")
    rich(x + w - 14, y + 20, [("the_bit_is_the_proof", "m", 400, id_color("the_bit_is_the_proof"))], 10.4,
         anchor="end")
    hub_w = 190
    hx, hy, hh_ = x + 14, y + 34, h - 46
    rect(hx, hy, hub_w, hh_, V, V_D, 1.2, rx=8)
    text(hx + hub_w / 2, hy + 30, "TheOneBit", "m", 700, 13, WHITE, "middle")
    resolve("TheOneBit")
    text(hx + hub_w / 2, hy + 50, "least erasure at the zeros:", "s", 400, 10.2, V_2, "middle")
    text(hx + hub_w / 2, hy + 64, "every zero fixed by its", "s", 400, 10.2, V_2, "middle")
    text(hx + hub_w / 2, hy + 78, "retraction onto the line", "s", 400, 10.2, V_2, "middle")
    faces = [("RH ITSELF", "the Mathlib statement", "bit_face_identity"),
             ("THE MADE-ZERO SEAT", "ℂ seated: fold, registration", "bit_face_made_zero"),
             ("A HOLDING SELECTOR", "forcing least erasure", "bit_face_selector"),
             ("RECORD = ZEROS", "the record's coincidence", "bit_face_fixed_point"),
             ("THE FIELD", "defect zero at every zero", "bit_face_conservation")]
    gx = hx + hub_w + 30
    fw = (x + w - 14 - gx - 4 * 8) / 5
    for k, (t1, t2, nm) in enumerate(faces):
        fx = gx + k * (fw + 8)
        rect(fx, hy, fw, hh_, V_T, V, 1, rx=7)
        text(fx + fw / 2, hy + 22, t1, "s", 700, 10.4, V_D, "middle")
        for j, l in enumerate(wrap(t2, fw - 12, "s", 400, 10.0)):
            text(fx + fw / 2, hy + 40 + j * 13, l, "s", 400, 10.0, BODY, "middle")
        rich(fx + fw / 2, hy + hh_ - 12, [(nm, "m", 400, id_color(nm))], 9.6, anchor="middle")
        if tw(nm, "m", 400, 9.6) > fw - 8:
            raise SystemExit("FACE NAME WIDER THAN ITS BOX: " + nm)
    path(f"M{hx + hub_w + 2:.1f},{hy + hh_ / 2:.1f} L{gx - 4:.1f},{hy + hh_ / 2:.1f}", stroke=V, sw=2,
         marker="arrP")
    text(hx + hub_w + 15, hy + hh_ / 2 - 6, "↔", "s", 700, 12, V_D, "middle")
    return h


def fig4(y):
    y += step_band(y, 4, "RETRACTION, REGISTRATION AND THE LOSSLESS RECORD",
                   "theorem, unconditional; the discrete record and Row 4 ∅, the record over ℂ std", G, G_T,
                   "Every point of every record lies on the line; the record of a record is the record; Rec is "
                   "idempotent and the record self-recursive. Every record carries least erasure, and at the zeros the "
                   "cargo loop delivers B′ with no premise. The Pause holds unconditionally.",
                   "Lossless memory: the memory of a memory is the memory, on no axiom. The projection is its own "
                   "fixed point, the cargo recognizes itself, and Row 4 reads the line from the zero side.",
                   ["the_remembered_is_lossless", "rec_idempotent", "record_is_self_recursive",
                    "record_has_least_erasure", "cargo_at_zeros", "pause_is_unconditional"],
                   ["RememberedOffered.the_remembered_is_lossless", "operational_self_recursion",
                    "self_recognition_witness", "RememberedOffered.row_four_from_the_zero_side"]) + 10
    y += step_band(y, 5, "BIDIRECTIONAL HALTED UNIDUCTION",
                   "theorem; acts ∅, faces p, the sweeps pQ, over ℂ std", G, G_T,
                   "Five readings agree on every fold-closed world; the zero report and the prime bound halt at the "
                   "value, one record carrying both worlds; over ℂ no uniform route yields the value.",
                   "The prime act is the zero act; the named faces are the socket; every proof of the value constructs "
                   "the act at the zeros.",
                   ["PrimeFreedom.five_readings_agree", "RememberedOffered.bidirectional_halted_uniduction",
                    "round2_halted_uniduction", "complex_prime_bound_iff_rh"],
                   ["PrimeFreedom.acts_are_one", "PrimeFreedom.named_faces_are_the_socket", "socket_at_zeta_zeros"]) + 10
    y += step_band(y, 6, "THE HEAT FLOW AND THE TIMELESS MONISM ZONE",
                   "theorem; the four names ∅, the flow and the sole witness pQ, the zone and Residual Monism std", G,
                   G_T,
                   "disc(t) = disc(0) + 8t; the width never grows; reality is transported. Time zero remembers and "
                   "every later time forgets, so no readout of the flowed record decides the bit.",
                   "Least erasure, the value, Monism and the co-located root: four names, one proposition. Monism is "
                   "the sole faithful witness, and Residual Monism splits the one record.",
                   ["PrimeFreedom.HeatFlow.disc_flow", "RememberedOffered.flow_monotone",
                    "RememberedOffered.zero_time_remembers", "RememberedOffered.flowed_record_forgets"],
                   ["RememberedOffered.four_names_one_proposition", "RememberedOffered.monism_is_the_sole_witness",
                    "RememberedOffered.the_timeless_zone_closed", "round2_residual_monism"]) + 10
    y += step_band(y, 7, "THE NORMAL FORM · THE AXIS",
                   "theorem, unconditional; the normal form, the cone and the five faces std, the price ∅", G, G_T,
                   "(B′ → B) ↔ RH: the bridge is necessary and sufficient. B′ holds at every record; B is RH. "
                   "Two worlds share one record and both carry B′, while the value holds in one and fails in the "
                   "other: the bit is located, and the seven apex readings are one statement.",
                   "LookBack, every zero fixed by its retraction, is self-recognition and is the bridge. Registration "
                   "is priced: zero heat on the line, one unit per off-line pair, kT·ln 2 per forgotten bit.",
                   ["zeta_ra_loop", "h_id_proved", "apex_cone", "the_self_recognition_closure", "one_record",
                    "registered_has_value", "pair_world_lacks_value"],
                   ["self_recognition_is_look_back", "look_back_is_the_closure", "RememberedOffered.price_zero_iff_value",
                    "PrimeFreedom.landauer_floor_exact"],
                   below=faces_row)
    return y


# ================================================================ FIGURE 5 · STEP 8
CHAIN5 = [
    ("ANALYTIC OFF THE POLE", "ζ analytic on ℂ ∖ {1}; the punctured plane preconnected",
     ["zeta_analyticOnNhd_off_pole", "off_pole_isPreconnected"]),
    ("NO ACCUMULATION OFF THE POLE", "identity theorem, with ζ(2) ≠ 0", ["zeta_zeros_not_accPt_off_pole"]),
    ("NONE AT THE POLE", "(s − 1) ζ(s) → 1", ["zeta_ne_zero_near_pole", "zeta_zeros_not_accPt_pole"]),
    ("ACCUMULATE NOWHERE", "the zeros of ζ have no accumulation point in ℂ", ["zeta_zeros_never_accumulate"]),
    ("FINITELY MANY NONTRIVIAL ZEROS BELOW T", "they lie in the compact [0, 1] × [−T, T]",
     ["zeta_zeros_finite_below", "zeta_zeros_finite_at_height"]),
    ("A COMPLETE LIST AT EVERY HEIGHT", "the nontrivial zeros of height ≤ T, exactly; their set countable",
     ["zeta_zero_list_exists", "zeta_zero_set_countable"]),
    ("CERTIFICATE ↔ REAL PART", "at every height, at the true zeros", ["zeta_certificate_iff_real_part"]),
    ("RH = A CERTIFICATE AT EVERY HEIGHT", "one countable family of finite checks; the one bit the same family",
     ["rh_iff_certificates", "the_one_bit_iff_certificates"]),
]


def rect_zeros(x, y, w, h):
    rect(x, y, w, h, WHITE, LINE, 1, rx=7)
    text(x + w / 2, y + 20, "[0, 1] × [−T, T]", "s", 700, 10.4, B_D, "middle")
    rx0, rx1 = x + 40, x + w - 30
    ry0, ry1 = y + 40, y + h - 34
    rect(rx0, ry0, rx1 - rx0, ry1 - ry0, B_T, B, 1.3)
    lx = (rx0 + rx1) / 2
    line(lx, ry0, lx, ry1, G, 2)
    import random
    rnd = random.Random(7)
    ys = [ry0 + 14 + k * (ry1 - ry0 - 28) / 8 + (rnd.random() - 0.5) * 10 for k in range(9)]
    for yy in ys:
        E.append(f'<circle cx="{lx:.1f}" cy="{yy:.1f}" r="3.6" fill="{G}"/>')
    text(rx0 - 6, ry0 + 4, "T", "s", 700, 10.4, NAVY, "end")
    text(rx0 - 6, ry1 + 4, "−T", "s", 700, 10.4, NAVY, "end")
    text(rx0, ry1 + 15, "0", "s", 400, 9.6, GREY, "middle")
    text(rx1, ry1 + 15, "1", "s", 400, 9.6, GREY, "middle")
    text(x + w / 2, y + h - 8, "finitely many: a list exists", "s", 400, 9.6, B_D, "middle")


def fig5(y):
    def lay(y0, draw):
        x0, w0 = M + 14, CW - 28
        lw = 400
        # left: the schema
        sch = [
            card(lw, "THE SCHEMA, ON NO AXIOM", "A certificate at T, a complete list of the zeros up to T with a check "
                 "that each lies on the line, yields the real part at T, for every zero set with natural heights. No "
                 "computation is an input: each certificate is the hypothesis of its own instance.",
                 ["RHUnicorn.real_part_of_certificate", "RHUnicorn.rh_iff_real_and_unicorn",
                  "RememberedOffered.the_cut_on_the_chart"], G, tsize=12.6, bsize=11.8, lh=15.4, isize=10.6),
            card(lw, "AT ζ, CITED AT THEIR OWN GRADE", "Interval checks are true bounded sentences, theorems of PA and "
                 "ZFC; the evaluation bound of Hardy's function, Turing's method as Lehman corrected it, and the "
                 "Riemann–von Mangoldt count; no real zero. Conjugation is proved in the master.",
                 ["zeta_zeros_conj"], A, tsize=12.6, bsize=11.8, lh=15.4, isize=10.6),
            card(lw, "THE HEIGHT AT ζ", "The height of a zero is ⌈|Im s|⌉, a function of the Im s that registration "
                 "keeps; RH is the real part at every height.", ["zetaHeight", "rh_iff_real_part_at_every_height"], B,
                 tsize=12.6, bsize=11.8, lh=15.4, isize=10.6),
            card(lw, "UNCONDITIONAL AT EVERY COMPUTED HEIGHT", "At every height any computation certifies, now or in "
                 "the future, every nontrivial zero with |Im s| ≤ T lies on the line: a theorem of ZFC.",
                 [], G, fill=G_T, tsize=12.6, bsize=11.8, lh=15.4),
        ]
        hl = sum(c.h for c in sch) + 10 * (len(sch) - 1)
        # right: the finite form chain
        rw = w0 - lw - 16
        cw_ = rw - 190
        boxes = []
        for t, d, ids in CHAIN5:
            tl = wrap(t, cw_ - 20, "s", 700, 11.4)
            dl = wrap(d, cw_ - 20, "s", 400, 11.0)
            il = id_lines(ids, cw_ - 20, 10.2)
            boxes.append((tl, dl, il, 8 + len(tl) * 14 + len(dl) * 13.6 + len(il) * 13.4 + 8))
        arrow_gap = 14
        hr = 26 + sum(b[3] for b in boxes) + arrow_gap * (len(boxes) - 1) + 40
        hh = max(hl, hr)
        if draw:
            cy = y0
            for c in sch:
                c.draw(x0, cy)
                cy += c.h + 10
            rx = x0 + lw + 16
            rect(rx, y0, rw, hh, WHITE, B, 1.3, rx=9)
            text(rx + 12, y0 + 20, "THE FINITE FORM AT THE TRUE ZEROS · FROM MATHLIB'S ANALYSIS", "s", 700, 11.0, B_D,
                 ls="0.5")
            by = y0 + 32
            for k, (tl, dl, il, bh) in enumerate(boxes):
                bx = rx + 12
                fill = NAVY if k == len(boxes) - 1 else B_T
                rect(bx, by, cw_, bh, fill, B, 1, rx=6)
                tcol, dcol = (WHITE, SUB) if fill == NAVY else (B_D, BODY)
                yy = by + 8
                for l in tl:
                    text(bx + 10, yy + 11, l, "s", 700, 11.4, tcol)
                    yy += 14
                for l in dl:
                    text(bx + 10, yy + 10.5, l, "s", 400, 11.0, dcol)
                    yy += 13.6
                if fill == NAVY:
                    LIGHT = {G: "#8fe0c8", T: "#8fd3e6", B: "#a9c8ff", SLATE: "#c8d8e8", GREY: SUB}
                    ids_draw(bx + 10, yy + 10, [[(s, LIGHT[c]) for s, c in ln] for ln in il], 10.2, 13.4)
                else:
                    ids_draw(bx + 10, yy + 10, il, 10.2, 13.4)
                if k < len(boxes) - 1:
                    line(bx + cw_ / 2, by + bh + 1, bx + cw_ / 2, by + bh + arrow_gap - 1, ARROW, 1.6, marker="arr")
                by += bh + arrow_gap
            rect_zeros(rx + 12 + cw_ + 12, y0 + 32, rw - cw_ - 36, 330)
            ids_draw(rx + 12, y0 + hh - 14, id_lines(["rh_finite_form_closure"], cw_ - 20, 10.6), 10.6)
            text(rx + 12 + tw("rh_finite_form_closure", "m", 400, 10.6) + 10, y0 + hh - 14,
                 "binds the chain, nothing before the colon", "s", 400, 10.6, GREY)
        return hh
    y += band(y, "STEP 8 · THE REAL PART, UNCONDITIONAL AT EVERY COMPUTED HEIGHT, AND THE FINITE FORM", "", G, G_T,
              lambda: lay(0, False), lambda yy: lay(yy, True), pad=12, hh=36)
    y += 12

    def fence(y0, draw):
        return two_col(y0, M + 14, CW - 28, [
            ("PHYSICO-FORMAL", V_D, "Every finite computation to height T is a verified world below T: registering its "
             "certified zeros is lossless and costs nothing at any positive temperature, and the compute loop holds "
             "the record's idempotence and the cargo's least erasure with no premise.",
             ["RememberedOffered.price_zero_iff_value", "computational_enactment_capstone"]),
            ("WHAT THE KERNEL DOES NOT DO", R_D, "It re-checks no certificate's numerics and constructs no certificate "
             "at any height: a certificate at T is a computation on ζ, carrying the grade of whoever certifies it. "
             "Read at every height, the family is the bit.", [])], draw)
    y += band(y, "BELOW EVERY CERTIFIED HEIGHT THE BIT IS RECORDED; ABOVE IT, NONE IS", "", NAVY, "#eef2f7",
              lambda: fence(0, False), lambda yy: fence(yy, True), pad=12, hh=36)
    return y


# ================================================================ FIGURE 6 · STEP 9, THE WALL
ALLEY = [
    ("SYMMETRY", "The fold s ↦ 1 − s̄ forces nothing: the pair {14i, 1 + 14i} is closed and off the line.",
     ["the_unconditional_route_is_blocked", "no_closed_principle_decides"]),
    ("THE RECORD OF HEIGHTS", "An even record cannot decide an odd property above any height, in both orientations.",
     ["RHUnicorn.unicorn_block", "RHUnicorn.supply_side_silent", "record_decides_nothing",
      "PrimeFreedom.record_decides_nothing_free"]),
    ("COMPUTATION", "Every certified height is a record; a fold-closed world agrees below T and leaves above.",
     ["PrimeFreedom.certified_height_never_forces", "RememberedOffered.unicorn_blocked_on_the_chart"]),
    ("EXISTENCE", "An inhabited premise leaves the unicorn part exactly where it was.",
     ["RHUnicorn.unicorn_rule_exact", "RHUnicorn.unicorn_no_cure"]),
    ("THE EULER PRODUCT TAKEN ALONE", "Positivity is keyed; with a negative λ in the Euler-product family (cited), "
     "no uniform bridge.", ["PrimeFreedom.positivity_is_keyed", "analytic_route_sealed"]),
    ("COALITIONS OF ATOMS", "No coalition of admissible atoms agrees with RH on every fold-closed world.",
     ["PrimeFreedom.no_coalition_decides"]),
    ("SELF-RECURSION", "Closure does not give it, and the record's self-recursion does not transfer.",
     ["closure_does_not_give_self_recursion", "record_self_recursion_does_not_transfer"]),
    ("SELF-REFERENCE", "A statement self-verifies exactly when it is true: no bit from nothing.",
     ["self_verifying_iff_true"]),
    ("THE TOTAL CHART BLOCK", "On the chart, every premise that forces the value is the value itself or strictly "
     "stronger.",
     ["RememberedOffered.the_unconditional_route_is_blocked"]),
]
CLASSES = [
    ("REFUTED", R, "the unselected schema", "Reflection closure alone gives no value.", ["the_unconditional_route_is_blocked"]),
    ("EXACT", B, "self-grounding at RH", "Nonempty (SelfGrounding RH) ↔ RH.", ["grounding_rh_iff"]),
    ("EXACT", B, "the made-zero seat", "RH ↔ the zeros form a made-zero locus.", ["FTOE.BRIDGE.rh_iff_ftoe_made_zero"]),
    ("REDUCED", A, "the conservation field", "The seat's inhabitation is one statement: the chiral defect vanishes "
     "at every zero.", ["conservation_obligation_zeta"]),
]


def two_worlds(x, y, w, h):
    rect(x, y, w, h, WHITE, LINE, 1, rx=8)
    text(x + 14, y + 22, "WHY THE BLOCK IS A THEOREM · TWO WORLDS, ONE RECORD", "s", 700, 11.0, INK, ls="0.5")
    colw = (w - 60) / 2
    bh = 190
    for k, (lab, sub, ok) in enumerate([("THE REGISTERED WORLD", "{reg p}", True),
                                        ("THE PAIR WORLD", "{p, fold p}", False)]):
        bx = x + 20 + k * (colw + 20)
        by = y + 36
        rect(bx, by, colw, bh, G_T if ok else R_T, G if ok else R, 1.2, rx=7)
        text(bx + colw / 2, by + 18, lab, "s", 700, 10.4, G_D if ok else R_D, "middle", ls="0.5")
        text(bx + colw / 2, by + 33, sub, "s", 400, 10.4, BODY, "middle")
        lx = bx + colw / 2
        line(lx, by + 44, lx, by + bh - 40, G, 2)
        py = by + 44 + (bh - 84) / 2
        if ok:
            E.append(f'<circle cx="{lx:.1f}" cy="{py:.1f}" r="5" fill="{G}"/>')
        else:
            for px in (lx - 34, lx + 34):
                E.append(f'<circle cx="{px:.1f}" cy="{py:.1f}" r="5" fill="{R}"/>')
        text(bx + colw / 2, by + bh - 24, "B′ holds: same record", "s", 400, 10.0, BODY, "middle")
        text(bx + colw / 2, by + bh - 10, "value holds" if ok else "value fails", "s", 700, 10.4,
             G_D if ok else R_D, "middle")
    ty = y + 36 + bh + 20
    for j, l in enumerate(wrap("Both worlds carry B′ and leave one record, while the value holds on the first and "
                               "fails on the second. A route that reads only what the two worlds share answers both "
                               "alike, so it decides neither: the demand for a zero-bit proof asks for a term of a "
                               "type the kernel proves empty.", w - 28, "s", 400, 11.2)):
        text(x + 14, ty + j * 14.6, l, "s", 400, 11.2, BODY)
    ids_draw(x + 14, y + h - 14, id_lines(["one_record", "registered_has_value", "pair_world_lacks_value"], w - 28,
                                          10.4), 10.4)


def fig6(y):
    def lay(y0, draw):
        cards = [(lambda t, b, ids: (lambda w: card(w, t, b, ids, R, icon="✕", tsize=12.4, bsize=11.6, lh=15.0,
                                                    isize=10.4, ilh=14.0)))(*a) for a in ALLEY]
        return grid(cards, 3, M + 14, y0, CW - 28, draw=draw, gap=10, vgap=10)
    y += band(y, "THE DEAD ALLEY · EVERY ZERO-BIT ROUTE REFUTED BY THEOREM", "", R, "#fbf3f2",
              lambda: lay(0, False), lambda yy: lay(yy, True), pad=12, hh=36)
    y += 12
    # two worlds diagram beside the classification
    lw = 430
    rx, rw = M + lw + 14, CW - lw - 14
    rows = []
    for v, col, what, d, ids in CLASSES:
        dl = wrap(d, rw - 150 - 24, "s", 400, 11.2)
        il = id_lines(ids, rw - 150 - 24, 10.4)
        rows.append((v, col, what, dl, il, 10 + max(14, len(dl) * 14.4 + len(il) * 13.8) + 8))
    sel = wrap("Selection stands on the other side of the block: on a configuration whose type carries least erasure "
               "the bridge and the value are theorems, the selection printed in every signature, and a holding zeta "
               "selector exists exactly when RH holds.", rw - 24, "s", 400, 11.2)
    sel_ids = id_lines(["the_conservation_classification_zeta", "zeta_selector_iff_rh",
                        "block_and_selection_coherent_zeta", "rh_unconditional_selected_closure"], rw - 24, 10.4)
    hh = 30 + sum(r[5] for r in rows) + 8 + len(sel) * 14.4 + len(sel_ids) * 13.8 + 14
    hh = max(hh, 340)
    two_worlds(M, y, lw, hh)
    rect(rx, y, rw, hh, WHITE, B, 1.3, rx=9)
    text(rx + 12, y + 20, "THE SCHEMA SPACE AT THE FERTILE SEAT, CLASSIFIED", "s", 700, 11.0, B_D, ls="0.5")
    yy = y + 30
    for v, col, what, dl, il, rh in rows:
        pill(rx + 12, yy + 2, v, col, WHITE, 9.0, h=18, anchor="start")
        text(rx + 12, yy + 36, what, "s", 700, 10.0, INK)
        for j, l in enumerate(dl):
            text(rx + 150, yy + 13 + j * 14.4, l, "s", 400, 11.2, BODY)
        ids_draw(rx + 150, yy + 13 + len(dl) * 14.4, il, 10.4, 13.8)
        line(rx + 12, yy + rh - 3, rx + rw - 12, yy + rh - 3, LINE, 1)
        yy += rh
    yy += 4
    for j, l in enumerate(sel):
        text(rx + 12, yy + 11 + j * 14.4, l, "s", 400, 11.2, BODY)
    ids_draw(rx + 12, yy + 11 + len(sel) * 14.4, sel_ids, 10.4, 13.8)
    y += hh + 12

    def nec(y0, draw):
        return two_col(y0, M + 14, CW - 28, [
            ("EVERY PROOF SUPPLIES THE ACT", V_D, "At every reflection-closed configuration of the chart, every proof of "
             "the value, from any premise, is a supply of the act's field; any two proofs are equal.",
             ["RememberedOffered.the_atomic_necessity", "socket_at_zeta_zeros"]),
            ("EVERY ROUTE PASSES THE BIT", V_D, "Over ℂ every route to RH, from any premise Q, delivers the zero-free "
             "half-strip, LookBack, injective retraction and the root read twice.",
             ["every_route_passes_the_bit", "analytic_route_sealed"]),
            ("RETURN IS FREE, RESISTANCE PAYS", V_D, "A configuration with the value registers at zero heat; one "
             "without it pays at least one unit, kT·ln 2 per forgotten bit.",
             ["RememberedOffered.return_is_free_resistance_pays"])], draw)
    y += band(y, "THE NECESSITY · THE BIT IS EVERY PROOF'S OBLIGATION", "", V, V_T, lambda: nec(0, False),
              lambda yy: nec(yy, True), pad=12, hh=36)
    return y


# ================================================================ FIGURE 7 · THE BIT DELIVERED TWICE
PREMS = ["the chart reading carries LookBack to ζ", "the vacuum realizes the carrier of every read zero",
         "a charged carrier is a population ≥ n₀", "it annihilates at a rate ≥ r₀", "the temperature is ≥ T₀",
         "the residual covers population × rate × heat", "a certified bound R ≤ ε on a dataset",
         "the gap: ε < δ = n₀·r₀·T₀·693147"]


def fig7(y):
    def imp(y0, draw):
        return two_col(y0, M + 14, CW - 28, [
            ("THE IMPASSE", A_D, "Given the real part at T, RH is exactly the unicorn part at T. No registered point "
             "lies off the line, and above every height no reading of an even record decides it: the only door is "
             "the bit.", ["RHUnicorn.unicorn_no_bypass", "PrimeFreedom.unicorn_never_registered",
                          "RHUnicorn.unicorn_block"]),
            ("THE DICHOTOMY", A_D, "The record recurses on itself at every configuration and one record covers two "
             "worlds, so the bit closes only by an act that reads past the record.",
             ["RememberedOffered.the_bit_closes_only_by_an_act_past_the_record"])], draw)
    y += band(y, "STEP 10 · THE UNICORN IMPASSE", "", A, A_T, lambda: imp(0, False), lambda yy: imp(yy, True), pad=12,
              hh=36)
    y += 12
    half = (CW - 14) / 2
    s1 = [
        card(half - 20, "THE CARGO LOOP", "B′ holds, verifies itself, and absorbs every premise; the loop stops at the "
             "record, and the step to the zeros is the bridge.", ["ra_recursion_at_record", "self_recognition_witness"],
             G, tsize=12.4, bsize=11.6, lh=15.0, isize=10.4),
        card(half - 20, "THE ACT", "A reflection-closed configuration with least erasure at it; the canonical bundle "
             "at the record exists for every configuration, and at the zeros the bundle is the bit.",
             ["value_from_the_act", "formal_act", "identification_is_the_proof"], G, tsize=12.4, bsize=11.6, lh=15.0,
             isize=10.4),
        card(half - 20, "THE BRIDGE GIVES RH, THREE WAYS", "By the normal form applied, by self-recognition enforcing "
             "the bridge, and by the terminal capstone, nothing before its colon.",
             ["rh_from_the_cargo_loop", "self_recognition_enforces_bridge", "terminal_self_recursion_capstone"], G,
             tsize=12.4, bsize=11.6, lh=15.0, isize=10.4),
        card(half - 20, "THE FORMAL KIND DELIVERS", "On the chart the cargo carried from the record closes the value, "
             "on no axiom.", ["RememberedOffered.formal_kind_delivers"], G, tsize=12.4, bsize=11.6, lh=15.0,
             isize=10.4),
        card(half - 20, "THE COMPUTATION, WITNESSED", "The kernel checks every step; the sealed volume runs finite "
             "instances of the closure a second time in Fortran, 13,081 checks with zero failures; the closure over "
             "infinite zero sets is checked by the kernel alone.", [], G, fill=G_T, tsize=12.4, bsize=11.6, lh=15.0),
    ]
    pl = [wrap(f"{k + 1} · {p}", half - 40, "s", 400, 11.2) for k, p in enumerate(PREMS)]
    s2 = [
        card(half - 20, "THE CARRIER CLOSES THE UNICORN", "On the act's zero set the unicorn part is closed at every "
             "height; on the actual zeros the reading gives the line and the refuter's absence.",
             ["RememberedOffered.the_unicorn_closed_on_the_act", "PrimeFreedom.the_kinetic_bar"], B, tsize=12.4,
             bsize=11.6, lh=15.0, isize=10.4),
        card(half - 20, "LOOKBACK AND RH IN ONE THEOREM", "From the eight printed premises, through the carrier "
             "closure on the chart, pointwise and on no axiom.",
             ["FormalMasterClosure.physico_formal_supplies_look_back_and_rh",
              "PhysicoFormal.classical_rh_from_physico_formal_closure"], B, tsize=12.4, bsize=11.6, lh=15.0,
             isize=10.4),
        card(half - 20, "THE GRAND WITNESS ERADICATES", "Its premises cannot all stand on a world carrying an off-line "
             "pair; the physical kind delivers the value on no axiom.",
             ["RememberedOffered.the_grand_witness_eradicates_the_unicorn", "RememberedOffered.physical_kind_delivers"],
             B, tsize=12.4, bsize=11.6, lh=15.0, isize=10.4),
    ]
    h1 = 30 + sum(c.h + 8 for c in s1)
    h2 = 30 + 18 + sum(len(p) for p in pl) * 14.2 + 10 + sum(c.h + 8 for c in s2)
    hh = max(h1, h2) + 4
    for k, (title, col, tint, cards) in enumerate([("STAGE 1 · LOCAL COMPUTATION · THE FORMAL KIND", G, G_T, s1),
                                                   ("STAGE 2 · EXTERNAL PHYSICS · THE GRAND WITNESS", B, B_T, s2)]):
        x = M + k * (half + 14)
        rect(x, y, half, hh, tint, col, 1.4, rx=9)
        text(x + 12, y + 21, title, "s", 700, 11.6, col if col != G else G_D, ls="0.5")
        cy = y + 30
        if k == 1:
            text(x + 12, cy + 11, "THE EIGHT PRINTED PREMISES, IN THE KERNEL'S UNITS", "s", 700, 9.8, B_D, ls="0.5")
            cy += 18
            for p in pl:
                for j, l in enumerate(p):
                    text(x + 22, cy + 11, l, "s", 400, 11.2, BODY)
                    cy += 14.2
            cy += 10
        for c in cards:
            c.draw(x + 10, cy)
            cy += c.h + 8
    y += hh + 12

    def kinds(y0, draw):
        return two_col(y0, M + 14, CW - 28, [
            ("TWO KINDS AND NO THIRD", NAVY, "On the chart every witness of the value, from any premise, is a witness "
             "of both kinds, the formal cargo and the physical carrier; over ℂ every proof of RH yields the formal "
             "kind at the zeros, the bridge itself.", ["RememberedOffered.two_kinds_of_witness_and_no_third",
                                                       "RememberedOffered.FormalCargo",
                                                       "RememberedOffered.PhysicalWitness"]),
            ("THE FORCED FORM OF EVERY PROOF", NAVY, "Every proof of the value constructs the act; any two proofs are "
             "one; the form of the field of the value is the form of every proof of the hypothesis.",
             ["RememberedOffered.accepting_rh_forces_the_atomic_proof", "RememberedOffered.the_form_is_the_hypothesis",
              "RememberedOffered.both_values_atomic"]),
            ("THE SAME BIT, AS A FIELD", NAVY, "The conservation field, the chiral defect vanishing at every zero, gives "
             "RH in one term through the made-zero seat.", ["rh_of_conservation_seat",
                                                             "FTOE.BRIDGE.ftoe_closes_mathlib_rh"])], draw)
    y += band(y, "ONE BIT, DELIVERED TWICE · EACH STEP FROM IT A THEOREM", "", NAVY, "#eef2f7",
              lambda: kinds(0, False), lambda yy: kinds(yy, True), pad=12, hh=36)
    return y


# ================================================================ FIGURE 8 · THE VERDICT AND THE FINAL FORM
EXITS = ["closure alone gives no value", "no record-respecting reading decides it",
         "no premise delivers it while either kind fails", "on either kind no point stands off the line",
         "the act is both kinds", "both kinds stand on the registered world, none on its pair world"]
ZEXITS = ["the fold does not force the line; no record-invariant predicate decides",
          "B′ is proved, and the bridge B′ → B is RiemannHypothesis",
          "no premise reaches RiemannHypothesis while the bridge fails",
          "every route delivers the bit in its four readings",
          "on the bridge, RH holds and no zero lies right of the line"]
FRAMING = [("A proof from what every closed configuration shares", "refuted on the chart and over ℂ"),
           ("A decision from the record", "refuted on the chart and over ℂ; above every height silent"),
           ("A route to RH past the bridge", "refuted over ℂ")]
VERDICT = ["1 · the Real Part is proved", "2 · the Unicorn Part is unclosable without the bit",
           "3 · the bridge: necessary, sufficient, irreducible, mandatory, exclusive",
           "4 · delivered twice, by its two kinds", "5 · nothing escapes",
           "6 · the capstones bind it, nothing before the colon"]


def final_nest(x, y, w, draw):
    """the_final_form ⊃ (the barrier ⊃ ...) + finite form + bit by height, drawn as nested boxes."""
    pad = 12
    inner_w = w - 2 * pad
    bw = (inner_w - 2 * 10) / 3
    barrier = [("RH IS THE ONE BIT", ["bit_face_identity"]), ("FIVE FACES, ONE BIT", ["the_bit_is_the_proof"]),
               ("THE CLASSIFICATION", ["the_conservation_classification_zeta"]),
               ("THE FIELD GIVES RH", ["rh_of_conservation_seat"])]
    finite = [("THE ZEROS OF ζ ACCUMULATE NOWHERE", ["zeta_zeros_never_accumulate"]),
              ("NONTRIVIAL ZEROS FINITE BELOW T", ["zeta_zeros_finite_below"]),
              ("NONTRIVIAL ZEROS COUNTABLE", ["zeta_zero_set_countable"]),
              ("CERTIFICATE ↔ REAL PART", ["zeta_certificate_iff_real_part"]),
              ("RH = CERTIFICATES", ["rh_iff_certificates"])]
    def col_h(items, cw):
        return 40 + sum(8 + len(wrap(t, cw - 16, "s", 700, 10.6)) * 13 + len(id_lines(i, cw - 16, 9.8)) * 12.6 + 8 + 4
                        for t, i in items) + 6
    hb = col_h(barrier, bw)
    hf = col_h(finite, bw)
    hbit = 34 + 8 + 13 * 3 + 12.6 * 2 + 16
    ih = max(hb, hf, hbit)
    h = 36 + ih + pad + 22
    if draw:
        rect(x, y, w, h, NAVY, rx=10)
        text(x + pad, y + 23, "THE FINAL FORM · ONE THEOREM, NOTHING BEFORE THE COLON", "s", 700, 12.4, GOLD, ls="0.6")
        rich(x + w - pad, y + 23, [("the_final_form", "m", 700, WHITE)], 11.4, anchor="end")
        resolve("the_final_form")
        for k, (title, items, nm) in enumerate([("THE BARRIER", barrier, "the_barrier_is_one_bit"),
                                                ("THE FINITE FORM AT THE TRUE ZEROS", finite, "rh_finite_form_closure"),
                                                ("THE ONE BIT BY HEIGHT", None, "the_one_bit_iff_certificates")]):
            bx = x + pad + k * (bw + 10)
            by = y + 36
            rect(bx, by, bw, ih, "#e6edf5", NAVY_ST, 1, rx=8)
            text(bx + 10, by + 18, title, "s", 700, 10.2, NAVY, ls="0.5")
            rich(bx + 10, by + 31, [(nm, "m", 700, id_color(nm))], 9.8)
            cy = by + 40
            if items:
                for t, ids in items:
                    tl = wrap(t, bw - 16, "s", 700, 10.6)
                    il = id_lines(ids, bw - 16, 9.8)
                    bh = 8 + len(tl) * 13 + len(il) * 12.6 + 8
                    rect(bx + 8, cy, bw - 16, bh, WHITE, LINE, 1, rx=5)
                    for j, l in enumerate(tl):
                        text(bx + 14, cy + 17 + j * 13, l, "s", 700, 10.6, INK)
                    ids_draw(bx + 14, cy + 17 + len(tl) * 13, il, 9.8, 12.6)
                    cy += bh + 4
            else:
                rows = [("TheOneBit ↔ ∀ T, a certificate at T", True),
                        ("A certificate at T: the complete list of the nontrivial zeros of height at most T, each "
                         "checked on the line.", False),
                        ("The list exists at every height: the finite form.", False),
                        ("The check at every height is the one bit: one countable family of finite statements, "
                         "delivered twice by the act.", False)]
                for s_, bold in rows:
                    for l in wrap(s_, bw - 20, "s", 700 if bold else 400, 10.8):
                        text(bx + 10, cy + 13, l, "s", 700 if bold else 400, 10.8, INK if bold else BODY)
                        cy += 14.2
                    cy += 6
                ids_draw(bx + 10, cy + 10, id_lines(["zetaHeight", "rh_iff_certificates"], bw - 20, 9.8), 9.8, 12.6)
        text(x + pad, y + h - 9, "Bound with the barrier by exact type: the question closed to one bit, the bit seated, "
             "faced, fenced and plugged in.", "s", 400, 10.6, SUB)
    return h


def fig8(y):
    # nothing escapes, two panels
    def ne(y0, draw):
        x0, w0 = M + 14, CW - 28
        cw_ = (w0 - 12) / 2
        el = [wrap("• " + e, cw_ - 30, "s", 400, 11.4) for e in EXITS]
        zl = [wrap("• " + e, cw_ - 30, "s", 400, 11.4) for e in ZEXITS]
        h1 = 30 + sum(len(l) for l in el) * 14.6 + 6 + 16
        h2 = 30 + sum(len(l) for l in zl) * 14.6 + 6 + 16
        hh = max(h1, h2)
        if draw:
            for k, (title, lines_, nm, col) in enumerate([("ON THE CHART · SIX EXITS CLOSED · ON NO AXIOM", el,
                                                           "RememberedOffered.nothing_escapes_on_the_chart", G),
                                                          ("AT THE ZEROS OF ζ · WITH THE NORMAL FORM", zl,
                                                           "nothing_escapes_at_the_zeros", B)]):
                x = x0 + k * (cw_ + 12)
                rect(x, y0, cw_, hh, WHITE, col, 1.3, rx=8)
                text(x + 12, y0 + 20, title, "s", 700, 10.6, col if col != G else G_D, ls="0.5")
                cy = y0 + 30
                for l in lines_:
                    for j, s in enumerate(l):
                        text(x + 14 + (0 if j == 0 else 14), cy + 11, s, "s", 400, 11.4, BODY)
                        cy += 14.6
                ids_draw(x + 12, y0 + hh - 10, id_lines([nm], cw_ - 24, 10.4), 10.4)
        return hh
    y += band(y, "NOTHING ESCAPES", "", NAVY, "#eef2f7", lambda: ne(0, False), lambda yy: ne(yy, True), pad=12, hh=36)
    y += 12
    # open framing refuted + the verdict, side by side
    lw = (CW - 14) / 2
    fl = [(wrap(a, lw - 52, "s", 700, 11.4), wrap(b, lw - 52, "s", 400, 11.0)) for a, b in FRAMING]
    h1 = 30 + sum(len(a) * 14.4 + len(b) * 13.6 + 10 for a, b in fl) + 44
    vl = [wrap(v, lw - 30, "s", 400, 11.4) for v in VERDICT]
    h2 = 30 + sum(len(v) for v in vl) * 15 + 44
    hh = max(h1, h2)
    rect(M, y, lw, hh, WHITE, R, 1.3, rx=9)
    text(M + 12, y + 20, "THE OPEN FRAMING, REFUTED ON EACH COUNT", "s", 700, 11.0, R_D, ls="0.5")
    cy = y + 30
    for a, b in fl:
        text(M + 14, cy + 13, "✕", "s", 700, 13, R)
        for j, l in enumerate(a):
            text(M + 34, cy + 12 + j * 14.4, l, "s", 700, 11.4, INK)
        cy += len(a) * 14.4
        for j, l in enumerate(b):
            text(M + 34, cy + 11 + j * 13.6, l, "s", 400, 11.0, BODY)
        cy += len(b) * 13.6 + 10
    text(M + 12, y + hh - 26, "What remains of the question is the bridge: delivered twice.", "s", 700, 11.0, R_D)
    ids_draw(M + 12, y + hh - 10, id_lines(["TerminalVerdict.the_open_framing_is_refuted"], lw - 24, 10.4), 10.4)
    vx = M + lw + 14
    rect(vx, y, lw, hh, WHITE, NAVY, 1.3, rx=9)
    text(vx + 12, y + 20, "THE TERMINAL VERDICT · §X-t · BOUND BY EXACT TYPE", "s", 700, 11.0, NAVY, ls="0.5")
    cy = y + 30
    for v in vl:
        for j, l in enumerate(v):
            text(vx + 16, cy + 12, l, "s", 400, 11.4, BODY)
            cy += 15
    text(vx + 12, y + hh - 26, "RH is proved by the physico-formal closure.", "s", 700, 11.0, NAVY)
    ids_draw(vx + 12, y + hh - 10, id_lines(["TerminalVerdict.the_terminal_verdict", "the_terminal_certification"],
                                            lw - 24, 10.4), 10.4)
    y += hh + 12
    # the final form
    y += final_nest(M, y, CW, True) + 12
    return y


FOOT = [
    ("WHAT IS PROVED · ", "every theorem of the master, on no axiom or on Lean's standard axioms: the floor, the strip, "
     "the record, the normal form and the five faces, the finite form, the wall and the necessity, the two kinds and "
     "no third, nothing escaping, the barrier and the final form."),
    ("WHAT IS CITED · ", "the analytic lemmas of a certificate, the provability of true bounded sentences, no real "
     "zero, a negative λ in the Euler-product family, the doors' equivalences for ζ, and Landauer's principle, each at "
     "its own grade."),
    ("WHAT IS SUPPLIED · ", "the one bit, by the act at premise grade: printed as a premise, assumed nowhere, delivered "
     "twice, by local computation and by external physics as grand witness."),
    ("SEAT · ", f"RH_Both_Sides_Formal_Master_v3_0_39_CC.lean · sha256 {SEAT['sha']} · {SEAT['lines']} lines · "
     f"{SEAT['theorems']} theorems · {SEAT['pins']} pins ({SEAT['p0']} on no axiom, {SEAT['p1']} on propext, "
     f"{SEAT['p2']} on propext and Quot.sound, {SEAT['p3']} on the standard three) · Lean 4.19.0 · Mathlib v4.19.0 · "
     f"exit 0 in {SEAT['secs']} s · no sorry, no declared axiom, no native_decide"),
]


def receipts(y):
    lines_all = []
    for head, body in FOOT:
        first_w = CW - 36 - tw(head, "s", 700, 11.2)
        out, cur, limit = [], "", first_w
        for w_ in body.split(" "):
            t = (cur + " " + w_) if cur else w_
            if tw(t, "s", 400, 11.2) <= limit or not cur:
                cur = t
            else:
                out.append(cur)
                cur, limit = w_, CW - 36
        if cur:
            out.append(cur)
        lines_all.append((head, out))
    h = 18 + sum(len(l) for _, l in lines_all) * 15.6 + (len(lines_all) - 1) * 5 + 12
    rect(M, y, CW, h, NAVY, rx=9)
    yy = y + 24
    for head, out in lines_all:
        for j, l in enumerate(out):
            if j == 0:
                rich(M + 18, yy, [(head, "s", 700, GOLD), (l, "s", 400, "#dbe6f1")], 11.2)
            else:
                text(M + 18, yy, l, "s", 400, 11.2, "#dbe6f1")
            yy += 15.6
        yy += 5
    return h


# ================================================================ BUILD
def font_face(key, famname, weight):
    chars = "".join(sorted(USED.get(key, set()))) + " "
    tt = TTFont(FONTFILE[key])
    opts = subset.Options()
    opts.flavor = "woff2"
    opts.layout_features = ["kern", "liga"]
    opts.notdef_outline = True
    sub = subset.Subsetter(opts)
    sub.populate(text=chars)
    sub.subset(tt)
    buf = io.BytesIO()
    tt.flavor = "woff2"
    tt.save(buf)
    return (f"@font-face{{font-family:'{famname}';font-weight:{weight};font-style:normal;"
            f"src:url(data:font/woff2;base64,{base64.b64encode(buf.getvalue()).decode()}) format('woff2');}}")


FIGS = [
    (1, "THE TEN STEPS AND THE SEAL", fig1, False),
    (2, "RIEMANN'S DIVISION MADE EXACT", fig2, False),
    (3, "STEPS 1 TO 3 · THE FLOOR, THE PRIME SIDE AND THE STRIP", fig3, False),
    (4, "STEPS 4 TO 7 · THE RECORD, THE UNIDUCTION, THE HEAT FLOW, THE NORMAL FORM", fig4, False),
    (5, "STEP 8 · THE REAL PART AND THE FINITE FORM", fig5, False),
    (6, "STEP 9 · THE WALL AND THE NECESSITY", fig6, False),
    (7, "STEP 10 · THE BIT DELIVERED TWICE", fig7, False),
    (8, "THE VERDICT, THE FINAL FORM AND THE RECEIPTS", fig8, True),
]

if __name__ == "__main__":
    import os
    os.makedirs(OUTDIR, exist_ok=True)
    report, allchecked = [], {}
    only = {int(a) for a in sys.argv[1:]} if len(sys.argv) > 1 else None
    for num, title, body, with_receipts in FIGS:
        if only and num not in only:
            continue
        E.clear(); USED.clear(); CHECKED.clear()
        E.append("BG")
        y = fig_header(num, title) + 12
        y = body(y) + 12
        if with_receipts:
            y += receipts(y) + 10
        y += legend(y) + 12
        H = int(round(y))
        E[0] = f'<rect x="0" y="0" width="{W}" height="{H}" fill="{BG}"/>'
        faces = [font_face(("s", 400), "RHSans", 400), font_face(("s", 700), "RHSans", 700),
                 font_face(("m", 400), "RHMono", 400), font_face(("m", 700), "RHMono", 700)]
        defs = ('<defs>'
                f'<marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
                f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{ARROW}"/></marker>'
                f'<marker id="arrR" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
                f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{R}"/></marker>'
                f'<marker id="arrP" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
                f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{V}"/></marker>'
                f'<marker id="arrN" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
                f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{NAVY}"/></marker>'
                f'<style>{"".join(faces)}</style></defs>')
        import string
        ttl = f"The Riemann Hypothesis: The Real Part and One Bit · Figure {num} · {string.capwords(title.lower())}"
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" '
               f'aria-label="{escape(ttl)}">\n<title>{escape(ttl)}</title>\n{defs}\n' + "\n".join(E) + "\n</svg>\n")
        fn = f"{OUTDIR}/RH_Figure_{num}_v1_3_0_CC.svg"
        open(fn, "w", encoding="utf-8").write(svg)
        allchecked.update(CHECKED)
        report.append((num, H, len(svg), len(CHECKED)))
    json.dump({k: list(v) for k, v in allchecked.items()}, open(OUTDIR + "/checked_ids.json", "w"), indent=0,
              ensure_ascii=False)
    for r in report:
        print(f"Figure {r[0]}: 1100 x {r[1]} px, {r[2]} bytes, {r[3]} names resolved")
    print("total distinct names:", len(allchecked))
