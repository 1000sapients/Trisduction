#!/usr/bin/env python3
"""Drawing primitives for the RH v1.3.0_CC figures (carried from the P ≠ NP v1.13.0 figure builder).
Every monospace identifier is resolved against the index of the master v3.0.39_CC and colored by its cone:
green = theorem on no axiom, teal = theorem on propext or on propext and Quot.sound, blue = theorem on Lean's
standard axioms, slate = definition or structure. An unresolved name, or a theorem without a known cone, halts."""
import base64, io, json, re, sys
from html import escape
from PIL import ImageFont
from fontTools import subset
from fontTools.ttLib import TTFont

SP = "/tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad"
OUTDIR = SP + "/fig39/out"
IDX = json.load(open(SP + "/fig39/kernel_index.json", encoding="utf-8"))
FD = "/usr/share/fonts/truetype/dejavu/"
FONTFILE = {("s", 400): FD + "DejaVuSans.ttf", ("s", 700): FD + "DejaVuSans-Bold.ttf",
            ("m", 400): FD + "DejaVuSansMono.ttf", ("m", 700): FD + "DejaVuSansMono-Bold.ttf"}
FAMILY = {"s": "RHSans, 'DejaVu Sans', Verdana, Arial, sans-serif",
          "m": "RHMono, 'DejaVu Sans Mono', Menlo, Consolas, monospace"}
_PIL = {k: ImageFont.truetype(v, 100) for k, v in FONTFILE.items()}

NAVY, NAVY2, NAVY_ST, PILL_TX, SUB = "#0e2a47", "#1d4066", "#3f6186", "#dcebfb", "#c8d8e8"
BG, INK, BODY, GREY, ARROW, LINE = "#f7f9fa", "#10222e", "#24333d", "#5a6a76", "#33475b", "#c3d2dc"
G, G_T, G_D = "#177e6c", "#e7f4f0", "#0f5c4e"
B, B_T, B_D = "#2f5aa8", "#e9f0fb", "#1e447c"
R, R_T, R_D = "#b3261e", "#fdecea", "#7f1d17"
A, A_T, A_D = "#b7791f", "#fdf3e0", "#7a4a12"
V, V_T, V_2, V_D = "#5b4bc4", "#f1edfd", "#d9d2f7", "#3c3550"
T, T_T, T_D = "#0e7490", "#e4f3f7", "#0b5468"
SLATE, WHITE, GOLD = "#33566e", "#ffffff", "#ffd98a"

W, M = 1100, 22
CW = W - 2 * M
E, USED = [], {}
CHECKED = {}
NB = " "
# preference order when a short name is declared in several namespaces: the paper's convention is that an
# unprefixed name is in BoundChainMathlib
PREF = ["BoundChainMathlib.", "FTOE.BRIDGE.", "FTOE."]


def resolve(name):
    ds = IDX["decl"].get(name.split(".")[-1]) or []
    pick = None
    if "." in name:
        ds = [d for d in ds if d[0] == name or d[0].endswith("." + name)]
        if len({d[0] for d in ds}) > 1:
            raise SystemExit(f"AMBIGUOUS NAME {name}: {[d[0] for d in ds]}")
        if ds:
            pick = ds[0]
    if not ds:
        raise SystemExit("NOT A DECLARATION OF v3.0.39_CC: " + name)
    if pick is None:
        for p in PREF:
            hit = [d for d in ds if d[0] == p + name]
            if hit:
                pick = hit[0]
                break
    if pick is None:
        if len({d[0] for d in ds}) > 1:
            raise SystemExit(f"AMBIGUOUS NAME {name}: {[d[0] for d in ds]}")
        pick = ds[0]
    full, line_, kind = pick
    cone = IDX["cone"].get(full)
    CHECKED[name] = (full, kind, cone, line_)
    return full, kind, cone


def id_color(name):
    full, kind, cone = resolve(name)
    if kind not in ("theorem", "lemma"):
        return SLATE
    if cone is None:
        raise SystemExit("THEOREM WITHOUT A KNOWN CONE: " + full)
    return {"∅": G, "p": T, "pQ": T, "std": B}[cone]
