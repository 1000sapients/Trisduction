"""Index of the RH master v3.0.39_CC: every declaration with its line and kind, and every cone the kernel printed,
guarded (the pin's expected message) or unguarded (the compile output), plus cones printed by the olean probe.
Writes kernel_index.json: {"decl": {short: [[full, line, kind], ...]}, "cone": {full: "∅"|"p"|"pQ"|"std"}}."""
import json, re, sys, os
SP = "/tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad"
LEAN = SP + "/rh39/RH_Both_Sides_Formal_Master_v3_0_39_CC.lean"
sys.path.insert(0, SP + "/rh39/tools")
from codeonly import strip
src = open(LEAN, encoding="utf-8").read()
code = strip(src)
KW = r"(theorem|lemma|def|structure|abbrev|inductive|class|instance)"
decl = re.compile(r"^\s*(?:@\[[^\]]*\]\s*)?(?:private\s+|protected\s+|noncomputable\s+|partial\s+)*" + KW + r"\s+([^\s(:{\[]+)")
st, D = [], {}
for i, l in enumerate(code.split("\n"), 1):
    m = re.match(r"^\s*(namespace|section)\s+(\S+)", l)
    e = re.match(r"^\s*end(?:\s+(\S+))?\s*$", l)
    if m:
        st.append((m.group(1), m.group(2))); continue
    if e:
        if st and st[-1][1] == (e.group(1) or ""):
            st.pop()
        continue
    d = decl.match(l)
    if d:
        ns = ".".join(n for k, n in st if k == "namespace")
        full = (ns + "." + d.group(2)) if ns else d.group(2)
        short = d.group(2).split(".")[-1]
        D.setdefault(short, []).append([full, i, d.group(1)])
        # also index by the name as written with its namespace suffixes (e.g. RHUnicorn.x)
        parts = full.split(".")
        for k in range(1, len(parts)):
            D.setdefault(".".join(parts[k:]), [])
            if [full, i, d.group(1)] not in D[".".join(parts[k:])]:
                D[".".join(parts[k:])].append([full, i, d.group(1)])
def cone_of(s):
    s = s.strip()
    if s == "" or s is None:
        return "∅"
    ax = frozenset(a.strip() for a in s.replace("\n", " ").split(",") if a.strip())
    return {frozenset(): "∅", frozenset({"propext"}): "p", frozenset({"propext", "Quot.sound"}): "pQ",
            frozenset({"propext", "Classical.choice", "Quot.sound"}): "std"}[ax]
C = {}
for m in re.finditer(r"/-- info: '([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms) -/\s*#guard_msgs in\s*#print axioms (\S+)", src):
    C[m.group(1)] = cone_of(m.group(2) or "")
outs = [SP + "/rh39/compile.out"] + ([SP + "/fig39/probe.out"] if os.path.exists(SP + "/fig39/probe.out") else [])
for f in outs:
    for m in re.finditer(r"^'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)", open(f, encoding="utf-8").read(), re.M):
        C.setdefault(m.group(1), cone_of(m.group(2) or ""))
json.dump({"decl": D, "cone": C}, open(SP + "/fig39/kernel_index.json", "w", encoding="utf-8"), ensure_ascii=False)
nthm = sum(1 for v in D.values() for x in v if x[2] == "theorem")
print("declarations indexed:", len({x[0] for v in D.values() for x in v}), "cones known:", len(C))
