#!/usr/bin/env python3
"""Drawing primitives for the RH v1.3.0_CC figures (carried from the P ≠ NP v1.13.0 figure builder).
Every monospace identifier is resolved against the index of the master v3.0.39_CC and colored by its cone:
green = theorem on no axiom, teal = theorem on propext or on propext and Quot.sound, blue = theorem on Lean's
standard axioms, slate = definition or structure. An unresolved name, or a theorem without a known cone, halts."""
import base64, io, json, re, sys
from html import escape
from PIL import ImageFont
from fontTools import subset
from fontTools.ttLib import TTFont

SP = "/tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad"
OUTDIR = SP + "/fig39/out"
IDX = json.load(open(SP + "/fig39/kernel_index.json", encoding="utf-8"))
FD = "/usr/share/fonts/truetype/dejavu/"
FONTFILE = {("s", 400): FD + "DejaVuSans.ttf", ("s", 700): FD + "DejaVuSans-Bold.ttf",
            ("m", 400): FD + "DejaVuSansMono.ttf", ("m", 700): FD + "DejaVuSansMono-Bold.ttf"}
FAMILY = {"s": "RHSans, 'DejaVu Sans', Verdana, Arial, sans-serif",
          "m": "RHMono, 'DejaVu Sans Mono', Menlo, Consolas, monospace"}
_PIL = {k: ImageFont.truetype(v, 100) for k, v in FONTFILE.items()}

NAVY, NAVY2, NAVY_ST, PILL_TX, SUB = "#0e2a47", "#1d4066", "#3f6186", "#dcebfb", "#c8d8e8"
BG, INK, BODY, GREY, ARROW, LINE = "#f7f9fa", "#10222e", "#24333d", "#5a6a76", "#33475b", "#c3d2dc"
G, G_T, G_D = "#177e6c", "#e7f4f0", "#0f5c4e"
B, B_T, B_D = "#2f5aa8", "#e9f0fb", "#1e447c"
R, R_T, R_D = "#b3261e", "#fdecea", "#7f1d17"
A, A_T, A_D = "#b7791f", "#fdf3e0", "#7a4a12"
V, V_T, V_2, V_D = "#5b4bc4", "#f1edfd", "#d9d2f7", "#3c3550"
T, T_T, T_D = "#0e7490", "#e4f3f7", "#0b5468"
SLATE, WHITE, GOLD = "#33566e", "#ffffff", "#ffd98a"

W, M = 1100, 22
CW = W - 2 * M
E, USED = [], {}
CHECKED = {}
NB = " "
# preference order when a short name is declared in several namespaces: the paper's convention is that an
# unprefixed name is in BoundChainMathlib
PREF = ["BoundChainMathlib.", "FTOE.BRIDGE.", "FTOE."]


def resolve(name):
    ds = IDX["decl"].get(name.split(".")[-1]) or []
    pick = None
    if "." in name:
        ds = [d for d in ds if d[0] == name or d[0].endswith("." + name)]
        if len({d[0] for d in ds}) > 1:
            raise SystemExit(f"AMBIGUOUS NAME {name}: {[d[0] for d in ds]}")
        if ds:
            pick = ds[0]
    if not ds:
        raise SystemExit("NOT A DECLARATION OF v3.0.39_CC: " + name)
    if pick is None:
        for p in PREF:
            hit = [d for d in ds if d[0] == p + name]
            if hit:
                pick = hit[0]
                break
    if pick is None:
        if len({d[0] for d in ds}) > 1:
            raise SystemExit(f"AMBIGUOUS NAME {name}: {[d[0] for d in ds]}")
        pick = ds[0]
    full, line_, kind = pick
    cone = IDX["cone"].get(full)
    CHECKED[name] = (full, kind, cone, line_)
    return full, kind, cone


def id_color(name):
    full, kind, cone = resolve(name)
    if kind not in ("theorem", "lemma"):
        return SLATE
    if cone is None:
        raise SystemExit("THEOREM WITHOUT A KNOWN CONE: " + full)
    return {"∅": G, "p": T, "pQ": T, "std": B}[cone]
def tw(s, fam="s", wt=400, size=13.0):
    return _PIL[(fam, wt)].getlength(s) * size / 100.0


def glue(s):
    s = re.sub(r" (≠|∉|∈|≥|≤|<|>|=|\+|→|↔|∧|×) ", lambda m: NB + m.group(1) + NB, s)
    s = re.sub(r"\b(Re|Im) s\b", lambda m: m.group(1) + NB + "s", s)
    s = re.sub(r"(degree|degrees|Parts|Part|seed|grade|Figure|Section|Theorem) (\d)",
               lambda m: m.group(1) + NB + m.group(2), s)
    return s


def wrap(s, maxw, fam="s", wt=400, size=13.0):
    words, lines, cur = glue(s).split(" "), [], ""
    for w_ in words:
        t = (cur + " " + w_) if cur else w_
        if tw(t, fam, wt, size) <= maxw or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = w_
    if cur:
        lines.append(cur)
    for l in lines:
        if tw(l, fam, wt, size) > maxw + 0.5:
            raise SystemExit(f"UNWRAPPABLE LINE ({tw(l, fam, wt, size):.0f} > {maxw:.0f}): {l}")
    return lines


def id_lines(ids, maxw, size=11.2, wt=400):
    sep = " · "
    lines, cur, curw = [], [], 0.0
    for n in ids:
        col = id_color(n)
        shown = n.split(".")[-1]
        wpiece = tw(shown, "m", wt, size)
        if wpiece > maxw + 0.5:
            raise SystemExit(f"IDENTIFIER WIDER THAN ITS BOX: {n}")
        wsep = tw(sep, "m", wt, size) if cur else 0.0
        if cur and curw + wsep + wpiece > maxw:
            lines.append(cur)
            cur, curw, wsep = [], 0.0, 0.0
        if cur:
            cur.append((sep, GREY))
        cur.append((shown, col))
        curw += wsep + wpiece
    if cur:
        lines.append(cur)
    return lines


def note(fam, wt, s):
    USED.setdefault((fam, wt), set()).update(s)


def rect(x, y, w, h, fill, stroke="none", sw=0, rx=0, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    E.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx}" fill="{fill}" '
             f'stroke="{stroke}" stroke-width="{sw}"{d}/>')


def line(x1, y1, x2, y2, stroke=ARROW, sw=2, marker=None):
    mk = f' marker-end="url(#{marker})"' if marker else ""
    E.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{stroke}" stroke-width="{sw}"{mk}/>')


def path(d, fill="none", stroke="none", sw=0, marker=None):
    mk = f' marker-end="url(#{marker})"' if marker else ""
    E.append(f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{mk}/>')


def text(x, y, s, fam="s", wt=400, size=13.0, fill=BODY, anchor="start", ls=None):
    note(fam, wt, s)
    l = f' letter-spacing="{ls}"' if ls else ""
    E.append(f'<text x="{x:.1f}" y="{y:.1f}" font-family="{FAMILY[fam]}" font-size="{size}" font-weight="{wt}" '
             f'fill="{fill}" text-anchor="{anchor}"{l}>{escape(s)}</text>')


def rich(x, y, runs, size=13.0, anchor="start"):
    parts = []
    for s, fam, wt, fill in runs:
        note(fam, wt, s)
        parts.append(f'<tspan font-family="{FAMILY[fam]}" font-weight="{wt}" fill="{fill}">{escape(s)}</tspan>')
    E.append(f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" xml:space="preserve">'
             f'{"".join(parts)}</text>')


def ids_draw(x, y, lines, size=11.2, lh=15.2, wt=400, anchor="start"):
    for i, ln in enumerate(lines):
        rich(x, y + i * lh, [(s, "m", wt, c) for s, c in ln], size=size, anchor=anchor)


def pill(cx, y, label, fill, tx, size=10.0, h=20, anchor="middle"):
    wpx = tw(label, "s", 700, size) + 20 + 0.4 * len(label)
    x = cx - wpx / 2 if anchor == "middle" else cx
    rect(x, y, wpx, h, fill, rx=h / 2)
    text(x + wpx / 2, y + h / 2 + size * 0.36, label, "s", 700, size, tx, "middle", ls="0.4")
    return wpx


class Block:
    def __init__(self, h, fn):
        self.h, self.fn = h, fn

    def draw(self, x, y, h=None):
        self.fn(x, y, self.h if h is None else h)


def card(w, title, body, ids, accent, fill=WHITE, tcol=INK, icon=None, tsize=13.0, bsize=12.4, lh=16.6,
         isize=11.0, ilh=15.0, stroke=None, kicker=None, kcol=None):
    pad_l, pad_r, top = 16, 12, 11
    tx_w = w - pad_l - pad_r - (20 if icon else 0)
    tl = wrap(title, tx_w, "s", 700, tsize)
    bl = wrap(body, w - pad_l - pad_r, "s", 400, bsize) if body else []
    il = id_lines(ids, w - pad_l - pad_r, isize) if ids else []
    kl = 1 if kicker else 0
    h = top + kl * 15 + len(tl) * (tsize + 4) + (3 + len(bl) * lh if bl else 0) + (5 + len(il) * ilh if il else 0) + 9

    def fn(x, y, hh):
        rect(x, y, w, hh, fill, stroke or LINE, 1, rx=7)
        rect(x, y, 5, hh, accent)
        cy = y + top
        if kicker:
            text(x + pad_l, cy + 9, kicker, "s", 700, 9.6, kcol or accent, ls="0.7")
            cy += 15
        ix = x + pad_l
        if icon:
            text(ix, cy + tsize - 1, icon, "s", 700, tsize + 1, accent)
            ix += 20
        for i, t in enumerate(tl):
            text(ix, cy + tsize - 1 + i * (tsize + 4), t, "s", 700, tsize, tcol)
        cy += len(tl) * (tsize + 4)
        if bl:
            cy += 3
            for i, t in enumerate(bl):
                text(x + pad_l, cy + bsize - 1 + i * lh, t, "s", 400, bsize, BODY)
            cy += len(bl) * lh
        if il:
            cy += 5
            ids_draw(x + pad_l, cy + isize - 1, il, isize, ilh)

    return Block(h, fn)


def grid(cards, cols, x, y, w, gap=12, vgap=12, draw=True):
    cw = (w - gap * (cols - 1)) / cols
    rows = [cards[i:i + cols] for i in range(0, len(cards), cols)]
    cy = y
    for r in rows:
        rh = max(c(cw).h for c in r)
        for j, c in enumerate(r):
            if draw:
                c(cw).draw(x + j * (cw + gap), cy, rh)
        cy += rh + vgap
    return cy - vgap - y


def band(y, label, right, color, tint, h_fn, draw_fn, pad=14, hh=40, rfam="m"):
    ch = h_fn()
    total = hh + pad + ch + pad
    rect(M, y, CW, total, tint, color, 1.4, rx=9)
    rect(M, y, CW, hh, color, rx=9)
    rect(M, y + hh - 9, CW, 9, color)
    rwt = 700 if rfam == "m" else 400
    lsz = 16.0
    while tw(label, "s", 700, lsz) + 0.5 * len(label) + (tw(right, rfam, rwt, 11) + 40 if right else 0) > CW - 36 \
            and lsz > 11:
        lsz -= 0.5
    ty = y + hh / 2 + 6
    text(M + 18, ty, label, "s", 700, lsz, WHITE, ls="0.5")
    if right:
        if rfam == "m":
            for nm in right.split(" · "):
                resolve(nm)
        text(W - M - 16, ty - 0.5, right, rfam, rwt, 11, WHITE, "end")
    draw_fn(y + hh + pad)
    return total


def panel_title(x, y, w, title, col, size=12.2, draw=True):
    tl = wrap(title, w - 0.5 * len(title), "s", 700, size)
    if draw:
        for j, l in enumerate(tl):
            text(x, y + 20 + j * 15.5, l, "s", 700, size, col, ls="0.5")
    return 30 + (len(tl) - 1) * 15.5


def fig_header(num, title):
    h = 54
    rect(0, 0, W, h, NAVY)
    rect(0, h - 4, W, 4, V)
    text(M, 22, f"FIGURE {num}", "s", 700, 11, GOLD, ls="1.2")
    text(M, 42, title, "s", 700, 17, WHITE, ls="0.4")
    rt = "P ≠ NP: FORM BY THEOREM, VALUE BY THE ACT · KERNEL v1.13.0 · EVERY NAME CHECKED"
    text(W - M, 22, rt, "s", 400, 10, SUB, "end", ls="0.6")
    return h


def legend(y):
    h = 30
    rect(M, y, CW, h, WHITE, LINE, 1, rx=7)
    lx = M + 14
    text(lx, y + 19.5, "READING", "s", 700, 10.4, INK, ls="0.8")
    lx += tw("READING", "s", 700, 10.4) + 22
    for col, lab in [(G, "theorem on no axiom at all"), (B, "theorem on Lean's standard axioms"),
                     (SLATE, "definition")]:
        rect(lx, y + 9, 12, 12, col, rx=2)
        text(lx + 18, y + 19.5, lab, "s", 400, 10.6, BODY)
        lx += 18 + tw(lab, "s", 400, 10.6) + 22
    return h


