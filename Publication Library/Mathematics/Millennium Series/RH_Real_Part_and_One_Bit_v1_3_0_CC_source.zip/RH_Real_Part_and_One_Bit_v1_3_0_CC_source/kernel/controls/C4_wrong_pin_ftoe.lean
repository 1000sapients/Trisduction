import RHMaster39
-- Control 4: a forged pin on a no-axiom theorem must fail the guard.
/-- info: 'FTOE.ftoe_unconditional_return_one_bit' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.ftoe_unconditional_return_one_bit
