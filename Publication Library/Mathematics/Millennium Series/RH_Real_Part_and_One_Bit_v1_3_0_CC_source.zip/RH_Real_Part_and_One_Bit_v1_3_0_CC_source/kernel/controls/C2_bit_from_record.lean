import RHMaster39
-- Control 2: the record's least erasure, proved with no premise, is not the bit.
theorem c2 : BoundChainMathlib.TheOneBit := BoundChainMathlib.cargo_at_zeros
