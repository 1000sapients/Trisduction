import RHMaster39
-- Control 5: a sorry is reported, and under warningAsError it fails the build.
set_option warningAsError true
theorem c5 : RiemannHypothesis := sorry
