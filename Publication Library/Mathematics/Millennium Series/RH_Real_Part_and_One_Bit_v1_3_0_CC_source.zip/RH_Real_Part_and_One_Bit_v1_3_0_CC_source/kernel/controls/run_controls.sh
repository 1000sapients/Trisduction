#!/bin/bash
export PATH=$HOME/.elan/bin:$PATH
cd /home/claude/mathos_boot
for f in /tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad/rh39/controls/*.lean; do
  b=$(basename $f .lean)
  lake env bash -c "LEAN_PATH=\$LEAN_PATH:/tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad/rh39/mod lean $f" > /tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad/rh39/controls/$b.out 2>&1
  echo "$b exit $?" >> /tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad/rh39/controls/results.txt
done
