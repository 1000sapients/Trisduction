import RHMaster39
-- Control 6: a zeta selector that is not shown to hold gives nothing.
theorem c6 : RiemannHypothesis :=
  BoundChainMathlib.rh_of_zeta_selector ⟨True, fun _ => BoundChainMathlib.cargo_at_zeros⟩ trivial
