import RHMaster39
-- Control 3: a forged pin on the final form must fail the guard.
/-- info: 'BoundChainMathlib.the_final_form' does not depend on any axioms -/
#guard_msgs in #print axioms BoundChainMathlib.the_final_form
