import RHMaster39
-- Control 1: the conservation field cannot be discharged by computation of the chiral defect.
theorem c1 : RiemannHypothesis :=
  BoundChainMathlib.rh_of_conservation_seat (fun _ _ => rfl)
