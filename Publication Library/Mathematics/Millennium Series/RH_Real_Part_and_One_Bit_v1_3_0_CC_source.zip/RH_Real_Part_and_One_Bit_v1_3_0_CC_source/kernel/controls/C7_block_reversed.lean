import RHMaster39
-- Control 7: reflection closure does not give the value; the reversed block is refused.
theorem c7 : ∀ S : BoundChainMathlib.Config, BoundChainMathlib.Closed S → BoundChainMathlib.Value S :=
  fun S hS => BoundChainMathlib.selected_config_value_is_a_theorem ⟨S, hS, fun _ h => h⟩
