import RHMaster39
-- Positive control: the pins hold when imported, and the final form is the theorem the paper cites.
/-- info: 'BoundChainMathlib.the_final_form' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms BoundChainMathlib.the_final_form
/-- info: 'FTOE.ftoe_unconditional_return_one_bit' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.ftoe_unconditional_return_one_bit
example : (RiemannHypothesis ↔ BoundChainMathlib.TheOneBit) := BoundChainMathlib.the_final_form.1.1
example : ¬ ∀ S : BoundChainMathlib.Config, BoundChainMathlib.Closed S → BoundChainMathlib.Value S :=
  BoundChainMathlib.the_final_form.1.2.2.1.1
