"""Strip Lean comments (nested block comments, line comments) and string literals; print code-only text."""
import sys
def strip(src):
    out=[]; i=0; n=len(src); depth=0; instr=False
    while i<n:
        c=src[i]; nx=src[i+1] if i+1<n else ''
        if depth>0:
            if c=='/' and nx=='-': depth+=1; i+=2; continue
            if c=='-' and nx=='/': depth-=1; i+=2; continue
            out.append('\n' if c=='\n' else ' '); i+=1; continue
        if instr:
            if c=='\\': out.append('  '); i+=2; continue
            if c=='"': instr=False
            out.append('"' if c=='"' else ('\n' if c=='\n' else ' ')); i+=1; continue
        if c=='/' and nx=='-': depth=1; i+=2; out.append('  '); continue
        if c=='-' and nx=='-':
            while i<n and src[i]!='\n': out.append(' '); i+=1
            continue
        if c=='"': instr=True; out.append('"'); i+=1; continue
        out.append(c); i+=1
    return ''.join(out)
if __name__=='__main__':
    sys.stdout.write(strip(open(sys.argv[1],encoding='utf-8').read()))
