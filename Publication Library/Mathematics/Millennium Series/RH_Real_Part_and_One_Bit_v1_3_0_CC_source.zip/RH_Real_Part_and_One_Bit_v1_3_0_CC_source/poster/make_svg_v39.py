"""Poster v3.0.39_CC from the v3.0.34_CC poster: exact replacements, each asserted to occur once.
Usage: python3 make_svg_v39.py SEAT_SHA PAPER_SHA LINES THEOREMS PINS"""
import sys
seat_sha, paper_sha, nlines, nthm, npins = sys.argv[1:6]
SP = '/tmp/claude-0/-home-claude/8df7b8fd-8cdb-55ba-b51d-c49f4399ddce/scratchpad'
t = open(SP + '/build34/RH_10_Level_Architecture_Poster_v3_0_34_CC.svg', encoding='utf-8').read()

def rep(old, new, count=1):
    global t
    assert t.count(old) == count, (t.count(old), old[:90])
    t = t.replace(old, new)

rep('>MASTER v3.0.34_CC · LEAN 4.19.0 · MATHLIB c44e0c8e<', '>MASTER v3.0.39_CC · LEAN 4.19.0 · MATHLIB c44e0c8e<')
rep('COMPILE EXIT 0 · 760 PINS · 0 SORRY · 0 AXIOMS DECLARED', f'COMPILE EXIT 0 · {npins} PINS · 0 SORRY · 0 AXIOMS DECLARED')
rep('>PAPER v1.2.3_CC · TRACTATUS MATHEMATICUS<', '>PAPER v1.3.0_CC · TRACTATUS MATHEMATICUS<')
rep('>zeta_ra_loop · apex_cone · the_self_recognition_closure<', '>zeta_ra_loop · apex_cone · the_bit_is_the_proof<')
rep('>The bridge is located exactly: necessary and sufficient. The bit is self-recognition.<',
    '>The bridge is located exactly: necessary and sufficient. One bit, on five faces.<')
rep('>real_part_of_certificate · the_cut_on_the_chart · price_zero_iff_value<',
    '>real_part_of_certificate · rh_iff_certificates · rh_finite_form_closure<')
rep('>Unconditional at every height computed now or in any future. Registration is lossless: 0 heat paid.<',
    '>Unconditional at every computed height; at the true zeros RH is a certificate at every height.<')
rep('>final_formal_closure_complete · the_terminal_certification · the_terminal_verdict · nothing_escapes_at_the_zeros<',
    '>the_final_form · the_barrier_is_one_bit · the_terminal_verdict · nothing_escapes_at_the_zeros<')
rep('>SEAT  RH_Both_Sides_Formal_Master_v3_0_34_CC.lean · sha256 9a526f99… · 14,535 lines · 927 theorems<',
    f'>SEAT  RH_Both_Sides_Formal_Master_v3_0_39_CC.lean · sha256 {seat_sha[:8]}… · {int(nlines):,} lines · {nthm} theorems<')
rep('>PAPER  RH_Real_Part_and_One_Bit_v1_2_3_CC.md · sha256 b5c0dbfb… · Appendix E byte-identical to the seat<',
    f'>PAPER  RH_Real_Part_and_One_Bit_v1_3_0_CC.md · sha256 {paper_sha[:8]}… · Appendix E byte-identical to the seat<')
assert '—' not in t, 'em dash left'
out = SP + '/poster39/RH_10_Level_Architecture_Poster_v3_0_39_CC.svg'
open(out, 'w', encoding='utf-8').write(t)
print('wrote', out, len(t.encode()))
