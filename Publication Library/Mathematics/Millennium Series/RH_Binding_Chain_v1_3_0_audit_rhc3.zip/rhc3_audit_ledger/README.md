# rhc3 audit ledger · The Ten-Level Binding Chain, v1.3.0, the formal edition

Cycle rhc3, rounds 1 to 21, closed by the architect's ruling of 14 October 2026 (no computed terminal verdict; last valid verdict CONTINUE-DEBT at round 20, round 21 VOID-UNDERPOWERED).

- `audit_rhc3/`: `cycle.json` (pre-registration and falsifiers), `findings.jsonl` (109 rows), `rounds.jsonl` (21 closed rounds), `superseded.json` (18 recorded supersessions), `controls_r{1..22}.{commit.txt,sealed.json}` (SELF controls, committed by digest before each prosecution; r22 committed and never prosecuted), `sweep_r{N}_{FID}.json` (109 sweep specs), `digest_entries.json` (228 diff hunks with their finding ids).
- `round_blocks/`: the round emission block of each round, 1 to 21.
- `candidates/`: every candidate version, r0 to r21, plus r3j (joint repairs filed in round 4) and r19a (the architect amendment applied before the round-19 prosecution). r10 = r9, r16 = r15, r18 = r17, r20 = r21 = r19 carried as new version files. The final master is r21 with the date line stamped 14 October 2026.
- `prosecutions/`: the blind prosecutor's output of each round, as delivered (findings against the seeded copy, controls included).
- `repairs/`: the repair scripts of rounds 1 to 5 and 9; later repairs were inline and are recorded by their sweep specs.
- `tools/`: the ledger, control, sweep and verification tools; the citation and cone checker; the spine lock and its lock file; the digest and closing-card generators; the builders; `cones205.json` (every `#print axioms` cone of seed 2.0.5), `probe_box1_final.out` (the compile of Box 1 from the final text against the seed).
- `PreForge_Digest_rhc3.md`: the change census, reconciled against the r0 to final diff.

Re-verify: `python3 tools/verify_all.py audit_rhc3 candidates/cand_v1_3_0_r21.md` prints `109 specs, 0 failures: PASS`.
