# Prosecution report, round 7 (blind)

Object: `paper.md` (formal edition v1.3.0), its Appendix A seed `RH_Both_Sides_Seed_v2.0.5.lean`, reference 8 `Cargo_Delivered_Hardened.lean`, and the cone table `compiler_cones_all_738.txt`.
Toolchain: `/home/claude/apu/lean/lean-4.19.0-linux/bin/lean`, core Lean 4.19.0, no Mathlib. Every probe file, script and output is in this folder.

Four findings: one STRUCTURAL, three COSMETIC. No FATAL or LOAD-BEARING defect survived checking. The conditional, the packaging, the refusal, the cargo binding and every printed cone match the compiler.

---

## 1. Findings

| id | register | target (quoted, with section) | mechanism | severity | minimal falsifier and suggested repair | executed evidence |
|---|---|---|---|---|---|---|
| N1 | PROVENANCE, plus PARAMETER (census of exits) | Section 4, "The three exits": "in the physical edition a physical premise or the observational model, as that edition states it, a refusal whose shape on the carrier is a read zero off the line realized in no measured register (`the_one_exit_is_a_second_register`)". Section 5: "on the carrier a refusal has a shape, a read zero off the line realized in no measured register (`the_one_exit_is_a_second_register`), the physical edition's F-Bridge." | The cited theorem (seed line 10001) has four hypotheses: `h_read`, the bound `B` with its certificate, `h_gap`, and `h_signal : ∀ c, realized c → ¬ Neutral c → B.R ≥ δ`. It does not take `h_realize`. Its conclusion, `¬ ClassicalRH → ∃ p, Zζ p ∧ ¬ onLine p ∧ ¬ realized (map_zero_to_carrier p)`, gives the shape of a denial only when the reading, the bound, the gap and the signal floor are all granted. The physical edition builds the signal floor from `h_pop`, `h_rate`, `h_temp` and `h_couple` (`signal_floor`, line 9825). So the shape belongs to exactly one refusal, the refusal of `h_realize`. A refusal of the reading, of the observational model (`B`), or of any of `h_pop`, `h_rate`, `h_temp` or `h_couple` falls outside the theorem's hypotheses. The prose gives this shape to every physical-edition F-Bridge refusal, which is false for most branches. Section 5 also defines "the physical edition's F-Bridge" as this shape. Under that definition, a refusal of `h_pop` with every other input granted is not F-Computed, not F-Flux and not this shape, which contradicts "there is no fourth exit for either". | STRUCTURAL. It bears only on the physical edition and the fenced corroboration. This edition's conditional and its two exits are untouched, and Section 4's list of refusals by name still covers every input of the eight-input capstone. | The probe `AuditProbes.refusal_without_second_register` compiles with cone none. It sets `ClassicalRH := Value Zζ` (the reading holds by `Iff.rfl`), `Zζ = pairWorld offPoint`, `realized = fun _ => True`, `population = rate = fun _ => 0`, `n0 = r0 = T0 = T = 1` and `B = ⟨0, 0, _, _⟩`. Under these values the gap `B.ε < detectionGap 1 1 1` holds, and `h_realize`, `h_temp` and `h_couple` hold. `h_pop` and `h_rate` fail and the hypothesis is denied, yet every read zero off the line is realized, so the claimed shape is absent. **Repair:** state the theorem's hypotheses in both passages, for example: "with the reading, the bound, the gap and the signal floor granted, a denial asserts a read zero off the line realized in no measured register: the shape of refusing `h_realize`". Keep F-Bridge for the physical edition as the refusal by name of any of its inputs, and make the shape one branch of it, not its definition. | E12 (P4), E18 |
| N2 | Internal contradiction (a number printed twice) | Section 6: "The timeless closure, five names one proposition with no act of the zero set and no premise on the value in it, … (`the_timeless_zone_closed`)". Against this, the Level 8 row says "On every configuration four names are one proposition". | The first conjunct of `the_timeless_zone_closed` (line 6454) identifies four predicates on every configuration: `LeastErasure S`, `Value S`, `RootReadTwice S` and `R ∧ RootReadTwice S`. The seed's own docstring and section heading say "Four names" (lines 6335, 6344, 6450). The count of five in Section 6 contradicts both the cited theorem and Level 8. Section 6 is interpretive, but this is a numerical claim about a theorem. | COSMETIC | Read conjunct 1 of `the_timeless_zone_closed`: three biconditionals with `Value S`, so four names. **Repair:** change "five names" to "four names". | E14 |
| N3 | PROVENANCE | Section 4, "The reading": "Read at every resolution n ≥ 1, resolution zero being no reading and the family's term there the empty configuration, the hypothesis `h0` of the compositions that package the act, the reading is an identification of statements; the interface proves no such identification as a law, … at every resolution (`the_reading_every_is_keyed`, Box 1)". Box 1's docstring says "the constant family at the pair world". | The witness in the cited composition is `R := fun _ => pairWorld offPoint`. Its term at resolution 0 is the pair world, which is closed, off the line and not empty. It therefore violates `h0`, the condition the same sentence places on the reading at every resolution. The theorem shows that the identification is no law over all fold-closed families. Failure over a larger class does not show failure over the subclass the sentence names, the families with `R 0` empty. The claim is true, but the cited witness lies outside the scope the prose gives it. | COSMETIC | `AuditProbes.keyed_witness_violates_h0`, which states `¬ ((fun _ => pairWorld offPoint) 0 = fun _ => False)`, compiles with cone none. **Repair:** add `R 0 = fun _ => False` as a conjunct and use the family that is empty at 0 and the pair world above it. `AuditProbes.the_reading_every_is_keyed_h0` compiles with cone none. | E12 (P5) |
| N4 | PARAMETER (a printed condition that is never used; a regression of the T2 rewrite) | Section 1, "The two editions": "where Zζ collects the family's resolutions, the configurations closed and the term at resolution zero empty, they carry one content (`value_collected`, `the_act_is_the_premise_packaged`, `the_act_every_is_the_value_packaged`)" | After the rewrite, `the_act_every_is_the_value_packaged` takes `h0` alone and derives closedness from the value. The one-configuration act at the collected configuration needs no closedness either, because the value implies fold-closedness. None of the three cited declarations uses the printed condition "the configurations closed". The sentence therefore disagrees with Section 4 ("the packaging adds one hypothesis … the closedness of the configurations following from the value") and with Box 1's docstring. | COSMETIC | `AuditProbes.collected_act_iff_every {R} (h0 : R 0 = fun _ => False) : (∃ A : ActualZeros, A.zeros = fun p => ∃ n, 1 ≤ n ∧ R n p) ↔ ∃ Z : Charts.ActualZerosEvery, Z.zeros = R` compiles with cone [propext, Quot.sound] and has no closedness hypothesis. **Repair:** delete "the configurations closed", or say that it follows from the value. | E12 (P7) |

---

## 2. Evidence log

**E1. File identity.**
- Ran `sha256sum` and `wc -l` on the seed and on reference 8.
  - Seed: `a82ef4f0ad6ceb43a2d3cc964b110943dbb02f050ab88ff2845df1226a321a57`, 10268 lines.
  - Reference 8: `9b4f663ff6bd14a233fb9f2d2aceb7e144364c35950e7cf5ddcf64e99e57852f`, 184 lines.
- Extracted Appendix A with `sed -n '221,10488p' paper.md > scratch/appendixA_extract.lean` and ran `cmp` against the seed: IDENTICAL. Its sha256 matches the Appendix A heading.

**E2. Declaration census.**
- `python3 -I scratch/decls.py` strips nested block comments and line comments, then tracks namespaces and sections.
- Result: 738 `theorem`, 313 `def`, 47 `structure`, 18 `abbrev`, 5 `inductive`, 0 `axiom`.
- A plain grep finds 739 theorems, because one occurrence sits inside a comment.
- A grep on the comment-stripped code finds no `sorry`, `admit` or `native_decide`.
- `set_option linter` appears once, at line 10224, on `stage2_optional_corroboration`.

**E3. Cone table.**
- The table has 997 lines and 738 distinct names, with no name carrying two different cones.
- Cone counts: none 428, [propext] 42, [propext, Quot.sound] 210, [propext, Classical.choice, Quot.sound] 58. These match Box 2.
- The set of theorem names in the table equals the set of theorems in the seed (E2).

**E4. Box 1.**
- Built `box1.lean` from the seed, Box 1 (paper lines 78–124) and the 8 `#print axioms` lines, then compiled it: exit 0, 0 errors, 0 warnings, real time 40.8 s.
- Cones: `classical_rh_from_the_act_every` none, `classical_rh_from_the_act` none, `the_act_every_is_the_value_packaged` [propext, Quot.sound], `refusing_the_act_is_the_denial` [propext, Quot.sound], `value_collected` none, `the_reading_every_is_keyed` none, `cargo_binding_on_the_seed` none, `Charts.ActualZerosEvery.atRes` none.
- All match Box 1 as printed.

**E5. Reference 8.**
- Compiled `cargo_copy.lean`: exit 0 with no output, so all 8 `#guard_msgs` pins passed.
- `HardenedCargo.cargo_binding_necessary_and_sufficient` is pinned at none.

**E6. Fresh cones for all 738 seed theorems.**
- Compiled `probes2_full.lean` (seed, Box 1, probes, and `#print axioms` for each of the 738 theorems): exit 0.
- Comparing with the supplied table: 0 missing, 0 differences, same counts as E3.
- The 5 warnings in this run come from my own probe P4b (unused variables), not from the seed.

**E7. Resolution of cited names.**
- The paper body (lines 1–215) contains 138 distinct backticked identifiers.
- Every cited theorem and definition resolves to a declaration in the seed, except:
  - the names the paper marks as the Formal Master's (`BoundChainMathlib.*`, `FormalMasterClosure.*`);
  - `cargo_binding_necessary_and_sufficient` (reference 8);
  - the seven compositions of Box 1;
  - `Classical.em` and `Classical.byContradiction`;
  - hypothesis and field names such as `h0`, `h_read` and `supply`.
- Part tags resolve the homonyms correctly:
  - `record_decides_nothing` (Part II) is `PrimeFreedom`;
  - `keyless_forces_nothing` (Part IV) is `Hinge`;
  - `unicorn_block` (Part II) is `PrimeFreedom`;
  - `two_denials` (Part III) is `RememberedOffered`;
  - `value_from_the_act` (Part III) is `RememberedOffered`.
- Part map from the section markers: I is `TOE0`; II is `PrimeFreedom`; III is `RememberedOffered` and `RHUnicorn`; IV is `Hinge`; IV-b is `ForceWitness`; V is `ArrowSide`; V-b is `Charts`; VI is `BothSides`; VII is `LeastErasureDoF` and `Hardening`; VIII is `PhysicoFormal`; the cargo section is `ApparatusCargo`.

**E8. Every printed cone in the prose.**
- A regex scan of the body checked every name–cone pair: 83 pairs, 0 mismatches once part tags are applied.
- The only raw "mismatch" was `computation_enacts_stage1`. It is a definition, absent from the theorem table, and the seed pins it at none.

**E9. Reach census.**
- `reach.lean` is `import Lean`, then `box1.lean`, then a metaprogram that walks the transitive closure over the types and values of constants, including constructors and recursors. It compiled with exit 0.
- Counts of ledger names from Levels 1–9 that each term reaches:

| Term | Ledger names reached |
|---|---|
| `classical_rh_from_the_act_every` | 0 |
| `classical_rh_from_the_act` | 1 (`Hardening.le_iff_value`) |
| `the_act_every_is_the_value_packaged` | 8 |
| `refusing_the_act_is_the_denial` | the same 8 |
| `value_collected`, `the_reading_every_is_keyed`, `cargo_binding_on_the_seed` | 0 each |
| Every `ApparatusCargo` theorem | 0 |
| `the_run_witnesses_a_run`, `the_run_does_not_force_the_value`, `force_witness_closure` | 0 each |

- The 8 names reached by the packaging and the refusal are `the_act_at_every_resolution`, `prime_side_halts`, `row_four_from_the_zero_side`, `the_one`, `no_closed_principle_decides`, `the_atomic_proof`, `the_atomic_necessity` and `bidirectional_halted_uniduction`.
- No homonym of any ledger name is reached.
- The probe's list of ledger names was checked against the 55 distinct backticked names in ledger rows 1–9: equal sets.
- Constants each proof term mentions directly:
  - The refusal mentions only the packaging and the definitions `Charts.ActualZerosEvery` and `RememberedOffered.Value`.
  - The packaging mentions `value_from_the_act` (III), `ActualZerosEvery.atRes` and `the_act_at_every_resolution` (V-b), definitions of Part III, and `TOE0.RA₀`. `TOE0.RA₀` occurs only inside the elaborated type argument of `And.left`.
  - `classical_rh_from_the_act` mentions the theorems `classical_rh_iff_le_of_reading` and `supply_is_the_premise` (VII) and the types of Part III.
  - `force_witness_closure` mentions only `ForceWitness` constants.

**E10. Blocked reach and isolation of the cargo** (`reach2.lean`, exit 0).
- With `Charts.the_act_at_every_resolution` blocked, the packaging and the refusal reach no ledger name from Levels 1–9. Those names therefore enter only through that theorem.
- The 93 constants of `ApparatusCargo` reach no seed constant outside `ApparatusCargo`. `cargo_binding_on_the_seed` likewise reaches nothing outside it.
- Namespace roots reached:

| Term | Roots reached |
|---|---|
| The run's theorems | `ForceWitness`; `force_witness_closure` also reaches `RememberedOffered` |
| Conditional at every resolution | `RememberedOffered`, `Charts` |
| Conditional at one configuration | `RememberedOffered`, `Hardening` |
| Packaging and refusal | `TOE0`, `RememberedOffered`, `Charts` |

**E11. What the extra roots are** (`reach3.lean`, exit 0).
- The only `RememberedOffered` constant the run reaches is `RememberedOffered.calm._proof_38`, an auxiliary proof shared by elaboration.
- The packaging reaches `TOE0` through the type of `the_act_at_every_resolution` (`rootOf TOE0.ra₀`).
- The one-configuration conditional reaches only types, definitions and `reg_erases_nothing_iff` from Part III.

**E12. Probes** (`probes2.lean` inside `probes2_full.lean`, exit 0). Cones:

| Probe | Cone |
|---|---|
| P3 `bridge_from_realization_dec`, the bridge with `Nat.decLe` and `decEq` case splits only | none |
| P4 `refusal_without_second_register` (N1) | none |
| P5 `keyed_witness_violates_h0` (N3) | none |
| P5 `the_reading_every_is_keyed_h0` (repair for N3) | none |
| P6 `packaging_needs_h0`: a family empty at every n ≥ 1 and the pair world at 0 has the value at every n ≥ 1 but no act | none |
| P7 `collected_act_iff_every` (N4) | [propext, Quot.sound] |
| P8: the conditional at every resolution typechecks with its two inputs and no `h0` | (no cone printed) |
| `PhysicoFormal.the_one_exit_is_a_second_register` | [propext, Classical.choice, Quot.sound] |

**E13. The reader's rule.**
- `python3 -I scratch/reader_rule.py` reimplements `readAt`: round half to even, then `clampStrip`. It asserts the 8 values the seed checks by `decide` in `one_resolution_is_not_enough`.
- Over rationals a/b with 2 ≤ b < 120:
  - Claim A (|σ − 1/2| > η and n > 1/(2η) gives `readAt ≠ 0`): 2,745,880 cases, 0 violations.
  - Claim B (|σ − 1/2| < 1/(4n), "closer than the half-step", gives `readAt = 0`): 25,055 cases, 0 violations.
  - The sharp threshold n > 1/(4|σ − 1/2|) with n ≥ 2: 2,064,696 cases, 0 violations.
- So "beyond 1/(2η)" is a correct sufficient threshold, though not sharp.

**E14. Four names or five.**
- `grep -n -i 'five names\|four names'` on the seed finds lines 5364, 6335, 6344, 6450 and 6472, all "four names".
- On the paper body it finds Level 8 (line 39), "four names are one proposition", and Section 6 (line 179), "five names one proposition".

**E15. Further probes** (`probes3.lean`, exit 0, every cone none).
- `ApparatusCargo.onLine = RememberedOffered.onLine` and `ApparatusCargo.Point = RememberedOffered.Point`, both by `rfl`.
- `value_is_no_law`: the conclusion of `the_run_does_not_force_the_value` holds with `True` in place of the run.
- The floor of `Stage1` holds for every event.
- A neutral event has `before = after`.
- The paper discloses each of these.

**E16. Toolchain.** `lean --version` prints `Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)`, as in Box 2.

**E17. Where the cargo section begins.**
- `sed -n '10105,10114p'` shows that line 10110 is the last `#print axioms` of Part VIII and line 10112 opens the comment "Level 10 cargo".
- `set_option linter.unusedVariables false` appears once (E2).

**E18. Signatures read directly in the seed.**

| Declaration (line) | Signature as read | Result |
|---|---|---|
| `the_one_exit_is_a_second_register` (10001) | hypotheses `h_read`, `B`, `h_gap`, `h_signal`; no `h_realize` | basis of N1 |
| `classical_rh_from_physico_formal_closure` (9872) | `h_read`, `h_realize`, `h_pop`, `h_rate`, `h_temp`, `h_couple`, `B`, `h_gap`, plus the data `realized`, `population` and `rate` | "eight inputs" holds |
| `stage2_optional_corroboration` (10230) | 9 inputs; the five physical premises unused; `Classical.em` in the proof | as printed |
| `classical_rh_from_identification_gap_and_bound` (9351) | 5 hypotheses | as printed |
| `independence_forces_truth` (2429) | `Setting` (line 2407) carries `sigma1 : ¬hyp → Prov ¬hyp` and `sound_neg` | "complete and sound on the denial" holds |

**E19. Unit arithmetic.**
- A Python check of the conversion: the kernel's number is `2725·693147`, and k_B times that number over 10^9, divided by k_B·2.725·ln 2, gives 0.99999974.
- 693147/10^6 ≤ ln 2, so the truncation lowers the gap.

---

## 3. Results by target

**T1. F-Bridge for both editions (Section 4), and Section 5's sentence naming the physical edition's F-Bridge.**
Finding N1. The rest of T1 checked out:
- This edition's F-Bridge names a concrete refusal, of the reading or of the act. Its "denial" branch is exactly `refusing_the_act_is_the_denial`, which compiles with h_read and h0 at [propext, Quot.sound] (E4).
- Each conditional of Box 1 has two inputs, so for this edition the exits F-Computed and F-Bridge are complete (E4, E18).
- F-Computed names a concrete observation, and the paper's reader's-rule thresholds hold (E13).
- F-Flux names a concrete observation that bears only on the physical side.
- "Refusing only the author's posit … is no exit, since Box 1 needs no run" agrees with the signatures. No event and no run appears in either conditional (E9 direct lists).

**T2. Box 1's packaging and refusal, with `h0` as the only added hypothesis and closedness derived; every sentence citing them.**
Finding N4. The rest of T2 checked out:
- Both compositions compile with the printed cones (E4).
- `h0` is the only hypothesis beyond `R`, and it is necessary: P6 exhibits a family that has the value at every n ≥ 1 and carries no act when `R 0 ≠ ∅` (E12).
- Closedness is derived inside the proof, and P7 shows the same without any closedness hypothesis.
- The packaging uses the first conjunct of `the_act_at_every_resolution` (`.1`), as Section 4 says.
- The abstract, the Level 10 row, Section 4's capstone, F-Bridge and Section 7 all state the type correctly. Only Section 1 keeps the closedness condition that is no longer used.

**T3. Box 1's `the_reading_every_is_keyed` and the reading paragraph.**
Finding N3. The rest of T3 checked out:
- The composition compiles with cone none (E4), and its docstring matches its witness.
- `the_reading_is_keyed` (Hardening, line 9435) has the one-configuration form, stated through `LeastErasure`. That is equivalent to `Value` by `le_iff_value`.
- The identification at every resolution is mathematically sound under the reader's rule (E13): a zero on the line reads at d = 0 at every n, and a zero off the line reads off it for every n > 1/(4|σ − 1/2|).

**T4. Section 3: "Box 1's packaging calls `the_act_at_every_resolution` … directly, its refusal through the packaging".**
Checked, nothing found.
- The packaging's proof term mentions `Charts.the_act_at_every_resolution` directly. The refusal's term mentions only the packaging (E9).
- Both reach exactly eight ledger names from Levels 1–9: `the_act_at_every_resolution` plus the seven the paper lists. The seven fall in Levels 2, 3, 5, 6, 7, 8 and 9 (E9).
- With `the_act_at_every_resolution` blocked, they reach none, which confirms "enter the packaging only through" (E10).
- The other counts in the same paragraph hold: the cargo's, the run's and the every-resolution conditional's terms reach 0, and the one-configuration conditional reaches only `le_iff_value` through `classical_rh_iff_le_of_reading` (E9).

**T5. Section 7: "named by the parts each calls directly … its packaging on Parts III and V-b".**
Checked, nothing found. The constants each term calls directly are listed in E9:

| Term | Parts it calls directly |
|---|---|
| The cargo's terms | the cargo section only |
| Box 1's binding | the cargo section only |
| The run's terms | Part IV-b only |
| Box 1's conditionals | Parts III, V-b and VII, taken together |
| The packaging | `value_from_the_act` (III), `atRes` and `the_act_at_every_resolution` (V-b) |
| The refusal | the packaging |

Two artifacts of elaboration do not change this.
- `TOE0.RA₀` appears directly in the packaging's term, but only inside the implicit type argument of `And.left`, not as a called declaration.
- The run's closure reaches `RememberedOffered.calm._proof_38`, but that is a shared auxiliary proof, not a call (E11).

The count "three" matches Section 3's three groups: the cargo with its binding, the run, and the conditional with its packaging.

---

## 4. Checks that found nothing

- Digests, line counts and Appendix A against the seed file: identical (E1). Box 2's toolchain string matches (E16). The seam between lines 10,110 and 10,112 is where the paper says (E17).
- The census of 738 theorems, 0 `axiom` commands, no `sorry`, `admit` or `native_decide` outside comments, and a single linter switch (E2).
- All 738 cones in the table, recomputed by a fresh compile: 0 differences (E6). All 83 cones printed in the prose: 0 mismatches (E8). Box 1's 8 cones (E4). Reference 8's pins (E5).
- Every cited name resolves to a declaration of the kind the prose describes, with the part tags correct (E7).
- The "cargo section depends on nothing above it", and no seed term relates `VerificationEvent` to the run or to an act. The cargo section is last and closed under reach, so no earlier term can mention it (E10).
- The cargo's points and line are the offset chart's by definition (E15).
- Input counts: "eight inputs" (`classical_rh_from_physico_formal_closure`), "nine inputs" with the five physical premises unused (`stage2_optional_corroboration`), "three inputs printed as five hypotheses", "two inputs" per conditional, and "seven compositions" (E4, E18).
- "The step admits a constructive proof" for `bridge_from_realization`: P3 has cone none (E12).
- The SI conversion k_B × kernel / 10^9, the truncation of ln 2 lowering the gap, and T0 = 2725 mK (E19).
- The reader's rule: the 1/(2η) threshold, the half-step claim, and `one_resolution_does_not_decide_the_next` (E13).
- Level 1's "complete and sound on the denial" (`Setting`). Level 3's points (1, 0) and (3, 0) about the line x = 2 (`centred_yet_off`). Level 6's chart assignments (Part II for the first two, the offset chart for the next two). Level 9's quantification over every proposition in `accepting_rh_forces_the_atomic_proof` and `the_atomic_necessity`.
- Section 4's "all three cones are empty" in the cargo paragraph names four declarations. All four are empty (E4, E5, E6). Read as the three declarations on the seed's types, it is exact, so there is no finding.
- Section 3's "at one configuration Part VII": the theorems that conditional calls are both in Part VII; its types come from Part III. Read as theorems called, it is exact, and Section 7 states the union.
- "No fourth exit" for this edition, tested against both conditionals of Box 1: each has exactly two inputs, so the refusals are of the reading or of the act, and a certified zero refutes the act under the reading (E4, E13).
