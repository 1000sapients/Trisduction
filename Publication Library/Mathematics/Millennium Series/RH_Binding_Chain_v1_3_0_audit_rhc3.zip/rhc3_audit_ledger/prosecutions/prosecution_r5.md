# Prosecution report, round 5 (blind)

Object: `paper.md` (the formal edition, v1.3.0), its seed `RH_Both_Sides_Seed_v2.0.5.lean` (Appendix A), reference 8 `Cargo_Delivered_Hardened.lean`, and the cone table `compiler_cones_all_738.txt`. Toolchain: core Lean 4.19.0 (commit 6caaee842e94), no Mathlib. Every probe, script and output is in `scratch/`. Probes append declarations to an unmodified copy of the seed (`scratch/seed.lean`), plus Box 1 verbatim (`scratch/box1.lean`, extracted from paper lines 78 to 112), unless stated otherwise.

The paper's stated axioms, inputs, vocabulary and architecture are held fixed. Findings are restricted to mathematical errors and internal contradictions.

Result: 11 findings. None is FATAL or LOAD-BEARING. Four are STRUCTURAL (Q1 to Q4) and seven are COSMETIC (Q5 to Q11).

---

## 1. Findings table (most severe first)

| id | register | target (passage, section) | mechanism | severity | minimal falsifier and suggested repair | evidence |
|---|---|---|---|---|---|---|
| Q1 | DEFINITIONAL (grade drift) | §7, answer to "Then the physical premises were needed after all": "this edition takes it from the act, which the cargo's theorems establish at the configurations where the zeros of ζ are read" | The cargo's theorems (`local_computation_is_forgetting`, `event_witnesses_floor`, `stage1_closes`, `computation_enacts_stage1`) mention no configuration. They hold of every event and are consistent with a closed configuration that has no act. The sentence raises the act from premise to theorem, which contradicts the Box 1 caption ("no arrow runs from Stage 1 to an act at the configurations R"), §3 ("no term of the seed … runs from either to an act at the configurations where the zeros of ζ are read"), §4 "The boundary" (the act is "the premise on the value, an input of every conditional"), §1 ("posited in the other"), and the front note's rule that the type governs over `ActualZerosEvery`'s docstring, which is the one place where the ζ-readings are said to form an act. | STRUCTURAL | **Falsifier:** `Probe.cargo_does_not_establish_an_act` compiles with an empty cone. It conjoins all four cargo statements with `Closed (pairWorld offPoint) ∧ ¬ ∃ A : ActualZeros, A.zeros = pairWorld offPoint`. The comment-stripped cargo section (lines 10134 to 10268) has 0 occurrences of `Config`, `ActualZeros`, `Value` or `LeastErasure`. **Repair:** "this edition takes it from the act, the one formal premise, which the author posits the run of record supplies; no theorem of the seed establishes it at those configurations." | E13, E26 |
| Q2 | KINEMATIC (dependency census) | §3: "at one configuration it uses Part VII and, of Levels 1 to 9, `le_iff_value` of Level 2"; "its packaging Part V-b's `the_act_at_every_resolution`, and no other theorem the ledger names at Levels 1 to 9"; "Levels 1 to 9 are not steps inside those proofs". §7: on the objection "the capstone's proof does not invoke Levels 1 to 9", "Correct about the proof terms … Levels 1 to 9 are not steps inside those proofs" | 1. `le_iff_value` enters `classical_rh_from_the_act` only transitively, through `classical_rh_iff_le_of_reading`, so the paper counts transitive use as "use". 2. In that sense the packaging `the_act_every_is_the_value_packaged`, and through it `refusing_the_act_is_the_denial`, uses eight theorems the ledger names at Levels 1 to 9: `the_act_at_every_resolution` (L6, L7, used directly), `bidirectional_halted_uniduction` (L9), `the_atomic_necessity` (L9), `the_atomic_proof` (L5, L7), `no_closed_principle_decides` (L3), `prime_side_halts` (L2), `row_four_from_the_zero_side` (L2, L6) and `the_one` (L2, L8). It also reaches Part I (`TOE0.RA₀`) through the type of `the_act_at_every_resolution`. 3. In the direct sense, the one-configuration conditional does not use `le_iff_value` at all. 4. Read either way, one of the two census sentences in §3 is false. 5. "Levels 1 to 9 are not steps inside those proofs" is false of the packaging, whose direct step is a Level 6/7 theorem, and false of the one-configuration conditional by §3's own sentence. §7's concession inherits the error. | STRUCTURAL | **Falsifier:** the `#ledgerdeps` meta-command (probe2, `import Lean` prepended) prints, for `the_act_every_is_the_value_packaged`, "direct uses: [Charts.the_act_at_every_resolution]" and "transitive uses:" the eight names above. For `classical_rh_from_the_act` it prints "direct: []" and "transitive: [Hardening.le_iff_value]". **Repair:** "Of Levels 1 to 9, the one-configuration conditional reaches `le_iff_value` (Level 2), and the packaging reaches `the_act_at_every_resolution` (Levels 6, 7) and through it [the seven named]; the cargo, the run and the every-resolution conditional reach none; the chain is otherwise one of statements." | E18, E19 |
| Q3 | DEFINITIONAL | §4, opening paragraph: "Toward refutation the one channel a foundation keeps is F-Computed, a finite certificate that the configuration is not closed, a zero off the line" | The Notation fixes `Closed` as fold-closure. A zero off the line does not make a configuration non-closed: the seed's pair world is closed and has an off-line point (`pair_world_lacks_le`, `the_carrier_alone_decides_nothing`, and Level 3's own sentence). Non-closure implies an off-line point, but the converse fails, so "not closed" is strictly stronger than the refuter. Read literally, the channel is empty for any fold-symmetric zero set. The sentence contradicts Level 1's statement of the same channel ("a finite computation that certifies a zero off the line") and the F-Computed of "The three exits". | STRUCTURAL | **Falsifier:** `Probe5.closed_yet_off` proves `Closed (pairWorld offPoint) ∧ (∃ p, pairWorld offPoint p ∧ ¬ onLine p) ∧ ∀ S, ¬ Closed S → ∃ p, S p ∧ ¬ onLine p` (compiles; cone [propext, Classical.choice, Quot.sound]). **Repair:** "a finite certificate that the value fails at the configuration, a zero off the line". | E22 |
| Q4 | KINEMATIC | §6 (a mathematical claim inside the register section): "the reflection s ↦ 1 − s̄ that fixes Re s = 1/4" | Re(1 − s̄) = 1 − Re s, so the fixed set is Re s = 1/2. The reflection sends Re s = 1/4 to 3/4. On Part IV's chart x = 4 Re s the fold sends (1, 0) to (3, 0) and fixes x = 2. The claim contradicts the paper's line Re s = 1/2 (Level 6, "The reading") and Level 3, where the pair at Re s = 1/4 and 3/4 is off the line. | STRUCTURAL | **Falsifier:** `Probe5.quarter_is_moved`: `Hinge.fold (1,0) = (3,0) ∧ Hinge.fold (2,0) = (2,0) ∧ ¬ Hinge.onLine (1,0) ∧ Hinge.onLine (2,0)` (empty cone). The Python check gives Re 1/4 → 3/4 and fixed Re = 1/2. **Repair:** "fixes Re s = 1/2". | E22, E24 |
| Q5 | DEFINITIONAL (T4, T5) | Notation: "a pair member lands on the neutral state at its height with its magnitude and sign kept nowhere". Level 10 row: "its magnitude and sign kept nowhere … facts … that Part VIII proves as theorems on its own copy (`annihilate_forgets`, `pair_is_two_states_one_image`)". Abstract: "posited as such an event, one that loses a label" | The front note says the type governs over `VerificationEvent`'s docstring. That type keeps the pre-image state in its field `before`. Magnitude and sign can be recovered from every event, and the two partner events are distinct events with one landing state. "Kept nowhere" holds only of the landing state `after`. The two Part VIII theorems the row cites prove only that the sign is identified. That magnitudes are identified holds by computation alone. | COSMETIC | **Falsifier:** `Probe.event_keeps_the_label` proves `labelOf (evOf m t s) = some (m, s)`, that the partner events have equal `after` and are unequal, and that `(evOf 0 t s).after = (evOf 7 t s).after` (cone [propext]). **Repair:** "kept in no register of the landing state (the event itself records `before`)", and cite `annihilate_fixes_iff_neutral` for the magnitude. | E14 |
| Q6 | DEFINITIONAL | "The value" is used in three senses. (a) Abstract, Level 10 row and §4 "The run of record": a run "forces no value [at every closed configuration], so its flag is no proof of the value". (b) §4 F-Bridge: "Refusing the reading … holds the value open, the position Level 1 proves the interface leaves available"; §7: "refusing the reading leaves the value open". | (a) `the_run_does_not_force_the_value` proves only `¬ ∀ S, Closed S → Value S`, which is the law. Level 9 uses "proof of the value at a closed zero set, from any premise whatever", and in that sense the flag is a premise from which the value follows at every closed configuration where the value holds. (b) A reader who refuses only the reading but grants the act has the chart value at every resolution (`Charts.the_value_at_every_resolution`). Only the classical sentence is open. | COSMETIC | **Falsifier:** `Probe.flag_implies_value_somewhere` proves `(ran s = true → Value (nearWorld 4)) ∧ Closed (nearWorld 4) ∧ ¬ ∀ S closed, Value S` (empty cone). The seed's `Charts.the_value_at_every_resolution` has an empty cone. **Repair:** write "no proof of the value at every closed configuration", and "holds the classical sentence open". | E16, E7 |
| Q7 | DEFINITIONAL (T2) | §4 "The reading": "a configuration that has the value at resolution four can lack it at resolution fifty (`one_resolution_does_not_decide_the_next` none)" | The Notation makes a configuration a set of chart points, and `Value S` has no resolution parameter. The cited theorem concerns two different configurations, `nearWorld 4` and `nearWorld 50`, which are the readings of one zero pair. Here "configuration" means the zero set before reading. §1 (T2) excludes that sense ("a single resolution, not a single configuration"). | COSMETIC | **Falsifier:** `Probe5.two_configurations` proves `Charts.nearWorld 4 ≠ Charts.nearWorld 50` (empty cone). **Repair:** "a zero pair whose reading at resolution four has the value can have a reading at resolution fifty that lacks it". | E22 |
| Q8 | DEFINITIONAL (T3) | §7: "with the reading granted, that no act stands at the configurations where the zeros of ζ are read, which is the denial itself (`refusing_the_act_is_the_denial`)" | The cited composition takes `h0`, and also `hR`. §4's F-Bridge lists "the configurations closed and the term at resolution zero empty" as conditions separate from the reading, but §7 drops them. Without `h0` the claim fails: take a family whose term at resolution 0 is closed and off the line and whose other terms are empty. It has the value at every n ≥ 1, yet no act exists. (`hR` can be dropped; see T7.) | COSMETIC | **Falsifier:** `Probe.h0_needed` proves `(∀ n, Closed (Rbad n)) ∧ (∀ n, 1 ≤ n → Value (Rbad n)) ∧ ¬ ∃ Z : ActualZerosEvery, Z.zeros = Rbad` (empty cone). **Repair:** add "and the term at resolution zero empty". | E11, E10 |
| Q9 | DEFINITIONAL | Notation: "`LeastErasure S` is every point fixed by the registration". Level 2 cites `least_erasure_is_the_value` and `least_erasure_unconditional`, and Level 5 cites `root_at_zeros_is_least_erasure`, all from Part II and untagged. | Part II defines `LeastErasure Z := ∀ Z', SameRecord Z Z' → OffLine Z → OffLine Z'` (seed line 1043), a record-based predicate. It equals the pointwise form only through a theorem. The Notation's caveat "a theorem is read on the chart of its part" covers charts, not a second definition. The ledger gives no part tag here because the theorem names are unique. | COSMETIC | **Falsifier:** for Part II, the pointwise form `Iff.rfl` is rejected with a type mismatch (`q9neg`), while the record form is accepted by `Iff.rfl`. For Part III, the pointwise form is accepted by `Iff.rfl` (`q9pos`). `Probe5.partII_le_pointwise` gives the equivalence by theorem. **Repair:** add to the Notation that Part II defines least erasure through the record and proves it equivalent to the pointwise form. | E23, E22 |
| Q10 | DEFINITIONAL | "closed Stage 1", 11 occurrences (abstract, §1, Level 10 row, §3, §4, §6, §7), e.g. "every closed Stage 1 carries its forgetting" | The Notation fixes "Closed" as fold-closure of a configuration. A Stage 1 has no configuration, and every term of `Stage1` satisfies `stage1_closes`. The qualifier therefore selects nothing: this is a second sense of a defined term. | COSMETIC | **Falsifier:** `Probe5.every_stage1_is_closed`, i.e. `∀ s, stage1_closes s` (empty cone), and the occurrence count. **Repair:** drop "closed", or define "a Stage 1 closes on its two fields". | E22, E26 |
| Q11 | DEFINITIONAL (symbols) | §4 "The three exits": F-Computed "read at a resolution beyond 1/(2ε)" and F-Flux "detected above the bound ε", in the same paragraph. Also "configurations R" (§4, Box 1 caption) against "certified bound B with R ≤ ε" (§5). | ε names both the margin of a zero from the line (Level 6, "The reading") and the sensitivity bound on the residual (§5, F-Flux). R names both the family of configurations and the residual observable. | COSMETIC | **Falsifier:** grep, ε on paper lines 37, 126 and 154 (margin) against 154, 160 and 162 (bound); R on lines 72 and 122 against 162. **Repair:** rename the margin (for example η) and the residual (for example R_obs). | E26 |

---

## 2. Evidence log

| id | command (abridged) | key output |
|---|---|---|
| E1 | `ls -la; wc -l` on the four files | seed 10268 lines; ref. 8 184 lines; paper 10476 lines; cone table 997 lines |
| E2 | `sha256sum RH_Both_Sides_Seed_v2.0.5.lean Cargo_Delivered_Hardened.lean` | `a82ef4f0ad6ceb43a2d3cc964b110943dbb02f050ab88ff2845df1226a321a57`; `9b4f663ff6bd14a233fb…` (matches Box 2's prefix 9b4f663ff6bd14a2) |
| E3 | `python3 -I`: extract the ```` ```lean ```` block of Appendix A (paper lines 207 to 10476), hash it and compare | sha256 a82ef4f0…a57; `body == seed` True |
| E4 | `scratch/strip.py` (removes nested `/- -/` and `--` comments), then grep | raw `^theorem` lines 739 and `^axiom` lines 1 (seed line 6552, inside a docstring); after stripping: theorems 738, `axiom` 0, `sorry|admit|native_decide` 0 |
| E5 | `scratch/fullnames.py` (namespace-tracked names) diffed against the table's unique names | 738 = 738, no difference |
| E6 | `lean seed.lean` | exit 0 in 42 s, 259 unguarded print lines, no error or warning; `set_option linter.unusedVariables false` occurs once (line 10224, `stage2_optional_corroboration`) |
| E7 | `census.lean` = seed + `#print axioms` for all 738 names | none 428, [propext] 42, [propext, Quot.sound] 210, [propext, Classical.choice, Quot.sound] 58, sorryAx 0; as a set, identical to the table. The table's first 259 lines are the seed's own prints and its last 738 the census. `Charts.the_value_at_every_resolution`, `Hardening.pair_world_lacks_le`, `PhysicoFormal.the_carrier_alone_decides_nothing`, `Hinge.centred_yet_off` and `Charts.one_resolution_is_not_enough` all have an empty cone |
| E8 | `probe1.lean` = seed + Box 1 verbatim + prints | exit 0, no warning. `classical_rh_from_the_act_every` none; `classical_rh_from_the_act` none; `the_act_every_is_the_value_packaged` [propext, Quot.sound]; `refusing_the_act_is_the_denial` [propext, Quot.sound]; `value_collected` none; `cargo_binding_on_the_seed` none; `Charts.ActualZerosEvery.atRes` none; `ApparatusCargo.computation_enacts_stage1` none. All seven Box 1 lines match |
| E9 | `scratch/conecheck.py` plus the list-form check | 87 inline cone citations and 24 list citations (§5) all match the compiler, with no mismatches and nothing unresolved |
| E10 | probe1 `Probe.packaged_without_hR` and `Probe.refusing_without_hR` (`h0` only, via `value_closed : Value S → Closed S`) | compile; cones none and [propext] |
| E11 | probe1 `Probe.h0_needed` (Rbad: pair world at 0, empty at n ≥ 1) | compiles, none |
| E12 | probe1 `Probe.collected_one_content`: with `hR` and `h0`, `(∃ A : ActualZeros, A.zeros = collect R) ↔ ∃ Z : ActualZerosEvery, Z.zeros = R` | compiles, [propext, Quot.sound] |
| E13 | probe1 `Probe.cargo_does_not_establish_an_act`; `sed -n 10134,10268p seed_nocomment.lean \| grep -cE "Config\|ActualZeros\|Value\|LeastErasure"` | compiles, none; grep count 0 |
| E14 | probe1 `Probe.event_keeps_the_label` | compiles, [propext] |
| E15 | probe1 `Probe.bridge_constructive` (statement of `bridge_from_realization`, proved by deciding `δ ≤ R` and `p.1 = 0`) | compiles, none |
| E16 | probe1 `Probe.flag_implies_value_somewhere` | compiles, none |
| E17 | probe1 `Probe.cargo_line_is_offset_line : ApparatusCargo.onLine = RememberedOffered.onLine := rfl` | compiles, none |
| E18 | `probe2.lean` (`import Lean` + seed + Box 1 + `#ledgerdeps`, a direct and transitive scan of `getUsedConstants` against the 55 distinct Level 1 to 9 ledger names) | every-resolution conditional: direct [], transitive []. One-configuration conditional: direct [], transitive [Hardening.le_iff_value]. Packaging: direct [Charts.the_act_at_every_resolution], transitive [the_act_at_every_resolution, bidirectional_halted_uniduction, row_four_from_the_zero_side, prime_side_halts, the_atomic_proof, no_closed_principle_decides, the_one, the_atomic_necessity]. Refusal: the same transitive set. `value_collected`, `cargo_binding_on_the_seed`, `the_run_does_not_force_the_value`, `force_witness_closure` and `stage1_closes`: [] |
| E19 | `probe3.lean` / `probe4.lean` (`#nsdeps`, `#whichRO`: namespaces reached through types and values) | every-resolution conditional: RememberedOffered, Charts. One-configuration: RememberedOffered, Hardening. Packaging: RememberedOffered, Charts, TOE0 (`TOE0.RA₀` from the type of `the_act_at_every_resolution`). Cargo binding and `stage2_optional_corroboration`: ApparatusCargo only. Run theorems: ForceWitness; `force_witness_closure` also touches `RememberedOffered.calm._proof_38`, a compiler-shared auxiliary proof that is not prosecuted |
| E20 | `lean ref8.lean`; `sed -n 10111,10268p seed.lean > cargo_alone.lean; lean cargo_alone.lean` | ref. 8 exit 0 with every pin passing silently; the cargo section compiles standalone with exit 0, and line 10,110 is the last line of Part VIII's prints |
| E21 | `python3 -I reader.py` (Lean's `readAt` reimplemented with half-even rounding and clamping) | spot values `[0,0,1,-1,-2,2,3,-3]` match `one_resolution_is_not_enough`. For σ = a/b with b < 120: 0 violations of "off the line at every n > 1/(2ε)" and 0 violations of "onto the line when \|σ − 1/2\| < 1/(4n)". The tight threshold N satisfies min N·4\|δ\| = 1.0, so 1/(2ε) is sufficient but not tight |
| E22 | `probe5.lean` | `closed_yet_off` [propext, Classical.choice, Quot.sound]; `quarter_is_moved`, `two_configurations`, `partII_le_pointwise` and `every_stage1_is_closed` all none; exit 0 |
| E23 | `q9neg.lean`: `example … PrimeFreedom.LeastErasure Z ↔ ∀ z, Z z → PrimeFreedom.reg z = z := Iff.rfl`; `q9pos.lean`: Part III's pointwise form and Part II's record form by `Iff.rfl` | q9neg exit 1, "type mismatch Iff.rfl"; q9pos exit 0, 0 errors |
| E24 | `python3 -I -c` reflection (Re, Im) ↦ (1 − Re, Im) | Re 1/4 → 3/4; fixed Re = 1/2; on x = 4 Re s, Re 1/4 is x = 1 and the line is x = 2 |
| E25 | `probe6.lean`: `Probe6.t6_clauses` and `Probe6.root_from_conjunct_two` | compile; [propext, Classical.choice, Quot.sound] |
| E26 | grep on paper lines 1 to 202 | "closed Stage 1": 11 occurrences on lines 15, 22, 41, 64, 72, 166, 174. "not steps inside those proofs": lines 64 and 184. "which the cargo's theorems establish": line 176. "configuration is not closed, a zero off the line": line 68. "fixes Re s = 1/4": line 166. "kept nowhere": lines 26, 41, 160. "its flag is no proof of the value": lines 15, 41, 130. "holds/leaves the value open": lines 154, 178. ε as margin: lines 37, 126, 154; ε as bound: lines 154, 160, 162. R as configurations: lines 72, 122; R as residual: line 162 |
| E27 | `python3 -I` signature count and unit chain | `stage2_optional_corroboration`: 9 hypotheses. `classical_rh_from_physico_formal_closure`: 8. `classical_rh_from_identification_gap_and_bound`: 5. Kernel number at T₀ is 2725 × 693147 = 1888825575, and k_B × that / 10⁹ = 2.6078051e-23 J against k_B × 2.725 × ln 2 = 2.6078058e-23 J. ln 2 truncated at 6 decimals is 0.693147 (True) |

---

## 3. Per-target results

**T1. Box 1's six compositions, their hypotheses and every citation.**
- Box 1 compiles verbatim against the seed, and all seven printed cones match (E8).
- **`h0`** is necessary: Q8 and E11 give the counterexample.
- **`hR`** is not necessary for the packaging or the refusal. On the offset chart, `Value S → Closed S`, and `R 0 = ∅` is closed. `Probe.packaged_without_hR` proves the packaging from `h0` alone with an empty cone (E10). The paper's sentences state `hR` as a sufficient hypothesis "of its type", so this is an economy point, not an error.
- **Citations checked:**
  - Abstract: correct.
  - §1: correct; "one content" is confirmed by E12.
  - Level 10 row: all cones correct (E8, E9).
  - §4 capstone: "first conjunct" matches the `rw [(… R hR).1]` step.
  - "The reading": `h0` is a hypothesis of exactly the two packaging compositions.
  - "The three exits": all three conditions are stated.
  - §3's census of what the compositions use is internally inconsistent (Q2).
  - §7 drops `h0` (Q8).

**T2. "A single resolution, not a single configuration"; two supplies carrying one content.**
- The sentence in §1 is consistent with the Lean:
  - `value_collected` makes the collected configuration carry exactly the every-resolution value.
  - E12 proves that, under `hR` and `h0`, an act at the collected configuration exists exactly when an act at every resolution exists.
  - `one_resolution_does_not_decide_the_next` shows a one-resolution reading is substantive.
- The regression is elsewhere: §4 "The reading" uses "configuration" for the pre-reading zero pair (Q7).
- As in T1, `hR` is not needed for E12, since `Value` implies `Closed`.

**T3. F-Bridge by branches; the §7 answer.**
- Branch (c) holds: asserting that no act stands, with the reading, closedness and `h0`, is the denial (`refusing_the_act_is_the_denial`, E8). It also holds without closedness (E10), so the branch in which closedness is refused collapses into the denial and creates no fourth position.
- Branch (d) holds: refusing only the posit is no exit, since no run or event appears in any Box 1 signature (E8, E18).
- "Every branch leaves the cargo's theorems standing" holds, because the cargo's statements are unconditional and mention no configuration (E13).
- Defects found:
  - Branch (a), "refusing the reading … holds the value open", is true of the classical sentence but not of the chart value once the act is granted (Q6b).
  - The §7 answer omits `h0` (Q8).

**T4. Front note on docstrings and the governing types.**
- The two docstrings named do say more than their types:
  - `VerificationEvent` (seed line 10151): "one label forgotten", though a neutral event forgets nothing.
  - `ActualZerosEvery` (line 8640): that the ζ readings form such a family.
- The rule is kept in the Notation and the Level 10 row ("loses a label exactly when the state is a pair member").
- It is broken twice:
  - §7 asserts the act at the ζ readings, which is the content of the `ActualZerosEvery` docstring, and assigns it to the cargo's theorems (Q1).
  - "Kept nowhere" says more than `VerificationEvent`'s type, which keeps `before` (Q5).

**T5. What the seed names a forgetting; later uses of "forgetting", "loses a label" and "kept nowhere".**
- The seed does name the landing a forgetting: field `h_forget`, theorem `local_computation_is_forgetting`, field `Stage1.forgetting_done`.
- "Loses a label exactly when the state is a pair member" holds by computation on the cargo's copy. Part VIII proves it on its own copy with `annihilate_fixes_iff_neutral`.
- Annihilation also identifies magnitudes (E14). Under the seed's convention the one label is the sign (Part VIII's docstrings), and §5 states that the count is of listed labels, so this is consistent.
- Level 4's "forced forgetting" refers to the record, that is, registration, which `map_reg` identifies with annihilation, so it is consistent too.
- §7's "The cargo proves … losing a label" is true by computation, and the Level 10 row says the cargo section carries it by computation rather than as a theorem. This is wording only and not prosecuted.
- Defect found: "kept nowhere" (Q5).

**T6. Level 1's sentence against `the_unconditional_route_is_blocked`.** Checked, nothing found.
- E25 shows each clause is a projection of the theorem:
  - "no premise shared by every reflection-closed configuration … forces the value" is conjunct 2;
  - "the root included" is conjunct 3, and it also follows from conjunct 2 because `SelfGrounding R` yields R;
  - "no reading of the record decides it" is conjunct 4;
  - "every premise that does force it is the value or strictly stronger" is conjunct 5.
- "Forces" is used uniformly to mean "at every closed configuration" in the abstract, Level 1 and §4.
- The cones of `the_unconditional_route_is_blocked` and `premise_trichotomy` ([propext, Classical.choice, Quot.sound]) match.

**T7. Inputs in each conditional's signature and the packaging's added hypotheses.**
- The sentence is true as stated:
  - `classical_rh_from_the_act_every` takes `(h_read) (Z) (hZ)`, and `classical_rh_from_the_act` takes `(h_read) (A) (hA)`: the reading and the act with its zero-set equation, and nothing else.
  - The packaging adds `hR` and `h0`, and the refusal adds `h_read`, `hR` and `h0`.
- `hR` is dispensable (E10). This makes the packaging stronger than printed, not wrong.
- The census sentence of §3 next to it is the defect (Q2).

---

## 4. Checks that found nothing

- Digests, sizes and identity:
  - The seed sha256 and ref. 8 prefix match.
  - Appendix A is byte-identical to the seed.
  - Line counts are 10,268 and 184.
  - The 10,110 boundary is correct, and the cargo section compiles alone, so it depends on nothing above it (E2, E3, E20).
- Census: 738 theorems, 0 `axiom` commands, and 0 sorry, admit or native_decide outside comments. Box 2's cone tally 428/42/210/58 was regenerated, and the table equals 259 seed prints plus 738 (E4, E5, E7).
- Every cone printed in the prose matches the compiler: 111 citations, including all target cones (E8, E9).
- §5 counts are correct:
  - eight inputs, nine inputs, and "three inputs printed as five hypotheses";
  - the five physical premises are unused in `stage2_optional_corroboration` but each is used in `classical_rh_from_physico_formal_closure`;
  - one linter-off option (E6, E27).
- The §5 unit chain is homogeneous for the heat: k_B·N/10⁹ = k_B·T·ln 2, and truncating ln 2 lowers the gap (E27). The units of ε, a flux, against δ = n₀r₀q₀ cannot be decided from the text because the unit of the population is not stated, so nothing is prosecuted there.
- §5's claim that `bridge_from_realization` admits a constructive proof is correct: E15 has an empty cone.
- The reader's rule thresholds in Level 6, "The reading" and F-Computed hold. The bound 1/(2ε) is sufficient, and the half-step clause is exact (E21).
- Level 3's points (1, 0) and (3, 0) about x = 2 are correct (`centred_yet_off`). `independence_forces_truth` matches Level 1's sentence. `the_atomic_proof` parts II to IV and V are as cited.
- Every ledger name shared by two parts carries its part tag. The cargo's line equals the offset chart's by `rfl` (E17).
- `the_charts_are_one` maps the four chart-bound act types. `PrimeAct` reaches the offset chart through `toActual` and `ActualZerosEvery` through `atRes`, so "every act structure" holds by composition.
- The ledger's level labels and item counts (ten levels, eight items for Levels 2 to 9, six compositions, three exits) are consistent across the abstract, §1, §3 and the ledger.
