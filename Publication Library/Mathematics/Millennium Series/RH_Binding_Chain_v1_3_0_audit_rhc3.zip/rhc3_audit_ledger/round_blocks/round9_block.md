# rhc3 · Round 9 · kinematic + definitional (cap lifted by the architect, 2026-10-13 17:09: "Complete the audit cycle and forge")
controls digest 039ff21731219e3e (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
protocol note: from this round the prosecutor is told that planted defects of three kinds exist, placement and count withheld
errata: none · declared targets: N1-N4 (round-8 additions), prosecuted as T1-T4
leak-scan: CLEAN
findings: V1-V7; V1, V6 and V2 credited to controls C1, C2 and C3; W-1, W-2, W-4 filed from V3, V4, V7; W-3 refuses V5; W-5, W-6 filed from the defense end-to-end read (every cited type printed by #check and read against its ledger gloss, rows 1-10, plus Sections 1-7 whole)
arbitration: 5 EARNED, 1 REFUSED-STRUCTURAL
integration: 5 sweep specs, pre PASS on r8, post PASS on r9; 96 specs re-verified PASS; checker RESULT PASS; spine lock VERIFY PASS; Box 1 unchanged from r7
additions declared (round-10 targets): P1 rows 4 and 5 "the root"; P2 the null sentence of Section 5; P3 Section 6 "deed"; P4 the capstone's "the packaging's type"; P5 "all four cones"
controls: 3/3 SELF
verdict: CONTINUE (no prereg hit; debt from rounds 1, 2 and 4 open, clean streak 0/2)
new version: cand_v1_3_0_r9.md
