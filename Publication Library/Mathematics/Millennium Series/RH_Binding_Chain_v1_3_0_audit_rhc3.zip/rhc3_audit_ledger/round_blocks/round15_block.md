# rhc3 · Round 15 · kinematic + definitional
controls digest 0c33b0044ad630ea (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
errata: none · declared targets: U1, U2 (round-14 additions), prosecuted as T1, T2
leak-scan: CLEAN
findings: G1-G4; G1, G2, G3 credited to controls C2, C3, C1; DD-1 filed from G4 (a regression of the defense's own CC-3 addition)
arbitration: 1 EARNED
integration: 1 sweep spec, pre PASS on r14, post PASS on r15; 106 specs re-verified PASS (CC-3 superseded by DD-1); checker RESULT PASS; spine lock VERIFY PASS; standing rule from this round: no defense-side additions beyond the minimal repair of a filed finding
additions declared (round-16 targets): V1 the Notation's Part II chart sentence in the seed's own words
controls: 3/3 SELF
verdict: CONTINUE (clean streak 0/2)
new version: cand_v1_3_0_r15.md
