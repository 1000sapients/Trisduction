# rhc3 · Round 4 · limit + symmetry (re-run of void round 3)
controls digest 1fce618032d346fc (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
errata: none · declared targets: D1-D6 (round-3 additions) and the r3 joint repairs, prosecuted as T1-T8
leak-scan: CLEAN
findings: R1-R12; R5, R7 and R12 credited to controls C1, C3 and C2; I-1..I-5 (joints from the r3 end-to-end read) and I-6..I-14 (R1-R4, R6, R8-R11) filed; I-15 (spine-lock regression on C6, found at verify) filed
arbitration: 11 EARNED, 4 SCOPED; subtitle held under the Title Lock (I-14); seed docstrings scoped, the seed byte-fixed (I-12, I-13)
integration: Box 1 grows to six compositions, compiled against the seed, cones diffed against the printed lines: MATCH; 15 sweep specs, pre PASS on r3/r3j, post PASS on r4; 71 specs re-verified PASS with supersessions F-4, H-4, H-5, I-3 recorded; checker RESULT PASS (143 names); spine lock VERIFY PASS (C1 FORTIFIED precision); end-to-end read of abstract, front note, Notation, Section 1, Level 10 row, Section 3, Section 4 capstone, reading, boundary, exits, Section 7; two joints repaired in-round (conditional's signature count, the one-content conditions)
additions declared (round-5 targets): E1 Box 1 packaging compositions and their citations; E2 Section 1 twin paragraph (resolution, not configuration; two structures, one content); E3 F-Bridge by branch (Section 4, Section 7); E4 front-note docstring sentence; E5 Notation forgetting sentence and the label-loss sentences; E6 Level 1 "decides" sentence; E7 capstone signature sentence with hR and h0
controls: 3/3 SELF
verdict: CONTINUE-PREREG-BLOCK (4 prereg hits, debt; valid rounds 3, six-register coverage complete)
new version: cand_v1_3_0_r4.md
