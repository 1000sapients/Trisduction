# rhc3 · Round 19 · kinematic + definitional
controls digest 9e975b8f9943f392 (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
architect amendment (2026-10-13 22:38, "use it"): the Formal Master cited at version 3.0.8 (git FINAL_BINDING/RH Binding/RH_Both_Sides_Formal_Master_v3_0_8.lean, sha256 fe45b3c1eb69d8ef, byte-identical to the upload; 11,734 lines; the seed's 739 theorem lines and 1,393 docstring openers all present; 20 hunks of proof adjustment and notes); applied before prosecution as cand_v1_3_0_r19a.md, sweep AMEND-1 pre PASS on r18, post PASS; reference 7, Section 4 "The reading", F-Computed's ℂ clause and Section 7's second answer rewritten; the Master file placed in the blind folder as text
errata: none · declared targets: the amendment, prosecuted as T1
leak-scan: CLEAN
findings: N1-N4; N1, N2, N3 credited to controls C3, C2, C1; FF-1 filed from N4 (the amendment's description of the master closure's cargo conjunct)
arbitration: 1 EARNED
integration: 1 sweep spec, pre PASS on r19a, post PASS on r19; 109 specs re-verified PASS; checker RESULT PASS (153 names, Master names whitelisted); spine lock VERIFY PASS
additions declared (round-20 targets): Y1 the master-closure conjunct sentence; the rest of the amendment stands prosecuted once and is re-read at equal weight
controls: 3/3 SELF
verdict: CONTINUE (clean streak 0/2)
new version: cand_v1_3_0_r19.md
