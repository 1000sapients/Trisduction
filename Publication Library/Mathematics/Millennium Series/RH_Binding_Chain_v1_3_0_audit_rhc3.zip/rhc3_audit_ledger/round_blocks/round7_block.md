# rhc3 · Round 7 · parameter + provenance (re-run of void round 6)
controls digest 71362fb053a4943c (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
errata: none · declared targets: G1-G5 (round-6 additions), prosecuted as T1-T5
leak-scan: CLEAN
findings: N1-N4; N2 credited to control C1; L-1..L-3 filed (N1, N3, N4)
arbitration: 3 EARNED; L-3 repeats K-2's mechanism at Section 1
integration: Box 1 grows to eight compositions (the_collected_act_is_the_act_every; the_reading_every_is_keyed restated with R 0 empty), recompiled, cones diffed: MATCH; 3 sweep specs, pre PASS on r6, post PASS on r7; 86 specs re-verified PASS (I-8 superseded by L-3); checker RESULT PASS (145 names); spine lock VERIFY PASS; end-to-end read of Section 1 twin paragraph, Section 4 capstone, reading, exits, Section 5 close
additions declared (round-8 targets): H1 F-Bridge's physical branch and the realization shape (Sections 4, 5); H2 the_collected_act_is_the_act_every and Section 1's one-content sentence; H3 the_reading_every_is_keyed with R 0 empty and the reading paragraph; H4 the capstone's account of the eight compositions
controls: 1/3 SELF (C2 drift and C3 scope missed)
verdict: VOID-UNDERPOWERED (findings retained)
new version: cand_v1_3_0_r7.md
