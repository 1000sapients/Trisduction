# rhc3 · Round 6 · parameter + provenance
controls digest 90bc990dde488a2d (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
errata: none · declared targets: F1-F7 (round-5 additions), prosecuted as T1-T7
leak-scan: CLEAN
findings: P1-P5; P2 credited to control C1; K-1..K-4 filed (P1, P3, P4, P5)
arbitration: 4 EARNED
integration: Box 1 grows to seven compositions, the packaging and refusal restated without hR (closedness derived from the value inside the proof), recompiled, cones diffed: MATCH; dependency census re-run on the new terms, unchanged; 4 sweep specs, pre PASS on r5, post PASS on r6; 83 specs re-verified PASS (I-6 twice and J-5 superseded by K-2); checker RESULT PASS; spine lock VERIFY PASS; end-to-end read of abstract, Level 10 row, Section 3, Section 4 capstone, reading, exits, Section 5 close, Section 7; one joint repaired in-round ("its type")
additions declared (round-7 targets): G1 F-Bridge with the physical edition's branch, and Section 5's naming of it; G2 packaging and refusal without hR and every citation; G3 the_reading_every_is_keyed and the reading paragraph; G4 Section 3 "its refusal through the packaging"; G5 Section 7 "named by the parts each calls directly"
controls: 1/3 SELF (C2 drift and C3 scope missed)
verdict: VOID-UNDERPOWERED (findings retained; parameter and provenance re-run in round 7)
new version: cand_v1_3_0_r6.md
