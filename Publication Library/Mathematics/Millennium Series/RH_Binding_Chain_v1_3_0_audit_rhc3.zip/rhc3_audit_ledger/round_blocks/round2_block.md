# rhc3 · Round 2 · parameter + provenance
controls digest 0310dcac97328607 (SELF) · boot CHAIN D0 69df3f9d54a8 -> D3 73915965567c
errata: none · declared targets: A1-A7 (round-1 additions), prosecuted
leak-scan: CLEAN
findings: Q1-Q17; Q8, Q13 and the planted clause of Q17 credited to controls; G-1..G-17 filed (10 EARNED, 7 SCOPED)
integration: 17 sweep specs, pre PASS on r1 (G-17 one phrase in-round), post PASS on r2; all 23 round-1 specs re-verified PASS on r2; end-to-end read of front note, abstract, Section 1, Levels 1/4/6/10, Sections 3, 4, 6, 7; joints G-16, G-17 filed
additions declared (round-3 targets): B1 cargo_binding_on_the_seed (Box 1, Level 10, Section 4); B2 Level 6 reader's rule as input; B3 boundary paragraph and the posit sentences; B4 Section 1 twin-object sentence; B5 front-note cone provenance; B6 ladder_proof_lands_on_least_erasure route (Level 1, Section 4); B7 Level 10 floor and projection sentences
controls: 3/3 SELF
verdict: CONTINUE-PREREG-BLOCK
new version: cand_v1_3_0_r2.md
