# rhc3 · Round 13 · kinematic + definitional
controls digest 0caff37bcec01ddd (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
errata: none · declared targets: R1-R3 (round-12 additions), prosecuted as T1-T3
leak-scan: CLEAN
findings: B1-B4; B1 and B2 credited to controls C1 and C3; BB-1 filed from B3; BB-2 filed from B4 (repeat of V5/W-3)
arbitration: 2 EARNED
integration: 2 sweep specs, pre PASS on r12, post PASS on r13; 102 specs re-verified PASS (K-3 superseded by BB-2); checker RESULT PASS; spine lock VERIFY PASS
additions declared (round-14 targets): S1 row 3's citation placement; S2 Section 7's attribution rule sentence
controls: 2/3 SELF (C2 drift in Section 7 read as an announced dual use; the plant was too charitable)
verdict: VOID-UNDERPOWERED (findings retained and repaired)
new version: cand_v1_3_0_r13.md
