# rhc3 · Round 12 · kinematic + definitional
controls digest b7b6ad20c9d4402d (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
errata: none · declared targets: Q1 (round-11 addition), prosecuted as T1
leak-scan: CLEAN
findings: U1-U4; U1, U3, U2 credited to controls C1, C2, C3; AA-1 filed from U4; AA-2, AA-3 filed from the defense end-to-end read of every cited type against its gloss (hypotheses dropped at row 9 and in Section 5)
arbitration: 3 EARNED
integration: 3 sweep specs, pre PASS on r11, post PASS on r12; 100 specs re-verified PASS; checker RESULT PASS; spine lock VERIFY PASS
additions declared (round-13 targets): R1 row 3 "with an empty low band"; R2 row 9 "At every closed zero set the zero reports halt"; R3 Section 5 "at rate and heat at or above their floors"
controls: 3/3 SELF
verdict: CONTINUE (clean streak 0/2)
new version: cand_v1_3_0_r12.md
