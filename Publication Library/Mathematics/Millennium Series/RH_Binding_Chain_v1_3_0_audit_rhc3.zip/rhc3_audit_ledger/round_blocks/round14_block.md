# rhc3 · Round 14 · kinematic + definitional
controls digest c4eef7e876547dd5 (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
errata: none · declared targets: S1, S2 (round-13 additions), prosecuted as T1, T2
leak-scan: CLEAN
findings: D1-D5; D1, D2, D3 and D4 credited to controls C1, C2, C3 and C3 (the scope plant carried two widenings); CC-1 filed from D5; CC-2, CC-3 filed from the defense end-to-end read (direct constants of every Level 10 term recomputed by a compiled probe; the Notation's chart list against Part II's resolution-two chart)
arbitration: 3 EARNED
integration: 3 sweep specs, pre PASS on r13, post PASS on r14; 105 specs re-verified PASS (M-3 superseded by CC-1); checker RESULT PASS; spine lock VERIFY PASS
additions declared (round-15 targets): U1 Section 7's attribution list (the refusal, value_collected); U2 the Notation's Part II resolution-two chart
controls: 3/3 SELF
verdict: CONTINUE (clean streak 0/2)
new version: cand_v1_3_0_r14.md
