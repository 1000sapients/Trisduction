# rhc3 · Round 5 · kinematic + definitional
controls digest 3eb4d7d063f2fe4b (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
errata: none · declared targets: E1-E7 (round-4 additions), prosecuted as T1-T7
leak-scan: CLEAN
findings: Q1-Q11; Q1, Q3 and Q4 credited to controls C3, C2 and C1; J-1..J-8 filed (Q2, Q5-Q11)
arbitration: 8 EARNED; J-5 repeats I-9's mechanism at Section 7
integration: 8 sweep specs, pre PASS on r4, post PASS on r5; 79 specs re-verified PASS (F-3 superseded by J-2); Section 3 census re-derived in-session by a transitive constant scan of 13 proof terms, matching the prosecution's; checker RESULT PASS (144 names); spine lock VERIFY PASS; end-to-end read of Notation, Section 3, Level 10 row, Section 4 run of record, reading, exits, Section 5 capstone paragraph, Section 7
additions declared (round-6 targets): F1 Section 3 dependency census and its Section 7 counterpart; F2 Notation additions (Part II least erasure, closed Stage 1, the landing state and before); F3 Level 10 carrier sentence with annihilate_fixes_iff_neutral; F4 "no proof of the value at every closed configuration" and "classical sentence open" sites; F5 η, B.ε and B.R; F6 the zero-pair sentence of the reading; F7 Section 7 refusal conditions
controls: 3/3 SELF
verdict: CONTINUE (no prereg hit; debt from rounds 1, 2 and 4 open, clean streak 0/2)
new version: cand_v1_3_0_r5.md
