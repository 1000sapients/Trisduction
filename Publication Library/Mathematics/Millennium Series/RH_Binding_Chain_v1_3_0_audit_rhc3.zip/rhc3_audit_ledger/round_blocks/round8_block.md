# rhc3 · Round 8 · kinematic + definitional (the autorun cap)
controls digest f1227337707e7d06 (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
errata: none · declared targets: H1-H4 (round-7 additions), prosecuted as T1-T4
leak-scan: CLEAN
findings: M1-M6; M2 credited to control C1; M-1..M-5 filed (M1, M3, M4, M5, M6)
arbitration: 5 EARNED; M-3 repeats K-3's census mechanism
integration: 5 sweep specs, pre PASS on r7, post PASS on r8; 91 specs re-verified PASS (K-3, L-1 superseded by M-3, M-1); checker RESULT PASS (145 names); spine lock VERIFY PASS; Box 1 unchanged from r7 (compiled, cones MATCH)
additions declared (open targets for a resumed cycle): N1 F-Bridge's physical branch, direction restored; N2 Section 3 and Section 7 census with the collected act; N3 Level 7 row's index range; N4 Section 7's cone sentence by declaration
controls: 1/3 SELF (C2 drift and C3 scope missed)
verdict: VOID-UNDERPOWERED (findings retained) · autorun cap of eight rounds reached, cycle OPEN
new version: cand_v1_3_0_r8.md
