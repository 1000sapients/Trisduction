# rhc3 · Round 1 · kinematic + definitional
controls digest 15459dd32c71eb3c (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c · SEAT EARNED (PhysOSᵀ 1.0.16p, project floor, digest unpublished)
errata: none (first round) · declared targets: none (first round)
leak-scan: CLEAN
findings: 23 prosecution rows P1-P23; P9 and the planted clauses of P2 and P11 credited to controls; residues filed
arbitration: F-1..F-23 per ledger (16 EARNED, 7 SCOPED)
integration: 23 sweep specs, pre PASS on r0, post PASS on r1; end-to-end read of front matter, Sections 1-7 and Box 1-2 joints; 5 joint collisions found and filed as F-23
additions declared (round-2 mandatory targets): A1 charts paragraph (Notation, the_charts_are_one); A2 Box 1 every-resolution conditional and reading paragraph; A3 Level 6 resolution reading of the refuter; A4 run/event two-types sentence (Section 3); A5 reference 8 and Box 2 hardened-cargo line; A6 foundation route toward proof (Level 1, Section 4); A7 two-input count and premise sentence (Section 4)
controls: 3/3 SELF
verdict: CONTINUE-PREREG-BLOCK (12 prereg hits, debt)
new version: cand_v1_3_0_r1.md
