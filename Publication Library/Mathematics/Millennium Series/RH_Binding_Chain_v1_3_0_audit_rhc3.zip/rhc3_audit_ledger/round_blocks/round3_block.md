# rhc3 · Round 3 · limit + symmetry
controls digest a9f47cf4014248f3 (SELF) · boot CHAIN D0 69df3f9d54a8 -> D1 657329bff9e1 -> D2 17e4896183f6 -> D3 73915965567c
errata: none · declared targets: B1-B7 (round-2 additions), prosecuted
leak-scan: CLEAN
findings: S1-S18; S1 and S15 credited to controls C3 and C1; H-2..H-14, H-16..H-18 filed (11 EARNED, 5 SCOPED)
integration: 16 sweep specs, pre PASS on r2, post PASS on r3; checker RESULT PASS (137 names); prior specs re-verified, F-2 and G-14 required phrases superseded by H-18 and H-17 on purpose and recorded in superseded.json, their banned phrases at zero; end-to-end read of abstract, front note, Sections 1-7, Boxes 1-2: five joints found (two senses of forgetting, a second ladder instance without its chart, the boundary's reading, the abstract's reading, "the one premise") and filed in round 4 as I-1..I-5
additions declared (round-4 targets): D1 Box 1 bound n >= 1 and the atRes print; D2 reading at one configuration as a premise (Section 1, Section 4); D3 F-Bridge and Section 7 refusal; D4 Level 10 carrier copy and neutral event; D5 "in the author's posit" sites; D6 Level 6 chart split and the Level 9 citation for the weakest premise
controls: 2/3 SELF (C2 drift missed)
verdict: VOID-UNDERPOWERED (findings retained; limit and symmetry re-run in round 4)
new version: cand_v1_3_0_r3.md; joint repairs on cand_v1_3_0_r3j.md
