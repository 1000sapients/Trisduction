#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""spine_lock.py · the Spine Lock manifest for the Automated Paper Upgrade protocol.

Makes the no-concession law checkable rather than promised. Detects the artifact's
register, harvests candidate load-bearing claims, locks them, refuses any concession
that arrives without a named geometric mechanism, and verifies the rewrite carries
the spine forward. Stdlib only. No row is ever rewritten.

  spine_lock.py detect  --file OLD.txt
  spine_lock.py init    --lock L.json --file OLD.txt --thesis "..." --title "..." [--subtitle "..."]
                        [--claims "C1::text|C2::text"]
  spine_lock.py claim   --lock L.json --id C4 --text "..." [--tier T|C|S|P|E]
  spine_lock.py concede --lock L.json --id C2 --mechanism SEAL_L_LIT --evidence "..." --from-tier T --to-tier C
  spine_lock.py retitle --lock L.json --to "..." --cut-claim C2 --mechanism ORIENT_SCOPE --evidence "..."
  spine_lock.py verify  --lock L.json --file NEW.md
  spine_lock.py digest  --lock L.json
"""
import argparse, json, os, re, sys, datetime, hashlib, unicodedata
import urllib.request, urllib.parse, urllib.error, subprocess, tempfile

# ---- the only admissible grounds for a concession -------------------------
# A claim may be scoped, demoted, or cut ONLY on one of these named geometric
# failures. Anything else is a declining-direction inflation and is refused.
SCOPES = {"CLAIM", "PHRASE", "HEADER"}

# Falsifier necessity typing. FORCED is the only kind admissible as a headline
# falsification criterion; the other two are barred or demoted, per §2.7a.
FALSIFIER_KINDS = {
 "FORCED":   "the paper's own geometry entails the prediction; seed-native, nothing imported carries it",
 "IMPORT":   "the prediction rests on something the paper takes as true and did not derive; barred as a headline criterion",
 "LOOPED":   "the falsifier anchors on a claim that anchors on the falsifier; barred outright",
}
MAX_FALSIFIERS = 3

MECHANISMS = {
 "SEAL_L_DELETION":  "deletion test returns a slot count other than three on a complete atomic claim",
 "SEAL_L_LIT":       "linguistic isolation test collision; two axes share surface vocabulary",
 "SEAL_G_GATE":      "a named gate of the twelve fails; the gate number and mechanism are recorded",
 "DET_COLLAPSE":     "post-projection Gram determinant at or below the parameter-free floor",
 "COND_GATE":        "conditioning of the correlation matrix at or above its gate",
 "ORIENT_SCOPE":     "the claim reads a truth-sign off the orientation-blind scalar",
 "TIER_INFLATION":   "the claim is stated above the grade its warrant earns",
 "REGISTER_INVAR":   "a chart-manufactured magnitude is read as a structure-fact",
 "ARITHMETIC":       "a printed figure does not reproduce at the declared seed",
 "WITNESS_ABSENT":   "a seal is asserted with no supplied determinacy witness",
}
TIERS = ["T","C","S","P","E"]           # theorem, conditional, structural, premise, engineering
TIER_RANK = {t:i for i,t in enumerate(TIERS)}   # lower index = stronger

def _norm_title(x):
    """Case, whitespace, dash and quote tolerant. The original renders all-caps under
    the edition's text-transform, so a case-sensitive compare would false-fault."""
    x = (x or "").lower()
    x = x.replace("\u2014","-").replace("\u2013","-").replace("\u00b7"," ")
    x = x.replace("\u2018","'").replace("\u2019","'").replace("\u201c",'"').replace("\u201d",'"')
    x = re.sub(r"[^a-z0-9]+"," ",x)
    return " ".join(x.split()).strip()

def _front_matter(text):
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.S)
    if not m: return {}
    fm = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1); fm[k.strip()] = v.strip().strip('"')
    return fm

T2_TOKENS = ["⟀","Ξ₀","Ø₀","V_F","V_E","V_ER","M_seal","PSP-","APEX-","sPSP","MD-PSP","CN-PSP",
             "Mosaic Seal","GOL","L_1","L_2","L_3","Trisduction","Trisductive","RA","RAM"]
T2_STRICT = ["⟀","Ξ₀","Ø₀","V_F","V_E","V_ER","M_seal","PSP-","APEX-","sPSP","Mosaic Seal","[⟀]"]
EDITION_SIGNALS = {
 "journal":     ["Tractatus","masthead","Keywords","Abstract","Correspondence","Competing interests"],
 "apex":        ["Apex Pristine","classification"],
 "textbook":    ["PART ","Chapter ","Key Points","In Practice"],
 "scripture":   ["surah","ayah","basmala","tafsir","word grid"],
 "encyclopedia":["headword","q.v.","see also","guide word"],
}
CLAIM_CUES = re.compile(
  r"(?:^|\s)(?:the (?:seminal |central |core |load-bearing )?(?:claim|thesis) is|"
  r"this paper (?:argues|claims|establishes|shows|develops)|we (?:claim|argue|establish|show)|"
  r"the (?:verdict|result) is|theorem|proposition|lemma|is sealed|issues \[|"
  r"\[⟀\]|\[X\]|\[\?\]|sealed at|broken at|under-determined)", re.I)

def now(): return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
def die(m): print("FAULT: "+m); sys.exit(2)
def load(p):
    if not os.path.exists(p): die(f"lock not found: {p}")
    return json.load(open(p,encoding="utf-8"))
def save(p,d):
    d["updated"]=now(); json.dump(d,open(p,"w",encoding="utf-8"),indent=2,ensure_ascii=False); return d
def read(p):
    if not os.path.exists(p): die(f"file not found: {p}")
    return open(p,encoding="utf-8",errors="replace").read()

# ---------------------------------------------------------------- detect
def detect_register(text):
    strict = {t:text.count(t) for t in T2_STRICT if text.count(t)}
    loose  = {t:len(re.findall(r"\b"+re.escape(t)+r"\b",text)) for t in T2_TOKENS}
    loose  = {k:v for k,v in loose.items() if v}
    distinct = len(loose)
    if strict:                       tier, why = "2", f"strict framework tokens present: {sorted(strict)}"
    elif distinct == 0:              tier, why = "0", "no framework vocabulary detected"
    elif distinct <= 3:              tier, why = "1", f"{distinct} distinct framework terms, none strict"
    else:                            tier, why = "2", f"{distinct} distinct framework terms without strict glyphs; treat as native"
    ed, best = "journal", 0
    for name, sigs in EDITION_SIGNALS.items():
        n = sum(1 for s in sigs if s.lower() in text.lower())
        if n > best: ed, best = name, n
    return {"tier":tier,"tier_evidence":why,"strict_tokens":strict,"framework_terms":loose,
            "edition":ed,"edition_signals_matched":best,
            "edition_confidence":"high" if best>=3 else ("medium" if best==2 else "low")}

def harvest_claims(text, cap=40):
    out=[]
    for para in re.split(r"\n\s*\n", text):
        s=" ".join(para.split())
        if len(s)<40: continue
        for sent in re.split(r"(?<=[.!?])\s+", s):
            if len(sent)<40 or len(sent)>400: continue
            if CLAIM_CUES.search(sent): out.append(sent.strip())
    seen=set(); ded=[]
    for c in out:
        k=c[:80].lower()
        if k not in seen: seen.add(k); ded.append(c)
    return ded[:cap]

# ---------------------------------------------------------------- commands
def cmd_detect(a):
    t=read(a.file); r=detect_register(t); c=harvest_claims(t)
    print("REGISTER DETECTION")
    print(f"  lingo tier ......... Tier {r['tier']}   ({r['tier_evidence']})")
    print(f"  edition ............ {r['edition']}   (confidence {r['edition_confidence']}, {r['edition_signals_matched']} signals)")
    if r["strict_tokens"]: print(f"  strict tokens ...... {r['strict_tokens']}")
    print(f"  framework terms .... {len(r['framework_terms'])} distinct")
    print(f"\nCANDIDATE LOAD-BEARING CLAIMS ({len(c)} harvested; the Defense seat confirms and completes)")
    for i,x in enumerate(c[:12],1): print(f"  [{i}] {x[:150]}{'...' if len(x)>150 else ''}")
    if len(c)>12: print(f"  ... and {len(c)-12} more")

def cmd_init(a):
    if os.path.exists(a.lock): die(f"lock already exists at {a.lock}; locks are write-once at init")
    t=read(a.file); r=detect_register(t)
    tier = a.tier or r["tier"]; ed = a.edition or r["edition"]
    claims={}
    if a.claims:
        for item in a.claims.split("|"):
            if "::" not in item: die(f"claim must be ID::text, got {item!r}")
            cid,txt=item.split("::",1); claims[cid.strip()]={"text":txt.strip(),"tier":None,"status":"HELD"}
    d={"schema":"spine_lock/2","created":now(),"artifact":os.path.basename(a.file),
       "artifact_sha256":hashlib.sha256(t.encode("utf-8",errors="replace")).hexdigest()[:16],
       "thesis":a.thesis,
       "title":{"original":a.title,"target":a.title,"status":"VERBATIM","retitled":None},
       "subtitle":{"original":a.subtitle or "","target":a.subtitle or "","status":"VERBATIM","retitled":None},
       "lingo_tier":tier,"original_edition":ed,"target_edition":"journal","detection":r,
       "claims":claims,"concessions":[],"fortifications":[],"log":[{"t":now(),"e":"init"}]}
    save(a.lock,d)
    print(f"LOCK INITIALIZED  {a.lock}")
    print(f"  thesis ....... {a.thesis[:110]}")
    print(f"  title ........ {a.title}")
    if a.subtitle: print(f"  subtitle ..... {a.subtitle}")
    print(f"  register ..... Tier {tier} carried forward | edition {ed} -> journal (hard default)")
    print( "  title status . VERBATIM  (negotiated artifact; moves only through 'retitle')")
    print(f"  claims ....... {len(claims)} registered")
    if not claims: print("  NOTE: zero claims registered. Register the spine with 'claim' before the rewrite.")

def cmd_claim(a):
    d=load(a.lock)
    if a.id in d["claims"]: die(f"claim {a.id} already registered; claims are write-once")
    if a.tier and a.tier not in TIERS: die(f"tier must be one of {TIERS}")
    d["claims"][a.id]={"text":a.text,"tier":a.tier,"status":"HELD"}
    d["log"].append({"t":now(),"e":"claim","id":a.id}); save(a.lock,d)
    print(f"CLAIM REGISTERED  {a.id}  tier={a.tier or 'unset'}  [HELD]")

def cmd_concede(a):
    d=load(a.lock)
    if a.id not in d["claims"]: die(f"unknown claim {a.id}")
    if a.mechanism not in MECHANISMS:
        print("REFUSED. A concession requires a named geometric mechanism. Admissible grounds:")
        for k,v in MECHANISMS.items(): print(f"  {k:18s} {v}")
        print("\nNo other ground is admissible. 'A reviewer might object', 'safer to hedge',")
        print("and 'this sounds too strong' are declining-direction inflations and are refused.")
        sys.exit(2)
    if not a.evidence or len(a.evidence.strip())<20:
        die("a concession requires executed evidence of at least 20 characters, not an assertion")
    if a.from_tier and a.from_tier not in TIERS: die(f"from-tier must be one of {TIERS}")
    if a.to_tier and a.to_tier not in TIERS: die(f"to-tier must be one of {TIERS}")
    if a.from_tier and a.to_tier and TIER_RANK[a.to_tier] < TIER_RANK[a.from_tier]:
        die("this is a promotion, not a concession; record it with 'fortify'")
    c=d["claims"][a.id]
    scope = (a.scope or "CLAIM").upper()
    if scope not in SCOPES:
        die(f"--scope must be one of {sorted(SCOPES)}; CLAIM is the only one that licenses a retitle")
    # A repair scoped to one adjective or one heading is not a claim the gate cut.
    # Recording both as CUT lets a title move off a phrase-level fix, which is
    # exactly the move the Title Lock exists to forbid.
    if scope == "CLAIM":  c["status"] = "SCOPED" if a.to_tier else "CUT"
    else:                 c["status"] = "HELD_SCOPED"
    c["conceded"]={"mechanism":a.mechanism,"gloss":MECHANISMS[a.mechanism],"evidence":a.evidence,
                   "from_tier":a.from_tier,"to_tier":a.to_tier,"scope":scope,
                   "licenses_retitle": scope=="CLAIM", "t":now()}
    if a.to_tier: c["tier"]=a.to_tier
    d["concessions"].append({"id":a.id,"mechanism":a.mechanism,"from":a.from_tier,"to":a.to_tier,
                             "scope":scope,"licenses_retitle":scope=="CLAIM","t":now()})
    d["log"].append({"t":now(),"e":"concede","id":a.id,"m":a.mechanism}); save(a.lock,d)
    print(f"CONCESSION RECORDED  {a.id}  scope={scope}  "
          f"{a.from_tier or '?'} -> {a.to_tier or ('CUT' if scope=='CLAIM' else 'HELD')}")
    print(f"  mechanism .. {a.mechanism}  ({MECHANISMS[a.mechanism]})")
    print(f"  evidence ... {a.evidence[:120]}")
    if scope != "CLAIM":
        print(f"  scope ...... {scope}: the claim is HELD; only the named {scope.lower()} is cut.")
        print("  retitle .... NOT licensed. A title moves only where a CLAIM was cut.")
    print("  This claim is now a mandatory named target for the Phase 2 cycle.")

def cmd_falsifier(a):
    """Register one falsification criterion and gate it before it reaches the page.

    The gate exists because a falsifier is the one place a paper volunteers an
    attack surface, and an unforced one points that surface at the codex rather
    than at the paper. The recorded exhibit is the IPG/MOND family: four
    falsification clauses were built on an orthodoxy import, and when the import
    retired all four had to be re-typed and one coordinate was hard-deleted on
    the anchor loop it had grown. None of that was a failure of the geometry. It
    was a failure of what the falsifiers took for granted.
    """
    d=load(a.lock)
    d.setdefault("falsifiers",[])
    kind=(a.kind or "").upper()
    if kind not in FALSIFIER_KINDS:
        print("REFUSED. Every falsifier is typed for necessity before it is admitted:")
        for k,v in FALSIFIER_KINDS.items(): print(f"  {k:8s} {v}")
        sys.exit(2)
    if kind == "LOOPED":
        die("a looped falsifier is barred outright; cut the loop at the claim side "
            "and re-derive the prediction from the geometry, or drop it")
    if kind == "IMPORT" and not a.tripwire:
        die("an IMPORT falsifier is not admissible as a headline criterion. Pass "
            "--tripwire to carry it beneath the register at its honest grade, or "
            "re-derive it as FORCED, or drop it. Do not print it as a criterion.")
    if not a.compromises.strip():
        die("a falsifier must name exactly what its firing compromises. 'The framework "
            "is falsified' is not a blast radius, it is an unaimed charge")
    if not a.conditions.strip():
        die("a falsifier must name the conditions under which it binds, so that a "
            "reader can tell a miss from a hit. Unconditioned criteria misfire")
    if not a.event.strip() or len(a.event.strip()) < 15:
        die("a falsifier must state the observable event that fires it, sharply")
    headline=[f for f in d["falsifiers"] if not f.get("tripwire")]
    if not a.tripwire and len(headline) >= MAX_FALSIFIERS:
        die(f"{MAX_FALSIFIERS} headline falsifiers already registered. Fewer and tighter "
            f"is the rule; a fourth is a fourth attack surface. Cut a weaker one first, "
            f"which needs no mechanism because a falsifier is not a claim")
    fid=a.fid or f"F{len(d['falsifiers'])+1}"
    rec={"id":fid,"kind":kind,"event":a.event.strip(),"conditions":a.conditions.strip(),
         "compromises":a.compromises.strip(),"tripwire":bool(a.tripwire),
         "imports":[s.strip() for s in (a.imports or "").split(";") if s.strip()],
         "claim":a.claim or None,"t":now()}
    d["falsifiers"].append(rec)
    d["log"].append({"t":now(),"e":"falsifier","id":fid,"kind":kind}); save(a.lock,d)
    print(f"FALSIFIER REGISTERED  {fid}  kind={kind}"+("  [tripwire, below the register]" if a.tripwire else ""))
    print(f"  event ....... {rec['event'][:110]}")
    print(f"  binds on .... {rec['conditions'][:110]}")
    print(f"  compromises . {rec['compromises'][:110]}")
    if rec["imports"]:
        print(f"  imports ..... {', '.join(rec['imports'])}")
        print("  CARRYING LAW: this falsifier caps at the weakest import above. It cannot")
        print("  carry the paper's verdict further than the thing it borrowed.")
    else:
        print("  imports ..... none declared; the prediction is carried by the geometry alone")
    print(f"  headline count {len([f for f in d['falsifiers'] if not f.get('tripwire')])}/{MAX_FALSIFIERS}")


def cmd_fortify(a):
    d=load(a.lock)
    if a.id not in d["claims"]: die(f"unknown claim {a.id}")
    c=d["claims"][a.id]
    if a.to_tier and a.to_tier not in TIERS: die(f"to-tier must be one of {TIERS}")
    if not a.evidence or len(a.evidence.strip())<20:
        die("a promotion requires the external mass that licenses it, stated in at least 20 characters")
    c["status"]="FORTIFIED"; c["fortified"]={"kind":a.kind,"evidence":a.evidence,
        "from_tier":c.get("tier"),"to_tier":a.to_tier,"t":now()}
    if a.to_tier: c["tier"]=a.to_tier
    d["fortifications"].append({"id":a.id,"kind":a.kind,"to":a.to_tier,"t":now()})
    d["log"].append({"t":now(),"e":"fortify","id":a.id}); save(a.lock,d)
    print(f"FORTIFICATION RECORDED  {a.id}  kind={a.kind}  tier -> {a.to_tier or c.get('tier')}")

STOP=set("""this that with from have been were will would could shall must than then when what which
where whose while about above after also among because before both each else even ever from into itself
more most much only other over same some such their there these they thing those through under upon very
whether within without your paper claim claims section sections result results does not are the and for
its it's a an of to in on by is as at be or if it we our us""".split())

NUMWORD = {"zero":"0","one":"1","two":"2","three":"3","four":"4","five":"5","six":"6",
           "seven":"7","eight":"8","nine":"9","ten":"10","eleven":"11","twelve":"12",
           "twenty":"20","thirty":"30","forty":"40","fifty":"50","sixty":"60"}

def _tok(s):
    """Unicode-aware word tokenizer. The ASCII class [a-z0-9]+ splits any accented
    name, so a paper citing Berut with its acute could never match a claim naming
    the same author, and the checker would report missing content that is present.
    Caught on a live run; the fix is to tokenize letters rather than ASCII."""
    return re.findall(r"[^\W_]+", s.lower(), flags=re.UNICODE)

def _fold(w):
    """Strip diacritics so an accented author name matches its own citation."""
    return "".join(c for c in unicodedata.normalize("NFKD", w)
                   if not unicodedata.combining(c))

def _stem(w):
    """Light suffix fold. The claim text in a lock is the registrant's own
    paraphrase, so its inflections are the scribe's choices and not the paper's.
    Demanding 'outperforms' where the paper writes 'will outperform', or
    'falsifiability' where it writes 'falsifiable', tests the summary's grammar
    rather than the claim's survival, which inverts what the check is for."""
    w = _fold(w)
    w = NUMWORD.get(w, w)
    for pre in ("un", "non", "in", "re"):
        if len(w) > len(pre) + 4 and w.startswith(pre):
            w = w[len(pre):]; break
    for suf in ("ability","ibility","ations","ation","ingly","edly","ings","ing",
                "ies","ied","es","ed","s","ly","al","ity","ive","able","ible"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            w = w[:-len(suf)]
            if len(w) > 3 and w[-1] == w[-2]:      # gemination: forbidd -> forbid
                w = w[:-1]
            return w
    return w

def _present(text, claim_text, floor=0.70):
    """Rarity-weighted presence. The claim survives only if its distinctive anchors
    survive, not merely its common vocabulary. Guards against a gutted rewrite
    scoring high on generic academic words.

    Matching is on folded stems over Unicode tokens, and the reason is a rule this
    protocol enforces everywhere else: a checker whose false positives are repaired
    by editing the artifact has stopped checking the artifact. On the live run that
    produced this fix, eight of eight reported absences were inflection, numeral
    form, or an accented name, and the only genuine loss the run surfaced was
    caught by reading the diff rather than by the score."""
    words = [w for w in _tok(claim_text) if len(w) > 3 and w not in STOP]
    if not words: return True, 1.0
    words = sorted(set(_stem(w) for w in words))
    hay = [_stem(w) for w in _tok(text)]
    freq = {}
    for w in hay: freq[w] = freq.get(w, 0) + 1
    hayset = set(hay)
    anchors = sorted(words, key=lambda w: freq.get(w, 0))[:max(3, len(words)//4)]
    def _hit(a):
        if a in hayset: return True
        # a stem that is a prefix of a present stem, or vice versa, is the same
        # word family. The anchor asks whether the claim's distinctive term
        # survives, not whether the registrant's inflection of it does.
        return any((h.startswith(a) or a.startswith(h)) and min(len(a), len(h)) >= 5
                   for h in hayset)
    anchors_ok = all(_hit(a) for a in anchors)
    overlap = sum(1 for w in words if w in hayset) / len(words)
    return (anchors_ok and overlap >= floor), overlap

def cmd_retitle(a):
    """A negotiated title moves only where the Concession Gate cut what it names.
    Same discipline as a concession: a named mechanism, executed evidence, and the
    cut claim it traces to. There is no other route to a title change."""
    d=load(a.lock)
    field = "subtitle" if a.subtitle else "title"
    if a.mechanism not in MECHANISMS:
        print("REFUSED. The title and subtitle are negotiated artifacts, not scribe output.")
        print("They move only where the Concession Gate cut what they name, on one of:")
        for k,v in MECHANISMS.items(): print(f"  {k:18s} {v}")
        print("\nA better phrasing, a punchier line, and a clearer framing are not mechanisms.")
        sys.exit(2)
    if a.cut_claim not in d["claims"]:
        die(f"unknown claim {a.cut_claim}; a retitle traces to the claim the gate cut")
    c=d["claims"][a.cut_claim]
    if c["status"] not in ("CUT","SCOPED"):
        die(f"claim {a.cut_claim} is {c['status']}; a title moves only where the gate cut or scoped what it names")
    if not a.evidence or len(a.evidence.strip())<20:
        die("a retitle requires executed evidence of at least 20 characters, not an assertion")
    old=d[field]["original"]
    if _norm_title(old)==_norm_title(a.to):
        die("the proposed title is the original; nothing to record")
    d[field].update({"target":a.to,"status":"RETITLED",
        "retitled":{"from":old,"to":a.to,"mechanism":a.mechanism,"gloss":MECHANISMS[a.mechanism],
                    "cut_claim":a.cut_claim,"evidence":a.evidence,"t":now()}})
    d["log"].append({"t":now(),"e":"retitle","field":field,"m":a.mechanism}); save(a.lock,d)
    print(f"RETITLE RECORDED  ({field})")
    print(f"  from ....... {old}")
    print(f"  to ......... {a.to}")
    print(f"  mechanism .. {a.mechanism} via {a.cut_claim}  ({MECHANISMS[a.mechanism]})")
    print("  Closest match to the negotiated original is the standard; this is on the record.")

def cmd_verify(a):
    d=load(a.lock); new=read(a.file)
    print("SPINE VERIFICATION  ·  the rewrite against the lock")
    print(f"  lock ....... {a.lock}")
    print(f"  rewrite .... {a.file}\n")
    faults=[]
    fm=_front_matter(new)
    r=detect_register(new)

    # --- the title gate: a negotiated artifact, checked before anything else ---
    for field in ("title","subtitle"):
        lk=d.get(field) or {}
        want=lk.get("target","") or ""
        if not want and field=="subtitle":
            print(f"  {field:9s}: none in the original, none required"); continue
        got=fm.get(field,"")
        if not got:
            ok = _norm_title(want) in _norm_title(new)
            src="body text"
        else:
            ok = _norm_title(got)==_norm_title(want)
            src="front matter"
        mark = "VERBATIM" if lk.get("status")=="VERBATIM" else "RETITLED"
        print(f"  {field:9s}: {'MATCH' if ok else 'MISMATCH'} ({src}, {mark})")
        if not ok:
            print(f"             lock wants : {want}")
            print(f"             rewrite has: {got or '(not found in front matter)'}")
            faults.append(f"{field} drifted from the negotiated original with no recorded retitle")

    tier_ok = r["tier"]==d["lingo_tier"]
    tgt = d.get("target_edition","journal")
    ed_ok = r["edition"]==tgt or fm.get("edition","")==tgt
    print(f"  tier     : rewrite reads Tier {r['tier']}; lock carries Tier {d['lingo_tier']}  ->  {'MATCH' if tier_ok else 'MISMATCH'}")
    print(f"  edition  : rewrite reads {fm.get('edition') or r['edition']}; target {tgt} (hard default)  ->  {'MATCH' if ed_ok else 'MISMATCH'}")
    if not tier_ok: faults.append(f"lingo tier drifted {d['lingo_tier']} -> {r['tier']}")
    if not ed_ok:   faults.append(f"edition is not the {tgt} hard default")
    print()
    held=scoped=cut=fort=missing=unknown=0
    for cid,c in sorted(d["claims"].items()):
        ok,score=_present(new,c["text"])
        st=c["status"]
        if st=="CUT":
            cut+=1; print(f"  {cid:5s} CUT       (mechanism {c['conceded']['mechanism']})  present={ok}")
            continue
        if not ok:
            missing+=1; faults.append(f"{cid} absent from the rewrite with no recorded concession (overlap {score:.2f})")
            print(f"  {cid:5s} ABSENT    overlap {score:.2f}   <-- FAULT")
            continue
        if st=="HELD":      held+=1;   print(f"  {cid:5s} HELD      overlap {score:.2f}  tier {c.get('tier') or '-'}")
        elif st=="SCOPED":  scoped+=1; print(f"  {cid:5s} SCOPED    overlap {score:.2f}  {c['conceded']['from_tier']} -> {c['conceded']['to_tier']}  ({c['conceded']['mechanism']})")
        elif st=="FORTIFIED":fort+=1;  print(f"  {cid:5s} FORTIFIED overlap {score:.2f}  tier {c.get('tier') or '-'}")
        elif st=="HELD_SCOPED":
            scoped+=1
            cc=c.get("conceded",{})
            print(f"  {cid:5s} SCOPED    overlap {score:.2f}  tier {c.get('tier') or '-'}  "
                  f"({cc.get('mechanism','?')} on {cc.get('scope','?')})")
        else:
            # A status the printer does not recognise must never make a claim
            # disappear from the census. Silent census loss is the one failure
            # the hygiene contract forbids outright, and an unknown status is
            # exactly how it happens.
            unknown+=1
            print(f"  {cid:5s} STATUS?   overlap {score:.2f}  unrecognised status {st!r}  <-- FAULT")
            faults.append(f"{cid} carries unrecognised status {st!r}; census cannot account for it")
    thesis_ok,tscore=_present(new,d["thesis"])
    # --- the falsification register --------------------------------------
    fz = d.get("falsifiers", [])
    head = [f for f in fz if not f.get("tripwire")]
    trip = [f for f in fz if f.get("tripwire")]
    if fz:
        print(f"\n  FALSIFIERS  {len(head)} headline"
              + (f" + {len(trip)} tripwire" if trip else "") + f"  (cap {MAX_FALSIFIERS})")
        for f in fz:
            tag = "tripwire" if f.get("tripwire") else "headline"
            print(f"    {f['id']:4s} {f['kind']:7s} {tag:9s} compromises: {f['compromises'][:58]}")
            if f.get("imports"):
                print(f"         caps at the weakest import: {', '.join(f['imports'])}")
        bad = [f['id'] for f in head if f['kind'] != "FORCED"]
        if bad:
            faults.append(f"headline falsifier(s) {', '.join(bad)} are not FORCED; an unforced "
                          f"criterion points its attack surface at what the paper borrowed")
            print(f"    <-- FAULT: {', '.join(bad)} headline but not FORCED")
        if len(head) > MAX_FALSIFIERS:
            faults.append(f"{len(head)} headline falsifiers against a cap of {MAX_FALSIFIERS}")
            print(f"    <-- FAULT: over the cap")
    else:
        print(f"\n  FALSIFIERS  none registered  (advisory: the register is optional, and a "
              f"paper\n              carrying criteria on the page with none in the lock has not "
              f"gated them)")

    print(f"\n  thesis carried forward: {'YES' if thesis_ok else 'NO'}  (overlap {tscore:.2f})")
    if not thesis_ok: faults.append("the original thesis is not carried forward; the spine is broken")
    n=len(d["claims"])
    accounted = held + fort + scoped + cut + missing + unknown
    print(f"\n  CENSUS  {n} registered | {held} held | {fort} fortified | {scoped} scoped | "
          f"{cut} cut | {missing} absent" + (f" | {unknown} unrecognised" if unknown else ""))
    if accounted != n:
        # The reconciliation is the point of a census: registered in must equal
        # dispositioned out. A printer that drops a row is how a claim leaves a
        # ledger without anyone deciding that it should.
        print(f"  CENSUS FAULT: {n} registered but {accounted} dispositioned")
        faults.append(f"census does not reconcile: {n} registered, {accounted} dispositioned")
    if n: print(f"  concession rate: {(scoped+cut)}/{n} = {(scoped+cut)/n:.0%}  (every one carries a named mechanism)")
    sf=d.get("surfaces")
    if not sf:
        faults.append("the surface scan of 2.1a has not run; 'surfaces' is unpopulated and a "
                      "rewrite cannot reach Phase 2 without knowing which addresses this work "
                      "already owns")
    else:
        print(f"\n  surfaces: {sf.get('disposition')}  (scanned {sf.get('scanned')})")
        if sf.get("disposition")=="AMBIGUOUS":
            faults.append("surface scan returned AMBIGUOUS; ask before any replacement is planned")
    if faults:
        print("\n  VERIFY: FAULT")
        for f in faults: print(f"    - {f}")
        sys.exit(1)
    print("\n  VERIFY: PASS  ·  spine carried, register matched, every concession mechanism-named")

# ---- appended by v1.2.0 · the surface scan -------------------------------
def _norm_title_loose(x):
    """Key 4. Folds case and punctuation, strips a subtitle after ':' and a
    trailing edition suffix after ' - '. Catches the bare/-Journal pair."""
    x = (x or "").split(":")[0]
    x = re.sub(r"\s+-\s+(journal|source|edition|preprint|draft|annotated)\b.*$", "", x,
               flags=re.I)
    return _norm_title(x)

def _http(url, token=None, timeout=90):
    req = urllib.request.Request(url, headers={"User-Agent": "spine-lock"})
    if token:
        req.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.getcode(), json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b"{}")
        except Exception:
            return e.code, {}
    except Exception as e:
        return 0, {"_t": str(e)[:120]}

def scan_git(titles, repo="1000sapients/Trisduction", branch="main"):
    """Unauthenticated. Blobless clone; falls back to the Contents API only if git
    is unavailable, since the API is rate-capped and shared across a sandbox."""
    import subprocess, tempfile
    try:
        td = tempfile.mkdtemp(prefix="sl_")
        subprocess.run(["git", "clone", "--filter=blob:none", "--no-checkout", "--depth", "1",
                        "-q", "-b", branch, "https://github.com/%s.git" % repo, td],
                       check=True, capture_output=True, timeout=300)
        out = subprocess.run(["git", "ls-tree", "-r", "--name-only", "HEAD"], cwd=td,
                             capture_output=True, text=True, check=True).stdout
    except Exception as e:
        return {"state": "UNREADABLE", "why": str(e)[:100], "hits": []}
    hits = []
    for p in out.splitlines():
        if not p.startswith("Publication Library/"):
            continue
        stem = os.path.splitext(os.path.basename(p))[0]
        for k, t in titles:
            n = _norm_title(stem) if k != 4 else _norm_title_loose(stem)
            if n and n == t:
                hits.append({"path": p, "key": k}); break
    return {"state": "PRESENT" if hits else "ABSENT", "hits": hits}

def scan_ia(ident):
    """Three-valued, per the publication layer. A dark identifier is spent forever
    and is never read as absent."""
    c, d = _http("https://archive.org/metadata/%s" % urllib.parse.quote(ident))
    if c == 0:
        return {"state": "UNREADABLE", "why": d.get("_t", ""), "identifier": ident}
    if d.get("is_dark") is True:
        return {"state": "DARK", "identifier": ident}
    if d.get("metadata"):
        return {"state": "PRESENT", "identifier": ident,
                "mediatype": d["metadata"].get("mediatype"),
                "files": [f["name"] for f in d.get("files", []) if not f["name"].startswith("__")]}
    return {"state": "ABSENT", "identifier": ident}

def scan_zenodo(titles, md5=None):
    """Owner-scoped is the only complete channel and it needs the token. Absent the
    token the surface is UNREADABLE: a zero from the public search is not evidence."""
    tok = os.environ.get("ZENODO_TOKEN", "")
    if not tok:
        return {"state": "UNREADABLE",
                "why": "ZENODO_TOKEN unset; the public search is not a substitute for the "
                       "owner-scoped channel and a search zero is not evidence of absence",
                "hits": []}
    rows, page = [], 1
    while page <= 20:
        c, d = _http("https://zenodo.org/api/user/records?size=100&page=%d&sort=newest" % page, tok)
        if c != 200:
            return {"state": "UNREADABLE", "why": "http=%d" % c, "hits": []}
        h = (d.get("hits") or {}).get("hits") or []
        rows += h
        if len(h) < 100:
            break
        page += 1
    hits = []
    for r in rows:
        title = r.get("title") or ""
        # md5 is evaluated ALWAYS and never as a fallback. It was written as a
        # for/else, so byte-identity, the strongest key there is, went unconsulted
        # whenever any weaker key hit first. Found on the second live run.
        bytes_match = bool(md5) and any((f.get("checksum") or "").replace("md5:", "") == md5
                                        for f in (r.get("files") or []))
        matched = None
        for k, t in titles:
            n = _norm_title(title) if k != 4 else _norm_title_loose(title)
            if n and n == t:
                matched = k; break
        if matched is not None or bytes_match:
            hits.append({"recid": str(r.get("id")), "doi": r.get("doi"),
                         "concept": str(r.get("conceptrecid")),
                         "concept_doi": r.get("conceptdoi"), "title": title[:70],
                         "key": 5 if bytes_match else matched, "bytes_match": bytes_match})
    return {"state": "PRESENT" if hits else "ABSENT", "hits": hits, "enumerated": len(rows)}

def cmd_surfaces(a):
    """Run the §2.1a surface scan and write the result into the lock."""
    L = load(a.lock)
    t_target = L.get("title", {}).get("target") or ""
    t_orig = L.get("title", {}).get("original") or ""
    keys = []
    s_target = L.get("subtitle", {}).get("target") or ""
    s_orig = L.get("subtitle", {}).get("original") or ""
    if t_target:
        keys.append((2, _norm_title(t_target)))
    # Key 2c: the concatenated form. A paper carrying a subtitle is deposited on a
    # citation surface as "Title: Subtitle", and neither the bare title nor the bare
    # original matches that string. Found on the second live run, where the correct
    # record matched only on the weak normalised key and forced a false AMBIGUOUS.
    for tt, ss in ((t_target, s_target), (t_orig, s_orig)):
        if tt and ss:
            keys.append((2, _norm_title(tt + ": " + ss)))
    if t_orig and _norm_title(t_orig) != _norm_title(t_target):
        keys.append((3, _norm_title(t_orig)))
    # Key 4 is emitted even where its target string duplicates key 2's, because its
    # job is to change how the CANDIDATE is normalised and not to add a new target.
    # Deduplicating on the target alone silently disables it, which is how the live
    # test missed a ' - Journal' sibling sitting beside its own bare file.
    seen4 = set()
    for t in (t_target, t_orig):
        if t:
            n = _norm_title_loose(t)
            if n and n not in seen4:
                seen4.add(n); keys.append((4, n))
    md5 = None
    if a.pdf and os.path.exists(a.pdf):
        h = hashlib.md5()
        with open(a.pdf, "rb") as f:
            for b in iter(lambda: f.read(1 << 20), b""):
                h.update(b)
        md5 = h.hexdigest()
    ident = a.ia_identifier or ("trisduction-" + re.sub(r"[^a-z0-9]+", "-",
                                _norm_title(t_target)).strip("-"))
    print("SURFACE SCAN  ·  §2.1a")
    print("  keys      " + ", ".join("k%d=%r" % (k, t[:44]) for k, t in keys))
    print("  pdf md5   %s" % (md5 or "not supplied"))
    g = scan_git(keys); i = scan_ia(ident); z = scan_zenodo(keys, md5)
    print("\n  git       %-11s %s" % (g["state"],
          "; ".join("%s (k%d)" % (os.path.basename(h["path"]), h["key"]) for h in g["hits"])
          or g.get("why", "")))
    print("  archive   %-11s %s" % (i["state"], i.get("identifier", "")))
    print("  zenodo    %-11s %s" % (z["state"],
          "; ".join("%s k%d %s" % (h["doi"], h["key"], h["title"][:40]) for h in z["hits"])
          or z.get("why", "")))
    states = [g["state"], i["state"], z["state"]]
    present = [s for s in states if s == "PRESENT"]
    amb = []
    if len(z.get("hits", [])) > 1:
        amb.append("more than one zenodo candidate")
    if len([h for h in g.get("hits", []) if h["path"].lower().endswith(".pdf")]) > 1:
        amb.append("more than one git PDF candidate")
    k4_only = [h for h in g.get("hits", []) + z.get("hits", [])
               if h.get("key") == 4 and not h.get("bytes_match")]
    if k4_only:
        amb.append("hit found only on the normalised key, which is a signal and not a proof")
    if i["state"] == "DARK":
        amb.append("archive identifier is DARK, spent and unclaimable")
    if amb:
        disp = "AMBIGUOUS"
    elif "UNREADABLE" in states and not present:
        disp = "UNREADABLE"
    elif not present:
        disp = "ABSENT"
    elif len(present) == 3 or "UNREADABLE" not in states and len(present) == len([s for s in states if s != "ABSENT"]):
        disp = "RESIDENT" if len(present) == 3 else "PARTIAL"
    else:
        disp = "PARTIAL"
    L["surfaces"] = {"scanned": now(), "disposition": disp, "keys": keys,
                     "pdf_md5": md5, "git": g, "archive": i, "zenodo": z,
                     "ambiguity": amb}
    save(a.lock, L)
    print("\n  DISPOSITION  %s" % disp)
    for x in amb:
        print("    ambiguity: %s" % x)
    if disp == "AMBIGUOUS":
        print("  HALT. No deletion runs on a guess. Ask the architect before replacing.")
        return 2
    if disp == "UNREADABLE":
        print("  A surface could not be enumerated. It is neither replaced nor claimed.")
    print("  written to %s under 'surfaces'" % a.lock)
    return 0

def cmd_digest(a):
    d=load(a.lock)
    print("SPINE LOCK DIGEST")
    print(f"  artifact ... {d['artifact']}  (sha {d['artifact_sha256']})")
    print(f"  register ... Tier {d['lingo_tier']} carried | edition {d.get('original_edition')} -> {d.get('target_edition','journal')}")
    for field in ("title","subtitle"):
        lk=d.get(field) or {}
        if not lk.get("original") and field=="subtitle": continue
        print(f"  {field:9s}. [{lk.get('status','?')}] {lk.get('target','')}")
        if lk.get("retitled"):
            rt=lk["retitled"]
            print(f"             was: {rt['from']}")
            print(f"             via: {rt['mechanism']} on {rt['cut_claim']} · {rt['evidence'][:60]}")
    print(f"  thesis ..... {d['thesis'][:150]}")
    print(f"\n  CLAIMS ({len(d['claims'])})")
    for cid,c in sorted(d["claims"].items()):
        print(f"    {cid:5s} [{c['status']:9s}] tier={c.get('tier') or '-':2s}  {c['text'][:90]}")
        if c.get("conceded"): print(f"           concession: {c['conceded']['mechanism']} · {c['conceded']['evidence'][:70]}")
    print(f"\n  CONCESSIONS {len(d['concessions'])}   FORTIFICATIONS {len(d['fortifications'])}")
    print("\n  PHASE 2 PRE-REGISTRATION (pass these to audit_ledger.py init --claims)")
    live=[c for c,v in sorted(d["claims"].items()) if v["status"]!="CUT"]
    print(f"    --claims \"{','.join(live)}\"")

def main():
    p=argparse.ArgumentParser(prog="spine_lock.py"); s=p.add_subparsers(dest="cmd",required=True)
    d=s.add_parser("detect"); d.add_argument("--file",required=True); d.set_defaults(f=cmd_detect)
    i=s.add_parser("init"); i.add_argument("--lock",required=True); i.add_argument("--file",required=True)
    i.add_argument("--thesis",required=True); i.add_argument("--title",required=True); i.add_argument("--subtitle")
    i.add_argument("--claims"); i.add_argument("--tier"); i.add_argument("--edition")
    i.set_defaults(f=cmd_init)
    c=s.add_parser("claim"); c.add_argument("--lock",required=True); c.add_argument("--id",required=True)
    c.add_argument("--text",required=True); c.add_argument("--tier"); c.set_defaults(f=cmd_claim)
    x=s.add_parser("concede"); x.add_argument("--lock",required=True); x.add_argument("--id",required=True)
    x.add_argument("--mechanism",required=True); x.add_argument("--evidence",required=True)
    x.add_argument("--from-tier",dest="from_tier"); x.add_argument("--to-tier",dest="to_tier")
    x.add_argument("--scope",default="CLAIM",help="CLAIM | PHRASE | HEADER; only CLAIM licenses a retitle")
    x.set_defaults(f=cmd_concede)
    fz=s.add_parser("falsifier"); fz.add_argument("--lock",required=True)
    fz.add_argument("--kind",required=True,help="FORCED | IMPORT | LOOPED")
    fz.add_argument("--event",required=True,help="the observable that fires it")
    fz.add_argument("--conditions",required=True,help="the conditions under which it binds")
    fz.add_argument("--compromises",required=True,help="exactly what falls, and nothing above it")
    fz.add_argument("--imports",default="",help="semicolon-separated orthodoxy imports it rests on")
    fz.add_argument("--tripwire",action="store_true",help="carry below the register, not as a criterion")
    fz.add_argument("--claim",default=""); fz.add_argument("--fid",default="")
    fz.set_defaults(f=cmd_falsifier)
    y=s.add_parser("fortify"); y.add_argument("--lock",required=True); y.add_argument("--id",required=True)
    y.add_argument("--kind",default="promotion"); y.add_argument("--evidence",required=True)
    y.add_argument("--to-tier",dest="to_tier"); y.set_defaults(f=cmd_fortify)
    rt=s.add_parser("retitle"); rt.add_argument("--lock",required=True); rt.add_argument("--to",required=True)
    rt.add_argument("--cut-claim",dest="cut_claim",required=True); rt.add_argument("--mechanism",required=True)
    rt.add_argument("--evidence",required=True); rt.add_argument("--subtitle",action="store_true")
    rt.set_defaults(f=cmd_retitle)
    v=s.add_parser("verify"); v.add_argument("--lock",required=True); v.add_argument("--file",required=True); v.set_defaults(f=cmd_verify)
    sc=s.add_parser("surfaces"); sc.add_argument("--lock",required=True)
    sc.add_argument("--pdf",help="the rendered PDF, for the md5 key")
    sc.add_argument("--ia-identifier",dest="ia_identifier",help="override the derived archive address")
    sc.set_defaults(f=cmd_surfaces)
    g=s.add_parser("digest"); g.add_argument("--lock",required=True); g.set_defaults(f=cmd_digest)
    a=p.parse_args(); rc=a.f(a)
    sys.exit(rc if isinstance(rc,int) else 0)

if __name__=="__main__": main()
