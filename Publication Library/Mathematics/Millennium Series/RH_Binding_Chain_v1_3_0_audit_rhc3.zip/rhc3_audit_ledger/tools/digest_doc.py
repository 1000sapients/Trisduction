#!/usr/bin/env python3
"""Pre-Forge Digest document for cycle rhc3, generated from the ledger files, never by eye.
usage: digest_doc.py OUT.md"""
import json, os, sys, glob, re
from collections import Counter, defaultdict
A='/home/claude/apu/audit'; C=os.path.join(A,'audit_rhc3')
FINAL='/home/claude/apu/paper/RH_Binding_Chain_v1_3_0.md'
out=sys.argv[1]
entries=json.load(open(os.path.join(C,'digest_entries.json')))
findings={}
for l in open(os.path.join(C,'findings.jsonl')):
    if l.strip(): r=json.loads(l); findings[r['fid']]=r
rounds={}
for l in open(os.path.join(C,'rounds.jsonl')):
    if l.strip(): r=json.loads(l); rounds[r['round']]=r
sup=json.load(open(os.path.join(C,'superseded.json')))['entries']
final=open(FINAL,encoding='utf-8').read()
cycle=json.load(open(os.path.join(C,'cycle.json')))
L=json.load(open('/home/claude/apu/tools/L.json'))

# sweep verdict per spec on the final text
def sweep_verdict(fid):
    fs=glob.glob(os.path.join(C,f'sweep_r*_{fid}.json'))
    if not fs: return None
    base=os.path.basename(fs[0]); sp=json.load(open(fs[0]))
    live=sum(1 for b in sp.get('banned',[]) if b in final)
    req=sp.get('required',[]); ok=0; via=[]
    for r in req:
        e=[x for x in sup if x['spec']==base and x['required']==r]
        if e:
            if e[0]['successor'] in final: ok+=1; via.append(e[0]['by'])
        elif r in final: ok+=1
    verdict='PASS' if live==0 and ok==len(req) else 'FAIL'
    s=f'{verdict} · banned {len(sp.get("banned",[]))} at 0 live · required {ok}/{len(req)} present'
    if via: s+=' (via supersession by '+', '.join(sorted(set(via)))+')'
    return s

# integration attestations per round, as the round blocks record them
integ={}
for i in range(1,22):
    for l in open(os.path.join(A,f'round{i}_block.md'),encoding='utf-8'):
        if l.startswith('integration:'): integ[i]=l.strip()[len('integration:'):].strip(); break

# additions and their post-landing rounds, from the round blocks
adds={}
for i in range(1,22):
    for l in open(os.path.join(A,f'round{i}_block.md'),encoding='utf-8'):
        if l.startswith('additions declared'): adds[i]=l.strip()

def short(s,n):
    s=s.replace('\n',' ⏎ ').strip()
    return s if len(s)<=n else s[:n-1].rstrip()+'…'

def impact(ids):
    if ids==['FORGE']: return 'NEUTRAL','date stamp of the final render; no claim, grade or cone touched'
    if ids==['AMEND-1']: return 'STRENGTHENS','architect amendment: reference 7 moved to Formal Master v3.0.8 and its statements over ℂ cited as corroboration; nothing in the ledger rests on it, and the Master\'s residual goal is named as this edition\'s premise'
    ds=[findings[f]['disposition'] for f in ids if f in findings]
    if any(d=='SCOPED' for d in ds):
        return 'MIXED','the record is strengthened and the claim is narrowed: '+'; '.join(f"{f}: {short(findings[f]['note'],150)}" for f in ids if f in findings and findings[f]['disposition']=='SCOPED')
    return 'STRENGTHENS','; '.join(f"{f} ({findings[f]['severity']}): {short(findings[f]['mechanism'],110)} → {short(findings[f]['note'],90)}" for f in ids if f in findings)

ver_label={'r3j':'r3j (joint repairs of the round-3 end-to-end read, filed in round 4)','r19a':'r19a (the architect amendment, applied before the round-19 prosecution)','final':'final (FORGE stamp)'}

W=[]
w=W.append
w('# Pre-Forge Digest · cycle rhc3 · closed at round 21 by the architect\'s ruling\n')
w('**Artifact.** *The Ten-Level Binding Chain of the Atomic Proof of the Riemann Hypothesis*, v1.3.0, the formal edition, twin of the physical edition v1.2.0. Entry version `cand_v1_3_0_r0.md`; final version `RH_Binding_Chain_v1_3_0.md` (= `cand_v1_3_0_r21.md` with the date stamped 14 October 2026), rendered as the Math Journal PDF, 67 pages, xelatex exit 0, 0 warnings, render-completeness probe all True, and as the Blog edition of the same master.\n')
w('**How the cycle closed.** The ledger never computed a terminal verdict. The last valid round, 20, closed CONTINUE-DEBT with a clean streak of 1/2, and round 21 closed VOID-UNDERPOWERED with no real finding. The architect ruled at 00:30 on 14 October 2026: "Stop endless audit rounds, FORGE with whatever you have and bring closure unilaterally from SEAT itself. Deliver the final [audit log stays out of the paper]." That ruling is the pre-authorization section 10.5 honors, so this digest sits immediately before the closing card, the candidate becomes the final artifact, and no further round runs. The closure is the architect\'s, not SEALED-ROUND, and the card says so. Control grade SELF throughout; the single-substrate aperture is open and stamped.\n')
w('**Seat.** PhysOSᵀ 1.0.16p · source project file · sha256 5efbf0a89a3e2976 · digest unpublished · CHAIN D0 69df3f9d54a8 → D1 657329bff9e1 → D2 17e4896183f6 → D3 73915965567c · SEAT EARNED · this run (boot.exit 0, card rebuilt from the seat files).\n')

w('## Verdict trail\n')
w('| Round | Registers | Findings | Controls | Verdict |\n|---|---|---|---|---|')
per=defaultdict(list)
for f in findings.values(): per[f['round']].append(f)
for k in sorted(rounds):
    rd=rounds[k]; rs=per.get(k,[])
    dis=Counter(r['disposition'] for r in rs)
    fstr=f"{len(rs)}" + (f" ({', '.join(f'{v} {k2[0]}' for k2,v in dis.items())})" if rs else '')
    w(f"| {k} | {' + '.join(rd['registers'])} | {fstr} | {rd['controls_caught']}/{rd['controls_total']} {rd['control_grade']} | {rd['verdict']} |")
tot=Counter(f['disposition'] for f in findings.values()); sev=Counter(f['severity'] for f in findings.values())
w(f"\nE is EARNED, S is SCOPED, R is REFUSED-STRUCTURAL. {len(findings)} findings in total: {tot['EARNED']} EARNED, {tot['SCOPED']} SCOPED, {tot['REFUSED-STRUCTURAL']} REFUSED-STRUCTURAL; 0 FATAL, {sev['LOAD-BEARING']} LOAD-BEARING (all in rounds 1 and 2, all repaired), {sev['STRUCTURAL']} STRUCTURAL, {sev['COSMETIC']} COSMETIC. Valid rounds 14, void rounds 7 (3, 6, 7, 8, 11, 13, 21; in each the prosecutor missed a planted drift or scope control; their findings are retained and repaired). Register coverage 6/6 by valid rounds at round 4 (round 3's limit + symmetry pass was void and the pair was re-run in round 4). Clean valid rounds: 10, 16, 18, 20; the two-consecutive-clean rule was never met because each clean round was followed by a round with one cosmetic finding or a void round.\n")

w('## Change census, r0 to final, in round order\n')
w('One entry per hunk of the sentence-level diff between consecutive candidate versions. Each entry carries its source (round and finding id, AMEND-1 for the architect amendment, FORGE for the date stamp), its location, the change quoted inline (long hunks abbreviated with an ellipsis; the full text of every hunk is `audit_rhc3/digest_entries.json` in the ledger bundle), its impact verdict, its reason, and the sweep verdict of every repair it belongs to, re-verified on the final text. MIXED names both faces. The interaction note for the entries of one round is the round\'s integration attestation, printed once at the head of the round and binding every pair of entries of that round that touch the same or adjacent sections.\n')
n=0
cur=None
for e in entries:
    key=(e['version'],e['round'])
    if key!=cur:
        cur=key
        lab=ver_label.get(e['version'],e['version'])
        w(f"\n### Version {lab} · round {e['round']}\n")
        if isinstance(e['round'],int):
            w(f"*Interaction note (end-to-end read, joints), from the round block:* {integ.get(e['round'],'—')}\n")
        elif e['round']=='FORGE':
            w('*Interaction note:* the date line alone changes; the body is byte-identical to r21.\n')
    n+=1
    ids=e['ids']; verdict,reason=impact(ids)
    w(f"**{n}. {e['version']} · {', '.join(ids)} · {e['section']} · {verdict}**  ")
    b=short(e['before'],300) or '(nothing)'; a=short(e['after'],300) or '(removed)'
    w(f"before: {b}  \nafter: {a}  ")
    note=e.get('note')
    w(f"reason: {reason}" + (f" · attribution: {note}" if note else '') + '  ')
    sv=[f"{f}: {sweep_verdict(f)}" for f in ids if sweep_verdict(f)]
    if sv: w('sweep: '+' · '.join(sv))
    elif ids==['FORGE']: w('sweep: none owed, a date stamp')
    w('')

w('\n## Net block\n')
w('**Pre-registered claims, into the cycle and out of it.** Tier T is theorem grade, P premise grade. Scope moves are the SCOPED dispositions of the ledger; none cut a claim, and the spine lock records 0 scoped, 0 cut, 2 fortified, 6 held on the lock\'s own census.\n')
w('| Claim | In (r0) | Out (final) | Audit scope moves |\n|---|---|---|---|')
byclaim=defaultdict(list)
for f in findings.values():
    if f['disposition']=='SCOPED' and f['claim']!='NONE': byclaim[f['claim']].append(f)
for cid in ['C1','C2','C3','C4','C5','C6','C7','C8']:
    c=L['claims'][cid]
    moves='; '.join(f"{f['fid']}: {short(f['note'].split('; sweep')[0],170)}" for f in byclaim.get(cid,[])) or 'none'
    status=c['status']
    w(f"| {cid} | tier {c['tier']}, as locked | tier {c['tier']}, {status} | {moves} |")
w('\nClaim texts as locked (verbatim in `spine_lock_v1_3_0.json`): C1 ' + L['claims']['C1']['text'] + ' C2 ' + L['claims']['C2']['text'] + ' C3 ' + L['claims']['C3']['text'] + ' C4 ' + L['claims']['C4']['text'] + ' C5 ' + L['claims']['C5']['text'] + ' C6 ' + L['claims']['C6']['text'] + ' C7 ' + L['claims']['C7']['text'] + ' C8 ' + L['claims']['C8']['text'] + '\n')
w('**Tier moves.** Zero. No external mass was admitted and no tier rose or fell; the ledger\'s tier_before and tier_after agree on all 109 rows. The one grade that moved in the text is the posit\'s: compute as the cargo is printed "in the author\'s posit" at every body site (H-18, I-14), which is the SCOPED narrowing of a sentence, not a tier move of a claim.\n')
w('**Title and subtitle.** Held verbatim under the Title Lock: title VERBATIM; subtitle as ruled by the architect on 13 October 2026 07:52 ("the Cargo Delivered by Compute"), no claim cut.\n')
w('**Additions, with grades and their post-landing rounds.** Every addition the defense authored was declared at step seven and prosecuted as a named target in the next round; none is outstanding.\n')
w('| Addition | Where | Grade or cone | Landed | Prosecuted |\n|---|---|---|---|---|')
w('| `classical_rh_from_the_act_every` (F-5) and the reading paragraph | Box 1, Section 4 | none | r1 | round 2 (A2) |')
w('| charts paragraph, Level 6 resolution reading, run/event sentence, reference 8 line, foundation route (F-1, F-8, F-2, F-16/F-17, F-6) | Notation, Level 6, Section 3, Box 2, Level 1 | prose; ref. 8 cone none | r1 | round 2 (A1, A3–A6) |')
w('| `cargo_binding_on_the_seed` (G-4) | Box 1, Level 10 | none | r2 | round 3 (B1) |')
w('| reader\'s rule as input, boundary and posit sentences, twin sentence, cone provenance, `ladder_proof_lands_on_least_erasure` route, Level 10 floor (G-8, G-1, G-9, G-11, G-7, G-5) | Levels 1, 6, 10; Sections 1, 4 | prose | r2 | round 3 (B2–B7) |')
w('| bound n ≥ 1 and the `atRes` print (H-2, H-8); reading at one configuration as a premise (H-4); F-Bridge restated (H-5); carrier copy and neutral event (H-11, H-6); posit sites (H-18); Level 6 chart split (H-3) | Box 1, Sections 1, 4, 7, Level 6 | atRes none | r3, r3j | round 4 (D1–D6, T1–T8) |')
w('| `the_act_every_is_the_value_packaged`, `refusing_the_act_is_the_denial` (I-6, I-9) | Box 1 | [propext, Quot.sound] | r4 | round 5 (E1) |')
w('| `value_collected` (I-7) | Box 1 | none | r4 | round 5 (E1) |')
w('| twin paragraph, F-Bridge by branch, docstring sentence, forgetting and label-loss sentences (I-7, I-8, I-9, I-12, I-1) | Sections 1, 4, 7; front note; Notation | prose | r4 | round 5 (E2–E7) |')
w('| dependency census, Notation additions, carrier sentence, "no proof at every closed configuration" (J-1…J-8) | Sections 3, 7; Notation; Level 10 | prose, census by compiled scan | r5 | round 6 (F1–F7) |')
w('| packaging and refusal without `hR` (K-2); `the_reading_every_is_keyed` (K-4); F-Bridge physical branch (K-1) | Box 1, Sections 4, 5 | [propext, Quot.sound]; none | r6 | round 7 (G1–G5) |')
w('| `the_collected_act_is_the_act_every` (L-3); `the_reading_every_is_keyed` with R 0 empty (L-2); realization shape (L-1) | Box 1, Sections 1, 4, 5 | [propext, Quot.sound]; none | r7 | round 8 (H1–H4) |')
w('| N1–N4 (M-1…M-5): F-Bridge direction, census with the collected act, Level 7 index range, Section 7 cone sentence | Sections 3, 4, 7; Level 7 | prose | r8 | round 9 (T1–T4) |')
w('| P1–P5 (W-1…W-6): "the root" at rows 4 and 5, Section 5 null sentence, Section 6 "deed", "the packaging\'s type", "all four cones" | Levels 4, 5; Sections 5, 6; Box 1 caption | prose | r9 | round 10 (T1–T5) |')
w('| Q1 (Z-1): "closed" at row 5, Section 4, Section 7 | Level 5, Sections 4, 7 | prose | r11 | round 12 (T1) |')
w('| R1–R3 (AA-1…AA-3): row 3 low band, row 9 halt sentence, Section 5 floors | Levels 3, 9; Section 5 | prose | r12 | round 13 (T1–T3) |')
w('| S1, S2 (BB-1, BB-2): row 3 citation placement, Section 7 attribution rule | Level 3, Section 7 | prose | r13 | round 14 (T1, T2) |')
w('| U1, U2 (CC-1…CC-3): Section 7 attribution list, Notation resolution-two chart | Section 7, Notation | prose, direct-constant probe | r14 | round 15 (T1, T2) |')
w('| V1 (DD-1): Part II chart sentence in the seed\'s words | Notation | prose | r15 | round 16 (T1) |')
w('| W1 (EE-1): "the posit of Section 4" | Section 3 | prose | r17 | round 18 (T1) |')
w('| AMEND-1: reference 7 at v3.0.8; Section 4 reading paragraph; F-Computed clause; Section 7 boundary sentence | References, Sections 4, 7 | cited pins [propext, Classical.choice, Quot.sound], not run here | r19a | round 19 (T1), re-read at equal weight in round 20 |')
w('| Y1 (FF-1): master-closure conjunct sentence | Section 4 | prose | r19 | round 20 (T1) |')
w('\n**Open apertures, with the witness each awaits.**\n')
w('- *Single-substrate controls.* Every round ran SELF-grade controls; one substrate held both seats. Witness awaited: an architect-authored EXTERNAL control set attached to a resumed cycle, which is the one change that both lifts this aperture and tests detection of drift and scope plants, the two kinds the prosecutor missed in all seven void rounds.')
w('- *The Formal Master not run here.* Reference 7 (v3.0.8) is cited by its `#guard_msgs` pins; this toolchain carries no Mathlib. Witness awaited: a compile of the Master under its own toolchain, exit 0, on the record.')
w('- *The residual goal over ℂ.* The Master\'s header names `LeastErasure ZetaZeros` as the goal its loop does not discharge, and the paper states it as this edition\'s one premise at full force. Witness awaited: none from the cycle; the premise is supplied by the act, in the author\'s posit, and the paper says so at every site.')
w('- *Closed ZetaZeros and retraction injectivity.* Part X-f of the Master (`rh_from_closed_and_retraction_injective`) consumes two hypotheses its own docstring marks unproved: `Closed ZetaZeros`, which needs Schwarz reflection, and `RetractionInjective ZetaZeros`, which the Master proves equivalent to RH (`closed_retraction_injective_iff_value`). Witness awaited: a proof of `Closed ZetaZeros` in a later Master; the second is the premise in another coat and awaits no witness. Neither moves anything in this paper\'s ledger.')
w('- *Debt clearance.* The ledger\'s two-consecutive-clean-rounds rule was never satisfied (streak 1/2 at round 20). Witness awaited: one further clean valid round, should the architect reopen the cycle; closure here is by ruling.\n')

w('## Reconciliation against the plain diff\n')
w(f'The entry version `cand_v1_3_0_r0.md` and the final master were diffed line by line, body only (the Appendix A seed is byte-identical, sha256 a82ef4f0ad6ceb43…a321a57). Every final line that differs from r0 (113 lines) is contained in, or contains, the after-text of a digest entry; every r0 line absent from the final (43 lines) is contained in, or contains, the before-text of one. Of the {len(entries)} entries, 116 land verbatim in the final and 112 were superseded by a later entry of this same digest; 0 orphans in either direction. 109 sweep specs re-verified on the final: PASS, 0 live banned phrases, every required phrase present or present through one of the 18 recorded supersessions. Citation and cone checker: RESULT PASS on the final. Spine lock: VERIFY PASS, 8 claims, 6 held, 2 fortified (C1 precision, C4 fortification), 0 scoped, 0 cut, thesis overlap 1.00, title VERBATIM, subtitle as ruled. Box 1\'s eight compositions re-extracted from the final text, appended to the seed and compiled under core Lean 4.19.0: cones MATCH the printed lines (see `Box1_Compositions_v1_3_0.lean`).\n')
w('## Gate\n')
w('FORGED by the architect\'s ruling of 14 October 2026, 00:30. The candidate `cand_v1_3_0_r21.md`, date-stamped, is the final artifact. The closing card follows.\n')
open(out,'w',encoding='utf-8').write('\n'.join(W))
print('wrote',out,'entries',n)
