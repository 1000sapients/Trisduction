#!/usr/bin/env python3
"""Fact-check the paper's Lean citations against the compiler's cone table.

usage: check_paper.py paper.md cones.json seed.lean
Every backticked identifier is resolved against the seed's declarations.
Every identifier immediately followed by a cone (none / [..]) is checked
against #print axioms output. Prints mismatches and unresolved names.
"""
import json, re, sys

paper, conesf, seedf = sys.argv[1:4]
md = open(paper, encoding='utf-8').read()
body = md.split('## Appendix A')[0]
fenced = re.findall(r'```.*?```', body, flags=re.S)
body = re.sub(r'```.*?```', ' ', body, flags=re.S)
cones = json.load(open(conesf, encoding='utf-8'))
extra = sys.argv[4] if len(sys.argv) > 4 else None
if extra:
    for l in open(extra, encoding='utf-8'):
        m = re.match(r"'(.+?)' (does not depend on any axioms|depends on axioms: \[(.*)\])", l.strip())
        if m: cones.setdefault(m.group(1), 'none' if m.group(2).startswith('does') else '[' + m.group(3) + ']')
seed = open(seedf, encoding='utf-8').read()

short = {}
for q, c in cones.items():
    parts = q.split('.')
    for k in range(1, len(parts)):
        short.setdefault('.'.join(parts[-k:]), []).append((q, c))
declared = set(re.findall(r'^\s*(?:noncomputable |private |protected )*(?:theorem|def|structure|inductive|abbrev)\s+([^\s:({\[]+)', seed, re.M))

# names that live outside the seed and are cited as such
EXTERNAL = {'h0', 'hR', 'before', 'le_refl', 'BoundChainMathlib.cargo_at_zeros', 'BoundChainMathlib.h_id_proved', 'BoundChainMathlib.zeta_ra_loop', 'BoundChainMathlib.offline_zero_iff_not_rh', 'LeastErasure (Rec ZetaZeros)', 'RiemannHypothesis ↔ LeastErasure ZetaZeros', 'LeastErasure ZetaZeros', 'guard_msgs', '#guard_msgs', 'succ_le_succ', 'zero_le', 'h_read_proved', 'transport_zeta', 'record_has_least_erasure', 'the_flipped_formal_master_closure',
            'RiemannHypothesis ↔ Value ZetaZeros', 'Rec M', 'M', 'Stage1 → ClassicalRH', 'h_read', 'h_realize',
            'h_pop', 'h_rate', 'h_temp', 'h_couple', 'h_gap', '#print axioms', 'axiom', 'lean', 'Closed',
            'Value S', 'LeastErasure S', 'ActualZeros', 'Stage1', 'cargo_binding_necessary_and_sufficient', 'x86_64', 'guard_msgs', '#guard_msgs', 'native_decide', 'Classical.em', 'supply', 'Classical.byContradiction', 'BoundChainMathlib.h_read_proved', 'BoundChainMathlib.transport_zeta', 'BoundChainMathlib.record_has_least_erasure', 'FormalMasterClosure.the_flipped_formal_master_closure', 'h_forget'}

CONE = r'(none|\[[A-Za-z., ]+\])'
faults = []
# 1. name + explicit cone, possibly with a parenthetical Part hint or ", parts .." between
for m in re.finditer(r'`([^`]+)`((?:\s*\((?:Part [^)]*|ii)\))?(?:,\s*parts? [^\[·]*?)?)\s+' + CONE, body):
    name, hint, cone = m.group(1), m.group(2), m.group(3)
    cands = short.get(name, [])
    if not cands:
        faults.append(f'UNRESOLVED (cone given): {name}')
        continue
    if not any(c == cone for _, c in cands):
        faults.append(f'CONE MISMATCH: {name} paper={cone} compiler={[c for _, c in cands]}')
    elif len(set(c for _, c in cands)) > 1:
        print(f'  note: {name} {hint.strip()} has variants {[(q, c) for q, c in cands]}; paper {cone} matches one')

# 2. parenthetical lists ending in ", none)" : every member must have cone none
for m in re.finditer(r'\(((?:`[^`]+`,\s*)+`[^`]+`),\s*none\)', body):
    for name in re.findall(r'`([^`]+)`', m.group(1)):
        cands = short.get(name, [])
        if not cands:
            faults.append(f'UNRESOLVED (list none): {name}')
        elif not any(c == 'none' for _, c in cands):
            faults.append(f'CONE MISMATCH (list none): {name} compiler={[c for _, c in cands]}')

# 3. every backticked identifier resolves to the seed or the external set
for name in sorted(set(re.findall(r'`([^`]+)`', body))):
    if name in EXTERNAL or name in declared or name in short:
        continue
    faults.append(f'NOT IN SEED: {name}')

for blk in fenced:
    for tok in re.findall(r'\b[a-z][A-Za-z0-9_]*_[A-Za-z0-9_]+\b', blk):
        if tok not in declared and tok not in short and tok not in EXTERNAL and not tok.startswith(('h_','RH_')):
            faults.append(f'NOT IN SEED (fenced): {tok}')
print('checked', len(set(re.findall(r'`([^`]+)`', body))), 'distinct backticked names')
for f in faults:
    print('  FAULT', f)
print('RESULT', 'PASS' if not faults else f'{len(faults)} FAULTS')
sys.exit(1 if faults else 0)
