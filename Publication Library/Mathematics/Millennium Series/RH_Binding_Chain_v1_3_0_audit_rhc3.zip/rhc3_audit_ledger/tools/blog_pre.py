#!/usr/bin/env python3
"""Blog pre-transform for the binding-chain master: front matter -> headed prose,
{=latex} Verbatim boxes -> fenced text, the seed include -> a pointer, escaped pipes protected.
usage: blog_pre.py master.md out.md"""
import re, sys, yaml
src, out = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf-8').read()
m = re.match(r'^---\n(.*?)\n---\n', s, re.S)
fm = yaml.safe_load(m.group(1)); body = s[m.end():]
head = [f"# {fm['title']}", "", f"## {fm['subtitle']}", "", f"**{fm['author_line']}** · {fm['affiliation']}", "",
        f"*{fm['date']}*", "", "*Blog edition, rendered from the sealed Markdown master of v1.3.0, the formal edition, 14 October 2026; the same text as the Math Journal PDF, its tables set as lists and its boxes as code.*", "",
        "**Abstract.** " + ' '.join(fm['abstract'].split()), ""]
# latex boxes: pull the Verbatim body and the box title
def box(mm):
    blk = mm.group(1)
    title = re.search(r'\\color\{deep\}(.*?)\}\\par', blk)
    verb = re.search(r'\\begin\{Verbatim\}\[[^\]]*\]\n(.*?)\\end\{Verbatim\}', blk, re.S)
    cap = re.search(r'\{\\footnotesize\\itshape\\color\{faint\} (.*?)\}\\par', blk, re.S)
    o = ''
    if title: o += '**' + title.group(1).replace('\\textbar\\', '·').replace('\\', '') + '**\n\n'
    if verb: o += '```\n' + verb.group(1).rstrip('\n') + '\n```\n'
    if cap: o += '\n*' + cap.group(1).strip() + '*\n'
    return o
body = re.sub(r'```\{=latex\}\n(.*?)```', box, body, flags=re.S)
body = re.sub(r'```lean\n@@INCLUDE ([^@]+)@@\n```',
              lambda mm: f"*The seed, {mm.group(1)}, is delivered as a file beside this post and printed whole in the PDF edition; its sha256 is the one in the heading.*", body)
body = body.replace('\\|', '\x01')
body = body.replace('\\*', '*')
open(out, 'w', encoding='utf-8').write('\n'.join(head) + body)
print('pre-transform written')
