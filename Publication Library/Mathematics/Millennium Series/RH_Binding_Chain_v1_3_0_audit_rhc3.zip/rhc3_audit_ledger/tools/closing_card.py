#!/usr/bin/env python3
"""Closing card for cycle rhc3, built from the ledger files.
usage: closing_card.py OUT.md"""
import json, os, sys, glob, hashlib, subprocess
from collections import Counter, defaultdict
A='/home/claude/apu/audit'; C=os.path.join(A,'audit_rhc3'); D='/home/claude/apu/deliver'
FINAL='/home/claude/apu/paper/RH_Binding_Chain_v1_3_0.md'
out=sys.argv[1]
findings=[json.loads(l) for l in open(os.path.join(C,'findings.jsonl')) if l.strip()]
rounds={json.loads(l)['round']:json.loads(l) for l in open(os.path.join(C,'rounds.jsonl')) if l.strip()}
sup=json.load(open(os.path.join(C,'superseded.json')))['entries']
cycle=json.load(open(os.path.join(C,'cycle.json')))
L=json.load(open('/home/claude/apu/tools/L.json'))
final=open(FINAL,encoding='utf-8').read()
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
W=[]; w=W.append
w('# Closing card · cycle rhc3 · The Ten-Level Binding Chain, v1.3.0, the formal edition\n')
w('**Closure.** By the architect\'s ruling of 14 October 2026, 00:30, at round 21, not by a computed terminal verdict. The ledger\'s last valid verdict is round 20, CONTINUE-DEBT (clean streak 1/2); round 21 is VOID-UNDERPOWERED with no real finding. The seat executed the ruling from the ledger files and nothing else.\n')
w('**Seat.** PhysOSᵀ 1.0.16p · source project file · sha256 5efbf0a89a3e2976 · digest unpublished · CHAIN D0 69df3f9d54a8 → D1 657329bff9e1 → D2 17e4896183f6 → D3 73915965567c · SEAT EARNED · this run.\n')
w('## Final artifact\n')
w('| File | sha256 | Note |\n|---|---|---|')
for f,note in [('RH_Binding_Chain_v1_3_0_Formal_MathJournal.pdf','Math Journal edition, 67 pages, xelatex exit 0, 0 warnings, completeness probe all True'),
               ('RH_Binding_Chain_v1_3_0_Formal.md','Markdown master, Appendix A seed inlined (= cand_v1_3_0_r21.md, dated 14 October 2026)'),
               ('RH_Binding_Chain_v1_3_0_Formal.blog.md','Blog edition of the same master, Module VII, same title, byline, date and abstract'),
               ('Box1_Compositions_v1_3_0.lean','the eight compositions of Box 1, extracted from the final text, compiled against seed 2.0.5: exit 0, cones MATCH'),
               ('spine_lock_v1_3_0.json','spine lock: VERIFY PASS, 8 claims, 6 held, 2 fortified, 0 scoped, 0 cut'),
               ('PreForge_Digest_rhc3.md','228 entries, reconciled, 0 orphans'),
               ('rhc3_audit_ledger.zip','ledger: findings, rounds, controls, 109 sweep specs, supersessions, round blocks 1 to 21, candidates r0 to r21, tools')]:
    p=os.path.join(D,f)
    w(f"| `{f}` | {sha(p)[:16] if os.path.exists(p) else 'pending'} | {note} |")
w('\nSeed of Appendix A: `RH_Both_Sides_Seed_v2.0.5.lean`, sha256 a82ef4f0ad6ceb43a2d3cc964b110943dbb02f050ab88ff2845df1226a321a57, byte-identical through the cycle. Title and subtitle held under the Title Lock. No Audit paragraph in the paper, by the architect\'s ruling; the paper names the cycle in its date line only.\n')
w('## Pre-registered claims, falsifiers, surviving scope and tier\n')
w('| Claim | Falsifier (write-once at cycle open) | Tier in → out | Status | Scope moves (SCOPED dispositions) |\n|---|---|---|---|---|')
byclaim=defaultdict(list)
for f in findings:
    if f['disposition']=='SCOPED' and f['claim']!='NONE': byclaim[f['claim']].append(f['fid'])
for cid in ['C1','C2','C3','C4','C5','C6','C7','C8']:
    c=L['claims'][cid]
    w(f"| {cid} | {cycle['falsifiers'][cid]} | {c['tier']} → {c['tier']} | {c['status']} | {', '.join(byclaim.get(cid,[])) or 'none'} |")
w('\nNo claim was cut. Spine-lock falsifiers: F1 FORCED (headline, compromises C4 at the supply posited at Level 10), F2 IMPORT (tripwire, compromises the optional corroboration of Section 5 only). Thesis carried forward, overlap 1.00.\n')
w('## Disposition census, all rounds\n')
tot=Counter(f['disposition'] for f in findings); sev=Counter(f['severity'] for f in findings); reg=Counter(f['register'] for f in findings)
w(f"{len(findings)} findings: {tot['EARNED']} EARNED, {tot['SCOPED']} SCOPED, {tot['REFUSED-STRUCTURAL']} REFUSED-STRUCTURAL, 0 REFUSED-MASSLESS, 0 APERTURE. Severity: 0 FATAL, {sev['LOAD-BEARING']} LOAD-BEARING, {sev['STRUCTURAL']} STRUCTURAL, {sev['COSMETIC']} COSMETIC. Every EARNED finding carries a repaired attestation and a sweep spec; every SCOPED finding carries its scope sentence. Repeats filed as such: " + ', '.join(f"{f['fid']}→{f['repeat_of']}" for f in findings if f.get('repeat_of')) + '. Tier moves: 0. External mass admitted: none.\n')
w('| Round | Verdict | Registers | Findings | E / S / R | Controls |\n|---|---|---|---|---|---|')
per=defaultdict(list)
for f in findings: per[f['round']].append(f)
for k in sorted(rounds):
    rd=rounds[k]; rs=per.get(k,[]); dis=Counter(r['disposition'] for r in rs)
    w(f"| {k} | {rd['verdict']} | {' + '.join(rd['registers'])} | {len(rs)} | {dis['EARNED']} / {dis['SCOPED']} / {dis['REFUSED-STRUCTURAL']} | {rd['controls_caught']}/{rd['controls_total']} {rd['control_grade']} |")
w(f"\nBy register across the cycle: " + ', '.join(f'{k} {v}' for k,v in reg.most_common()) + '.\n')
w('## Register coverage\n')
w('All six registers prosecuted by valid rounds: kinematic and definitional (rounds 1, 5, 9, 10, 12, 14 to 20), parameter and provenance (round 2), limit and symmetry (round 4; round 3 void and re-run). Void rounds 3, 6, 7, 8, 11, 13 and 21 also ran their pairs; their findings are retained and repaired, and they count for nothing toward the floor. From round 4 the highest-yield pair restated, kinematic and definitional, per A3.\n')
w('## Control detection\n')
w('Grade SELF in every round; the grade floor is SELF and the single-substrate aperture is stamped here. Detection: 3/3 in rounds 1, 2, 4, 5, 9, 10, 12, 14, 15, 16, 17, 18, 19, 20; 2/3 in rounds 3, 11, 13, 21; 1/3 in rounds 6, 7, 8. In every miss the arithmetic plant was caught and a drift or scope plant was not; from round 9 the prosecutor was told that plants of three kinds exist, placement and count withheld. Commitments and reveals are in the bundle as `controls_r{N}.commit.txt` and `controls_r{N}.sealed.json`; `controls_r22` was committed for a round the architect stopped before prosecution and is unrevealed by any prosecution.\n')
w('## Propagation record\n')
specs=sorted(glob.glob(os.path.join(C,'sweep_r*_*.json')),key=lambda p:(int(os.path.basename(p).split('_')[1][1:]),os.path.basename(p)))
w(f'{len(specs)} sweep specs re-verified on the final master (`verify_all.py`): PASS, 0 failures. Per spec, banned phrases at 0 live and required phrases present, with the supersession where one is recorded.\n')
w('| Spec | Banned (all at 0 live) | Required present | Supersession |\n|---|---|---|---|')
for s in specs:
    base=os.path.basename(s); sp=json.load(open(s)); req=sp.get('required',[]); ok=0; via=[]
    for r in req:
        e=[x for x in sup if x['spec']==base and x['required']==r]
        if e:
            if e[0]['successor'] in final: ok+=1; via.append(e[0]['by'])
        elif r in final: ok+=1
    live=sum(1 for b in sp.get('banned',[]) if b in final)
    assert live==0 and ok==len(req), base
    w(f"| {base[6:-5]} | {len(sp.get('banned',[]))} | {ok}/{len(req)} | {', '.join(sorted(set(via))) or ''} |")
w(f"\n{len(sup)} supersessions recorded in `superseded.json`, each by a later finding that reworded a required phrase on purpose. Citation and cone checker on the final: RESULT PASS, 153 distinct backticked names, every seed cone matched against `cones205.json`, every composition cone against the compiled probe. Spine lock VERIFY PASS. Box 1 recompiled from the final text: exit 0, 0 warnings, 9 cones MATCH.\n")
w('## Errata census\n')
w('None. No ERR row was logged: no finding filed by the auditing seats was later corrected as wrong. The nine repeats are the same mechanism recurring at another site, found at an end-to-end read or by the next prosecutor, and the one repeat of a refusal, BB-2 of W-3, left the refusal standing on substance and tightened the wording of the attribution rule the refusal relied on. Three defense-side additions regressed and were repaired by the next round\'s finding (BB-2\'s attribution sentence by CC-1, CC-3\'s chart sentence by DD-1, the amendment\'s master-closure sentence by FF-1), which is the standing reason, from round 15, for no defense additions beyond the minimal repair of a filed finding.\n')
w('## Reversions ordered at the gate\n')
w('None. The architect\'s one instruction at the gate was closure; the architect\'s one amendment, reference 7 at v3.0.8, was applied before round 19 and prosecuted in rounds 19 and 20.\n')
w('## Open apertures\n')
w('1. Single-substrate controls, SELF grade throughout; awaits an architect-authored EXTERNAL control set.\n2. The Formal Master v3.0.8 cited by its pins and not run here; awaits a compile under its own toolchain on the record.\n3. The residual goal over ℂ, `LeastErasure ZetaZeros`, is this edition\'s one premise, supplied by the act in the author\'s posit; awaits no witness from the cycle.\n4. `Closed ZetaZeros` unproved in the Master (Schwarz reflection); retraction injectivity is RH in another coat; neither moves the ledger.\n5. The two-consecutive-clean-rounds debt rule was never met (streak 1/2 at round 20); closure is by ruling.\n')
w('## What the artifact survived, in one line\n')
w('Held under all six registers across 21 rounds, 14 valid and 7 void, SELF controls throughout, 109 findings answered, 10 load-bearing repaired, 23 scoped down on the record with no claim cut and no tier moved, the title held, closed by the architect\'s ruling with the debt rule unmet and five apertures open.\n')
open(out,'w',encoding='utf-8').write('\n'.join(W)); print('wrote',out)
