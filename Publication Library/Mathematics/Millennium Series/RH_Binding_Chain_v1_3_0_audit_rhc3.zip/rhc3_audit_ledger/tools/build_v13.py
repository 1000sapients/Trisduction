#!/usr/bin/env python3
"""Math Journal build for the binding-chain paper (house toolchain, xelatex).

usage: build_v13.py source.md stem
Pre-processes the Markdown master, then runs pandoc + xelatex twice through
mathjournal_1col_v13.tex (the house template plus two blackboard glyphs).
  1. the binding ledger pipe table -> footnotesize LaTeX longtable, house widths
  2. References and Appendix A -> one two-column block, the seed as a numbered
     Verbatim at the house codebook size
  3. @@INCLUDE path@@ -> file contents
Reports xelatex exit, overfull boxes, missing glyphs, page count, and the
render-completeness probe (terminal string, terminal sections present).
"""
import re, subprocess, sys, os

src, stem = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf-8').read()

def tex_inline(x):
    """Inline Markdown in a ledger cell -> LaTeX."""
    out = []
    for i, part in enumerate(re.split(r'(`[^`]+`)', x)):
        if part.startswith('`') and part.endswith('`'):
            code = part[1:-1]
            code = code.replace('\\', '\\textbackslash ').replace('{', '\\{').replace('}', '\\}') \
                       .replace('#', '\\#').replace('_', '\\_')
            out.append('\\texttt{\\scriptsize ' + code + '}')
        else:
            t = part.replace('\\|', '|')
            t = t.replace('&', '\\&').replace('%', '\\%').replace('#', '\\#')
            t = re.sub(r'\*\*(.+?)\*\*', r'\\textbf{\1}', t)
            t = re.sub(r'(?<!\*)\*(?!\*)(.+?)\*', r'\\emph{\1}', t)
            t = t.replace('|', '\\textbar{}')
            out.append(t)
    return ''.join(out)

def ledger(block):
    rows = [r for r in block.strip('\n').split('\n') if r.strip().startswith('|')]
    cells = [[c.strip() for c in re.split(r'(?<!\\)\|', r.strip().strip('|'))] for r in rows]
    head, data = cells[0], [c for c in cells[2:]]
    W = ['0.041', '0.131', '0.21', '0.42', '0.121']
    spec = ''.join('>{\\raggedright\\arraybackslash}p{%s\\textwidth}' % w for w in W)
    L = ['```{=latex}', '{\\footnotesize\\setlength{\\tabcolsep}{3.2pt}',
         '\\begin{longtable}{' + spec + '}', '\\toprule',
         ' & '.join('\\textbf{%s}' % h for h in head) + ' \\\\', '\\midrule', '\\endfirsthead',
         '\\toprule', ' & '.join('\\textbf{%s}' % h for h in head) + ' \\\\', '\\midrule', '\\endhead',
         '\\bottomrule', '\\endlastfoot']
    for r in data:
        lvl, name, thms, what, grade = r
        # first sentence of the name cell in bold, as the house ledger sets it
        m = re.match(r'^(.*?\.)(\s.*)?$', name)
        name_t = '\\textbf{' + tex_inline(m.group(1)) + '}' + tex_inline(m.group(2) or '') if m else tex_inline(name)
        grade_t = re.sub(r'\b(THEOREM|PREMISE)\b', r'\\textbf{\1}', tex_inline(grade))
        L.append('\\textbf{%s} & %s & %s & %s & %s \\\\' % (lvl, name_t, tex_inline(thms), tex_inline(what), grade_t))
        L.append('\\addlinespace[2pt]')
    L += ['\\end{longtable}}', '```']
    return '\n'.join(L)

# 1. the ledger
m = re.search(r'(## 2\. The binding ledger\n\n)(\|.*?\n)(?=\n## )', s, re.S)
assert m, 'ledger table not found'
s = s[:m.start(2)] + ledger(m.group(2)) + '\n' + s[m.end(2):]

# 2. References + Appendix A in one two-column block, the seed numbered
inc = re.search(r'```lean\n@@INCLUDE ([^@]+)@@\n```', s)
assert inc, 'seed include not found'
seed = open(inc.group(1), encoding='utf-8').read().rstrip('\n')
CFS = os.environ.get('CFS', '\\fontsize{5.0}{5.6}')
verb = ('```{=latex}\n\\begin{Verbatim}[fontsize=' + CFS + '\\selectfont,numbers=left,numbersep=2.5pt,'
        'breaklines,breakanywhere,breaksymbolleft={}]\n' + seed + '\n\\end{Verbatim}\n\\end{multicols}\n```')
s = s[:inc.start()] + verb + s[inc.end():]
s = s.replace('## References\n', '```{=latex}\n' + ('\\clearpage\n' if os.environ.get('BREAK_REFS') else '') + '\\begin{multicols}{2}\n\\raggedcolumns\n```\n\n## References\n', 1)
ri = s.index('## References\n'); ai = s.index('## Appendix A')
refs = s[ri:ai]
refs = re.sub(r'(?<!/)/(?!/)', lambda _m: '/`\\allowbreak{}`{=latex}', refs)
refs = refs.replace('https://', 'https://`\\allowbreak{}`{=latex}')
s = s[:ri] + refs + s[ai:]

open(stem + '_pdf.md', 'w', encoding='utf-8').write(s)
subprocess.run(['pandoc', stem + '_pdf.md', '-o', stem + '.tex', '--template', 'mathjournal_1col_v13.tex',
                '--standalone', '-f', 'markdown+raw_tex+tex_math_dollars', '--no-highlight'], check=True)
for _ in range(2):
    r = subprocess.run(['xelatex', '-interaction=nonstopmode', '-halt-on-error', stem + '.tex'],
                       capture_output=True, text=True)
log = open(stem + '.log', errors='replace').read()
bad = [l for l in log.splitlines() if l.startswith('!') or 'Missing character' in l or 'Overfull' in l]
print('xelatex exit', r.returncode, '| warnings:', len(bad))
for l in bad[:12]:
    print('  ', l)
info = subprocess.run(['pdfinfo', stem + '.pdf'], capture_output=True, text=True).stdout
pages = int(info.split('Pages:')[1].split('\n')[0].strip())
txt = subprocess.run(['pdftotext', stem + '.pdf', '-'], capture_output=True, text=True).stdout
last_seed = seed.strip().split('\n')[-1].strip()
probe = {'terminal seed line': last_seed[:40] in txt.replace('\n', ' ') or last_seed.split()[-1] in txt,
         'Section 7 present': 'The default reading, answered' in txt,
         'References present': 'References' in txt,
         'Appendix A present': 'Appendix A' in txt}
print('pages', pages, '| completeness probe', probe)
