#!/usr/bin/env python3
"""Pre-Forge Digest generator: per-round sentence-level hunks mapped to finding ids via sweep specs."""
import difflib, re, json, glob, os, sys
A='/home/claude/apu/audit'
seq=[('r0','cand_v1_3_0_r0.md',None),('r1','cand_v1_3_0_r1.md',1),('r2','cand_v1_3_0_r2.md',2),('r3','cand_v1_3_0_r3.md',3),
     ('r3j','cand_v1_3_0_r3j.md',4),('r4','cand_v1_3_0_r4.md',4),('r5','cand_v1_3_0_r5.md',5),('r6','cand_v1_3_0_r6.md',6),
     ('r7','cand_v1_3_0_r7.md',7),('r8','cand_v1_3_0_r8.md',8),('r9','cand_v1_3_0_r9.md',9),('r11','cand_v1_3_0_r11.md',11),
     ('r12','cand_v1_3_0_r12.md',12),('r13','cand_v1_3_0_r13.md',13),('r14','cand_v1_3_0_r14.md',14),('r15','cand_v1_3_0_r15.md',15),
     ('r17','cand_v1_3_0_r17.md',17),('r19a','cand_v1_3_0_r19a.md',19),('r19','cand_v1_3_0_r19.md',19),
     ('final','/home/claude/apu/paper/RH_Binding_Chain_v1_3_0.md','FORGE')]
def body(p):
    t=open(p if p.startswith('/') else os.path.join(A,p),encoding='utf-8').read()
    return t.split('## Appendix A')[0]
specs={}
for f in glob.glob(os.path.join(A,'audit_rhc3','sweep_r*_*.json')):
    m=re.match(r'sweep_r(\d+)_(.+)\.json',os.path.basename(f)); specs.setdefault(int(m.group(1)),[]).append((m.group(2),json.load(open(f))))
findings={}
for l in open(os.path.join(A,'audit_rhc3','findings.jsonl')):
    r=json.loads(l); findings[r['fid']]=r
def section_of(lines,i):
    sec='front matter'
    for k in range(i,-1,-1):
        l=lines[k]
        if l.startswith('## '): return l[3:].strip()
        if l.startswith('abstract:'): return 'abstract'
        if l.startswith('\\* Every theorem'): return 'front note'
        if l.startswith('| '): 
            m=re.match(r'^\| (\d+) \|',l)
            if m: return f'ledger row {m.group(1)}'
    return sec
SENT=re.compile(r'(?<=[.;:])\s+(?=[A-Z`*(‘\'"])')
def sent_split(s): return SENT.split(s)
def hunks(a,b):
    la,lb=a.split('\n'),b.split('\n')
    out=[]
    for tag,i1,i2,j1,j2 in difflib.SequenceMatcher(None,la,lb,autojunk=False).get_opcodes():
        if tag=='equal': continue
        sec=section_of(la,i1 if i1<len(la) else len(la)-1)
        if tag=='replace' and (i2-i1)==(j2-j1):
            for x,y in zip(la[i1:i2],lb[j1:j2]):
                sa,sb=sent_split(x),sent_split(y)
                for t2,p1,p2,q1,q2 in difflib.SequenceMatcher(None,sa,sb,autojunk=False).get_opcodes():
                    if t2=='equal': continue
                    out.append((sec,' '.join(sa[p1:p2]),' '.join(sb[q1:q2])))
        else:
            out.append((sec,'\n'.join(la[i1:i2]),'\n'.join(lb[j1:j2])))
    return out
# Manual attribution for consumer-site propagations the sweep specs do not name:
# (version, section, substring that must occur in the after-text (or in the before-text when prefixed 'B:'), finding ids, note)
MANUAL=[
 ('r1','1. The chain','posited as the event whose act supplies that field',['F-2','F-23'],'Section 1 consumer site of the F-2 repair, reached at the F-23 joint read'),
 ('r1','ledger row 3','an_off_line_zero_comes_in_four',['F-15'],'ledger row 3 cites the four-point theorem the F-15 repair names'),
 ('r1','ledger row 8','that some state is realized',['F-3'],'row 8 states the floor as the F-3 scope reads it'),
 ('r1','4. The fixed stance','at every resolution and at one configuration, composed and compiled',['F-5'],'Box 1 title follows the F-5 composition at every resolution'),
 ('r1','4. The fixed stance','cited as corroboration over ℂ',['F-17'],'Formal Master marked as corroboration, the F-17 scope'),
 ('r1','4. The fixed stance','the unused-variable linter is off for one theorem',['F-9'],'Box 2 compile line states the linter fact F-9 found'),
 ('r1','4. The fixed stance','ref. 8      Cargo_Delivered_Hardened.lean · 184 lines',['F-16','F-17'],'Box 2 prints the hardened cargo cone, the F-16 and F-17 provenance repairs'),
 ('r1','7. The default reading, answered','the proofs of Level 10 are three, the cargo\'s on the cargo section',['F-1','F-23'],'Section 7 consumer site of the F-1 proof-term separation, reached at the F-23 joint read'),
 ('r2','4. The fixed stance','Box 1 prints three compositions',['G-4'],'count follows the G-4 composition cargo_binding_on_the_seed'),
 ('r2','4. The fixed stance','and the cargo\'s binding, composed and compiled',['G-4'],'Box 1 title names the G-4 binding'),
 ('r2','4. The fixed stance','The conditionals\' inputs are the reading and the act',['G-4'],'caption scoped to the conditionals once the binding joined Box 1 under G-4'),
 ('r2','4. The fixed stance','a separate file with its own copy of the types',['G-4'],'Box 2 states the type-copy fact G-4 found'),
 ('r3','front note','`Classical.byContradiction`',['H-14'],'front note lists the constant H-14 corrected'),
 ('r3','1. The chain','a reading that carries that resolution\'s content and so is a premise',['H-4'],'Section 1 twin sentence carries the H-4 scope'),
 ('r3','4. The fixed stance','fun n _ => hZ ▸',['H-2'],'Box 1 proof term follows the H-2 bound in the type'),
 ('r4','front note','the six compositions of Box 1',['I-6','I-7','I-9'],'count follows the three compositions added under I-6, I-7 and I-9'),
 ('r4','3. The single bind','its packaging Part V-b\'s `the_act_at_every_resolution`',['I-6','I-11'],'Section 3 names the packaging\'s dependency, I-6 and I-11'),
 ('r4','4. The fixed stance','Box 1 prints six compositions',['I-6','I-7','I-9'],'count and grades follow the three compositions added under I-6, I-7 and I-9'),
 ('r4','4. The fixed stance','the act packaged, and the cargo\'s binding',['I-6'],'Box 1 title names the I-6 packaging'),
 ('r4','7. The default reading, answered','its packaging on Part V-b',['I-6'],'Section 7 consumer site of the I-6 packaging'),
 ('r6','front note','the seven compositions of Box 1',['K-4'],'count follows the K-4 composition the_reading_every_is_keyed'),
 ('r6','4. The fixed stance','Box 1 prints seven compositions',['K-4'],'count follows the K-4 composition'),
 ('r6','4. The fixed stance','the one added hypothesis is the empty term at resolution zero',['K-2'],'Box 1 docstring follows the K-2 removal of hR'),
 ('r6','4. The fixed stance','the closedness of the configurations following from the value',['K-2'],'Box 1 docstring, K-2'),
 ('r6','4. The fixed stance','theorem the_act_every_is_the_value_packaged {R : Nat → Config} (h0 :',['K-2'],'Box 1 signature without hR, K-2'),
 ('r6','4. The fixed stance','have hR : ∀ n, Closed (R n) := fun n p hp => by',['K-2'],'Box 1 proof derives closedness from the value, K-2'),
 ('r6','4. The fixed stance','ClassicalRH ↔ ∀ n, 1 ≤ n → Value (R n)) (h0 :',['K-2'],'Box 1 refusal signature without hR, K-2'),
 ('r6','4. The fixed stance','rw [the_act_every_is_the_value_packaged h0, h_read]',['K-2'],'Box 1 refusal proof without hR, K-2'),
 ('r7','front note','the eight compositions of Box 1',['L-3'],'count follows the L-3 composition the_collected_act_is_the_act_every'),
 ('r7','4. The fixed stance','Box 1 prints eight compositions',['L-3'],'count and grades follow the L-3 composition'),
]
entries=[]; n=0
prev=body(seq[0][1])
for name,path,rnd in seq[1:]:
    cur=body(path)
    for sec,before,after in hunks(prev,cur):
        ids=[]; note=''
        if isinstance(rnd,int):
            for fid,sp in specs.get(rnd,[]):
                if any(bn in before for bn in sp.get('banned',[])) or any(rq in after for rq in sp.get('required',[])):
                    ids.append(fid)
            if not ids:
                for v,s,sub,fids,nt in MANUAL:
                    if v==name and s==sec and ((sub[2:] in before) if sub.startswith('B:') else (sub in after)):
                        ids=list(fids); note=nt; break
        elif rnd=='FORGE':
            ids=['FORGE']; note='date stamp of the final render'
        entries.append({'version':name,'round':rnd,'section':sec,'before':before,'after':after,'ids':sorted(set(ids)),'note':note})
    prev=cur
json.dump(entries,open(os.path.join(A,'audit_rhc3','digest_entries.json'),'w'),ensure_ascii=False,indent=1)
print('entries',len(entries),'unmapped',sum(1 for e in entries if not e['ids'] and isinstance(e['round'],int)))
for e in entries:
    if not e['ids'] and isinstance(e['round'],int): print(' UNMAPPED',e['version'],e['section'],'|',e['before'][:70],'->',e['after'][:70])
