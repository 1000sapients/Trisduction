#!/usr/bin/env python3
"""Re-verify every sweep spec of a cycle against a candidate, honouring superseded.json.
usage: verify_all.py CYCLE_DIR FILE"""
import json, sys, glob, os
d, f = sys.argv[1], sys.argv[2]
t = open(f, encoding='utf-8').read()
sup = json.load(open(os.path.join(d, 'superseded.json')))['entries'] if os.path.exists(os.path.join(d, 'superseded.json')) else []
fails = 0; n = 0
for s in sorted(glob.glob(os.path.join(d, 'sweep_*.json'))):
    spec = json.load(open(s)); base = os.path.basename(s); n += 1
    for b in spec.get('banned', []):
        if b in t: print(f'LIVE banned  {base}: {b}'); fails += 1
    for r in spec.get('required', []):
        e = [x for x in sup if x['spec'] == base and x['required'] == r]
        if e:
            if e[0]['successor'] not in t: print(f'ABSENT successor {base} ({e[0]["by"]}): {e[0]["successor"]}'); fails += 1
            continue
        if r not in t: print(f'ABSENT required {base}: {r}'); fails += 1
print(f'{n} specs, {fails} failures:', 'PASS' if not fails else 'FAIL')
sys.exit(1 if fails else 0)
