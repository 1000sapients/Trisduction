#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MEDIUM / SUBSTACK / BLOG format builder.

Takes any source .md (codex, paper, or scripture output) and emits a single
.md that survives copy-paste into the Medium or Substack editor without
breaking. The two editors have no reliable markdown-table paste and no LaTeX,
so the transform linearises every table into labelled prose, flattens raw HTML
(including the RTL word grid) into inline gloss, converts ^x^/~x~/<sup>/<sub>
to Unicode super/subscript where the glyph exists, and leaves headers, bold,
italic, blockquotes, lists, links, and fenced code untouched, since those paste
faithfully on both platforms. All mathematics is already Unicode by house rule;
any LaTeX is reported so it can be hand-fixed.

  python3 build_blog.py source.md /mnt/user-data/outputs/{slug}.blog.md
"""
import sys, re
from pathlib import Path

SUP = {'0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹',
       '+':'⁺','-':'⁻','=':'⁼','(':'⁽',')':'⁾','n':'ⁿ','i':'ⁱ','a':'ᵃ','b':'ᵇ','c':'ᶜ',
       'd':'ᵈ','e':'ᵉ','k':'ᵏ','m':'ᵐ','t':'ᵗ','x':'ˣ'}
SUB = {'0':'₀','1':'₁','2':'₂','3':'₃','4':'₄','5':'₅','6':'₆','7':'₇','8':'₈','9':'₉',
       '+':'₊','-':'₋','=':'₌','(':'₍',')':'₎','a':'ₐ','e':'ₑ','k':'ₖ','m':'ₘ','n':'ₙ',
       'x':'ₓ','t':'ₜ','i':'ᵢ','s':'ₛ','p':'ₚ'}

def to_unicode_run(s, table):
    if all(ch in table for ch in s):
        return ''.join(table[ch] for ch in s)
    return None

def convert_supsub(text):
    # <sup>..</sup> and ^..^  ;  <sub>..</sub> and ~..~
    def rep_sup(m):
        u = to_unicode_run(m.group(1), SUP); return u if u else m.group(1)
    def rep_sub(m):
        u = to_unicode_run(m.group(1), SUB); return u if u else m.group(1)
    text = re.sub(r'<sup>(.*?)</sup>', rep_sup, text, flags=re.S)
    text = re.sub(r'<sub>(.*?)</sub>', rep_sub, text, flags=re.S)
    text = re.sub(r'\^([^\s^]{1,8})\^', rep_sup, text)
    text = re.sub(r'(?<!~)~([^\s~]{1,8})~(?!~)', rep_sub, text)
    return text

def linearize_rtl_grid(html):
    """The protocol's <table dir="rtl"> word grid -> inline per-word gloss."""
    rows = re.findall(r'<tr>(.*?)</tr>', html, flags=re.S)
    cells = [re.findall(r'<td[^>]*>(.*?)</td>', r, flags=re.S) for r in rows]
    cells = [[c.strip() for c in row] for row in cells]
    if not cells:
        return ''
    ncol = max(len(r) for r in cells)
    ar = cells[0] if len(cells) > 0 else []
    tr = cells[1] if len(cells) > 1 else []
    me = cells[2] if len(cells) > 2 else []
    parts = []
    for i in range(ncol):
        a = ar[i] if i < len(ar) else ''
        t = tr[i] if i < len(tr) else ''
        m = me[i] if i < len(me) else ''
        gloss = ', '.join(x for x in (t, m) if x)
        parts.append(f'**{a}** ({gloss})' if gloss else f'**{a}**')
    return '> ' + '  ·  '.join(parts) + '\n'

def linearize_pipe_table(block):
    lines = [ln for ln in block.strip('\n').splitlines() if ln.strip()]
    rows = []
    for ln in lines:
        if re.match(r'^\s*\|?\s*:?-{2,}', ln.replace('|', '').strip()[:3]) or re.match(r'^[\s|:-]+$', ln):
            continue
        cells = [c.strip() for c in ln.strip().strip('|').split('|')]
        rows.append(cells)
    if len(rows) < 2:
        return block
    header, body = rows[0], rows[1:]
    out = []
    for r in body:
        first = r[0] if r else ''
        rest = []
        for j in range(1, len(r)):
            lab = header[j] if j < len(header) else ''
            val = r[j]
            if val:
                rest.append(f'{lab}: {val}' if lab else val)
        line = f'- **{first}**' + (' · ' + '; '.join(rest) if rest else '')
        out.append(line)
    return '\n'.join(out) + '\n'

def transform(md):
    notes = []
    # 1. RTL word grids -> inline gloss
    md = re.sub(r'<table[^>]*dir="rtl"[^>]*>.*?</table>',
                lambda m: linearize_rtl_grid(m.group(0)), md, flags=re.S)
    # 2. any other raw <table> ... </table> (HTML) -> drop to a note (rare)
    md = re.sub(r'<table.*?</table>',
                lambda m: '*[table flattened for blog; see source]*\n', md, flags=re.S)
    # 3. pipe tables -> labelled lists  (protect fenced code first)
    fences = []
    def stash(m):
        fences.append(m.group(0)); return f'\x00F{len(fences)-1}\x00'
    md = re.sub(r'```.*?```', stash, md, flags=re.S)
    # find blocks of >=2 consecutive lines containing a pipe, with a separator row
    out_lines, buf = [], []
    def flush():
        nonlocal buf
        if buf:
            block = '\n'.join(buf)
            if re.search(r'^\s*\|?[\s:-]*-{2,}[\s:|-]*$', block, flags=re.M) and block.count('|') >= 2:
                out_lines.append(linearize_pipe_table(block))
            else:
                out_lines.extend(buf)
            buf = []
    for ln in md.splitlines():
        if '|' in ln and ln.strip():
            buf.append(ln)
        else:
            flush(); out_lines.append(ln)
    flush()
    md = '\n'.join(out_lines)
    for i, f in enumerate(fences):
        md = md.replace(f'\x00F{i}\x00', f)
    # 4. strip leftover block HTML wrappers + inline style spans
    md = re.sub(r'</?div[^>]*>', '', md)
    md = re.sub(r'<span[^>]*>(.*?)</span>', r'\1', md, flags=re.S)
    # 5. super/subscript to Unicode
    md = convert_supsub(md)
    # 6. flag LaTeX
    if re.search(r'(?<!\\)\$[^$\n]+\$|\\\(|\\\[|\\begin\{', md):
        notes.append('LaTeX detected: convert to Unicode by hand; Medium and Substack do not render it from paste.')
    md = re.sub(r'\n{3,}', '\n\n', md)
    return md, notes

def main():
    if len(sys.argv) < 2:
        sys.exit('usage: build_blog.py source.md [out.blog.md]')
    src = Path(sys.argv[1])
    out = sys.argv[2] if len(sys.argv) > 2 else str(src.with_suffix('.blog.md'))
    md, notes = transform(src.read_text(encoding='utf-8'))
    Path(out).write_text(md, encoding='utf-8')
    print('wrote', out)
    for n in notes:
        print('NOTE:', n)

if __name__ == '__main__':
    main()
