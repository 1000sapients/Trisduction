# -*- coding: utf-8 -*-
"""Extract Lean excerpts from the master file and render them with pygments to LaTeX
(fancyvrb/fvextra Verbatim) with line numbers equal to the master file's own line numbers."""
import re, pathlib
from pygments import highlight
from pygments.lexers import Lean4Lexer
from pygments.formatters import LatexFormatter
from pygments.style import Style
from pygments.token import Keyword, Name, Comment, String, Number, Operator, Punctuation, Text, Generic

SRC = pathlib.Path('../v3024cc.lean').read_text(encoding='utf-8').splitlines()

class HouseStyle(Style):
    default_style = ''
    styles = {
        Text: '#171717', Punctuation: '#171717', Operator: '#171717',
        Keyword: 'bold #8A5523', Keyword.Type: '#1F3A66',
        Name: '#171717', Name.Function: '#171717', Name.Class: '#1F3A66', Name.Builtin: '#171717',
        Name.Decorator: '#8A5523', Name.Constant: '#171717', Name.Variable: '#171717',
        Comment: 'italic #6f6f6f', Comment.Multiline: 'italic #6f6f6f', Comment.Single: 'italic #6f6f6f',
        String: '#1F5C3D', String.Doc: 'italic #6f6f6f', Number: '#171717', Generic: '#171717',
    }

EXCERPTS = [
 ('defs', 11021, 11085, 'The complex chart: the translation dictionary and the definitions of Part X'),
 ('reading', 11136, 11154, 'The reading and the identification'),
 ('record', 11156, 11213, 'The record, the act, the transport measure, the cargo'),
 ('fixedpoint', 11215, 11242, 'Set-level idempotence and the fixed-point characterization (X-a)'),
 ('fiber', 11269, 11361, 'Fiber invariance and the barred refuter (X-c)'),
 ('toe0', 106, 146, 'The self-grounding root (Part I)'),
 ('faces', 11244, 11267, 'Analytic faces (X-b)'),
 ('loop', 11363, 11442, 'The self-grounding recursion and the five-way loop (X-d)'),
 ('binding', 11444, 11479, 'The eleven-part binding and the transfer status (X-d)'),
 ('strip', 11481, 11550, 'Strip equivalence and functional-equation closure (X-e)'),
 ('orbit', 11552, 11624, 'Retraction injectivity and orbit collapse (X-f)'),
 ('chart', 11626, 11657, 'The discrete-to-complex chart homomorphism (X-g)'),
 ('schwarz', 11658, 11773, 'Schwarz reflection for zeta and its two auxiliaries (X-h)'),
 ('nonvanish', 11775, 11851, 'Non-vanishing at the negative odd integers; the zeros avoid the nonpositive integers (X-h)'),
 ('zclosed', 11853, 11929, 'The zeros closed under s to 1-s, conjugation and the fold; the orbit collapse at the zeros; strip confinement (X-h)'),
 ('socket', 12097, 12169, 'The pins of X-h, the socket at the zeros, and Part VIII\'s carrier in the plane (X-h, X-i)'),
 ('cone', 12171, 12229, 'The cone over the four readings of the bit (X-k)'),
 ('pause', 12231, 12278, 'The impossibility over $\mathbb{C}$, the pause and the unconditional forward pass (X-l)'),
 ('seal', 12280, 12343, 'The look back, the unconditional retrospective seal and the step to the hypothesis (X-l)'),
 ('canonical', 12345, 12372, 'The canonical apex: the canonical record hypothesis, unconditional, and the property off the line (X-l)'),
 ('monism', 12374, 12429, 'The Monism witness over $\mathbb{C}$ and the canonical normal-form bridge (X-l)'),
 ('target', 12431, 12504, 'The Euler product boundary and the analytic target reduction (X-l)'),
 ('joint', 12506, 12534, 'The joint physico-formal seal over $\mathbb{C}$ (X-l)'),
 ('roundtwo', 12536, 12614, 'Round 2: the least erasure of the record as a self-grounding root, the halt, the residual monism, and the delivery of the bit by every route (X-l)'),
 ('sealed', 12616, 12642, 'The analytic route sealed (X-l)'),
 ('gol', 12644, 12731, 'The complex three-axis lock, the Ground-On-Line locus and its loop (X-l)'),
 ('band', 12733, 12840, 'The strict strip, the completed zeros, and the zero-free band (X-l)'),
 ('selfrec', 12842, 12909, 'The self-recognition of the zeros and the self-recognition closure (X-l)'),
 ('tcert', 12911, 13013, 'The terminal certification as a theorem (X-l)'),
 ('arch', 10831, 10914, 'The bound chain and the discrete recursion (Part IX)'),
 ('arrows', 9415, 9462, 'The capstone in both forms (§VII-e)'),
 ('keyed', 9486, 9526, 'No third position; the reading and the bridge are keyed; the bound alone decides nothing (§VII-e, §VII-f)'),
 ('carrier', 9691, 9780, 'The physical carrier, charge conjugation, annihilation, the map (§VIII-a, §VIII-b)'),
 ('violation', 9841, 9862, 'Mathematical violation forces physical discard (§VIII-c)'),
 ('bound', 9953, 9987, 'The certified bound, the detection gap, the signal floor (§VIII-e)'),
 ('physcap', 10007, 10061, 'The physico-formal capstone and no third position on the carrier (§VIII-e)'),
 ('exit', 10145, 10166, 'The one exit is a second register (§VIII-h)'),
 ('apparatus', 10359, 10409, 'The apparatus cargo: the event and Stage 1 (Part VIII-b)'),
 ('binder', 10168, 10204, 'The physical binder: the physico-formal closure, bound (§VIII-g)'),
 ('capstone', 13058, 13135, 'The master closure (Part XI)'),
 ('extensions', 13137, 13241, 'The complex extensions and the twin binder, bound (Part XI)'),
 ('pins', 11933, 11946, 'The head of Part X\'s pin block, the pin of rh_from_the_cargo_loop standing in Listing~8'),
]

fmt0 = LatexFormatter(style=HouseStyle)
pathlib.Path('snips/pygstyle.tex').write_text(fmt0.get_style_defs(), encoding='utf-8')
meta = []
for name, a, b, title in EXCERPTS:
    code = '\n'.join(SRC[a-1:b])
    fmt = LatexFormatter(style=HouseStyle, linenos=True, linenostart=a, envname='Verbatim',
                         verboptions=r'breaklines,breaksymbolleft={},breakindent=1.2em,breakafter={_.},breakaftersymbolpre={},breakaftersymbolpost={},fontsize=\leancodesize,numbersep=4pt,xleftmargin=1.9em,baselinestretch=1.0')
    if name=='pins':
        fmt = LatexFormatter(style=HouseStyle, linenos=True, linenostart=a, envname='Verbatim', verboptions=r'breaklines,breakanywhere,breaksymbolleft={},breakanywheresymbolpre={},breakindent=1.2em,fontsize=\leancodesize,numbersep=4pt,xleftmargin=1.9em,baselinestretch=1.0')
    out = highlight(code, Lean4Lexer(), fmt)
    pathlib.Path(f'snips/{name}.tex').write_text(out, encoding='utf-8')
    meta.append((name, a, b, title, b-a+1))
    print(f'{name:10s} {a:>6}-{b:<6} {b-a+1:>4} lines  {title}')
pathlib.Path('snips/meta.txt').write_text('\n'.join(f'{m[0]}\t{m[1]}\t{m[2]}\t{m[3]}' for m in meta))
