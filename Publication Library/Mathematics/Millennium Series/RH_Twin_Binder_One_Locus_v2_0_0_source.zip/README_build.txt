Build: xelatex paper.tex (twice). Requires TeX Gyre Pagella, DejaVu Sans Mono, fontspec, fvextra, multicol, needspace, pygments (Lean4Lexer).
Regenerate listings from the master file:  python3 gen_snips.py   (reads ../v3019.lean = RH_Both_Sides_Formal_Master_v3_0_19.lean)
Regenerate Appendix D:                      python3 gen_fullfile.py
Markdown master:                            python3 gen_md.py   (pandoc, gfm); audit edition: python3 gen_md.py --no-fullfile
