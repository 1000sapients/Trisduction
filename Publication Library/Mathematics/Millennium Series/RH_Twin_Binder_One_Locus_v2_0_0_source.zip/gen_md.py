# -*- coding: utf-8 -*-
"""Markdown master: paper.tex -> paper_md.tex (listings as numbered verbatim, Appendix D as one verbatim block)
-> pandoc -> paper.md. Pass --no-fullfile to replace Appendix D's verbatim file by a one-line pointer (audit edition)."""
import re, pathlib, subprocess, sys
SRC = pathlib.Path('../v3019.lean').read_text(encoding='utf-8').splitlines()
tex = pathlib.Path('paper.tex').read_text(encoding='utf-8')
nofull = '--no-fullfile' in sys.argv
out_tex = 'paper_md_audit.tex' if nofull else 'paper_md.tex'
out_md = 'paper_audit.md' if nofull else 'paper.md'

tex = tex.replace('\\input{snips/pygstyle.tex}\n', '').replace('\\def\\PYZus{\\char`\\_\\allowbreak}\n', '')

# the dagger macro: pandoc expands \newcommand but drops \textdagger, so the mark is given literally
tex = tex.replace('\\newcommand{\\dg}{\\textsuperscript{\\textdagger}}', '\\newcommand{\\dg}{†}')
tex = tex.replace('\\;\\textperiodcentered\\;', ' · ').replace('\\textperiodcentered', '·')  # chip separator survives pandoc
# boxes and the terminal line: pandoc drops the jbox title argument and brace-grouped font switches
def box_title(m):
    t = m.group(1).replace('\\textbar\\ ', '| ')
    return '\\par\\noindent\\rule{\\textwidth}{0.8pt}\\par\\noindent\\textbf{' + t + '}\\par'
tex = re.sub(r'\\begin\{jbox\}\{((?:[^{}]|\{[^{}]*\})*)\}', box_title, tex)
tex = tex.replace('\\end{jbox}', '\\par\\noindent\\rule{\\textwidth}{0.4pt}\\par')
tex = tex.replace('\\noindent{\\small\\itshape End of manuscript.}', '\\textit{End of manuscript.}')

# theorem-like environments: pandoc cannot number the house heads, so number them here as the PDF does (section.n)
ENVS = {'theorem': 'Theorem', 'definition': 'Definition', 'proposition': 'Proposition', 'corollary': 'Corollary'}
sec = 0; thm = 0; i = 0; buf = []
tok = re.compile(r'\\section\{|\\begin\{(theorem|definition|proposition|corollary)\}|\\end\{(theorem|definition|proposition|corollary)\}|\\appendix')
appendix = False
while True:
    m = tok.search(tex, i)
    if not m: buf.append(tex[i:]); break
    buf.append(tex[i:m.start()])
    if m.group(0) == '\\appendix':
        appendix = True; sec = 0; buf.append(m.group(0)); i = m.end(); continue
    if m.group(0) == '\\section{':
        sec += 1; thm = 0; buf.append(m.group(0)); i = m.end(); continue
    if m.group(1):
        thm += 1
        j = m.end(); opt = ''
        if j < len(tex) and tex[j] == '[':
            depth = 0; k = j
            while k < len(tex):
                if tex[k] == '{': depth += 1
                elif tex[k] == '}': depth -= 1
                elif tex[k] == ']' and depth == 0: break
                k += 1
            opt = tex[j+1:k]; j = k + 1
        label = (chr(64 + sec) if appendix else str(sec)) + '.' + str(thm)
        head = '\\par\\noindent\\textbf{' + ENVS[m.group(1)] + ' ' + label + '}' + (' (' + opt + ')' if opt else '') + '\\textbf{.} '
        buf.append(head); i = j; continue
    buf.append('\\par'); i = m.end()
tex = ''.join(buf)

def numbered(a, b):
    return '\n'.join(f' {i:>6}  {SRC[i-1]}' for i in range(a, b + 1))

def take_arg(s, i):
    """s[i] == '{'; return (content, index after closing brace) with balanced braces."""
    assert s[i] == '{'
    depth = 0; j = i
    while j < len(s):
        if s[j] == '{': depth += 1
        elif s[j] == '}':
            depth -= 1
            if depth == 0: return s[i+1:j], j + 1
        j += 1
    raise ValueError('unbalanced')

n = 0; pos = 0; parts = []
while True:
    k = tex.find('\\listing{', pos)
    if k < 0: parts.append(tex[pos:]); break
    parts.append(tex[pos:k])
    i = k + len('\\listing')
    key, i = take_arg(tex, i); cap, i = take_arg(tex, i); a, i = take_arg(tex, i); b, i = take_arg(tex, i)
    n += 1
    parts.append(f'\n\\textbf{{Listing {n}. {cap}}} (master lines {a} to {b})\n\n\\begin{{verbatim}}\n{numbered(int(a), int(b))}\n\\end{{verbatim}}\n')
    pos = i
tex = ''.join(parts)

full_pat = re.compile(r'\\begingroup\n\\setlength\{\\columnwidth\}\{[^\n]*\}\n\\input\{snips/fullfile\.tex\}\n\\endgroup')
m = full_pat.search(tex)
assert m, 'Appendix D block not found'
if nofull:
    repl = ('\n[Appendix D reproduces RH\\_Both\\_Sides\\_Formal\\_Master\\_v3\\_0\\_19.lean verbatim, all 12,788 lines, '
            'numbered; in this audit edition the file is supplied beside the paper and omitted here.]\n')
else:
    repl = '\n\\begin{verbatim}\n' + numbered(1, len(SRC)) + '\n\\end{verbatim}\n'
tex = tex[:m.start()] + repl + tex[m.end():]
pathlib.Path(out_tex).write_text(tex, encoding='utf-8')
r = subprocess.run(['pandoc', out_tex, '-f', 'latex', '-t', 'gfm', '--wrap=none', '-o', out_md], capture_output=True, text=True)
print('pandoc rc', r.returncode, r.stderr[:800])
md = pathlib.Path(out_md).read_text(encoding='utf-8').replace('\\allowbreak{}', '')
pathlib.Path(out_md).write_text(md, encoding='utf-8')
print(out_md, len(md), 'bytes;', md.count('\n'), 'lines; End of manuscript:', 'End of manuscript' in md)
