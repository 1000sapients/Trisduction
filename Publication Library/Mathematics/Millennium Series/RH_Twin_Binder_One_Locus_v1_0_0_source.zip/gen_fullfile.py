# -*- coding: utf-8 -*-
"""Appendix D: the whole master file, two columns, the file's own line numbers, deterministic pagination.
Each source line is word-wrapped to WIDTH visible characters; each page holds two columns of LPC physical lines,
emitted as two top-aligned minipages, so no page can ever overflow. Light highlighting: comments gray italic,
keywords bold copper, through the pygments PY macros already loaded by the paper."""
import re, pathlib, textwrap

SRC = pathlib.Path('../v308c.lean').read_text(encoding='utf-8').splitlines()
WIDTH = 60          # visible chars per physical line after the number gutter
LPC   = 78          # physical lines per column
CONT  = '  '        # continuation indent
KW = (r'\b(theorem|lemma|def|noncomputable|abbrev|structure|inductive|class|instance|namespace|end|section|open|'
      r'import|where|by|fun|match|with|if|then|else|let|have|show|from|exact|intro|intros|rintro|obtain|rcases|cases|'
      r'refine|constructor|apply|rw|simp|unfold|linarith|norm_num|decide|rfl|trivial|exfalso|calc|induction|set_option|'
      r'variable|Type|Prop|Sort|private|protected|deriving|example|do|return|mutual|at|only|using)\b')
kw_re = re.compile(KW)

_ESC = str.maketrans({'\\': '\\PYZbs{}', '{': '\\PYZob{}', '}': '\\PYZcb{}'})
def esc(s):
    return s.translate(_ESC)

def highlight_code(s):
    parts = []; pos = 0
    for m in kw_re.finditer(s):
        parts.append(esc(s[pos:m.start()])); parts.append('\\PY{k}{' + esc(m.group(0)) + '}'); pos = m.end()
    parts.append(esc(s[pos:]))
    return ''.join(parts)

# comment-region state machine on the source: block comments /- ... -/ (nesting counted), line comments --
phys = []   # (lineno or '', text, is_comment)
depth = 0
for i, line in enumerate(SRC, start=1):
    line = line.replace('\t', '    ')
    is_comment = depth > 0 or line.lstrip().startswith('--') or ('/-' in line)
    j = 0
    while j < len(line) - 1:
        if line[j:j+2] == '/-': depth += 1; j += 2; continue
        if line[j:j+2] == '-/': depth = max(0, depth - 1); j += 2; continue
        j += 1
    if line == '':
        phys.append((i, '', is_comment)); continue
    wrapped = textwrap.wrap(line, width=WIDTH, subsequent_indent=CONT, break_long_words=True,
                            break_on_hyphens=False, replace_whitespace=False, drop_whitespace=False)
    if not wrapped: wrapped = ['']
    for k, w in enumerate(wrapped):
        phys.append((i if k == 0 else '', w, is_comment))

total = len(phys); per_page = 2 * LPC
pages = (total + per_page - 1) // per_page
print('source lines', len(SRC), 'physical lines', total, 'pages', pages)

def render_line(num, text, is_c):
    body = '\\PY{c}{' + esc(text) + '}' if is_c else highlight_code(text)
    return '\\LN{' + str(num) + '}' + body

VOPT = '[commandchars=\\\\\\{\\},fontsize=\\leancodesize,baselinestretch=1.0,xleftmargin=0pt]'
out = []
for p in range(pages):
    chunk = phys[p*per_page:(p+1)*per_page]
    left = chunk[:LPC]; right = chunk[LPC:]
    first = next((n for n, _, _ in chunk if n != ''), '')
    last = next((n for n, _, _ in reversed(chunk) if n != ''), '')
    out.append('\\fullfilehead{' + str(first) + '}{' + str(last) + '}')
    out.append('\\noindent\\begin{minipage}[t]{\\columnwidth}\\vspace{0pt}')
    out.append('\\begin{Verbatim}' + VOPT)
    out.extend(render_line(n, t, c) for n, t, c in left)
    out.append('\\end{Verbatim}')
    out.append('\\end{minipage}\\hfill\\begin{minipage}[t]{\\columnwidth}\\vspace{0pt}')
    out.append('\\begin{Verbatim}' + VOPT)
    out.extend(render_line(n, t, c) for n, t, c in right)
    out.append('\\end{Verbatim}')
    out.append('\\end{minipage}\\par\\clearpage')
pathlib.Path('snips/fullfile.tex').write_text('\n'.join(out) + '\n', encoding='utf-8')
print('written snips/fullfile.tex')
