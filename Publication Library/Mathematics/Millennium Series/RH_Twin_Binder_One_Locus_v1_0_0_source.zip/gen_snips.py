# -*- coding: utf-8 -*-
"""Extract Lean excerpts from the master file and render them with pygments to LaTeX
(fancyvrb/fvextra Verbatim) with line numbers equal to the master file's own line numbers."""
import re, pathlib
from pygments import highlight
from pygments.lexers import Lean4Lexer
from pygments.formatters import LatexFormatter
from pygments.style import Style
from pygments.token import Keyword, Name, Comment, String, Number, Operator, Punctuation, Text, Generic

SRC = pathlib.Path('../v308c.lean').read_text(encoding='utf-8').splitlines()

class HouseStyle(Style):
    default_style = ''
    styles = {
        Text: '#171717', Punctuation: '#171717', Operator: '#171717',
        Keyword: 'bold #8A5523', Keyword.Type: '#1F3A66',
        Name: '#171717', Name.Function: '#171717', Name.Class: '#1F3A66', Name.Builtin: '#171717',
        Name.Decorator: '#8A5523', Name.Constant: '#171717', Name.Variable: '#171717',
        Comment: 'italic #6f6f6f', Comment.Multiline: 'italic #6f6f6f', Comment.Single: 'italic #6f6f6f',
        String: '#1F5C3D', String.Doc: 'italic #6f6f6f', Number: '#171717', Generic: '#171717',
    }

EXCERPTS = [
 ('defs',      10985, 11021, 'The complex chart: the definitions of Part X'),
 ('reading',   11071, 11089, 'The reading and the identification'),
 ('record',    11091, 11148, 'The record, the act, the transport measure, the cargo'),
 ('fixedpoint',11150, 11179, 'Set-level idempotence and the fixed-point characterization (X-a)'),
 ('faces',     11181, 11204, 'Analytic faces (X-b)'),
 ('fiber',     11206, 11297, 'Fiber invariance and the barred refuter (X-c)'),
 ('loop',      11299, 11401, 'The self-grounding recursion and the five-way loop (X-d)'),
 ('strip',     11403, 11475, 'Strip equivalence and functional-equation closure (X-e)'),
 ('orbit',     11477, 11547, 'Retraction injectivity and orbit collapse (X-f)'),
 ('chart',     11549, 11575, 'The discrete-to-complex chart homomorphism (X-g)'),
 ('capstone',  11640, 11697, 'The master closure (Part XI)'),
 ('toe0',        221,   258, 'The self-grounding root (Part I)'),
 ('arrows',     9536,  9577, 'The capstone in both forms (Part VII-e)'),
 ('keyed',      9600,  9634, 'No third position; the reading and the bridge are keyed (Part VII-e, VII-f)'),
 ('carrier',    9764,  9847, 'The physical carrier, charge conjugation, annihilation, the map (Part VIII-a, VIII-b)'),
 ('violation',  9913,  9931, 'Mathematical violation forces physical discard (Part VIII-c)'),
 ('bound',     10023, 10053, 'The certified bound, the detection gap, the signal floor (Part VIII-e)'),
 ('physcap',   10086, 10132, 'The physico-formal capstone and no third position on the carrier (Part VIII-e)'),
 ('exit',      10215, 10232, 'The one exit is a second register (Part VIII-h)'),
 ('apparatus', 10358, 10404, 'The apparatus cargo: the event and Stage 1 (Part VIII-b)'),
 ('arch',      10835, 10908, 'The bound chain and the discrete recursion (Part IX)'),
 ('pins',      11577, 11595, 'The pinned cones of Part X'),
]

fmt0 = LatexFormatter(style=HouseStyle)
pathlib.Path('snips/pygstyle.tex').write_text(fmt0.get_style_defs(), encoding='utf-8')
meta = []
for name, a, b, title in EXCERPTS:
    code = '\n'.join(SRC[a-1:b])
    fmt = LatexFormatter(style=HouseStyle, linenos=True, linenostart=a, envname='Verbatim',
                         verboptions=r'breaklines,breaksymbolleft={},breakindent=1.2em,breakafter={_.},breakaftersymbolpre={},breakaftersymbolpost={},fontsize=\leancodesize,numbersep=4pt,xleftmargin=1.9em,baselinestretch=1.0')
    if name=='pins':
        fmt = LatexFormatter(style=HouseStyle, linenos=True, linenostart=a, envname='Verbatim', verboptions=r'breaklines,breakanywhere,breaksymbolleft={},breakanywheresymbolpre={},breakindent=1.2em,fontsize=\leancodesize,numbersep=4pt,xleftmargin=1.9em,baselinestretch=1.0')
    out = highlight(code, Lean4Lexer(), fmt)
    pathlib.Path(f'snips/{name}.tex').write_text(out, encoding='utf-8')
    meta.append((name, a, b, title, b-a+1))
    print(f'{name:10s} {a:>6}-{b:<6} {b-a+1:>4} lines  {title}')
pathlib.Path('snips/meta.txt').write_text('\n'.join(f'{m[0]}\t{m[1]}\t{m[2]}\t{m[3]}' for m in meta))
