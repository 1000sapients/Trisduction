# -*- coding: utf-8 -*-
"""Extract Lean excerpts from the master file and render them with pygments to LaTeX
(fancyvrb/fvextra Verbatim) with line numbers equal to the master file's own line numbers."""
import re, pathlib
from pygments import highlight
from pygments.lexers import Lean4Lexer
from pygments.formatters import LatexFormatter
from pygments.style import Style
from pygments.token import Keyword, Name, Comment, String, Number, Operator, Punctuation, Text, Generic

SRC = pathlib.Path('../v3012.lean').read_text(encoding='utf-8').splitlines()

class HouseStyle(Style):
    default_style = ''
    styles = {
        Text: '#171717', Punctuation: '#171717', Operator: '#171717',
        Keyword: 'bold #8A5523', Keyword.Type: '#1F3A66',
        Name: '#171717', Name.Function: '#171717', Name.Class: '#1F3A66', Name.Builtin: '#171717',
        Name.Decorator: '#8A5523', Name.Constant: '#171717', Name.Variable: '#171717',
        Comment: 'italic #6f6f6f', Comment.Multiline: 'italic #6f6f6f', Comment.Single: 'italic #6f6f6f',
        String: '#1F5C3D', String.Doc: 'italic #6f6f6f', Number: '#171717', Generic: '#171717',
    }

EXCERPTS = [
 ('defs', 11016, 11081, 'The complex chart: the translation dictionary and the definitions of Part X'),
 ('reading', 11131, 11149, 'The reading and the identification'),
 ('record', 11151, 11208, 'The record, the act, the transport measure, the cargo'),
 ('fixedpoint', 11210, 11237, 'Set-level idempotence and the fixed-point characterization (X-a)'),
 ('fiber', 11264, 11356, 'Fiber invariance and the barred refuter (X-c)'),
 ('toe0', 101, 141, 'The self-grounding root (Part I)'),
 ('faces', 11239, 11262, 'Analytic faces (X-b)'),
 ('loop', 11358, 11438, 'The self-grounding recursion and the five-way loop (X-d)'),
 ('binding', 11439, 11474, 'The eleven-part binding and the transfer status (X-d)'),
 ('strip', 11476, 11546, 'Strip equivalence and functional-equation closure (X-e)'),
 ('orbit', 11547, 11620, 'Retraction injectivity and orbit collapse (X-f)'),
 ('chart', 11621, 11652, 'The discrete-to-complex chart homomorphism (X-g)'),
 ('schwarz', 11653, 11768, 'Schwarz reflection for zeta and its two auxiliaries (X-h)'),
 ('nonvanish', 11770, 11846, 'Non-vanishing at the negative odd integers; the zeros avoid the nonpositive integers (X-h)'),
 ('zclosed', 11848, 11924, 'The zeros closed under s to 1-s, conjugation and the fold; the orbit collapse at the zeros; strip confinement (X-h)'),
 ('socket', 12092, 12164, 'The pins of X-h, the socket at the zeros, and Part VIII\'s carrier in the plane (X-h, X-i)'),
 ('cone', 12166, 12224, 'The cone over the four readings of the bit (X-k)'),
 ('arch', 10826, 10909, 'The bound chain and the discrete recursion (Part IX)'),
 ('arrows', 9420, 9457, 'The capstone in both forms (§VII-e)'),
 ('keyed', 9484, 9521, 'No third position; the reading and the bridge are keyed; the bound alone decides nothing (§VII-e, §VII-f)'),
 ('carrier', 9686, 9776, 'The physical carrier, charge conjugation, annihilation, the map (§VIII-a, §VIII-b)'),
 ('violation', 9836, 9857, 'Mathematical violation forces physical discard (§VIII-c)'),
 ('bound', 9948, 9982, 'The certified bound, the detection gap, the signal floor (§VIII-e)'),
 ('physcap', 10015, 10056, 'The physico-formal capstone and no third position on the carrier (§VIII-e)'),
 ('exit', 10144, 10161, 'The one exit is a second register (§VIII-h)'),
 ('apparatus', 10354, 10405, 'The apparatus cargo: the event and Stage 1 (Part VIII-b)'),
 ('binder', 10163, 10199, 'The physical binder: the physico-formal closure, bound (§VIII-g)'),
 ('capstone', 12269, 12346, 'The master closure (Part XI)'),
 ('extensions', 12348, 12412, 'The complex extensions and the twin binder, bound (Part XI)'),
 ('pins', 11928, 11941, 'The head of Part X\'s pin block, the pin of rh_from_the_cargo_loop standing in Listing~8'),
]

fmt0 = LatexFormatter(style=HouseStyle)
pathlib.Path('snips/pygstyle.tex').write_text(fmt0.get_style_defs(), encoding='utf-8')
meta = []
for name, a, b, title in EXCERPTS:
    code = '\n'.join(SRC[a-1:b])
    fmt = LatexFormatter(style=HouseStyle, linenos=True, linenostart=a, envname='Verbatim',
                         verboptions=r'breaklines,breaksymbolleft={},breakindent=1.2em,breakafter={_.},breakaftersymbolpre={},breakaftersymbolpost={},fontsize=\leancodesize,numbersep=4pt,xleftmargin=1.9em,baselinestretch=1.0')
    if name=='pins':
        fmt = LatexFormatter(style=HouseStyle, linenos=True, linenostart=a, envname='Verbatim', verboptions=r'breaklines,breakanywhere,breaksymbolleft={},breakanywheresymbolpre={},breakindent=1.2em,fontsize=\leancodesize,numbersep=4pt,xleftmargin=1.9em,baselinestretch=1.0')
    out = highlight(code, Lean4Lexer(), fmt)
    pathlib.Path(f'snips/{name}.tex').write_text(out, encoding='utf-8')
    meta.append((name, a, b, title, b-a+1))
    print(f'{name:10s} {a:>6}-{b:<6} {b-a+1:>4} lines  {title}')
pathlib.Path('snips/meta.txt').write_text('\n'.join(f'{m[0]}\t{m[1]}\t{m[2]}\t{m[3]}' for m in meta))
