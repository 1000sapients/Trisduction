# The Poincaré Precedent and the Stronger Case: Why All Seven Qualify · v1.0.0_CC · 24 October 2026

A companion note to the Millennium synthesis (Synthesis v1.0.0_CC). Draft. Nothing here is pushed or published;
seating, indexing and pushing are the Architect's acts under the confirmation gate.

**The note.** Math Journal, two columns, 12 pages: the note in 8, with three figures and three tables, and Appendix A,
the mini case printed whole. Two domains, the kernel and the record; the seven bits on one footing in the kernel;
Perelman's derivation as the record took it and as the kernel types it, one inhabitant strictly inside the bit; the
precedent stated exactly; the stronger case on four counts (minimal premise, delivered twice, checked by the kernel,
armed); the precedent as a rule and not a value; the other road; three falsifiers; positioning; conclusion.

**The mini case.** `Poincare_Precedent_v1_0_0_CC.lean`: core Lean 4.19.0, no import, no axiom declared, no `sorry`, no
`native_decide`; 21 theorems, every cone empty and pinned by `#guard_msgs`; compiles silent in under a second. Every
step of the note maps to one of its theorems and to the master theorem that proves it at full scale (the note's
Table 2).

| Path | What |
|---|---|
| `paper/Poincare_Precedent_v1_0_0_CC.pdf` | the note, Math Journal edition |
| `paper/Poincare_Precedent_v1_0_0_CC.md` | its Markdown master; carries the mini case and its manifest in a machine-readable block at its foot (the one-line `awk` extraction in the block's header rebuilds the file) |
| `paper/figs/` | the three figures, SVG with subset fonts embedded, PDF and PNG |
| `lean/Poincare_Precedent_v1_0_0_CC.lean` | the mini case |
| `lean/BUILD_RECEIPT.txt` | toolchain, SHA-256, counts, the silent compile |
| `tools/` | the Markdown builder and the figure builder (they read the synthesis tools in place: `build_pdf.py`, `mj_template.tex`, `synthfigs.py`) |
| `MANIFEST.sha256` | SHA-256 of every file in this folder |

**Verify.** `sha256sum -c MANIFEST.sha256`, then `lean lean/Poincare_Precedent_v1_0_0_CC.lean` (exit 0, no message).

**Receipts, this build.** Mini case: exit 0, silent, 0.43 s, 21 theorems on no axiom, 21 pins; a drifted pin fails the
compile. Fresh extract from the Markdown master: byte-identical, compiles silent. Paper: 12 pages; render probe end,
conclusion and references present, no missing glyph, no overfull box, no bleed, no ink outside the text block; 55
distinct theorem names, every one a declaration of the master's tree or of the mini case, every theorem among them
with a pinned cone. Master census cited: 2,967 theorems, 2,778 pins, 19 of 19 certificates passing.
