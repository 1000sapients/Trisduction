#!/usr/bin/env python3
"""precfigs.py · the three figures of The Poincaré Precedent and the Stronger Case, edition 1.0.0_CC.

Usage: precfigs.py [n ...]
Built on the synthesis figure builder (synthfigs.py and its primitives, read in place, never copied): Figures 1 and 3
are the synthesis's two-domain and seven-key figures under this note's numbering; Figure 2, the crossing typed, is new.
Every monospace identifier is resolved against index_PREC.json, the index of the Millennium Grand Master tree with the
mini case's declarations added, and colored by its pinned cone; an unresolved name or a theorem without a pinned cone
halts the build. Then each SVG is printed to PDF and PNG by Chromium."""
import json, os, string, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SYNTHFIGS = os.path.abspath(os.path.join(HERE, "..", "..", "synth", "figs", "synthfigs.py"))
FIGTAIL = os.path.join(os.path.dirname(SYNTHFIGS), "figtail_ref.py")

g = {"__file__": SYNTHFIGS, "__name__": "synthfigs_lib"}
exec(open(SYNTHFIGS, encoding="utf-8").read().split("\nFIGS = [")[0], g)
exec(open(FIGTAIL, encoding="utf-8").read().split("FIGS = [")[0], g)
g.update(ROW="PREC", IDX=json.load(open(os.path.join(HERE, "index_PREC.json"), encoding="utf-8")),
         OUTDIR=os.path.join(HERE, "out"),
         CFG=dict(ns="PoincarePrecedent", record_ns="MillenniumGrandMaster", binding_ns="PerelmanHunt",
                  header_right="POINCARÉ PRECEDENT · v1.0.0_CC", short="The Poincaré Precedent",
                  stem="Poincare_Precedent"),
         NEW_NS="PoincarePrecedent.", REC_NS="MillenniumGrandMaster.", BIND_NS="PerelmanHunt.")

FIG2 = r'''
def figCrossing(y):
    y += section_title(y, "PERELMAN'S ROUTE, TYPED IN THE KERNEL: ONE INHABITANT STRICTLY INSIDE THE BIT") + 8
    lw = 600
    xr = M + lw + 18
    rw = CW - lw - 18
    items = [("A witness gives the act", ["PCClose.witness_gives_act", "a_witness_gives_the_act"]),
             ("The act holds where no witness exists", ["PCClose.act_without_witness", "no_witness_on_the_soliton"]),
             ("Every witness is a crossing, and the crossing is wider", ["PCClose.crossing_types_the_crossing",
              "the_witness_is_strictly_inside_the_act"]),
             ("Perelman's route is strictly stronger than the sentence",
              ["PC.HOST.faithful_route_strictly_stronger", "the_witness_route_is_strictly_stronger"]),
             ("The bit is the minimal premise", ["MillenniumGrandMaster.the_bit_is_the_minimal_premise",
              "the_bit_is_minimal"]),
             ("Every route to the sentence passes the bit", ["MillenniumGrandMaster.seven_routes_pass_the_bit",
              "the_witness_route_passes_the_bit"])]
    # right panel: what the kernel proves, the master's theorem first and the mini case's second
    rect(xr, y, rw, 30, NAVY, rx=7)
    text(xr + 14, y + 20, "WHAT THE KERNEL PROVES · MASTER, THEN MINI CASE", "s", 700, 11, GOLD, ls="0.5")
    cy = y + 38
    for t, ids in items:
        b = card(rw, t, None, ids, NAVY2, tsize=11.6, isize=10.6, ilh=14.2)
        b.draw(xr, cy)
        cy += b.h + 7
    bottom = cy - 7
    lh = bottom - y
    # left panel: three nested regions
    x0, y0 = M, y
    rect(x0, y0, lw, lh, B_T, B, 1.6, rx=14)
    text(x0 + 18, y0 + 25, "THE BIT · THE ACT, EXACTLY THE SENTENCE", "s", 700, 12.6, B_D, ls="0.5")
    for k, l in enumerate(wrap("the minimal premise: necessary and sufficient, and every route to the sentence passes it",
                               lw - 36, "s", 400, 11.4)):
        text(x0 + 18, y0 + 44 + k * 15, l, "s", 400, 11.4, BODY)
    x1, y1 = x0 + 24, y0 + 72
    w1, h1 = lw - 48, lh - 96
    rect(x1, y1, w1, h1, T_T, T, 1.4, rx=12)
    text(x1 + 16, y1 + 24, "A CROSSING", "s", 700, 12.2, T_D, ls="0.5")
    cl = wrap("a functional never rising along the step, level off the seat only where the step lands on it",
              w1 - 32, "s", 400, 11.2)
    for k, l in enumerate(cl):
        text(x1 + 16, y1 + 42 + k * 14.5, l, "s", 400, 11.2, BODY)
    x2, y2 = x1 + 20, y1 + 54 + len(cl) * 14.5
    w2, h2 = 360, y1 + h1 - 20 - y2
    rect(x2, y2, w2, h2, V_T, V, 1.4, rx=10)
    tl = wrap("A WITNESS · THE 2002 FUNCTIONAL'S SHAPE", w2 - 28, "s", 700, 11.4)
    for k, l in enumerate(tl):
        text(x2 + 14, y2 + 23 + k * 16, l, "s", 700, 11.4, V_D, ls="0.4")
    wy = y2 + 23 + len(tl) * 16
    wl = wrap("strictly decreasing along the step at every state off the seat, and invariant under the rescaling",
              w2 - 28, "s", 400, 11.2)
    for k, l in enumerate(wl):
        text(x2 + 14, wy + 4 + k * 14.5, l, "s", 400, 11.2, BODY)
    py = wy + 4 + len(wl) * 14.5 + 10
    pill(x2 + w2 / 2, py, "PERELMAN'S DERIVATION", V, WHITE, size=10.2, h=21)
    al = wrap("one inhabitant of the bit, accepted as unconditional on 18\u00a0March\u00a02010",
              w2 - 28, "s", 400, 11.2)
    for k, l in enumerate(al):
        text(x2 + w2 / 2, py + 40 + k * 14.5, l, "s", 400, 11.2, V_D, "middle")
    ry = py + 40 + len(al) * 14.5 + 16
    line(x2 + 40, ry - 10, x2 + w2 - 40, ry - 10, V_2, 1)
    rl = wrap("the route needs, beside the functional, the κ-solutions, the canonical neighbourhoods, surgery and "
              "finite extinction: it carries more than the sentence", w2 - 36, "s", 400, 10.8)
    for k, l in enumerate(rl):
        text(x2 + w2 / 2, ry + 8 + k * 14, l, "s", 400, 10.8, GREY, "middle")
    # the self-similar flow: inside the act, inside the crossing, outside the witness
    sx0 = x2 + w2
    sx1 = x1 + w1
    cx = (sx0 + sx1) / 2
    cyp = y2 + h2 / 2 - 18
    circle(cx, cyp, 8, NAVY, WHITE, 2)
    sl = wrap("the self-similar flow", sx1 - sx0 - 24, "s", 700, 11.4)
    for k, l in enumerate(sl):
        text(cx, cyp + 28 + k * 15, l, "s", 700, 11.4, INK, "middle")
    ul = wrap("the act holds, a crossing exists, no witness exists", sx1 - sx0 - 26, "s", 400, 11.0)
    for k, l in enumerate(ul):
        text(cx, cyp + 30 + len(sl) * 15 + k * 14, l, "s", 400, 11.0, BODY, "middle")
    y = bottom + 10
    y += idband(y, "THE RECORD ACCEPTED THE INHABITANT; THE KERNEL PUTS THE INHABITANT INSIDE THE BIT",
                ["MillenniumGrandMaster.the_witness_is_a_strict_subtype",
                 "MillenniumGrandMaster.the_offering_is_strictly_inside_the_bit",
                 "MillenniumGrandMaster.the_poincare_precedent", "the_stronger_case_in_miniature"],
                color=V_D, body="Whatever yields the sentence yields the bit, so to accept Perelman's derivation as "
                                "resolving the question was to accept a delivery of the Poincaré bit. The bit stood at "
                                "premise grade in Lean before the award and stands there after it.") + 6
    return y
'''
exec(FIG2, g)

g["FIGS"] = [(1, "TWO DOMAINS AND THE POINCARÉ PRECEDENT", g["fig6"]),
             (2, "THE CROSSING, TYPED: PERELMAN'S ROUTE STRICTLY INSIDE THE BIT", g["figCrossing"]),
             (3, "SEVEN BITS, SEVEN KEYS: THE PRECEDENT TRAVELS AS A RULE", g["fig7"])]

BUILD = r'''
os.makedirs(OUTDIR, exist_ok=True)
allchecked = {}
for num, title, body in FIGS:
    if ONLY and num not in ONLY:
        continue
    E.clear(); USED.clear(); CHECKED.clear()
    E.append("BG")
    y = fig_header(num, title) + 12
    y = body(y) + 12
    y += legend(y) + 12
    H = int(round(y))
    E[0] = f'<rect x="0" y="0" width="{W}" height="{H}" fill="{BG}"/>'
    faces = [font_face(("s", 400), "RowSans", 400), font_face(("s", 700), "RowSans", 700),
             font_face(("m", 400), "RowMono", 400), font_face(("m", 700), "RowMono", 700)]
    defs = ('<defs>'
            f'<marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
            f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{ARROW}"/></marker>'
            f'<style>{"".join(faces)}</style></defs>')
    ttl = f"{CFG['short']} · Figure {num} · {string.capwords(title.lower())}"
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" '
           f'aria-label="{escape(ttl)}">\n<title>{escape(ttl)}</title>\n{defs}\n' + "\n".join(E) + "\n</svg>\n")
    fn = f"{OUTDIR}/{CFG['stem']}_Figure_{num}_v1_0_0_CC.svg"
    open(fn, "w", encoding="utf-8").write(svg)
    allchecked.update(CHECKED)
    SIZES[num] = (W, H)
    print(f"[PREC] Figure {num}: {W}x{H}, {len(CHECKED)} names checked")
json.dump({k: list(v) for k, v in allchecked.items()}, open(f"{OUTDIR}/checked_ids.json", "w"), indent=0,
          ensure_ascii=False)
'''
g["ONLY"] = {int(a) for a in sys.argv[1:]} or None
g["SIZES"] = {}
g["string"] = string
exec(BUILD, g)

# print each SVG to PDF and PNG with Chromium
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    br = p.chromium.launch()
    for num, (w, h) in g["SIZES"].items():
        stem = os.path.join(g["OUTDIR"], f"Poincare_Precedent_Figure_{num}_v1_0_0_CC")
        svg = open(stem + ".svg", encoding="utf-8").read()
        html = ("<!doctype html><html><head><style>@page{margin:0}html,body{margin:0;padding:0}"
                "svg{display:block}</style></head><body>" + svg + "</body></html>")
        pg = br.new_page(viewport={"width": w, "height": h}, device_scale_factor=1.5)
        pg.set_content(html)
        pg.wait_for_timeout(150)
        pg.screenshot(path=stem + ".png", full_page=False)
        pg.pdf(path=stem + ".pdf", width=f"{w}px", height=f"{h}px", print_background=True,
               margin={"top": "0", "right": "0", "bottom": "0", "left": "0"})
        pg.close()
    br.close()
print("[PREC] PDF and PNG printed for", sorted(g["SIZES"]))
