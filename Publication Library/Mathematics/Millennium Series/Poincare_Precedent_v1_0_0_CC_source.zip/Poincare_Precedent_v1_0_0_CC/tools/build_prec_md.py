#!/usr/bin/env python3
"""build_prec_md.py · the Markdown master of The Poincaré Precedent and the Stronger Case, edition 1.0.0_CC.

Assembles src/*.md in order; replaces [[FIG:n]] by the full-width figure, halting on a figure missing, doubled or out
of order; fills the receipts (the mini case's SHA-256 from its bytes, the master's theorem and pin totals from its
certified census); halts on any unfilled placeholder; and appends the mini case as the machine-readable carrier."""
import glob, hashlib, json, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
SP = os.path.dirname(HERE)
MD = "Poincare_Precedent_v1_0_0_CC.md"
LEAN = os.path.join(HERE, "Poincare_Precedent_v1_0_0_CC.lean")
CENSUS = os.path.join(SP, "master", "cert", "census.json")

CAP = {
    1: "Two domains and the Poincaré precedent. In the kernel every row's form is proved and every row's bit is a "
       "premise, the Poincaré bit included. In the record the Clay Institute accepted Perelman's derivation as "
       "unconditional; the six other bits stand delivered twice and qualify for the same standing. With the bit "
       "adopted, every row's sentence is a theorem.",
    2: "The crossing, typed. Frames carrying a witness of the 2002 functional's shape lie strictly inside frames "
       "carrying a crossing, which lie strictly inside frames where the act holds; the act is exactly the sentence, "
       "the minimal premise. The self-similar flow rests, with a crossing and no witness. Right: each step in the "
       "master and in the mini case.",
    3: "Seven bits, seven keys. The 128 patterns of the seven values, each realized on the product of the rows' own "
       "frames, read RH, P~≠~NP, NS, YM, Hodge, BSD, Poincaré from left to right. The Poincaré value settles no other "
       "row: the precedent travels as a rule, never as a value.",
}


def fig(m):
    n = int(m.group(1))
    return ("```{=latex}\n\\begin{figure*}[tp]\n\\centering\n"
            "\\includegraphics[width=\\textwidth]{figs/Poincare_Precedent_Figure_%d_v1_0_0_CC.pdf}\\\\[5pt]\n"
            "\\begin{minipage}{\\textwidth}\\footnotesize{\\color{deep}\\textbf{Figure %d}}\\ \\textbar\\ %s\\end{minipage}\n"
            "\\end{figure*}\n```" % (n, n, CAP[n]))


body = "\n".join(open(p, encoding="utf-8").read().rstrip("\n") + "\n"
                 for p in sorted(glob.glob(os.path.join(HERE, "src", "*.md"))))
figs = [int(x) for x in re.findall(r"\[\[FIG:(\d)\]\]", body)]
if figs != [1, 2, 3]:
    raise SystemExit(f"figures: {figs}")
body = re.sub(r"\[\[FIG:(\d)\]\]", fig, body)
# no line ends between a label and its number, inside "Lean 4", or inside "P ≠ NP" (prose only: code, raw LaTeX and
# the front matter are left as written)
NB = "\u00a0"


def tie(seg):
    seg = re.sub(r"\b(Figure|Table|Section|Appendix|Parts?) (?=[0-9A-Z])", lambda m: m.group(1) + NB, seg)
    return seg.replace("Lean 4", "Lean" + NB + "4").replace("P ≠ NP", "P" + NB + "≠" + NB + "NP")


fm_end = body.index("\n---\n", 4) + 5
pieces = re.split(r"(```.*?```|`[^`\n]*`)", body[fm_end:], flags=re.S)
body = body[:fm_end] + "".join(x if x.startswith("`") else tie(x) for x in pieces)
# a section heading never ends a column: keep five lines of room below every heading
body = re.sub(r"^## ", lambda m: "\\needspace{5\\baselineskip}\n\n## ", body, flags=re.M)

raw = open(LEAN, "rb").read()
h = hashlib.sha256(raw).hexdigest()
census = json.load(open(CENSUS, encoding="utf-8"))
if not census.get("all_pass"):
    raise SystemExit("census: the master's certificates do not all pass")
body = (body.replace("@SHAFULL@", h).replace("@THM@", "{:,}".format(census["total_theorems"]))
            .replace("@PIN@", "{:,}".format(census["total_pins"])))
left = re.findall(r"@[A-Z]+@", body)
if left:
    raise SystemExit(f"unfilled: {left}")

text = raw.decode("utf-8")
if "\n~~~~~" in text or "-->" in text:
    raise SystemExit("unsafe carried file")
nthm = len(re.findall(r"^theorem\s", text, re.M))
npin = len(re.findall(r"^#guard_msgs\s+in\s+#print\s+axioms\s", text, re.M))
if nthm != npin:
    raise SystemExit(f"theorems {nthm} != pins {npin}")
blk = ["<!--", "MACHINE-READABLE MINI CASE AND MANIFEST (not rendered). Extract with:",
       "awk '{sub(/\\r$/,\"\")} /^~~~~~[a-z0-9]+ file=[A-Za-z0-9_.]+$/{sub(/.*file=/,\"\");f=$0;next} "
       "/^~~~~~$/{if(f!=\"\"){close(f);f=\"\"};next} f!=\"\"{print > f}' " + MD,
       "", "~~~~~sha256 file=MANIFEST.sha256", "%s  Poincare_Precedent_v1_0_0_CC.lean" % h, "~~~~~", "",
       "~~~~~lean file=Poincare_Precedent_v1_0_0_CC.lean", text.rstrip("\n"), "~~~~~", "", "-->"]
out = body.rstrip("\n") + "\n\n" + "\n".join(blk) + "\n"
os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
open(os.path.join(HERE, "out", MD), "w", encoding="utf-8").write(out)
words = len(re.sub(r"```.*?```", "", re.split(r"## Appendix\sA", body)[0], flags=re.S).split())
print(f"{MD}: body {words} words · figures {figs} · mini case {nthm} theorems, {npin} pins, sha256 {h[:16]} · "
      f"master census {census['total_theorems']} theorems, {census['total_pins']} pins")
