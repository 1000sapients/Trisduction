ROUND 2 PROSECUTION · registers parameter, provenance · copy read: seeded_r2.md · declared targets: none outstanding; full sweep of citations and parameters

P2-a (Section 3): the search bound "3q <= n" against findSplit_sound, 2q <= n. Minimal falsifier: read the theorem.
P2-b (Section 12): "the mirror returns a split"; the search returns it, and the mirror carries splits to splits. Drift. Minimal falsifier: read check_means.
P2-c (Section 15): "computed in the kernel" to 4 x 10^18; the kernel computes to 2000 and carries the certified region as a field. Widened. Minimal falsifier: read Section 12.

Provenance, each citation against the clause it carries: Oliveira e Silva, Herzog and Pardi 2014, the even statement verified to 4 x 10^18; Helfgott 2013, every odd number greater than 5 a sum of three primes; Chen 1973, every sufficiently large even number a prime plus a product of at most two primes; Hardy and Littlewood 1923, the expected number of splits, typed not used; the series papers by DOI. Parameter census: the heights 2000 and 4 x 10^18 are a computed bound and a cited bound, neither fitted. No finding.

H-1 (provenance, target C5): a computation by decide is not a proof. Minimal falsifier: what does the kernel check?
