ROUND 3 PROSECUTION · registers limit, symmetry · copy read: seeded_r3.md · declared targets: none outstanding; full re-sweep

P3-a (Section 13): "three halves" against row_split, two. Minimal falsifier: read the theorem.
P3-b (Section 5): "the kernel's citation" decides 4 to 2000; it is the kernel's computation. Drift. Minimal falsifier: read executed_to_2000.
P3-c (Section 17): F-Region said to refute "the act and the whole closure"; it refutes the executed check or the certificate. Widened. Minimal falsifier: read Section 17's own grading.

Symmetry: the mirror is an involution on [0, n] with its one fixed point the seat for even n; splits come in mirror pairs. Limit: below 2000 by computation, below the certified height by the carried field, above it on the act; the certificate does not reach above its height; the remainder is not forced; no finite record forces the value. No real finding.

H-2 (limit, target C6): with the certified region at 4 x 10^18 the remainder is negligible. Minimal falsifier: does any finite height force the value?
