#!/usr/bin/env python3
"""seed_controls.py v2 - calibration controls for the Trisduction Audit Cycle.

Three or more planted defects per round, committed by hash BEFORE the
prosecuting pass runs, revealed only after the round closes. The commitment
proves the control set was fixed in advance and not fitted to whatever the
auditor happened to find.

Two grades, kept mechanically apart:
  EXTERNAL  the architect authored the defects off-transcript and supplies
            them as a JSON file at commit. Witness-independent. Load-bearing.
            Requires --file; generated controls may not wear this grade.
  SELF      this script generated them in-session. The commitment forecloses
            post-hoc fitting; it does NOT foreclose in-context leakage, since
            one substrate holds both seats and the sealed file is readable
            on disk. Engineering grade, aperture named at every reveal.

All commands run from the cycle's working directory; files live under
./audit_<cycle>/.

Usage:
  seed_controls.py plan   --round N --cycle NAME [--seed S] [--sections K]
  seed_controls.py commit --round N --cycle NAME [--grade SELF]
  seed_controls.py commit --round N --cycle NAME --grade EXTERNAL --file F.json
  seed_controls.py reveal --round N --cycle NAME --caught "C1,C3"

External file format: JSON list of >= 3 objects, each with unique "id",
plus "kind" and "spec"; "section" optional.
"""
import argparse, hashlib, json, os, random, sys

KINDS = [
    ("ARITH", "one numeric result altered so it no longer follows from the "
              "inputs printed beside it; magnitude changed, not a typo"),
    ("DRIFT", "one defined term used in a second, incompatible sense in a "
              "later section, with no redefinition announced"),
    ("SCOPE", "one claim's warrant tier or quantifier silently widened, "
              "premise read as theorem or a scoped result stated universally"),
]


def cdir(cycle):
    d = os.path.join(".", f"audit_{cycle}")
    os.makedirs(d, exist_ok=True)
    return d


def build(rnd, cycle, seed, sections):
    if sections < 1:
        print("FAULT: --sections must be >= 1."); sys.exit(2)
    rg = random.Random(f"{cycle}|{rnd}|{seed}")
    k = min(3, sections)
    picks = rg.sample(range(1, sections + 1), k=k)
    return [{"id": f"C{i+1}", "kind": kk, "spec": ss,
             "section": picks[i % k]}
            for i, (kk, ss) in enumerate(KINDS)]


def load_external(path):
    try:
        data = json.load(open(path, encoding="utf-8"))
    except Exception as e:
        print(f"FAULT: cannot read external control file: {e}"); sys.exit(2)
    if not (isinstance(data, list) and len(data) >= 3):
        print("FAULT: external control file must be a JSON list of >= 3 "
              "controls."); sys.exit(2)
    ids = set()
    for c in data:
        if not (isinstance(c, dict) and all(k in c for k in
                                            ("id", "kind", "spec"))):
            print("FAULT: each control needs id, kind, spec."); sys.exit(2)
        if c["id"] in ids:
            print(f"FAULT: duplicate control id {c['id']}."); sys.exit(2)
        ids.add(c["id"])
    return data


def digest(controls, cycle, rnd):
    blob = json.dumps({"cycle": cycle, "round": rnd, "controls": controls},
                      sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("cmd", choices=["plan", "commit", "reveal"])
    p.add_argument("--round", type=int, required=True)
    p.add_argument("--cycle", required=True)
    p.add_argument("--seed", default="20260622")
    p.add_argument("--sections", type=int, default=12)
    p.add_argument("--caught", default="")
    p.add_argument("--grade", choices=["EXTERNAL", "SELF"], default="SELF")
    p.add_argument("--file", default="")
    a = p.parse_args(argv)

    d = cdir(a.cycle)
    sealed = os.path.join(d, f"controls_r{a.round}.sealed.json")
    commit = os.path.join(d, f"controls_r{a.round}.commit.txt")

    if a.cmd == "plan":
        for c in build(a.round, a.cycle, a.seed, a.sections):
            print(f"{c['id']} {c['kind']} section~{c['section']}: {c['spec']}")
        print("WARNING: if this listing is visible inside the audit session, "
              "the round is pre-contaminated. Plan off-transcript; this "
              "command exists for EXTERNAL-grade preparation.")
        return 0

    if a.cmd == "commit":
        if os.path.exists(sealed):
            print(f"FAULT: {sealed} exists. Controls are committed once per "
                  f"round and never re-rolled."); return 2
        if a.grade == "EXTERNAL":
            if not a.file:
                print("FAULT: EXTERNAL grade requires --file with the "
                      "architect-authored control set. In-session generated "
                      "controls may not wear the EXTERNAL grade; that is "
                      "laundering, and the grade would be void."); return 2
            controls = load_external(a.file)
        else:
            if a.file:
                print("FAULT: SELF grade with --file is ambiguous. Omit "
                      "--file, or claim EXTERNAL if the file was authored "
                      "off-transcript."); return 2
            controls = build(a.round, a.cycle, a.seed, a.sections)
        dg = digest(controls, a.cycle, a.round)
        with open(sealed, "w", encoding="utf-8") as f:
            json.dump({"cycle": a.cycle, "round": a.round, "grade": a.grade,
                       "controls": controls, "digest": dg}, f, indent=2)
        with open(commit, "w", encoding="utf-8") as f:
            f.write(dg + "\n")
        print(f"COMMITTED round {a.round} grade {a.grade} "
              f"digest {dg[:16]} controls {len(controls)}")
        if a.grade == "SELF":
            print("SELF grade: the sealed file is readable in-session. The "
                  "commitment forecloses post-hoc fitting only; the "
                  "single-substrate aperture stays open and is stamped into "
                  "any seal this cycle earns.")
        else:
            print("EXTERNAL grade: sealed from the supplied file. Keep its "
                  "authoring off-transcript until reveal.")
        print("Display the digest, never the sealed file, until the round "
              "closes.")
        return 0

    if not os.path.exists(sealed):
        print("FAULT: no committed control set for this round. A round with "
              "no committed controls is VOID-UNCALIBRATED."); return 2
    rec = json.load(open(sealed, encoding="utf-8"))
    if digest(rec["controls"], a.cycle, a.round) != rec["digest"]:
        print("FAULT: control set does not match its commitment. Round VOID.")
        return 3
    caught = {c.strip().upper() for c in a.caught.split(",") if c.strip()}
    ids = [c["id"] for c in rec["controls"]]
    hit = [i for i in ids if i.upper() in caught]
    print(f"REVEAL round {a.round} grade {rec['grade']} "
          f"digest {rec['digest'][:16]} verified")
    for c in rec["controls"]:
        mark = "CAUGHT " if c["id"].upper() in caught else "MISSED "
        print(f"  {mark}{c['id']} {c['kind']} "
              f"section~{c.get('section', '-')}")
    print(f"detection {len(hit)}/{len(ids)}")
    if rec["grade"] == "SELF":
        print("aperture: SELF-grade controls; detection proves power against "
              "post-hoc fitting, not against in-context leakage.")
    if len(hit) < len(ids):
        print("ROUND UNDERPOWERED: findings are retained, no SEALED-ROUND "
              "may issue from this round.")
    return 0


if __name__ == "__main__":
    sys.exit(main())