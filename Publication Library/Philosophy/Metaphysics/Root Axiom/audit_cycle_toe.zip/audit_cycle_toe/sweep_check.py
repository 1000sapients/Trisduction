#!/usr/bin/env python3
"""sweep_check.py v1 - phrase-level propagation sweep for the Trisduction
Audit Cycle.

The recorded dominant failure mode across live series is a repair that lands
at the governing section and dies before the abstract, the summary boxes,
the Conclusion, the Limitations, the ledger rows, the appendices. This tool
makes the sweep mechanical: counts are printed, never asserted, and the exit
code is the verdict. It proves phrase absence, never semantic absence; the
REMOVED-versus-REWORDED ruling stays the Arbiter's.

Usage:
  sweep_check.py count  --file F --phrase "..." [--ci]
      Print the occurrence count of one phrase.
  sweep_check.py verify --file F --spec spec.json [--ci] [--pre]
      spec.json: {"banned": ["...", ...], "required": ["...", ...]}
      Without --pre, the post-repair check: PASS requires every banned
      phrase at count 0 and every required phrase at count >= 1.
      With --pre, the pre-repair check, run against the unrepaired
      candidate: PASS requires every banned phrase at count >= 1, proving
      the spec's strings actually occur in the artifact; required phrases
      are ignored. A pre-count of zero means the spec was written from
      memory; re-derive the phrase from the artifact.

Counts are plain substring counts on the raw text; --ci lowercases both
sides. Exit 0 PASS, 1 FAIL, 2 FAULT.
"""
import argparse, json, sys


def read(path):
    try:
        return open(path, encoding="utf-8").read()
    except Exception as e:
        print(f"FAULT: cannot read {path}: {e}")
        sys.exit(2)


def count(text, phrase, ci):
    if ci:
        return text.lower().count(phrase.lower())
    return text.count(phrase)


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("cmd", choices=["count", "verify"])
    p.add_argument("--file", required=True)
    p.add_argument("--phrase", default="")
    p.add_argument("--spec", default="")
    p.add_argument("--ci", action="store_true")
    p.add_argument("--pre", action="store_true")
    a = p.parse_args(argv)
    text = read(a.file)

    if a.cmd == "count":
        if not a.phrase.strip():
            print("FAULT: --phrase is empty; an empty sweep counts nothing.")
            return 2
        print(f"{count(text, a.phrase, a.ci):>4}  {a.phrase}")
        return 0

    if not a.spec:
        print("FAULT: verify requires --spec with the sweep spec JSON.")
        return 2
    try:
        spec = json.load(open(a.spec, encoding="utf-8"))
    except Exception as e:
        print(f"FAULT: cannot read spec: {e}")
        return 2
    banned = [s for s in spec.get("banned", []) if str(s).strip()]
    required = [s for s in spec.get("required", []) if str(s).strip()]
    if not banned and not required:
        print("FAULT: spec carries no phrases; a sweep with no phrases "
              "verifies nothing.")
        return 2

    fail = False
    if a.pre:
        for ph in banned:
            c = count(text, ph, a.ci)
            ok = c >= 1
            fail = fail or not ok
            print(f"{'FOUND ' if ok else 'ABSENT'} banned   {c:>4}  {ph}")
        print("PRE-SWEEP " + ("PASS: every banned phrase occurs in the "
                              "pre-repair candidate; the spec targets real "
                              "strings." if not fail else
                              "FAIL: a banned phrase has pre-count 0; the "
                              "spec was written from memory. Re-derive the "
                              "phrase from the artifact."))
        return 1 if fail else 0

    for ph in banned:
        c = count(text, ph, a.ci)
        ok = c == 0
        fail = fail or not ok
        print(f"{'OK    ' if ok else 'LIVE  '} banned   {c:>4}  {ph}")
    for ph in required:
        c = count(text, ph, a.ci)
        ok = c >= 1
        fail = fail or not ok
        print(f"{'OK    ' if ok else 'ABSENT'} required {c:>4}  {ph}")
    print("SWEEP " + ("FAIL: a banned phrase is live or a required phrase "
                      "is absent; the repair has not propagated." if fail
                      else "PASS: banned at zero across the candidate, "
                           "required present."))
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())