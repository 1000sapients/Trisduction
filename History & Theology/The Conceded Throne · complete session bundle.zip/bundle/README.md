# THE CONCEDED THRONE · complete session bundle

Everything produced in this session, plus the two earlier works for reference.
Six distinct documents across three works. No two files share a hash.

## 1 · The Conceded Throne (new this session)

The Hebrew-Bible-alone volume. 102,038 words, 130 pages, 19 books, 166 chapters,
21 excursus, 15 appendices.

Measured corpus balance: **1,325 Hebrew Bible citations, 0 New Testament, 0 Qur'an.**
The eleven non-Hebrew references in the whole book sit inside the three regions
licensed to name what the scope law excludes: Chapter 5's exclusion list,
Appendix J's boundary statement, and Bibliography section VII.

    01 · The Conceded Throne · Journal Edition.pdf     130 pages
    02 · The Conceded Throne · Manuscript.md           102,038 words

## 2 · Census data and result

Book II executes the debt the seed article named at its own section 13 and capped
its strength on. No machine-readable Hebrew text was obtainable in the working
environment, so the census ran over the only complete machine-readable witness
available: the Companion Bible's KJV text layer, 35 files, Genesis to Malachi.

    878 raw rest-field sites
    114 terminal-position candidates
     23 machine-marked, hand-sorted to 11 genuine
      0 clauses with a royal figure as grammatical subject of giving rest

Eleven times a king stands at a terminus site; eleven times he is the recipient
with God named as giver in the same clause. The one apparent counterexample is
Bullinger's 1913 note on Psalm 101, not a verse.

The raw data is included so the sort can be re-run by hand and disagreed with at
a specific row.

## 3 · Tools

The build and verification pipeline. The verification suite is the honest place
to look first: it records what the instrument can and cannot check, and three of
its checks exist only because an earlier version passed something it should have
failed.

## 4 · Chapter sources

The 19 book files, the excursus, the appendices, and the front matter, before
assembly. Chapter numbers here are pre-renumbering for four of the books; the
renumber tool in folder 3 carries the map.

## 5 · The two earlier works

Not produced this session. Included so all three works sit together.

    History of the Messianic Position    112,948 words   140 pages   60/26/13 HB/NT/Q
    The Office of the Messiah             88,707 words   120 pages   48/8/42

## The scope finding that forced a fresh build

The earlier claim that Books I-III of *History of the Messianic Position* were
99% Hebrew was an instrument artifact: the citation regex had no pattern for
1 Enoch, 4Q521, or 11QMelchizedek, so it scored Second Temple chapters as clean.
Measured properly, Book I carries 6 non-Hebrew references, Book II carries 70,
Book III carries 66. There was never a Hebrew-only cut available.
