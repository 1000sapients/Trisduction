# BOOK III · THE TERMINUS

## CHAPTER 21 · Genesis 2:2 and the Seventh Position

The corpus opens with six days of making and a seventh of something else, and the something else is the position this book is about.

*Wa-yikhal ʾelohim ba-yom ha-shevi'i melaʾkto ʾasher ʿasah, wa-yishbot ba-yom ha-shevi'i mi-kol melaʾkto ʾasher ʿasah. Wa-yevarekh ʾelohim ʾet yom ha-shevi'i wa-yeqaddesh ʾoto, ki vo shavat mi-kol melaʾkto ʾasher baraʾ ʾelohim la-ʿasot.*

Four observations, each checkable against the text, and each bearing on everything downstream.

**The seventh day is not a seventh act of the same kind.** Days one through six each contain a divine speech, a making, and a naming or a blessing, and each closes with the formula *wa-yehi ʿerev wa-yehi voqer*. The seventh contains no speech of creation, no making, and no evening-and-morning formula. It contains a completing, a ceasing, a blessing, and a sanctifying. Three of those four have no parallel in the preceding six, and the one that does, the blessing, was previously applied to creatures and here is applied to a day.

**The seventh day is the only unclosed member of a closed series.** Six times the text says evening and morning. The seventh time it does not. Whatever is meant by that, a break in a pattern the author has established six times is a break the author made, and the reader who notices it is reading rather than importing. This book takes no position on what the omission signifies. It records that the omission exists and that it exists at the position the corpus is about to make its terminal one.

**The object of the cessation is stated three times.** *Melaʾkto ʾasher ʿasah* appears in the first half of verse two and again in the second. *Melaʾkto ʾasher baraʾ ʾelohim la-ʿasot* appears in verse three. Three statements of the same object across two verses. What ceases is the making, and the repetition forecloses any reading in which something else is what stops. Nothing is said to begin.

**The vocabulary is cessation and not recuperation.** Chapter 9 established this and the point bears repeating in situ, because the whole downstream argument is vulnerable to a reader who imports fatigue at Genesis 2 and never removes it. There is no exhaustion in *šbt*. Isaiah 40:28 explicitly denies of God the two words that would carry exhaustion, *loʾ yiʿaf we-loʾ yigaʿ*, and Genesis 2 does not use either.

What follows from the four is a single structural fact and it is worth naming precisely because it is easy to state too grandly. **The corpus places a cessation at the terminal position of its opening account, blesses and sanctifies that position, and describes it in a vocabulary that carries no fatigue and no reward.** That is all. It is not yet a claim about the promise, about the land, about the monarchy, or about any figure. It is a claim about what kind of thing occupies the last slot in the first story.

Two later texts pick that slot up and neither of them is subtle about it.

**Exodus 20:11** grounds the sabbath commandment in Genesis 2 by direct citation: *ki sheshet yamim ʿasah YHWH ʾet ha-shamayim we-ʾet ha-ʾareṣ ʾet ha-yam we-ʾet kol ʾasher bam wa-yanaḥ ba-yom ha-shevi'i*. The verb here is not *šbt* but *nwḥ*, the settling-root, which is a fact the English obscures completely and which matters for this book's argument. The Decalogue's own citation of Genesis 2 substitutes the second root for the first. The two are being treated as occupying one position.

**Deuteronomy 5:15** grounds the same commandment differently, in the exodus rather than in creation, and the difference between the two groundings is one of the standard problems of the Decalogue's transmission. This book takes no position on it. It notes that Exodus grounds the seventh position in a cessation from making and Deuteronomy grounds it in a deliverance from servitude, and that both are terminal positions of a completed action.

**Psalm 95:11** will name the object of the promise as *menuḥati*, my rest, using the nominal of the root Exodus 20:11 used for Genesis 2. Chapter 26 works that verse in full. What is established here is only that the vocabulary chain runs: Genesis 2 cessation, Exodus 20 settling, Psalm 95 my settling-place. Three books, one position, two roots the corpus treats as adjacent.

A reader may object that Genesis 2 is about a day and Psalm 95 is about a land, and that running a vocabulary chain between them is a conflation. The objection is good and the answer is that the corpus runs the chain, not this book. Exodus 20:11 puts the *nwḥ* root at Genesis 2's position. Hebrews is not available to this argument and is not needed for it; the citation is inside the Torah. What the corpus does with a vocabulary is evidence about that vocabulary, and a reader who wants to separate the day from the land has to separate them against Exodus 20:11 rather than in the absence of it.

## CHAPTER 22 · Deuteronomy 12:9 · Not Yet Come to the Rest

*Ki loʾ vaʾtem ʿad ʿattah ʾel ha-menuḥah we-ʾel ha-naḥalah ʾasher YHWH ʾeloheykha noten lakh.*

For you have not yet come to the resting-place and to the inheritance which the LORD your God is giving you.

This is the promise's terminus named in the corpus's own words, and it is worth taking the sentence apart before taking it up.

**The verb is one of arrival.** *Baʾ ʾel*, to come to. It governs a destination. This is not a verb of receiving, of being granted, or of having conferred; it is a verb of getting somewhere. The people are the subject. What they have not done is arrive.

**The negation is temporal and it is marked twice.** *Loʾ ... ʿad ʿattah*, not until now. The construction states a present deficiency against an implied future sufficiency. Deuteronomy 12 is set on the plains of Moab and the not-yet is a statement about the position at that moment.

**Two objects stand in a pair.** *Ha-menuḥah we-ha-naḥalah*, the resting-place and the inheritance. Both definite. Both governed by the one preposition, repeated. The pairing is doing work: an inheritance is a possession and a resting-place is a condition, and the corpus puts them in apposition without merging them.

**The relative clause has God as the giver.** *ʾAsher YHWH ʾeloheykha noten lakh*, which the LORD your God is giving you. The participle is present-progressive in force. The giving is underway while the arriving has not happened. That is the whole shape of this book in one verse and it is present in the corpus at the first statement of the terminus.

The next verse supplies the causative and the sequel.

*Wa-ʿavartem ʾet ha-Yarden wi-shavtem ba-ʾareṣ ʾasher YHWH ʾeloheykhem manḥil ʾetkhem, we-heniaḥ lakhem mi-kol ʾoyeveykhem mi-saviv wi-shavtem beṭaḥ.*

You will cross the Jordan and dwell in the land which the LORD your God is causing you to inherit, and he will cause you to settle from all your enemies round about, and you will dwell in safety.

Four verbs and their subjects, in order. You cross. You dwell. He causes to inherit. He causes to settle. Then you dwell in safety. The alternation is exact and it is not accidental: the human verbs are motion and residence, the divine verbs are both causatives, and the second human verb depends on the second divine one.

Three consequences, each returned to later.

**The terminus is named rather than inferred.** It has a lexeme. The lexeme is a state-word from the settling-root. The corpus does not describe a condition and leave a reader to name it; it supplies the noun.

**The terminus is stated with no figure in the clause.** No king, no anointed one, no branch, no messenger, no eschatological agent of any kind stands anywhere in Deuteronomy 12:9-10 or in the surrounding pericope. Under the criterion of Chapter 2, the strip here is the identity operation. This is a substantive content by the test, at the first place the corpus states it.

**The giver is named and it is God.** Twice, in two causatives, in one verse. The census of Chapter 17 found this pattern holding at every terminus site where an agent appears at all. Here it is at the beginning, in the Torah, before any king exists.

One further note on the pair. *Naḥalah* and *menuḥah* are not from the same root; *naḥalah* is from *nḥl* and *menuḥah* from *nwḥ*, and the similarity is aural rather than etymological. Whether the pairing is a deliberate assonance is a question this book has no way to settle. What is settleable is that the corpus repeats the pairing. Chapter 27 finds it again at 1 Chronicles 22:9 in a different form, where the *menuḥah* root generates a man's characterization and the inheritance is a temple.

## CHAPTER 23 · Joshua 21:44 · He Gave Them Rest

*Wa-yanaḥ YHWH lahem mi-saviv ke-khol ʾasher nishbaʿ la-ʾavotam, we-loʾ ʿamad ʾish bi-fneyhem mi-kol ʾoyeveyhem, ʾet kol ʾoyeveyhem natan YHWH be-yadam.*

And the LORD gave them rest round about, according to all that he swore to their fathers, and not a man of all their enemies stood before them; the LORD delivered all their enemies into their hand.

Deuteronomy 12 said not yet. Joshua 21 says done. The two verses use the same root and the corpus places them at the two ends of one narrative arc, which is the seam von Rad identified and this book works.

The verse deserves close attention because a great deal is packed into it.

**The verb is the same root in a different stem.** Deuteronomy 12:10 used the hiphil *heniaḥ*. Joshua 21:44 uses *wa-yanaḥ*, which is also causative in force here. The subject is YHWH. The recipient is *lahem*, to them. The pattern of Chapter 62 is already fully formed.

**The fulfilment is stated against the oath.** *Ke-khol ʾasher nishbaʿ la-ʾavotam*, according to all that he swore to their fathers. This is not a partial or provisional statement. The clause explicitly measures the delivery against the promise and finds it complete.

**Two further clauses reinforce it.** Not a man stood before them. All their enemies were given into their hand. The verse says three things where one would have sufficed, which is the mark of a summary statement rather than a passing note.

**The next verse goes further still.** *Loʾ nafal davar mi-kol ha-davar ha-ṭov ʾasher dibber YHWH ʾel beyt Yisraʾel, ha-kol baʾ.* Not a word failed of all the good word which the LORD spoke to the house of Israel; all came to pass. The Hebrew *ha-kol baʾ* is as absolute as the language permits: the whole thing arrived.

The statement is repeated twice more in the same book. **Joshua 22:4**: *we-ʿattah heniaḥ YHWH ʾeloheykhem la-ʾaḥeykhem ka-ʾasher dibber lahem*, now the LORD your God has given rest to your brothers as he said to them, spoken to the eastern tribes as they are sent home. And **Joshua 23:1**: *wa-yehi mi-yamim rabbim ʾaḥarey ʾasher heniaḥ YHWH le-Yisraʾel mi-kol ʾoyeveyhem mi-saviv*, after the LORD had given Israel rest from all their enemies round about, which opens Joshua's farewell.

Three statements, one book, one root, all in the perfect or with perfect force. The corpus is not hedging.

Now the difficulty, and it should be faced squarely rather than managed.

Joshua 13:1 opens the second half of the book with *we-ha-ʾareṣ nishʾarah harbeh meʾod le-rishtah*, and there remains very much land to be possessed. Judges 1 lists the places from which the tribes did not drive out the inhabitants. Judges 2:3 has the LORD declaring he will not drive them out. On any reading, the book that says all came to pass also says a great deal did not.

Three responses are available in the literature and this book takes none of them as its own.

The first is compositional: the statements come from different hands and the tension is a seam. That may be right and it is not this book's business.

The second is qualitative: the rest given was real but partial, and the full rest awaits. This is the majority reading and it is coherent. Its cost is that it requires the corpus to be using *heniaḥ* in the perfect, three times, with *ha-kol baʾ* attached, to mean something less than what those words say.

The third is the one this book will develop, and it is not a resolution of the tension but a relocation of it. **The corpus states the giving as complete and states elsewhere that the receiving did not happen.** Those are different predicates with different subjects. A gift can be given completely and not taken up, and the two statements are then both true without either being partial. Whether that is what the corpus means is the question Book IV takes up, and Psalm 95:11 is the hinge.

What Joshua 21:44 establishes for the present purpose is narrower and is not in dispute on any reading. **The delivery is attributed to God, stated in a completive form, measured against the oath, and delivered under a non-royal agent.** Joshua is not a king, is not anointed, founds no dynasty, and has no successor. The corpus attaches its strongest statement of the terminus to a man whose office ends when he dies.

## CHAPTER 24 · Judges · Four Deliveries by Ordinary Agents

The book of Judges delivers the terminus four times, in a fixed formula, under four deliverers, and none of them is a king.

*Wa-tishqoṭ ha-ʾareṣ ʾarbaʿim shanah*, and the land was quiet forty years, at 3:11 after Othniel.
*Wa-tishqoṭ ha-ʾareṣ shemonim shanah*, eighty years, at 3:30 after Ehud.
*Wa-tishqoṭ ha-ʾareṣ ʾarbaʿim shanah*, forty years, at 5:31 after the battle at the Kishon.
*Wa-tishqoṭ ha-ʾareṣ ʾarbaʿim shanah*, forty years, at 8:28 after Gideon.

Two hundred years in aggregate. The formula is identical in three of the four and differs in the fourth only in the numeral.

The deliverers repay attention because the corpus goes out of its way to make them unimpressive.

**Othniel** is Caleb's younger brother or nephew, depending on how the genealogy is parsed, and his qualification in the narrative is that he took Kiriath-sepher and married Achsah. The text says the spirit of the LORD was upon him and he judged and went out to war, and gives no further detail.

**Ehud** is left-handed, which the text specifies as *ʾiṭṭer yad yemino*, restricted in his right hand, and which the narrative treats as an operational advantage because the guards checked the wrong thigh. He makes his own weapon, a cubit long, two-edged. The assassination is described in physical detail that has embarrassed commentators for two thousand years.

**Deborah** judges under a palm tree and Barak refuses to go without her. The victory is credited in the prose to a rainstorm and in the poetry to the stars fighting from their courses, and the killing blow is struck by Jael with a tent peg. Judges 5:31 attaches the quiet-formula to the end of that.

**Gideon** is threshing wheat in a winepress to hide it from the Midianites when he is called, asks for two signs with a fleece, is told his army is too large twice, and attacks with three hundred men carrying jars and torches.

None of the four is anointed. None founds a dynasty. Gideon is offered one and refuses, in the verse Chapter 42 will treat as the corpus's opening position on monarchy. Three of the four have successors only in the sense that the cycle restarts.

Three consequences.

**A terminus repeatedly delivered by ordinary agents is not a terminus requiring an extraordinary one.** This is the load-bearing inference and it should be stated carefully. The claim is not that no extraordinary agent could deliver it, nor that the corpus never associates the terminus with a great figure. The claim is that the corpus, four times, in fixed language, attributes the delivery of the condition to circumstances in which no such figure is present. That is an existence proof and existence proofs are cheap to state and hard to refute.

**The condition is temporary and the corpus says why.** Each period ends. In every case the text attributes the ending to the people's return to what they had been doing, in the formula *wa-yosifu benei Yisraʾel la-ʿasot ha-raʿ be-ʿeyney YHWH*. The corpus never attributes the ending to a defect in the deliverance or to the death of the deliverer as such, though the death is usually mentioned. The failure is located at the receiver, four times, in the book that delivers the terminus four times. Book IV will find the same location in five further texts across three other books.

**The root is *šqṭ* and not *nwḥ*.** The Judges refrain uses the third root, whose subject is characteristically the land, and the subject here is the land. This is a real lexical difference and this book does not pretend the four roots are one word. What connects the Judges refrain to Joshua 21:44 is not the root but the position: both are terminal statements about the condition of Israel in the land after deliverance, and Joshua 11:23 uses *šqṭ* of exactly the situation Joshua 21:44 will describe with *nwḥ*. The corpus itself puts the two roots at one position in one book.

## CHAPTER 25 · 1 Kings 8:56 · Announced as Already Given

*Barukh YHWH ʾasher natan menuḥah le-ʿammo Yisraʾel ke-khol ʾasher dibber, loʾ nafal davar ʾeḥad mi-kol devaro ha-ṭov ʾasher dibber be-yad Mosheh ʿavdo.*

Blessed be the LORD, who has given rest to his people Israel according to all that he promised; not one word has failed of all his good promise which he spoke by the hand of Moses his servant.

The setting is the dedication of the temple, the speaker is Solomon, and the statement is in the perfect. This is the corpus's second completive announcement of the terminus and it is made at the high point of the monarchy by the king who built the house.

Four features.

**The noun is the nominal.** *Natan menuḥah*, gave rest, using the substantive rather than the causative verb. The construction is a giving with a thing given. That grammatical shape recurs across Chronicles and it is what makes the recipient-slot analysis of Chapter 17 possible.

**The recipient is the people, not the king.** *Le-ʿammo Yisraʾel*, to his people Israel. Solomon is speaking and Solomon is not the object of the verb. At the single moment in the corpus where a king might most naturally have claimed the delivery for himself or for his throne, the king assigns it to the people and the giver to God.

**The measurement is against Moses.** *ʾAsher dibber be-yad Mosheh ʿavdo.* The fulfilment is measured not against the Davidic covenant of 2 Samuel 7, which had been given to this speaker's father, but against the word spoken through Moses. Solomon is standing in a temple his father was forbidden to build, at the peak of a dynasty, and he dates the promise to the man who never entered the land.

**The formula echoes Joshua.** *Loʾ nafal davar ʾeḥad mi-kol devaro ha-ṭov* is Joshua 21:45's *loʾ nafal davar mi-kol ha-davar ha-ṭov* with one word added. The Deuteronomistic editor is quoting himself, and the quotation puts the temple dedication and the conquest summary in the same frame. Whatever one makes of the composition, the final form has two completive statements of the terminus in matching language, one at the end of the conquest and one at the dedication of the house.

The difficulty here is the same as at Joshua and is if anything sharper. This is Solomon speaking, and the corpus will spend 1 Kings 11 on his apostasy, the division of the kingdom, and the loss of ten tribes. A statement that the rest has been given, spoken by a man the same book will convict, is a statement placed under strain by its own book.

Two things can be said about that and neither is a resolution.

The strain is not hidden by the corpus. 1 Kings 8 and 1 Kings 11 are four chapters apart, in one book, by any account of the composition. Whoever assembled the material let both stand.

And the strain runs the direction this book will argue. If the terminus were a possession, then Solomon's announcement and Solomon's apostasy would be a contradiction requiring one of the two to be qualified. If the terminus is a state, then a man can stand inside a delivered condition and walk out of it, and the corpus can say both things about him without either being false. Deuteronomy 8:12-14 supplies exactly that mechanism and Chapter 36 works it: eating and being satisfied, building good houses and dwelling in them, and then *ram levavekha we-shakhaḥta*, your heart is lifted up and you forget. A state entered and unnoticed is, to the one standing in it, indistinguishable from a state never given.

## CHAPTER 26 · Psalm 95 · The Flock, the Hearing, the Non-Entry

The psalm that supplies the corpus's statement of non-entry supplies the diagnosis in the same breath, and the sequence of the two is the most compressed statement of this book's argument anywhere in the Hebrew Bible.

**Verse 7.** *Ki huʾ ʾeloheynu wa-ʾanaḥnu ʿam marʿito we-ṣoʾn yado; ha-yom ʾim be-qolo tishmaʿu.*

For he is our God and we are the people of his pasture and the sheep of his hand; today, if you will hear his voice.

**Verse 11.** *ʾAsher nishbaʿti ve-ʾappi ʾim yevoʾun ʾel menuḥati.*

To whom I swore in my anger that they should not enter my rest.

Four verses apart. The relation of the two is the psalm's whole structure and it runs in a fixed order: relation, then condition, then failure, then non-entry.

**The relation is stated first and it is unconditional.** We are the people of his pasture and the sheep of his hand. Nothing in verse 7a is conditioned on anything. The flock-relation is asserted.

**The condition is a hearing.** *Ha-yom ʾim be-qolo tishmaʿu*, today if you will hear his voice. The protasis is left grammatically open; the sentence has no stated apodosis and breaks off into the warning of verse 8. That incompleteness is itself striking and old: the sentence begins a conditional and never finishes it, and what follows instead is *ʾal taqshu levavkhem*, do not harden your hearts.

**The failure is a hardening of the heart, and the site is Meribah and Massah.** Verses 8 through 10 recite it: forty years, a generation, *ʿam toʿey levav hem*, a people erring in heart, *we-hem loʾ yadʿu derakhay*, and they did not know my ways.

**The non-entry is the consequence and it is stated in the terminus vocabulary.** *Menuḥati*, my rest, the nominal of the settling-root with a first-person suffix. Not their rest. His.

Five observations.

**The object is the same object.** *Menuḥah* at Deuteronomy 12:9, *heniaḥ* at Joshua 21:44, *menuḥah* at 1 Kings 8:56, *menuḥati* here. One vocabulary across four books. The psalm is not introducing a new concept; it is stating a negative about the concept the historical books stated positively.

**The verb is one of entering.** *Yevoʾun ʾel*, they shall come to. This is Deuteronomy 12:9's verb, *baʾ ʾel*, in the same construction with the same preposition. The corpus states the not-yet and the never-did with the same verb and the same object across the two books.

**The failure is located in an organ.** Heart, twice: *ʾal taqshu levavkhem* at verse 8 and *ʿam toʿey levav* at verse 10. And in a knowing: *loʾ yadʿu derakhay*. Book IV will find heart, eyes, and ears in five further texts and the psalm supplies the first member.

**The condition is a hearing and it is offered today.** *Ha-yom.* The adverb is emphatic by position and it is the same adverb Deuteronomy 30 uses five times to mark the near frame at 30:11-19. Two books, one adverb, one position: the thing is available now and the condition is a reception.

**The oath is sworn in anger and it concerns a generation.** *Nishbaʿti ve-ʾappi.* The corpus is describing the wilderness generation at Numbers 14, and the psalm reapplies it to its own hearers by the *ha-yom*. The reapplication is the psalm's own move, not a reader's.

What Psalm 95 does not say is worth stating as carefully as what it says, because F3 turns on it. **It does not say the rest was withheld.** It does not say the rest was postponed, reserved, delayed, or given to another. It says they did not enter it, and it gives the reason in the four preceding verses, and the reason is on their side. There is no clause anywhere in the psalm placing a deficiency in the object.

## CHAPTER 27 · 1 Chronicles 22:9 · A Man of Rest, Named Before Birth

*Hinneh ven nolad lakh, hu yihyeh ʾish menuḥah, wa-hanihoti lo mi-kol ʾoyevaw mi-saviv, ki Shelomoh yihyeh shemo, we-shalom wa-sheqeṭ ʾetten ʿal Yisraʾel be-yamaw.*

Behold, a son shall be born to you; he will be a man of rest, and I will give him rest from all his enemies round about, for Solomon will be his name, and I will give peace and quiet to Israel in his days.

This verse is the densest single site in the whole census and it repays being taken apart word by word.

**Three of the four roots appear in one verse.** *Menuḥah* from *nwḥ*. *Hanihoti* from *nwḥ* in the hiphil. *Sheqeṭ* from *šqṭ*. Plus *shalom*, which Chapter 20 held outside the four for good reason but which the corpus places here beside two of them. This is the corpus assembling its own vocabulary field in a single sentence, and it is the best evidence available that the roots this book has separated are ones the corpus itself groups.

**The man is characterized by the state, not the source of it.** *ʾIsh menuḥah*, a man of rest. The construct is descriptive: he is a man belonging to, or marked by, the condition. It is not *ʾish meniaḥ*, a man who causes rest, which the language could have formed. The distinction is exactly the one Chapter 17's census turned on and here it is in the morphology.

**The giving is God's and it is stated in the first person twice.** *Wa-hanihoti lo*, and I will cause him to settle. *ʾEtten ʿal Yisraʾel*, I will give upon Israel. Two first-person verbs, one recipient who is the king, one recipient who is the people.

**The name is an etymology and the corpus supplies it.** *Ki Shelomoh yihyeh shemo*, for Solomon will be his name. The *ki* is causal or explanatory: he will be a man of rest *because* his name will be Solomon, which is to say the name encodes the condition. The corpus is doing philology on itself.

**The whole verse is a prospective justification for a building permit.** The context is David explaining why he was not permitted to build the temple and Solomon will be. Verse 8: *dam la-rov shafakhta*, you have shed much blood, and made great wars; you shall not build. Verse 10: he shall build a house for my name. The *menuḥah* is the qualifying condition for the building, and the corpus states that the man of war is disqualified and the man of rest is qualified.

Three consequences.

**The corpus can name a man for the terminus without making him its source.** This is the finding, and it is the sharpest available answer to the objection that Chapter 17's census was reading grammar too finely. Here is the single verse in the entire Hebrew Bible where a named king is most tightly bound to the terminus vocabulary, and the verse takes the trouble, in first-person divine speech, to say who gives it to him.

**The terminus is a precondition rather than a product.** Solomon has the rest *before* he builds. The sequence in the passage is: he will be a man of rest, I will give him rest, therefore he will build. The house is downstream of the condition, not the means to it.

**The prospective naming is a real oddity and it is not this book's business.** A son named before birth, with the name explained, is a device the corpus uses rarely. Whether 1 Chronicles 22 is the Chronicler's composition or draws on older material is a question this book does not enter. The verse says what it says in the received text and that is the object.

One further point closes the chapter and it is uncomfortable for a tidy reading. The Chronicler is writing after the monarchy has ended. He puts into David's mouth a divine speech naming Solomon a man of rest, in a book whose readers know how Solomon ended and how the house ended. Whatever he thought he was doing, he was not writing a triumphalist account of a delivered terminus. He was recording a designation, and Chapter 62 will find him doing the same thing three more times with a throne.

## CHAPTER 28 · Ezekiel 37:14 · The Ingathering's Own Terminal Clause

Ezekiel 37 is the chapter of the dry bones, and it is the chapter that most nearly refutes this book. It deserves a careful reading for that reason and not in spite of it.

The vision runs from verse 1 to verse 14 and its structure is a sequence of divine acts. I will open your graves. I will bring you up. I will bring you into the land. I will put my spirit in you and you shall live. And then the last clause of the last verse.

*We-hinnaḥti ʾetkhem ʿal ʾadmatkhem, wi-daʿtem ki ʾani YHWH dibbarti we-ʿasiti neʾum YHWH.*

And I will settle you upon your own land, and you shall know that I the LORD have spoken and performed it.

**The final verb of the ingathering sequence is the settling-root in the hiphil.** *We-hinnaḥti*, and I will cause you to settle. This is the same form as Deuteronomy 12:10's *we-heniaḥ*, and it stands at the end of a chain of acts as the thing the acts arrive at.

That is a significant finding and it cuts in two directions at once.

**It supports the argument.** The corpus, at the climax of its most famous restoration vision, terminates the sequence in the settling-root and then in a knowing. The gathering is not the end of the sentence. Two further clauses follow it and the second is *wi-daʿtem ki ʾani YHWH*, and you shall know that I am the LORD, which is the recognition-formula that closes scores of Ezekiel's oracles. The vision ends in a settling and a knowing.

**It cost the argument a claim.** An earlier version of this project held that the messianic frame was only partly removable, on the ground that the restoration material could not be stated without the act-layer. Ezekiel 37:14 falsified it. The corpus states the terminus at the end of the act-layer in the terminus's own vocabulary, so the terminus is available even inside the passage that most fully belongs to the acts. The earlier claim is recorded here as dead rather than quietly removed, because a book that reports only its surviving positions is reporting half a method.

Now the difficulty. Verses 21 through 28 continue the chapter and introduce a figure.

Verse 22: one nation, one king over them all, *u-melekh ʾeḥad yihyeh le-khullam le-melekh*. Verse 24: *we-ʿavdi Dawid melekh ʿaleyhem we-roʿeh ʾeḥad yihyeh le-khullam*, my servant David king over them and one shepherd for all of them. Verse 25: *we-Dawid ʿavdi nasiʾ lahem le-ʿolam*, and David my servant prince to them forever. Verse 26: a covenant of peace, an everlasting covenant, and the sanctuary in their midst forever.

So the chapter contains both the terminus in its own vocabulary at verse 14 and a royal figure of maximal permanence at verses 22 to 25. A reader who wants to say the corpus subordinates the figure to the state has to say something about that.

Three things can be said and each is checkable.

**The two passages are separate oracles.** Verse 15 opens *wa-yehi devar YHWH ʾelay leʾmor*, and the word of the LORD came to me, saying, which is Ezekiel's standard formula for the beginning of a new unit. The bones vision runs 1 to 14 and closes on the recognition-formula. The two sticks oracle runs 15 to 28. They are adjacent and they are not one pericope, and the criterion of Chapter 2 operates on pericopes.

**Verse 14 is unmarked and verse 24 is marked.** Under the criterion the corpus therefore holds the terminus available without the figure, since it states it at verse 14 in a pericope where no figure stands. That is the whole test and it returns a clean result here.

**Verse 24 itself separates the roles.** *We-ʿavdi Dawid melekh ʿaleyhem* stands beside Ezekiel 34:24's *wa-ʾani YHWH ʾehyeh lahem le-ʾelohim we-ʿavdi Dawid nasiʾ be-tokham*, and Chapter 61 works that verse at length. The two roles are distinguished in one sentence by the corpus.

What this chapter concedes, and it should be conceded plainly, is that Ezekiel 37 as a whole is a chapter in which the terminus and the figure sit close together and are both stated at maximum strength. A reader who finds the pericope division too convenient has a real objection. The reply is that the division is marked by the corpus's own formula and not chosen for the occasion, and that the reader is invited to check verse 15.

## CHAPTER 29 · Isaiah 11:9 and 2:4 · State Descriptions With No Agent

Two verses in Isaiah describe the terminal condition with no agent in the clause at all, and they are the strongest instances in the corpus of a content stated without anyone to state it about.

**Isaiah 11:9.** *Loʾ yareʿu we-loʾ yashḥitu be-khol har qodshi, ki maleʾah ha-ʾareṣ deʿah ʾet YHWH ka-mayim la-yam mekhassim.*

They shall not hurt nor destroy in all my holy mountain, for the earth shall be full of the knowledge of the LORD as the waters cover the sea.

**Isaiah 2:4.** *We-shafaṭ beyn ha-goyim we-hokhiaḥ le-ʿammim rabbim, we-kittetu ḥarvotam le-ʾittim wa-ḥanitoteyhem le-mazmerot, loʾ yisaʾ goy ʾel goy ḥerev we-loʾ yilmedu ʿod milḥamah.*

Nation shall not lift sword against nation, neither shall they learn war any more.

Take the second first, because it carries a complication that the first does not.

**Isaiah 2:4 has a judging subject in its first clause.** *We-shafaṭ beyn ha-goyim*, and he shall judge between the nations. The antecedent is YHWH from 2:3, who teaches his ways from Zion. So the verse is not agentless in its opening. What is agentless is its closing: the beating of swords into ploughshares has the nations as subject, and *loʾ yisaʾ goy ʾel goy ḥerev we-loʾ yilmedu ʿod milḥamah* has the nations as subject twice more. The terminal clause of the passage describes a cessation whose subject is the nations themselves, and there is no figure anywhere in Isaiah 2:2-4.

The verb in the final clause is worth noticing. *Loʾ yilmedu*, they shall not learn. Not they shall not fight; they shall not learn. The cessation is stated at the level of the practice rather than the event, which is a way of stating a condition rather than an outcome. A world in which nobody fights this year is a lull. A world in which nobody learns war is a different kind of object.

**Isaiah 11:9 is fully agentless in its operative clause.** *Ki maleʾah ha-ʾareṣ deʿah ʾet YHWH.* The earth is full of the knowledge of the LORD. The verb is stative, the subject is the earth, and there is no one performing the filling. The simile that follows, *ka-mayim la-yam mekhassim*, as the waters cover the sea, is a picture of saturation rather than of an act. Water covering the sea is not something water does; it is what the sea is.

The complication here is the reverse of Isaiah 2's. Isaiah 11:9 sits eight verses after Isaiah 11:1, the shoot from the stump, which is the corpus's most famous single messianic verse. The chapter opens with a figure and closes with an agentless state.

That is the structure the criterion is built to read, and here it reads cleanly. **The pericope contains a figure. The terminus clause does not.** Under the test, the content is available without the figure because the corpus states it in a clause the figure does not occupy, in a grammar that has no room for an agent.

An objection is available and should be answered. Isaiah 11:9 opens with *ki*, for or because, which subordinates it to what precedes. If the *ki* is causal, then the fullness of knowledge is the consequence of the figure's activity in verses 3 through 5, and the clause is figure-indexed after all by subordination.

Three responses.

The *ki* attaches most immediately to 11:9a, the not-hurting and not-destroying, and gives the reason for that. Whether it reaches back past 11:6-8 to the figure of 11:1-5 is a question about the scope of the conjunction, and it is genuinely open.

Even on the reading most favourable to the objection, the content of the clause is a state with no agent. A causal chain terminating in an agentless state is exactly the structure this book argues for: the figure is a means and the state is what the means moves toward. The objection, if granted, supplies the argument rather than damaging it.

And the corpus states the same content elsewhere without any figure in the vicinity. Habakkuk 2:14: *ki timmaleʾ ha-ʾareṣ la-daʿat ʾet kevod YHWH ka-mayim yekhassu ʿal yam*. Almost the same words, in a different book, in a passage about the fall of a plunderer, with no figure anywhere near it. Under the criterion the content is substantive on the strength of Habakkuk alone.

## CHAPTER 30 · Leviticus 26 and 2 Chronicles 36:21 · The Exile Priced in Sabbaths

The corpus accounts the length of the exile in a currency, and the currency is the terminus.

**2 Chronicles 36:21.** *Le-malloʾt devar YHWH be-fi Yirmeyahu ʿad raṣetah ha-ʾareṣ ʾet shabbetoteha, kol yemey ha-shammah shavatah le-malloʾt shivʿim shanah.*

To fulfil the word of the LORD by the mouth of Jeremiah, until the land had enjoyed her sabbaths; all the days of her desolation she kept sabbath, to fulfil seventy years.

**Leviticus 26:34-35.** *ʾAz tirṣeh ha-ʾareṣ ʾet shabbetoteha kol yemey hoshammah we-ʾattem be-ʾereṣ ʾoyeveykhem, ʾaz tishbat ha-ʾareṣ we-hirṣat ʾet shabbetoteha. Kol yemey hoshammah tishbot ʾet ʾasher loʾ shavtah be-shabbetoteykhem be-shivtekhem ʿaleha.*

Then the land shall enjoy her sabbaths as long as she lies desolate and you are in your enemies' land; then the land shall rest and enjoy her sabbaths. As long as she lies desolate she shall rest, because she did not rest in your sabbaths when you dwelt upon her.

Four observations.

**The exile's duration is denominated in unkept sabbaths.** Not in years of punishment, not in units of guilt, not in a ratio of offences to consequences. In sabbaths the land did not get. The Chronicler is explicit that the seventy years is the sum of that debt.

**The land is the subject of the resting verb.** *Tishbat ha-ʾareṣ*, the land shall rest, using *šbt*, the cessation root of Genesis 2. Not the people. The land. Both texts are consistent on this and both use the same root.

**The debt is a debt of cessation.** *ʾEt ʾasher loʾ shavtah be-shabbetoteykhem*, that which she did not rest in your sabbaths. The thing owed is a stopping that did not happen. This is the sharpest available demonstration that the corpus treats the terminus vocabulary as denoting something that can be owed, accumulated, and repaid, which is not how one talks about a reward.

**The catastrophe is priced in the currency of the terminus.** That is the finding and it should be stated at the right strength. The corpus had many available vocabularies for exile: covenant, curse, wrath, scattering, the sword, all of which it uses elsewhere and Leviticus 26 uses at length in the preceding thirty verses. At the point of stating the duration, it switches to the sabbath-root and states the whole thing as an account being settled.

This is a stronger result than the argument required, and a convenient finding deserves the caution appropriate to one. Three qualifications.

**The sabbath here is the sabbatical year and not the seventh day.** Leviticus 25 legislates the seventh year of rest for the land, and Leviticus 26:34 is referring to that legislation. The root is the same and the institution is not. Chapter 9 established that the root is cessation regardless of the interval; the interval here is seven years and not seven days.

**The Chronicler is making an interpretive move and the corpus shows him making it.** He cites Jeremiah for the seventy years, which Jeremiah 25:11 and 29:10 supply, and he cites the sabbath-accounting, which Leviticus 26 supplies, and he joins them. Jeremiah does not say the seventy years are unkept sabbaths. The joining is the Chronicler's. That is a datum about how a biblical writer read his own corpus, and it is offered at that weight rather than as a claim about Jeremiah.

**Nothing about a figure enters here at all.** Neither text carries a royal or eschatological agent, in the clause or in the surrounding pericope. The exile is opened, endured, and closed in the terminus vocabulary with no figure named anywhere, and the closing at 2 Chronicles 36:22-23 is credited to Cyrus, which Chapter 71 takes up because Cyrus holds a title that ought to complicate everything and turns out to complicate exactly one thing.

## CHAPTER 31 · A State Is Entered, Not Delivered

Book III has established a set of facts and this chapter draws the inference they support and stops there.

**The facts.**

The corpus names its terminus in a lexeme rather than describing a condition and leaving the naming to a reader. The lexeme is *menuḥah* and its verbal forms, from a root whose image is settlement.

It states the terminus as not yet reached at Deuteronomy 12:9, in a verb of arrival, with God named as the one giving.

It states the terminus as delivered at Joshua 21:44, in the causative, with God as subject and a non-royal agent presiding, and repeats the statement twice more in the same book.

It delivers the terminus four times in Judges under four ordinary deliverers, using the third root, with the land as subject.

It announces the terminus as already given at 1 Kings 8:56, in the perfect, at the dedication of the temple, with the people as recipient and the measurement taken against Moses.

It states the terminus as not entered at Psalm 95:11, using the same verb of arrival as Deuteronomy 12:9 and the same nominal with a divine suffix, and supplies the reason in the four preceding verses, and the reason is a hearing that did not happen and a heart that hardened.

It names a man for the terminus at 1 Chronicles 22:9 and takes the trouble, in the same verse, to say who gives it to him.

It terminates its greatest restoration vision in the settling-root at Ezekiel 37:14.

It states the terminal condition twice in Isaiah with no agent in the operative clause, and states the same content again in Habakkuk with no figure anywhere near it.

And it prices the exile in the currency of the terminus, in two books, with the land as the subject of the resting.

**The inference.**

A state is entered rather than delivered. That is a claim about a category and it is the only inference Book III needs.

The corpus's own grammar carries it. Deuteronomy 12:9 uses a verb of arrival and Psalm 95:11 uses the same verb negated. Both make the people the subject of the entering. The giving-verbs, by contrast, have God as subject throughout: *heniaḥ*, *wa-yanaḥ*, *natan menuḥah*, *hanihoti*, *we-hinnaḥti*. Two grammatical patterns, two different subjects, consistently distributed. God gives; the people enter or do not.

**The consequence, stated at exactly its strength and no further.**

If the terminus is entered rather than delivered, then a failure of entry is not addressed by an improvement in delivery. That is not yet an argument about the monarchy or about any figure. It is a conditional whose antecedent Book III has established and whose consequent Books IV and VIII will test against the corpus.

Two things Book III has not shown, and saying so here forecloses two misreadings.

**It has not shown that the corpus never associates the terminus with a figure.** It does, at Isaiah 11, at Ezekiel 34 and 37, at 1 Chronicles 22. The claim is that the corpus also states it without one, repeatedly, in clauses where the strip is the identity operation.

**It has not shown that the act-layer is unimportant.** Ezekiel 37:1-14 is an act-sequence and it is one of the great passages of the corpus. The claim is that the corpus terminates the sequence in the settling-root, which is a statement about where the sequence points and not about whether it matters.

What remains is the question Book IV takes up. If the terminus was given and not entered, where does the corpus locate the failure? The answer turns out to be uniform across five texts in three books, and it is not where a reader expecting a theodicy would look.
