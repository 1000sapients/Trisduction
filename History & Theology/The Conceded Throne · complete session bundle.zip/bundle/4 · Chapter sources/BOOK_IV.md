# BOOK IV · THE DEFICIT

## CHAPTER 32 · Deuteronomy 29:3 · The Organ Not Given

*We-loʾ natan YHWH lakhem lev la-daʿat we-ʿeynayim lirʾot we-ʾoznayim lishmoaʿ ʿad ha-yom ha-zeh.*

And the LORD has not given you a heart to know, and eyes to see, and ears to hear, unto this day.

This is the corpus's first full statement of the deficit and it names three organs. Every subsequent statement in this book uses at least one of the three and most use two or three. The triad is not a rhetorical flourish; it is a fixed inventory the corpus returns to across four centuries of its own internal chronology.

The setting is worth having in view because it makes the verse harder rather than easier. Deuteronomy 29 opens with Moses summoning all Israel and reciting what they have seen. Verse 1: *ʾAttem reʾitem ʾet kol ʾasher ʿasah YHWH le-ʿeyneykhem be-ʾereṣ Miṣrayim*, you have seen all that the LORD did before your eyes in the land of Egypt. Verse 2: the great trials, the signs, the wonders. Verse 4: forty years in the wilderness, clothes not worn out, sandals not worn out. Verse 5: no bread, no wine, no strong drink, *le-maʿan tedʿu ki ʾani YHWH ʾeloheykhem*, that you may know that I am the LORD your God.

So the deliverable is delivered, exhaustively, and the recitation of it stands immediately before the statement that the receiving organ was not given.

Four things follow.

**The failure is stated as a lack in the receiver, not a lack in the gift.** The verse does not say the signs were insufficient, ambiguous, or withheld. It recites them and then says the organ was not given.

**The three organs are cognitive, not moral.** A heart to know, eyes to see, ears to hear. The Hebrew *lev* is not the seat of emotion in this corpus but of thought, intention, and understanding; the deficiency named is an inability to register rather than an unwillingness to comply. That is a different diagnosis from disobedience and the corpus states it in different vocabulary.

**The subject of the not-giving is God.** *Loʾ natan YHWH lakhem.* This is the verse's difficulty and it will not be managed away here. On the face of it the corpus is saying God did not supply the organ needed to receive what God supplied, and Chapter 39 addresses the problem that raises rather than pretending it does not exist.

**The temporal marker leaves the situation open.** *ʿAd ha-yom ha-zeh*, unto this day. Not forever, not permanently, not by decree. The phrase records a state of affairs as of the moment of speaking. Whatever else is true, the verse does not close the case.

One further feature deserves attention because it is easily missed and bears on Book IV's whole argument. The three organs recur as a set in Isaiah 6:10 and the order is preserved: heart, eyes, ears. Isaiah 6:10 reverses the direction, hardening rather than not-giving, and adds a purpose clause. Isaiah 42:20 takes eyes and ears and drops the heart. Jeremiah 5:21 has *ʿeynayim lahem we-loʾ yirʾu ʾoznayim lahem we-loʾ yishmaʿu*, eyes they have and see not, ears they have and hear not, addressed to a *ʿam sakhal we-ʾeyn lev*, a foolish people without heart. Ezekiel 12:2 has almost identical language: *ʿeynayim lahem lirʾot we-loʾ raʾu ʾoznayim lahem lishmoaʿ we-loʾ shameʿu*. Psalm 115:5-6 applies the same inventory to idols. Psalm 135:16-17 repeats it.

Six sites, four books, one inventory. The corpus is not improvising a metaphor each time; it is using a fixed diagnostic and applying it to Israel, to the wilderness generation, to the exiles, and to the idols of the nations. Chapter 38 counts them.

The relation between Deuteronomy 29:3 and Jeremiah 5:21 is the sharpest instance. Deuteronomy says the organ was not given. Jeremiah says they have the organs and do not use them. Those are two different claims and the corpus makes both about the same population in the same vocabulary. It does not reconcile them, and Chapter 39 is about the fact that it does not.

## CHAPTER 33 · Isaiah 6 · Commissioned Into Non-Reception

Isaiah 6 is the hardest text in this book and it is hard in a way that cannot be softened without losing what makes it evidence.

The chapter is a throne vision. The prophet sees the LORD high and lifted up, the seraphim call to one another, the doorposts shake, the house fills with smoke. Isaiah says *ʾoy li ki nidmeyti*, woe is me for I am undone, and names the reason: *ki ʾish ṭemeʾ sefatayim ʾanokhi u-ve-tokh ʿam ṭemeʾ sefatayim ʾanokhi yoshev*, a man of unclean lips dwelling among a people of unclean lips. A seraph takes a coal from the altar with tongs and touches his mouth. The guilt is removed. Then the commission.

*Wa-yoʾmer lekh we-ʾamarta la-ʿam ha-zeh, shimʿu shamoaʿ we-ʾal tavinu, u-reʾu raʾo we-ʾal tedaʿu.*

Go and say to this people: hear indeed, but do not understand; see indeed, but do not know.

*Hashmen lev ha-ʿam ha-zeh we-ʾoznaw hakhbed we-ʿeynaw hashaʿ, pen yirʾeh ve-ʿeynaw u-ve-ʾoznaw yishmaʿ u-levavo yavin wa-shav we-rafaʾ lo.*

Make the heart of this people fat, and their ears heavy, and shut their eyes, lest they see with their eyes and hear with their ears and understand with their heart and turn and be healed.

Four features.

**The three organs are the Deuteronomy 29:3 inventory, in the same order.** Heart, ears, eyes at 6:10a, then eyes, ears, heart at 6:10b in the reverse order for the purpose clause. The chiasm is deliberate and the inventory is fixed.

**The commission is a commission to deliver into non-reception and it says so at the moment of commissioning.** This is not a report after the fact that the message failed. It is the terms of the assignment, stated before the assignment begins. Whatever else is going on, the corpus is not claiming its prophet was surprised.

**The purpose clause is the difficulty.** *Pen ... wa-shav we-rafaʾ lo*, lest they turn and be healed. On the surface the hardening is instrumental to preventing a healing, which is a proposition that has generated two and a half millennia of commentary and will not be settled here.

**Verse 11 asks how long and receives a duration rather than a resolution.** *Wa-ʾomar ʿad matay ʾAdonay*, and I said, how long, Lord. The answer is: until cities lie waste without inhabitant, houses without people, and the land is utterly desolate. The prophet asks a question about termination and gets an answer about extent.

What this book takes from Isaiah 6 is narrow and it is worth separating from what this book does not take.

**What is taken.** The deficit is located in the three organs, in the same inventory as Deuteronomy 29:3, at the moment of a prophetic commissioning, in the corpus's own words. That is a datum about where the corpus puts the problem.

**What is not taken.** No position on the theology of the hardening. Whether the imperatives are prescriptive or descriptive-of-outcome, whether the prophet's preaching is the instrument of a judgment already determined, whether the purpose clause states an intention or an effect: these are the questions of the hardening literature, they are live, and this book has nothing to add to them. Chapter 39 says so at length and explains why the argument does not need them settled.

One feature of the chapter is directly load-bearing and is usually noticed late. **Isaiah 6 closes on the terminus imagery of Book IX.** Verse 13: *we-ʿod bah ʿasiriyah we-shavah we-haytah le-vaʿer, ka-ʾelah we-kha-ʾallon ʾasher be-shalleket maṣṣevet bam, zeraʿ qodesh maṣṣavtah.*

And yet a tenth shall be in it, and it shall return and be consumed; as a terebinth and as an oak whose stump remains when they are felled, the holy seed is its stump.

The commission into non-reception ends in a felled tree with a surviving stump, seven chapters before Isaiah 11:1 grows a shoot from a stump. The corpus places the deficit and the stump-image in the same chapter, and Chapter 89 works the relation.

## CHAPTER 34 · Isaiah 42:19 · The Corpus Puts Its Own Messenger in the Category

*Mi ʿiwwer ki ʾim ʿavdi, we-ḥeresh ke-malʾakhi ʾeshlaḥ, mi ʿiwwer ki-meshullam we-ʿiwwer ke-ʿeved YHWH. Raʾot rabbot we-loʾ tishmor, paqoaḥ ʾoznayim we-loʾ yishmaʿ.*

Who is blind but my servant, and deaf as my messenger whom I send? Who is blind as he that is at peace with me, and blind as the servant of the LORD? Seeing many things, but you observe not; opening the ears, but he hears not.

This verse is the reason the deficit motif in this book cannot be read as a polemic.

**The corpus applies the diagnostic to its own messenger.** Not to the nations, not to idolaters, not to an opposing party. *ʿAvdi*, my servant. *Malʾakhi ʾeshlaḥ*, my messenger whom I send. *ʿEved YHWH*, the servant of the LORD. Four designations, all of them honorific, all of them the corpus's own vocabulary for the figure it most closely identifies with.

**The organs are two of the three.** Blind and deaf: eyes and ears. The heart is absent from this instance and present in most of the others.

**The final clause states the structure of the deficit exactly.** *Paqoaḥ ʾoznayim we-loʾ yishmaʿ*, opening the ears and he does not hear. The infinitive absolute *paqoaḥ* describes a state of openness. The organ is not sealed. It is open and not receiving. That is the sharpest formulation of the whole motif anywhere in the corpus, and it forecloses the reading in which the deficit is a physical obstruction.

The consequence for the argument is a fence rather than a support, and it is the more valuable for that.

**The polemical use of the motif is foreclosed by the corpus itself.** A reader could take the heart-eyes-ears diagnostic as a weapon: they do not see, we do. Isaiah 42:19 makes that unavailable, because the corpus assigns the condition to its own servant in the strongest possible terms and in a chapter that is otherwise about that servant's commission. Whoever the servant is, and the identification is contested at Isaiah 42 as it is throughout the servant material, the corpus is not exempting him.

That fence applies to this book too, and Chapter 108 says so.

A further observation on the immediate context. Isaiah 42:18 opens *ha-ḥershim shemaʿu we-ha-ʿiwrim habbiṭu lirʾot*, you deaf, hear; you blind, look and see. The imperative is addressed to the very organs said to be deficient. That is not a contradiction; it is the same shape as Jeremiah 6:16, where the instruction is to walk on paths that already exist and the answer recorded is a refusal. The corpus issues the command to the deficient party and records the outcome, and it does this repeatedly.

Isaiah 42:20's *we-loʾ tishmor* switches to second person in the middle of a third-person sequence, which is a well-known textual awkwardness. Some manuscripts and the versions regularize it. This book takes no position and the argument is unaffected either way, since the deficiency predicate holds of the servant in both readings.

## CHAPTER 35 · Jeremiah 6:16 · And They Said, We Will Not Walk

Chapter 12 introduced this verse for its vocabulary. This chapter takes it for its argument, because it is the single passage that answers the strongest objection to Book IV.

The objection is this. Two of the four principal deficit texts describe an organ *not given* and one has the ears *made* heavy. So the deficit looks imposed rather than incurred, and if it is imposed then the failure is not at the receiver in any morally interesting sense, and Book IV's whole claim collapses into a claim about divine agency.

Jeremiah 6:16 is the answer, and it is an answer because nothing in it is withheld and nothing in it is made heavy.

*Koh ʾamar YHWH, ʿimdu ʿal derakhim u-reʾu, we-shaʾalu li-netivot ʿolam ʾey zeh derekh ha-ṭov u-lekhu vah, u-miṣʾu margoaʿ le-nafshotekhem. Wa-yomeru loʾ nelekh.*

Take it clause by clause.

**Stand at the roads and look.** *ʿImdu ʿal derakhim u-reʾu.* An imperative of position and an imperative of sight. The organ Isaiah 6:10 shut is here commanded to operate, with no indication that it cannot.

**Ask for the ancient paths.** *We-shaʾalu li-netivot ʿolam.* The paths already exist. *ʿOlam* here is durative rather than eternal: the long-standing ways. Nothing is being built, revealed, disclosed, or awaited. The instruction is to find out where something already standing is.

**Where the good way is, and walk in it.** *ʾEy zeh derekh ha-ṭov u-lekhu vah.* An interrogative and an imperative. The good way is one of the ancient paths and the task is to identify it and use it.

**And find repose for your souls.** *U-miṣʾu margoaʿ le-nafshotekhem.* The terminus, in the fourth root, as the outcome of the walking. Note the verb: *miṣʾu*, find. Not receive, not be given. Find. The terminus is at the end of the paths and the finding is the walker's.

**And they said, we will not walk.** *Wa-yomeru loʾ nelekh.*

Five features of that final clause carry the whole weight.

It is speech, quoted. The corpus does not describe an inability and does not narrate a failure. It quotes a sentence.

The verb is the same verb as the imperative. *Lekhu* in the command, *nelekh* in the refusal. The refusal is precise: it declines exactly what was asked.

The subject is first person plural. They speak for themselves.

There is no divine agent anywhere in the refusal. Nothing hardens, nothing is withheld, nothing is made heavy, nothing is shut.

And the whole exchange is compressed into a single verse, which puts the offer and the refusal in a relation a reader cannot separate.

Deuteronomy 30:19 has the same shape from the other side. *Ha-ʿidoti vakhem ha-yom ʾet ha-shamayim we-ʾet ha-ʾareṣ, ha-ḥayyim we-ha-mawet natati le-faneykha, ha-berakhah we-ha-qelalah, u-vaḥarta ba-ḥayyim.* I have set before you life and death, blessing and curse; therefore choose life. The imperative *u-vaḥarta* is a command to choose, addressed to a party the corpus assumes can.

**The corpus carries both an unfurnished organ and a declined offer, and reconciles neither.** That is the honest statement of the position and Chapter 39 defends the decision not to resolve it. What the corpus carries nowhere is a withheld terminus, and that is the claim Book IV is actually making.

## CHAPTER 36 · Deuteronomy 8 · The Mechanism Is Prosperity

The corpus supplies a mechanism for the deficit and the mechanism is not what a reader would guess.

*Pen toʾkhal we-savaʿta u-vattim ṭovim tivneh we-yashavta. U-veqarkha we-ṣoʾnkha yirbeyun we-khesef we-zahav yirbeh lakh we-khol ʾasher lekha yirbeh. We-ram levavekha we-shakhaḥta ʾet YHWH ʾeloheykha ha-moṣiʾakha me-ʾereṣ Miṣrayim mi-beyt ʿavadim.*

Lest you eat and be satisfied, and build good houses and dwell in them, and your herds and flocks multiply, and your silver and gold multiply, and all you have multiplies. And your heart is lifted up and you forget the LORD your God who brought you out of the land of Egypt, from the house of slavery.

**The danger condition is prosperity, not hardship.** Every clause in the protasis is a benefit. Eating, satisfaction, good houses, dwelling, multiplying herds, multiplying silver, multiplying everything. The corpus lists eight good outcomes and then names the risk they carry.

**The failure is a lifted heart and a forgetting.** *Ram levavekha we-shakhaḥta.* The heart again, and the verb of the deficit here is memory rather than perception. The chapter has already supplied the positive form at 8:2: *we-zakharta ʾet kol ha-derekh*, and you shall remember all the way. And at 8:18: *we-zakharta ʾet YHWH ʾeloheykha ki huʾ ha-noten lekha koaḥ la-ʿasot ḥayil*, you shall remember that it is he who gives you power to get wealth.

**The mechanism is structural and it explains the shape of the whole problem.** A state entered and unnoticed is, to the one standing in it, indistinguishable from a state never given. That sentence is the hinge of Book IV. If the terminus is a condition rather than an object, then it can be occupied without being registered, and the failure to register it produces exactly the phenomenology of not having received it. The people in Deuteronomy 8 are not being warned that prosperity will be taken away. They are being warned that they will stop seeing it as given.

Exodus 20:8 guards the same position with the one imperative of memory in the Decalogue. *Zakhor ʾet yom ha-shabbat le-qaddesho.* Remember the sabbath day to keep it holy. Of ten commandments, one is a command to remember, and its object is the seventh position. Deuteronomy's version of the Decalogue substitutes *shamor*, keep, at 5:12, and the difference between the two verbs is one of the classical problems. Nothing here turns on which is prior. What both versions agree on is that the seventh position requires an act of attention that the corpus thought worth commanding.

Three further sites confirm that the corpus treats forgetting as the operative failure rather than as a lapse.

**Deuteronomy 6:10-12.** Cities you did not build, houses full of good things you did not fill, cisterns you did not dig, vineyards and olive trees you did not plant. Then: *hishamer lekha pen tishkaḥ ʾet YHWH*, take heed lest you forget the LORD. The list is a list of unearned goods and the warning attaches to the unearnedness.

**Deuteronomy 32:15.** *Wa-yishman Yeshurun wa-yivʿaṭ, shamanta ʿavita kasita, wa-yiṭṭosh ʾeloah ʿasahu.* Jeshurun grew fat and kicked; you grew fat, thick, gorged; and he forsook the God who made him. The verb *shaman* is the same root as Isaiah 6:10's *hashmen lev*, make the heart fat. The corpus uses one image for the hardening and for the effect of prosperity.

**Hosea 13:6.** *Ke-marʿitam wa-yisbaʿu, saveʿu wa-yarom libbam, ʿal ken shekheḥuni.* According to their pasture they were filled; they were filled and their heart was lifted up; therefore they forgot me. Three verbs in the exact sequence of Deuteronomy 8: satisfied, heart lifted, forgot.

Four books, one mechanism, stated in overlapping vocabulary. This is not a stray warning. It is the corpus's standing account of how a delivered condition goes unregistered.

## CHAPTER 37 · Exodus 20:8 · The One Imperative of Memory

The Decalogue contains ten items and one of them is a command to remember. Its object is the seventh position, and that fact deserves a chapter rather than a clause.

*Zakhor ʾet yom ha-shabbat le-qaddesho. Sheshet yamim taʿavod we-ʿasita kol melaʾkhtekha, we-yom ha-shevi'i shabbat la-YHWH ʾeloheykha, loʾ taʿaseh khol melaʾkhah.*

Remember the sabbath day to keep it holy. Six days you shall labour and do all your work, but the seventh day is a sabbath to the LORD your God; you shall do no work.

Four observations, and the fourth is the one that matters for this book.

**The verb is an infinitive absolute functioning as an imperative.** *Zakhor*, remember, standing at the head of the clause. Deuteronomy 5:12 has *shamor*, keep or guard. The two versions differ and the difference is old, discussed within the tradition and unresolved. This book uses the Exodus form because the argument concerns memory, and notes that the Deuteronomy form would carry the same weight for a different reason, since guarding also implies a thing that can be lost by inattention.

**The grounding at 20:11 is Genesis 2.** *Ki sheshet yamim ʿasah YHWH ʾet ha-shamayim we-ʾet ha-ʾareṣ ... wa-yanaḥ ba-yom ha-shevi'i, ʿal ken berakh YHWH ʾet yom ha-shabbat wa-yeqaddeshehu.* The Decalogue cites the creation account explicitly. And as Chapter 21 noted, it cites it with the *nwḥ* root where Genesis used *šbt*. The two roots are being treated as one position by the corpus at the point where the corpus is most careful.

**The commandment is about a cessation and not about an activity.** *Loʾ taʿaseh khol melaʾkhah.* The content of the observance is a not-doing. Whatever is added by later practice, the commandment as stated prescribes the absence of an action and no positive act at all.

**A thing that must be remembered is a thing that can be forgotten while it stands.** This is the connection to Chapter 36 and it is the reason this chapter exists. Nobody commands the remembrance of a thing that is absent; absence enforces its own attention. The imperative of memory presupposes an object that is present and can go unregistered. The corpus places that imperative on the seventh position and on nothing else in the Decalogue.

Two further considerations, both offered at low weight.

The sabbath commandment is the longest of the ten in both versions, by a considerable margin, and it is the only one that supplies a reason grounded in a narrative. That is an emphasis a reader can notice without building on it.

And the extension of the commandment is total: son, daughter, male slave, female slave, cattle, and the resident alien within your gates. Deuteronomy 5:14 adds *le-maʿan yanuaḥ ʿavdekha wa-ʾamatekha kamokha*, so that your male and female slave may rest as you do, using the settling-root. The purpose clause makes the terminus available to a slave on the same terms as to the householder, which is a structural fact about the corpus's own distribution of the condition and one that no figure mediates.

## CHAPTER 38 · The Three Organs, Counted Across the Corpus

The heart-eyes-ears inventory is not a metaphor the corpus improvises. It is a fixed diagnostic, and this chapter counts its occurrences so that the claim can be checked rather than felt.

**The full triad, all three organs in one passage.**

Deuteronomy 29:3. Heart to know, eyes to see, ears to hear. Stated as not given.

Isaiah 6:9-10. Heart, ears, eyes in the hardening clause; eyes, ears, heart in the purpose clause. Stated as an instruction to the prophet.

Jeremiah 5:21. *ʿAm sakhal we-ʾeyn lev, ʿeynayim lahem we-loʾ yirʾu, ʾoznayim lahem we-loʾ yishmaʿu.* A foolish people without heart; eyes they have and see not, ears they have and hear not. Stated as a present condition with the organs possessed.

Ezekiel 12:2. *Beyt meri huʾ ʾasher ʿeynayim lahem lirʾot we-loʾ raʾu ʾoznayim lahem lishmoaʿ we-loʾ shameʿu, ki beyt meri hem.* A rebellious house, which have eyes to see and see not, ears to hear and hear not. The heart is implied by *beyt meri* rather than named.

**Two of the three.**

Isaiah 42:19-20. Blind and deaf: eyes and ears. Applied to the servant.

Isaiah 43:8. *Hoṣiʾ ʿam ʿiwwer we-ʿeynayim yesh, we-ḥershim we-ʾoznayim lamo.* Bring out the blind people that have eyes, and the deaf that have ears. The same shape: organs present, function absent.

Isaiah 29:10. *Ki nasakh ʿaleykhem YHWH ruaḥ tardemah wa-yeʿaṣṣem ʾet ʿeyneykhem.* The LORD has poured out a spirit of deep sleep and closed your eyes. With 29:18: *we-shameʿu va-yom ha-huʾ ha-ḥershim divrey sefer u-me-ʾofel u-me-ḥoshekh ʿeyney ʿiwrim tirʾenah*, the deaf shall hear and the eyes of the blind shall see, which is the reversal.

Isaiah 35:5. *ʾAz tippaqaḥnah ʿeyney ʿiwrim we-ʾozney ḥershim tippataḥnah.* Then the eyes of the blind shall be opened and the ears of the deaf unstopped. Both organs, both in the passive.

**The idol application, which is the key to the whole inventory.**

Psalm 115:5-7. *Peh lahem we-loʾ yedabberu, ʿeynayim lahem we-loʾ yirʾu, ʾoznayim lahem we-loʾ yishmaʿu, ʾaf lahem we-loʾ yeriḥun, yedeyhem we-loʾ yemishun, ragleyhem we-loʾ yehallekhu.* Mouths and speak not, eyes and see not, ears and hear not, noses and smell not, hands and handle not, feet and walk not.

Psalm 135:15-17 repeats it in shortened form.

And then the sting, which both psalms deliver identically. Psalm 115:8: *kemohem yihyu ʿoseyhem, kol ʾasher boṭeaḥ bahem.* Those who make them shall be like them, and everyone who trusts in them.

**The count.** Eleven passages across five books: Deuteronomy, Isaiah, Jeremiah, Ezekiel, Psalms. Isaiah alone carries five. The inventory is stable, the vocabulary is stable, and the syntax is stable: an organ named, its function named, and the function negated.

Two structural results follow from the count.

**The idol texts supply the corpus's own explanation of the image.** An idol has the organs and no function. A people that trusts an idol becomes like it. So the deficit is not a random affliction; the corpus states a mechanism by which the condition is acquired, and it names the mechanism as resemblance to what one trusts. That is a diagnosis with a cause, offered by the corpus, in the same vocabulary as the deficit texts.

**The reversal is stated in the passive.** Isaiah 35:5's *tippaqaḥnah* and *tippataḥnah* are both nifal. Isaiah 29:18's *tirʾenah* has the eyes as subject. Nobody in these passages opens anybody's eyes; the eyes are opened. Chapter 62's finding about conferral grammar is visible here in a different domain, and the convergence is worth noting even though this book does not build on it.

## CHAPTER 39 · The Hardening Problem, and Why This Book Does Not Solve It

The corpus says the organ was not given, at Deuteronomy 29:3. It says the heart was to be made fat and the eyes shut, at Isaiah 6:10. It says a spirit of deep sleep was poured out, at Isaiah 29:10. And it says the people have the organs and do not use them, at Jeremiah 5:21 and Ezekiel 12:2, and it quotes them refusing, at Jeremiah 6:16.

Those are two accounts and the corpus does not reconcile them. This chapter states why the book does not attempt to.

**The reconciliations available.** There are several and each is respectable.

The hardening can be read as judicial: a response to a prior refusal, so that the sequence is refusal first and hardening second, and the two accounts are stages rather than rivals. Exodus provides the pattern that supports this, since Pharaoh hardens his own heart before God is said to harden it, and the corpus alternates the subject deliberately across the plague cycle.

The hardening can be read as descriptive of outcome expressed in the idiom of intention, which is a recognized feature of the corpus's way of speaking about causation and appears in the prophetic commissioning formulas generally.

The hardening can be read as rhetorical: an assignment stated in its harshest terms to a prophet who will preach for decades to no visible effect, so that the commissioning inoculates him against the interpretation that he failed.

The hardening can be read straightforwardly, as the corpus's assertion that God did what the text says, with the theological consequences accepted rather than managed.

**Why this book takes none of them.** Because the argument does not need one and taking one would cost more than it bought.

The claim Book IV makes is a claim about location: the corpus places the deficit at the receiver rather than in the terminus. That claim holds under every one of the four readings above. On the judicial reading the deficit is at the receiver and incurred. On the descriptive reading it is at the receiver and reported. On the rhetorical reading it is at the receiver and stated harshly. On the straightforward reading it is at the receiver and imposed. In no case is it in the gift.

That is the whole point and it is worth stating in the form of a test. Take any of the four readings. Now ask: does the corpus, on that reading, say the terminus was withheld, delayed, reserved, or given to another? The answer is no on all four, because there is no such clause anywhere in the corpus to be read in any way.

**What the book does claim about the tension.** One thing, and it is a claim about the corpus's habit rather than about the theology. The corpus carries both an unfurnished organ and a declined offer, and reconciles neither. That is a feature of a corpus that preserves rather than harmonizes, and Book X finds nine further instances of the same behaviour. A tradition operating by deletion does not keep both.

**A concession.** A reader who holds that the hardening texts, properly read, make the whole deficit divine in origin will find Book IV's language occasionally more moralized than that reading permits. Where this book says the failure was at the receiver, such a reader should hear the failure was located at the receiver, which is the claim actually being made and is neutral on origin. Where the language slips, the slip is mine and the corrected form is the one just given.

## CHAPTER 40 · Deuteronomy 30:19 · The Same Shape From the Other Side

*Ha-ʿidoti vakhem ha-yom ʾet ha-shamayim we-ʾet ha-ʾareṣ, ha-ḥayyim we-ha-mawet natati le-faneykha, ha-berakhah we-ha-qelalah, u-vaḥarta ba-ḥayyim le-maʿan tiḥyeh ʾattah we-zarʿekha.*

I call heaven and earth to witness against you this day: I have set before you life and death, blessing and curse; therefore choose life, that you may live, you and your seed.

Jeremiah 6:16 records an offer and a refusal. Deuteronomy 30:19 records an offer and a command to accept, and the command presupposes exactly what Jeremiah's refusal exercised.

**The verb of setting is in the perfect.** *Natati le-faneykha*, I have set before you. Done. The four items are placed and the placing is complete.

**The verb of choosing is a command addressed to the hearer.** *U-vaḥarta ba-ḥayyim.* Second person singular imperative in form, waw-consecutive perfect in function, and either way the subject is the person addressed. Nothing chooses on their behalf and nothing is said to prevent the choosing.

**The witnesses are heaven and earth.** The formula belongs to the covenant-lawsuit and it appears at Deuteronomy 4:26, 30:19, 31:28, and 32:1, and at Isaiah 1:2. The invocation of witnesses presupposes a party capable of breach, which presupposes a party capable of compliance.

**The frame is *ha-yom*.** Chapter 3 established that Deuteronomy 30 marks two temporal frames and that the near one is marked five times, at verses 11, 15, 16, 18, and 19. This verse carries the fifth. The choice is available today.

Set the two verses side by side and the shape is one shape from two sides.

Deuteronomy 30:19: the objects are placed, the command is to choose, and the corpus records no answer.
Jeremiah 6:16: the paths are standing, the command is to walk, and the corpus records the answer, and it is no.

Between them they cover the whole structure that Book IV is describing. Something available, an instruction to take it, and a party whose taking or not-taking is the operative variable. In neither passage does anything stand between the hearer and the object. In neither is anything withheld. In neither is an intermediary named.

One further verse belongs beside them and it is the strongest single statement of availability in the corpus. Deuteronomy 30:11-14, which Chapter 3 used to establish that the criterion is native. *Loʾ nifleʾt hiʾ mimmekha we-loʾ reḥoqah hiʾ. Loʾ va-shamayim hiʾ ... we-loʾ me-ʿever la-yam hiʾ ... ki qarov ʾeleykha ha-davar meʾod be-fikha u-vilvavkha la-ʿasoto.* It is not too hard for you, nor far off. It is not in heaven. It is not beyond the sea. It is very near to you, in your mouth and in your heart, to do it.

Three modes of intermediation named and denied, and then the positive: in your mouth and in your heart. The organ named as deficient at Deuteronomy 29:3 is named at 30:14 as the location of the near word, six chapters later in the same book.

The corpus places those two statements in one scroll and does not reconcile them. Chapter 39 has already said why this book does not either.

## CHAPTER 41 · Nowhere a Withheld Terminus

Book IV closes with a negative claim, and a negative claim about a corpus is a claim a reader can break with one verse. It is stated here in a form precise enough to be broken.

**The claim.** In the Hebrew Bible there is no clause that attributes the non-entry into the terminus to an absent, withheld, delayed, reserved, or postponed terminus. Every clause that supplies a reason supplies one located in the heart, the eyes, the ears, the hearing, the memory, or a refusal spoken by the hearers.

**The evidence, gathered.**

Deuteronomy 29:3. The organ not given. Location: heart, eyes, ears.

Psalm 95:8-11. Do not harden your hearts; a people erring in heart; they did not know my ways; they shall not enter my rest. Location: heart, knowing.

Isaiah 6:9-10. Hear and do not understand, see and do not know; heart fat, ears heavy, eyes shut. Location: heart, ears, eyes.

Isaiah 42:19-20. Blind servant, deaf messenger, ears open and not hearing. Location: eyes, ears.

Jeremiah 6:16. The paths stand, the instruction is to walk, and they said we will not walk. Location: a spoken refusal.

Deuteronomy 8:12-14 with Deuteronomy 32:15 and Hosea 13:6. Satisfied, heart lifted, forgot. Location: heart, memory.

Judges, four times. The land was quiet forty years, and the children of Israel again did evil in the sight of the LORD. Location: the people's return to what they had been doing.

Jeremiah 5:21, Ezekiel 12:2, Isaiah 43:8. Organs possessed, functions absent. Location: the organs.

**What is not found.** No clause saying the rest was not yet given. No clause saying it was reserved for a later time. No clause saying it awaited a figure. No clause saying it was given to another party. No clause saying it was insufficient. No clause saying the giver delayed. The corpus's giving-verbs are in the perfect at Joshua 21:44, at 1 Kings 8:56, at 1 Chronicles 22:18, at 1 Chronicles 23:25, at 2 Chronicles 14:6, at 2 Chronicles 15:15, and at 2 Chronicles 20:30, and there is no corresponding set of clauses in which the giving is deferred.

**How to break it.** Produce one verse in which the failure of the terminus is attributed to the terminus. A verse in which the rest is said to be not yet given rather than not yet entered. A verse in which the object rather than the receiver carries the deficiency. One verse is enough and the claim falls.

**Two near-misses, named so that they are not mistaken for finds.**

Deuteronomy 12:9's *loʾ vaʾtem ʿad ʿattah*, you have not yet come. This is a not-yet and it is a not-yet of arrival, with the people as subject of the coming and God as subject of the giving in the same verse. It states that the arrival has not occurred, not that the object is absent. Chapter 22 works it.

Psalm 95:11's *ʾim yevoʾun ʾel menuḥati*, if they shall enter my rest. The oath excludes a generation from entry. It does not withdraw the rest, and the psalm's own *ha-yom* at verse 7 reopens the condition to the hearers. Chapter 26 works it.

Both are about entry. Neither is about the object. And that distinction, between the entering and the given, is the distinction Book III established from the grammar and Book IV has now traced through eleven passages in five books. What Book V takes up is what the corpus did instead.
