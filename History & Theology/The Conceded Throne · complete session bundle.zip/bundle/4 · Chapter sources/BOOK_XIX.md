# BOOK XIX · THE DWELLING

## CHAPTER 161 · The Corpus's Other Menuḥah

Psalm 95:11 says they did not enter my rest. Psalm 132:14 says this is my resting place forever, here I will dwell. One word, one divine suffix, two psalms, two statements.

*Zoʾt menuḥati ʿadey ʿad, poh ʾeshev ki ʾiwwitiha.*

This is my resting place forever; here I will dwell, for I have desired it.

The referent is Zion, named in the preceding verse: *ki vaḥar YHWH be-Ṣiyyon, ʾiwwah le-moshav lo*, for the LORD has chosen Zion, he has desired it for his dwelling.

**Two verbs of desiring in two verses, both with God as subject.** *ʾIwwah* and *ʾiwwitiha*, from *ʾwh*, to desire or long for. The corpus's statement about why the place is chosen is a divine wanting, repeated.

**And the seated verb is *yšb*.** *Poh ʾeshev*, here I will dwell or sit. The same root as Deuteronomy 12:10's *wi-shavtem beṭaḥ*, you shall dwell in safety, and as 1 Chronicles 29:23's *wa-yeshev Shelomoh*, and Solomon sat.

**The relation between the two menuḥah-statements.** Psalm 95:11's is the people's unentered rest. Psalm 132:14's is God's own resting place, occupied.

Two readings.

**They are different objects sharing a word.** One is a condition and the other is a location. On this reading the coincidence of vocabulary is unremarkable.

**They are the same object read from two sides.** God's dwelling is where the people's rest is, and the corpus states that one party is in it and the other did not enter.

**This book prefers the first and records the second**, because the second is attractive and the corpus supplies no clause connecting the two psalms.

**What is not in doubt is the vocabulary's range.** *Menuḥah* denotes, in the corpus's own usage, a condition delivered to a people at Deuteronomy 12:9 and 1 Kings 8:56, a characterization of a man at 1 Chronicles 22:9, an unentered object at Psalm 95:11, and a place God dwells at Psalm 132:14. That is a wide range for a narrow word and it is worth having in view before the temple material is read.

## CHAPTER 162 · The Tabernacle · A Dwelling That Moves

*We-ʿasu li miqdash we-shakhanti be-tokham.* And let them make me a sanctuary, that I may dwell among them. Exodus 25:8.

**The verb is *škn*, to dwell or tent**, and it is the root behind *mishkan*, the tabernacle, and behind the later term for the divine presence that this book does not use because it is post-biblical.

**Two features of the commission.**

**The making is theirs and the dwelling is his.** *We-ʿasu li*, and they shall make for me. *We-shakhanti*, and I will dwell. Two subjects, two verbs, and the second is not conditional on the first in the grammar though it follows it in the sequence.

**The specification is total and it is given.** Exodus 25:9: *ke-khol ʾasher ʾani marʾeh ʾotekha ʾet tavnit ha-mishkan we-ʾet tavnit kol kelaw we-khen taʿasu.* According to all that I show you, the pattern of the tabernacle and the pattern of all its furniture, so shall you make it. The word *tavnit*, pattern, recurs at 25:40 and 26:30 and 27:8.

**And the craftsmen are equipped.** Exodus 31:2-5: *reʾeh qaraʾti ve-shem Beṣalʾel ... wa-ʾamalleʾ ʾoto ruaḥ ʾelohim be-ḥokhmah u-vi-tvunah u-ve-daʿat u-ve-khol melaʾkhah.* See, I have called by name Bezalel, and I have filled him with the spirit of God, in wisdom and understanding and knowledge and all craftsmanship.

**Wisdom, understanding, and knowledge.** Three of the six qualities of Isaiah 11:2, given by a filling, to a metalworker, for the making of furniture. The corpus's first person equipped with a divine spirit for a task is a craftsman.

**And the tabernacle moves.** Numbers 9:15-23: the cloud covers it, and when the cloud is taken up they journey, and where the cloud settles they camp. *ʿAl pi YHWH yisʿu u-ʿal pi YHWH yaḥanu*, at the command of the LORD they journeyed and at the command of the LORD they camped, repeated five times in nine verses.

**The verb at 9:17 for the cloud's settling is *škn*.** *U-vi-meqom ʾasher yishkon sham he-ʿanan sham yaḥanu*. In the place where the cloud settled, there they camped.

**The structural point.** The corpus's first dwelling is portable, its pattern is shown rather than devised, its craftsmen are filled with a spirit, and its location is determined by a cloud. Nothing about it is held.

## CHAPTER 163 · 2 Samuel 7 · The House Nobody Asked For

The dynastic oracle begins with a refusal of a building project and Chapter 59 noted the reversal. This chapter reads it as a temple text.

**7:1-2.** David sits in his house, the LORD has given him rest from all his enemies, and he says to Nathan: *ʾanokhi yoshev be-veyt ʾarazim wa-ʾaron ha-ʾelohim yoshev be-tokh ha-yeriʿah.* I dwell in a house of cedar and the ark of God dwells within curtains.

**Both verbs are *yšb*.** The king dwells and the ark dwells, in one sentence, and the contrast is between the materials.

**7:5-7 is the refusal and it is a question.** *Ha-ʾattah tivneh li vayit le-shivti?* Shall you build me a house to dwell in? And 7:6: *ki loʾ yashavti be-vayit le-mi-yom haʿaloti ʾet benei Yisraʾel mi-Miṣrayim we-ʿad ha-yom ha-zeh, wa-ʾehyeh mithallekh be-ʾohel u-ve-mishkan.* I have not dwelt in a house since the day I brought up the children of Israel from Egypt to this day, but have been moving about in a tent and a tabernacle.

**7:7.** *Ha-davar dibbarti ʾet ʾaḥad shivṭey Yisraʾel ʾasher ṣiwwiti lirʿot ʾet ʿammi ʾet Yisraʾel leʾmor lammah loʾ venitem li beyt ʾarazim?* Did I ever speak a word to any of the tribes of Israel whom I commanded to shepherd my people Israel, saying, why have you not built me a house of cedar?

**Three things in that verse.** The shepherding vocabulary of Book X. *ʿAmmi*, my people. And a rhetorical question establishing that no house was ever requested.

**Then the reversal at 7:11.** *We-higgid lekha YHWH ki vayit yaʿaseh lekha YHWH.* The LORD declares that the LORD will make you a house.

**The word *bayit* carries two senses and the oracle turns on the pun.** A building and a dynasty. David proposes to build a building; God says he will build a dynasty; and the building will be built by the son.

**7:13.** *Huʾ yivneh bayit li-shmi.* He shall build a house for my name.

*Li-shmi*, for my name. Not for me. The formula recurs at 1 Kings 8:17-20 five times in David's and Solomon's speeches, and Deuteronomy uses it throughout for the chosen place: *ha-maqom ʾasher yivḥar YHWH le-shakken shemo sham*, the place the LORD will choose to make his name dwell there, at Deuteronomy 12:11, 14:23, 16:2, 16:6, 16:11, 26:2.

**The name-formula is the corpus's own qualification of the dwelling.** What is in the house is the name.

## CHAPTER 164 · 1 Kings 8 · Solomon's Own Qualification

The dedication prayer is the corpus's most extended treatment of what a temple is and it contains its own disclaimer.

**8:12-13, the opening.** *YHWH ʾamar li-shkon ba-ʿarafel. Banoh vaniti beyt zevul lakh, makhon le-shivtekha ʿolamim.* The LORD said he would dwell in thick darkness. I have surely built you an exalted house, a place for you to dwell in forever.

**And 8:27, fifteen verses later.** *Ki ha-ʾumnam yeshev ʾelohim ʿal ha-ʾareṣ? Hinneh ha-shamayim u-shmey ha-shamayim loʾ yekhalkelukha, ʾaf ki ha-bayit ha-zeh ʾasher baniti.*

But will God indeed dwell on the earth? Behold, heaven and the heaven of heavens cannot contain you; how much less this house that I have built.

**The builder states, in the dedication, that the building cannot contain the one it is built for.** That is the corpus placing its own qualification in the mouth of the man at the moment of completion.

**And the prayer's operative request is not for presence but for attention.** 8:29: *li-hyot ʿeynekha fetuḥot ʾel ha-bayit ha-zeh laylah wa-yom ʾel ha-maqom ʾasher ʾamarta yihyeh shemi sham, li-shmoaʿ ʾel ha-tefillah.* That your eyes may be open toward this house night and day, toward the place of which you said, my name shall be there, to listen to the prayer.

**Eyes open and a listening.** The two organs of Book IV, requested of God rather than of the people, in the temple's dedication.

**And the prayer's structure is seven petitions, each following the same shape.** A situation, a turning toward the house, and then *we-ʾattah tishmaʿ ha-shamayim*, and you shall hear in heaven. The formula recurs at 8:32, 8:34, 8:36, 8:39, 8:43, 8:45, and 8:49.

**Seven hearings, all located in heaven, all requested toward a house that cannot contain the hearer.**

**8:41-43 extends it to the foreigner.** *We-gam ʾel ha-nokhri ʾasher loʾ me-ʿammekha Yisraʾel huʾ u-vaʾ me-ʾereṣ reḥoqah le-maʿan shemekha ... we-ʾattah tishmaʿ ha-shamayim ... we-ʿasita ke-khol ʾasher yiqraʾ ʾeleykha ha-nokhri.* And also the foreigner who is not of your people Israel, when he comes from a far country for your name's sake, you shall hear in heaven and do according to all the foreigner calls to you for.

**And the stated purpose is knowledge.** 8:43: *le-maʿan yedʿun kol ʿammey ha-ʾareṣ ʾet shemekha le-yirʾah ʾotekha ke-ʿammekha Yisraʾel.* That all the peoples of the earth may know your name and fear you as your people Israel.

**The temple's stated function in its own dedication is to be a direction for prayer whose hearing happens elsewhere, and its stated reach includes the foreigner, and its stated purpose is a knowing.**

**And then 8:56, worked at Chapter 25.** Blessed be the LORD who has given rest to his people Israel.

The dedication ends on the terminus vocabulary, with the giver named, the recipient the people, and the measurement taken against Moses.

## CHAPTER 165 · The Glory That Departs

Ezekiel narrates the presence leaving, in stages, and the staging is the point.

**Ezekiel 8-11 is one vision.** The prophet is taken by a lock of his head to Jerusalem, shown four abominations in the temple in escalating order, and then shown the departure.

**9:3.** *U-khevod ʾelohey Yisraʾel naʿalah me-ʿal ha-keruv ʾasher hayah ʿalaw ʾel miftan ha-bayit.* The glory of the God of Israel went up from the cherub on which it was, to the threshold of the house.

**10:4.** *Wa-yarom kevod YHWH me-ʿal ha-keruv ʿal miftan ha-bayit.* Repeated.

**10:18.** *Wa-yeṣeʾ kevod YHWH me-ʿal miftan ha-bayit wa-yaʿamod ʿal ha-keruvim.* The glory went out from the threshold and stood over the cherubim.

**10:19.** They lifted their wings and went up from the earth, and stood at the door of the east gate.

**11:23.** *Wa-yaʿal kevod YHWH me-ʿal tokh ha-ʿir wa-yaʿamod ʿal ha-har ʾasher mi-qedem la-ʿir.* The glory of the LORD went up from the midst of the city and stood on the mountain which is east of the city.

**Five stages.** From the cherub to the threshold. At the threshold. From the threshold to the cherubim. To the east gate. To the mountain east of the city.

**The departure is slow and the corpus narrates every stage.** That is not how the corpus narrates most things and the deliberateness is worth noticing.

**And 11:16 supplies the interim provision.** *Ki hirḥaqtim ba-goyim we-khi hafiṣotim ba-ʾaraṣot, wa-ʾehi lahem le-miqdash meʿaṭ ba-ʾaraṣot ʾasher baʾu sham.* Though I have removed them far off among the nations and scattered them among the countries, yet I have been to them a sanctuary in small measure in the countries where they have come.

*Miqdash meʿaṭ*, a sanctuary in small measure, or a little sanctuary. The corpus supplies, in the middle of the departure vision, a statement that the sanctuary function continues without the building.

**And the return is narrated at 43:1-5**, by the same gate. *We-hinneh kevod ʾelohey Yisraʾel baʾ mi-derekh ha-qadim ... wa-yavoʾ kevod YHWH ʾel ha-bayit derekh shaʿar ʾasher panaw derekh ha-qadim.* The glory came from the way of the east and entered the house by the gate facing east.

**43:7.** *Wa-yoʾmer ʾelay ben ʾadam ʾet meqom kisʾi we-ʾet meqom kappot raglay ʾasher ʾeshkon sham be-tokh benei Yisraʾel le-ʿolam.* And he said to me: son of man, the place of my throne and the place of the soles of my feet, where I will dwell among the children of Israel forever.

*Meqom kisʾi*, the place of my throne. In the temple vision of the book that gives its prince a bounded portion and a prescribed route.

## CHAPTER 166 · The Presence and the Terminus

Book XIX closes by relating the dwelling material to the argument.

**The corpus's dwelling vocabulary and its terminus vocabulary overlap at three points.**

**Psalm 132:14.** *Zoʾt menuḥati ʿadey ʿad, poh ʾeshev.* The terminus noun applied to the divine dwelling.

**1 Chronicles 28:2.** David's speech: *ʾani ʿim levavi li-vnot beyt menuḥah la-ʾaron berit YHWH we-la-hadom ragley ʾeloheynu.* I had it in my heart to build a house of rest for the ark of the covenant of the LORD and for the footstool of our God.

*Beyt menuḥah*, a house of rest. The terminus noun in a construct with a building, in the Chronicler's version of the 2 Samuel 7 scene.

**And Isaiah 66:1.** *Koh ʾamar YHWH, ha-shamayim kisʾi we-ha-ʾareṣ hadom raglay, ʾey zeh vayit ʾasher tivnu li we-ʾey zeh maqom menuḥati?*

Thus says the LORD: heaven is my throne and the earth is my footstool; where is the house you would build for me, and where is the place of my rest?

*Meqom menuḥati*, the place of my rest, in a rhetorical question denying that a built house can be it.

**Three sites. One says the place is Zion and God dwells there. One has a king proposing a house of rest for the ark. And one asks where such a place could possibly be.**

**And Isaiah 66:2 supplies the answer, and it is not a location.** *We-ʾet kol ʾelleh yadi ʿasatah wa-yihyu khol ʾelleh neʾum YHWH, we-ʾel zeh ʾabbiṭ ʾel ʿani u-nekheh ruaḥ we-ḥared ʿal devari.*

All these things my hand has made, and so all these things came to be, says the LORD. But to this one will I look: to the poor and contrite in spirit, and who trembles at my word.

**The corpus's sharpest question about where its own rest could be located is answered with a description of a person.** *ʿAni u-nekheh ruaḥ we-ḥared ʿal devari.* Poor, contrite in spirit, and trembling at the word.

**And *ḥared ʿal devari*, trembling at my word, is a reception.** The organ of Book IV, functioning.

**What Book XIX establishes.**

The corpus's dwelling is portable before it is fixed, is qualified by its own builder at the moment of dedication, is described as containing a name rather than a presence, departs in five narrated stages, is replaced in the interim by a sanctuary in small measure, and is finally denied as a location for the divine rest in a verse that answers the question with a person's disposition.

**That is the same structure the whole book has been tracing, in a fourth register.** Not a possession. Not a container. A relation, stated in the corpus's own vocabulary, with the deficit's own organ as the condition.
