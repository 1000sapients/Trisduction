# BOOK XIV · THE RESULT

## CHAPTER 126 · The Removability Result · Six Substantive Contents

The criterion of Chapter 2 is now applied and this chapter states what survives the strip.

**Six contents are substantive under the test**, meaning the corpus states each somewhere in a passage naming no eschatological figure and no dated event.

**Covenant fidelity.** Deuteronomy 30:19-20: I have set before you life and death; choose life; to love the LORD your God, to obey his voice, and to cleave to him. Deuteronomy 10:12-13: what does the LORD your God ask of you, answered in five infinitives.

**Subordination of power to the teaching.** Deuteronomy 17:18-20: the king writes a copy, reads it all his days, and his heart is not lifted above his brothers. 1 Samuel 12:14-15: if you fear the LORD and serve him and obey his voice, then both you and the king who reigns over you shall follow the LORD your God.

**Refusal of self-certification.** Deuteronomy 13:2-6: a prophet or dreamer who gives a sign that comes to pass and says let us go after other gods shall not be heeded. Deuteronomy 18:21-22: the test of a word not spoken by the LORD is that it does not come to pass. Proverbs 27:2: *yehallelkha zar we-loʾ fikha*, let another praise you and not your own mouth. Jeremiah 9:22-23: the subtraction of wisdom, might, and riches.

**Hope preserved under collapse.** Ezekiel 37:11: *ʾaveda tiqwatenu nigzarnu lanu*, our hope is lost, we are cut off, quoted by God as the people's own words and answered in the following verses. Lamentations 3:21-24: *zoʾt ʾashiv ʾel libbi ʿal ken ʾoḥil, ḥasdey YHWH ki loʾ tamnu*, this I recall to my heart, therefore I have hope: the mercies of the LORD are not consumed. Jeremiah 29:11-14: *ki ʾanokhi yadaʿti ʾet ha-maḥashavot ʾasher ʾanokhi ḥoshev ʿaleykhem ... maḥshevot shalom we-loʾ le-raʿah la-tet lakhem ʾaḥarit we-tiqwah.*

**The justice-arc.** Amos 5:24: *we-yiggal ka-mayim mishpaṭ u-ṣedaqah ke-naḥal ʾeytan*, let justice roll down like waters and righteousness like an ever-flowing stream. Psalm 72:12-14, though that psalm is figure-indexed and its content is stated elsewhere without one. Isaiah 1:17: *dirshu mishpaṭ ʾashsheru ḥamoṣ shifṭu yatom rivu ʾalmanah.* Micah 6:8.

**And the terminus.** Deuteronomy 12:9. Joshua 21:44. 1 Kings 8:56. 1 Chronicles 22:9. Ezekiel 37:14. Psalm 95:11. Isaiah 11:9. Isaiah 2:4. Habakkuk 2:14.

**One note on the fifth entry.** Amos 5:24's anchor is the strongest of the justice-arc's because Amos contains no royal-figure material at all, so the content is stated in a book where the strip is vacuous. That is the cleanest form of a substantive verdict: a whole book carrying the content and no figure.

**And one note on the sixth.** The terminus has nine anchors across seven books, which is more than any of the other five. The content this book has been tracing is the one the corpus states most often without a figure.

## CHAPTER 127 · What Fails the Strip · The Act-Layer

The criterion cuts and this chapter states what it cuts.

**What fails is the act-layer**: the gathering, the return to the land, the rebuilding, the restoration of offices, the reunification of the two houses.

**The failing sites.** Ezekiel 37:21, worked at Chapter 4. Ezekiel 36:24. Deuteronomy 30:3-5. Jeremiah 23:3. Isaiah 56:8. Micah 2:12. Psalm 147:2. Amos 9:11. In every case the act is the main verb and the whole content, and deleting the act leaves no residual predicate.

**A failed strip is not a demotion and Chapter 4 said so.** This chapter says it again because it is the point at which the whole book is most likely to be misread.

Ezekiel 37 is one of the great passages of the corpus. Its failure under a test that measures availability-without-a-figure says nothing about its importance, its truth, its centrality, or its standing. It says that the corpus does not state that content in a figure-free clause, which is a fact about the content's grammar and nothing else.

**And the criterion's verdict here is the least interesting thing about these passages.** What is interesting is what the corpus does with them, which is the subject of the next chapter.

## CHAPTER 128 · The Purpose Clauses · Road and Destination in the Corpus's Own Grammar

The act-layer fails the strip. The corpus subordinates it grammatically wherever it states it. This chapter sets out the evidence, and it is the strongest single body of evidence in the book because the subordination is syntactic rather than interpretive.

**Deuteronomy 30:3-6.** The LORD will return your captivity and have compassion and gather you from all the peoples. If your outcasts are at the ends of heaven, from there he will gather you and from there he will take you. And he will bring you into the land your fathers possessed, and you shall possess it, and he will do you good and multiply you above your fathers.

**And then 30:6.** *U-mal YHWH ʾeloheykha ʾet levavekha we-ʾet levav zarʿekha le-ʾahavah ʾet YHWH ʾeloheykha be-khol levavkha u-ve-khol nafshekha **le-maʿan ḥayyekha**.*

And the LORD your God will circumcise your heart and the heart of your seed, to love the LORD your God with all your heart and all your soul, **that you may live**.

**The gathering runs for three verses and lands on a heart-circumcision, and the heart-circumcision carries a purpose clause whose object is life.** The acts are stated and then subordinated, in the corpus's own syntax, by *le-maʿan*.

**Ezekiel 36:24-28.** I will take you from among the nations and gather you from all the countries and bring you into your own land. I will sprinkle clean water on you and you shall be clean. I will give you a new heart and put a new spirit within you; I will remove the heart of stone and give you a heart of flesh. I will put my spirit within you and cause you to walk in my statutes. And you shall dwell in the land I gave your fathers.

**And then 36:28b.** *Wi-hyitem li le-ʿam wa-ʾanokhi ʾehyeh lakhem le-ʾelohim.* And you shall be my people and I will be your God.

**The sequence lands on the covenant formula.** Six acts and a relation, in that order, with the relation last.

**Ezekiel 37:21-23.** I will take the children of Israel from among the nations and gather them and bring them into their own land. And I will make them one nation. And one king shall be king over them all. They shall not defile themselves any more with their idols. I will save them and cleanse them.

**And then 37:23b.** *We-hayu li le-ʿam wa-ʾani ʾehyeh lahem le-ʾelohim.* Same formula, same position.

**And 37:14 supplies the terminus in the settling-root**, at the end of the preceding oracle, which Chapter 28 worked.

**Three sequences, three books' worth of act-material, and each lands somewhere else.** Deuteronomy 30 lands on a purpose clause. Ezekiel 36 and 37 land on the covenant formula. None of the three ends on the act.

**The result, stated exactly.** The corpus files the acts as road and states the destination separately. That is not a claim that the acts are unreal, unimportant, or optional. It is a claim about where the corpus's own grammar puts them, and the grammar is checkable at three named passages in two books.

## CHAPTER 129 · Positioning Against the Prior Literature

Six positions and this book's relation to each.

**Menuḥah as land-gift, with an unresolved already-and-not-yet between Joshua and Psalm 95.** Von Rad and the literature following him. **This book is downstream of it.** The seam is not claimed as new. What is added is the removability criterion, the executed census of Book II, and the resulting sort of the royal material as means.

**The monarchy tension resolved by source division into pro- and anti-monarchic strands.** Classical source criticism on 1 Samuel 8 through 12, and the Deuteronomistic History hypothesis. **No position taken.** The book treats the final form's retention of both as the datum, which is compatible with any account of how it got there.

**Messianism as a comparatively late development not present in the pre-exilic royal texts.** Mowinckel and successors. **Compatible.** The escalation sequence redescribes the same material by content and commits to no dating beyond the corpus's own narrative order for its first three stages.

**The royal and future-royal texts as the interpretive centre toward which the corpus tends.** Much confessional and canonical-critical reading. **Directly opposed at the sorting**, though not on the reality or importance of the material. This book argues the corpus itself subordinates the acts to a state it names independently, and does so in three purpose clauses.

**The sabbath as institution and sign, studied on its own.** The extensive sabbath literature. **Adjacent.** This book's interest is in *menuḥah* as the promise's terminus rather than in sabbath observance as such, and it connects the two only through the root-field of Book II.

**Isaiah 6:9-10 as a hardening motif to be explained theologically or redactionally.** The hardening literature. **Used differently.** The book takes 6:9-10 with Deuteronomy 29:3, Isaiah 42:19, and Jeremiah 6:16 as a converging diagnosis of reception rather than as a problem about divine intent, and Chapter 39 states why it declines to solve the problem.

**A seventh position deserves naming because it is the one closest to this book.** The reading on which the Deuteronomistic material is fundamentally about obedience and its consequences, with the monarchy a subordinate theme. This book is adjacent to that and differs in one respect: it locates the corpus's terminus in a specific lexeme rather than in a general condition, and the specificity is what makes the census of Book II possible.

## CHAPTER 130 · Falsification · The Three Criteria and Their Results

Chapter 6 stated three criteria before the evidence. This chapter returns them with results.

**F1, the terminus criterion.** If the terminal clauses are systematically figure-indexed, Book III fails.

**Executable:** run the concordance across the corpus, isolate terminal-position sites, and count agent-requirements.

**Result: does not fail, on the available instrument.** Book II executed an English-side census over the whole corpus: 878 field sites, 114 terminal-position candidates, 23 machine-marked. Of the 23, six were the editor's notes, six were the wrong sense of the English word, and eleven were genuine terminus sites at which a king stood as recipient with God named as giver. A direct subject test over the whole corpus returned zero verses in which a royal figure is the grammatical subject of giving rest.

**The residual debt is stated at Chapter 19 and is not discharged.** The Hebrew-side census is still owed and a reader with a Hebrew concordance can execute it.

**F2, the concession criterion.** If the corpus withdraws the concession rather than re-issuing it at higher intensity, Books V and VIII fail.

**Executable:** search for any withdrawal formula.

**Result: none exists.** 2 Samuel 7:15 explicitly bars the withdrawal against a named precedent. Hosea 13:11's taking is a taking of a king rather than a repeal of the institution, and Chapter 50 gave three reasons. Every removal in the corpus is the removal of an occupant: Saul, the northern dynasties, Coniah, Zedekiah.

**F3, the receiver criterion.** If Deuteronomy 29:3, Psalm 95:11, Isaiah 6:9-10, and Isaiah 42:19-20 can be read as locating the failure in an absent or withheld terminus, Book IV dissolves.

**Executable:** identify the subject of the deficiency in each.

**Result: all four place it in the heart, the ears, the eyes, or the hearing.** And Chapter 41 extended the search across eleven passages in five books and found no clause anywhere attributing the non-entry to the terminus. Chapter 41 also stated how to break the claim: produce one verse.

**Two further falsifiers were generated by the argument itself and are recorded here.**

**Chapter 100's negative.** Produce one verse in which a royal or messianic figure is the grammatical subject of the gathering. Eight sites in six books were surveyed and in every one the gatherer is God.

**Chapter 84's negative.** Produce one passage in which a figure gives a heart, opens an ear, or supplies knowledge to a people. This book has not found one. Jeremiah 3:15's shepherds who feed with knowledge and understanding is the closest, and it is plural and unnamed.

**And two claims that were falsified during the work are recorded as dead rather than removed.**

**The partial-removability claim.** An earlier version held that the messianic frame was only partly removable because the restoration material could not be stated without the act-layer. Ezekiel 37:14 falsified it: the corpus states the terminus in the settling-root at the end of the act-sequence.

**The Zechariah 6:13 fusion reading.** An earlier version read 6:13 as fusing two offices in one person. *Beyn shenehem*, between them both, falsified it.

## CHAPTER 131 · The Limit Case · What Would Fall If the Figure Arrived

The sharpest question a critic can ask is what this book has at stake, and the answer is nothing.

**Suppose a royal figure of the expected kind arrives.** What in this book falls?

**Book II's census stands.** 878 field sites, 114 terminal candidates, zero verses with a royal subject of giving rest. An arrival does not change what the corpus says.

**Book III's terminus stands.** Named in the settling-root, delivered under Joshua, announced under Solomon, held four times in Judges, recorded as unentered at Psalm 95:11.

**Book IV's deficit stands.** Eleven passages, five books, three organs, and no clause attributing the failure to the terminus.

**Book V's concession stands.** The refusal at Judges 8:23, the demand quoted in advance at Deuteronomy 17:14, the itemized bill, the unanswered-outcry clause, the confession at 1 Samuel 12:19.

**Book VI's conferral grammar stands.** Fifteen sites, six books, two languages. An arriving figure who received what he holds would be the sixteenth.

**Books VIII and XII stand.** The escalation is a description of what the corpus does across eight stages, and an arrival at the end of it is the arrival of a means.

**The argument is that the figure is a means, and a means that arrives is a means that has arrived.**

No claim in this book rests on non-arrival. None predicts arrival. None adjudicates whether any historical claimant met the description. A reader looking for a book that argues against a messiah has picked up the wrong one, and a reader looking for a book that argues for one has too.

**And the converse case.** Suppose no figure ever arrives. Does that vindicate the book? No, and for the same reason. The book's claims are about the corpus's arrangement of its own materials, and non-arrival would be as irrelevant to them as arrival.

**What would actually falsify the book** is stated at Chapter 130 and is entirely internal: a verse. One verse with a royal subject of giving rest. One verse attributing the non-entry to the terminus. One verse with a figure gathering. One withdrawal formula. Any of them and the corresponding book fails.

That is the appropriate stake for a study of a corpus, and it is the only stake this book has.

## CHAPTER 132 · Limits, Debts, and What Is Carried as Contested

**The principal debt is the Hebrew census.** Book II executed an English-side pass and stated at Chapter 19 exactly what it cannot do. The root-level ratio, the pericope-boundary test, the negative field, the verse identification beyond the quoted sites, and the OCR noise floor are all owed. The central result is a grammatical one and grammar is what English preserves best, so the direction is unlikely to reverse, but every figure in Book II should be treated as provisional.

**Two philological points are carried as contested and not silently resolved.** The referent of *soferim* and the parsing of *ʿasah* at Jeremiah 8:8. The subject of *wa-yitten* at Genesis 14:20. In each case the argument is constructed to hold under either reading.

**The index-type classification is an instrument of this book and not a property of the text.** Chapter 4 said so and it bears repeating at the end. The corpus performs the stripping operation, at Deuteronomy 30, Micah 6, Jeremiah 9, and Deuteronomy 10. It does not perform the taxonomy. The taxonomy is mine.

**The escalation sequence is ordered by content and not by date.** Chapters 8 and 75 said so twice and a reader who takes it as a compositional claim has taken more than is offered.

**The pair at Chapter 88 is the most contestable in the book.** Isaiah 11:1's two nouns may be a synonymous parallelism, and if they are, the Job 14:8 tension dissolves. The observation is offered with the objection stated at full strength.

**Chapter 39's decision not to resolve the hardening problem is a limit and not a finding.** A reader who holds that the hardening texts make the deficit wholly divine in origin will find this book's language occasionally more moralized than that reading permits, and the corrected form is given there.

**Chapter 125's standard applies to this book.** A corpus that states two things and reconciles neither has been read here by a reader who extracted one coherent position from it. That extraction is an interpretation. It is offered as one and the falsifiers of Chapter 130 are the form in which it can be tested.

**And one further limit, which is about the author rather than the argument.** This book is written from outside the guild and from a position of religious commitment, and states this plainly rather than implying a neutrality it does not have. The method is designed to make that irrelevant: the single-corpus constraint, the stated criterion, the executed census with its stated debt, and the falsification criteria are there so that the argument can be checked by a reader who shares none of the author's commitments and rejected by one who shares all of them.

## CHAPTER 133 · Conclusion · The Rest Was Given, It Was Not Entered

The Hebrew Bible names the terminus of its promise in a root whose sense is settlement and not recuperation. It states that terminus as not yet reached at Deuteronomy 12:9, as delivered at Joshua 21:44 and twice more in that book, as held four times in Judges under four ordinary deliverers, as announced already given at 1 Kings 8:56 at the dedication of the temple, and as not entered at Psalm 95:11.

It locates the failure of entry in the hearing, the heart, the eyes, and a refusal spoken by the hearers themselves, across eleven passages in five books, and nowhere in a gift withheld.

It grants a visible monarchy against an itemized prosecution and a notice that the resulting outcry will go unanswered, seats the king on a throne it repeatedly calls God's, and subordinates the occupant to a written law he copies from another office's exemplar and reads for life.

When kings fail it re-issues the grant at higher intensity, eight times, without ever withdrawing it and without ever pointing back to the terminus it had already named.

And across the whole of that escalation, from a man anointed from a flask who hides among the baggage to one like a son of man receiving everlasting dominion in a night vision, the grammar by which the figure holds what he holds never changes. The verb is passive or the subject is God. At 2 Samuel 7:8, at Psalm 2:7, at Psalm 45:8, at Psalm 110:1, at Isaiah 9:5, at 1 Chronicles 29:23, at Ezekiel 34:23, and at Daniel 7:14 alike. And the title itself is a passive participle, naming what was done to its bearer.

**What the corpus does not do is confuse the two.** It states the destination in clauses containing no figure and no date, and it places the acts of gathering and restoration under purpose clauses whose object is the state those acts move toward. The road is real and the corpus commands it. It is simply not the destination, and the corpus says so in its own grammar.

That the shoot grows and the stump dies in the dust. That the persisting part is the root and the trigger is water already in the ground. That the paths are ancient and the instruction is to walk them and the answer recorded is *loʾ nelekh*, we will not walk. That the man named for the rest announced it in the temple and did not remain in it. That a king wrote a psalm calling himself a sheep. That the exile was priced in sabbaths the land did not get.

These are the corpus's own images for a gift that stands and is not taken up.

The census found no verse in which a king gives rest, and found eleven in which a king receives it. The subject test over the whole corpus returned one apparent counterexample and it was a commentator's note written in 1913.

**The rest was given. It was not entered. And on the corpus's own account the failure was never in the giving.**
