# BOOK VI · THE SEAT

## CHAPTER 53 · 1 Chronicles 29:23 · The Throne of YHWH

*Wa-yeshev Shelomoh ʿal kisseʾ YHWH le-melekh taḥat Dawid ʾaviv wa-yaṣlaḥ, wa-yishmeʿu ʾelaw kol Yisraʾel.*

And Solomon sat on the throne of the LORD as king in place of David his father, and prospered, and all Israel obeyed him.

The construct is *kisseʾ YHWH*. The throne of the LORD. Not the throne of Israel, not the throne of David, not the throne of the kingdom. The throne of the LORD, with Solomon sitting on it.

This is one of the most consequential three-word phrases in the Hebrew Bible for the argument of this book, and it is worth establishing first that it is not a slip.

**The Chronicler uses the construction three times in one work.**

**1 Chronicles 28:5**, of the son chosen to succeed: *wa-yivḥar bi-Shelomoh veni la-shevet ʿal kisseʾ malkhut YHWH ʿal Yisraʾel*. He chose Solomon my son to sit on the throne of the kingdom of the LORD over Israel. Here the construct is doubled: the throne of the kingdom of the LORD.

**1 Chronicles 29:23**, the seating itself, quoted above.

**2 Chronicles 9:8**, in the mouth of the queen of Sheba: *barukh YHWH ʾeloheykha ʾasher ḥafeṣ bekha le-titkha ʿal kisʾo le-melekh la-YHWH ʾeloheykha.* Blessed be the LORD your God who delighted in you, to set you on his throne as king for the LORD your God.

The third occurrence is the decisive one and it should be read slowly. *ʿAl kisʾo*, on his throne, with the pronoun referring to YHWH from the preceding clause. *Le-melekh*, as king. *La-YHWH ʾeloheykha*, for the LORD your God.

**The beneficiary of the kingship is named, and it is not the king.** The lamed of *la-YHWH* is a lamed of advantage or of purpose: king for the LORD your God. Solomon sits on a throne belonging to another, as king on behalf of that other.

Three attempts to soften this are available and each fails on a specific piece of evidence.

**The honorific reading**, on which throne of the LORD is a pious way of saying throne of Israel-under-God, a compliment rather than a statement of ownership. This does not survive being paired with an explicit assertion of ownership by the honoree's own predecessor, twelve verses earlier. **1 Chronicles 29:11**: *lekha YHWH ha-gedullah we-ha-gevurah we-ha-tifʾeret we-ha-neṣaḥ we-ha-hod ki khol ba-shamayim u-va-ʾareṣ, lekha YHWH ha-mamlakhah we-ha-mitnasseʾ le-khol le-roʾsh.* Yours, LORD, is the greatness and the power and the glory and the victory and the majesty, for all in heaven and earth is yours; yours, LORD, is the kingdom, and you are exalted as head above all. *Lekha YHWH ha-mamlakhah*: yours is the kingdom. Twelve verses later a man sits on the throne of it.

**The scribal-error reading**, on which the text is corrupt and should read throne of Israel. There is no manuscript support for this and the phrase occurs three times in variant forms, which is the opposite of what a single corruption looks like.

**The Chronicler's-idiosyncrasy reading**, on which this is one late writer's theological embellishment and not the corpus's position. This is the strongest of the three and it is partly right: the phrase is the Chronicler's and Samuel-Kings does not use it. What it cannot do is remove the phrase from the corpus. The Chronicler is inside the canon and his three statements are three statements. And Chapter 55 finds the same structure in a psalm that is not his, and Chapter 61 finds it in Ezekiel.

Two features of the immediate context sharpen the reading further.

**The seating is in the middle of a chapter about giving.** 1 Chronicles 29 is the account of the offerings for the temple, and its theological centre is David's prayer at 29:14: *ki mimmekha ha-kol u-mi-yadkha natannu lakh*, for all things come from you, and of your own have we given you. The chapter's argument is that nothing given to God originated with the giver. The seating at verse 23 falls inside that frame.

**The verb of sitting is ordinary.** *Wa-yeshev*, and he sat. The corpus does not use an elevated verb, does not describe an ascent, and does not narrate an enthronement rite. A man sits down on a piece of furniture that belongs to someone else, and the corpus says whose.

## CHAPTER 54 · Two More Chronicler Sites, and What Three Occurrences Establish

Chapter 53 quoted the three occurrences. This chapter asks what three establishes that one would not.

**One occurrence is a phrase.** A single instance of *kisseʾ YHWH* could be idiom, hyperbole, a fossilized expression, or a scribal artefact. Any of those would make it unsafe to build on.

**Three occurrences in one work, in three different constructions, in three different speech situations, is a usage.** 28:5 is David speaking to the assembly about the choice of his successor. 29:23 is the narrator reporting the accession. 2 Chronicles 9:8 is a foreign queen speaking to Solomon in praise. Three registers, three speakers, one construction. That distribution is what distinguishes a writer's settled way of describing a thing from a phrase that slipped through.

**And the third occurrence adds a term the other two do not have.** *La-YHWH ʾeloheykha*, for the LORD your God. The queen of Sheba does not merely repeat the ownership; she states the purpose. Whoever composed her speech understood the construction well enough to extend it.

Two further sites in Chronicles belong beside the three and are usually not brought into the discussion.

**1 Chronicles 17:14**, the Chronicler's version of the dynastic oracle. Where 2 Samuel 7:16 reads *we-neʾman beytekha u-mamlakhtekha ʿad ʿolam le-faneykha*, your house and your kingdom shall be established forever before you, the Chronicler reads *we-haʿamadtihu be-veyti u-ve-malkhuti ʿad ha-ʿolam we-khisʾo yihyeh nakhon ʿad ʿolam*. I will set him in **my** house and in **my** kingdom forever, and his throne shall be established forever.

The pronouns have moved. Samuel has your house and your kingdom, addressed to David. Chronicles has my house and my kingdom, spoken by God, with the throne alone assigned to the son. That is a systematic change and it runs in the direction Chapter 53 described.

**2 Chronicles 13:8**, in the mouth of Abijah addressing the northern army: *we-ʿattah ʾattem ʾomerim le-hitḥazzeq lifney mamlekhet YHWH be-yad benei Dawid.* And now you think to withstand the kingdom of the LORD in the hand of the sons of David.

*Mamlekhet YHWH be-yad benei Dawid*: the kingdom of the LORD in the hand of the sons of David. Ownership and custody in one construct chain, with the Davidides holding rather than owning.

**Five sites.** Three with *kisseʾ*, one with the pronoun shift in the dynastic oracle, one with *mamlekhet YHWH* held in a hand. The Chronicler has a consistent position and states it five times in five ways.

One further consideration should be recorded because it cuts against a lazy reading of the Chronicler as a royalist. He is writing after the monarchy has ended, for a community without a king, under Persian administration. On the usual account his purpose is to legitimate the temple community by grounding it in the Davidic past. If that is right, then the systematic relocation of ownership from the dynasty to God is a strange move for a royalist to make, and a natural one for a writer explaining to a kingless community that what mattered about the kingdom was never in the dynasty's possession.

This book does not claim to know his purpose. It records that the five sites are consistent, that they run one direction, and that the direction is the one Books III through V have been tracing from entirely different material.

## CHAPTER 55 · Psalm 110:1 · The Seat Is Offered, and the Offerer Named

*Neʾum YHWH la-ʾadoni, shev li-mini ʿad ʾashit ʾoyveykha hadom le-ragleykha.*

The utterance of the LORD to my lord: sit at my right hand until I make your enemies a footstool for your feet.

This is the corpus's most exalted single statement about a royal figure and it is also, read grammatically, its clearest statement of conferral. Both facts are in one verse and neither cancels the other.

**The opening formula is a prophetic one.** *Neʾum YHWH*, the utterance of the LORD, is the standard prophetic citation formula, used hundreds of times across the prophets to introduce divine speech. Here it introduces a speech addressed to a human figure by a speaker who is not that figure.

**The addressee is *ʾadoni*, my lord.** A human superior. The corpus uses *ʾadoni* constantly for a person of higher rank addressed by an inferior: Genesis 23:6 of Abraham, 1 Samuel 24:9 of Saul, 1 Kings 1:13 of David. The vocalization is not the divine one and the psalm's superscription attributes it to David, which sets up the well-known question of who is addressing whom that this book does not need to enter.

**The seat is offered by imperative.** *Shev li-mini*, sit at my right hand. The verb is a command from the speaker to the addressee, and the location is defined relative to the speaker. It is his right hand. The addressee is given a position at somebody else's side.

**The subjugation is the speaker's work.** *ʿAd ʾashit ʾoyveykha hadom le-ragleykha.* Until **I** make your enemies a footstool. The first person is the speaker's and the enemies are the addressee's. The addressee does not defeat them; he sits while they are made into furniture.

That grammatical arrangement is the whole finding of Book VI in one verse and it appears in the psalm the tradition has most consistently read as the high point of royal exaltation. The exaltation and the conferral are not competing readings. The verse says both and it says the second in the grammar.

**Verse 2 continues the pattern.** *Maṭṭeh ʿuzzekha yishlaḥ YHWH mi-Ṣiyyon.* The rod of your strength the LORD shall send from Zion. The rod is the addressee's, *ʿuzzekha*; the sending is YHWH's.

**Verse 3 is textually difficult and this book makes no use of it.** *ʿAmmekha nedavot be-yom ḥeylekha be-hadrey qodesh me-reḥem mishḥar lekha ṭal yalduteykha* is one of the most contested verses in the Psalter, with the Masoretic Text, the Septuagint, and the versions diverging substantially. No argument here depends on it and none is built on it.

**Verse 4 is the second conferral and Chapter 56 works it.**

**Verse 5 reverses the position.** *ʾAdonay ʿal yeminkha maḥaṣ be-yom ʾappo melakhim.* The Lord at your right hand shatters kings in the day of his wrath. In verse 1 the addressee sits at YHWH's right hand; in verse 5 the Lord is at the addressee's right hand. The relation is stated from both sides in one psalm, which is either a deliberate reciprocity or an indication that the two verses come from different hands. This book takes no position and notes that on either reading the shattering is not the addressee's act.

One observation to close, and it should be made carefully because it can be overstated. Psalm 110 is a psalm of enormous exaltation and this chapter has read it for its verbs. That is a partial reading and it is the reading the book's question requires. A reader whose question is what the psalm claims about the addressee's status will find this chapter says almost nothing about that, and will be right. The claim here is only that the psalm, in stating the status, states it as given, and states who gives it, in a grammar the corpus repeats at Daniel 7:14 and at 1 Chronicles 29:23 and at Psalm 2:7.

## CHAPTER 56 · Psalm 110:4 · A Priesthood Not Aaron's

*Nishbaʿ YHWH we-loʾ yinnaḥem, ʾattah khohen le-ʿolam ʿal divrati Malki-Ṣedeq.*

The LORD has sworn and will not repent: you are a priest forever after the order of Melchizedek.

**The conferral is by oath and the oath is God's.** *Nishbaʿ YHWH*, the LORD has sworn. The perfect. And *we-loʾ yinnaḥem*, and he will not change his mind, which forecloses revocation in the same clause that makes the grant.

**The grant is a priesthood, given to the figure of verse 1.** The addressee of *ʾattah khohen* is the *ʾadoni* of verse 1. One psalm, one figure, two conferrals: a seat and a priesthood, both given, both by the same speaker.

**The order named is not Aaron's.** *ʿAl divrati Malki-Ṣedeq*, after the manner of Melchizedek. This is the striking feature and it is easily passed over by a reader who takes Melchizedek as a generic honorific.

Melchizedek appears in the Hebrew Bible exactly twice: at Genesis 14:18-20 and here. Nowhere else. At Genesis 14:18 he is *melekh Shalem* and *khohen le-ʾel ʿelyon*, king of Salem and priest of God Most High. He brings out bread and wine, blesses Abram, and receives a tenth. He is not an Israelite, he predates Sinai, he predates Aaron by five generations, and the corpus supplies him with no genealogy at all.

So the royal priesthood of Psalm 110:4 is patterned on a pre-Israelite, non-Aaronide, genealogically unplaced figure, in a corpus that legislates the priesthood as hereditary in Aaron's line at Exodus 28-29 and Numbers 3 and 18, and that executes kings for priestly acts at 2 Chronicles 26:16-21.

**The dynastic-form question, and the corpus's own answer to it.** A reader may suspect that *Malki-Ṣedeq* is a personal name invented for the passage, or a title, and that the psalm is reaching for an archaism. The corpus supplies the check independently. **Joshua 10:1** names the king of Jerusalem at the conquest *ʾAdoni-Ṣedeq*, my lord is Ṣedeq, or lord of righteousness. Two Jerusalemite kings, both with *ṣedeq* as the theophoric or predicative element, separated by centuries in the corpus's own chronology, in two different books with no literary relation. That is not an isolated anomaly. It is a local dynastic naming form, and the corpus preserves two instances of it.

The consequence is that Psalm 110:4 is not inventing a legendary priest-king. It is patterning the Davidic royal priesthood on the pre-Israelite Jerusalemite one, whose form the corpus attests twice.

Three notes on what this chapter does and does not claim.

**It does not claim the Davidic kings functioned as priests.** The evidence for royal priestly action is contested: David wearing an ephod and offering at 2 Samuel 6:14-18, Solomon offering at 1 Kings 3:4 and blessing at 8:14, and against them the Uzziah episode at 2 Chronicles 26. This book takes no position on the historical question.

**It does not claim the Aaronide priesthood is thereby displaced.** Numbers 25:12-13 gives Phinehas *berit kehunnat ʿolam*, a covenant of perpetual priesthood, and Ezekiel 44:15 restricts temple service to the sons of Zadok. The corpus carries both the perpetual Aaronide grant and the perpetual non-Aaronide one, and reconciles them nowhere. Book X counts this among its ten pairs.

**What it does claim is the conferral grammar.** The priesthood is sworn to the figure by God, in the perfect, with the revocation barred. The figure does not hold it in his own right and does not hold it by descent, since the order named has no descent. He holds it because it was sworn.

## CHAPTER 57 · Melchizedek and Adoni-Ṣedeq · The Received Institution

Chapter 56 established that the royal priesthood is patterned on a non-Israelite order. This chapter takes the wider observation that the pattern belongs to: what Israel holds, the corpus records as received, with the source named.

**Four transfers, four foreign sources, none concealed.**

**A standing priestly order, from Melchizedek.** Genesis 14:18-20, made permanent for the Davidic figure at Psalm 110:4. The order is his and the corpus says so.

**A divine title, from the same encounter.** Melchizedek blesses Abram *le-ʾel ʿelyon qoneh shamayim wa-ʾareṣ*, by God Most High, possessor of heaven and earth, at Genesis 14:19. Four verses later, at 14:22, Abram swears *harimoti yadi ʾel YHWH ʾel ʿelyon qoneh shamayim wa-ʾareṣ*. I have lifted my hand to YHWH, God Most High, possessor of heaven and earth. The title spoken by the Canaanite priest is taken onto Abram's own oath, with the Name prefixed. The corpus narrates the acquisition of a divine epithet and shows the joining seam in the syntax.

**An administrative procedure, from Jethro.** Exodus 18:13-23. Moses judges the people alone from morning to evening. Jethro, priest of Midian, observes and says *loʾ ṭov ha-davar ʾasher ʾattah ʿoseh*, the thing you are doing is not good, and proposes the delegated judiciary: rulers of thousands, hundreds, fifties, and tens. And then 18:24: *wa-yishmaʿ Mosheh le-qol ḥoteno wa-yaʿas kol ʾasher ʾamar.* And Moses listened to the voice of his father-in-law and did all that he said.

The verb is *shmʿ be-qol*, to listen to the voice, which Book IV traced as the corpus's own idiom for the receiving Israel is repeatedly said to fail at. Here Moses performs it, and the voice is a Midianite priest's.

**The sanctuary's ground, from Ornan the Jebusite.** 2 Chronicles 3:1 places the temple *be-har ha-Moriyyah ... bi-meqom ʾasher hekhin be-Dawid bi-goren ʾOrnan ha-Yevusi*, on Mount Moriah, in the place David had prepared, at the threshing floor of Ornan the Jebusite. And the acquisition is recorded, at 2 Samuel 24:24, with David refusing a gift: *loʾ ki qano ʾeqneh me-ʾotekha bi-meḥir, we-loʾ ʾaʿaleh la-YHWH ʾelohay ʿolot ḥinnam.* No, but I will surely buy it from you at a price, and I will not offer to the LORD my God burnt offerings that cost me nothing.

Bought and not seized. The corpus records the price, fifty shekels of silver in Samuel and six hundred shekels of gold in Chronicles, and the discrepancy is a known problem that does not affect the point.

**What the four have in common.** In each case the corpus could have concealed the source and did not. It could have given the priestly order no antecedent. It could have had Abram coin the divine title. It could have had Moses devise the judiciary. It could have had the threshing floor be ancestral land. In every case it names an outsider, names the transfer, and in the fourth case names the sum.

Two disciplinary notes.

**The Genesis 14:20 subject is contested and nothing here depends on it.** *Wa-yitten lo maʿaser mi-kol*, and he gave him a tenth of everything, has no explicit subject and can be read either way: Abram tithing to Melchizedek, or Melchizedek giving Abram a tenth of the spoil. The majority reading is the first. This book takes no side, because Psalm 110:4 settles whose order the priesthood is independently of who handed whom a tenth.

**The observation is about the corpus's habit, not about historical dependence.** Whether Israelite institutions historically derive from Canaanite or Midianite ones is a question for a different discipline. The claim here is about what the corpus records, and what it records is a pattern of acknowledged receipt.

## CHAPTER 58 · Deuteronomy 17:18-20 · The King Copies a Law He Did Not Write

Chapter 43 established that the law of the king regulates a demand. This chapter reads its single positive requirement.

*We-hayah khe-shivto ʿal kisseʾ mamlakhto we-khatav lo ʾet mishneh ha-torah ha-zoʾt ʿal sefer mi-lifney ha-kohanim ha-Lewiyyim. We-haytah ʿimmo we-qaraʾ vo kol yemey ḥayyaw, le-maʿan yilmad le-yirʾah ʾet YHWH ʾelohaw li-shmor ʾet kol divrey ha-torah ha-zoʾt we-ʾet ha-ḥuqqim ha-ʾelleh la-ʿasotam. Le-vilti rum levavo me-ʾeḥaw u-le-vilti sur min ha-miṣwah yamin u-semoʾl, le-maʿan yaʾarikh yamim ʿal mamlakhto huʾ u-vanaw be-qerev Yisraʾel.*

And when he sits on the throne of his kingdom, he shall write for himself a copy of this law in a book, from before the levitical priests. And it shall be with him, and he shall read in it all the days of his life, that he may learn to fear the LORD his God, to keep all the words of this law and these statutes, to do them. That his heart be not lifted up above his brothers, and that he turn not aside from the commandment to the right or the left, so that he may prolong days over his kingdom, he and his sons, in the midst of Israel.

Five features.

**The requirement attaches to the moment of sitting.** *Khe-shivto ʿal kisseʾ mamlakhto*, when he sits on the throne of his kingdom. The first act of the reign is a copying.

**The exemplar is in the custody of others.** *Mi-lifney ha-kohanim ha-Lewiyyim*, from before the levitical priests. The king does not hold the master text. He copies from a copy held by a different office. Two institutions, one dependent on the other for the document.

**He writes it himself.** *We-khatav lo*, and he shall write for himself. Not have written, not commission. The corpus makes the king perform the scribal act, which is the act of a man taking down what another has composed.

**He reads it all his life.** *We-qaraʾ vo kol yemey ḥayyaw.* Not once at accession. Continuously.

**The purpose clause names the failure mechanism.** *Le-vilti rum levavo me-ʾeḥaw*, that his heart be not lifted up above his brothers. That is Deuteronomy 8:14's *ram levavekha* applied to the king. The law of the king guards against the same mechanism the law of prosperity warned about, in the same words.

**And a guard erected against an impossibility is not a guard.** This is the inference and it is worth stating explicitly. The corpus does not legislate against risks it considers unreal. The presence of the clause is evidence that whoever composed it expected the failure, and the corpus supplies the executions.

**2 Chronicles 26:16.** *U-khe-ḥezqato gavah libbo ʿad le-hashḥit wa-yimʿal ba-YHWH ʾelohaw wa-yavoʾ ʾel heykhal YHWH le-haqṭir ʿal mizbaḥ ha-qeṭoret.* And when he was strong, his heart was lifted up to his destruction, and he trespassed against the LORD his God and went into the temple of the LORD to burn incense on the altar of incense. Uzziah, struck with a skin disease on the forehead, put out of the temple, and living in a separate house until his death, with his son over the household judging the people. The verb is *gavah* rather than *rum*, but the idiom is identical and the result is a king removed from function while alive.

**2 Chronicles 32:25.** *We-loʾ khe-gemul ʿalaw heshiv Yeḥizqiyyahu ki gavah libbo, wa-yehi ʿalaw qeṣef we-ʿal Yehudah wi-Yerushalayim.* But Hezekiah did not render according to the benefit done to him, for his heart was lifted up; and there was wrath upon him and upon Judah and Jerusalem. And then 32:26, the mitigation: *wa-yikkanaʿ Yeḥizqiyyahu be-govah libbo*, Hezekiah humbled himself for the pride of his heart.

Two named kings, one idiom, one book, both executions of a guard written into the law of the king.

The structural consequence for Book VI. **The king is subordinate to a document he did not author and cannot alter.** He copies it from another office's exemplar, reads it for life, and is held by its purpose clause to a station among his brothers rather than above them. That is a description of a delegated office with an external standard, and it is the Deuteronomic form of the same relation Chronicles states with *kisseʾ YHWH* and Psalm 110 states with *shev li-mini*.

## CHAPTER 59 · 2 Samuel 7:14-15 · Discipline Inside the Sonship Clause

The dynastic oracle at 2 Samuel 7 is the corpus's foundational statement of the Davidic grant, and its most exalted verse carries a limit inside itself.

*ʾAni ʾehyeh lo le-ʾav we-huʾ yihyeh li le-ven, ʾasher be-haʿawoto we-hokhaḥtiv be-shevet ʾanashim u-ve-nigʿey benei ʾadam. We-ḥasdi loʾ yasur mimmennu ka-ʾasher hasiroti me-ʿim Shaʾul ʾasher hasiroti mi-lefaneykha.*

I will be to him a father and he will be to me a son; when he does wrong I will chasten him with the rod of men and with the strokes of the sons of men. But my covenant loyalty shall not depart from him, as I took it from Saul whom I removed from before you.

**The sonship is stated in the covenant formula.** *ʾAni ʾehyeh lo le-ʾav we-huʾ yihyeh li le-ven.* The construction *ʾehyeh le ... yihyeh li le* is the corpus's standard covenant formula, used of God and the people at Exodus 6:7, Leviticus 26:12, Jeremiah 7:23, Ezekiel 36:28, and elsewhere. Its application to a king is a narrowing of a relation the corpus elsewhere applies to a nation.

**The wrongdoing is anticipated in the same sentence.** *ʾAsher be-haʿawoto*, when he does wrong. Not if. The particle carries a temporal-conditional force, and the corpus does not hedge: the sonship clause and the misconduct clause are one sentence.

**The discipline is by ordinary means.** *Be-shevet ʾanashim u-ve-nigʿey benei ʾadam*, with the rod of men and the strokes of the sons of men. This is a striking specification. The chastening is not by plague, by prodigy, or by direct visitation. It is by human agency, which in the narrative that follows means Absalom, Sheba, Rezon, Hadad, Jeroboam, and eventually Nebuchadnezzar.

**The withdrawal is barred, and the bar is stated against a precedent.** *We-ḥasdi loʾ yasur mimmennu ka-ʾasher hasiroti me-ʿim Shaʾul.* The same verb *swr* in the qal for the not-departing and in the hiphil for the removal from Saul. The corpus uses one root on both sides of the contrast, which makes the contrast precise: the thing that was removed from Saul will not be removed from this house.

So the grant is unrevokable and the occupant is disciplinable. Those are two different objects and the verse distinguishes them in one sentence. Chapter 76 takes up the permanence and Chapter 50 has already used verse 15 to answer F2.

Two features of the wider chapter belong here.

**The oracle begins by refusing David's proposal.** 7:1-2 has David saying he dwells in a house of cedar while the ark dwells in curtains. 7:5: *ha-ʾattah tivneh li bayit le-shivti*, shall you build me a house to dwell in? And 7:11 turns the noun around: *we-higgid lekha YHWH ki vayit yaʿaseh lekha YHWH*, the LORD declares that the LORD will make you a house. The whole oracle is a reversal of who builds what for whom, and the reversal is its structure.

**The verse before the sonship clause carries the same reversal.** 7:8: *ʾani leqaḥtikha min ha-nawah me-ʾaḥar ha-ṣoʾn li-hyot nagid ʿal ʿammi ʿal Yisraʾel.* I took you from the pasture, from following the sheep, to be *nagid* over my people, over Israel. Three things: the taking is God's, the title is *nagid* rather than *melekh*, and the people are *ʿammi*, mine. Chapter 61 returns to that possessive because Ezekiel builds on it.

**And the whole grant is answered by David in the register of receipt.** 7:18: *mi ʾanokhi ʾAdonay YHWH u-mi veyti ki haviʾotani ʿad halom*, who am I, Lord GOD, and what is my house, that you have brought me this far. The response to a conferral is a question about desert, which is the response the grammar invites.

## CHAPTER 60 · Psalm 2:7 · Dated in One Adverb

*ʾAsapperah ʾel ḥoq, YHWH ʾamar ʾelay beni ʾattah ʾani ha-yom yelidtikha.*

I will declare the decree: the LORD said to me, you are my son; today I have begotten you.

The verse is one of the corpus's highest statements about a king and it dates itself in a single word.

**The statement is a quotation of a decree.** *ʾAsapperah ʾel ḥoq*, I will recount the statute, or with the preposition read as concerning, I will tell of the decree. The speaker is reporting something enacted rather than describing a condition.

**The sonship is declared by the speaker's superior.** *YHWH ʾamar ʾelay*, the LORD said to me. The relation is constituted by an utterance and the utterance is quoted.

**And it is dated.** *ʾAni ha-yom yelidtikha*, today I have begotten you.

*Ha-yom* is the datum. A begetting that happens today is an event with a date, and a relation constituted on a date is a relation that did not obtain the day before. The corpus is not describing an eternal filiation; it is quoting a decree issued at a moment.

The moment is the coronation. That identification is not imported: the psalm supplies the setting in its own verses. 2:2, kings of the earth setting themselves against YHWH and against his anointed. 2:6, *wa-ʾani nasakhti malki ʿal Ṣiyyon har qodshi*, I have installed my king on Zion, my holy hill. 2:8, ask of me and I will give the nations as your inheritance. 2:9, you shall break them with a rod of iron. The furniture of the psalm is accession, installation, the submission of vassals, and the granting of territory, which is the standard content of an enthronement.

**The verb *nasakhti* at 2:6 is a second conferral in the same psalm.** Its root is disputed between *nsk*, to pour or install, and a by-form; either way the subject is God and the object is the king. *Malki*, my king, with the possessive. The king is God's king in the same psalm in which he is God's son.

**And 2:8 makes the inheritance conditional on a request.** *Sheʾal mimmenni we-ʾettenah goyim naḥalatekha.* Ask of me and I will give. The nations are not the king's by right; they are available on petition. The most expansive territorial claim in the Psalter is stated as a thing to be asked for.

Three notes.

**The adoption formula is the standard reading and it is a reading.** Comparative material from the ancient Near East uses similar language of kings, and the majority of scholarship reads Psalm 2:7 as a Judahite adoption formula at accession. This book uses the internal evidence and does not need the comparative material, though the comparative material supports it.

**The psalm's own frame is a threat and a warning.** It opens with nations raging and closes at 2:10-12 with an instruction to the kings of the earth: be wise, be warned, serve the LORD with fear, kiss the son lest he be angry. The exaltation of the king in verses 6 through 9 sits inside an address to other kings, which is the rhetorical situation of a suzerain announcing a vassal's installation.

**And the exaltation is real.** This book has no interest in diminishing it. A man is declared son of God, installed on a holy hill, and offered the nations. What the verse also does, in its central word, is date the declaration, and a dated sonship is a conferred one.

## CHAPTER 61 · Ezekiel 34:24 · Two Roles, One Verse, Distinguished

*Wa-ʾani YHWH ʾehyeh lahem le-ʾelohim we-ʿavdi Dawid nasiʾ be-tokham, ʾani YHWH dibbarti.*

And I the LORD will be their God, and my servant David a prince in their midst; I the LORD have spoken.

One verse, two roles, one grammatical structure holding them apart. This is the sharpest statement in the prophetic corpus of the distinction Book VI is describing and it is worth reading against its whole chapter, because the chapter is a sustained argument about who the shepherd is.

**Ezekiel 34 opens against the shepherds of Israel.** 34:2: *hoy roʿey Yisraʾel ʾasher hayu roʿim ʾotam, ha-loʾ ha-ṣoʾn yirʿu ha-roʿim.* Woe to the shepherds of Israel who feed themselves; should not the shepherds feed the flock? The indictment runs through verse 10: they eat the fat, clothe themselves with the wool, kill the fatlings, and do not feed the flock; the weak are not strengthened, the sick not healed, the broken not bound, the strayed not brought back, the lost not sought.

**Then the removal.** 34:10: *hineni ʾel ha-roʿim we-darashti ʾet ṣoʾni mi-yadam we-hishbattim me-reʿot ṣoʾn.* Behold I am against the shepherds and will require my flock at their hand and cause them to cease from feeding the flock.

**Then the substitution, and the subject is God.** 34:11: *hineni ʾani we-darashti ʾet ṣoʾni u-viqqartim.* Behold I, even I, will search for my sheep and seek them out. Verses 11 through 16 are a sustained first-person sequence: I will seek, I will deliver, I will bring out, I will gather, I will bring in, I will feed, I will cause them to lie down, I will seek the lost, I will bring back the strayed, I will bind the broken, I will strengthen the sick. Eleven first-person verbs.

**And 34:15 uses the settling-root.** *ʾAni ʾerʿeh ṣoʾni wa-ʾani ʾarbiṣem*, I will feed my flock and I will make them lie down. The terminus vocabulary in the middle of the shepherd oracle, with God as subject.

**Then, after all that, the Davidic figure.** 34:23: *wa-haqimoti ʿaleyhem roʿeh ʾeḥad we-raʿah ʾethen ʾet ʿavdi Dawid, huʾ yirʿeh ʾothen we-huʾ yihyeh lahen le-roʿeh.* And I will set up over them one shepherd and he shall feed them, my servant David; he shall feed them and he shall be their shepherd.

And then 34:24, the verse.

**The possessive runs throughout and it never transfers.** *Ṣoʾni*, my flock, at 34:6, 34:8, 34:10 twice, 34:11, 34:12, 34:15, 34:17, 34:19, 34:22, and 34:31. Eleven occurrences. In the same chapter in which a shepherd is appointed, the flock is called God's eleven times and is never once called the shepherd's.

**The appointing verb is causative with God as subject.** *Wa-haqimoti ʿaleyhem*, and I will raise up over them.

**The title is *nasiʾ*, not *melekh*.** At 34:24 and again at 37:25, where 37:24 had used *melekh*. Ezekiel's preference for *nasiʾ* runs through the temple vision at 44:3, 45:7-8, 45:16-17, and 46:2-18, where the prince has assigned portions, brings his own offerings, enters by a specified gate, and is warned at 45:8 *we-loʾ yonu ʿod nesiʾay ʾet ʿammi*, my princes shall no more oppress my people. The word *nasiʾ* is a term for a tribal chief or leader and it is a step down from *melekh* in register.

**And the divine role is stated first and in the covenant formula.** *Wa-ʾani YHWH ʾehyeh lahem le-ʾelohim.* The same formula as 2 Samuel 7:14 but with the people as the second party, which is its usual application. The verse gives God the covenant relation and the prince a location, *be-tokham*, in their midst.

The finding: **the corpus places both roles in one sentence and assigns them different predicates.** God is their God. David is a prince among them. Not two names for one office; two offices in one clause, with a comma between them that the corpus supplies as a waw.

## CHAPTER 62 · The Passive Verb and the Named Giver

Book VI has read eleven passages across six books. This chapter states what they have in common, because the commonality is the book's principal finding and it is a grammatical one.

**The pattern.** Wherever the corpus states what a royal or exalted figure holds, the verb is passive, or the verb is active with God as its subject and the figure as its object or beneficiary. There is no exception in the passages examined.

**The evidence, gathered.**

Deuteronomy 17:15. *Som tasim ʿaleykha melekh ʾasher yivḥar YHWH ʾeloheykha bo.* The king is the one God chooses. The choosing verb has God as subject.

1 Samuel 8:22. *We-himlakhta lahem melekh.* Samuel is commanded to make them a king. The king does not take the office.

2 Samuel 7:8. *ʾAni leqaḥtikha min ha-nawah.* I took you from the pasture. First person divine, second person object.

2 Samuel 7:11. *Ki vayit yaʿaseh lekha YHWH.* The LORD will make you a house. The house is made for him.

2 Samuel 7:14. *ʾAni ʾehyeh lo le-ʾav.* The relation is constituted by divine declaration.

Psalm 2:6. *Wa-ʾani nasakhti malki.* I have installed my king.

Psalm 2:7. *ʾAni ha-yom yelidtikha.* Today I have begotten you.

Psalm 2:8. *Sheʾal mimmenni we-ʾettenah.* Ask of me and I will give.

Psalm 110:1. *Shev li-mini.* Sit at my right hand. Imperative from the giver, and *ʾashit ʾoyveykha*, I will make your enemies, first person divine.

Psalm 110:4. *Nishbaʿ YHWH ... ʾattah khohen.* The LORD has sworn; you are a priest.

1 Chronicles 28:5. *Wa-yivḥar bi-Shelomoh veni.* He chose Solomon.

1 Chronicles 29:23. *Wa-yeshev Shelomoh ʿal kisseʾ YHWH.* He sat on a throne belonging to another.

2 Chronicles 9:8. *Le-titkha ʿal kisʾo le-melekh la-YHWH.* To set you on his throne as king for the LORD.

Ezekiel 34:23. *Wa-haqimoti ʿaleyhem roʿeh ʾeḥad.* I will raise up over them one shepherd.

Daniel 7:14, which Chapter 82 works in full. *We-leh yehiv sholṭan.* And to him was given dominion. Aramaic peʿil, passive, with no agent expressed.

**Fifteen sites. Six books. Two languages. One grammar.**

Three things follow.

**The grammar is not a coincidence of one editor.** The sites span the Torah, the Former Prophets, the Latter Prophets, the Psalter, and the Writings, in Hebrew and in Aramaic. No single hand produced them and no single school is plausible for all of them.

**The grammar survives the escalation.** Book VIII will show the figure growing from a man anointed with oil to a being receiving everlasting dominion in a night vision. Across that whole escalation, the verb does not change. At Deuteronomy 17:15 God chooses; at Daniel 7:14 it is given. The magnitude of what is held rises steeply and the mode of holding does not move at all.

**And the grammar is independent of the census.** Chapter 17 found, from an entirely different instrument on an entirely different question, that where a king appears at a terminus site he appears as recipient with the giver named. This chapter finds the same relation in the conferral material by reading verbs. Two instruments, no shared premise, one result. That convergence is the strongest evidence Book VI has and it is worth naming as such.

One qualification, because the claim is a universal and universals are fragile. The claim is about the passages examined, which are the principal conferral passages of the corpus. It is not a claim that no verse anywhere has a king as the subject of an acquiring verb; kings take cities, take wives, take spoil, and take the kingdom by force in the northern narratives constantly. The claim is narrower and is about what the corpus says a royal figure holds *by grant*, and there the grammar is uniform.

## CHAPTER 63 · Anointing Itself · The Morphology of a Passive Title

The title itself is a passive participle and this chapter is about that fact.

*Mashiaḥ* is the passive participle of *mšḥ*, to smear or anoint. Morphologically it is a qatil-form functioning as a passive adjective: anointed, one who has been smeared. It is not an agent noun. There is no form in the corpus meaning one who anoints applied to the figure, and the corpus's agent-forms for the rite are always the officiant: Samuel anoints, Zadok anoints, the elders anoint.

Three observations follow from the morphology alone and each is checkable.

**The title names what was done to the bearer.** A *mashiaḥ* is defined by having received an application. The word contains no claim about what he does, only about what happened to him. In this it differs from every other Hebrew royal title. *Melekh* is from a root of ruling. *Nagid* is from a root of being in front or being told. *Moshel* is an active participle, one who rules. *Nasiʾ* is from *nśʾ*, to lift, and is usually taken as one lifted up, which is itself passive in force, and which is Ezekiel's preferred term.

**The rite is performed by another.** Every anointing narrative in the corpus has an officiant distinct from the anointed. Samuel anoints Saul at 1 Samuel 10:1, pouring a flask of oil on his head and kissing him. Samuel anoints David at 16:13, taking the horn of oil and anointing him in the midst of his brothers. Zadok the priest and Nathan the prophet anoint Solomon at 1 Kings 1:39, Zadok taking the horn of oil from the tent. Jehoiada's people anoint Joash at 2 Kings 11:12. A prophet's servant anoints Jehu at 2 Kings 9:6. The men of Judah anoint David at 2 Samuel 2:4 and the elders of Israel at 5:3.

Seven anointings, seven officiants, no self-anointing anywhere in the corpus.

**The substance is external and the source is named.** Oil, in a flask at 1 Samuel 10:1 (*pakh ha-shemen*) or a horn at 16:13 and 1 Kings 1:39 (*qeren ha-shemen*). At 1 Kings 1:39 the horn is taken *min ha-ʾohel*, from the tent, which is to say from the sanctuary. The substance conferring the office comes from a place the office does not control.

The consequence for this book is one sentence and it should be stated exactly. **The corpus's central royal title is morphologically a record of something received.** That is not an argument, since morphology does not settle theology, and a passive title can be borne by a figure who acts with total sovereignty. What it is is a convergence: the title's form, the rite's structure, the conferral verbs of Chapter 62, and the census result of Chapter 17 all point one direction, and the title is the smallest and hardest of the four data.

One further note, and it is a genuine complication rather than a supporting detail. **The rite is not confined to kings.** Aaron and his sons are anointed at Exodus 29:7 and Leviticus 8:12. The tabernacle and its furniture are anointed at Exodus 40:9-11. Elisha is to be anointed prophet at 1 Kings 19:16. And Hazael, king of Aram, is to be anointed at the same verse, which Chapter 70 works because it is the strangest item in the whole field.

So *mashiaḥ* is not a royal title exclusively, and a book that presented it as one would be overstating. Chapter 74's census sorts every occurrence and finds the distribution is wider than the tradition's usage suggests. What holds across the whole distribution, kings and priests and furniture and a foreign king alike, is the passive: everything anointed in the Hebrew Bible had the oil applied to it by somebody else.
