# BOOK II · THE FOUR ROOTS

## CHAPTER 9 · Šbt · The Hand Comes Off the Work

The account of creation closes not on a seventh act of the same kind as the six but on a cessation. *Wa-yikhal ʾelohim ba-yom ha-shevi'i melaʾkto ʾasher ʿasah, wa-yishbot ba-yom ha-shevi'i mi-kol melaʾkto ʾasher ʿasah.*

The verb is *šbt*, and the first thing to establish about it is what it does not mean. It is not a fatigue word. There is no exhaustion in it, no recuperation, no restoration of a depleted capacity. The image in *šbt* is the hand coming off the work. A thing that was proceeding stops proceeding. Whether the one who stops is tired is not in the root and is not in the passage, and Genesis 2 supplies no predicate that would suggest it.

This matters because the English word rest carries fatigue as its dominant sense, and a reader working in English will import the fatigue without noticing the import. Once fatigue is in the picture, the seventh day becomes a recovery and the terminus of the promise becomes a reward for effort, which is a coherent theology and is not what the vocabulary says. The corpus has other resources for exhaustion. *Yaʿaf* and *yagaʿ* both carry it, and Isaiah 40:28 uses both to deny them of God in the same breath: *loʾ yiʿaf we-loʾ yigaʿ*. The denial is explicit and it is made with the words that would carry the sense. *Šbt* is not among them.

The root's ordinary usage confirms the reading. Manna ceases, *wa-yishbot ha-man*, on the day after they eat of the produce of the land at Joshua 5:12. A thing that had been happening stops happening; nobody rests. Leviticus 26:6 uses the hiphil for the removal of dangerous animals from the land, *we-hishbatti ḥayyah raʿah min ha-ʾareṣ*, causing them to cease. The land keeps its sabbaths at Leviticus 26:34 with the same root in a form that makes the land the subject of a cessation. Amos 8:4 has the merchants asking when the new moon will be over so they can sell grain, and when the sabbath will be over, *we-ha-shabbat we-niftaḥah bar*: for them the sabbath is precisely a stoppage of business, and their impatience with it is the point of the oracle.

Two further features of the root's placement in Genesis 2 are worth recording because they recur throughout this book.

First, the seventh day is the only day of the seven that is blessed and sanctified, *wa-yevarekh ʾelohim ʾet yom ha-shevi'i wa-yeqaddesh ʾoto*, and it is the only one with no evening-and-morning formula closing it. The other six each close. The seventh is not closed in the text. Whatever is intended by that, the text has left the seventh day grammatically open in a series where closure is the pattern, and a reader is entitled to notice a break in a pattern the author established six times.

Second, the object of the cessation is named twice in the same verse: *melaʾkto ʾasher ʿasah*, his work which he had made, appearing in both halves. The repetition fixes the referent. What ceases is the making. Nothing else is said to cease and nothing is said to begin.

The reason this root opens Book II rather than the one the promise actually uses is that *šbt* fixes the semantic field. The corpus has a word for the terminal position in its own foundational narrative, that word denotes cessation and not recuperation, and the terminus of the promise will be named in a cognate field. A reader who has understood that the seventh day is a stopping rather than a napping is in a position to read the rest of this book. A reader who has not will keep supplying a tiredness the text does not contain.

## CHAPTER 10 · Nwḥ · The Alighting That Stays

The second root is *nwḥ*, and it is the one the promise uses.

Its image is settlement: a thing that was in motion comes to a place and stays there. The clearest instance in the corpus is not a theological one. At Genesis 8:4 the ark comes to rest on the mountains of Ararat, *wa-tanaḥ ha-tevah ʿal harey ʾAraraṭ*. The vessel has been afloat and moving; it grounds and stops moving; that grounding is *nwḥ*. Nothing about fatigue enters. The ark is not tired. It has arrived.

Compare the same chapter three verses earlier for the contrast that fixes the sense. The dove sent out at 8:9 finds no *manoaḥ le-khaf raglah*, no resting-place for the sole of her foot, and returns to the ark. The word is a nominal from the same root and it names a place a foot can settle on. The dove's problem is not weariness; it is that the waters are still over the face of the earth and there is nowhere to come down. *Nwḥ* is about a landing site.

That is the vocabulary in which the promise's terminus is named, and once the image is fixed the theological uses become legible rather than vague.

Deuteronomy 12:9 states the position negatively and in the perfect: *ki loʾ vaʾtem ʿad ʿattah ʾel ha-menuḥah we-ʾel ha-naḥalah ʾasher YHWH ʾeloheykha noten lakh*. You have not yet come to the resting-place and to the inheritance. The construction is *baʾ ʾel*, to come to, which is a verb of arrival at a location. *Ha-menuḥah* is the nominal of settlement and it stands in a pair with *ha-naḥalah*, the inheritance. Two nouns, one preposition, one motion-verb. Whatever else the terminus is, the grammar makes it a place one arrives at.

The very next verse supplies the causative: *we-heniaḥ lakhem mi-kol ʾoyeveykhem mi-saviv wi-shavtem beṭaḥ*. He will cause you to settle from all your enemies round about, and you will dwell in safety. The hiphil *heniaḥ* is the standard form for the divine act throughout the Deuteronomistic material, and it will recur at Joshua 21:44 and across Chronicles. It is worth naming its shape now, because Chapter 62 turns on it. The form is causative and its subject is God. Somebody causes the settling. The one settled is the object.

The nominal *menuḥah* is the noun this book will use most, and it is worth separating from its near neighbours. It is not *shalom*, which is a much wider word covering wholeness, welfare, and the absence of hostility, and which Chapter 20 addresses separately. It is not *beṭaḥ*, which is security or confidence and appears beside *menuḥah* at Deuteronomy 12:10 as a distinct predicate. It is not *nawah*, a pasture or habitation, though the roots are visually similar and are occasionally confused in translation. *Menuḥah* is the state of having settled, and the corpus uses it of a person, of a people, and of a place, and once, at 1 Chronicles 22:9, of a man who is to be characterized by it.

One further site fixes the root's range in a direction that will matter at Book VI. At Isaiah 11:2 the spirit of the LORD *we-naḥah ʿalaw*, settles upon him. The same root, the same image of a coming-down-and-staying, used of a spirit alighting on a figure. That is a real messianic use of *nwḥ* and this book will not pretend otherwise. What it is not is a use in which the figure gives rest. It is a use in which something settles on him. The direction of the verb is worth keeping in view from here on, because the direction turns out to be the whole finding of Chapter 17.

## CHAPTER 11 · Šqṭ · The Land Is Quiet

The third root is *šqṭ*, and its subject is characteristically the land.

Its sense is undisturbedness: quiet from outside molestation. Not internal peace, not the absence of conflict in general, but the specific condition of not being troubled from without. The corpus's densest deployment of it is the refrain in Judges, and the refrain is worth setting out in full because it is one of the most underweighted facts in the whole discussion.

*Wa-tishqoṭ ha-ʾareṣ ʾarbaʿim shanah*, and the land was quiet forty years, at Judges 3:11 after Othniel. *Wa-tishqoṭ ha-ʾareṣ shemonim shanah*, eighty years, at 3:30 after Ehud. Forty years at 5:31 after Deborah and Barak. Forty years at 8:28 after Gideon. Four deliveries, two hundred years of quiet in aggregate, and the deliverers are a nephew of Caleb, a left-handed Benjaminite with a homemade dagger, a woman judging under a palm tree, and a man threshing wheat in a winepress because he was afraid.

The refrain is formulaic, which is sometimes taken as a reason to discount it. That gets the inference backwards. A formula is a statement the corpus makes repeatedly in fixed language, which is a mark of settled usage rather than of carelessness, and the fact that the same clause is used four times about four different deliverers is what makes it evidence about the category rather than about any one of them.

The root's non-theological uses confirm the sense. Joshua 11:23 closes the conquest with *we-ha-ʾareṣ shaqṭah mi-milḥamah*, the land had quiet from war, where the source of the disturbance is named and it is external. Judges 18:7 describes the people of Laish as *shoqeṭ u-voṭeaḥ*, quiet and secure, and the description is immediately followed by their being destroyed, which is a grim way of establishing that *šqṭ* is a condition and not a guarantee. Isaiah 14:7 has the whole earth at quiet, *naḥah shaqṭah kol ha-ʾareṣ*, on the fall of the king of Babylon, with both roots in one clause. Jeremiah 30:10 promises Jacob *we-shaqaṭ we-shaʾanan we-ʾeyn maḥarid*, quiet and at ease with none to make afraid, where the third clause glosses the first two by naming the absence of a disturber.

Two consequences follow and both bear directly on the argument of this book.

**The terminus is repeatedly delivered by ordinary agents.** Four times in one book, by four deliverers none of whom is a king, none of whom is anointed, and none of whom founds anything. That is not an incidental observation. It is a datum about what kind of agent the condition requires, and the answer the corpus gives is: not a special one.

**The condition is temporary and the corpus says so.** Forty years, eighty years, forty, forty. Each period ends and the cycle restarts with the people doing evil again. This is often read as a comment on the inadequacy of the judges, and it can be. It can also be read as a comment on the receiver, since in every case the corpus attributes the ending to what the people did and not to a failure in the deliverance. Book IV takes that up.

## CHAPTER 12 · Rgʿ · Repose at the End of a Walk

The fourth root is *rgʿ*, and it is the smallest of the four and the most personal.

Its subject is a person and its sense is relief. The corpus's decisive site is Jeremiah 6:16 and the whole verse deserves setting out, because it is the single passage in this book that carries the most weight per word.

*Koh ʾamar YHWH, ʿimdu ʿal derakhim u-reʾu, we-shaʾalu li-netivot ʿolam ʾey zeh derekh ha-ṭov u-lekhu vah, u-miṣʾu margoaʿ le-nafshotekhem. Wa-yomeru loʾ nelekh.*

Stand at the roads and look, and ask for the ancient paths where the good way is, and walk in it, and find *margoaʿ* for your souls. And they said, we will not walk.

*Margoaʿ* is the nominal, and its image is the repose at the end of a walk. Not the absence of walking; the condition arrived at by walking. That is exactly the shape of the terminus this book will argue for, and it appears here in a verse that also supplies the diagnosis of why the terminus is unoccupied, in the last four words.

Three features of the verse are load-bearing and each is returned to later.

**The paths already exist.** *Netivot ʿolam*, ancient paths. Nothing is being built, revealed, or awaited. The instruction is to ask where they are and walk on them. Chapter 35 works this against the alternative reading, in which the deficit is something withheld.

**The instruction is an ordinary imperative addressed to the hearer.** Stand, look, ask, walk. Four verbs, all second person plural, no intermediary in any of them. This is the Deuteronomy 30:11-14 shape in a different book and a different vocabulary.

**The refusal is spoken by the hearers and quoted.** *Wa-yomeru loʾ nelekh.* The corpus does not describe them as unable. It quotes them declining. Whatever is to be said about the hardening texts of Isaiah 6 and Deuteronomy 29, and Chapter 39 says a good deal, this verse has nothing withheld and nothing made heavy. It has an offer and a refusal.

The root's other uses are few and they sharpen rather than complicate the sense. Deuteronomy 28:65 threatens that among the nations *loʾ targiaʿ*, you will find no repose, and pairs it with a trembling heart and failing eyes: the loss of *rgʿ* is stated as a psychological condition and not a physical one. Isaiah 34:14 has the night-creature finding *manoaḥ* in the ruins of Edom, using the *nwḥ* nominal in a parallel position, which shows the two roots overlapping at the edges without being interchangeable at the centre.

A homonym has to be flagged. *Regaʿ* meaning a moment is spelled identically and is common. Isaiah 54:7-8 uses it twice in two verses, *be-regaʿ qaṭon ʿazavtikh*, for a small moment I forsook you. Nothing in this book rests on a *rgʿ* site without the sense being checked, and the census of Chapter 15 excludes moment-sites explicitly.

## CHAPTER 13 · The Census, I · What Can and Cannot Be Executed

The seed article behind this book named a single debt and capped its own strength on it. The debt was a census: the *nwḥ*, *menuḥah*, and *šqṭ* concordance across the whole corpus, with terminal-position sites isolated and the marked-to-unmarked ratio printed. This chapter and the six after it discharge as much of that debt as the available instruments allow and state precisely how much remains.

The statement of the limit comes first, because a partially discharged debt reported as discharged is worse than one reported as owed.

**What was not available.** No machine-readable Hebrew text of the Masoretic canon was accessible in the working environment where this census was executed, and no package registry reachable from that environment carried one. Every attempt to obtain one is recorded and every attempt failed. This is a fact about the working conditions and not about the world; a reader with Accordance, Logos, BibleWorks, or a printed Even-Shoshan can run the Hebrew census in an afternoon and should.

**What was available.** A complete English witness to the Hebrew Bible in machine-readable form: the Authorised Version of 1611 as printed in the Companion Bible, thirty-five files covering Genesis through Malachi. The text layer is uncorrected optical character recognition, which introduces noise, and the text is interleaved with an editor's notes, which introduces a different kind of noise. Both are handled and both are reported.

**What this instrument can and cannot do.** It can exhaustively isolate candidate sites in a way another reader can reproduce. It can answer a grammatical question about subject and object, because English preserves that relation. It cannot distinguish *šbt* from *nwḥ* from *šqṭ* from *rgʿ*, because the Authorised Version renders all four with rest, renders *nwḥ* also as quiet and set down and lay, and renders *šqṭ* also as rest. It therefore cannot produce the root-level ratio the debt names.

The honest summary is that this census narrows the debt rather than discharging it, and that the part it discharges is the part that turns out to matter most. The article's F1 asks whether the terminal sites are *systematically figure-indexed*, requiring a royal or eschatological agent. That is at bottom a question about who stands in the subject slot of the giving. English preserves subject and object. So the decisive question is answerable on the available witness even though the lexical question is not.

Every figure printed in the next six chapters is a count of English tokens. None is a count of Hebrew roots. Where a claim would require the Hebrew, the claim is not made.

## CHAPTER 14 · The Census, II · The Raw Field

The first pass captures the English rest-field across all thirty-five Hebrew Bible files, deliberately over-generously, so that the filtering happens in the open at later passes rather than silently at the first one.

The search terms are the Authorised Version's renderings of the four roots and their obvious inflections: rest, rested, resteth, rests, resting, quiet, quietly, quietness, quieted, cease, ceased, ceaseth, ceasing, sabbath, sabbaths, ease, eased, repose, settled.

**The result is 878 candidate sites.**

The token distribution is as follows. Rest, 399. Sabbath, 134. Cease, 83. Quiet, 47. Sabbaths, 46. Ease, 34. Ceased, 32. Rested, 27. Settled, 21. Resting, 13. Ceaseth, 11. Quietness, 10. Rests, 6. Quieted, 5. Quietly, 3. Resteth, 3. Repose, 2. Ceasing, 1. Eased, 1.

Three observations about the raw field before it is filtered.

**The field is dominated by one token.** Rest and its inflections account for 448 of 878 sites, better than half. That concentration is itself the evidence for the conflation problem named in the last chapter: a single English word is doing the work of at least three Hebrew roots, and no amount of care with the English can separate them.

**The sabbath tokens are a large and mostly separate population.** 180 sites between sabbath and sabbaths, better than a fifth of the field. Most of these are the institution rather than the terminus: sabbath observance, sabbath offerings, sabbath violations, the sabbath-year and jubilee legislation, and the rotation of temple watches. They are excluded at the next pass by the governing-verb filter, which is the right way to exclude them, since the exclusion is then visible and reversible rather than a decision made at the search string.

**Two books return zero.** Joel and Obadiah carry no token in the field at all. Both are short. Nothing follows from this beyond a note that the field is not uniformly distributed, and the distribution is reported in the next chapter because uneven distribution is a fact a reader should be able to see.

## CHAPTER 15 · The Census, III · Terminal Position

The second pass asks which of the 878 sites place the rest-word in terminal position, meaning as the object of a giving, an entering, a granting, a swearing, an inheriting, or a possessing. This is the position in which rest is the thing promised or arrived at rather than an ordinary pause, a weekly institution, or a stoppage of some other activity.

The filter is deliberately generous. It admits any site whose surrounding window contains one of the governing constructions, and the residue is then hand-sorted rather than trusted. A generous filter with a visible hand-sort is preferable to a tight filter whose exclusions nobody ever sees.

**114 of the 878 sites are terminal-position candidates.**

The distribution by book: Chronicles 16, Psalms 13, Isaiah 13, Jeremiah 9, Ezekiel 9, Joshua 8, Deuteronomy 7, Ezra-Nehemiah 7, Exodus 5, Kings 5, Lamentations 5, Genesis 4, Job 3, Leviticus 2, and one each in Numbers, Ruth, Samuel, Esther, Proverbs, Daniel, Habakkuk, and Zephaniah.

Three things in that distribution are worth stating.

**Chronicles leads.** Sixteen sites, more than any other book, in a work often treated as a late and theologically tidy retelling. Whatever else is true of the Chronicler, he is interested in this vocabulary and uses it more densely than his sources. Chapters 27 and 53 take that up, and the finding at Chapter 62 depends on it.

**The Deuteronomistic core is well represented but not dominant.** Joshua 8, Deuteronomy 7, Kings 5, Samuel 1. Twenty-one sites across the material where von Rad located the seam. That is a substantial share and it is not the whole field, which matters because an argument resting only on the Deuteronomistic History would be an argument about one editorial project rather than about the corpus.

**The prophets carry a third of the field.** Isaiah 13, Jeremiah 9, Ezekiel 9, Lamentations 5, plus the single sites in Daniel, Habakkuk, and Zephaniah: thirty-nine of 114. The terminus vocabulary is not confined to the historical books, which is the most common assumption about it.

Ezra-Nehemiah's seven is an artifact worth flagging honestly. Most of them are the sabbath-observance material of Nehemiah 13, which the governing-verb filter admitted on a construction and which the hand-sort removes. The number is reported before the hand-sort because reporting only post-sort numbers hides the sort.

## CHAPTER 16 · The Census, IV · The Marking Test

The third pass is the one the debt was about. Of the 114 terminal-position candidates, how many carry a royal or eschatological agent?

The machine pass tests for the presence of any royal or eschatological token anywhere in a 220-character window around the site: king, kings, messiah, anointed, David, Solomon, branch, shoot, prince, son of man, shepherd, servant of the LORD, throne, sceptre, reign, kingdom, ruler, deliverer, redeemer.

**23 of the 114 carry such a token. 91 do not.** At the crude machine level that is 20.2 percent marked.

That figure is not the result, because a token in a window is not an index. The 23 have to be read, and reading them dissolves most of them.

**Six are the editor's own notes and not the biblical text.** Bullinger's 1913 apparatus is interleaved with the verse text in the OCR layer, and six of the twenty-three matches fall in his notes rather than in scripture. One of these is discussed separately at Chapter 17 because it is the most instructive item in the whole census.

**Six are the wrong sense of the English word.** Deuteronomy 3:13's the rest of Gilead is a remainder and not the root at all. The sabbath-watch rotations at 2 Kings 11:5, 2 Kings 11:9, and 2 Chronicles 23:4 are the day and not the terminus; the king appears in them because the watches are set at the king's house. Jeremiah 17:25 and Ezekiel 46:1-2 are sabbath-day observance passages in which kings and a prince appear in adjacent clauses about entering gates.

**Eleven are genuine terminus sites at which a king stands in the window.** These are the real cases and they are: 2 Samuel 7:1, 1 Chronicles 22:9 counted three times for three separate tokens in one verse, 1 Chronicles 22:18, 1 Chronicles 23:25, 2 Chronicles 14:6, 2 Chronicles 15:15, and 2 Chronicles 20:30 counted twice.

The eleven are the census's finding and the next chapter is about what they say.

## CHAPTER 17 · The Subject Test, and What It Returned

Read the eleven.

2 Samuel 7:1. *Wa-YHWH heniaḥ lo mi-saviv mi-kol ʾoyevaw.* The LORD had given him rest round about from all his enemies. The king is present. He is the indirect object. The subject of the hiphil is YHWH.

1 Chronicles 22:9. *Hu yihyeh ʾish menuḥah wa-hanihoti lo mi-kol ʾoyevaw mi-saviv.* He shall be a man of rest, and I will give him rest from all his enemies round about. Solomon is named in the next clause. The subject of the giving is God, speaking in the first person.

1 Chronicles 22:18. *Ha-loʾ YHWH ʾeloheykhem ʿimmakhem wa-heniaḥ lakhem mi-saviv.* Has he not given you rest on every side. Subject named, and it is not the king; the addressees are the leaders of Israel.

1 Chronicles 23:25. *Heniaḥ YHWH ʾelohey Yisraʾel le-ʿammo.* The LORD God of Israel has given rest to his people. David is the speaker. The subject of the verb is God and the recipient is the people; no king occupies either slot.

2 Chronicles 14:6. *Ki heniaḥ YHWH lo.* Because the LORD had given him rest. Asa is the recipient.

2 Chronicles 15:15. *Wa-yanaḥ YHWH lahem mi-saviv.* The LORD gave them rest round about. The people are the recipient.

2 Chronicles 20:30. *Wa-yanaḥ lo ʾelohaw mi-saviv.* His God gave him rest round about. Jehoshaphat is the recipient.

**Eleven out of eleven. The king is the recipient. The giver is named in the same clause, and the giver is God.**

That is a stronger result than the argument required and it was not the result being looked for. The census was run to answer whether the terminus sites are figure-indexed, and the expected answer was that most are not. The answer that came back is that the ones which *are* marked are marked in the opposite direction: they are precisely the sites at which the corpus takes the trouble to say that the king received it.

A fourth pass tested the converse directly. Query: any clause anywhere in the corpus in which a royal or eschatological noun stands as the grammatical subject of a giving-verb governing rest, quiet, quietness, or repose.

**Two hits, and both dissolve.**

The first is 1 Chronicles 22:9 again, matched because Solomon's name precedes the second half of God's speech. The subject of *I will give* is God. The regex caught a proximity, not a subject.

The second is Bullinger's note on Psalm 101, and it is the most useful thing the census produced. His note reads: *of David. Relating to the true David, and His coming rule to give rest to the earth.* There it is: a royal figure as the subject of giving rest, in a sentence written in 1913 by an editor, attached to a psalm that does not say it.

**Zero verses. One commentator's gloss.** The figure-indexed reading of the terminus has to be supplied from outside the text because the text does not carry it, and the census caught the supply happening on the page.

## CHAPTER 18 · What the Census Settles

Three results, stated at the strength the instrument supports and no higher.

**The terminus sites are overwhelmingly unmarked.** 91 of 114 carry no royal or eschatological token at all in a generous window. That is 80 percent at the crude level and higher after the hand-sort removes the six note-matches and the six wrong-sense matches, since both categories were counted as marked. Post-sort, 103 of 114 sites are unmarked and 11 are marked-as-recipient. **Marked-as-agent: zero.**

**Where a king appears at a terminus site, he appears as recipient.** Eleven for eleven, with the giver named in the clause. This is not the absence of a pattern. It is a pattern running the other way, and it converges with the conferral grammar Book VI documents from an entirely different direction, which is the strongest kind of convergence available: two instruments, no shared premise, one result.

**F1 does not fail.** The article's first falsification criterion asked whether the terminal clauses are systematically figure-indexed such that the frame is not removable. On the available witness they are not, and the sites that come closest are sites where the corpus explicitly makes the figure the object.

One caution about the second result, because it is the one most likely to be overstated by a sympathetic reader. Eleven sites is a small number and they cluster in two books, Samuel and Chronicles, which are related. A skeptic can reasonably say that the eleven are one editorial habit rather than a corpus-wide grammar. The reply is that Book VI reaches the same conclusion from Psalms, Deuteronomy, Ezekiel, and Daniel, none of which is in the Chronicler's ambit, and that the convergence is what carries the weight rather than the eleven alone. The eleven on their own would be suggestive. The eleven plus Book VI is a finding.

## CHAPTER 19 · What the Census Leaves Open

The debt is narrowed and it is not paid. Five things remain owed and each is stated so that a reader with better tools can execute it.

**The root-level ratio.** The count that the article named is a Hebrew count and this is an English one. The Authorised Version renders all four roots with rest and renders two of them with quiet, so the ratio of *nwḥ* sites to *šqṭ* sites to *šbt* sites in terminal position is unknown here. It is straightforwardly recoverable by anyone with a Hebrew concordance.

**The pericope test.** The marking test here used a 220-character window, which is an arbitrary proxy for the pericope. A proper execution would mark pericope boundaries and test whether a royal figure stands anywhere within them. That test would return a higher marked count than 20 percent, since pericopes are longer than 220 characters, and the interesting question is how much higher.

**The negative field.** This census counted where the terminus vocabulary appears. It did not count where a royal figure appears without it, which is the complementary question and would say something about whether the two vocabularies avoid each other or merely fail to coincide.

**Verse identification.** The OCR text layer does not carry reliable chapter markers, so the census identifies sites by book and by an inferred verse number, and the inference fails in places. Every verse cited in Chapter 17 has been checked by hand against the text. The unquoted remainder has not been individually verified and no claim is made about any site not quoted.

**The noise floor is unmeasured.** Uncorrected OCR drops and mangles words. A word the OCR destroyed is a site this census never saw. There is no way to estimate the rate from inside the instrument, and the direction of the resulting error is unknown, so no correction is applied and the possibility is simply on the record.

The residual position is this. The census's central result is a grammatical one, and grammar is the part of the Hebrew that English preserves best. The direction of that result is unlikely to reverse under a better instrument. Every other figure in Book II should be treated as provisional and every one of them is recoverable.

## CHAPTER 20 · Šalom Beside the Four, and Why It Is Not a Fifth

A reader who has followed four roots will ask about a fifth, and the answer is that *shalom* belongs to a different category and admitting it would wreck the census.

*Shalom* is not a rest-word. Its root *šlm* carries completeness, wholeness, and the settling of an account. It covers welfare in a greeting, the absence of hostility in a treaty, the soundness of a stone that has not been cut, the payment of a debt, and the state of a person who is unharmed. Genesis 43:27 uses it three times in one exchange about whether an old man is well. 2 Kings 4:26 has the Shunammite say *shalom* over her dead son. Job 9:4 asks who has hardened himself against God *wa-yishlam*, and prospered.

The word's range is wide enough that it can occupy the terminal position, and it does. Isaiah 9:6 gives the *sar shalom* as the fourth throne-name. Isaiah 54:10 has the covenant of *shalom* not removed. Ezekiel 34:25 and 37:26 both make a covenant of *shalom* with the restored people. Numbers 25:12 gives Phinehas the covenant of *shalom*. Micah 5:4 says of the ruler from Bethlehem *we-hayah zeh shalom*.

The reason it is excluded from the census is precisely that range. A word that can mean wholeness, welfare, treaty, payment, and safety cannot be used to test whether the corpus has a *specific* vocabulary for its terminus, because it will match everywhere and the match will carry no information. Including it would have inflated the field from 878 sites to something in the thousands and would have made the marking test meaningless, since *shalom* appears constantly in royal contexts for reasons that have nothing to do with the terminus.

The four roots were chosen because each is narrow. *Šbt* is cessation and its subject is a worker. *Nwḥ* is settlement and its subject is a mover. *Šqṭ* is undisturbedness and its subject is characteristically the land. *Rgʿ* is relief and its subject is a person. Four distinct offices with four distinct subjects and four distinct images, none of them synonyms, and this book does not treat them as such. A fifth word that overlaps all four and much else besides is not a fifth member of that set.

One consequence of the exclusion should be conceded rather than hidden. *Shalom* is the word the tradition most often uses for what this book calls the terminus, and a reader steeped in that tradition will feel its absence throughout. The exclusion is methodological and it is not a claim that *shalom* is unimportant or that the tradition is wrong to use it. It is a claim that a wide word cannot do a narrow test's work.

And there is a positive result inside the exclusion. Deuteronomy 12:10 puts *menuḥah*'s causative beside a different security-word, *wi-shavtem beṭaḥ*, and Jeremiah 30:10 puts *šqṭ* beside *shaʾanan*. The corpus itself distinguishes the settling from the security that follows it, using two words where one would have done. That is a small piece of evidence that the narrow reading of the four roots is the corpus's own and not an imposition, and it is offered at that weight.
