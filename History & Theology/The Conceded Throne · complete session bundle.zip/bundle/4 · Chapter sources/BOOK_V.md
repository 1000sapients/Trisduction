# BOOK V · THE CONCESSION

## CHAPTER 42 · Judges 8:23 · The Refusal

The corpus's opening position on monarchy is a refusal, it is spoken by a man who had just won, and it is spoken in a form that makes the refusal a positive assertion about somebody else.

*Wa-yoʾmeru ʾish Yisraʾel ʾel Gidʿon, meshol banu gam ʾattah gam binkha gam ben binkha, ki hoshaʿtanu mi-yad Midyan. Wa-yoʾmer ʾalehem Gidʿon, loʾ ʾemshol ʾani bakhem we-loʾ yimshol beni bakhem, YHWH yimshol bakhem.*

And the men of Israel said to Gideon: rule over us, you and your son and your son's son also, for you have saved us from the hand of Midian. And Gideon said to them: I will not rule over you, and my son will not rule over you; the LORD will rule over you.

**The offer is dynastic and the corpus makes that explicit.** *Gam ʾattah gam binkha gam ben binkha*, you and your son and your son's son. Three generations named. This is not an offer of leadership; it is an offer of a house, and the offer is made on the basis of a deliverance that has just occurred.

**The refusal is threefold and matches the offer clause by clause.** I will not rule. My son will not rule. Two of the three generations are declined explicitly and the third by implication. Gideon answers the structure of the offer and not merely its substance.

**The reason given is not modesty.** *YHWH yimshol bakhem.* The LORD will rule over you. The refusal is grounded in a positive claim about who does rule, in the imperfect, which in this construction carries present and future force alike. Gideon does not say the office is unnecessary or that he is unworthy. He says it is occupied.

**The verb is *mšl*, not *mlk*.** To rule rather than to reign as king. The distinction matters at the next chapter, because Abimelech's story uses *mlk* throughout and the corpus is not careless with the pair. Gideon declines to rule; his son will claim to be king.

The narrative immediately complicates the refusal and this book will not pretend otherwise.

Verses 24 to 27 have Gideon asking for the golden earrings of the spoil, receiving seventeen hundred shekels of gold, and making an ephod which he sets up in his city, *wa-yiznu khol Yisraʾel ʾaḥaraw sham wa-yehi le-Gidʿon u-le-veyto le-moqesh*, and all Israel went whoring after it there, and it became a snare to Gideon and to his house. Verse 30 says he had seventy sons, *ki nashim rabbot hayu lo*, for he had many wives. Verse 31 names a concubine in Shechem whose son is called Abimelech, which means my father is king.

So the man who refuses the crown accumulates gold, a cult object, a harem, seventy sons, and a son named my-father-is-king. The corpus records all of it in nine verses and offers no comment.

Two readings are available. On one, Gideon's refusal is pious words and the narrative exposes it. On the other, the refusal is genuine and the narrative shows how quickly the substance of kingship accrues to a man who has declined its name. This book does not adjudicate between them, and the argument does not require it. What is load-bearing is the sentence at 8:23, because the corpus puts it in the mouth of the man best placed to accept, at the moment he is offered the throne, and preserves it.

Judges 9 then supplies the corpus's own commentary in the form of a fable, and Chapter 51 takes it up.

Two closing observations.

**The offer is grounded in a deliverance and the deliverance produced the terminus.** Judges 8:28 closes the Gideon cycle with *wa-tishqoṭ ha-ʾareṣ ʾarbaʿim shanah bi-yemey Gidʿon*, and the land was quiet forty years in the days of Gideon. The people ask for a dynasty five verses before the corpus records that the condition they wanted a dynasty to secure had already been delivered under a man who refused one.

**The refusal is never retracted.** The corpus records the demand again at 1 Samuel 8, receives it differently, and never returns to Judges 8:23 to qualify it. The sentence stands unamended in the received text and no later passage says Gideon was wrong.

## CHAPTER 43 · Deuteronomy 17:14 · A Statute Conditioned on Being Asked For

Before the demand is made, the law anticipates it, and the form of the anticipation is the datum.

*Ki tavoʾ ʾel ha-ʾareṣ ʾasher YHWH ʾeloheykha noten lakh wi-rishtah we-yashavtah bah, we-ʾamarta ʾasimah ʿalay melekh ke-khol ha-goyim ʾasher sevivotay. Som tasim ʿaleykha melekh ʾasher yivḥar YHWH ʾeloheykha bo.*

When you come into the land which the LORD your God is giving you, and possess it and dwell in it, and you say: I will set a king over me like all the nations that are round about me. You shall surely set a king over you whom the LORD your God chooses.

**The protasis contains a speech act.** *We-ʾamarta*, and you shall say. The statute is not conditioned on a circumstance, a need, or a threat. It is conditioned on the people saying a sentence. This is unusual in the Deuteronomic legislation, which typically conditions on situations rather than on utterances, and the exception is worth noticing.

**The sentence they will say is quoted in advance.** *ʾAsimah ʿalay melekh ke-khol ha-goyim ʾasher sevivotay.* I will set a king over me like all the nations round about me. The law records the demand verbatim before the demand is made, and 1 Samuel 8:5 will reproduce the operative phrase, *ke-khol ha-goyim*, almost word for word.

**The apodosis regulates rather than commands.** *Som tasim ʿaleykha melekh ʾasher yivḥar YHWH*, you shall surely set a king whom the LORD chooses. The infinitive absolute construction is emphatic and is often read as a positive command. Read against the protasis it is more naturally the regulation of a thing conditioned on being requested: if you say this, then the king you set shall be the one God chooses. A permission with constraints attached is not the same object as an instruction.

**The constraints are then itemized and they are all restrictions.** Verses 15 through 17: from among your brothers and not a foreigner; he shall not multiply horses for himself nor cause the people to return to Egypt to multiply horses; he shall not multiply wives lest his heart turn aside; he shall not greatly multiply silver and gold. Four prohibitions, three of them beginning *loʾ yarbeh*, he shall not multiply.

**And then the positive requirement, which is a copying.** Verses 18 through 20: *we-khatav lo ʾet mishneh ha-torah ha-zoʾt ʿal sefer mi-lifney ha-kohanim ha-Lewiyyim*, he shall write for himself a copy of this law in a book, from before the levitical priests. He shall read in it all the days of his life. Purpose clause: *le-vilti rum levavo me-ʾeḥaw*, that his heart be not lifted up above his brothers.

Chapter 58 works the copying requirement in full. Two things are established here.

**A statute that regulates an anticipated demand is not the same as a statute that establishes an office.** The corpus has forms for establishing offices and uses them: the priesthood at Exodus 28-29, the judges at Deuteronomy 16:18, the cities of refuge at Deuteronomy 19. None of those is conditioned on the people saying they want one. The monarchy alone carries that condition.

**The purpose clause names the same failure Deuteronomy 8 named.** *Rum levavo*, his heart lifted up, is the identical phrase as Deuteronomy 8:14's *ram levavekha*. The law of the king guards against exactly the mechanism the law of prosperity warned about, in the same words, and applies it to the one man most exposed to it. Chapter 58 shows the corpus executing the guard twice on named kings.

## CHAPTER 44 · 1 Samuel 8:5 · Like All the Nations

The demand arrives and the corpus quotes it.

*Wa-yoʾmeru ʾelaw, hinneh ʾattah zaqanta u-vaneykha loʾ halkhu bi-derakheykha, ʿattah simah lanu melekh le-shofṭenu ke-khol ha-goyim.*

And they said to him: behold, you are old and your sons do not walk in your ways; now set us a king to judge us like all the nations.

**The stated grounds are two and both are real.** Samuel is old. His sons are corrupt, and the corpus has just said so at 8:3: *wa-yiṭṭu ʾaḥarey ha-baṣaʿ wa-yiqḥu shoḥad wa-yaṭṭu mishpaṭ*, they turned aside after gain, took bribes, and perverted judgment. The demand is not made out of nothing. It responds to a succession problem and to a documented failure of the existing arrangement.

**The office requested is judging.** *Le-shofṭenu*, to judge us. That is the function the judges of the previous book performed and that Samuel is performing and that his sons are performing badly. So the request is not for a new function.

**The requested form is foreign and the corpus quotes the phrase.** *Ke-khol ha-goyim*, like all the nations. Deuteronomy 17:14 predicted this phrase and 1 Samuel 8:5 delivers it. The people say it again at 8:20 in an expanded form: *we-hayinu gam ʾanaḥnu ke-khol ha-goyim u-shefaṭanu malkenu we-yaṣaʾ le-faneynu we-nilḥam ʾet milḥamoteynu*, that we also may be like all the nations, and our king may judge us and go out before us and fight our battles.

**Judges already existed.** This is the observation that fixes the character of the demand. Israel had judging. It had had judging for the whole span of the previous book, delivered by ordinary agents, with the terminus attached four times. The request replaces an existing function with a different form of the same function. The demand is therefore about form and not about function, and the form named is the neighbours'.

Two clarifications, because this reading can be pushed too far.

**The demand is not unreasonable and the corpus does not say it is.** A hereditary judiciary that has gone corrupt in one generation, with no mechanism for replacing it, is a real institutional failure. The people are asking for a solution to a problem the corpus has just documented. Nothing in 1 Samuel 8 suggests they were wrong about the problem.

**The added element at 8:20 is military and it is new.** Going out before us and fighting our battles is not the judges' function as Judges describes it, though several judges fought. The expanded demand at 8:20 asks for a standing military leader with a hereditary office, which is a different institution from an intermittently raised deliverer.

Samuel's reaction is recorded and is worth having. 8:6: *wa-yeraʿ ha-davar be-ʿeyney Shemuʾel ka-ʾasher ʾameru tenah lanu melekh le-shofṭenu, wa-yitpallel Shemuʾel ʾel YHWH.* The thing was evil in the eyes of Samuel when they said give us a king to judge us, and Samuel prayed to the LORD.

The corpus records the prophet's displeasure and then, in the next verse, has God tell him the displeasure is misdirected. That is the subject of the next chapter and it is the most quoted sentence in the whole transaction.

## CHAPTER 45 · 1 Samuel 8:7 · Rejected, Not Ended

*Wa-yoʾmer YHWH ʾel Shemuʾel, shemaʿ be-qol ha-ʿam le-khol ʾasher yoʾmeru ʾeleykha, ki loʾ ʾotekha maʾasu ki ʾoti maʾasu mi-melokh ʿaleyhem.*

And the LORD said to Samuel: listen to the voice of the people in all that they say to you, for they have not rejected you but they have rejected me from reigning over them.

Every word of the second clause repays attention because the sentence is precise in a way its usual paraphrase is not.

**The verb is *mʾs*, to reject or refuse.** It is a verb of the receiver. One rejects an offer, a person, a proposal. It is not a verb of removal or of cessation.

**The object is the first person.** *ʾOti maʾasu*, me they have rejected. Not my rule as an institution, not the arrangement, not the covenant. The pronoun.

**The prepositional phrase specifies the respect.** *Mi-melokh ʿaleyhem*, from reigning over them. The rejection is of the reigning as it bears on them.

**What the clause does not say.** It does not say the reign ended. It does not say the reign was suspended, withdrawn, transferred, or replaced. It does not say God ceased to rule. It says they rejected him from reigning over them, which leaves the sovereignty untouched and changes only its acceptance.

That distinction is the whole of Chapter 45 and it is not a subtlety invented for the occasion. The corpus states the continuing sovereignty repeatedly and in the same period. 1 Samuel 12:12 has Samuel say *wa-YHWH ʾeloheykhem malkekhem*, and the LORD your God is your king, spoken after Saul has been made king. Psalm 93:1, Psalm 97:1, and Psalm 99:1 all open *YHWH malakh*, the LORD reigns, in a group of psalms whose whole subject is that reign. Isaiah 6:5 has the prophet say *ʾet ha-melekh YHWH ṣevaʾot raʾu ʿeynay*, my eyes have seen the King, the LORD of hosts, in a vision dated to the year king Uzziah died.

So the corpus asserts the reign continuing, during the monarchy, in three of its major divisions.

**The consequence.** What changed at 1 Samuel 8 was not the sovereignty but its acceptance, and therefore its visibility. That is a claim about the transaction, and it is the corpus's own claim rather than an inference from it. The people asked for a *visible* sovereign of the neighbours' kind, and the corpus says the request was a rejection of the one they had, whose reign the corpus goes on asserting.

Verse 8 supplies the precedent: *ke-khol ha-maʿasim ʾasher ʿasu mi-yom haʿaloti ʾotam mi-Miṣrayim we-ʿad ha-yom ha-zeh, wa-yaʿazvuni wa-yaʿavdu ʾelohim ʾaḥerim, ken hemah ʿosim gam lakh.* According to all the works they have done from the day I brought them up from Egypt until this day, forsaking me and serving other gods, so they do also to you.

The corpus categorizes the demand with the golden calf and its successors. That is a strong categorization and it is the corpus's, not this book's.

And then verse 9, which is the hinge of the whole passage. *We-ʿattah shemaʿ be-qolam, ʾakh ki haʿed taʿid bahem we-higgadta lahem mishpaṭ ha-melekh ʾasher yimlokh ʿaleyhem.* Now listen to their voice, only you shall solemnly warn them and tell them the manner of the king who will reign over them.

Grant, with a warning. The warning is the subject of the next chapter and it is itemized.

## CHAPTER 46 · 1 Samuel 8:11-18 · The Itemized Bill

The corpus prints the cost of the monarchy in advance, item by item, in the voice of the prophet at the moment of the grant. There is nothing else like it in the ancient Near Eastern royal material and its preservation is the most striking editorial fact in the books of Samuel.

*Wa-yoʾmer, zeh yihyeh mishpaṭ ha-melekh ʾasher yimlokh ʿaleykhem.* This will be the manner of the king who will reign over you.

**Your sons.** He will take them for his chariots and his horsemen, and they will run before his chariots. He will appoint them commanders of thousands and of fifties, and to plough his ground and reap his harvest, and to make his weapons and the equipment of his chariots.

**Your daughters.** *We-ʾet benoteykhem yiqqaḥ le-raqqaḥot u-le-ṭabbaḥot u-le-ʾofot.* He will take for perfumers, cooks, and bakers.

**Your fields, vineyards, and olive groves.** *We-ʾet sedoteykhem we-ʾet karmeykhem we-zeyteykhem ha-ṭovim yiqqaḥ we-natan la-ʿavadaw.* The best of them, taken and given to his servants.

**A tenth of your seed and of your vineyards.** Given to his officers and servants.

**Your male and female servants, your best young men, and your donkeys.** *We-ʿasah li-melaʾkhto.* Put to his work.

**A tenth of your flocks.**

**And the summary.** *We-ʾattem tihyu lo la-ʿavadim.* And you shall be his servants.

The verb *lqḥ*, to take, appears six times in eight verses. It is the structural spine of the speech. Nothing in the list is given to the people; every item is a transfer from them.

Two features convert this from a warning into something with a different force.

**The tenth.** Two of the items are a tenth, on seed and vineyards at verse 15 and on flocks at verse 17. That is the tithe rate, and the tithe in this corpus belongs to the sanctuary and to the Levite. The king's claim is stated at the rate of a sacral due, which is a way of saying what kind of claim it is.

**The final clause, verse 18, which converts warning into contract.** *U-zeʿaqtem ba-yom ha-huʾ mi-lifney malkekhem ʾasher beḥartem lakhem, we-loʾ yaʿaneh YHWH ʾetkhem ba-yom ha-huʾ.*

And you will cry out in that day because of your king whom you have chosen for yourselves, and the LORD will not answer you in that day.

Chapter 47 is about that clause alone.

One further note on the whole speech. Samuel is instructed at 8:9 to *haʿed taʿid*, solemnly warn, using the same verb as Deuteronomy 30:19's *ha-ʿidoti*, I call to witness. The legal register is deliberate. The people are being told the terms before they accept, in a form the corpus uses for covenant witness, and 1 Samuel 12:17-19 will have them acknowledge afterwards that they had been told.

## CHAPTER 47 · 1 Samuel 8:18 · The Unanswered-Outcry Clause

*U-zeʿaqtem ba-yom ha-huʾ mi-lifney malkekhem ʾasher beḥartem lakhem, we-loʾ yaʿaneh YHWH ʾetkhem ba-yom ha-huʾ.*

And you will cry out in that day because of your king whom you have chosen for yourselves, and the LORD will not answer you in that day.

This is the most consequential single clause in Book V and it is usually passed over as rhetorical emphasis. It is not rhetorical. It is a stated exclusion, and it excludes the mechanism the corpus had used for the whole preceding book.

**The verb *ṣʿq* is the corpus's technical term for the covenant outcry.** Exodus 2:23: *wa-yizʿaqu wa-taʿal shawʿatam ʾel ha-ʾelohim*, and they cried out and their cry went up to God. Exodus 22:22, of the widow and orphan: *ki ʾim ṣaʿoq yiṣʿaq ʾelay shamoaʿ ʾeshmaʿ ṣaʿaqato*, if he cries at all to me, I will surely hear his cry. And throughout Judges: *wa-yizʿaqu venei Yisraʾel ʾel YHWH* at 3:9, at 3:15, at 4:3, at 6:6, at 10:10. Five times in the book that delivers the terminus four times, and in each case the outcry is followed by a deliverer.

**The Judges cycle is: sin, oppression, outcry, deliverer, quiet.** The outcry is the mechanism by which the cycle turns. Remove it and the cycle cannot complete.

**1 Samuel 8:18 removes it, for this cause, in advance.** *We-loʾ yaʿaneh YHWH ʾetkhem.* The LORD will not answer you. Not will delay, not will answer differently. Will not answer.

Three consequences and each is checkable.

**The grant carries a stated exclusion from the remedy.** The people are told, before they choose, that the standard mechanism for relief from oppression will not operate against the oppression they are choosing. That converts the speech from a warning about consequences into a statement of terms.

**The exclusion is grounded in the choosing.** *ʾAsher beḥartem lakhem*, whom you have chosen for yourselves. The reflexive *lakhem* is emphatic: chosen by you, for you. The corpus attaches the exclusion to the fact that the thing was requested, which is the same structure as Deuteronomy 17:14's conditioning of the statute on the demand.

**The corpus does not repeat the exclusion and does not revoke it.** There is no later passage stating that the outcry-clause was lifted. There are, however, passages in which the corpus records outcry against kings and records a response: Elijah against Ahab, Nathan against David, and the whole prophetic tradition of indictment. Whether those constitute an answer in the sense 8:18 denies is a question the corpus does not address, and this book does not resolve it.

One reading should be set aside explicitly because it is available and this book does not take it. The clause could be read as a prediction that turned out false, since kings were opposed and prophets were sent. That reading requires taking *loʾ yaʿaneh* as a forecast rather than a term, and the surrounding legal register at 8:9 tells against it. But the reading exists, it is not absurd, and a reader who takes it will weaken this chapter without touching Chapters 44 through 46.

## CHAPTER 48 · 1 Samuel 8:19-22 · The Refusal to Hear, and the Grant

*Wa-yemaʾanu ha-ʿam li-shmoaʿ be-qol Shemuʾel, wa-yoʾmeru loʾ ki ʾim melekh yihyeh ʿaleynu.*

And the people refused to listen to the voice of Samuel, and they said: no, but a king shall be over us.

**The verb of refusal is *mʾn*, to be unwilling.** It is not an inability. Compare Exodus 7:14 of Pharaoh, *meʾen le-shallaḥ ha-ʿam*, he is unwilling to let the people go, and Jeremiah 5:3, *meʾanu qaḥat musar*, they refused to take correction, and Jeremiah 6:16's *wa-yomeru loʾ nelekh*, which is the same shape with the refusal quoted rather than named.

**The refusal is to *hear*.** *Li-shmoaʿ be-qol.* This is the receiving organ of Book IV in the middle of the monarchy transaction. The corpus states the demand for a king as a failure of the same faculty it names at Deuteronomy 29:3, at Isaiah 6:10, and at Psalm 95:7.

**The refusal is quoted.** *Loʾ ki ʾim melekh yihyeh ʿaleynu.* No, but a king shall be over us. Two words of refusal and a declarative.

Verse 20 then expands the demand, as Chapter 44 noted: like all the nations, our king judging us, going out before us, fighting our battles.

Verse 21: Samuel hears all the words of the people and speaks them in the ears of the LORD. The corpus takes the trouble to say the demand was reported verbatim.

Verse 22: *wa-yoʾmer YHWH ʾel Shemuʾel, shemaʿ be-qolam we-himlakhta lahem melekh.* And the LORD said to Samuel: listen to their voice and make them a king.

**The grant is a command to Samuel and it is unconditional at this point.** No further warning, no further condition, no delay. The grant issues.

**The grammar of the whole transaction is now complete and it has a shape.** The people refuse to hear. God tells Samuel to hear them. The verb *shmʿ* appears on both sides of the transaction: *wa-yemaʾanu ha-ʿam li-shmoaʿ*, the people refused to hear, and *shemaʿ be-qolam*, listen to their voice. The corpus builds the reversal into the vocabulary.

Two things this chapter does not claim.

**It does not claim the grant was reluctant in a way the text states.** The text does not supply an adverb. Hosea 13:11 will supply one and Chapter 50 uses it, but 1 Samuel 8:22 is bare.

**It does not claim Saul's kingship was illegitimate.** The corpus proceeds immediately to anoint him at 10:1, has Samuel present him at Mizpah, and has Samuel defend him. Whatever the transaction was, its product is treated as real. The claim of Book V is about how the corpus characterizes the transaction, not about whether the institution it produced was valid.

## CHAPTER 49 · 1 Samuel 12 · The Farewell, and the Rain Out of Season

Samuel's farewell speech is the corpus's own summary of the transaction it has just narrated, and it contains a scene that is easy to skip and hard to explain away.

The speech opens with an accounting. 12:3: *hinneni ʿanu vi neged YHWH we-neged meshiḥo, ʾet shor mi laqaḥti wa-ḥamor mi laqaḥti u-mi ʿashaqti ʾet mi raṣṣoti u-mi-yad mi laqaḥti khofer.* Here I am; testify against me before the LORD and before his anointed: whose ox have I taken, whose donkey have I taken, whom have I defrauded, whom have I oppressed, from whose hand have I taken a bribe?

The verb is *lqḥ*, taken, three times. It is the same verb that ran six times through the bill at 8:11-18. Samuel is answering the king's manner point by point with a denial in the same vocabulary, and the people answer at 12:4: *loʾ ʿashaqtanu we-loʾ raṣṣotanu we-loʾ laqaḥta mi-yad ʾish meʾumah*, you have not defrauded us nor oppressed us nor taken anything from any man's hand.

The corpus has just contrasted the judge who took nothing with the king who will take everything, using one verb, in four chapters.

Verse 12 supplies the diagnosis in Samuel's own words: *wa-tirʾu ki Naḥash melekh benei ʿAmmon baʾ ʿaleykhem wa-toʾmeru li loʾ ki melekh yimlokh ʿaleynu, wa-YHWH ʾeloheykhem malkekhem.* You saw that Nahash king of the Ammonites came against you, and you said to me: no, but a king shall reign over us; and the LORD your God is your king.

Two things there. The demand is dated to a military threat, which the narrative of chapter 8 did not mention and which supplies a further motive. And the final clause asserts the continuing reign in the present tense, after Saul has been made king, which Chapter 45 used.

Then the scene.

Verses 16 through 19. *Ha-loʾ qeṣir ḥiṭṭim ha-yom, ʾeqraʾ ʾel YHWH we-yitten qolot u-maṭar, u-deʿu u-reʾu ki raʿatkhem rabbah ʾasher ʿasitem be-ʿeyney YHWH li-shʾol lakhem melekh.* Is it not wheat harvest today? I will call to the LORD and he will send thunder and rain, that you may know and see that your wickedness is great which you have done in the sight of the LORD in asking for yourselves a king.

Wheat harvest in that climate falls in the dry season. Rain then is destructive and out of season, and the sign is chosen for that reason.

Verse 18: he called, and the LORD sent thunder and rain that day, and all the people greatly feared the LORD and Samuel.

Verse 19: *wa-yoʾmeru khol ha-ʿam ʾel Shemuʾel, hitpallel beʿad ʿavadeykha ʾel YHWH ʾeloheykha we-ʾal namut, ki yasafnu ʿal kol ḥaṭṭoʾteynu raʿah li-shʾol lanu melekh.* And all the people said to Samuel: pray for your servants to the LORD your God that we die not, for we have added to all our sins this evil, to ask for ourselves a king.

**The people name the asking an evil, after the fact, in their own words.** That is the corpus's own retrospective verdict on the transaction, placed in the mouths of the parties who made the demand, four chapters after they made it.

And then verse 20, which is the reason this chapter matters as much for what follows as for what precedes. *Wa-yoʾmer Shemuʾel ʾel ha-ʿam, ʾal tiraʾu, ʾattem ʿasitem ʾet kol ha-raʿah ha-zoʾt, ʾakh ʾal tasuru me-ʾaḥarey YHWH wa-ʿavadtem ʾet YHWH be-khol levavkhem.* Do not fear. You have done all this evil, yet do not turn aside from following the LORD, but serve the LORD with all your heart.

The evil is affirmed and the relation is not withdrawn. Verse 22: *ki loʾ yiṭṭosh YHWH ʾet ʿammo ba-ʿavur shemo ha-gadol*, the LORD will not forsake his people for his great name's sake. Verse 23: *gam ʾanokhi ḥalilah li me-ḥaṭoʾ la-YHWH me-ḥadol le-hitpallel baʿadkhem*, far be it from me that I should sin against the LORD in ceasing to pray for you.

That is the shape the corpus holds throughout: the transaction named as an evil, the parties named as having done it, the relation continued, the concession standing. Chapter 50 supplies the price and Chapter 76 supplies the permanence.

## CHAPTER 50 · Hosea 13:11 · Priced in Anger

*ʾEtten lekha melekh be-ʾappi we-ʾeqqaḥ be-ʿevrati.*

I gave you a king in my anger and took him away in my wrath.

Four words carry the chapter and two of them are the adverbial phrases.

**The giving is stated in the first person with a prepositional phrase of manner.** *Be-ʾappi*, in my anger. The noun *ʾaf* is the nostril and by extension the flaring of anger, and the phrase is common in the corpus for divine wrath. The grant of monarchy is characterized by the giver, and the characterization is not favourable.

**The taking is likewise characterized.** *Be-ʿevrati*, in my wrath. *ʿEvrah* is overflow, the sense of anger passing a limit.

**The tenses are debated and the debate does not affect the point.** *ʾEtten* is imperfect and *ʾeqqaḥ* is imperfect; both can be read as past-durative, as present, or as future. The standard reading takes them as past with reference to the whole institution or as iterative with reference to the northern dynasties. Hosea's context at 13:10, *ʾehi malkekha ʾefo we-yoshiʿakha be-khol ʿareykha*, where now is your king that he may save you in all your cities, supports the reading that this is about kings failing to save. Nothing in this chapter depends on the choice.

**The critical question is what the taking takes.** This is F2, and it is the falsifier Book V's argument is most exposed to. If Hosea 13:11 records the withdrawal of the concession, then the corpus does withdraw and Chapter 84's whole account of escalation without withdrawal is wrong.

Three reasons it does not.

**The object is a king, not the kingship.** *ʾEtten lekha melekh*, I gave you a king, singular, indefinite. *We-ʾeqqaḥ*, and I took, with the object supplied by the preceding noun. What is given and taken is an occupant. The corpus has vocabulary for institutions and does not use it here.

**Hosea's own context is a sequence of occupants.** 13:10 asks where the king is. 7:7 says *kol malkeyhem nafalu*, all their kings have fallen. 8:4 says *hem himlikhu we-loʾ mimmenni*, they set up kings and not from me. The northern kingdom went through nine dynasties in two centuries and Hosea's material is saturated with that instability. A statement about kings being given and removed reads naturally against it.

**The corpus states the non-withdrawal explicitly elsewhere and Hosea does not contradict it.** 2 Samuel 7:15, *we-ḥasdi loʾ yasur mimmennu ka-ʾasher hasiroti me-ʿim Shaʾul*, my covenant loyalty shall not depart from him as I took it from Saul. The clause names a removal from Saul, an occupant, and bars the corresponding removal from the house. That is the corpus distinguishing between removing a man and removing the grant, in one verse, using the same verb for both halves.

So the F2 search returns nothing. There is no withdrawal formula anywhere in the corpus. There are removals of kings, in quantity: Saul, the northern dynasties, Jehoiachin at Jeremiah 22:24-30, Zedekiah. Every one of them is the removal of an occupant.

What Hosea 13:11 does establish, and it is worth having, is that the corpus's own characterization of the grant is negative at the point of giving. That is a second witness to what 1 Samuel 8 said in narrative, delivered by a prophet in a different kingdom in a different vocabulary.

## CHAPTER 51 · Gideon, Abimelech, and the Fable of the Bramble

Judges 9 is the corpus's own commentary on kingship and it takes the form of a fable told from a hilltop by a man expecting to be killed.

The narrative first. Abimelech, Gideon's son by the concubine at Shechem, persuades his mother's kin to back him, takes seventy pieces of silver from the temple of Baal-berith, hires *ʾanashim reqim u-foḥazim*, empty and reckless men, and kills his seventy brothers on one stone at Ophrah. Jotham, the youngest, escapes. Abimelech is made king at Shechem by the terebinth of the pillar.

Jotham then stands on the top of Mount Gerizim, lifts his voice, and tells the fable.

*Halokh halkhu ha-ʿeṣim li-mshoaḥ ʿaleyhem melekh.* The trees went out to anoint a king over them.

They ask the olive. *Wa-yoʾmer lahem ha-zayit, he-ḥodalti ʾet dishni ʾasher bi yekhabbedu ʾelohim wa-ʾanashim we-halakhti la-nuaʿ ʿal ha-ʿeṣim.* Should I leave my fatness, by which they honour God and man, and go to sway over the trees?

They ask the fig. Should I leave my sweetness and my good fruit, and go to sway over the trees?

They ask the vine. *He-ḥodalti ʾet tiroshi ha-mesammeaḥ ʾelohim wa-ʾanashim.* Should I leave my new wine, which cheers God and man, and go to sway over the trees?

Then they ask the bramble. *Wa-yoʾmer ha-ʾaṭad ʾel ha-ʿeṣim, ʾim be-ʾemet ʾattem moshḥim ʾoti le-melekh ʿaleykhem, boʾu ḥasu ve-ṣilli, we-ʾim ʾayin teṣeʾ ʾesh min ha-ʾaṭad we-toʾkhal ʾet ʾarzey ha-Levanon.* If in truth you anoint me king over you, come and take refuge in my shade; and if not, let fire come out of the bramble and devour the cedars of Lebanon.

Four observations.

**Three productive trees decline and each gives the same reason.** Each names what it produces, each names who benefits, and each uses the identical verb of the office: *la-nuaʿ*, to sway or wave. The word is not *mšl* or *mlk* but a verb of motion above others, and it is chosen to make the office sound like tossing in the wind.

**The three declines are the Judges 8:23 refusal repeated three times in a different register.** Gideon declined. The olive, fig, and vine decline. The corpus states the refusal four times in two chapters.

**The bramble accepts, and it has nothing to leave.** The *ʾaṭad* is a thorny scrub with no fruit and no useful product. It is the only candidate that surrenders nothing by taking the office, and the corpus makes that the qualification.

**Its offer of shade is the joke and its threat is the point.** A bramble casts no shade a person could shelter in. And the alternative it names is fire from itself devouring the cedars of Lebanon, which is a threat of total destruction from the least of the plants against the greatest.

Jotham's application is explicit at 9:16-20, and the narrative fulfils it at 9:56-57: God repaid the wickedness of Abimelech, and all the wickedness of the men of Shechem, and *wa-tavoʾ ʾalehem qilelat Yotam ben Yerubbaʿal*, the curse of Jotham came upon them.

Two structural notes for this book.

**The verb of the fable is *mšḥ*, to anoint.** *Li-mshoaḥ ʿaleyhem melekh*, to anoint a king over them, and *moshḥim ʾoti le-melekh*, anointing me king. The corpus's first use of the anointing verb for a king is in a fable ridiculing the exercise, spoken about a fratricide. Chapter 64 works the rite and notes this.

**The fable is preserved in a corpus that also preserves the royal psalms.** That is Book X's subject and this is one of its ten pairs. A tradition operating by selection does not keep Judges 9 and Psalm 45 on one scroll.

## CHAPTER 52 · The Two Strands, and Why the Final Form Is the Datum

Book V has read 1 Samuel 8 through 12 as a single transaction with a determinate shape: refusal, demand, diagnosis, itemized bill, exclusion clause, refusal to hear, grant, retrospective confession, price. A reader trained in the source-critical treatment of these chapters will object that this reads as one thing what is demonstrably two.

The objection is serious and the response is not a rebuttal.

**The classical analysis.** Since Wellhausen the material has been divided into a pro-monarchic strand and an anti-monarchic one. The pro-monarchic material is usually located at 9:1-10:16, Saul's anointing in the search for the donkeys, at 11:1-11, the deliverance of Jabesh-gilead, and at 11:15, the kingship renewed at Gilgal. The anti-monarchic material is located at chapter 8, at 10:17-27, the selection by lot with Saul hiding among the baggage, and at chapter 12. The division is not arbitrary; the two bodies differ in vocabulary, in their attitude to the institution, and in their account of how Saul became king, and the second difference is the hardest to explain on a single-source reading.

**This book takes no position on it.** The analysis may be right in whole, in part, or not at all. Nothing in Book V depends on the outcome, and any position taken would be a position taken outside this book's competence.

**What this book does claim is that the final form's retention of both is the datum.**

That claim needs stating precisely because it is easily read as a dodge.

Somebody assembled this material. Whoever it was had the anti-monarchic material and the pro-monarchic material and produced a text containing both. Chapter 8's itemized bill sits four chapters before chapter 12's thunder and rain, and 9:1-10:16's warm account of Saul's anointing sits between them. That arrangement was made.

Three things follow from the arrangement itself, none of which requires a view about the sources.

**The result is not a smooth apologia and it was not made into one.** A redactor wanting a clean account of the founding of the monarchy had the material to produce one and did not. The bill, the exclusion clause, the divine categorization of the demand with the golden calf, and the people's own confession are all retained, in a work that goes on to celebrate David at length.

**The retention is a pattern rather than an accident, because the same corpus does it repeatedly.** Judges 8:23 and Judges 9's fable are retained beside 2 Samuel 7's permanence. Deuteronomy 23:4's bar on Moabites is retained beside Ruth 4:18-22's genealogy through a Moabite. Jeremiah 22:30's childless Coniah is retained beside Haggai 2:23's signet Zerubbabel. Book X counts ten such pairs. A corpus that does this once has had an accident. A corpus that does it ten times has a habit.

**A habit of retention is evidence about the corpus's relation to its own contents.** Specifically: the corpus is not optimized to produce a single coherent position on the monarchy, and a reader who extracts one has extracted it. This book extracts one too, and Chapter 108 says so under the heading of limits.

One last observation, offered as an observation and not as an argument. The two strands, if they exist, disagree about whether the monarchy was good. They do not disagree about the structure Book V has described. The pro-monarchic material has Samuel anoint Saul at God's direction, which is a conferral with a named giver, and has the kingdom renewed at Gilgal *lifney YHWH*, before the LORD. The anti-monarchic material has the throne granted under protest. Both have the office as something received from outside itself. Chapter 62's finding survives the source division, which is the strongest thing that can be said for a reading that declines to enter it.
