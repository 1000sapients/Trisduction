# BOOK IX · THE TREE

## CHAPTER 85 · Job 14:7-9 · Three Parts, Three Rulings

The corpus divides the felled tree into three parts and rules on each in three successive clauses, and the ruling is in a book nobody reads for messianic material.

*Ki yesh la-ʿeṣ tiqwah, ʾim yikkaret ʿod yaḥalif we-yonaqto loʾ teḥdal. ʾIm yazqin ba-ʾareṣ shorsho u-ve-ʿafar yamut gizʿo. Me-reaḥ mayim yafriaḥ we-ʿasah qaṣir kemo naṭaʿ.*

For there is hope for a tree: if it is cut down it will sprout again, and its shoot will not cease. Though its root grows old in the earth and its stump dies in the dust, at the scent of water it will bud and put out branches like a plant.

**Clause one: the tree has hope.** *Yesh la-ʿeṣ tiqwah.* Stated as a general proposition about trees, in a speech whose whole burden is that man has no such hope: 14:10 continues *we-gever yamut wa-yeḥelash, wa-yigwaʿ ʾadam we-ʾayyo*, but man dies and is laid low; man breathes his last, and where is he? The tree-image in Job is a contrast, not a promise.

**Clause two divides the underground parts and rules on each separately.** *ʾIm yazqin ba-ʾareṣ shorsho*, though its root grow old in the earth. *U-ve-ʿafar yamut gizʿo*, and its stump die in the dust.

**The root persists. The stump dies.** Two nouns, two verbs, in one verse, distinguished.

**Clause three names the trigger.** *Me-reaḥ mayim yafriaḥ*, at the scent of water it buds. The verb *rwḥ* in this form is a hapax construction and the sense is a perceiving of moisture. What revives the tree is not planting, watering, or tending. It is the presence of water already in the ground, detected.

Three observations, each of which the next chapters develop.

**The corpus has ruled on the stump and the ruling is that it dies.** That is a statement in the corpus's own words, in a wisdom book, about the part of a felled tree named *gezaʿ*.

**The corpus has ruled on the root and the ruling is that it persists.** *Shoresh*, root, growing old in the earth but not said to die.

**And the trigger is a presence rather than an arrival.** The water is already there. The tree does not receive it; it detects it. Chapter 87 works that.

One methodological note. Job is speaking in a lament and the passage is an argument for human hopelessness by contrast with vegetable resilience. Reading it as botanical doctrine would be reading a lament as a treatise. What this book takes from it is narrower: the corpus, at some point, in some register, distinguished the fate of a stump from the fate of a root, and used the words *gezaʿ* and *shoresh* to do it. That distinction is available to the corpus and Isaiah 11:1 uses both nouns in one verse.

## CHAPTER 86 · The Stump Dies in the Dust

*U-ve-ʿafar yamut gizʿo.*

The word *gezaʿ* occurs three times in the Hebrew Bible and this chapter takes all three, because a three-occurrence word can be surveyed completely.

**Job 14:8.** The stump dies in the dust.

**Isaiah 40:24.** *ʾAf bal niṭṭaʿu ʾaf bal zoraʿu ʾaf bal shoresh ba-ʾareṣ gizʿam, we-gam nashaf bahem wa-yivashu u-seʿarah ka-qash tissaʾem.* Scarcely are they planted, scarcely sown, scarcely has their stock taken root in the earth, when he blows on them and they wither and the storm carries them away like stubble. The subject is the princes and judges of the earth at 40:23, whom God brings to nothing. The *gezaʿ* here is the stock that fails to root.

**Isaiah 11:1.** *We-yaṣaʾ ḥoṭer mi-gezaʿ Yishay.* A shoot shall come out from the stump of Jesse.

**Three occurrences. Two of them state the stock's failure and one states a shoot coming from it.**

That is the tension and this book neither resolves it nor treats it as a fatal problem for anyone's reading. Three observations frame it.

**The two negative sites are not about the same object as Isaiah 11.** Job 14 is a general proposition about felled trees. Isaiah 40:24 is about the princes of the earth. Isaiah 11:1 is about the house of Jesse. A word can behave differently in three contexts and usually does.

**But the vocabulary is the corpus's own and it is narrow.** Three occurrences is a small enough field that the corpus's usage can be surveyed, and what the survey shows is that in two of three the *gezaʿ* is the part that does not carry on.

**And Isaiah 11:1 names a second source in its second half.** *We-neṣer mi-shorashaw yifreh*, and a branch from his roots shall grow. Stump in the first colon, roots in the second. Chapter 88 takes that up and it is the chapter this book most expects to be disagreed with.

Two further terms belong in the field and are worth distinguishing so that they are not conflated.

**Maṣṣevet**, at Isaiah 6:13, which Chapter 89 works. A different noun, usually taken as the stump or the standing part of a felled tree, and used in the corpus's other passage about a cut tree with a surviving element.

**Geza and gezaʿ are not to be confused with *shoresh*, root, which is common** and appears throughout in both literal and figurative senses: the root of the righteous at Proverbs 12:12, the root of Jesse at Isaiah 11:10, roots dried up at Hosea 9:16, and the root and branch formula at Malachi 3:19.

The point of the survey is not to settle Isaiah 11:1's botany. It is to establish that the corpus has a specific and small vocabulary for the parts of a felled tree, that it uses that vocabulary with some care, and that it says different things about different parts.

## CHAPTER 87 · The Root Persists, and the Trigger Is Water Already There

Job 14:8-9 rules that the root grows old in the earth without dying and that the trigger for regrowth is *reaḥ mayim*, the scent of water.

Both halves of that repay attention because both are counter-intuitive.

**The root's persistence is stated as endurance rather than as vitality.** *ʾIm yazqin ba-ʾareṣ shorsho*, though its root grow old in the earth. The verb is *zqn*, to age. The root is not described as vigorous, hidden, or protected. It is described as old. What it does is remain.

**The trigger is detection, not supply.** *Me-reaḥ mayim yafriaḥ.* At the scent of water it buds. The preposition *min* is causal here: from, or on account of, the scent. Water in the ground is perceived and the perception is sufficient.

**Nothing arrives.** No rain is mentioned. No planter waters it. No agent acts on the stump. The water is present and the tree responds to its presence.

Three connections to the argument of this book, each offered at its own weight.

**The strongest is structural and it is offered as an image rather than as an argument.** Book III established that the terminus is a state, present and unentered. Book IV established that the corpus locates the failure in a receiving faculty. Job 14:9 supplies a picture of exactly that arrangement: a resource already in the ground, a perception of it, and a response. Whether Job intended any such connection is unknowable and this book does not claim it. The picture is in the corpus and it is the corpus's own.

**The second is lexical and it is checkable.** The verb behind *reaḥ* is the same root as *wa-hariḥo be-yirʾat YHWH* at Isaiah 11:3, usually rendered his delight shall be in the fear of the LORD and literally something like his smelling. The corpus uses a scent-verb for the equipped figure's mode of discernment and for the felled tree's mode of detecting water. Two sites, one unusual verb, both about perceiving something not seen. This book records the coincidence and builds nothing on it, since two occurrences of a rare verb in two genres is thin evidence for anything.

**The third is negative and it is a fence.** Job 14 is a lament and the tree is a contrast to man. Building a doctrine of resurrection or of national restoration on it would be reading against its argument. This book takes the botany and leaves the polemic.

One further observation about the direction of the passage. Job's point is that the tree has what man lacks. If the tree-image is then applied to Israel, as Isaiah 11 applies a related image to Jesse's house, the application is a claim that the nation has what an individual does not. Whether the corpus intends that is unknown. That the two passages use overlapping vocabulary about a cut tree is a fact.

## CHAPTER 88 · Isaiah 11:1 · Two Sources, One Verse, Unreconciled

*We-yaṣaʾ ḥoṭer mi-gezaʿ Yishay we-neṣer mi-shorashaw yifreh.*

This chapter makes the observation this book most expects to be contested, and states the objection to it as clearly as the observation.

**The verse names two sources in two cola.** A shoot from the stump. A branch from the roots. *Gezaʿ* and *shorashaw*. Two different nouns for two different parts of a tree.

**And Job 14:8 has ruled on both, distinguishing them.** The root grows old and persists. The stump dies in the dust.

**So the corpus states both, and reconciles them nowhere.** Isaiah 11:1 grows a shoot from a part that Job 14:8 says dies. The corpus contains both sentences and no passage anywhere addresses the relation.

**The objection, stated at full strength.** Hebrew poetry is parallelistic. The two cola of Isaiah 11:1 are a standard synonymous parallelism, in which the second colon restates the first in different words. On that reading *gezaʿ* and *shorashaw* are not two sources but one source named twice, and the whole observation dissolves into a failure to recognize a poetic convention.

That objection is good and it may be right. Three things can be said in reply and none of them is decisive.

**Synonymous parallelism is rarely purely synonymous.** The dominant view in the study of Hebrew poetry for the last half-century has been that the second colon typically sharpens, specifies, intensifies, or advances the first rather than merely repeating it. On that view the shift from *gezaʿ* to *shorashaw* is doing something, and what it is doing is a question rather than a non-question.

**The corpus uses the two nouns differently elsewhere.** *Shoresh* is common and is used of persistence: Isaiah 37:31, *we-yasfah peleyṭat beyt Yehudah ha-nishʾarah shoresh le-maṭṭah we-ʿasah feri le-maʿlah*, the remnant shall again take root downward and bear fruit upward. *Gezaʿ* occurs three times and twice denotes a part that fails. That is not a strong distributional argument, since three occurrences cannot carry much, but it is not nothing.

**And Isaiah 11:10 uses *shoresh* alone.** *We-hayah ba-yom ha-huʾ shoresh Yishay ʾasher ʿomed le-nes ʿammim.* And in that day the root of Jesse, which stands as a signal to the peoples. Nine verses after the two-noun verse, the passage returns to the figure with one noun, and it is the root.

**What this book claims and does not claim.**

It does not claim that Isaiah 11:1 is a two-source oracle, that the corpus intends a contrast, or that Job is being alluded to.

It claims that the corpus contains a verse growing a shoot from a *gezaʿ* and a verse saying a *gezaʿ* dies in the dust, and that no passage in the corpus addresses the relation between them. Whether that is a real tension or an artifact of reading poetry too literally is a question a reader can decide, and the decision does not affect anything else in this book. Chapter 97 counts the pair among the ten and marks it as the most contestable of them.

## CHAPTER 89 · Isaiah 6:13 · The Holy Seed Is Its Stump

The commission into non-reception ends in a felled tree, and the placement is worth as much as the content.

*We-ʿod bah ʿasiriyah we-shavah we-haytah le-vaʿer, ka-ʾelah we-kha-ʾallon ʾasher be-shalleket maṣṣevet bam, zeraʿ qodesh maṣṣavtah.*

And yet a tenth shall be in it, and it shall return and be consumed; as a terebinth and as an oak whose *maṣṣevet* remains when they are felled, the holy seed is its *maṣṣevet*.

**The verse is textually and lexically difficult and the difficulty is named rather than managed.** *Maṣṣevet* is usually taken as the stump or the standing trunk of a felled tree, from *nṣb*, to stand. *Be-shalleket* is a hapax, usually taken as a felling or a casting down. And the final clause *zeraʿ qodesh maṣṣavtah* is absent from the Septuagint and from 1QIsa-a according to a common assessment, and is therefore held by many to be a later addition. This book does not adjudicate the text-critical question and its argument does not require the final clause.

**What the verse establishes without the disputed clause.** After the commission into non-reception, after *ʿad matay*, and after the answer about desolation, the chapter ends in an image of a felled tree with something remaining. That is the placement and it is not disputed.

**And the placement is seven chapters before Isaiah 11:1.** The commission that shuts eyes and stops ears ends in a stump. Seven chapters later a shoot comes from a stump. Whatever the compositional history, the received arrangement puts the deficit and the regrowth in the same book with the tree-image at both ends.

**Three observations.**

**The tenth returns and is consumed.** *We-shavah we-haytah le-vaʿer.* The verb *shwv* is the return-word, used throughout the corpus for repentance and for coming back from exile, and here what returns is consumed. Whatever comfort the verse offers is offered after a second destruction.

**The trees named are the terebinth and the oak**, *ʾelah* and *ʾallon*, both of them long-lived hardwoods that do in fact resprout from the base. The image is botanically apt and the corpus chose species that suit it.

**And the surviving element is called a seed, not a shoot.** *Zeraʿ qodesh*, holy seed, in the disputed clause. A seed and a stump are different objects: a seed is a beginning and a stump is a remainder. The clause identifies them, which is either a striking compression or an indication that the clause is a gloss.

**One structural point for Book IX.** The corpus's two great stump-passages, Isaiah 6:13 and Isaiah 11:1, use different nouns for the stump: *maṣṣevet* and *gezaʿ*. That is a lexical fact and this book makes nothing of it beyond recording it, since the two passages are seven chapters apart in a book whose composition is contested and the vocabulary of stumps is small enough that variation is unremarkable.

## CHAPTER 90 · The Ṣemaḥ Field · Branch as a Title

A second vegetable image runs through the prophetic corpus and becomes a title. This chapter surveys it.

**The noun is *ṣemaḥ*, from *ṣmḥ*, to sprout.** As a common noun it means growth or a sprout: Genesis 19:25 of the growth of the ground, Hosea 8:7 of standing grain, Ezekiel 16:7 of a plant of the field.

**As a title it occurs at five sites.**

**Jeremiah 23:5.** *Hinneh yamim baʾim neʾum YHWH wa-haqimoti le-Dawid ṣemaḥ ṣaddiq u-malakh melekh we-hiskil we-ʿasah mishpaṭ u-ṣedaqah ba-ʾareṣ.* Behold days are coming, says the LORD, when I will raise up for David a righteous Branch, and he shall reign as king and deal wisely and execute justice and righteousness in the land. And 23:6 gives the name: *we-zeh shemo ʾasher yiqreʾo YHWH ṣidqenu*, and this is his name by which he shall be called, the LORD our righteousness.

**Jeremiah 33:15.** *ʾAṣmiaḥ le-Dawid ṣemaḥ ṣedaqah we-ʿasah mishpaṭ u-ṣedaqah ba-ʾareṣ.* I will cause a Branch of righteousness to sprout for David. The verb and the noun are cognate: I will cause to sprout a sprout.

**Zechariah 3:8.** *Ki hinneni meviʾ ʾet ʿavdi Ṣemaḥ.* Behold I am bringing my servant Branch.

**Zechariah 6:12.** *Hinneh ʾish Ṣemaḥ shemo u-mi-taḥtaw yiṣmaḥ u-vanah ʾet heykhal YHWH.* Behold a man whose name is Branch, and he shall sprout from his place and build the temple of the LORD.

**Isaiah 4:2** is usually included and is different in character. *Ba-yom ha-huʾ yihyeh ṣemaḥ YHWH li-ṣvi u-le-khavod u-feri ha-ʾareṣ le-gaʾon u-le-tifʾeret li-fleyṭat Yisraʾel.* In that day the Branch of the LORD shall be for beauty and glory, and the fruit of the land for pride and honour, for the survivors of Israel. The parallelism with *peri ha-ʾareṣ*, fruit of the land, suggests a literal agricultural sense here, and many read it so.

**The conferral grammar holds at every site.**

Jeremiah 23:5: *wa-haqimoti*, I will raise up. First person divine.
Jeremiah 33:15: *ʾaṣmiaḥ*, I will cause to sprout. First person divine.
Zechariah 3:8: *hinneni meviʾ*, behold I am bringing. First person divine.
Zechariah 6:12: *u-mi-taḥtaw yiṣmaḥ*, he shall sprout from his place, which is the one site with the figure as grammatical subject, and the verb is intransitive growth rather than an act.

**Four of five have God as the subject of the raising, and the fifth has a plant growing.**

**Two further observations.**

**The name at Jeremiah 23:6 is a sentence and it is about God.** *YHWH ṣidqenu*, the LORD our righteousness. Compare Jeremiah 33:16, where the identical name is applied to Jerusalem rather than to a person: *we-zeh ʾasher yiqraʾ lah YHWH ṣidqenu*. The corpus gives the same theophoric name to the Branch and to the city, which tells against reading it as a claim about the bearer's nature and for reading it as a confession the bearer's existence occasions.

**And the field overlaps with Isaiah 11's without sharing its vocabulary.** Isaiah 11 uses *ḥoṭer*, *neṣer*, *gezaʿ*, and *shoresh*. The Branch material uses *ṣemaḥ*. Both are vegetable images for a Davidic figure and they share no noun. That is evidence that the image is a live metaphor in the corpus rather than a fixed term, which matters for how much weight any single occurrence can carry.

## CHAPTER 91 · Jeremiah 2:27 and Habakkuk 2:19 · The Fenced Location

The corpus is emphatic about a tree-image it forbids, and the prohibition sharpens what the permitted images are doing.

**Jeremiah 2:27.** *ʾOmerim la-ʿeṣ ʾavi ʾattah we-la-ʾeven ʾat yelidtani, ki fanu ʾelay ʿoref we-loʾ fanim; u-ve-ʿet raʿatam yoʾmeru qumah we-hoshiʿenu.*

Saying to the wood, you are my father, and to the stone, you gave me birth; for they have turned their back to me and not their face; but in the time of their trouble they will say, arise and save us.

**Habakkuk 2:19.** *Hoy ʾomer la-ʿeṣ haqiṣah, ʿuri le-ʾeven dumam, huʾ yoreh; hinneh huʾ tafus zahav wa-khesef we-khol ruaḥ ʾeyn be-qirbo.*

Woe to him who says to the wood, awake; to the silent stone, arise, it shall teach. Behold, it is overlaid with gold and silver and there is no breath at all within it.

**And the answer, one verse later.** Habakkuk 2:20: *wa-YHWH be-heykhal qodsho, has mi-panaw kol ha-ʾareṣ.* But the LORD is in his holy temple; let all the earth keep silence before him.

**Read the two verses together and the structure is exact.** A thing told to get up, which has no breath in it, against one already present who requires silence rather than summoning. Habakkuk sets the two side by side and the contrast is the whole point of the placement.

**Three observations.**

**The verbs addressed to the wood are all rousing-verbs.** *Qumah*, arise. *Haqiṣah*, awake. *ʿUri*, rouse yourself. The corpus's parody of idolatry is a parody of summoning: the worshipper's characteristic act toward the manufactured thing is to try to wake it.

**And the answer to the present God is silence.** *Has mi-panaw kol ha-ʾareṣ.* The interjection *has* is a hushing sound. Where the false object requires rousing, the real one requires quiet.

**Two objects are denoted by *ʿeṣ* and the shift must be marked rather than traded on.** At Job 14 and Isaiah 11 it is a felled tree, a living root system with a dead crown. At Jeremiah 2 and Habakkuk 2 it is carved timber, a manufactured article with no root at all. Those are different objects sharing a noun, and an argument that slid between them would be equivocating.

**What the fence establishes.** The corpus is not against tree-imagery; it uses it constantly and positively. What it fences is a location: the address of a rousing-summons to a made thing. The felled tree of Job 14 is not summoned; it detects water. The shoot of Isaiah 11:1 is not summoned; it comes out. Neither passage has anyone calling to a piece of wood.

That distinction is checkable and it is the corpus's own. It is also the reason this book's account of the escalation is not an argument against the figure. A figure whose coming is stated in the corpus's own grammar of conferral is categorically distinct from a thing a worshipper tries to wake. The fence at Habakkuk 2:19 is a fence against the second, and nothing in Book VIII places the messianic material on the wrong side of it.

## CHAPTER 92 · Ezekiel 17 and 31 · The Cedar, the Sprig, and the Felling

Two extended tree-allegories in Ezekiel supply the corpus's fullest development of the image and both are about a felling.

**Ezekiel 17.** The riddle of the eagles. A great eagle comes to Lebanon, takes the top of the cedar, crops off the topmost of its young twigs, and carries it to a land of merchants. Then it takes seed of the land and plants it in fertile soil beside abundant waters, and it becomes a spreading vine of low stature. A second eagle comes and the vine bends its roots toward it.

The interpretation is given at 17:12-21 and it is political: Nebuchadnezzar, Jehoiachin taken to Babylon, Zedekiah installed and bound by oath, and the turning to Egypt. The oath and its breach are the burden: 17:19, *ḥay ʾani ʾim loʾ ʾalati ʾasher bazah u-veriti ʾasher hefir u-netattiw be-roʾsho*, as I live, my oath which he despised and my covenant which he broke, I will bring upon his head.

**And then 17:22-24, which reverses the images.** *Wa-laqaḥti ʾani mi-ṣammeret ha-ʾerez ha-ramah we-natatti, me-roʾsh yoneqotaw rakh ʾeqṭof we-shatalti ʾani ʿal har gavoah we-talul.* I myself will take from the lofty top of the cedar and set it; from the topmost of its young twigs I will crop a tender one and I myself will plant it on a high and lofty mountain.

**The first eagle took a twig. God takes a twig.** The same act, narrated twice, once by a foreign king and once by God, with the pronoun *ʾani* emphatic in both clauses of the divine version: I myself will take, I myself will plant.

**And 17:24 states the principle.** *We-yadʿu kol ʿaṣey ha-sadeh ki ʾani YHWH hishpalti ʿeṣ gavoah higbahti ʿeṣ shafal, hovashti ʿeṣ laḥ we-hifraḥti ʿeṣ yavesh.* And all the trees of the field shall know that I the LORD have brought down the high tree and exalted the low tree, dried up the green tree and made the dry tree flourish.

Four verbs, all causative, all first person. The high brought down, the low raised, the green dried, the dry made to flourish. The corpus states its principle about trees in the vocabulary of reversal and puts every verb in the divine first person.

**Ezekiel 31.** Assyria as a cedar in Lebanon, fair of branches, its top among the clouds, the waters making it great, all the birds of heaven nesting in its boughs, all the beasts bringing forth under its shadow, and no tree in the garden of God like it.

And then 31:10-12: because it was high and lifted up and its heart was lifted up in its height, *wa-ram levavo be-govho*, God gives it into the hand of the mighty one of the nations, and strangers cut it down and leave it.

**The mechanism is Deuteronomy 8:14's again.** *Ram levavo*, his heart was lifted up. The identical idiom as the law of the king's purpose clause at Deuteronomy 17:20 and Deuteronomy 8:14's warning and 2 Chronicles 26:16's execution on Uzziah. Here it fells a cedar that stands for an empire.

**Two structural results for Book IX.**

**Every felling in the corpus's tree-allegories is attributed to God, and every planting too.** Ezekiel 17:24's four causatives state it as a principle.

**And the corpus's own reason for a felling, where it gives one, is the lifted heart.** That is the mechanism Book IV located in the receiver, applied here to nations and to trees, in one idiom across four books.

## CHAPTER 93 · What the Tree Material Establishes

Book IX has read six passages and this chapter states what they support.

**The corpus's tree-vocabulary is small, specific, and used with some care.** *ʿEṣ* for tree and for timber, with the two senses distinguishable by context and fenced at Habakkuk 2:19. *Gezaʿ* for stump, three occurrences. *Shoresh* for root, common. *Ḥoṭer* and *neṣer* for shoot and branch at Isaiah 11:1. *Maṣṣevet* at Isaiah 6:13. *Ṣemaḥ* for the Branch title at five sites. *ʾErez* for cedar and *ʾelah* and *ʾallon* for the resprouting hardwoods.

**Every regrowth is stated as coming from a remainder.** Isaiah 11:1 from a stump and roots. Isaiah 6:13 from a *maṣṣevet* after a felling. Job 14:7 from a cut tree. Ezekiel 17:22 from a twig cropped off a cedar top. None of the corpus's regrowth images is a new planting from nothing.

**Every planting and every felling in the allegories has God as subject.** Ezekiel 17:22-24 makes it a principle in four causatives. Jeremiah 23:5's *wa-haqimoti* and 33:15's *ʾaṣmiaḥ* have the same grammar in the Branch field. The conferral grammar of Book VI holds in the vegetable register without exception.

**And the corpus states one ruling about a stump that its most famous stump-verse does not observe.** Job 14:8 has the *gezaʿ* dying in the dust. Isaiah 11:1 grows a shoot from a *gezaʿ*. The corpus contains both and reconciles neither, and Chapter 88 stated the objection to making anything of it.

Two closing observations, both of which look forward.

**The tree material supplies the corpus's own picture of a resource present and unregistered.** Job 14:9's water is already in the ground; the tree detects it. That is Book III's terminus and Book IV's receiving faculty, in a vegetable image, in a wisdom book. This book offers the picture as a picture and claims nothing about intent.

**And the fenced location at Habakkuk 2:19 tells against reading this book as an argument about the figure.** The corpus prohibits addressing a summons to a piece of manufactured wood. It does not prohibit expecting a shoot from a felled stump, and it states the shoot in the same grammar it uses for every other conferral. Book IX ends where Book VIII ended: the figure is real in the corpus's own terms, and the terms are terms of receipt.
