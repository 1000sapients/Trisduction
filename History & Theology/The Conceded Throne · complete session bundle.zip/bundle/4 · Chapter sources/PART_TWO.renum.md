# PART TWO · TWENTY-ONE EXCURSUS

Short studies that belong to the argument but would have interrupted it. Each is self-contained and each states its own weight.

## EXCURSUS I · The Versification Problem at Isaiah 9

Isaiah 9:5 in the Hebrew is Isaiah 9:6 in most English versions, and the offset runs through the chapter because the Hebrew begins the chapter one verse earlier than the English. The Hebrew 8:23 is the English 9:1.

The difference matters here because Chapter 78 turns on the verse and a reader checking it in an English Bible will find the throne-name at 9:6 and the closing agent-clause at 9:7.

The general phenomenon is wider. The Psalms carry superscriptions as verse 1 in the Hebrew where English versions treat them as unnumbered headings, so Psalm 51:3 in the Hebrew is 51:1 in English and the offset is one or two depending on the length of the superscription. Joel is divided into four chapters in the Hebrew and three in most English versions, so the Hebrew 3:1's pouring out of the spirit is the English 2:28.

This book uses the Hebrew numbering throughout. Where a passage is likely to be checked, the English number is given at first occurrence in that book.

## EXCURSUS II · Why the Four Roots Are Four and Not One

A reader may reasonably ask whether *šbt*, *nwḥ*, *šqṭ*, and *rgʿ* are genuinely distinct or whether the distinctions are an artifact of a modern reader's desire for precision.

Three tests support the distinction and one complicates it.

**The subjects differ systematically.** *Šbt*'s subject is a worker or an activity: God at Genesis 2:2, the manna at Joshua 5:12, the land at Leviticus 26:34. *Nwḥ*'s subject is a mover: the ark at Genesis 8:4, the spirit at Isaiah 11:2, the people as the object of the causative. *Šqṭ*'s subject is characteristically the land: Judges 3:11, 3:30, 5:31, 8:28, Joshua 11:23. *Rgʿ*'s subject is a person or a soul: Jeremiah 6:16, Deuteronomy 28:65.

**The corpus uses two of them side by side where a synonym would be redundant.** Isaiah 14:7: *naḥah shaqṭah kol ha-ʾareṣ*, two roots in one clause. 1 Chronicles 22:9: *menuḥah*, *hanihoti*, and *sheqeṭ* in one verse.

**They take different objects in the causative.** *Heniaḥ* takes a person or people. *Hishbit* takes an activity or a class of things: wild beasts at Leviticus 26:6, the shepherds at Ezekiel 34:10.

**The complication.** The distinctions are tendencies rather than absolutes. *Nwḥ* is used of the land at Isaiah 14:7 and *šbt* is used of persons in the sabbath legislation. A reader who wants to press the distinctions further than tendencies will be pressing them past what the data supports, and this book has tried not to.

## EXCURSUS III · The Judges Cycle, Counted

The cycle in Judges has five elements and they recur with enough regularity to be counted.

Israel does evil in the sight of the LORD. The LORD gives them into the hand of an oppressor. They cry out. The LORD raises a deliverer. The land is quiet.

**The doing-evil formula** *wa-yaʿasu venei Yisraʾel ha-raʿ be-ʿeyney YHWH* occurs at 2:11, 3:7, 3:12, 4:1, 6:1, 10:6, and 13:1. Seven occurrences.

**The outcry formula** *wa-yizʿaqu venei Yisraʾel ʾel YHWH* occurs at 3:9, 3:15, 4:3, 6:6, and 10:10. Five occurrences.

**The raising formula** *wa-yaqem YHWH ... moshiaʿ* or *shofeṭ* occurs at 2:16, 2:18, 3:9, and 3:15.

**The quiet formula** *wa-tishqoṭ ha-ʾareṣ* occurs at 3:11, 3:30, 5:31, and 8:28. Four occurrences.

The four terminus-deliveries therefore stand inside a cycle whose other elements occur five to seven times each. The quiet formula is the rarest of the four elements, which means the corpus records more oppressions and more outcries than deliverances into quiet, and the ratio is a fact worth having.

**And the raising verb is *qwm* in the hiphil with God as subject**, which is Chapter 62's verb in Ezekiel 34:23 and Jeremiah 23:4.

## EXCURSUS IV · Gideon's Ephod

Judges 8:24-27 records that Gideon, having refused the crown, asked for the golden earrings of the spoil, received seventeen hundred shekels of gold, and made an ephod which he set up in his city.

*Wa-yizu khol Yisraʾel ʾaḥaraw sham wa-yehi le-Gidʿon u-le-veyto le-moqesh.* And all Israel went whoring after it there, and it became a snare to Gideon and to his house.

Three readings are available.

**The cynical reading.** The refusal was pious words and the ephod is the substance of the office acquired under another name. On this reading the narrative is an exposure.

**The tragic reading.** The refusal was genuine and the narrative shows how quickly the apparatus of a cult and a household accrues to a man who has declined the title. Seventy sons, many wives, a gold object, and a son named my-father-is-king.

**The compositional reading.** The refusal and the ephod come from different hands and the tension is a seam.

This book takes none of them. What is load-bearing at Chapter 42 is the sentence at 8:23, and the sentence stands in the received text whatever the narrative does with the man afterwards.

One observation the three readings share. **The corpus put both in the same chapter.** Whatever the composition, the assembly retained the refusal and the ephod, nine verses apart, without comment. That is Book XIII's habit operating in Judges.

## EXCURSUS V · The Ark, and What It Is Not

The ark is the corpus's most portable holy object and it is worth a note because it resists the conclusion a reader might draw from Book VI.

Books VI and X argued that what Israel holds is stated as received and that the flock's ownership never transfers. A reader might extend that to conclude that the corpus never states Israel as possessing anything.

The ark complicates that. It is made to specification at Exodus 25:10-22, carried by Israel, and 1 Samuel 4 has it taken into battle as though it guaranteed victory. It does not: Israel is defeated, thirty thousand foot soldiers fall, the ark is captured, and Eli falls backward and breaks his neck at the news.

**And the corpus's judgment on the episode is delivered by the enemy.** 1 Samuel 4:7-8, the Philistines: *baʾ ʾelohim ʾel ha-maḥaneh ... mi yaṣṣilenu mi-yad ha-ʾelohim ha-ʾaddirim ha-ʾelleh.* God has come into the camp; who will deliver us from the hand of these mighty gods?

**And then the ark defeats them without Israel.** 1 Samuel 5: Dagon falls on his face before it twice, the second time with head and hands cut off on the threshold; the people of Ashdod and Gath and Ekron are struck; and 1 Samuel 6 has the Philistines return it on a new cart drawn by two milk cows with a guilt offering of golden tumours and mice.

The episode is the corpus's clearest statement that the object is not a possession that can be deployed. Israel takes it out and loses; the Philistines take it home and are afflicted; it returns without anyone fetching it.

**The relevance to this book is one sentence.** The corpus has a category for a holy thing that Israel carries and does not control, and the ark is it. That is the same category the throne of 1 Chronicles 29:23 falls into and the flock of Ezekiel 34 falls into.

## EXCURSUS VI · Uzzah, and the Cost of Steadying

2 Samuel 6:6-7. The ark on a new cart, the oxen stumbling at the threshing floor of Nacon, Uzzah putting out his hand to steady it, and dying there.

*Wa-yiḥar ʾaf YHWH be-ʿUzzah wa-yakkehu sham ha-ʾelohim ʿal ha-shal.* The reading of *ha-shal* is uncertain and the parallel at 1 Chronicles 13:10 has *ʿal ʾasher shalaḥ yado*, because he put out his hand.

David's response is recorded and it is not pious. 6:8: *wa-yiḥar le-Dawid ʿal ʾasher paraṣ YHWH pereṣ be-ʿUzzah*, and David was angry because the LORD had broken out against Uzzah. And 6:9: *wa-yiraʾ Dawid ʾet YHWH ba-yom ha-huʾ wa-yoʾmer ʾeykh yavoʾ ʾelay ʾaron YHWH.* And David feared the LORD that day and said, how shall the ark of the LORD come to me?

The episode is included here for one reason. It is the corpus's sharpest instance of a category error being fatal: a man treats a holy object as a thing requiring his assistance, and the corpus records the outcome without explaining it, and records the king's anger about it.

Chapter 91's fence at Habakkuk 2:19 is the same distinction from the other side. The manufactured thing has to be told to get up. The real one requires silence and does not require steadying.

This excursus makes no argument. It records that the corpus has a story about the difference and that the story is unresolved in the text.

## EXCURSUS VII · The Name at Jeremiah 23:6 and 33:16

*We-zeh shemo ʾasher yiqreʾo YHWH ṣidqenu*, and this is his name by which he shall be called, the LORD our righteousness, at Jeremiah 23:6, of the Branch.

*We-zeh ʾasher yiqraʾ lah YHWH ṣidqenu*, and this is what she shall be called, the LORD our righteousness, at Jeremiah 33:16, of Jerusalem.

The same name, applied to a person in one chapter and to a city in another, in one book.

**That distribution tells against reading the name as a claim about the bearer's nature.** A theophoric name applied to a city is a confession about God made in connection with the city, not an assertion that the city is God. The corpus's own second application supplies the control.

**The construction is common in Israelite naming.** Personal names of the form divine-element plus predicate are ordinary: Elijah, my God is YHWH. Ezekiel, God strengthens. Isaiah, YHWH saves. Zedekiah, YHWH is my righteousness, which is the same elements as Jeremiah 23:6 with a first-person singular suffix, and Zedekiah is the last king of Judah whose reign the same book narrates.

**That last point is worth having.** Jeremiah gives the Branch a name that is Zedekiah's name pluralized, in a book that records Zedekiah's blinding at 39:7 and 52:11. Whether the wordplay is deliberate is unknowable and the elements are there.

## EXCURSUS VIII · Solomon's Request, Read Against Book IV

1 Kings 3:5-14. The dream at Gibeon, the offer, the request, and the grant.

*We-natatta le-ʿavdekha lev shomeaʿ li-shpoṭ ʾet ʿammekha le-havin beyn ṭov le-raʿ.* Give your servant a hearing heart to judge your people, to discern between good and evil.

**Three of Book IV's terms are in that clause.** *Lev*, heart, the organ of Deuteronomy 29:3. *Shomeaʿ*, hearing, the faculty of Psalm 95:7 and 1 Samuel 8:19. And *le-havin*, to discern, from *byn*, the verb Isaiah 6:9 negates: *shimʿu shamoaʿ we-ʾal tavinu*.

**And the request is for a giving.** *We-natatta*, and you shall give. The king asks for the organ Deuteronomy 29:3 says was not given.

**The divine response grants it and adds what was not asked.** 3:12: *hinneh natatti lekha lev ḥakham we-navon*, behold I have given you a wise and discerning heart. And 3:13: *we-gam ʾasher loʾ shaʾalta natatti lakh gam ʿosher gam kavod*, and also what you did not ask I have given you, both riches and honour.

**And 3:14 attaches a condition.** *We-ʾim telekh bi-drakhay li-shmor ḥuqqay u-miṣwotay ka-ʾasher halakh Dawid ʾavikha we-haʾarakhti ʾet yameykha.* And if you walk in my ways, keeping my statutes and my commandments as David your father walked, then I will lengthen your days.

The conditional applies to the length of days, not to the wisdom. The gift is unconditional and the tenure is not, which is the same structure as 2 Samuel 7:14-15 and Psalm 132:12.

**And 1 Kings 11:4's verdict uses the same organ.** *Loʾ hayah levavo shalem ʿim YHWH.* His heart was not whole with the LORD. The corpus gives the man the organ he asked for and reports at the end that the organ failed.

## EXCURSUS IX · What Happened to the Northern Kingdom's Expectation

The corpus is a Judahite document in its final form and the northern kingdom's own royal theology is largely absent from it. This excursus records what can be said and what cannot.

**What is recorded.** Nine dynasties in roughly two centuries, most of them founded by assassination: Jeroboam, Baasha, Zimri, Omri, Jehu, and the rest. 1 Kings 16 alone records three changes of dynasty. The corpus's judgment on all of them is a formula: *wa-yaʿas ha-raʿ be-ʿeyney YHWH wa-yelekh be-derekh Yarovʿam*, he did evil in the sight of the LORD and walked in the way of Jeroboam.

**Hosea 8:4's statement.** *Hem himlikhu we-loʾ mimmenni, hesiru we-loʾ yadaʿti.* They made kings and not from me; they removed and I did not know. That is the corpus's clearest statement about northern kingship and it denies divine appointment for the whole institution there.

**And Jeroboam did receive a dynastic promise.** 1 Kings 11:38, from Ahijah: *we-hayah ʾim tishmaʿ ʾet kol ʾasher ʾaṣawwekha ... u-vaniti lekha vayit neʾeman ka-ʾasher baniti le-Dawid.* If you listen to all I command you, I will build you a sure house as I built for David.

**A conditional dynastic promise to the northern founder, in the corpus, and it fails.** 1 Kings 14:7-11 records Ahijah's second oracle against him and 15:29 records the extermination of his house.

**What cannot be said.** Whether the northern kingdom carried its own royal ideology, whether it had messianic expectations, and what they looked like. The corpus does not preserve northern royal psalms as such, and any reconstruction would require material this book does not use.

The excursus exists to mark the gap. Half the population of the united monarchy is represented in this corpus by a formula of condemnation and a failed conditional promise, and a reader should know that the royal theology examined in this book is a Judahite one.

## EXCURSUS X · Sabbath, Sabbatical Year, and Jubilee

The seventh position is legislated at three scales and the three are worth separating.

**The seventh day.** Exodus 20:8-11, Deuteronomy 5:12-15, Exodus 31:12-17, Leviticus 23:3. Cessation from work, extended to household, slaves, cattle, and the resident alien.

**The seventh year.** Exodus 23:10-11, Leviticus 25:1-7. *Shabbat shabbaton yihyeh la-ʾareṣ shabbat la-YHWH*, a sabbath of solemn rest for the land, a sabbath to the LORD. The field is not sown, the vineyard not pruned, and what grows of itself is for the owner, the servants, the hired hand, the resident alien, the cattle, and the beasts.

**The fiftieth year.** Leviticus 25:8-55. Seven sabbaths of years, forty-nine, and then the jubilee proclaimed on the day of atonement with the trumpet. *U-qeraʾtem deror ba-ʾareṣ le-khol yosheveha.* Liberty proclaimed throughout the land to all its inhabitants. Each returns to his possession and to his family. Land reverts. Israelite debt-slaves go free.

**And the ground given for the land legislation is ownership.** Leviticus 25:23: *we-ha-ʾareṣ loʾ timmakher li-ṣmitut ki li ha-ʾareṣ ki gerim we-toshavim ʾattem ʿimmadi.* The land shall not be sold in perpetuity, for the land is mine; you are strangers and sojourners with me.

**That verse belongs with Book VI.** The corpus's economic legislation about the land is grounded in a statement that the land is God's and Israel is resident on it. The same relation the throne texts state, in the register of property law.

**And the exile is priced against this legislation**, at 2 Chronicles 36:21 and Leviticus 26:34-35, which Chapter 30 worked. The land takes the sabbaths it was owed under Leviticus 25 while the people are away.

## EXCURSUS XI · The Verb Šwv and the Two Returns

*Šwv* is one of the corpus's most frequent verbs and it carries two senses that both matter here: to return physically, and to turn back or repent.

**The physical sense.** Deuteronomy 30:3's *we-shav YHWH ʾeloheykha ʾet shevutekha*, and the LORD will return your captivity. Jeremiah 29:14, Ezekiel 39:25, and the whole restoration vocabulary.

**The repentance sense.** Hosea 14:2: *shuvah Yisraʾel ʿad YHWH ʾeloheykha*, return, Israel, to the LORD your God. Joel 2:12: *shuvu ʿaday be-khol levavkhem*, return to me with all your heart. Isaiah 6:10's *wa-shav we-rafaʾ lo*, lest they turn and be healed. Jeremiah 3, where the root occurs in various forms more than a dozen times in one chapter.

**And Deuteronomy 30 uses both in one passage.** 30:2: *we-shavta ʿad YHWH ʾeloheykha*, and you shall return to the LORD your God, which is the repentance sense with the people as subject. 30:3: *we-shav YHWH ʾeloheykha ʾet shevutekha we-riḥamekha we-shav we-qibbeṣkha*, the physical sense with God as subject, and the verb repeated.

Four occurrences of the root in two verses, alternating subjects.

**The relevance.** The corpus's word for the act it asks of the people and its word for the act it attributes to God in restoring them are the same word. That is a lexical fact and this book builds nothing on it, since a common verb doing double duty is unremarkable in any language. It is recorded because a reader tracking the argument's grammar will meet the alternation and should know it is there.

## EXCURSUS XII · The Deuteronomy 18 Prophet

Deuteronomy 18:15-22 is sometimes brought into messianic discussions and this excursus states why this book does not use it.

*Naviʾ mi-qirbekha me-ʾaḥeykha kamoni yaqim lekha YHWH ʾeloheykha, ʾelaw tishmaʿun.* A prophet from your midst, from your brothers, like me, the LORD your God will raise up for you; to him you shall listen.

**The conferral grammar holds**, as everywhere: *yaqim lekha YHWH*, the LORD will raise up for you, hiphil with God as subject.

**But the passage's own frame is institutional rather than singular.** 18:9-14 forbids divination, soothsaying, augury, sorcery, and consulting the dead. 18:15 then supplies the alternative: a prophet. And 18:20-22 gives the test for distinguishing a true prophet from a false one, which presupposes plural prophets and an ongoing problem of identification.

A passage that supplies a test for telling prophets apart is legislating for a category, not announcing an individual.

**The singular is generic.** The construction is the same as Deuteronomy 17:15's *som tasim ʿaleykha melekh*, which no one reads as announcing a single king.

**The passage has been read messianically for a long time and this book does not say that reading is wrong.** It says the passage's internal evidence supports an institutional reading, that the institutional reading is the majority scholarly one, and that nothing in this book's argument requires either.

**One feature is worth taking.** *ʾElaw tishmaʿun*, to him you shall listen, is the hearing imperative of Book IV, attached to a prophetic office. And 18:19: *we-hayah ha-ʾish ʾasher loʾ yishmaʿ ʾel devaray ʾasher yedabber bi-shmi ʾanokhi ʾedrosh me-ʿimmo.* And whoever does not listen to my words which he speaks in my name, I will require it of him.

The corpus attaches a sanction to the failure of hearing at the one place it institutes a mediating office, which is the strongest thing this book can say about a passage it otherwise sets aside.

## EXCURSUS XIII · What the Septuagint Does Differently, at Three Points

This book uses the Masoretic Text and does not practise textual criticism. Three divergences are worth noting because they bear on passages the argument uses.

**Isaiah 7:14.** The Hebrew *ha-ʿalmah* is a young woman of marriageable age; the Septuagint renders it *parthenos*, which carries a narrower sense. The divergence is old and its consequences are enormous for the history of interpretation. Nothing in this book depends on the verse.

**Zechariah 9:9.** The Hebrew *we-noshaʿ* is a nifal participle and passive: saved. The Septuagint renders with an active sense and many English versions follow. Chapter 115 uses the Hebrew and states the divergence there.

**Isaiah 6:13.** The final clause *zeraʿ qodesh maṣṣavtah*, the holy seed is its stump, is commonly held to be absent from the Septuagint and from the great Isaiah scroll. Chapter 89 states that the argument does not require the clause.

**And a fourth, of a different kind.** The Septuagint's Jeremiah is roughly one-eighth shorter than the Masoretic and its chapters are ordered differently, with the oracles against the nations in a different position. This is the largest divergence between the two traditions in any prophetic book and it is a live area of study. Nothing in this book turns on the order of Jeremiah's chapters.

The excursus exists to mark that the textual situation is not simple and that a reader checking this book's claims against a translation may be checking against a different base text.

## EXCURSUS XIV · The Two Names for the Corpus, and Why It Matters Here

The body of writing this book examines is called the Hebrew Bible, the Tanakh, the Old Testament, and the Miqra, and the choice among those names is not neutral.

**Old Testament** presupposes a New one and therefore presupposes a canon this book excludes. Using it would contradict the scope law of Chapter 1 in the act of stating it.

**Tanakh** is an acronym for Torah, Neviʾim, Ketuvim, and it names the corpus by its own internal division. It is accurate and it is a term of the Jewish tradition, which carries an implication this book cannot honour, since this book declines to read through that tradition's interpretive corpus.

**Miqra**, that which is read, is likewise internal.

**Hebrew Bible** is the term most nearly neutral among readers who do not share a canon, and it is the term this book uses. It is not perfectly neutral: Bible is a Christian-inflected word in English usage, and the corpus contains Aramaic. Both objections are real and neither has a better alternative attached.

The excursus is included because a book whose whole method is a scope law should say how it names the thing it has scoped, and should not pretend the naming was costless.

## EXCURSUS XV · The Four Royal Titles Compared

The corpus has four principal words for a ruler and they are not interchangeable.

***Melekh*, king.** The common word, from a root meaning to rule or reign. Used of Israelite kings, foreign kings, and God. It is the word the people demand at 1 Samuel 8:5, the word Deuteronomy 17:14 regulates, and the word Zephaniah 3:15 applies to YHWH.

***Nagid*, prince, designate, or leader.** From *ngd*, to be in front or to be told. Its distribution is striking. It is the word in the divine speech at 1 Samuel 10:1 where Samuel anoints Saul, at 1 Samuel 13:14 where God seeks a man after his own heart, at 2 Samuel 5:2 where the elders quote God, and at 2 Samuel 7:8 where God recalls taking David from the pasture.

**In every one of those four the speaker is God or is quoting God, and the higher word *melekh* stands nearby in the human speech.** 2 Samuel 5:2-3 is the sharpest: the elders quote God saying *nagid*, and in the next verse they anoint him *le-melekh*. The corpus puts the lower title in the divine mouth and the higher in the human one.

***Nasiʾ*, prince or lifted one.** From *nśʾ*, to lift or carry, and therefore passive in force: one who has been lifted up. Common in the Priestly material for tribal chiefs, and Ezekiel's preferred term for the coming figure, at 34:24, 37:25, and throughout the temple vision.

***Moshel*, ruler.** An active participle from *mšl*, to rule. This is the word Gideon declines at Judges 8:23, the word Micah 5:1 uses of the one from Bethlehem, and the word behind Zechariah 9:10's *u-mosholo*, his dominion.

**Set the four side by side and the pattern is visible.** *Melekh* is the demanded word. *Nagid* is the divine word and is lower. *Nasiʾ* is passive in its morphology and is the exilic prophet's choice. And *moshel* is the one active participle, and it is the word the corpus's first refusal declines.

That distribution is offered as an observation and not as an argument, because title-usage in the corpus is not tidy and counterexamples exist. What it adds to Book VI is one more piece of evidence, at the level of vocabulary, running the same direction as the verbs.

## EXCURSUS XVI · What ʿOlam Means Here

*ʿOlam* is usually rendered forever and the rendering is often right and sometimes not, and the difference matters at three points in this book.

**The root's sense is duration whose end is not in view.** It covers the remote past as readily as the remote future: *yemey ʿolam*, the days of old, at Deuteronomy 32:7, Isaiah 63:9, Amos 9:11, and Micah 7:14; *netivot ʿolam*, the ancient paths, at Jeremiah 6:16; *gevul ʿolam*, the ancient boundary, at Proverbs 22:28.

**It is used of bounded durations.** Exodus 21:6, the slave who declines manumission serves his master *le-ʿolam*, which is his lifetime. 1 Samuel 1:22, Hannah says Samuel will remain *ʿad ʿolam*, and 1:28 glosses it *kol ha-yamim ʾasher hayah*, all the days he lives.

**And it is used of the genuinely unbounded**, of God at Psalm 90:2, *me-ʿolam ʿad ʿolam ʾattah ʾel*, from everlasting to everlasting you are God.

**Where it matters here, three sites.**

**2 Samuel 7:13 and 7:16's *ʿad ʿolam*.** On the strongest reading the dynastic grant is unbounded. On the bounded reading it is a grant whose end is not in view, which is a weaker claim. Psalm 89:39-46's complaint that the covenant was renounced is the corpus's own evidence that at least one of its writers held the grant to have been terminable in fact whatever the formula said.

**Psalm 110:4's *le-ʿolam*.** A priesthood forever, sworn.

**Psalm 132:14's *ʿadey ʿad*.** A different and stronger formula, doubled, of the divine dwelling in Zion.

**This book does not adjudicate the sense at any of the three** and notes that the range exists. A reader who takes *ʿolam* as unbounded everywhere will find the corpus asserting several unbounded grants that its own laments say failed, which is a real problem and is Book XIII's habit operating on the largest possible object.

## EXCURSUS XVII · The Horn

*Qeren*, horn, is the corpus's image for the strength of a royal or personal position and it runs through the material this book has read.

**As the anointing vessel.** *Qeren ha-shemen* at 1 Samuel 16:13 for David and 1 Kings 1:39 for Solomon, against *pakh ha-shemen* for Saul and Jehu.

**As the image of exaltation.** 1 Samuel 2:1, Hannah's song: *ramah qarni ba-YHWH*, my horn is exalted in the LORD. And 2:10, the song's close: *we-yitten ʿoz le-malko we-yarem qeren meshiḥo*, he will give strength to his king and exalt the horn of his anointed.

**That verse deserves notice.** It is the first occurrence of *meshiaḥ* in the books of Samuel, it is in a song sung before any king exists, and both of its verbs are divine: he will give, he will exalt.

**Psalm 132:17.** *Sham ʾaṣmiaḥ qeren le-Dawid.* There I will cause a horn to sprout for David. The Branch verb and the horn noun in one clause, with God as subject.

**Psalm 89:18 and 89:25.** *Ki tifʾeret ʿuzzamo ʾattah u-vi-rṣonekha tarum qarnenu*, and *u-vi-shmi tarum qarno*. In my name his horn shall be exalted.

**Psalm 92:11.** *Wa-tarem ki-rʾem qarni*, you have exalted my horn like that of a wild ox.

**Ezekiel 29:21.** *Ba-yom ha-huʾ ʾaṣmiaḥ qeren le-veyt Yisraʾel.* The same construction as Psalm 132:17, of the house of Israel rather than of David.

**Daniel 7 and 8** use the image for kingdoms, and Daniel 7:8's little horn is the passage's antagonist.

**The pattern.** In every instance where a horn is exalted for an Israelite figure, the exalting verb is divine. *Yarem*, *tarum*, *ʾaṣmiaḥ*, *wa-tarem*: the horn is raised, and the raiser is named.

That is Chapter 62's grammar in a fifth register, and it is offered at that weight: as one more small piece running the same direction, not as an independent argument.

## EXCURSUS XVIII · Seven, and the Terminus

The number seven attaches to the terminus material with enough regularity to be worth recording, and with enough looseness that nothing is built on it.

**The seventh day.** Genesis 2:2-3, blessed and sanctified, the only member of a seven-part series left unclosed by the evening-and-morning formula.

**The seventh year.** Leviticus 25:1-7, a sabbath for the land.

**The seven-times-seven and the fiftieth.** Leviticus 25:8-10, the jubilee, liberty proclaimed.

**The seventy years.** Jeremiah 25:11 and 29:10, and 2 Chronicles 36:21's accounting of them as unkept sabbaths. Seventy is ten sevens and the Chronicler makes the sabbatical connection explicit.

**The seven petitions of Solomon's prayer.** 1 Kings 8:32, 34, 36, 39, 43, 45, 49, each closing *we-ʾattah tishmaʿ ha-shamayim*.

**The sevenfold spirit.** Isaiah 11:2, either six qualities in three pairs with *ruaḥ YHWH* as a summary, or seven with it as the first.

**The seven-branched lampstand** of Exodus 25:31-40 and of Zechariah 4:2, with its seven lamps and, in Zechariah, seven pipes.

**And Zechariah 3:9's seven eyes on one stone**, and 4:10's *shivʿah ʾelleh ʿeyney YHWH hemmah meshoṭeṭim be-khol ha-ʾareṣ*, these seven are the eyes of the LORD running to and fro through the whole earth.

**What can be said.** The number recurs at the terminus positions, in the sabbath legislation at three scales, in the exile's accounting, in the temple prayer's structure, in the equipping of the figure, and in the lampstand.

**What cannot.** Any inference from the recurrence. Seven is the corpus's most common structuring number and it recurs everywhere, including in material with no relation to this book's subject. A pattern that appears both where a thesis predicts it and where the thesis says nothing is not evidence for the thesis.

The excursus exists because a reader tracking the terminus vocabulary will notice the sevens and should know both that they are there and that this book declines to use them.

## EXCURSUS XIX · The Passages This Book Did Not Use

An honest accounting of what was left out, because a study whose selection is invisible is a study whose selection cannot be checked.

**Set aside as too contested to carry weight.** Genesis 3:15, Genesis 49:10, Daniel 9:24-27. Chapters 127, 128, and 117 state the reasons in each case, and in each the reason is lexical or text-critical rather than theological.

**Set aside as belonging to a different question.** Deuteronomy 18:15-22, treated at Excursus XII and read as institutional rather than singular. Isaiah 7:14, named at Chapter 111 and used for nothing. Zechariah 13:7, quoted at Chapter 97 and explicitly not attempted.

**Set aside for want of competence.** Isaiah 52:13-53:12's substitution language, which Chapter 143 declines and says why at length. This is the largest single omission in the book and it is the one most likely to make a reader feel the study has evaded its subject. The reason is stated rather than concealed: a book that has declined to enter the servant identification cannot then adjudicate what the fourth song claims about the servant's suffering, and doing so in one chapter would have been pretending to a competence not demonstrated anywhere else.

**Set aside by the scope law.** Every reading of every passage above produced by any tradition after the closing of the Hebrew canon. Appendix J names them.

**Genuinely not searched.** The wisdom books were surveyed at Chapters 133 and 134 and the survey was for the absence of royal-figure material rather than for the presence of terminus vocabulary. Proverbs, in particular, carries a substantial body of material about the heart, the ear, and knowledge that a fuller treatment would work. Chapter 134 quotes three verses and there are more.

**And the Song of Songs was not read at all** beyond confirming that it contains no royal-figure material. That is a whole book of the canon dismissed in a clause, and the clause is honest about it.

**Two further gaps that a reader should know about.**

**The northern kingdom's royal theology**, addressed at Excursus IX, which reports that the corpus preserves almost nothing of it and that this book therefore examines a Judahite royal theology and says so.

**And the census's own unsearched field**, at Chapter 19: the complementary count of where a royal figure appears without the terminus vocabulary, which would say whether the two vocabularies avoid each other or merely fail to coincide. That is the single most useful further study this book's method suggests and it was not run.

## EXCURSUS XX · Ṣedeq, and the Element in Two Jerusalemite Names

The root *ṣdq* runs through the royal material and its distribution is worth a note because it connects three passages this book treats separately.

**The two Jerusalemite kings.** *Malki-Ṣedeq* at Genesis 14:18 and *ʾAdoni-Ṣedeq* at Joshua 10:1. Chapter 56 used the pair to establish that the *ṣedeq* element is a local dynastic form and not an isolated anomaly, which is what makes Psalm 110:4's patterning of a royal priesthood on Melchizedek's order legible as a claim about a real institution rather than a legendary one.

**The Branch's name.** Jeremiah 23:5's *ṣemaḥ ṣaddiq*, a righteous Branch, and 33:15's *ṣemaḥ ṣedaqah*, a Branch of righteousness. And the name at 23:6, *YHWH ṣidqenu*, the LORD our righteousness, which Excursus VII noted is applied to Jerusalem at 33:16 as well.

**The last king's name.** *Ṣidqiyyahu*, Zedekiah, my righteousness is YHWH, the same elements with a first-person singular suffix. The corpus gives the Branch a name that is the last Davidic king's name in the plural, in a book that records that king's blinding at 39:7.

**The royal function.** Psalm 72:1-2's *mishpaṭeykha le-melekh ten we-ṣidqatkha le-ven melekh*, give the king your judgments and your righteousness to the king's son, followed by *yadin ʿammekha ve-ṣedeq*. Isaiah 9:6's establishing of the throne *be-mishpaṭ u-vi-ṣdaqah*. Isaiah 11:4-5's judging *be-ṣedeq* and *ṣedeq ʾezor motnaw*, righteousness the belt of his loins. Jeremiah 23:5's Branch executing *mishpaṭ u-ṣedaqah ba-ʾareṣ*.

**And the divine possession of it.** Psalm 72:1 asks God to give *ṣidqatkha*, your righteousness, to the king. The quality the royal material most consistently attributes to the figure is, in the psalm that most fully describes it, requested as a transfer from its owner.

**Two observations.**

**The element is Jerusalemite before it is Israelite**, on the corpus's own witness at Joshua 10:1, and the corpus does not conceal it. That belongs with Chapter 124's pattern of acknowledged receipt.

**And where the corpus states the figure's righteousness at its fullest, at Psalm 72:1, it states it as given.** Chapter 103 worked the verse. It is one more site for Appendix D's list and it was not included there because the object of the giving is a quality rather than an office, which is a distinction worth keeping.

## EXCURSUS XXI · The Criterion Applied to This Book

Audit symmetry requires that a study submit to the instrument it runs, and this excursus does that.

**The question.** Apply the removability criterion to this book's own central claim. Strip the figure-framing and ask what proposition remains.

**The claim.** The Hebrew Bible names a terminus in a specific vocabulary, states it as given and unentered, locates the failure in the receiver, concedes a monarchy under protest, escalates a royal figure eight times, and states everything that figure holds in a conferral grammar.

**Strip the figure.** What remains is: the Hebrew Bible names a terminus in a specific vocabulary, states it as given and unentered, and locates the failure in the receiver.

**That residue is substantive**, and the corpus states it in nine anchors at Appendix N, six of which carry no figure anywhere in the pericope. So the book's own central content survives its own test, which is what a reader should expect since the whole argument was constructed to identify contents that do.

**Now the harder application.** Apply the test to the *second* half of the claim, the conferral grammar. Strip the figure and nothing at all remains, because the claim is about how a figure holds what he holds and there is no figure-free version of it.

**Book VI therefore fails this book's own criterion**, and the failure is instructive rather than damaging, for the same reason Chapter 4 gave about Ezekiel 37:21. A content that fails the strip is not demoted; it is sorted. The conferral grammar is a claim about the figure material and it is figure-indexed by construction, exactly as the act-layer is act-indexed. Neither failure says anything about importance.

**What the exercise establishes.** The criterion cuts this book's own material the same way it cuts the corpus's, which is the minimum a reader should require of an instrument before trusting its verdicts. An instrument that passed everything the operator wanted to keep and cut everything he wanted to lose would be a preference wearing a procedure.

**And a second application, less comfortable.** Apply Chapter 125's finding about retention to this book. Chapter 125 argued that a corpus which preserves its own prosecution thirteen times has a habit of retention, and that a reader who extracts a single coherent position from it has added something.

This book extracts one. It reads thirteen retained pairs, declines to resolve any of them, and then states a position the corpus does not state. Appendix I records four claims that died and Chapter 165 records six limits, which is the closest this book comes to the corpus's own habit and is not the same thing.

**The honest form of that.** The corpus preserves. This book argues. Those are different activities and the second is not licensed by the first. What licenses the second is the falsifiers of Chapter 163, which are the form in which an argument can be held to account, and which the corpus, preserving rather than arguing, does not need and does not have.
