# BOOK XIII · WHAT THE CORPUS PRESERVES

## CHAPTER 120 · Jeremiah 8:8 · The Scribes Indicted, the Deposit Held

*ʾEykhah tomeru ḥakhamim ʾanaḥnu we-torat YHWH ʾittanu, ʾaken hinneh la-sheqer ʿasah ʿeṭ sheqer soferim.*

How do you say, we are wise and the law of the LORD is with us, when behold, the false pen of the scribes has made it into a lie?

**Two philological points are contested and both are carried as contested.**

**The referent of *soferim*.** The word can mean manuscript copyists or a teaching class with a professional function. Both readings have long support.

**The parsing of *ʿasah*.** It can be read with *ʿeṭ sheqer*, the false pen, as subject: the false pen of the scribes has made it a lie. Or *ʿasah* can be taken with a different subject or in a different construction, and the versions diverge.

**This book takes no side, because the argument holds under every combination.** Both readings of *soferim* place the fault at the carriage, and neither places it at the deposit. And *we-torat YHWH ʾittanu*, the law of the LORD is with us, stands in the same sentence under every parsing.

**That clause is the datum.** The verse is an indictment and its target is the handling. What is not indicted, and what the verse's own quoted claim asserts, is that the thing is in hand.

**Two parallel indictments in other books carry the identical shape at the priestly office.**

**Ezekiel 22:26.** *Kohaneyha ḥamesu torati wa-yeḥallelu qodashay, beyn qodesh le-ḥol loʾ hivdilu u-veyn ha-ṭameʾ le-ṭahor loʾ hodiʿu.* Her priests have done violence to my law and profaned my holy things; they have made no distinction between the holy and the common, nor taught the difference between the unclean and the clean.

*Torati*, my law, with the divine possessive, in the verse that indicts the priests for violence against it. The thing violated remains God's.

**Malachi 2:7-8.** *Ki siftey khohen yishmeru daʿat we-torah yevaqshu mi-pihu ki malʾakh YHWH ṣevaʾot huʾ. We-ʾattem sartem min ha-derekh, hikhshaltem rabbim ba-torah, shiḥattem berit ha-Lewi.* The lips of a priest should guard knowledge, and men should seek instruction from his mouth, for he is the messenger of the LORD of hosts. But you have turned aside from the way; you have caused many to stumble by the instruction; you have corrupted the covenant of Levi.

Same shape a third time: the office stated at its proper function, the office indicted for failing it, and the deposit named as intact.

**And Deuteronomy 4:2 and 13:1 belong here.** *Loʾ tosifu ʿal ha-davar ʾasher ʾanokhi meṣawweh ʾetkhem we-loʾ tigreʿu mimmennu.* You shall not add to the word which I command you, nor take from it.

**A prohibition on adding and subtracting is issued where adding and subtracting are anticipated.** That is the same inference as Chapter 58's about the law of the king: a guard erected against an impossibility is not a guard. The corpus expects tampering and legislates against it, twice, in one book.

**What this establishes for Book XIII.** The corpus indicts its own transmitting offices three times, in three books, and in every case names the deposit as held. That is a corpus with a specific and unusual relation to its own custodians, and it is the relation that makes the ten pairs of the next chapters legible.

## CHAPTER 121 · Ten Pairs · The First Five

The corpus states ten propositions on both ends and resolves neither end. This chapter takes five and the next takes five.

**Pair one. Deuteronomy 23:4-7 against Ruth 4:18-22 and 1 Kings 14:21.**

The bar: *loʾ yavoʾ ʿAmmoni u-Moʾavi bi-qhal YHWH gam dor ʿasiri loʾ yavoʾ lahem bi-qhal YHWH ʿad ʿolam.* No Ammonite or Moabite shall enter the assembly of the LORD, even to the tenth generation, forever.

The seating: Ruth 4:18-22 gives the genealogy Perez to David and runs it through Boaz, whose wife is Ruth *ha-Moʾaviyyah*, the Moabitess, so designated five times in the book. And 1 Kings 14:21 names Rehoboam's mother *Naʿamah ha-ʿAmmonit*, the Ammonitess, repeated at 14:31.

Both barred nations, both inside the Davidic line, both designated by nationality at the point of seating.

**Pair two. Jeremiah 22:24-30 against Haggai 2:23.**

The plucking: though Coniah were the signet on my right hand, I would pluck you from there; write this man childless.

The restoration: I will take you, Zerubbabel, and make you as a signet, for I have chosen you.

Same image, opposite direction, two generations apart in the genealogy at 1 Chronicles 3:17.

**Pair three. Isaiah 49:3 against Isaiah 49:6.**

*ʿAvdi ʾattah Yisraʾel*, you are my servant, Israel, at 49:3.

*Naqel mi-hyotekha li ʿeved le-haqim ʾet shivṭey Yaʿaqov*, it is too light a thing that you should be my servant to raise up the tribes of Jacob, at 49:6.

The servant is named Israel and given a mission to Israel, four verses apart, in one oracle.

**Pair four. Jeremiah 7:22 with 1 Samuel 15:22, Hosea 6:6, Isaiah 1:11, against Ezekiel 40 through 48.**

Jeremiah 7:22: *ki loʾ dibbarti ʾet ʾavoteykhem we-loʾ ṣiwwitim be-yom hoṣiʾi ʾotam me-ʾereṣ Miṣrayim ʿal divrey ʿolah wa-zavaḥ.* I did not speak to your fathers nor command them in the day I brought them out of Egypt concerning burnt offerings and sacrifices.

1 Samuel 15:22: *hinneh shemoaʿ mi-zevaḥ ṭov*, to obey is better than sacrifice.
Hosea 6:6: *ki ḥesed ḥafaṣti we-loʾ zavaḥ*, I desire covenant loyalty and not sacrifice.
Isaiah 1:11: *lammah li rov zivḥeykhem*, what to me is the multitude of your sacrifices.

Against them, Ezekiel's temple vision restores the whole apparatus in detail, with the prince's six lambs and a ram without blemish on the sabbath at 46:4, and the offerings specified through chapters 45 and 46.

**Pair five. Judges 8:23 and 1 Samuel 8:7 against 1 Chronicles 29:23.**

Kingship refused, and the demand for it named a rejection of the divine reign. And a king seated on the throne of the LORD.

Chapters 42, 45, and 53 worked all three.

## CHAPTER 122 · Ten Pairs · The Second Five

**Pair six. 1 Samuel 8:11-18 against Psalm 45:7.**

The itemized prosecution: your sons, your daughters, your fields, your vineyards, your olive groves, a tenth, a tenth, your servants, your best young men, your donkeys, and you shall be his servants.

And a king's throne addressed as *ʾelohim*, forever and ever.

The same institution, prosecuted in one book and exalted in another, in one canon.

**Pair seven. Numbers 25:12-13 and Ezekiel 44:15 against Psalm 110:4.**

The Aaronide grant: *hineni noten lo ʾet beriti shalom, we-haytah lo u-le-zarʿo ʾaḥaraw berit kehunnat ʿolam*, a covenant of perpetual priesthood to Phinehas and his seed. And Ezekiel 44:15's restriction of temple service to the sons of Zadok.

Against them, a perpetual priesthood conferred by divine oath on a non-Aaronide and pre-Israelite order.

**Pair eight. Deuteronomy 7:1-3 and Exodus 34:15-16 against the ancestry.**

The prohibition: *we-loʾ titḥatten bam, bittekha loʾ titten li-vno u-vitto loʾ tiqqaḥ li-vnekha.* You shall not intermarry with them.

Against it, the line and its neighbours run through the barred nations in seven instances across three registers, which Chapter 123 sets out.

**Pair nine. Job 14:8 against Isaiah 11:1.**

The stump dies in the dust. A shoot comes from the stump.

Chapter 88 stated the objection to this one and it is the most contestable of the ten.

**Pair ten. Psalm 23:1 with 2 Samuel 5:2 against Ezekiel 34:24.**

The king says the LORD is my shepherd. The elders say you shall shepherd my people. And Ezekiel has David a prince in their midst while God remains their God, with the flock called *ṣoʾni* eleven times in the chapter.

**Three further pairs belong in the count and are recorded here rather than promoted, because ten is a convenient number and the corpus does not stop at it.**

**Psalm 132:12's conditional against 2 Samuel 7:15's bar on withdrawal.** Chapter 105.

**1 Samuel 8:18's unanswered outcry against Psalm 72:12's king who delivers the needy when he cries.** Chapter 103.

**And 2 Kings 10:30's approval of Jehu's bloodshed against Hosea 1:4's visiting of that blood on his house.** Chapter 69.

**Thirteen pairs.** The number is not the point. The point is the habit.

## CHAPTER 123 · The Line Seated Through the Standing Bar

Pair eight requires its own chapter because the instances are numerous and the corpus quotes its own prohibition at the breach.

**Four instances stand inside the Davidic line as Ruth 4:18-22 enumerates it.**

**Judah**, at the head of the genealogy. Genesis 38:2 has him take *bat ʾish Kenaʿani u-shemo Shuaʿ*, the daughter of a Canaanite man named Shua. Her sons Er and Onan die and Shelah is not the line. The line routes instead through Tamar, whose origin the corpus does not supply, in the episode at Genesis 38 that produces Perez, and Ruth 4:18 begins the genealogy at Perez.

**Boaz through Ruth**, designated *ha-Moʾaviyyah* at Ruth 1:22, 2:2, 2:21, 4:5, and 4:10.

**David through the household of Uriah**, designated *ha-Ḥitti*, the Hittite, at 2 Samuel 11:3, 11:6, 11:17, 11:21, 11:24, 12:9, 12:10, 23:39, and 1 Kings 15:5. Bathsheba is introduced as his wife and the corpus repeats his nationality nine times.

**Solomon**, whose successor at 1 Kings 14:21 is the son of Naamah the Ammonitess.

**Three instances stand outside the Davidic line.**

**Ishmael through Hagar *ha-Miṣrit***, the Egyptian, at Genesis 16:1, 16:3, 21:9, and 25:12.

**Joseph through Asenath *bat Poṭi-Feraʿ khohen ʾOn***, daughter of Potiphera priest of On, at Genesis 41:45 and 46:20. The mother of Ephraim and Manasseh is the daughter of an Egyptian priest and the corpus states his office.

**Moses through Zipporah**, daughter of the priest of Midian, and through *ha-ʾishah ha-Kushit* at Numbers 12:1. And in that episode **the objectors are rebuked and the marriage is not**. Miriam and Aaron speak against Moses because of the Cushite woman; the LORD comes down in a pillar of cloud; Miriam becomes leprous. Nothing in the chapter says the marriage was wrong and the chapter's argument at 12:6-8 is about Moses's prophetic standing.

**And 1 Kings 11:2 quotes the prohibition verbatim at the point of the breach.**

*Min ha-goyim ʾasher ʾamar YHWH ʾel benei Yisraʾel loʾ tavoʾu vahem we-hem loʾ yavoʾu vakhem, ʾakhen yaṭṭu ʾet levavkhem ʾaḥarey ʾeloheyhem.* From the nations concerning which the LORD said to the children of Israel, you shall not go among them, neither shall they come among you, for surely they will turn away your heart after their gods.

**The corpus is therefore neither unaware nor approving.** It bars. It records the breach as a breach and quotes the bar while doing so. And it continues the line through it.

That combination is the datum. A tradition editing for consistency would have removed the bar, removed the designations, or removed the genealogy. This one keeps all three and prints the prohibition at the moment of its violation.

## CHAPTER 124 · What Israel Holds Is Recorded as Received

Chapter 57 set out the four transfers. This chapter states what the pattern is evidence for.

**The four.** A standing priestly order from Melchizedek. A divine title from the same encounter, taken onto Abram's oath four verses later with the Name prefixed. An administrative procedure from Jethro, with Moses recorded as listening to the voice of his father-in-law. And the sanctuary's ground from Ornan the Jebusite, bought at a named price with David refusing to offer what cost him nothing.

**A fifth belongs with them and is not usually counted.** The alphabet and the language are Canaanite, and the corpus knows it: Isaiah 19:18 calls Hebrew *sefat Kenaʿan*, the language of Canaan.

**And a sixth is arguable and is recorded at low confidence.** The temple's construction is executed with Tyrian labour and materials, and 1 Kings 5 records the treaty with Hiram and 1 Kings 7:13-14 names Hiram the craftsman as the son of a widow of Naphtali and a Tyrian father, a worker in bronze.

**What the pattern shows.** In each case the corpus could have concealed the source and did not. It could have given the priestly order no antecedent, had Abram coin the divine title, had Moses devise the judiciary, made the threshing floor ancestral land, and said nothing about the language.

**And the pattern converges with Books VI and X from a different direction.** Those books found the corpus stating what a king holds as received from God. This chapter finds the corpus stating what the nation holds as received from its neighbours. The two are different claims about different objects and they share a shape: a habit of recording provenance where a tradition optimizing for prestige would not.

**Two disciplinary notes.**

**The observation is about the corpus's narration, not about historical dependence.** Whether Israelite institutions historically derive from Canaanite, Midianite, or Egyptian ones is a question for archaeology and comparative religion. The claim here is about what the received text records.

**And the observation is not a claim of unique virtue.** Other traditions record borrowings too. What is being noted is that this corpus does it repeatedly, in the case of its most sacred institutions, and at points where concealment would have been easy.

## CHAPTER 125 · A Tradition Operating by Deletion Does Not Preserve Its Own Prosecution

Book XIII closes on the inference the preceding chapters support.

**The evidence.** Thirteen pairs, each stated on both ends and resolved by neither. Three indictments of the corpus's own transmitting offices with the deposit named as intact in each. Seven instances of the ancestry running through a standing bar with the bar quoted at the breach. Six recorded receipts from outside. And, from Book V, the itemized prosecution of the monarchy preserved on the same scroll as the royal psalms.

**The inference.** A tradition operating by deletion does not preserve its own prosecution thirteen times.

That is a claim about editorial behaviour and it should be stated carefully because it can be inflated in two directions.

**It does not establish that nothing was ever removed.** Deuteronomy 4:2's prohibition on adding and subtracting is evidence that both were anticipated, and Jeremiah 8:8 is evidence that the corpus itself alleged tampering. The claim is not that the corpus is unedited.

**It does not establish that the corpus is true.** A retained contradiction is evidence of an editorial policy, not of accuracy about anything.

**What it does establish** is that the corpus's characteristic response to material that tells against its own institutions is retention rather than removal, and that this response is repeated often enough to be a habit rather than an accident.

**Three consequences for the argument of this book.**

**The final form is a reliable object of study for a question about what the corpus says.** If the assembly is retentive, then what is in it is evidence about what the tradition held rather than about what a redactor wanted the tradition to appear to hold.

**The retained tensions are not problems to be solved.** Chapter 39 declined to resolve the hardening problem and this chapter supplies the general form of that decision. Where the corpus states two things and reconciles neither, a reader who reconciles them has added something. That addition may be right and it is an addition.

**And this book's own reading is subject to the same standard.** Chapter 108 will say so under the heading of limits. A book that extracts a single coherent position from a corpus that declined to state one has done something the corpus did not do, and the honest form of that is to name it rather than to present the extraction as a discovery.

One closing observation. The habit has a cost and the corpus pays it. A retentive tradition is harder to use. It cannot be quoted cleanly on the monarchy, on sacrifice, on the priesthood, on intermarriage, or on the fate of a stump, because it says two things about each. Every reader of it, ancient and modern, has had to choose, and every choosing has been an interpretation. That is the situation the whole history of reading this corpus has taken place inside, and it is a situation the corpus created for itself and did not have to.
