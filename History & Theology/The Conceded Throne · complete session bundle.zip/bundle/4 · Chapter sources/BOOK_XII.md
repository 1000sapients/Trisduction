# BOOK XII · THE PROPHETS AND THE FIGURE

## CHAPTER 110 · Reading the Prophets Book by Book

The prophetic corpus is where the messianic material is usually sought and it is the body this book has drawn on most heavily without yet treating systematically. This book of chapters surveys it, prophet by prophet, asking one question of each: what does this book say about a coming figure, and in what grammar.

The survey is not exhaustive. It takes the passages a reader would expect and it names the ones it omits. Its purpose is to establish whether the pattern of Books VI, VIII, and X holds across the prophetic corpus as a whole or only in the passages this book has selected.

Three procedural notes.

**The books are taken in canonical order**, Isaiah through Malachi, with the Twelve treated as a group and its members taken individually where they carry relevant material.

**Where a book carries nothing, that is reported.** Several prophetic books contain no royal-figure material at all and the silence is a datum.

**And where a passage is contested in its reference, the contest is named and the argument does not depend on the outcome.** Almost all of this material has been read in more than one way by serious readers over two millennia, and a survey that presented single readings as settled would be misrepresenting the field.

## CHAPTER 111 · Isaiah · The Densest Field

Isaiah carries more royal-figure material than any other prophetic book and it carries it in three distinguishable groups.

**Group one, the Immanuel and throne-name material of chapters 7 through 11.**

7:14, *hinneh ha-ʿalmah harah we-yoledet ben we-qaraʾt shemo ʿImmanu ʾEl*. The sign is given to Ahaz in the context of the Syro-Ephraimite crisis and 7:16 dates its significance: before the child knows to refuse the evil and choose the good, the land of the two kings will be forsaken. The reference is contested at every level and this book takes no position. Note only the conferral form: *YHWH huʾ yitten lakhem ʾot*, the Lord himself will give you a sign, at 7:14a.

9:5-6, the throne-name, worked at Chapter 78. Two passives and a closing agent-clause.

11:1-9, the shoot, worked at Chapters 79 and 84. The spirit settles on him; the state at 11:9 is agentless.

**Group two, the servant material of chapters 42 through 53.**

42:1, *hen ʿavdi ʾetmokh bo beḥiri raṣetah nafshi, natatti ruḥi ʿalaw mishpaṭ la-goyim yoṣiʾ*. Behold my servant whom I uphold, my chosen in whom my soul delights; I have put my spirit upon him; he shall bring forth justice to the nations. Four divine verbs in the opening line: I uphold, I have chosen, my soul delights, I have put my spirit.

49:3, *wa-yoʾmer li ʿavdi ʾattah Yisraʾel ʾasher bekha ʾetpaʾar*, you are my servant, Israel, in whom I will be glorified. And 49:6, four verses later, *naqel mi-hyotekha li ʿeved le-haqim ʾet shivṭey Yaʿaqov*, it is too light a thing that you should be my servant to raise up the tribes of Jacob. The servant is named Israel at 49:3 and distinguished from the tribes at 49:6. The corpus states both and Book XIII counts the pair.

50:4-9, the servant who is taught: *ʾAdonay YHWH natan li leshon limmudim la-daʿat la-ʿut ʾet yaʿef davar, yaʿir ba-boqer ba-boqer yaʿir li ʾozen li-shmoaʿ ka-limmudim.* The Lord GOD has given me the tongue of the taught, to know how to sustain the weary with a word; morning by morning he wakens my ear to hear as the taught.

**That verse belongs in Book IV and is placed here.** The servant's ear is wakened by another, morning by morning, to hear. The deficit inventory addressed, in the servant, by a divine act, repeatedly.

52:13-53:12, the fourth song. Its opening is conferral: *hinneh yaskil ʿavdi yarum we-nissaʾ we-gavah meʾod*, behold my servant shall prosper, he shall be exalted and lifted up and be very high. Three verbs of elevation, two of them in forms that can be read as passive or as intransitive. And 53:12: *lakhen ʾaḥalleq lo va-rabbim we-ʾet ʿaṣumim yeḥalleq shalal*, therefore I will divide him a portion with the great, first person divine.

**Group three, Cyrus at 44:28 and 45:1**, worked at Chapter 71.

**And 42:19's blind servant**, worked at Chapter 34, which belongs to group two and which forecloses any triumphal reading of the servant material.

**The result for Isaiah.** Three groups, all of them stating what the figure holds with divine verbs, and one of them applying the deficit diagnostic to the figure himself.

## CHAPTER 112 · Jeremiah · The Branch and the New Covenant

Jeremiah carries two bodies of relevant material and they sit in different registers.

**The Branch material**, at 23:5-6 and 33:14-16, worked at Chapter 90. *Wa-haqimoti* and *ʾaṣmiaḥ*, both first person divine.

**And 33:17-18 extends the promise to two offices**, which is the split of stage seven anticipated: *loʾ yikkaret le-Dawid ʾish yoshev ʿal kisseʾ veyt Yisraʾel, we-la-kohanim ha-Lewiyyim loʾ yikkaret ʾish mi-lefanay*, David shall never lack a man to sit on the throne of the house of Israel, and the levitical priests shall never lack a man before me. Two perpetual offices in two verses, with the priestly one stated in the same form as the royal.

**The Coniah oracle at 22:24-30 is the counter-testimony and Jeremiah supplies it himself.** *Ḥay ʾani neʾum YHWH ki ʾim yihyeh Konyahu ven Yehoyaqim melekh Yehudah ḥotam ʿal yad yemini ki mi-sham ʾettekekka.* As I live, though Coniah son of Jehoiakim king of Judah were the signet on my right hand, yet I would pluck you from there.

And 22:30: *kitvu ʾet ha-ʾish ha-zeh ʿariri gever loʾ yiṣlaḥ be-yamaw, ki loʾ yiṣlaḥ mi-zarʿo ʾish yoshev ʿal kisseʾ Dawid u-moshel ʿod bi-Yhudah.* Write this man down as childless, a man who shall not prosper in his days; for none of his seed shall prosper sitting on the throne of David and ruling again in Judah.

**And Haggai 2:23 restores the signet to Coniah's grandson.** *Ba-yom ha-huʾ neʾum YHWH ṣevaʾot ʾeqqaḥakha Zerubbavel ben Sheʾaltiʾel ʿavdi neʾum YHWH we-samtikha ka-ḥotam ki vekha vaḥarti.* In that day I will take you, Zerubbabel son of Shealtiel my servant, and make you as a signet, for I have chosen you.

The genealogy at 1 Chronicles 3:17-19 makes Zerubbabel the grandson of Jehoiachin, who is Coniah. Book XIII counts the pair, and notes that Haggai's verbs are three first-person divine ones: I will take, I will make, I have chosen.

**The new covenant at 31:31-34.** *Hinneh yamim baʾim neʾum YHWH we-kharatti ʾet beyt Yisraʾel we-ʾet beyt Yehudah berit ḥadashah.* And 31:33: *natatti ʾet torati be-qirbam we-ʿal libbam ʾekhtavennah, we-hayiti lahem le-ʾelohim we-hemmah yihyu li le-ʿam.* I will put my law within them and write it on their hearts, and I will be their God and they shall be my people.

And 31:34: *we-loʾ yelammedu ʿod ʾish ʾet reʿehu we-ʾish ʾet ʾaḥiw leʾmor deʿu ʾet YHWH, ki khullam yedʿu ʾoti le-miq-qaṭannam we-ʿad gedolam neʾum YHWH.* And they shall no longer teach each his neighbour and each his brother, saying, know the LORD, for they shall all know me from the least of them to the greatest.

**Chapter 82 used this passage and the point bears repeating here in its own book.** Jeremiah's answer to the deficit is a writing on the heart, with God as subject, and its stated result is a knowing that requires no teacher. There is no figure in the pericope. The Branch oracle stands eight chapters earlier and the two are never connected by the book.

## CHAPTER 113 · Ezekiel · The Prince, and the Sanctuary in the Midst

Ezekiel's royal material has been worked at Chapters 28, 61, and 95. This chapter states the book's overall position.

**The book prefers *nasiʾ* to *melekh*.** Chapter 61 counted the occurrences. In the temple vision of chapters 40 through 48 the term is *nasiʾ* throughout: 44:3, 45:7-8, 45:16-17, 45:22, 46:2-18, 48:21-22.

**The prince's portion is assigned and bounded.** 45:7: *we-la-nasiʾ mi-zzeh u-mi-zzeh li-trumat ha-qodesh we-la-ʾaḥuzzat ha-ʿir*, and to the prince on one side and the other of the holy portion and of the possession of the city. His land is defined relative to the sanctuary's and the city's, and 45:8 states the purpose: *le-maʿan loʾ yonu ʿod nesiʾay ʾet ʿammi*, so that my princes shall no more oppress my people.

*Nesiʾay*, my princes, and *ʿammi*, my people. Both possessives on God, in the verse restricting the prince's holding.

**The prince brings his own offerings.** 45:22: *we-ʿasah ha-nasiʾ ba-yom ha-huʾ baʿado u-veʿad kol ʿam ha-ʾareṣ par ḥaṭṭaʾt.* On that day the prince shall prepare for himself and for all the people of the land a bull for a sin offering. The prince offers a sin offering for himself, which places him among those needing one.

**His movement in the sanctuary is regulated.** 46:2: he enters by the porch of the gate from outside and stands by the post of the gate; the priests prepare his offering; he worships at the threshold and goes out; the gate is not shut until evening. 46:8-10: he enters and goes out by the same way; the people entering by the north gate go out by the south. Whatever else the prince is, he is a man whose route through a building is prescribed.

**And 46:16-18 limits his estate.** He may give a gift to a son and it becomes the son's inheritance; a gift to a servant reverts at the year of liberty. And 46:18: *we-loʾ yiqqaḥ ha-nasiʾ mi-naḥalat ha-ʿam le-honotam me-ʾaḥuzzatam*, the prince shall not take of the people's inheritance to thrust them out of their possession.

**That verse is 1 Samuel 8:14 answered.** The bill at 1 Samuel 8:14 had the king taking the best fields and vineyards and olive groves. Ezekiel 46:18 forbids exactly that, using the same verb *lqḥ*, in the temple vision, of the prince. The corpus states the abuse and states its prohibition, four centuries apart in its own chronology, in one vocabulary.

**And the vision's final word is a name for a city.** 48:35: *u-shem ha-ʿir mi-yom YHWH shammah.* And the name of the city from that day: **the LORD is there.**

The book that most carefully bounds its prince's portion, route, and estate closes on a sentence naming the city for a divine presence.

## CHAPTER 114 · Hosea, Amos, and Micah

**Hosea.** Chapter 50 worked 13:11's giving and taking in anger. Two further sites belong here.

3:5: *ʾaḥar yashuvu benei Yisraʾel u-viqshu ʾet YHWH ʾeloheyhem we-ʾet Dawid malkam, u-faḥadu ʾel YHWH we-ʾel ṭuvo be-ʾaḥarit ha-yamim.* Afterward the children of Israel shall return and seek the LORD their God and David their king, and shall come in fear to the LORD and to his goodness in the latter days.

Two objects of seeking, God and David, with God first and the fear-clause naming only God.

8:4: *hem himlikhu we-loʾ mimmenni, hesiru we-loʾ yadaʿti.* They made kings and not from me; they removed and I did not know. The book's position on the northern monarchies stated in one verse: made without divine appointment, and the corpus's word for that is *loʾ mimmenni*.

**Amos.** The book carries almost no royal-figure material, which is itself a datum for a prophet of the eighth century. Its one relevant passage is at the very end.

9:11: *ba-yom ha-huʾ ʾaqim ʾet sukkat Dawid ha-nofelet we-gadarti ʾet pirṣeyhen wa-harisotaw ʾaqim u-venitiha ki-mey ʿolam.* In that day I will raise up the booth of David that is fallen, and repair its breaches, and raise up its ruins, and build it as in the days of old.

**Four first-person divine verbs and no figure.** I will raise, I will repair, I will raise, I will build. The object is *sukkat Dawid*, the booth or hut of David, which is a diminutive: not a house, not a throne, a booth. And the whole restoration is stated with God as subject and no occupant named.

**Micah.** Chapter 99 worked 5:1-4. Two further observations.

3:11-12 is the book's indictment and it names three offices: *raʾsheyha be-shoḥad yishpoṭu we-khohaneyha bi-meḥir yoru u-neviʾeyha be-khesef yiqsomu*, her heads judge for a bribe, her priests teach for hire, her prophets divine for money. And 3:12: *ṣiyyon sadeh teḥaresh wi-Yrushalayim ʿiyyin tihyeh*, Zion shall be plowed as a field and Jerusalem shall become heaps.

And 6:8, which Chapter 3 used as the calibration case, stands three chapters later in the same book: what does the LORD require, and the answer contains no figure and no date.

**Micah therefore contains, in six chapters, the corpus's most specific naming of a birthplace and the corpus's cleanest figure-free statement of requirement.** The book holds both without relating them.

## CHAPTER 115 · Zechariah and Haggai · The Post-Exilic Pair

The two prophets of the rebuilding carry the corpus's most concrete royal material, addressed to a named living man, and it is worth reading for that reason.

**Haggai.** Two oracles.

2:6-9: *ʿod ʾaḥat meʿaṭ hiʾ wa-ʾani marʿish ʾet ha-shamayim we-ʾet ha-ʾareṣ*, once more, in a little while, I will shake the heavens and the earth. And 2:9: *gadol yihyeh kevod ha-bayit ha-zeh ha-ʾaḥaron min ha-rishon ʾamar YHWH ṣevaʾot, u-va-maqom ha-zeh ʾetten shalom.* The glory of this latter house shall be greater than the former, and in this place I will give peace.

*ʾEtten shalom*, I will give peace, first person divine, with no figure in the clause.

2:23, the signet oracle to Zerubbabel, quoted at Chapter 112. Three first-person divine verbs.

**Zechariah.** Beyond the material at Chapters 80 and 90, two passages.

**4:6.** *Loʾ ve-ḥayil we-loʾ ve-khoaḥ ki ʾim be-ruḥi ʾamar YHWH ṣevaʾot.* Not by might nor by power but by my spirit, says the LORD of hosts. Addressed to Zerubbabel, the Davidic governor, in a book that also gives him the temple foundation and the plummet in his hand at 4:9-10.

**9:9.** *Gili meʾod bat Ṣiyyon hariʿi bat Yerushalayim, hinneh malkekh yavoʾ lakh ṣaddiq we-noshaʿ huʾ, ʿani we-rokhev ʿal ḥamor we-ʿal ʿayir ben ʾatonot.*

Rejoice greatly, daughter of Zion; shout, daughter of Jerusalem; behold, your king comes to you, righteous and **saved**, humble and riding on a donkey, on a colt the foal of a donkey.

**The participle at the centre of that verse is the datum.** *We-noshaʿ*, nifal of *yšʿ*, and the nifal is passive: saved, delivered, having been given victory. Not saving. The Septuagint and several English versions render it actively as saviour, and the Hebrew form does not support that. The corpus's most quoted announcement of an arriving king describes him as righteous and saved.

And the two adjectives beside it: *ʿani*, poor or humble, and the mount, a donkey rather than a horse. 9:10 completes it: *we-hikhratti rekhev me-ʾEfrayim we-sus mi-Yrushalayim we-nikhretah qeshet milḥamah*, and I will cut off the chariot from Ephraim and the horse from Jerusalem and the battle bow shall be cut off. First person divine, cutting off the instruments of war, in the verse after the king arrives on a donkey.

**And 9:10 closes on the terminus.** *We-dibber shalom la-goyim u-mosholo mi-yam ʿad yam.* And he shall speak peace to the nations, and his dominion from sea to sea.

*U-mosholo*, and his dominion, from *mšl*, the verb Gideon declined. The corpus's arriving king is saved, humble, mounted on a donkey, and his dominion is stated in the verb refused at Judges 8:23. The corpus is not shy of the connection and does not comment on it.

## CHAPTER 116 · The Prophets Who Say Nothing

Several prophetic books contain no material about a coming royal figure, and a survey that reported only the books that do would be misrepresenting the field.

**Joel.** The book's subject is a locust plague, a call to repentance, the pouring out of the spirit at 3:1-2, and the day of the LORD. *We-hayah ʾaḥarey khen ʾeshpokh ʾet ruḥi ʿal kol basar we-nibbeʾu beneykhem u-venoteykhem*, I will pour out my spirit on all flesh and your sons and your daughters shall prophesy. First person divine, all flesh as recipient, and no figure anywhere in the book.

**Obadiah.** Twenty-one verses against Edom, closing at v. 21 with *we-ʿalu moshiʿim be-har Ṣiyyon li-shpoṭ ʾet har ʿEsaw, we-haytah la-YHWH ha-melukhah.* And saviours shall go up on Mount Zion to judge the mount of Esau, and the kingdom shall be the LORD's.

*Moshiʿim*, plural, saviours. And the closing clause assigns the kingdom to God. The book's one relevant sentence has a plural of deliverers and a divine kingship.

**Nahum.** Against Nineveh. No figure.

**Habakkuk.** The dialogue about the prosperity of the wicked, the Chaldeans, the woes, and the closing psalm. 3:13's *le-yeshaʿ meshiḥekha* is the one occurrence and Chapter 108 read it as an object of salvation. And 2:4's *we-ṣaddiq be-ʾemunato yiḥyeh*, the righteous shall live by his faithfulness, is the book's positive statement and it contains no figure.

**Zephaniah.** The day of the LORD, the judgment of the nations, and the closing at 3:14-17. *YHWH ʾelohayikh be-qirbekh gibbor yoshiaʿ*, the LORD your God is in your midst, a mighty one who saves. And 3:15: *melekh Yisraʾel YHWH be-qirbekh loʾ tirʾi raʿ ʿod*, the king of Israel, the LORD, is in your midst; you shall fear evil no more.

**The king of Israel is named and it is YHWH.** In a post-monarchic oracle of restoration, the corpus supplies a king and the king is God.

**Malachi.** The last book. It carries a messenger at 3:1, *hineni sholeaḥ malʾakhi u-finnah derekh le-fanay*, behold I send my messenger and he shall prepare the way before me, and 3:23, *hinneh ʾanokhi sholeaḥ lakhem ʾet ʾEliyyah ha-naviʾ lifney boʾ yom YHWH*, behold I send you Elijah the prophet before the coming of the great and terrible day of the LORD. Two sendings, both first person divine, and the figure sent is a messenger and a prophet rather than a king.

**The survey's result.** Of the twelve minor prophets, five carry no royal-figure material at all, one carries a plural of saviours and a divine kingship, one names the king of Israel as YHWH, and one sends a prophet. The concentration of royal-figure material in Isaiah, Jeremiah, Ezekiel, Micah, Zechariah, and Haggai is real and the distribution is uneven, and the uneven distribution is part of what the prophetic corpus is.

## CHAPTER 117 · Daniel · The Aramaic Court and the Seventy Weeks

Daniel has been used at Chapter 81 for 7:13-14. This chapter takes the book's other relevant material and states what it does and does not settle.

**The four kingdoms.** Chapters 2 and 7, the statue and the beasts. In both the sequence ends in a divine act. 2:44: *u-ve-yomeyhon di malkhayyaʾ ʾinnun yeqim ʾelah shemayyaʾ malkhu di le-ʿalmin laʾ titḥabbal.* And in the days of those kings the God of heaven will set up a kingdom which shall never be destroyed. *Yeqim*, he will set up, with God as subject.

**And 2:34's stone.** *Ḥazeh hawayta ʿad di hitgezeret ʾeven di laʾ vidayin.* You watched until a stone was cut out **not by hands**. The passive *hitgezeret* and the qualifying phrase together specify that the agent is not human and is not named.

**The seventy weeks at 9:24-27.** Two occurrences of *mashiaḥ*, at 9:25 and 9:26, and the passage is among the most contested in the Hebrew Bible. Its numbers, its starting point, its punctuation, and the identity of its figures have been read in more ways than can be summarized. This book takes no position on any of it and uses the passage for nothing.

What can be said without entering the dispute is that 9:26's *yikkaret mashiaḥ we-ʾeyn lo*, an anointed one shall be cut off and have nothing, is a passive of a violent verb applied to a bearer of the title, and belongs with the laments of Chapter 108 as another site where the corpus uses the title at a moment of failure.

**Chapter 9's prayer is the book's longest continuous passage and it contains no figure.** 9:4-19 is a confession: we have sinned, we have done wickedly, we have rebelled, we have not listened to your servants the prophets. *Loʾ shamaʿnu* at 9:6, *we-loʾ shamaʿnu be-qol YHWH* at 9:10, *we-loʾ ḥillinu ʾet peney YHWH* at 9:13. The hearing failure of Book IV, confessed three times in the prayer that precedes the corpus's most contested messianic passage.

And 9:18's petition: *ki loʾ ʿal ṣidqoteynu ʾanaḥnu mappilim taḥanuneynu le-faneykha ki ʿal raḥameykha ha-rabbim*, for we do not present our supplications before you on the ground of our righteousness but on the ground of your great mercies.

**The result for Daniel.** The book's two great visions end in divine acts stated with God as subject or in the passive. Its longest prayer confesses a hearing failure. And its most contested passage uses the royal title of a figure who is cut off.

## CHAPTER 118 · The Day of the LORD

The corpus's other great future-oriented motif is the day of the LORD, and it is worth setting beside the figure because it is more widely distributed and structurally different.

**The sites are numerous and span the prophetic corpus.** Amos 5:18-20, Isaiah 2:12 and 13:6-9, Joel 1:15 and 2:1-11 and 3:4 and 4:14, Obadiah 15, Zephaniah 1:7-18, Ezekiel 13:5 and 30:3, Malachi 3:23.

**Amos 5:18-20 is the earliest and it is a reversal.** *Hoy ha-mitʾawwim ʾet yom YHWH, lammah zeh lakhem yom YHWH, huʾ ḥoshekh we-loʾ ʾor.* Woe to you who desire the day of the LORD; why would you have it? It is darkness and not light. And 5:19: as if a man fled from a lion and a bear met him, or went into the house and leaned his hand on the wall and a serpent bit him.

The corpus's first extended treatment of the motif is a warning to people looking forward to it.

**Zephaniah 1:14-18 is the fullest description.** *Qarov yom YHWH ha-gadol qarov u-maher meʾod.* A day of wrath, of trouble and distress, of devastation and desolation, of darkness and gloom, of clouds and thick darkness, of trumpet and battle cry.

**And the day's characteristic grammar is that it has no human agent.** Across every site, what happens on the day is done by God or happens impersonally. The sun is darkened, the moon does not give its light, the stars withdraw their shining, the earth quakes, the heavens tremble. Where an agent is named it is YHWH: *ki gadol yom YHWH we-noraʾ meʾod u-mi yekhilennu*, at Joel 2:11, for the day of the LORD is great and very terrible, and who can endure it.

**Two structural observations for this book.**

**The day motif and the figure motif are largely disjoint in the corpus.** The passages that describe the day do not name a royal figure, and the passages that name a royal figure do not usually describe the day. Malachi 3:23 is the closest they come, sending Elijah before the day, and the figure sent there is a prophet.

**And the day is not a delivery.** It is stated as an arrival of God, or of God's action, and its characteristic effect on the hearers is that they cannot endure it. Amos 5:18's *lammah zeh lakhem yom YHWH* asks the audience why they want it, which presupposes that they do and implies they have misunderstood what it is.

That is a second corpus-internal case of the pattern Book VIII described: an expectation directed at an arrival, and a corpus responding by asking what the expectant party thinks the arrival will do for them.

## CHAPTER 119 · What the Prophetic Survey Establishes

Five results.

**The pattern holds across the corpus and not only in the selected passages.** Every prophetic statement of what a coming figure holds, in Isaiah, Jeremiah, Ezekiel, Micah, Zechariah, and Haggai, states it with a divine verb or a passive. The survey found no exception, and it looked in the books where an exception would be most likely.

**The distribution is uneven and five of the Twelve carry nothing.** A reader whose impression is that the prophetic corpus is saturated with messianic expectation has an impression formed by selection, and the selection is ancient and understandable and is still a selection.

**Two prophetic books name a king and the king is God.** Zephaniah 3:15's *melekh Yisraʾel YHWH be-qirbekh*, and Obadiah 21's *we-haytah la-YHWH ha-melukhah*. Both are post-monarchic in setting.

**The corpus's direct remedies for the deficit are prophetic and contain no figure.** Jeremiah 31:33-34 writes on the heart and produces a universal knowing. Ezekiel 36:26-27 replaces the heart and puts a spirit within. Joel 3:1 pours the spirit on all flesh. Three passages, three books, one grammar, and no figure in any of them.

**And the corpus's most quoted arrival-announcement describes the arriving king with a passive participle.** Zechariah 9:9's *we-noshaʿ*, saved.

One closing note. This book of chapters has been a survey rather than an argument, and its value is exactly that it looked systematically rather than selectively. The reading of Books VI through XI was built from passages this book chose. Book XII asked whether the pattern survives being tested against the whole prophetic corpus including the parts that were not chosen. It does, and the strongest single piece of evidence for that is Zechariah 9:9, which was not part of the original reading and which turned out on inspection to carry a passive participle at its centre.
