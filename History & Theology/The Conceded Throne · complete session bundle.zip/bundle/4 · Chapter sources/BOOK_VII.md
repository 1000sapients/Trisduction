# BOOK VII · THE OCCUPANTS

## CHAPTER 64 · The Anointing Rite · Oil, Horn, and Flask

Before the occupants, the rite, because the rite is described in enough physical detail that its structure can be read rather than assumed.

**The substance.** Oil, *shemen*. For the sanctuary and the priesthood the corpus specifies a compounded oil at Exodus 30:22-33: myrrh, sweet cinnamon, sweet calamus, cassia, and olive oil, in stated weights, compounded *maʿaseh roqeaḥ*, the work of a perfumer. It is called *shemen mishḥat qodesh*, holy anointing oil, and its replication for common use is prohibited on pain of being cut off, at 30:32-33. For the royal anointings the corpus does not specify the composition and refers simply to oil.

**The vessel.** Two are named and the difference has been noticed since antiquity. Saul is anointed from *pakh ha-shemen*, a flask or vial, at 1 Samuel 10:1. David is anointed from *qeren ha-shemen*, a horn of oil, at 16:13. Solomon from *ha-qeren shemen* at 1 Kings 1:39. Jehu from *pakh ha-shemen* at 2 Kings 9:1 and 9:3. The pattern, flask for Saul and Jehu, horn for David and Solomon, is suggestive and this book does not build on it, since two instances on each side is thin.

**The gesture.** *Wa-yiṣoq ʿal roʾsho*, and he poured on his head, at 1 Samuel 10:1. *Wa-yimshaḥ ʾoto be-qerev ʾeḥaw*, and he anointed him in the midst of his brothers, at 16:13. The oil goes on the head and the corpus says so where it says anything.

**The officiant.** Always another. Chapter 63 counted seven anointings and seven officiants. The categories are: a prophet (Samuel for Saul and David, a prophet's servant for Jehu), a priest with a prophet (Zadok and Nathan for Solomon), a priest (Jehoiada for Joash), and a body of men (the men of Judah and the elders of Israel for David, twice more).

**The accompanying acts.** At 1 Samuel 10:1 Samuel kisses Saul and states the reason: *ha-loʾ ki meshaḥakha YHWH ʿal naḥalato le-nagid*, has not the LORD anointed you prince over his inheritance? Note the two possessives: the LORD anoints, and the people are *naḥalato*, his inheritance. At 1 Kings 1:39-40 the trumpet is blown and the people say *yeḥi ha-melekh Shelomoh*, long live king Solomon, with piping and rejoicing so that the earth split with the sound. At 2 Kings 11:12 Jehoiada brings out the king's son, puts the crown on him and gives him *ha-ʿedut*, the testimony, then they anoint him and clap and say long live the king.

That last detail repays attention. **Joash receives the crown and the testimony before the anointing.** *Ha-ʿedut* is most naturally a document, the covenant or law-book, and Deuteronomy 17:18's copying requirement stands behind it. The corpus's most fully described coronation puts a text into the king's hands as part of the installation.

**What the rite does not include.** No self-application anywhere. No acquisition of the oil by the anointed. No statement that the anointing confers anything the anointed then owns. And no instance of a king anointing his own successor: Solomon is anointed at David's instruction but by Zadok and Nathan, which is the closest the corpus comes and is not the thing itself.

Two structural results carry into the rest of Book VII.

**Anointing is applied, not assumed.** The whole vocabulary of the rite is one of application by an agent to a recipient.

**The rite is not exclusively royal**, and this matters for the census of Chapter 78. Priests are anointed. The tabernacle and its vessels are anointed. Elisha is to be anointed prophet. And a foreign king is to be anointed, which is the item that most resists tidy accounts.

## CHAPTER 65 · Aaron and the Priestly Anointing

The corpus's first anointing of a person is priestly, not royal, and it is worth having in view before the kings because it establishes the vocabulary the royal narratives inherit.

**Exodus 29:7.** *We-laqaḥta ʾet shemen ha-mishḥah we-yaṣaqta ʿal roʾsho u-mashaḥta ʾoto.* And you shall take the anointing oil and pour it on his head and anoint him. Addressed to Moses, concerning Aaron. The verbs are take, pour, anoint, in that order, and the same sequence appears at 1 Samuel 10:1 for Saul.

**Leviticus 8:12.** The execution. *Wa-yiṣoq mi-shemen ha-mishḥah ʿal roʾsh ʾAharon wa-yimshaḥ ʾoto le-qaddesho.* And he poured of the anointing oil on Aaron's head and anointed him to sanctify him. The purpose is stated: *le-qaddesho*, to sanctify him, which is a setting-apart rather than an empowering.

**Exodus 30:30 and Leviticus 8:30 extend it to the sons**, and Exodus 40:15 makes it perpetual: *we-haytah li-hyot lahem moshḥatam li-khehunnat ʿolam le-dorotam*, and their anointing shall be to them for a perpetual priesthood throughout their generations.

**And the objects are anointed too.** Exodus 40:9-11: the tabernacle and all in it, the altar of burnt offering and all its vessels, the laver and its base. Leviticus 8:10-11 executes it. The same verb, the same oil, applied to furniture.

Three consequences for the argument.

**The rite sanctifies rather than empowers.** The stated purpose at Leviticus 8:12 is *le-qaddesho*. Nothing in the priestly anointing texts says the oil confers ability, authority in itself, or status independent of the office it inducts into. It marks a transfer into a category.

**A rite applicable to furniture is not a rite that constitutes a personal quality.** This observation is sometimes taken as diminishing and it is not meant so. It is a fact about the semantics of the operation: whatever anointing does, the corpus does it to a laver. The anointed thing becomes the sanctuary's, and the anointed man becomes the sanctuary's, and in neither case does the anointing describe an intrinsic property.

**The priestly anointing is prior in the corpus's own order.** Exodus and Leviticus precede Samuel in the canonical arrangement and in every account of composition. When Samuel pours oil on Saul's head, the corpus has already established what that operation means, and it means induction by another into a service that is not one's own.

One further site closes the chapter and it is the one that keeps the priestly anointing from being merely background. **Leviticus 4:3, 4:5, 4:16, and 6:15 all use the phrase *ha-kohen ha-mashiaḥ*, the anointed priest.** Four occurrences of *mashiaḥ* as a title, in the Torah, all of them priestly, all of them before any king exists. Chapter 78's census has to reckon with that, and the tradition's later concentration of the term on a royal figure is a narrowing the corpus itself does not perform.

## CHAPTER 66 · Saul · The First and the Rejected

Saul is the corpus's first anointed king and the account of him is structured around receiving and losing.

**The anointing.** 1 Samuel 10:1. *Wa-yiqqaḥ Shemuʾel ʾet pakh ha-shemen wa-yiṣoq ʿal roʾsho wa-yishaqehu wa-yoʾmer, ha-loʾ ki meshaḥakha YHWH ʿal naḥalato le-nagid.* Samuel took the flask of oil and poured it on his head and kissed him and said: has not the LORD anointed you prince over his inheritance?

Three things in the sentence. The subject of the anointing is stated as YHWH even though the hand is Samuel's. The title is *nagid*, prince or designate, not *melekh*. And the people are *naḥalato*, his inheritance, with the possessive on God.

**The signs that follow are received rather than performed.** 10:5-6: you will meet a band of prophets, *we-ṣalḥah ʿaleykha ruaḥ YHWH we-hitnabbita ʿimmam we-nehpakhta le-ʾish ʾaḥer*, and the spirit of the LORD will rush upon you and you will prophesy with them and be turned into another man. The verbs describing Saul are all things that happen to him: the spirit rushes, he is turned. 10:9 confirms it: *wa-yahafokh lo ʾelohim lev ʾaḥer*, God turned him another heart.

**The public presentation is by lot and Saul is hiding.** 10:20-22. The lot falls on Benjamin, then on the family of Matri, then on Saul, and he cannot be found. They inquire of the LORD and the answer is *hinneh huʾ neḥbaʾ ʾel ha-kelim*, behold he is hidden among the baggage. They run and fetch him.

**The rejection is stated twice and in the same verb as 1 Samuel 8:7.** 15:23: *yaʿan maʾasta ʾet devar YHWH wa-yimʾaskha mi-melekh.* Because you have rejected the word of the LORD, he has rejected you from being king. And 15:26: *ki maʾastah ʾet devar YHWH wa-yimʾaskha YHWH mi-hyot melekh ʿal Yisraʾel.*

The verb *mʾs* on both sides. At 8:7 the people rejected God from reigning. At 15:23 Saul rejects the word and is rejected from reigning. The corpus uses one verb for both movements and constructs the second as an answer to the first.

**And the tearing.** 15:27-28. Saul seizes the skirt of Samuel's robe and it tears, and Samuel says *qaraʿ YHWH ʾet mamlekhut Yisraʾel me-ʿaleykha ha-yom u-netanah le-reʿakha ha-ṭov mimmekka.* The LORD has torn the kingdom of Israel from you today and given it to your neighbour who is better than you. Torn from, given to. Both verbs with God as subject.

**The spirit departs and another comes.** 16:14: *we-ruaḥ YHWH sarah me-ʿim Shaʾul u-viʿatattu ruaḥ raʿah me-ʾet YHWH.* The spirit of the LORD departed from Saul and an evil spirit from the LORD terrified him. The verse is theologically difficult and this book does not attempt it. What it records grammatically is a departure and an arrival, neither of them Saul's act.

**And yet the title holds after the rejection.** This is the fact that most complicates any tidy account and the corpus insists on it. David refuses twice to strike Saul, and both refusals are stated in the anointing vocabulary. 1 Samuel 24:7: *ḥalilah li me-YHWH ʾim ʾeʿeseh ʾet ha-davar ha-zeh la-ʾadoni li-meshiaḥ YHWH.* Far be it from me to do this thing to my lord, the anointed of the LORD. And 26:9: *ki mi shalaḥ yado bi-meshiaḥ YHWH we-niqqah.* Who can stretch out his hand against the LORD's anointed and be guiltless? And 26:11 and 26:23, and 2 Samuel 1:14 and 1:16, where David executes the Amalekite who claimed to have killed Saul, on that ground.

Seven occurrences of *meshiaḥ YHWH* applied to a king the corpus has already said was rejected. The title survives the rejection of the man, which is exactly the distinction 2 Samuel 7:15 will make in the other direction, and Chapter 74 counts it.

## CHAPTER 67 · David · Anointed Three Times

David is anointed three times in the corpus and the three are by different parties for different constituencies, which is a fact usually flattened into one event.

**First, by Samuel, privately, at Bethlehem.** 1 Samuel 16:13. *Wa-yiqqaḥ Shemuʾel ʾet qeren ha-shemen wa-yimshaḥ ʾoto be-qerev ʾeḥaw, wa-tiṣlaḥ ruaḥ YHWH ʾel Dawid me-ha-yom ha-huʾ wa-maʿlah.* Samuel took the horn of oil and anointed him in the midst of his brothers, and the spirit of the LORD rushed upon David from that day forward.

The setting is a domestic sacrifice, the audience is his family, and the narrative has spent the preceding six verses on the rejection of his seven brothers, with 16:7's *ki ha-ʾadam yirʾeh la-ʿeynayim wa-YHWH yirʾeh la-levav*, man looks at the eyes and the LORD looks at the heart. The organ of Book IV appears here as the divine faculty of selection.

**Second, by the men of Judah, at Hebron.** 2 Samuel 2:4. *Wa-yavoʾu ʾanshey Yehudah wa-yimshehu sham ʾet Dawid le-melekh ʿal beyt Yehudah.* The men of Judah came and anointed David there king over the house of Judah. Seven years and six months, over one tribe.

**Third, by the elders of all Israel, at Hebron.** 2 Samuel 5:3. *Wa-yavoʾu kol ziqney Yisraʾel ʾel ha-melekh Ḥevronah wa-yikhrot lahem ha-melekh Dawid berit be-Ḥevron lifney YHWH, wa-yimshehu ʾet Dawid le-melekh ʿal Yisraʾel.* The elders came, the king made a covenant with them before the LORD, and they anointed David king over Israel.

**Three observations on the three.**

**Two of the three are performed by bodies of men, not by a prophet.** The tribal and national anointings are corporate acts, and the third involves a covenant cut between the king and the elders. That is a constitutional arrangement and the corpus records it without comment.

**The first is prophetic and the spirit follows it.** *Wa-tiṣlaḥ ruaḥ YHWH ʾel Dawid.* The same verb *ṣlḥ* as at Saul's 10:6 and 10:10. Whatever the corpus takes the anointing to accomplish, it associates the spirit's arrival with the prophetic one and not with the corporate ones.

**And the corpus states the reason for the northern accession in the vocabulary of Book VI.** 2 Samuel 5:2, the elders speaking: *wa-yoʾmer YHWH lekha ʾattah tirʿeh ʾet ʿammi ʾet Yisraʾel we-ʾattah tihyeh le-nagid ʿal Yisraʾel.* The LORD said to you: you shall shepherd my people Israel, and you shall be *nagid* over Israel.

*ʿAmmi*, my people, with the possessive on God, in the mouth of the men who are about to make David king. And the title in the divine speech is *nagid* rather than *melekh*, though the anointing in the next verse is *le-melekh*. The corpus places the two titles one verse apart with the higher one in the human act and the lower one in the divine speech.

**Psalm 23 belongs here.** *YHWH roʿi loʾ ʾeḥsar.* The LORD is my shepherd, I shall not want. The superscription attributes it to David; the corpus makes the king a sheep in the psalm the tradition most closely associates with him. And 2 Samuel 5:2 has appointed the same man shepherd over God's flock. Both statements stand and Book X counts the pair.

**One further site, and it is the one that shows the corpus applying its own standard to David.** 2 Samuel 12:7-9, Nathan's indictment. *ʾAnokhi meshaḥtikha le-melekh ʿal Yisraʾel we-ʾanokhi hiṣṣaltikha mi-yad Shaʾul, wa-ʾettenah lekha ʾet beyt ʾadoneykha we-ʾet neshey ʾadoneykha be-ḥeyqekha wa-ʾettenah lekha ʾet beyt Yisraʾel wi-Yhudah, we-ʾim meʿaṭ we-ʾosifah lekha ka-hennah we-kha-hennah.*

I anointed you king over Israel and I delivered you from the hand of Saul, and I gave you your master's house and your master's wives into your bosom and I gave you the house of Israel and Judah, and if that were too little I would have added to you this and that.

Five first-person verbs of giving in one sentence, listing everything the king holds. And then the charge at 12:9: *maddua baziita ʾet devar YHWH la-ʿasot ha-raʿ be-ʿeynay*, why have you despised the word of the LORD to do evil in my sight. The indictment is constructed as an inventory of gifts followed by the charge, which is the form of a suzerain's lawsuit against a vassal.

## CHAPTER 68 · Solomon · The Man of Rest Who Was Not

Solomon is the only figure in the corpus named for the terminus and the corpus records both the naming and the end.

**The designation.** 1 Chronicles 22:9, worked at Chapter 27. A man of rest, God giving him rest, the name explaining it, peace and quiet to Israel in his days.

**The anointing.** 1 Kings 1:39. Zadok takes the horn of oil from the tent and anoints him; the trumpet is blown; the people say long live king Solomon. The setting is a coup countered: Adonijah has already declared himself at En-rogel with Joab and Abiathar, and Solomon's accession is engineered by Nathan and Bathsheba while David is old and cold in his bed. The corpus's most exalted king is installed in a palace intrigue and the corpus narrates it in detail.

**The seating, in the Chronicler's terms.** 1 Chronicles 29:23, worked at Chapter 53. He sat on the throne of the LORD.

**The request.** 1 Kings 3:5-12. At Gibeon God appears in a dream: ask what I shall give you. Solomon's answer is 3:7-9: *ʾanokhi naʿar qaṭon loʾ ʾedaʿ ṣeʾt wa-voʾ*, I am a little child, I do not know how to go out or come in, and the request is *lev shomeaʿ li-shpoṭ ʾet ʿammekha*, a hearing heart to judge your people.

Two of Book IV's three organs in one phrase, requested rather than possessed. And *ʿammekha*, your people, with the possessive again on God, in the king's own mouth.

**The announcement of the terminus.** 1 Kings 8:56, worked at Chapter 25. Blessed be the LORD who has given rest to his people Israel, spoken at the dedication, with the giver named and the recipient the people.

**The apostasy.** 1 Kings 11:1-8. *We-ha-melekh Shelomoh ʾahav nashim nokhriyyot rabbot*, and king Solomon loved many foreign women, and the list runs Moabite, Ammonite, Edomite, Sidonian, Hittite. 11:2 quotes the prohibition at the point of the breach and Chapter 99 works that. 11:3: seven hundred wives, princesses, and three hundred concubines, *wa-yaṭṭu nashaw ʾet libbo*, and his wives turned away his heart. 11:4: *we-lo hayah levavo shalem ʿim YHWH ʾelohaw ki-levav Dawid ʾaviv*, his heart was not whole with the LORD his God as the heart of David his father.

The heart, four times in four verses.

**The judgment.** 11:11: *yaʿan ʾasher haytah zoʾt ʿimmakh we-loʾ shamarta beriti we-ḥuqqotay ʾasher ṣiwwiti ʿaleykha, qaroaʿ ʾeqraʿ ʾet ha-mamlakhah me-ʿaleykha u-netattiha le-ʿavdekha.* Because this is with you and you have not kept my covenant and my statutes, I will surely tear the kingdom from you and give it to your servant.

*Qaroaʿ ʾeqraʿ ... u-netattiha.* Tear and give. The same pair of verbs as Samuel's words to Saul at 1 Samuel 15:28, in the same order, with the same divine subject. The corpus uses one formula for the loss of the kingdom at both ends of the united monarchy.

**And the mitigation preserves the grant while removing the occupant's holding.** 11:12-13: not in your days, for David your father's sake; and not the whole, one tribe for David's sake and for Jerusalem's. The grant of 2 Samuel 7 holds and the kingdom divides.

The structural point for this book. **The corpus names a man for the terminus, states that God gives it to him, has him announce it in the temple, and then records that he did not remain in it.** The three statements are not in tension if the terminus is a state, since a state can be occupied and departed. They are in flat contradiction if it is a possession. Chapter 36's mechanism, the heart lifted and the forgetting, is the corpus's own account of how the departure happens, and 1 Kings 11:4's *loʾ hayah levavo shalem* is its application to this man.

Deuteronomy 17:17's prohibition, *we-loʾ yarbeh lo nashim we-loʾ yasur levavo*, he shall not multiply wives lest his heart turn aside, is quoted almost verbatim by 1 Kings 11:2-4's account of what happened. The law of the king named the mechanism and the narrative executes it on the corpus's greatest king.

## CHAPTER 69 · Jehu · The Anointing That Kills

Jehu is anointed and the anointing is a commission to slaughter. The episode is the corpus's most disturbing use of the rite and it belongs in any honest census.

**The commission.** 2 Kings 9:1-3. Elisha calls one of the sons of the prophets, gives him *pakh ha-shemen ha-zeh*, this flask of oil, and sends him to Ramoth-gilead. Find Jehu, take him into an inner chamber, pour the oil on his head and say: *koh ʾamar YHWH meshaḥtikha le-melekh ʾel Yisraʾel*, thus says the LORD, I have anointed you king over Israel. Then open the door and flee, and do not wait.

**The execution and the expanded charge.** 9:6-10. The young man pours the oil and delivers a longer speech than he was given: *we-hikkitah ʾet beyt ʾAḥʾav ʾadoneykha we-niqqamti demey ʿavaday ha-neviʾim*, and you shall strike the house of Ahab your master, and I will avenge the blood of my servants the prophets. Jezebel is named: dogs shall eat her in the portion of Jezreel and none shall bury her.

**And then he flees**, as instructed, and Jehu's fellow officers ask *maddua baʾ ha-meshuggaʿ ha-zeh ʾeleykha*, why did this madman come to you.

**The slaughter.** Joram shot through the heart between the arms and thrown into Naboth's field, with the corpus recalling Naboth by name at 9:25-26. Ahaziah of Judah pursued and killed. Jezebel thrown from a window, trampled by horses, and eaten by dogs. The seventy sons of Ahab beheaded, their heads sent in baskets and piled in two heaps at the gate of Jezreel. Forty-two kinsmen of Ahaziah killed at the pit of the shearing house. The worshippers of Baal gathered into the temple by a ruse, counted, and killed to a man.

**And the corpus's verdict is double.** 2 Kings 10:30: *wa-yoʾmer YHWH ʾel Yehuʾ, yaʿan ʾasher heṭivota la-ʿasot ha-yashar be-ʿeynay ke-khol ʾasher bi-levavi ʿasita le-veyt ʾAḥʾav, benei reviʿim yeshevu lekha ʿal kisseʾ Yisraʾel.* Because you have done well in doing what is right in my eyes, sons of the fourth generation shall sit on the throne of Israel for you. A four-generation dynastic grant, awarded for the killing.

And 10:31: *we-Yehuʾ loʾ shamar la-lekhet be-torat YHWH ʾelohey Yisraʾel be-khol levavo, loʾ sar me-ʿal ḥaṭṭoʾt Yarovʿam.* But Jehu did not take heed to walk in the law of the LORD with all his heart; he did not depart from the sins of Jeroboam.

Approval for the act and condemnation for the reign, in two consecutive verses.

**And then Hosea 1:4**, generations later: *u-faqadti ʾet demey Yizreʿel ʿal beyt Yehuʾ*, I will visit the blood of Jezreel upon the house of Jehu. The corpus condemns the bloodshed it had commissioned, in a different book, without reconciling the two.

Book X counts this among its retained pairs. What Book VII takes from it is narrower and it is three things.

**The anointing is a sending.** The oil is poured and a commission is delivered in the same act, and the commission is entirely a set of instructions.

**The officiant is the least of the parties.** Not Elisha but *ʾaḥad mi-benei ha-neviʾim*, one of the sons of the prophets, a man whose name the corpus does not give and whom Jehu's colleagues call a madman. The rite does not require rank in the one performing it.

**And the dynastic grant is given for performance, uniquely.** Every other conferral in Book VI is unmotivated in the text or grounded in divine choice. Jehu's four generations are stated as payment, *yaʿan ʾasher heṭivota*, because you have done well. That is the single clearest exception to the pattern of unearned conferral in the corpus, and an honest census reports it rather than passing over it.

## CHAPTER 70 · Hazael · An Anointing Outside Israel

*U-mashaḥta ʾet Ḥazaʾel le-melekh ʿal ʾAram.* And you shall anoint Hazael king over Aram.

1 Kings 19:15. It is one clause in a three-clause commission and it is the strangest item in the whole anointing field.

**The setting.** Elijah at Horeb after the flight from Jezebel, in the cave, after the wind and the earthquake and the fire and the *qol demamah daqqah*. He states his complaint twice, identically, and receives a threefold commission at 19:15-16.

*Lekh shuv le-darkekha midbarah Dammaseq, u-vaʾta u-mashaḥta ʾet Ḥazaʾel le-melekh ʿal ʾAram. We-ʾet Yehuʾ ben Nimshi timshaḥ le-melekh ʿal Yisraʾel, we-ʾet ʾElishaʿ ben Shafaṭ mi-ʾAvel Meḥolah timshaḥ le-naviʾ taḥteykha.*

Go, return on your way to the wilderness of Damascus; and when you come, anoint Hazael king over Aram. And Jehu son of Nimshi you shall anoint king over Israel, and Elisha son of Shaphat of Abel-meholah you shall anoint prophet in your place.

**Three anointings in two verses, and they are of three different kinds.** A foreign king. An Israelite usurper. A prophet.

Each is worth a sentence.

**Hazael is king of Aram, Israel's enemy, and the corpus is explicit about what he will do.** 2 Kings 8:12, Elisha weeping before him: *ki yadaʿti ʾet ʾasher taʿaseh li-vney Yisraʾel raʿah, mivṣereyhem teshallaḥ ba-ʾesh u-vaḥureyhem ba-ḥerev taharog we-ʿolaleyhem teraṭṭesh we-haroteyhem tevaqqeaʿ.* Because I know the evil you will do to the children of Israel: their strongholds you will set on fire, their young men you will kill with the sword, their infants you will dash in pieces, and their pregnant women you will rip open.

And Hazael's reply at 8:13 and Elisha's answer: *hiraʾani YHWH ʾotekha melekh ʿal ʾAram*, the LORD has shown me that you will be king over Aram.

**Jehu's anointing is executed by a proxy**, as Chapter 69 described, and not by Elijah.

**Elisha's anointing is prophetic and its execution is a mantle.** 19:19: Elijah passes by and casts his cloak on him. The corpus does not record oil for Elisha, which is a divergence between the instruction and the narration that this book notes and does not resolve.

**Two of the three commissions are not executed by the man commissioned.** Elijah anoints neither Hazael nor Jehu in the narrative; Elisha's word to Hazael at 2 Kings 8 and Elisha's servant's act at 2 Kings 9 do the work. That is a well-known feature of the Elijah-Elisha material and this book takes no position on it.

**What the Hazael clause establishes for the census.** The anointing verb, applied by divine instruction, to a foreign king, over a foreign nation, whose stated function is to devastate Israel. Whatever *mšḥ* means in this corpus, it does not mean membership in Israel, it does not mean piety, and it does not mean benefit to Israel.

That is a hard fact and it constrains every account of the vocabulary, including the one this book is giving. The most it will support is the conclusion Chapter 63 drew from the morphology: the term records that something was applied to the bearer by another. It supports nothing about the bearer's character, allegiance, or destiny. Chapter 71 finds the same conclusion forced by a second foreign figure, in a different book, with the title itself.

## CHAPTER 71 · Cyrus · Meshiaḥ at Isaiah 45:1

*Koh ʾamar YHWH li-meshiḥo le-Khoresh ʾasher heḥezaqti vi-mino le-rad le-fanaw goyim u-motney melakhim ʾafatteaḥ, li-ftoaḥ le-fanaw delatayim u-sheʿarim loʾ yissageru.*

Thus says the LORD to his anointed, to Cyrus, whose right hand I have held, to subdue nations before him and to loose the loins of kings, to open before him the two-leaved gates, and the gates shall not be shut.

**The title is applied to a Persian.** *Li-meshiḥo*, to his anointed, with the possessive on God, and the referent named immediately: *le-Khoresh*. This is the only occurrence in the Hebrew Bible of *mashiaḥ* applied to a non-Israelite ruler, and it is applied with the divine possessive.

**The passage is saturated with conferral verbs and every one has God as subject.**

45:1: *heḥezaqti vi-mino*, whose right hand I have held.
45:1: *le-rad le-fanaw goyim*, to subdue nations before him.
45:1: *u-motney melakhim ʾafatteaḥ*, I will loose the loins of kings.
45:2: *ʾani le-faneykha ʾelekh*, I will go before you.
45:2: *wa-hadurim ʾayasher*, and I will level the rough places.
45:2: *daltot neḥushah ʾashabber*, I will break in pieces the doors of bronze.
45:3: *we-natatti lekha ʾoṣrot ḥoshekh*, I will give you the treasures of darkness.

Seven first-person divine verbs in three verses, describing what Cyrus will hold.

**And the reason is stated, twice, and it is not Cyrus.** 45:4: *le-maʿan ʿavdi Yaʿaqov we-Yisraʾel beḥiri, wa-ʾeqraʾ lekha bi-shmekha ʾakhannekha we-loʾ yedaʿtani.* For the sake of my servant Jacob and Israel my chosen, I have called you by your name, I have surnamed you, though you have not known me. And 45:5: *ʾaʾazzerkha we-loʾ yedaʿtani*, I gird you though you have not known me.

*We-loʾ yedaʿtani*, twice. The anointed of the LORD does not know the LORD, and the corpus says so twice in two verses.

**The purpose is stated at 45:6.** *Le-maʿan yedʿu mi-mizraḥ shemesh u-mi-maʿaravah ki ʾefes bilʿaday, ʾani YHWH we-ʾeyn ʿod.* That they may know from the rising of the sun and from the west that there is none besides me; I am the LORD and there is no other.

**Four consequences for the census and for the argument.**

**The title does not require knowledge of the giver.** Stated explicitly, twice.

**The title does not require Israelite identity.** Cyrus is a Persian and the corpus names him.

**The title does not carry an eschatological content in itself.** Isaiah 45 is about a specific historical policy: the return from Babylon and the rebuilding, which 44:28 states in advance, *ha-ʾomer le-Khoresh roʿi we-khol ḥefṣi yashlim, we-le-ʾmor li-Yrushalayim tibbaneh we-heykhal tiwwased*, saying of Cyrus he is my shepherd and shall perform all my pleasure, saying of Jerusalem she shall be built and of the temple your foundation shall be laid.

*Roʿi*, my shepherd, applied to Cyrus at 44:28. Both of the corpus's principal royal metaphors, anointed and shepherd, applied to a foreign king in two adjacent verses.

**And the conferral grammar holds at its purest here.** A man who does not know God is given a right hand held, nations subdued, kings loosed, gates opened, doors broken, and treasures given, and the reason given is somebody else's benefit, and the purpose given is a knowledge that others will have.

This chapter complicates the argument and the complication is left standing. A tidy account of the corpus's messianic vocabulary would prefer Cyrus not to be there. He is there, in the corpus's most exalted prophetic material, holding the title with the divine possessive on it. Any account of *mashiaḥ* has to accommodate him, and the only account that does is the minimal one: the word says something was applied by another, and it says nothing else on its own.

## CHAPTER 72 · The Anointed Who Are Not Kings

Chapter 63 noted that the rite is not exclusively royal. This chapter sets out the non-royal field, because the tradition's concentration of *mashiaḥ* on a royal eschatological figure is a narrowing the corpus itself does not perform.

**The anointed priest.** *Ha-kohen ha-mashiaḥ* at Leviticus 4:3, 4:5, 4:16, and 6:15. Four occurrences of the noun as a title, all priestly, all in the Torah. In each case the context is the sin offering: if the anointed priest sins, bringing guilt on the people, he shall bring a bull. The title marks the officiant whose sin has corporate effect.

**The priesthood generally.** Exodus 29:7, Leviticus 8:12 for Aaron; Exodus 30:30 and Leviticus 8:30 for his sons; Exodus 40:15 for the perpetual grant. Numbers 3:3 calls Aaron's sons *ha-kohanim ha-meshuḥim ʾasher milleʾ yadam le-khahen*, the anointed priests whose hand was filled to serve.

**The prophet.** 1 Kings 19:16, Elisha to be anointed *le-naviʾ taḥteykha*, prophet in your place. And Isaiah 61:1: *ruaḥ ʾAdonay YHWH ʿalay yaʿan mashaḥ YHWH ʾoti le-vasser ʿanawim*, the spirit of the Lord GOD is upon me because the LORD has anointed me to bring good news to the poor. The verb here is *mšḥ* and the commission that follows is a set of announcements: liberty to captives, opening to the bound, the year of the LORD's favour, comfort to mourners.

**The patriarchs, in a psalm.** Psalm 105:15, repeated at 1 Chronicles 16:22: *ʾal tigʿu vi-meshiḥay we-li-neviʾay ʾal tareʿu.* Touch not my anointed ones, and do my prophets no harm. The plural, applied to Abraham, Isaac, and Jacob in their wanderings, in a psalm whose preceding verses have them as few in number and sojourners.

That plural is significant and it is often overlooked. **The corpus uses *meshiḥay* in the plural of the patriarchs**, none of whom held any office, none of whom was anointed with oil in any narrative, and none of whom was a king. The term is being used of persons under divine protection.

**The objects.** Exodus 40:9-11 and Leviticus 8:10-11: the tabernacle, its furniture, the altar and its vessels, the laver and its base. Numbers 7:1 records the anointing and sanctifying of the tabernacle, its furniture, the altar, and all its vessels at the completion of the setting up.

**Even a stone.** Genesis 28:18, Jacob at Bethel: *wa-yiqqaḥ ʾet ha-ʾeven ʾasher sam meraʾashotaw wa-yasem ʾotah maṣṣevah wa-yiṣoq shemen ʿal roʾshah.* He took the stone he had put under his head and set it up as a pillar and poured oil on its top. The verb here is *yṣq*, poured, the same verb as at 1 Samuel 10:1, and the phrase *ʿal roʾshah*, on its top or head, is the same as *ʿal roʾsho* for Saul.

**The distribution, summarized.** Kings, priests, at least one prophet by instruction and one by claim, the patriarchs in the plural, the sanctuary and everything in it, and a stone. That is the corpus's field.

Two consequences.

**A term with that distribution cannot carry a technical eschatological sense in the Hebrew Bible.** The later tradition's usage is a development and this book takes no position on whether it is a legitimate one. What it records is that the corpus's own usage is wide, physical, and not restricted to a coming figure.

**And the one thing every member of the field shares is the passive.** A stone does not anoint itself. Neither does a laver, a priest, a prophet, or a king.

## CHAPTER 73 · The Kings Who Are Not Anointed

The complement is as informative as the field. Most of Israel's and Judah's kings are never said to be anointed, and the corpus's silences have a pattern.

**Explicitly anointed in the narrative books.** Saul at 1 Samuel 10:1. David at 1 Samuel 16:13, 2 Samuel 2:4, and 2 Samuel 5:3. Absalom, in a report at 2 Samuel 19:11, *wa-ʾAvshalom ʾasher mashaḥnu ʿaleynu met ba-milḥamah*, and Absalom whom we anointed over us is dead in battle. Solomon at 1 Kings 1:39. Jehu at 2 Kings 9:6. Joash at 2 Kings 11:12. Jehoahaz at 2 Kings 23:30, *wa-yimshehu ʾoto wa-yamlikhu ʾoto taḥat ʾaviw*. And Hazael by instruction at 1 Kings 19:15.

**That is the list.** Seven Israelite or Judahite figures across two books covering roughly four centuries and some forty reigns.

Three observations on the pattern.

**Anointing is narrated at discontinuities.** Saul is the first king. David succeeds a rejected house. Absalom usurps. Solomon accedes against a rival claimant. Jehu overthrows a dynasty. Joash is restored after Athaliah. Jehoahaz is chosen by the people of the land over an elder brother, which 2 Kings 23:31 and 23:36 make clear by the ages given. Every anointing in the historical books is at a break in the ordinary succession.

**Ordinary successions are not narrated as anointings.** Rehoboam, Abijah, Asa, Jehoshaphat, Jehoram, Amaziah, Uzziah, Jotham, Ahaz, Hezekiah, Manasseh, Amon, Josiah: the formula is *wa-yimlokh X beno taḥtaw*, and X his son reigned in his place. The corpus is not saying they were not anointed. It is saying that when the succession is uncontested the corpus does not mention it.

**The northern kings are almost entirely unanointed in the text.** Jehu is the exception. Jeroboam receives a torn garment from Ahijah at 1 Kings 11:29-31 with ten pieces, and a dynastic promise at 11:38, but no oil. Baasha, Zimri, Omri, Ahab, and the rest accede by killing or by descent and the corpus records no rite.

**The consequence for the census.** The relation between the anointing rite and the office of king is looser in the corpus than the tradition's usage implies. Anointing is a legitimation performed where legitimation is in question. That is a functional account and it fits every case in the list, including Hazael, whose legitimation was in question in the strongest possible way since he acquired the throne by smothering his predecessor with a wet cloth at 2 Kings 8:15.

One caution. **An argument from silence is weak and this one is offered at that weight.** The corpus's failure to mention anointings at ordinary successions is compatible with their having occurred routinely and not being newsworthy, which is probably the historical truth. The observation is about the corpus's narration, not about the practice.

## CHAPTER 74 · The Census of Meshiaḥ · Every Occurrence, Sorted

The noun *mashiaḥ* occurs thirty-nine times in the Hebrew Bible. This chapter sorts them, and the sort is the point.

**Applied to Saul: fifteen occurrences**, all in 1 and 2 Samuel, and the great majority in David's mouth refusing to strike him. 1 Samuel 12:3 and 12:5, Samuel calling on the LORD and his anointed as witnesses to his own accounting. 1 Samuel 24:7 twice, 24:11, 26:9, 26:11, 26:16, 26:23. 2 Samuel 1:14, 1:16. And the group at 2 Samuel 19:22 and 23:1.

**Applied to David or the Davidic king: a substantial group**, including 1 Samuel 16:6, where Samuel sees Eliab and says *ʾakh neged YHWH meshiḥo*, surely the LORD's anointed is before him, and is wrong. 2 Samuel 22:51 and its parallel Psalm 18:51: *ʿoseh ḥesed li-meshiḥo le-Dawid u-le-zarʿo ʿad ʿolam*. Psalm 20:7, Psalm 28:8, Psalm 84:10, Psalm 89:39 and 89:52, Psalm 132:10 and 132:17, Lamentations 4:20, Habakkuk 3:13, 2 Chronicles 6:42.

**Applied to the priest: four**, at Leviticus 4:3, 4:5, 4:16, and 6:15.

**Applied to the patriarchs: two**, Psalm 105:15 and 1 Chronicles 16:22, both plural.

**Applied to Cyrus: one**, Isaiah 45:1.

**Applied to a figure in Daniel: two**, at Daniel 9:25 and 9:26, in a passage whose interpretation is contested at every level and which this book does not enter.

**Applied to the king generally, in the Psalms of lament and in Habakkuk**, where the referent is the reigning king in distress.

Four results from the sort, and each is checkable against a concordance.

**The largest single group is Saul, and Saul is the rejected king.** Fifteen of thirty-nine, and they cluster in narratives about refusing to harm him after his rejection. The corpus's densest use of its central royal title is in service of an argument that a rejected king may not be struck.

**Several occurrences are in laments over the title's failure.** Psalm 89:39: *ʾakh zanaḥta wa-timʾas, hitʿabbarta ʿim meshiḥekha*, but you have cast off and rejected, you have been wroth with your anointed. Psalm 89:52: the enemies reproach the footsteps of your anointed. Lamentations 4:20: *ruaḥ ʾappeynu meshiaḥ YHWH nilkad bi-shḥitotam*, the breath of our nostrils, the anointed of the LORD, was taken in their pits. The title appears at the moments of its greatest failure and the corpus does not withdraw it.

**No occurrence in the Hebrew Bible unambiguously designates a future eschatological deliverer.** That is a strong claim and it is stated with the two qualifications it requires. The Daniel 9 occurrences are contested and could bear such a reading on some interpretations. And the royal psalms have been read eschatologically by many communities for a long time, on grounds this book does not adjudicate. What can be said from the sort is that in every case where the referent is determinable from the immediate context, it is a historical person: Saul, David, a Davidic king, a priest, a patriarch, or Cyrus.

**And every occurrence is a passive participle.** Thirty-nine for thirty-nine. There is no cognate active noun in the corpus for the figure and none was ever formed.

The census's finding, stated once. **The corpus's central royal title names a passive condition, is applied to a rejected king more often than to any other referent, appears in laments over its own failure, is extended to priests and patriarchs and a Persian, and never once in a determinable context designates a coming deliverer.** That is a description of the vocabulary and it is not an argument against anyone's expectation. What it is is the base against which Book VIII's escalation has to be read.
