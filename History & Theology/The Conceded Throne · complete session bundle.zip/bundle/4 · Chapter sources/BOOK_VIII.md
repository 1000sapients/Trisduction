# BOOK VIII · THE ESCALATION

## CHAPTER 75 · The Sequence, and What Ordering It by Content Means

Eight stages are present in the corpus. This chapter states them, states how they are ordered, and states what the ordering is not.

**The eight.**

One, refusal. Judges 8:23.
Two, concession. 1 Samuel 8.
Three, permanence, with withdrawal barred. 2 Samuel 7:12-16, with 7:15.
Four, cosmic vocabulary. Psalm 2:7, Psalm 45:7, Psalm 110:1.
Five, the throne-name. Isaiah 9:5.
Six, regrowth after felling. Isaiah 11:1, from a *gezaʿ*.
Seven, the split into two. Zechariah 4:14, 6:13.
Eight, celestial conferral. Daniel 7:13-14.

**The ordering is by content.** Each stage answers the failure of the one beneath it, in the sense that its additional content is the kind of content that would address the preceding stage's deficiency. Refusal is answered by concession. A concession that can be regretted is answered by permanence. A permanence held by ordinary men is answered by cosmic vocabulary. Cosmic vocabulary attached to a failing dynasty is answered by a throne-name. A throne-name on a felled house is answered by regrowth from the stump. A single office that failed is answered by a split into two. And two offices in a demolished polity are answered by conferral from a court that is not on earth.

**No compositional dating is claimed for it.** This is the disclaimer of Chapter 8 restated at the point where it matters most. The first three stages stand in narrative sequence in the corpus itself: Judges precedes Samuel, and 1 Samuel 8 precedes 2 Samuel 7, on any account. The remaining five are ordered logically and the canonical arrangement is not the compositional order. Isaiah 9 and Isaiah 11 are dated variously across the literature. Zechariah 4 and 6 are securely post-exilic. Daniel 7 is dated by most scholarship to the second century and by some traditions to the sixth. Psalm 2, Psalm 45, and Psalm 110 are contested across a range of several centuries.

A reader who takes the sequence as a chronology has taken more than is offered. The sequence is an argument about content and it would hold if the material were composed in the reverse order.

**What the ordering does establish, if the content-relations hold.** Two things.

**The direction is monotonic.** At no point does a later stage contain less than an earlier one. The figure does not shrink. There is no stage at which the corpus scales back the claim, qualifies the permanence, or replaces a large figure with a small one.

**And the deficit does not move.** This is the finding the sequence exists to display and it is the reason the eight stages are set out at all. Book IV established that the corpus locates the failure at the receiver, in the same three organs, in five texts across three books. Those five texts are distributed across the whole span of the escalation: Deuteronomy 29:3 stands before stage one, Isaiah 6:9-10 stands between stages four and five in canonical position, Jeremiah 6:16 stands with stage six or after it, and Psalm 95:11 is undatable. At no point does the corpus report the deficit shrinking, being addressed, or being met.

**A figure rising against a deficit that does not move.** That is the structure and the rest of Book VIII sets it out stage by stage.

## CHAPTER 76 · Stages One to Three · Refusal, Concession, Permanence

The first three stages are the ones the corpus itself sequences, and Book V has worked two of them. This chapter takes the third and states the relation of the three.

**Stage one, refusal.** Judges 8:23. Gideon declines a dynastic offer and grounds the refusal in a claim that the office is occupied. Chapter 42.

**Stage two, concession.** 1 Samuel 8. The demand, the diagnosis, the itemized bill, the exclusion clause, the refusal to hear, the grant. Chapters 44 to 48.

**Stage three, permanence.** 2 Samuel 7:12-16.

*Ki yimleʾu yameykha we-shakhavta ʾet ʾavoteykha, wa-haqimoti ʾet zarʿakha ʾaḥareykha ʾasher yeṣeʾ mi-meʿeykha, wa-hakhinoti ʾet mamlakhto. Huʾ yivneh bayit li-shmi, we-khonanti ʾet kisseʾ mamlakhto ʿad ʿolam.*

When your days are fulfilled and you lie down with your fathers, I will raise up your seed after you who shall come from your body, and I will establish his kingdom. He shall build a house for my name, and I will establish the throne of his kingdom forever.

And 7:16: *we-neʾman beytekha u-mamlakhtekha ʿad ʿolam le-faneykha, kisʾakha yihyeh nakhon ʿad ʿolam.* Your house and your kingdom shall be established forever before you; your throne shall be established forever.

**The escalation between stage two and stage three is total and it is worth measuring.** At 1 Samuel 8 the monarchy is granted under an itemized prosecution with a clause excluding the standard remedy. At 2 Samuel 7 the same institution, in the same books, four chapters and one dynasty later, is made unrevokable forever with the withdrawal barred by name against a precedent.

Nothing in the intervening narrative retracts 1 Samuel 8. Nothing in 2 Samuel 7 acknowledges it. The corpus places the itemized bill and the everlasting grant in one work and does not reconcile them, which is Book X's subject and one of its ten pairs.

**Four verbs of establishment, all with God as subject.** *Wa-haqimoti*, I will raise up. *Wa-hakhinoti*, I will establish. *We-khonanti*, I will establish. And at 7:16 the passives *we-neʾman* and *nakhon*. Five conferral forms in five verses, which Chapter 62 counted.

**The permanence is stated four times in five verses.** *ʿAd ʿolam* at 7:13, at 7:16 twice, and the sense again at 7:15's *loʾ yasur*. The corpus is not stating this once.

**And the discipline clause sits inside it**, at 7:14, which Chapter 59 worked. The permanence is of the grant and the discipline is of the occupant, and one sentence holds both.

**The structural observation for Book VIII.** Stage three does not address anything stage two identified as a problem. 1 Samuel 8 identified a rejection of divine reign, an itemized cost, and a coming outcry that would go unanswered. 2 Samuel 7 makes the granted institution permanent. That is an escalation in magnitude and it is not a response to the stated defect.

A reader may object that stage three is a promise to a particular house and not a general statement about monarchy, and that is correct. It is nonetheless an escalation of the institution's standing: what was conceded under protest to a people is now covenanted forever to a line.

**And Psalm 89 is the corpus's own record of what happened to stage three.** 89:4-5 restates the covenant: *karatti verit li-vḥiri nishbaʿti le-Dawid ʿavdi, ʿad ʿolam ʾakhin zarʿekha u-vaniti le-dor wa-dor kisʾakha.* And 89:20-38 elaborate it at length, with 89:35-36's *loʾ ʾaḥallel beriti u-moṣaʾ sefatay loʾ ʾashanneh, ʾaḥat nishbaʿti ve-qodshi ʾim le-Dawid ʾakhazzev*, I will not profane my covenant nor alter what has gone out of my lips; once I have sworn by my holiness, I will not lie to David.

And then 89:39-46. *ʾAkh zanaḥta wa-timʾas, hitʿabbarta ʿim meshiḥekha. Neʾartah berit ʿavdekha, ḥillalta la-ʾareṣ nizro.* But you have cast off and rejected, you have been wroth with your anointed. You have renounced the covenant of your servant, you have profaned his crown to the ground.

The psalm states the everlasting covenant at maximum strength and then states, in the same psalm, that it has been renounced. And it closes at 89:47-52 with *ʿad mah YHWH tissater la-neṣaḥ*, how long, LORD, will you hide yourself forever, and *ʾayyeh ḥasadeykha ha-rishonim ʾAdonay nishbaʿta le-Dawid be-ʾemunatekha*, where are your former mercies, Lord, which you swore to David.

The corpus preserves the promise and the complaint that it failed, in one composition, unresolved. That is the datum stage four inherits.

## CHAPTER 77 · Stage Four · Cosmic Vocabulary in the Royal Psalms

Three psalms carry the fourth stage and each takes the king's language a register higher than the historical books ever do.

**Psalm 2:7.** *Beni ʾattah ʾani ha-yom yelidtikha.* Chapter 60 worked it. Sonship, declared, dated.

**Psalm 110:1.** *Shev li-mini.* Chapter 55 worked it. A seat at the right hand of God.

**Psalm 45:7.** *Kisʾakha ʾelohim ʿolam wa-ʿed, sheveṭ mishor sheveṭ malkhutekha.*

This is the escalation at its sharpest and the verse requires care, because its translation is genuinely contested and the argument must not rest on the contested part.

**The problem.** *Kisʾakha ʾelohim ʿolam wa-ʿed* can be read at least three ways. Your throne, O God, is forever and ever, with *ʾelohim* vocative, addressing the king as *ʾelohim*. Your throne is God, forever and ever, with *ʾelohim* predicative. Your divine throne is forever, taking *ʾelohim* as a genitive of quality. Each has defenders and each has difficulties.

**What is not contested.** The psalm is a royal wedding song. Its superscription is *shir yedidot*, a song of loves, and its content is a marriage: the king's beauty, his sword, his majesty, his ivory palaces, the daughter of Tyre with a gift, the princess in gold of Ophir, the virgins in her train, and the sons who will be princes in all the earth. Whatever *ʾelohim* is doing at verse 7, it is doing it in a wedding poem addressed to a reigning king.

**And what is not contested is the next verse.** 45:8: *ʾahavta ṣedeq wa-tisnaʾ reshaʿ, ʿal ken meshaḥakha ʾelohim ʾeloheykha shemen sasson me-ḥavereykha.*

You have loved righteousness and hated wickedness; therefore God, your God, has anointed you with the oil of gladness above your fellows.

**Four things in that verse and they settle what Book VIII needs.**

*Meshaḥakha*, has anointed you. The verb, with the king as object.

*ʾElohim ʾeloheykha*, God your God. Whatever verse 7 says, verse 8 has the addressee possessing a God, which is not something said of a deity.

*Shemen sasson*, oil of gladness. The substance.

*Me-ḥavereykha*, above your fellows. He has fellows. He is above them and he is of their number.

So the psalm that most nearly addresses a king as *ʾelohim* states in the next verse that God is his God and that he has been anointed above his fellows. The escalation and the conferral are one verse apart, and the conferral is in the unambiguous verse.

**The structural point for the sequence.** Stage four raises the vocabulary to its highest available register: sonship, a seat at the right hand, and a throne addressed with the divine name. And in every one of the three psalms the grammar of Chapter 62 holds. Psalm 2:6-8: I have installed, I have begotten, ask and I will give. Psalm 110:1-4: sit, I will make, the LORD has sworn. Psalm 45:8: God your God has anointed you.

**The magnitude rises and the mode of holding does not move.** That sentence is the whole of Book VIII and stage four is where it first becomes visible, because stage four is the first stage at which a reader would expect the mode to change.

## CHAPTER 78 · Stage Five · Isaiah 9:5 and the Throne-Name

*Ki yeled yullad lanu ben nittan lanu, wa-tehi ha-misrah ʿal shikhmo, wa-yiqraʾ shemo peleʾ yoʿeṣ ʾel gibbor ʾavi ʿad sar shalom.*

For a child is born to us, a son is given to us, and the government shall be on his shoulder, and his name is called Wonderful Counsellor, Mighty God, Everlasting Father, Prince of Peace.

**A note on versification.** This is Isaiah 9:5 in the Hebrew and 9:6 in most English versions, as Chapter 5 warned.

**The escalation.** This is the highest name applied to a royal figure in the prophetic corpus. *ʾEl gibbor*, mighty God, is used of God directly at Isaiah 10:21, *sheʾar yashuv sheʾar Yaʿaqov ʾel ʾel gibbor*, and at Jeremiah 32:18. *ʾAvi ʿad*, father of eternity or everlasting father, has no parallel applied to a human anywhere in the corpus.

**And the first two clauses are the passive.** *Yeled yullad lanu*, a child is born to us, pual. *Ben nittan lanu*, a son is given to us, nifal. Two passives in six words, at the opening of the corpus's highest royal name. And the beneficiary in both is *lanu*, to us.

**The government is placed on him.** *Wa-tehi ha-misrah ʿal shikhmo*, the government shall be upon his shoulder. The construction is one of placement: the *misrah* comes to be on him. He does not take it up.

**And the naming is passive too.** *Wa-yiqraʾ shemo*, and his name is called, which can be read as an impersonal active, one calls his name, or as a passive. Either way the naming is not his act.

**Verse 6 states the source explicitly and closes the passage.** *Le-marbeh ha-misrah u-le-shalom ʾeyn qeṣ, ʿal kisseʾ Dawid we-ʿal mamlakhto le-hakhin ʾotah u-le-saʿadah be-mishpaṭ u-vi-ṣdaqah me-ʿattah we-ʿad ʿolam, qinʾat YHWH ṣevaʾot taʿaseh zoʾt.*

Of the increase of the government and of peace there shall be no end, upon the throne of David and upon his kingdom, to establish it and to uphold it with judgment and with righteousness from now and forever. **The zeal of the LORD of hosts will do this.**

*Qinʾat YHWH ṣevaʾot taʿaseh zoʾt.* The zeal of the LORD of hosts will do this. The final clause of the passage names the agent, and it is not the child.

**Two textual and interpretive notes, both carried as open.**

The four names can be read as one long theophoric throne-name of the type attested for Egyptian and Mesopotamian kings, which is a well-established reading and would make the divine elements descriptive of the god who grants rather than of the king. Or they can be read as four titles predicated of the child. This book takes no position and does not need one, because both readings leave the passives at 9:5a and the agent-clause at 9:6b untouched.

The passage's original reference is contested: an accession oracle for Hezekiah, a birth oracle, or a purely future expectation. Again no position is taken.

**The structural point.** Stage five is the highest name in the prophetic corpus and it arrives inside a sentence with two passives, a placement, an impersonal naming, and a closing clause attributing the whole to the zeal of the LORD of hosts. The escalation is maximal and the conferral grammar is unbroken.

## CHAPTER 79 · Stage Six · Isaiah 11:1 and the Regrowth

*We-yaṣaʾ ḥoṭer mi-gezaʿ Yishay we-neṣer mi-shorashaw yifreh.*

And a shoot shall come out from the stump of Jesse, and a branch shall grow from his roots.

**The image is regrowth after felling.** *Gezaʿ* is a stump, the cut base of a tree. The word occurs three times in the Hebrew Bible: here, at Isaiah 40:24 where the princes are scarcely planted before their stock takes no root, and at Job 14:8 where the stump dies in the dust. Book IX works the tree at length; here the point is what the image does in the sequence.

**The felling is presupposed and it is not stated as a defeat of the promise.** The oracle does not say the tree will be cut. It begins after the cutting and says a shoot will come from the remains. So stage six is the promise re-issued over the wreckage of the earlier grant, and the wreckage is assumed rather than argued.

**Note the ancestor named.** *Mi-gezaʿ Yishay*, from the stump of Jesse. Not from the stump of David. The oracle goes behind the dynasty to its father, which is a way of starting the line again from before its royal history. That is a deliberate choice and the corpus makes it.

**The equipment is given.** 11:2: *we-naḥah ʿalaw ruaḥ YHWH, ruaḥ ḥokhmah u-vinah, ruaḥ ʿeṣah u-gevurah, ruaḥ daʿat we-yirʾat YHWH.* And the spirit of the LORD shall settle upon him: the spirit of wisdom and understanding, the spirit of counsel and might, the spirit of knowledge and the fear of the LORD.

Three observations. The verb is *nwḥ*, the settling-root, used of a spirit coming down and staying, as Chapter 10 noted. The direction is onto him. And the content is six qualities in three pairs, all of them faculties, and the second pair, counsel and might, is the vocabulary of Isaiah 9:5's *peleʾ yoʿeṣ* and *ʾel gibbor* redistributed as gifts.

**The equipment includes the organ of Book IV.** *Ruaḥ daʿat*, the spirit of knowledge. And 11:3: *wa-hariḥo be-yirʾat YHWH, we-loʾ le-marʾeh ʿeynaw yishpoṭ we-loʾ le-mishmaʿ ʾoznaw yokhiaḥ.* He shall not judge by what his eyes see, nor decide by what his ears hear.

**That is the deficit inventory, applied to the figure, in the negative.** Eyes and ears, the two organs of Isaiah 6:10 and 42:19, named as the faculties by which he will *not* judge. The corpus equips its figure by giving him a spirit of knowledge and then specifying that the two organs it elsewhere reports as defective are not what he will use.

Whatever else is going on there, the corpus is aware of the connection. Isaiah 6:10 shut the eyes and stopped the ears. Isaiah 11:3 has the figure judging by neither.

**And 11:4 supplies the mode of action.** *We-shafaṭ be-ṣedeq dallim we-hokhiaḥ be-mishor le-ʿanwey ʾareṣ, we-hikkah ʾereṣ be-sheveṭ piw u-ve-ruaḥ sefataw yamit rashaʿ.* He shall judge the poor with righteousness and decide with equity for the meek of the earth, and he shall strike the earth with the rod of his mouth and with the breath of his lips slay the wicked.

**And 11:9 closes on an agentless state**, which Chapter 29 worked: the earth full of the knowledge of the LORD as the waters cover the sea.

**The structural point for the sequence.** Stage six is the first stage at which the corpus equips the figure with the faculties whose absence Book IV diagnosed. That is the closest the escalation comes to addressing the actual deficit, and it is worth marking as such rather than passing over. What it does is give the figure the organs the people lack. What it does not do is give the people the organs the people lack.

That distinction is the hinge of Chapter 84 and it is stated here so that it is not read as a rhetorical flourish arriving late. The oracle is explicit: the spirit settles on *him*, singular, throughout 11:2-5. The state at 11:9 is universal. Nothing in the passage supplies the transition from the one to the other, and this book does not claim the corpus owed one.

## CHAPTER 80 · Stage Seven · Zechariah and the Split Into Two

*Wa-yoʾmer ʾelleh shenei venei ha-yiṣhar ha-ʿomedim ʿal ʾadon kol ha-ʾareṣ.*

And he said: these are the two sons of oil who stand by the Lord of all the earth. Zechariah 4:14.

**The vision.** A lampstand of gold with a bowl on top, seven lamps, seven pipes, and two olive trees, one on the right of the bowl and one on the left. The prophet asks twice what they are and is answered at 4:14.

**The phrase is unique.** *Benei ha-yiṣhar*, sons of the oil, occurs nowhere else in the Hebrew Bible. *Yiṣhar* is fresh oil, the product word, distinct from *shemen*, the substance word used in the anointing rite. The corpus coins an expression here and does not reuse it.

**Two, and they stand.** *Shenei*, two, and *ha-ʿomedim ʿal ʾadon kol ha-ʾareṣ*, standing by the Lord of all the earth. The posture is attendance.

**The second site.** Zechariah 6:13. *We-huʾ yivneh ʾet heykhal YHWH we-huʾ yissaʾ hod we-yashav u-mashal ʿal kisʾo, we-hayah khohen ʿal kisʾo, wa-ʿaṣat shalom tihyeh beyn shenehem.*

And he shall build the temple of the LORD, and he shall bear majesty and sit and rule upon his throne, and there shall be a priest upon his throne, and a counsel of peace shall be between them both.

**The last clause requires two parties.** *Beyn shenehem*, between them both. A counsel of peace between them both cannot be a description of one person holding two offices, because a counsel between a man and himself is not a counsel.

That reading has to be stated with a correction attached, because this project made the opposite error and the error is on the record. An earlier draft read 6:13 as fusing two offices in one person, which is a common reading and is available on some construals of *we-hayah khohen ʿal kisʾo*. The clause *beyn shenehem* falsified it. The withdrawal is recorded here rather than silently corrected.

**The context supplies the two.** Zechariah 3 is a vision of Joshua the high priest, standing before the angel of the LORD with the accuser at his right hand, in filthy garments which are removed and replaced. Zechariah 4:6-10 is addressed to Zerubbabel: *loʾ ve-ḥayil we-loʾ ve-khoaḥ ki ʾim be-ruḥi*, not by might nor by power but by my spirit, and his hands have laid the foundation and shall finish it. The two figures of the period are a priest and a governor of Davidic descent, and 4:14's two sons of oil are naturally the two.

**And 3:8 introduces the branch.** *Ki hinneni meviʾ ʾet ʿavdi Ṣemaḥ.* Behold I am bringing my servant Branch. With 6:12: *hinneh ʾish Ṣemaḥ shemo u-mi-taḥtaw yiṣmaḥ u-vanah ʾet heykhal YHWH*, behold a man whose name is Branch, and he shall branch out from his place and build the temple of the LORD.

**The structural point.** Stage seven splits the office. Where stages three through six had one figure carrying everything, Zechariah has two standing by the Lord of all the earth with a counsel of peace between them.

Two readings of the split are available and this book takes neither.

On one, the split is a diminishment: the post-exilic community has no king and distributes what a king held between a governor and a priest, and the vision dignifies the arrangement.

On the other, the split is an escalation: one office had failed, so the corpus doubles it, adding the priestly to the royal and thereby covering a function the monarchy had never held. Psalm 110:4's non-Aaronide priesthood stands behind this reading.

**What is not contested is the conferral grammar, which holds here as everywhere.** *Hinneni meviʾ ʾet ʿavdi Ṣemaḥ*, I am bringing my servant Branch, first person divine, at 3:8. *Not by might nor by power but by my spirit* at 4:6. And the crowns of 6:11 are made by the prophet at instruction and set on Joshua's head, then deposited in the temple at 6:14 as a memorial.

## CHAPTER 81 · Stage Eight · Daniel 7 and the Passive Yehiv

*Ḥazeh hawet be-ḥezwey leylyaʾ wa-ʾaru ʿim ʿananey shemayyaʾ ke-var ʾenash ʾateh hawah, we-ʿad ʿattiq yomayyaʾ meṭah u-qodamohi haqrevuhi. We-leh yehiv sholṭan wi-qar u-malkhu, we-khol ʿammayyaʾ ʾumayyaʾ we-lishshanayyaʾ leh yifleḥun; sholṭaneh sholṭan ʿalam di laʾ yeʿdeh u-malkhuteh di laʾ titḥabbal.*

I saw in the night visions, and behold, with the clouds of heaven one like a son of man was coming, and he came to the Ancient of Days and they brought him near before him. And to him was given dominion and glory and a kingdom, and all peoples, nations, and languages shall serve him; his dominion is an everlasting dominion which shall not pass away, and his kingdom one which shall not be destroyed.

This is the corpus's highest statement about a figure and it is in Aramaic and its central verb is passive.

**The magnitude.** Everlasting dominion. All peoples, nations, and languages serving. A kingdom that will not be destroyed. Nothing in the Hebrew Bible exceeds this and nothing else approaches it.

**The verb.** *Yehiv*, peʿil, the Aramaic passive. To him was given. No agent is expressed and none is grammatically required, though the context supplies one: the Ancient of Days is the only party in the scene who could give.

**The approach is likewise passive.** *Haqrevuhi*, they brought him near. The figure does not present himself; he is brought.

**And the arrival is stated with a verb of reaching.** *We-ʿad ʿattiq yomayyaʾ meṭah*, and he came to the Ancient of Days. The motion is toward a throne that is already occupied and was described in the preceding verses: 7:9, thrones were placed and the Ancient of Days took his seat, his garment white as snow, the hair of his head like pure wool, his throne flames of fire, its wheels burning fire.

**So the highest conferral in the corpus is a passive verb, in a court scene, before a seated figure, with the recipient brought in by others.**

That is the finding and it should be set against Chapter 62's list. Deuteronomy 17:15 God chooses. 2 Samuel 7:8 I took you. Psalm 2:7 I begot you. Psalm 110:1 sit at my right hand. Psalm 45:8 God your God anointed you. Isaiah 9:5 a son is given. 1 Chronicles 29:23 he sat on the throne of the LORD. Daniel 7:14 to him was given.

**Eight stages, two languages, six books, one grammar.**

**The identification of the figure is contested and this book does not enter it.** Daniel 7:18 has *we-yeqabbelun malkhutaʾ qaddishey ʿelyonin*, the saints of the Most High shall receive the kingdom, and 7:22 and 7:27 repeat it, which supports a collective reading. The individual reading has an equally long history. Note only that 7:18's verb is *yeqabbelun*, they shall receive, which is a verb of reception, so the collective reading preserves the conferral grammar exactly.

**Two further features of the chapter.**

**The four beasts precede.** 7:3-7. The dominion given to the figure follows the destruction of the fourth beast, and 7:12 records that the rest of the beasts had their dominion taken away, *heʿdiw sholṭanhon*, while their lives were prolonged for a season. The corpus places the conferral inside a sequence of dominions given and removed.

**And the court sits and books are opened.** 7:10: *dinaʾ yetiv we-sifrin petiḥu.* Judgment was set and the books were opened. The scene is judicial. Whatever is given at 7:14 is given by a court after a hearing, which is another way of saying it is not seized.

## CHAPTER 82 · The Category Substitution, Performed Eight Times

Book VIII has set out the stages. This chapter states what the sequence is doing, and the statement is the book's central claim.

**The problem, as Book IV established it.** The terminus is a state. A state is entered rather than delivered. The corpus locates the failure of entry in the receiver, in three organs, in five texts across three books, and nowhere in a withheld terminus.

**The response, as Book VIII has set it out.** Eight stages of increasing magnitude in the deliverer.

**The mismatch.** No enlargement of the agent addresses a deficiency in the entering.

That sentence is doing all the work and it should be tested rather than asserted, because it is the kind of claim that sounds decisive and can be empty.

**Test it against the stages.** Take each and ask what the additional content does for the deficit.

Stage two, a visible king rather than intermittent judges. Does a visible king supply a heart to know? Nothing in 1 Samuel 8-12 suggests it and 1 Samuel 12:19's confession suggests the opposite.

Stage three, permanence. Does an unrevokable dynasty supply eyes to see? Psalm 89's complaint is that the dynasty failed; the psalm nowhere claims the people's perception was at stake in it.

Stage four, cosmic vocabulary. Does a king addressed as son and seated at the right hand supply ears to hear? Isaiah 6 stands in the same corpus and reports the ears heavy.

Stage five, the throne-name. Does a child named Mighty God supply the organs? Isaiah 6:9-10 is three chapters earlier in the same book.

Stage six, the shoot with the sevenfold spirit. **This one comes closest and Chapter 79 said so.** The figure is given the spirit of knowledge and is said not to judge by what his eyes see or his ears hear. But the equipment is his. The passage supplies no transfer, and Isaiah 11:9's universal knowledge is stated as a state with no agent rather than as his achievement.

Stage seven, the split into two. Does doubling the office address a receiving failure? Zechariah's own audience is addressed at 1:4 with *ʾal tihyu kha-ʾavoteykhem ʾasher qarʾu ʾalehem ha-neviʾim ha-rishonim ... we-loʾ shameʿu we-loʾ hiqshivu ʾelay*, do not be like your fathers to whom the former prophets cried, and they did not hear or listen to me. The deficit is stated in the same book as stage seven, in its opening oracle.

Stage eight, everlasting dominion conferred in a heavenly court. Does dominion given to a figure supply a heart to a people? Nothing in Daniel 7 addresses the question and nothing claims to.

**Seven of the eight do not touch the deficit at all, and the eighth equips the figure rather than the receiver.**

**The claim, stated at its exact strength.** The sequence is not a development toward an answer. It is the same category substitution performed eight times at rising magnitude: a delivery solution offered to an entry problem.

**Two qualifications.**

**The corpus does address the receiver, elsewhere, and in the act-layer.** Deuteronomy 30:6: *u-mal YHWH ʾeloheykha ʾet levavekha we-ʾet levav zarʿekha le-ʾahavah ʾet YHWH ʾeloheykha be-khol levavkha*, and the LORD your God will circumcise your heart and the heart of your seed. Jeremiah 31:33: *natatti ʾet torati be-qirbam we-ʿal libbam ʾekhtavennah*, I will put my law within them and write it on their hearts. Ezekiel 36:26: *we-natatti lakhem lev ḥadash we-ruaḥ ḥadashah ʾetten be-qirbekhem*, I will give you a new heart and a new spirit I will put within you.

**Those three are the corpus's actual answer to the deficit and none of them contains a figure.** Deuteronomy 30:6 has God as subject and the people as object. Jeremiah 31:31-34 has God as subject throughout and closes at 31:34 with *ki khullam yedʿu ʾoti le-miq-qaṭannam we-ʿad gedolam*, for they shall all know me from the least to the greatest, with no intermediary in the clause. Ezekiel 36:26-27 has God as subject and specifies the mechanism: a new heart, a heart of flesh for a heart of stone, and my spirit within you.

That is the strongest result Book VIII produces and it was not sought. **Where the corpus addresses the deficit directly, it does so with God as subject and no figure in the clause.** Where it escalates a figure, it does not address the deficit. Two vocabularies, two grammars, and they do not overlap.

**And this book does not claim the corpus intended the contrast.** It records that the contrast is there and is checkable at named verses.

## CHAPTER 83 · What the Escalation Is Not

Four readings of the sequence are available and this book rejects three of them for stated reasons. Setting them out is a way of stating what the fourth claims.

**It is not evidence that the royal material is late.** The sequence is ordered by content and Chapter 75 said so. Several of its stages are dated early by good scholarship. A content-ordering is compatible with any chronology, including one in which the highest stages are the oldest.

**It is not evidence that the royal material is inauthentic, secondary, or an intrusion.** A means is not less real than a destination, and the corpus's own most sustained compositions are about the means. A reader who takes Book VIII as a demotion of Isaiah 11 or Daniel 7 has taken a sort for a ranking, which Chapter 4 warned about and Chapter 103 warns about again.

**It is not evidence that the expectation is mistaken.** Chapter 6's limit case stated why. If a figure of the expected kind arrives, every stage of the escalation is vindicated and every claim in this book stands unchanged, because the claim is about what the corpus's escalation does relative to a deficit it names separately, and an arrival does not alter that relation.

**What it is.** A structural observation about the corpus's own arrangement, and it has two parts.

**The figure grows monotonically.** From a man anointed with a flask of oil who hides among the baggage, to a dynastic guarantee, to a king addressed as son and seated at a right hand, to a child named Mighty God, to a shoot from a felled stump carrying a sevenfold spirit, to two figures standing by the Lord of all the earth, to one like a son of man receiving everlasting dominion from a court in the clouds.

**And the deficit does not move.** Deuteronomy 29:3's heart, eyes, and ears. Isaiah 6:10's heart, ears, and eyes. Isaiah 42:19's blind servant and deaf messenger. Jeremiah 5:21's eyes that do not see. Ezekiel 12:2's eyes to see that have not seen. Psalm 95's hardened heart. Jeremiah 6:16's we will not walk. Same organs, same vocabulary, distributed across the whole span, never reported as addressed.

**Two shapes, one corpus, and the corpus states both without comment.** That is the observation. Everything else in Book VIII is the evidence for it.

## CHAPTER 84 · The One Stage That Aims at the Deficit, and What It Shows

Chapter 82 named stage six as the closest approach and this chapter takes it alone, because the exception is more instructive than the rule.

Isaiah 11:2-3 equips the figure with a spirit of knowledge and specifies that he will not judge by what his eyes see or what his ears hear. That is the deficit inventory addressed, in the corpus's own vocabulary, in the middle of a messianic oracle.

**Three features of the equipment.**

**It is a settling.** *We-naḥah ʿalaw*, and it shall settle upon him, using *nwḥ*. The terminus root, applied to a spirit coming to rest on a person. The corpus uses the vocabulary of arriving-and-staying for the equipping.

**It is sixfold or sevenfold depending on the count.** Wisdom, understanding, counsel, might, knowledge, and the fear of the LORD, in three pairs, with *ruaḥ YHWH* standing at the head as either a seventh or a summary.

**And its content is faculties, not powers.** Every item is a mode of knowing or a disposition. There is no strength, no longevity, no invulnerability, no throne. The corpus equips its figure with the capacity Book IV said the people lacked.

**Now the question the chapter exists to ask.** Does the equipping transfer?

Read 11:2-5 and the answer is that the passage is entirely singular. *ʿAlaw*, upon him. *Wa-hariḥo*, and his delight. *Yishpoṭ*, he shall judge. *Yokhiaḥ*, he shall decide. *We-hikkah*, and he shall strike. *Yamit*, he shall slay. *We-hayah ṣedeq ʾezor motnaw*, righteousness shall be the belt of his loins. Every verb and every suffix is third masculine singular.

Read 11:6-8 and the subject changes to the animals: wolf and lamb, leopard and kid, calf and lion, cow and bear, lion eating straw, the nursing child at the hole of the asp.

Read 11:9 and the subject is the earth: *maleʾah ha-ʾareṣ deʿah ʾet YHWH*.

**The passage moves from a singular equipped figure to a universal state and supplies no clause connecting them.** There is no *le-maʿan*, no purpose clause, no consequence formula, no statement that he teaches, imparts, opens, or gives. The *ki* at 11:9b is causal for the not-hurting, and Chapter 29 discussed how far it reaches.

**Two honest readings of that gap.**

**The gap is not a defect.** Prophetic poetry moves between registers without connective tissue as a matter of course, and demanding a transfer clause is demanding a genre the passage is not.

**And the gap is a datum.** Whatever the genre, the corpus had available the vocabulary for a transfer and used it elsewhere: Deuteronomy 30:6 circumcises the heart, Jeremiah 31:33 writes on it, Ezekiel 36:26 replaces it. In each of those, God is the subject. In Isaiah 11, where the figure stands, no transfer is stated in either direction.

**The result.** The one stage that aims at the deficit equips the figure and stops there. The three passages that supply the deficit's remedy contain no figure. The two vocabularies do not meet anywhere in the corpus.

That is the sharpest form of Book VIII's finding and it is stated here rather than at the book's opening because it requires all eight stages to be visible before it can be checked. A reader who wants to break it should look for a passage in which a figure gives a heart, opens an ear, or supplies knowledge to a people. This book has not found one and does not claim none exists.
