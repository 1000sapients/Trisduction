# BOOK XI · THE PSALTER READ FOR ITS VERBS

## CHAPTER 102 · Why the Psalter Is Read Separately

The Psalter carries the corpus's highest royal language and it carries it in a genre the historical books do not use. This book reads it separately for three reasons.

**The genre is address, not narration.** A narrative reports what a king did. A psalm speaks to God about a king, or speaks as the king to God, or speaks about the king to an audience. The grammatical subjects therefore fall differently and the fall is informative.

**The royal psalms are the strongest single body of evidence against this book's reading.** Psalm 2, Psalm 45, Psalm 72, Psalm 89, Psalm 110, and Psalm 132 together contain the corpus's most exalted claims about a king, and any account that plays them down is selecting. This book does not play them down. It reads their verbs.

**And the Psalter contains the corpus's clearest statements of the divine kingship**, in the group at Psalms 93 to 99, which stand in the same book as the royal psalms and are never reconciled with them.

The method is the one used throughout. Take the passage at full strength. Ask what the corpus says the figure holds. Ask who the grammatical subject is of the verb by which he holds it.

## CHAPTER 103 · Psalm 72 · Give the King Your Judgments

*ʾElohim mishpaṭeykha le-melekh ten, we-ṣidqatkha le-ven melekh.*

O God, give your judgments to the king, and your righteousness to the king's son. Psalm 72:1.

**The psalm opens with an imperative addressed to God asking for a transfer.** *Ten*, give. The objects are *mishpaṭeykha* and *ṣidqatkha*, your judgments and your righteousness, both with the divine possessive. The king does not have them and the psalm asks that he be given them.

That is the whole of Book VI in the first verse of the psalm most concerned with royal justice.

**What the king will then do is stated in a long sequence and it is the corpus's best account of what a good king is for.** 72:2-4: judge your people with righteousness and your poor with justice; the mountains bring peace and the hills righteousness; he shall judge the poor of the people, save the children of the needy, and crush the oppressor.

**72:12-14 is the psalm's centre and it is worth quoting.** *Ki yaṣṣil ʾevyon meshawweaʿ we-ʿani we-ʾeyn ʿozer lo. Yaḥos ʿal dal we-ʾevyon we-nafshot ʾevyonim yoshiaʿ. Mi-tokh u-me-ḥamas yigʾal nafsham we-yeqar damam be-ʿeynaw.*

For he delivers the needy when he cries, and the poor who has no helper. He spares the weak and needy and saves the souls of the needy. From oppression and violence he redeems their soul, and precious is their blood in his sight.

**Note *meshawweaʿ*, when he cries.** This is the outcry vocabulary of 1 Samuel 8:18, in the cognate root *šwʿ*, and here the king answers it. The psalm assigns to the king exactly the function 1 Samuel 8:18 said would go unanswered. Book XIII counts the pair.

**And the psalm's closing verses relocate everything.** 72:18-19: *barukh YHWH ʾelohim ʾelohey Yisraʾel ʿoseh niflaʾot levaddo. U-varukh shem kevodo le-ʿolam we-yimmaleʾ khevodo ʾet kol ha-ʾareṣ.* Blessed be the LORD God, the God of Israel, who alone does wondrous things. And blessed be his glorious name forever, and let the whole earth be filled with his glory.

*Levaddo*, alone. In the closing doxology of the psalm that has just described a king doing everything, the corpus says God alone does wondrous things.

The doxology at 72:18-19 is usually taken as the closing formula for Book Two of the Psalter rather than as part of the psalm proper, and 72:20 confirms it: *kallu tefillot Dawid ben Yishay*, the prayers of David son of Jesse are ended. So the *levaddo* may be editorial rather than authorial. This book records that the corpus's arrangement places it there, and takes it at that weight.

**Two further observations.**

**The psalm's superscription is *li-Shelomoh*, for or of Solomon**, and its content maps onto 1 Kings 3's request for a hearing heart and 1 Kings 10's account of tribute from Sheba and Seba, which 72:10 names.

**And the psalm's terminal image is agricultural and agentless.** 72:16: *yehi fissat bar ba-ʾareṣ be-roʾsh harim, yirʿash ka-Levanon piryo we-yaṣiṣu me-ʿir ke-ʿesev ha-ʾareṣ.* Let there be abundance of grain in the land on the top of the mountains; let its fruit wave like Lebanon, and let them blossom from the city like the grass of the earth.

## CHAPTER 104 · Psalm 89 · The Covenant and the Complaint

Chapter 76 used this psalm for the covenant's failure. This chapter reads it whole, because it is the corpus's most sustained treatment of the Davidic grant and it contains its own refutation.

**Part one, the covenant stated.** 89:2-5 and 89:20-38. *Karatti verit li-vḥiri nishbaʿti le-Dawid ʿavdi, ʿad ʿolam ʾakhin zarʿekha u-vaniti le-dor wa-dor kisʾakha.* I have made a covenant with my chosen, I have sworn to David my servant: forever I will establish your seed and build up your throne to all generations.

**And 89:20-30 is the fullest statement of conferral in the Psalter.** *ʾAz dibbarta ve-ḥazon la-ḥasideykha wa-toʾmer shiwwiti ʿezer ʿal gibbor, harimoti vaḥur me-ʿam. Maṣaʾti Dawid ʿavdi, be-shemen qodshi meshaḥtiw. ʾAsher yadi tikkon ʿimmo ʾaf zeroʿi teʾammeṣennu.*

Then you spoke in a vision to your faithful ones and said: I have laid help on a mighty one, I have exalted one chosen from the people. I have found David my servant; with my holy oil I have anointed him. My hand shall be established with him, my arm also shall strengthen him.

**Count the first-person divine verbs in that passage.** I have laid. I have exalted. I have found. I have anointed. My hand shall establish. My arm shall strengthen. And it continues: 89:23, the enemy shall not outwit him; 89:24, I will beat down his foes; 89:25, my faithfulness and mercy shall be with him; 89:26, I will set his hand on the sea; 89:28, I will make him firstborn, highest of the kings of the earth.

**89:27 is the psalm's highest claim and it is put in the king's mouth as an address.** *Huʾ yiqraʾeni ʾavi ʾattah, ʾeli we-ṣur yeshuʿati.* He shall call to me: you are my father, my God, and the rock of my salvation.

The sonship of Psalm 2:7 restated from the other direction. In Psalm 2 God says you are my son. Here the king says you are my father, and adds *ʾeli*, my God. The corpus's highest filial claim about a king includes the king calling God his God.

**89:28.** *ʾAf ʾani bekhor ʾettenehu, ʿelyon le-malkhey ʾareṣ.* I also will make him firstborn, highest of the kings of the earth. *ʾEttenehu*, I will make him, first person.

**Part two, the discipline clause, which is 2 Samuel 7:14 in verse.** 89:31-34: if his sons forsake my law, I will visit their transgression with the rod and their iniquity with stripes, *we-ḥasdi loʾ ʾafir me-ʿimmo we-loʾ ʾashaqqer be-ʾemunati*, but my covenant loyalty I will not take from him, nor will I be false to my faithfulness.

**Part three, the complaint.** 89:39-46. You have cast off and rejected. You have been wroth with your anointed. You have renounced the covenant of your servant. You have profaned his crown to the ground. You have broken down all his walls. You have made his strongholds a ruin. You have exalted the right hand of his foes. You have turned back the edge of his sword. You have made his splendour to cease and cast his throne to the ground. You have shortened the days of his youth and covered him with shame.

**Eleven second-person verbs of destruction, addressed to God, about the covenant the psalm has just stated at maximum strength.**

**Part four, the question.** 89:47-52. *ʿAd mah YHWH tissater la-neṣaḥ.* How long, LORD, will you hide yourself forever? And 89:50: *ʾayyeh ḥasadeykha ha-rishonim ʾAdonay nishbaʿta le-Dawid be-ʾemunatekha.* Where are your former mercies, Lord, which you swore to David in your faithfulness?

**The psalm ends unanswered.** 89:53's *barukh YHWH le-ʿolam ʾamen we-ʾamen* is the doxology closing Book Three of the Psalter, not a resolution.

**What the psalm establishes.** The corpus's fullest statement of the Davidic conferral and the corpus's fullest complaint that it failed stand in one composition. The conferral is stated in eleven first-person divine verbs and the failure in eleven second-person ones. And the corpus preserves both, in one psalm, with a question at the end and no answer.

## CHAPTER 105 · Psalm 132 · The Oath and Its Condition

*Zekhor YHWH le-Dawid ʾet kol ʿunnoto.* Remember, LORD, for David, all his affliction. Psalm 132:1.

**The psalm has two oaths and the pairing is its structure.**

**David's oath**, 132:2-5. He swore to the LORD, vowed to the Mighty One of Jacob: I will not come into the tent of my house, nor go up to my bed, nor give sleep to my eyes or slumber to my eyelids, until I find a place for the LORD, a dwelling for the Mighty One of Jacob.

**God's oath**, 132:11-12. *Nishbaʿ YHWH le-Dawid ʾemet loʾ yashuv mimmennah, mi-peri viṭnekha ʾashit le-khisseʾ lakh. ʾIm yishmeru vaneykha beriti we-ʿedoti zo ʾalammedem, gam beneyhem ʿadey ʿad yeshevu le-khisseʾ lakh.*

The LORD has sworn to David a truth from which he will not turn back: of the fruit of your body I will set on your throne. **If your sons keep my covenant and my testimony which I shall teach them, their sons also forever shall sit on your throne.**

**The conditional at 132:12 is the datum.** *ʾIm yishmeru vaneykha beriti.* If your sons keep my covenant. The corpus's second full statement of the Davidic oath carries a condition that 2 Samuel 7 does not.

**Two readings.**

On one, the two statements are in tension: 2 Samuel 7:15 bars the withdrawal unconditionally and Psalm 132:12 conditions the continuation. Book XIII counts the pair.

On the other, the two are compatible if the unconditional element is the grant to the house and the conditional element is any given son's occupancy, which is precisely the distinction 2 Samuel 7:14-15 makes between disciplining the occupant and not removing the loyalty. On this reading Psalm 132 is stating the same structure from the occupant's side.

**This book prefers the second and does not require it**, because either way the psalm supplies a conditional clause attached to the throne, in the corpus's own words.

**Two further features.**

**The psalm's centre is a dwelling, not a dynasty.** 132:13-14: *ki vaḥar YHWH be-Ṣiyyon, ʾiwwah le-moshav lo. Zoʾt menuḥati ʿadey ʿad, poh ʾeshev ki ʾiwwitiha.* For the LORD has chosen Zion, he has desired it for his dwelling. **This is my resting place forever; here I will dwell, for I have desired it.**

*Zoʾt menuḥati.* This is my *menuḥah*. The terminus vocabulary, with the divine first-person suffix, as at Psalm 95:11. Two psalms use *menuḥati* and one says they did not enter it and the other says here I will dwell.

**And the psalm closes on a horn and a lamp.** 132:17: *sham ʾaṣmiaḥ qeren le-Dawid, ʿarakhti ner li-meshiḥi.* There I will cause a horn to sprout for David; I have prepared a lamp for my anointed.

*ʾAṣmiaḥ*, I will cause to sprout, the causative of the Branch root, first person divine. *ʿArakhti*, I have prepared or arranged, first person divine. *Li-meshiḥi*, for my anointed, with the divine possessive.

Three conferral verbs in one verse at the close of the psalm.

## CHAPTER 106 · The Enthronement Psalms · YHWH Malakh

Psalms 93, 95, 96, 97, 98, and 99 form a group whose subject is the divine kingship, and they stand in the same book as the royal psalms without any passage relating the two.

**Psalm 93:1.** *YHWH malakh geʾut laveš, laveš YHWH ʿoz hitʾazzar, ʾaf tikkon tevel bal timmoṭ.* The LORD reigns; he is clothed with majesty; the LORD is clothed, he has girded himself with strength; the world is established, it shall not be moved.

**Psalm 97:1.** *YHWH malakh tagel ha-ʾareṣ, yismeḥu ʾiyyim rabbim.* The LORD reigns; let the earth rejoice; let the many coastlands be glad.

**Psalm 99:1.** *YHWH malakh yirgezu ʿammim, yoshev keruvim tanuṭ ha-ʾareṣ.* The LORD reigns; let the peoples tremble; he sits enthroned upon the cherubim; let the earth quake.

**Psalm 96:10.** *ʾImru va-goyim YHWH malakh.* Say among the nations: the LORD reigns.

**Psalm 95, which is the group's outlier**, has the flock-relation, the hearing condition, and the non-entry, and Chapter 26 worked it. Its opening at 95:3 belongs with the group: *ki ʾel gadol YHWH u-melekh gadol ʿal kol ʾelohim.* For the LORD is a great God and a great king above all gods.

**Four observations.**

**The formula is a perfect and the sense is contested.** *YHWH malakh* can be read as the LORD has become king, the LORD reigns, or the LORD is king, and the choice bears on whether these are enthronement psalms marking an annual accession or declarations of a standing sovereignty. This book does not adjudicate.

**Whatever the reading, the reign is asserted during the monarchy's currency in the corpus's arrangement.** These psalms stand in a Psalter that also contains Psalm 2, Psalm 45, Psalm 89, and Psalm 110. The corpus asserts both kingships and never states the relation between them.

**And the assertion converges with 1 Samuel 8:7.** Chapter 45 argued that the rejection at 8:7 leaves the sovereignty untouched and changes only its acceptance. The enthronement psalms assert the sovereignty in the strongest terms, in the same corpus, during the period of the human monarchy, with no acknowledgement that anything happened to it. That is the corpus supplying its own evidence for the reading.

**The group's characteristic verbs are all divine.** He reigns. He is clothed. He has girded. He has established. He sits enthroned. He comes to judge. He has made known his salvation. There is no human figure anywhere in Psalms 93, 96, 97, 98, or 99.

**And Psalm 98:9 and 96:13 both close on the same clause.** *Ki vaʾ li-shpoṭ ha-ʾareṣ, yishpoṭ tevel be-ṣedeq we-ʿammim be-meysharim.* For he comes to judge the earth; he will judge the world with righteousness and the peoples with equity.

The judging function that Psalm 72:1-4 asks God to give to the king is here performed by God directly, in two psalms three compositions apart, with no figure in either.

## CHAPTER 107 · Psalm 8 and Psalm 144 · What a Man Is

Two psalms ask what a human being is and both answer in the vocabulary of grant.

**Psalm 8:5-7.** *Mah ʾenosh ki tizkerennu u-ven ʾadam ki tifqedennu. Wa-teḥasserehu meʿaṭ me-ʾelohim we-khavod we-hadar teʿaṭṭerehu. Tamshilehu be-maʿasey yadeykha, kol shattah taḥat raglaw.*

What is man that you remember him, and the son of man that you attend to him? Yet you have made him a little lower than *ʾelohim* and crowned him with glory and honour. You have made him rule over the works of your hands; you have put all things under his feet.

**Every verb has God as subject.** You remember. You attend. You have made him lack. You crown him. You make him rule. You have put.

**The vocabulary is royal.** *Kavod we-hadar*, glory and honour, is the pair used of the king at Psalm 21:6. *Tamshilehu*, you make him rule, is the causative of *mšl*, the verb Gideon refused at Judges 8:23. *Kol shattah taḥat raglaw* is the footstool image of Psalm 110:1 in different words.

**And the referent is generic.** *ʾEnosh* and *ben ʾadam*, man and son of man, in a psalm whose frame at 8:2 and 8:10 is *YHWH ʾadoneynu mah ʾaddir shimkha be-khol ha-ʾareṣ*, how majestic is your name in all the earth.

The corpus applies its royal conferral vocabulary to humanity as such, in a psalm about the moon and the stars and the beasts of the field, with God as the subject of every verb.

**Psalm 144:3-4 asks the same question and answers differently.** *YHWH mah ʾadam wa-tedaʿehu, ben ʾenosh wa-teḥashevehu. ʾAdam la-hevel damah, yamaw ke-ṣel ʿover.* LORD, what is man that you know him, the son of man that you think of him? Man is like a breath; his days are like a passing shadow.

**Same question, opposite answer, in one Psalter.** Psalm 8 crowns him. Psalm 144 makes him a breath. Book XIII does not count this among its ten pairs because the two are not contradictory propositions, but the juxtaposition is worth having: the corpus asks its anthropological question twice and gives two answers, and Psalm 144's superscription attributes it to David and its verses 10-11 are about delivering David from the sword.

**What this chapter adds to Book XI.** The conferral grammar is not confined to kings. Where the corpus states what a human being holds, in the most general terms it has, the verbs are the same verbs. That is the widest form of Chapter 62's finding and it suggests the grammar is a feature of how the corpus talks about creatures rather than a feature of how it talks about kings.

## CHAPTER 108 · The Laments Over the Anointed

Chapter 74's census noted that several occurrences of *mashiaḥ* fall in laments. This chapter reads them, because a title used at the moment of its failure is being used in a way that tells against a triumphal reading of the vocabulary.

**Psalm 89:39.** *ʾAkh zanaḥta wa-timʾas, hitʿabbarta ʿim meshiḥekha.* You have cast off and rejected, you have been wroth with your anointed. The verb *mʾs* is 1 Samuel 8:7's and 1 Samuel 15:23's, and it is here applied by the psalmist to God's treatment of the anointed.

**Psalm 89:52.** *ʾAsher ḥerfu ʾoyveykha YHWH, ʾasher ḥerfu ʿiqvot meshiḥekha.* With which your enemies have reproached, LORD, with which they have reproached the footsteps of your anointed.

**Lamentations 4:20.** *Ruaḥ ʾappeynu meshiaḥ YHWH nilkad bi-shḥitotam, ʾasher ʾamarnu be-ṣillo niḥyeh va-goyim.*

The breath of our nostrils, the anointed of the LORD, was taken in their pits, of whom we said: under his shadow we shall live among the nations.

**That verse is the sharpest.** The title *meshiaḥ YHWH*, at its full strength with the divine possessive, applied to a king who has been captured in a pit. And the relative clause quotes the expectation that failed: *be-ṣillo niḥyeh va-goyim*, in his shadow we shall live among the nations.

The corpus preserves both the title and the quotation of the hope, in a book of laments over the destruction, and does not qualify either.

**Psalm 84:10.** *Maginnenu reʾeh ʾelohim we-habbeṭ pney meshiḥekha.* Behold our shield, God, and look upon the face of your anointed. A petition, which presupposes a situation requiring one.

**Psalm 132:10.** *Ba-ʿavur Dawid ʿavdekha ʾal tashev pney meshiḥekha.* For the sake of David your servant, do not turn away the face of your anointed.

**Habakkuk 3:13.** *Yaṣaʾta le-yeshaʿ ʿammekha, le-yeshaʿ ʾet meshiḥekha.* You went forth for the salvation of your people, for the salvation of your anointed. The anointed is the object of the salvation, not its agent.

**Six sites and a pattern.** In every one the anointed is the object of petition, of reproach, of capture, or of salvation. In not one is he the agent of a deliverance.

That is a distributional observation about a small field and it is offered at that weight. What it establishes is that the corpus's use of its central royal title includes, prominently, the title's use at the moments of the office's greatest failure, and that the corpus does not withdraw the title at those moments. Saul keeps it after the rejection, at fifteen sites. The captured king of Lamentations 4:20 keeps it in the pit.

A title that survives the failure of its bearer is a title that names something other than the bearer's success. Chapter 63 said what: it names that something was applied by another.

## CHAPTER 109 · What the Psalter Establishes

Six results.

**The royal psalms state the highest claims and state them as conferred.** Psalm 2:6-8, five conferral forms. Psalm 45:8, God your God has anointed you. Psalm 72:1, give the king your judgments. Psalm 89:20-28, eleven first-person divine verbs. Psalm 110:1-4, sit, I will make, the LORD has sworn. Psalm 132:11-17, I will set, I will cause to sprout, I have prepared.

**The Psalter contains the corpus's clearest assertion that the covenant failed**, at Psalm 89:39-46, in eleven second-person verbs, in the same psalm as the fullest statement of it.

**It contains a conditional attached to the throne**, at Psalm 132:12, that 2 Samuel 7 does not have.

**It contains the divine kingship asserted at full strength in six psalms with no human figure anywhere in them.**

**It applies the royal conferral vocabulary to humanity as such at Psalm 8.**

**And it uses the royal title most densely in laments over the office's failure.**

Two closing observations.

**The Psalter is the strongest evidence against this book's reading and it is also, read for its verbs, the strongest evidence for it.** That is not a paradox. The exaltation and the conferral are two properties of the same sentences, and a reader who takes only the first has taken half of what is there.

**And the Psalter contains the corpus's other use of *menuḥati*.** Psalm 95:11 says they did not enter my rest. Psalm 132:14 says this is my resting place forever, here I will dwell. Two psalms, one word, one divine suffix, and two statements: the place is unentered, and the one whose place it is dwells there. The corpus states both and reconciles neither, which by now is the expected finding.
