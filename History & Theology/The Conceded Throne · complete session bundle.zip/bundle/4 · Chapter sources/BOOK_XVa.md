# BOOK XV · THE TORAH'S OWN FIGURES

## CHAPTER 134 · Why the Torah Is Read Last

The Torah stands first in the corpus and is read last in this book, and the ordering is deliberate.

The Torah's royal-figure material is sparse, contested at every site, and has been read through the later material for so long that a reader coming to it first will bring the later readings with them. Reading it after Books III through XIII means arriving with a vocabulary drawn from the corpus's own later usage, which is the only vocabulary this book has authority to use.

**Four passages are conventionally counted as the Torah's messianic material.** Genesis 3:15, Genesis 49:10, Numbers 24:17, and Deuteronomy 18:15. The fourth is treated at Excursus XII and set aside. The first three are taken here.

**A fifth body belongs with them and is usually not counted**: the patriarchal promises, which are the Torah's actual future-oriented material and which contain no figure at all.

**And a sixth observation frames the whole.** The Torah is where the terminus vocabulary is established, at Genesis 2:2, Exodus 20:11, Leviticus 25 and 26, and Deuteronomy 12:9. It is also where the deficit is first stated, at Deuteronomy 29:3. And it is where the law of the king anticipates the demand, at Deuteronomy 17:14. The Torah supplies Books III, IV, and V with their foundations and supplies Book VIII with almost nothing.

That asymmetry is a datum about the corpus's arrangement and it is the reason this book of chapters is short.

## CHAPTER 135 · Genesis 3:15 · The Seed and the Heel

*We-ʾeyvah ʾashit beynkha u-veyn ha-ʾishah u-veyn zarʿakha u-veyn zarʿah, huʾ yeshufkha roʾsh we-ʾattah teshufennu ʿaqev.*

And I will put enmity between you and the woman, and between your seed and her seed; he shall bruise you on the head and you shall bruise him on the heel.

**The verse's messianic reading is ancient and this book does not adjudicate it.** What can be said from the Hebrew is limited and is set out here.

**The subject of the first verb is God.** *ʾEyvah ʾashit*, I will put enmity. The whole arrangement is stated as a divine act, using the same verb *šyt* as Psalm 110:1's *ʿad ʾashit ʾoyveykha hadom le-ragleykha*, until I make your enemies a footstool.

**The noun *zeraʿ* is collective and singular in form.** It takes singular agreement throughout the corpus even where it plainly means descendants, as at Genesis 13:16 and 22:17. So the singular pronoun *huʾ* at 3:15b is grammatically expected and does not by itself establish an individual referent. It also does not exclude one.

**The verb *šwf* occurs three times in the Hebrew Bible** and its sense is uncertain. Genesis 3:15 twice, and Job 9:17, *ʾasher bi-seʿarah yeshufeni*, who crushes me with a tempest, and Psalm 139:11, *ʾakh ḥoshekh yeshufeni*, where the sense may be different. The corpus is using a rare verb and using it twice in one clause, with the same verb for both parties.

**The symmetry is the striking feature.** *Huʾ yeshufkha roʾsh we-ʾattah teshufennu ʿaqev.* One verb, two subjects, two body-parts. The asymmetry, if there is one, is entirely in the anatomy: a head-wound and a heel-wound are not equivalent injuries. That asymmetry is real and it is not in the verbs.

**What this book takes.** The enmity is instituted by a divine act stated in the first person. Beyond that the verse is too contested and too lexically uncertain to carry an argument, and no argument in this book rests on it.

## CHAPTER 136 · Genesis 49:10 · Shiloh, and the Sceptre

*Loʾ yasur sheveṭ mi-Yhudah u-meḥoqeq mi-beyn raglaw ʿad ki yavoʾ Shiloh we-lo yiqqehat ʿammim.*

The sceptre shall not depart from Judah, nor the ruler's staff from between his feet, until Shiloh comes; and to him shall be the obedience of the peoples.

**Every clause of that verse is contested.**

*Shiloh* is the crux. The consonantal text *šylh* has been read as a place name, as *shelo*, that which is his, as *shay lo*, tribute to him, as a personal name, and as a corruption. The versions diverge. There is no settled reading.

*Yiqqehat* is a hapax and its sense is inferred from context and from a possible Arabic cognate.

*Meḥoqeq* can be the ruler's staff or the ruler himself; the participle of *ḥqq*, to inscribe or decree, is used both ways.

**This book uses the verse for nothing** and says so plainly rather than offering a reading and then hedging it.

**Two observations that do not require settling the crux.**

**The verb *swr*, to depart, is the verb of 2 Samuel 7:15.** *We-ḥasdi loʾ yasur mimmennu*, my covenant loyalty shall not depart from him. The same root, in the same negative construction, of a thing not departing from a Judahite line. Whether the connection is deliberate is unknowable and the shared vocabulary is a fact.

**And the blessing is a father's deathbed speech, not an oracle.** Genesis 49:1: *heʾasfu we-ʾaggidah lakhem ʾet ʾasher yiqraʾ ʾetkhem be-ʾaḥarit ha-yamim*, gather and I will tell you what shall befall you in the latter days. The frame is a testament, and the other eleven sayings in the chapter are a mixture of blessing, curse, and geographical prediction, several of them unflattering. Reuben is unstable as water. Simeon and Levi are cursed for their anger. Issachar is a strong ass couching between the burdens. Reading Judah's saying as categorically different in kind from its eleven neighbours is a decision, and this book makes no decision about it.

## CHAPTER 137 · Numbers 24:17 · The Star and the Sceptre

*ʾErʾennu we-loʾ ʿattah, ʾashurennu we-loʾ qarov; darakh kokhav mi-Yaʿaqov we-qam sheveṭ mi-Yisraʾel u-maḥaṣ paʾatey Moʾav we-qarqar kol benei Shet.*

I see him, but not now; I behold him, but not near. A star shall come forth from Jacob and a sceptre shall rise from Israel, and shall crush the corners of Moab and destroy all the sons of Sheth.

**The speaker is Balaam**, a foreign diviner hired to curse Israel, whose donkey has spoken to him three chapters earlier. That is the corpus's setting for its clearest Torah statement of a coming ruler and it is worth registering.

**The immediate reference is military and directional.** Moab crushed, the sons of Sheth destroyed, Edom and Seir dispossessed at 24:18, and 24:19's *we-yerd mi-Yaʿaqov we-heʾevid sarid me-ʿir*. The oracle names neighbouring peoples and their defeat.

**The star and the sceptre are a pair of images and both are stated with intransitive verbs.** *Darakh kokhav*, a star treads or comes forth. *We-qam sheveṭ*, and a sceptre rises. No agent causes either. They come forth and rise.

**The temporal frame is a distancing.** *We-loʾ ʿattah*, and not now. *We-loʾ qarov*, and not near. Balaam's own framing places the vision at a remove.

**Two observations.**

**The oracle is spoken by an outsider and the corpus records it as true.** Numbers 23:5 and 23:16 have God putting a word in Balaam's mouth, and 24:2 has the spirit of God coming upon him. The Torah's clearest statement of a rising sceptre is delivered by a hired foreign diviner under divine compulsion.

That is not a diminishment. It belongs with Chapter 57's pattern of acknowledged receipt and with Chapter 71's Cyrus: the corpus repeatedly puts significant material in foreign mouths and does not hide the provenance.

**And the oracle's content is a conquest, not a terminus.** Nothing in Numbers 24:17-19 addresses the heart, the eyes, the ears, the knowledge, or the rest. It is an oracle of military supremacy over named neighbours.

## CHAPTER 138 · The Patriarchal Promises · The Torah's Actual Future Material

The Torah's sustained future-oriented material is the promise to the patriarchs, and it contains no figure.

**Genesis 12:1-3.** Go from your country to the land that I will show you. And I will make of you a great nation, and I will bless you and make your name great, and be a blessing. And I will bless those who bless you and curse him who curses you, and in you all the families of the earth shall be blessed.

**Count the first-person divine verbs.** I will show. I will make. I will bless. I will make great. I will bless. I will curse. Six, in three verses, with Abram as recipient.

**Genesis 15:5-6.** Look toward heaven and number the stars if you are able to number them; so shall your seed be. *We-heʾemin ba-YHWH wa-yaḥsheveha lo ṣedaqah.* And he believed in the LORD, and he counted it to him as righteousness.

**Genesis 15:18.** *Ba-yom ha-huʾ karat YHWH ʾet ʾAvram berit leʾmor, le-zarʿakha natatti ʾet ha-ʾareṣ ha-zoʾt.* On that day the LORD made a covenant with Abram, saying, to your seed I have given this land. The verb is perfect: I have given.

**And the covenant-cutting ceremony at 15:9-17 has the smoking fire-pot and flaming torch passing between the pieces alone.** Abram is in a deep sleep, *tardemah*, and a great darkness. The party that passes between the divided animals in the corpus's covenant ceremony is the divine one, and Abram sleeps through it.

**Genesis 17:1-8.** The covenant restated with circumcision as its sign, the name changed from Abram to Abraham, and 17:8's *we-natatti lekha u-le-zarʿakha ʾaḥareykha ʾet ʾereṣ megureykha ... la-ʾaḥuzzat ʿolam*, and I will give to you and your seed after you the land of your sojournings for an everlasting possession.

**Genesis 22:16-18**, after the binding: *bi nishbaʿti neʾum YHWH*, by myself I have sworn. And the blessing multiplied, and 22:18's *we-hitbarakhu ve-zarʿakha kol goyey ha-ʾareṣ ʿeqev ʾasher shamaʿta be-qoli*, and in your seed all the nations of the earth shall be blessed, **because you have obeyed my voice.**

*ʿEqev ʾasher shamaʿta be-qoli.* Because you listened to my voice. The hearing of Book IV, performed, and stated as the ground of the promise's confirmation.

**The result for Book XV.** The Torah's future material is a promise of land, descendants, and blessing to the nations, stated in first-person divine verbs, with a human party who believes, who sleeps through the covenant ceremony, and who is commended for having listened. There is no royal figure anywhere in it.

## CHAPTER 139 · The Blessing of the Nations, and Its Grammar

Four times the Torah states that the nations will be blessed through Abraham's line and the grammar of the verb is contested each time.

**Genesis 12:3.** *We-nivrekhu vekha kol mishpeḥot ha-ʾadamah.* Nifal.
**Genesis 18:18.** *We-nivrekhu vo kol goyey ha-ʾareṣ.* Nifal.
**Genesis 22:18.** *We-hitbarakhu ve-zarʿakha kol goyey ha-ʾareṣ.* Hitpael.
**Genesis 26:4**, to Isaac, and **Genesis 28:14**, to Jacob, repeat the formula.

**The contest.** The nifal can be passive, shall be blessed, or reflexive, shall bless themselves. The hitpael is more naturally reflexive. On the passive reading the line is a channel of blessing to the nations. On the reflexive reading the nations will invoke Abraham's name in blessing themselves, as at Genesis 48:20's *bekha yevarekh Yisraʾel*, by you Israel will bless.

**This book takes no position** and notes that the two readings differ substantially in what they claim about the line's function.

**What holds under both.** The blessing's source is stated in every instance as God, and the line is the location or the instance rather than the agent. Even on the strongest passive reading, *nivrekhu vekha* is blessed **in you**, a prepositional phrase, not blessed **by you**.

**And the corpus supplies its own gloss at Genesis 22:18.** *ʿEqev ʾasher shamaʿta be-qoli*, because you listened to my voice. The blessing's confirmation is grounded in a hearing.

That is the Torah's one statement connecting the promise to the nations with the faculty Book IV traced, and it grounds the connection in the patriarch's hearing rather than in any figure's action.

## CHAPTER 140 · What the Torah Establishes and What It Does Not

**What it establishes**, and each is worked in an earlier book.

The terminus, named at Genesis 2:2 in the cessation root, restated at Exodus 20:11 in the settling root, legislated at three scales in Leviticus 25, and stated as the promise's object at Deuteronomy 12:9.

The deficit, at Deuteronomy 29:3, in three organs, immediately after a recitation of forty years of signs.

The mechanism, at Deuteronomy 8:12-14: satisfied, heart lifted, forgot.

The criterion, at Deuteronomy 30:11-14 and 10:12-13, performed by the corpus itself.

The choice, at Deuteronomy 30:19.

The law of the king, at Deuteronomy 17:14-20, conditioned on a demand and containing four prohibitions and one positive requirement, which is a copying.

The anointing rite, at Exodus 29:7 and Leviticus 8:12, priestly and prior to any king.

And the covenant formula, at Exodus 6:7 and Leviticus 26:12, which Ezekiel 36:28 and 37:23 will use to close their restoration sequences.

**What it does not establish.**

No royal figure of the kind Books VIII and XII trace. The three candidate passages are contested at every level: Genesis 3:15's verb is a hapax-adjacent rarity and its referent is a collective noun, Genesis 49:10's crux is unsolved, and Numbers 24:17 is an oracle of military supremacy spoken by a foreign diviner.

**And the asymmetry is the chapter's finding.** The Torah supplies the terminus, the deficit, the mechanism, the criterion, the choice, and the constitutional restraint on kingship. It supplies almost nothing to the escalation.

That distribution is what a reader would expect if the escalation is, as Book VIII argued, a response to the failure of a monarchy the Torah anticipates and regulates rather than establishes. It is not what a reader would expect if the royal figure were the corpus's organizing centre from its opening.

The observation is offered at that weight. Distribution arguments are weak, the Torah is not the corpus's earliest material on any account, and a reader who holds that the messianic expectation was always implicit will not be moved by a count of explicit passages. What the count establishes is where the explicit passages are, which is a fact about the received arrangement.
