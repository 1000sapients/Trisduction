# BOOK X · THE SHEPHERD AND THE FLOCK

## CHAPTER 94 · The Metaphor and Its Two Ends

The corpus's most sustained image for the relation between God, the ruler, and the people is a flock, and the image has a fixed structure that survives every use.

**The flock is God's.** This is the constant. *Ṣoʾni*, my flock, eleven times in Ezekiel 34 alone. *ʿAmmi*, my people, throughout the corpus. *Ṣoʾn marʿito*, the sheep of his pasture, at Psalm 100:3. *ʿAm marʿito we-ṣoʾn yado*, the people of his pasture and the sheep of his hand, at Psalm 95:7.

**The shepherd is appointed.** Every human shepherd in the corpus is placed over a flock that is not his. 2 Samuel 5:2: you shall shepherd *ʿammi*, my people. Ezekiel 34:23: I will raise up over them one shepherd. Jeremiah 3:15: *we-natatti lakhem roʿim ke-libbi*, I will give you shepherds after my own heart.

**And God is the shepherd too, in the same corpus, without the two claims being reconciled.** Psalm 23:1: *YHWH roʿi*. Psalm 80:2: *roʿeh Yisraʾel haʾazinah, noheg ka-ṣoʾn Yosef*. Genesis 48:15, Jacob blessing: *ha-ʾelohim ha-roʿeh ʾoti me-ʿodi ʿad ha-yom ha-zeh*, the God who has shepherded me all my life to this day. Isaiah 40:11: *ke-roʿeh ʿedro yirʿeh, bi-zroʿo yeqabbeṣ ṭelaʾim u-ve-ḥeyqo yissaʾ*, he will feed his flock like a shepherd, gather the lambs in his arm, and carry them in his bosom.

**Two shepherds, one flock, no reconciliation.** That is the structure and Ezekiel 34 is the passage that states both in one chapter and leaves them standing.

Three observations before the chapters that follow.

**The metaphor is agricultural and the corpus does not romanticize it.** Sheep are property. A shepherd who eats the fat and clothes himself with the wool is doing what a shepherd is for; Ezekiel 34:3's indictment is not that he takes the produce but that he does not feed the flock. The image carries an economics.

**The metaphor is applied to foreign rulers too.** Isaiah 44:28 calls Cyrus *roʿi*, my shepherd. Jeremiah 25:34-36 addresses the shepherds and the principals of the flock in an oracle against the nations. Nahum 3:18 has the shepherds of Assyria slumbering.

**And the metaphor's most famous instance has the king as the sheep.** Psalm 23, attributed to David. Chapter 96 works it.

## CHAPTER 95 · Ezekiel 34 · The Indictment and the Substitution

The chapter has been used at Chapter 61 for one verse. This chapter reads it whole, because it is the corpus's most complete statement of the shepherd relation and its structure is an argument.

**Part one, the indictment.** 34:1-10. Woe to the shepherds of Israel who feed themselves. They eat the fat, clothe themselves with the wool, kill the fatlings, and do not feed the flock. The weak are not strengthened, the sick not healed, the broken not bound, the strayed not brought back, the lost not sought. *U-ve-ḥozqah reditem ʾotam u-ve-farekh*, and with force and with harshness you have ruled them.

The result at 34:5-6: *wa-tefuṣeynah mi-beli roʿeh wa-tihyeynah le-ʾokhlah le-khol ḥayyat ha-sadeh*, they were scattered for lack of a shepherd and became food for every beast of the field. They wandered on every mountain and hill, scattered on the face of the earth, *we-ʾeyn doresh we-ʾeyn mevaqqesh*, with none searching and none seeking.

**Part two, the removal.** 34:10. *Hineni ʾel ha-roʿim we-darashti ʾet ṣoʾni mi-yadam we-hishbattim me-reʿot ṣoʾn.* Behold I am against the shepherds and I will require my flock at their hand and cause them to cease from feeding the flock.

Two verbs there. *Darashti*, I will require, which is the verb the shepherds failed to perform at 34:6 where *ʾeyn doresh*, none searching. God does the searching the shepherds did not. And *hishbattim*, I will cause them to cease, from *šbt*, the cessation root of Genesis 2 used here for the termination of an office.

**Part three, the substitution, and it is the longest.** 34:11-16, eleven first-person verbs. I will search. I will seek out. I will deliver. I will bring out from the peoples. I will gather. I will bring in. I will feed. I will cause them to lie down. I will seek the lost. I will bring back the strayed. I will bind the broken. I will strengthen the sick.

**And 34:15 uses the terminus vocabulary.** *ʾAni ʾerʿeh ṣoʾni wa-ʾani ʾarbiṣem, neʾum ʾAdonay YHWH.* I will feed my flock and I will make them lie down. The verb *rbṣ* is the lying down of an animal at rest and it stands in the same field as the four roots without being one of them.

**Part four, the judgment within the flock.** 34:17-22. Between sheep and sheep, rams and goats. The fat sheep who have drunk the clear water and fouled the rest with their feet, who push with side and shoulder and thrust the weak with their horns. *We-hoshaʿti le-ṣoʾni we-loʾ tihyeynah ʿod la-vaz we-shafaṭti beyn seh la-seh.* I will save my flock and judge between sheep and sheep.

**Part five, the shepherd appointed.** 34:23-24. And I will raise up over them one shepherd and he shall feed them, my servant David. And I the LORD will be their God, and my servant David a prince in their midst.

**Part six, the covenant of peace and the terminus.** 34:25-31. A covenant of peace, evil beasts removed, dwelling securely in the wilderness and sleeping in the woods, showers of blessing, the tree of the field yielding fruit, the earth its increase, no more a prey to the nations, *we-yashvu la-veṭaḥ we-ʾeyn maḥarid*, dwelling securely with none making afraid.

**And the chapter closes on the possessive one last time.** 34:31: *we-ʾatten ṣoʾni ṣoʾn marʿiti ʾadam ʾattem, ʾani ʾeloheykhem.* And you are my flock, the flock of my pasture; you are men, and I am your God.

**The structure is the argument.** The shepherds fail. God removes them and does the work himself, in eleven verbs. Then he appoints a shepherd. Then he restates that he is their God and the flock is his.

**The appointment falls between two divine claims and is bracketed by them.** That is a placement, and this book takes it as one. The corpus could have run the sequence differently: failure, appointment, restoration. It runs it as failure, divine action, appointment, divine claim. The shepherd is installed inside a frame already occupied.

## CHAPTER 96 · Psalm 23 · The King Is the Sheep

*YHWH roʿi loʾ ʾeḥsar.*

The superscription is *mizmor le-Dawid*, a psalm of David, and whatever the preposition means, the corpus's tradition attaches the psalm to the king.

**The psalm makes its speaker a sheep and the whole of it follows from that.** He makes me lie down in green pastures, *bi-nʾot desheʾ yarbiṣeni*, using the same *rbṣ* as Ezekiel 34:15. He leads me beside still waters, *ʿal mey menuḥot yenahaleni*, and the noun is *menuḥot*, the plural of the settling-root nominal, in the terminus vocabulary. He restores my soul, *nafshi yeshovev*. He leads me in paths of righteousness *le-maʿan shemo*, for his name's sake.

**Three of the four opening clauses are causatives with God as subject.** He makes me lie down. He leads me. He restores. The speaker's verbs are the passive experience of being pastured.

**And the corpus has appointed this same speaker shepherd over God's flock.** 2 Samuel 5:2, the elders quoting divine speech: *ʾattah tirʿeh ʾet ʿammi ʾet Yisraʾel*. You shall shepherd my people Israel.

**So the corpus has one man as shepherd of the flock and as a sheep in it, and it states both.** That is the fifth of the ten pairs Book XIII counts, and it is the one that most resists being read as a redactional accident, since both statements attach to the same figure by the corpus's own attributions.

**The psalm's second half changes the metaphor.** Verses 5-6 move from pasture to table: *taʿarokh le-fanay shulḥan neged ṣoreray, dishanta va-shemen roʾshi kosi rewayah.* You prepare a table before me in the presence of my enemies; you anoint my head with oil; my cup overflows.

**The anointing verb here is *dšn*, not *mšḥ***, and it means to make fat or to enrich, used of the oil of hospitality rather than of installation. But the phrase is *va-shemen roʾshi*, oil on my head, which is the physical gesture of 1 Samuel 10:1's *wa-yiṣoq ʿal roʾsho*. The psalm attributed to the anointed king has God performing the oil-on-the-head gesture in the register of a host.

**And the closing verb is a dwelling.** *We-shavti be-veyt YHWH le-ʾorekh yamim.* The Masoretic pointing gives *we-shavti* from *yšb*, and I shall dwell, though the consonants also allow *šwb*, and I shall return. Either reading closes the psalm in a settling, in a house belonging to another.

**What the psalm establishes for Book X.** The corpus's most beloved statement of the shepherd relation is spoken by the sheep, and the corpus attributes it to the king. That is not an argument for anything by itself. Set beside Ezekiel 34's eleven possessives and 2 Samuel 5:2's *ʿammi*, it is a third witness that the corpus consistently holds the flock to be God's however many shepherds it appoints.

## CHAPTER 97 · The Shepherds Who Failed, Book by Book

The indictment of shepherds is not confined to Ezekiel and this chapter surveys the field, because a motif in four books is different from a motif in one.

**Jeremiah 23:1-2.** *Hoy roʿim meʾabbedim u-mefiṣim ʾet ṣoʾn marʿiti neʾum YHWH.* Woe to the shepherds who destroy and scatter the sheep of my pasture. And 23:2: *ʾattem hafiṣotem ʾet ṣoʾni wa-taddiḥum we-loʾ feqadtem ʾotam, hineni foqed ʿaleykhem ʾet roaʿ maʿalleykhem.* You have scattered my flock and driven them away and have not attended to them; behold, I attend to you for the evil of your doings.

The verb *pqd* used twice with opposite force: you did not attend to them, I attend to you. And *ṣoʾn marʿiti* and *ṣoʾni*, the possessive twice in two verses.

**Jeremiah 23:3-4 is the substitution, and it precedes the Branch oracle at 23:5.** *Wa-ʾani ʾaqabbeṣ ʾet sheʾerit ṣoʾni ... wa-hashivoti ʾethen ʿal nawehen ... wa-haqimoti ʿaleyhem roʿim we-raʿum.* And I will gather the remnant of my flock and bring them back to their fold, and I will set up shepherds over them who will feed them.

Note the plural: *roʿim*, shepherds, at 23:4, followed two verses later by the singular Branch at 23:5. The corpus places a plural restoration of the office and a singular figure in one oracle without harmonizing the number.

**Jeremiah 10:21.** *Ki nivʿaru ha-roʿim we-ʾet YHWH loʾ darashu, ʿal ken loʾ hiskilu we-khol marʿitam nafoṣah.* The shepherds are stupid and have not sought the LORD; therefore they have not prospered and all their flock is scattered. The failure is stated as a failure to seek, using *drš*, the same verb Ezekiel 34:6 uses for the searching the shepherds did not do.

**Zechariah 10:2-3 and 11:4-17.** 10:3: *ʿal ha-roʿim ḥarah ʾappi we-ʿal ha-ʿattudim ʾefqod*, my anger is kindled against the shepherds and I will punish the leaders. And chapter 11 is the extended sign-act of the worthless shepherd, with the two staves named *noʿam* and *ḥovelim*, favour and union, both broken, and the thirty pieces of silver weighed out as the shepherd's wages and thrown to the potter in the house of the LORD.

**Zechariah 13:7.** *Ḥerev ʿuri ʿal roʿi we-ʿal gever ʿamiti neʾum YHWH ṣevaʾot, hakh ʾet ha-roʿeh u-tefuṣeynah ha-ṣoʾn.* Awake, sword, against my shepherd and against the man who is my associate; strike the shepherd and the sheep shall be scattered.

That verse is difficult in every direction and this book does not attempt it. What it records is that the corpus contains an instruction to strike a shepherd whom it calls *roʿi*, my shepherd, and that the consequence stated is the scattering of the flock.

**Nahum 3:18 and Isaiah 56:11** carry the motif against Assyria and against Israel's watchmen respectively. Isaiah 56:11: *we-hemmah roʿim loʾ yadʿu havin, kullam le-darkam panu ʾish le-viṣʿo mi-qaṣehu*, and they are shepherds who cannot understand; they have all turned to their own way, each to his gain.

**The survey's result.** Five books carry the shepherd indictment: Jeremiah, Ezekiel, Zechariah, Isaiah, Nahum. The vocabulary is stable: scattering, not seeking, not attending, feeding themselves. And in every case the corrective is stated with God as subject, and where a new shepherd is appointed the appointing verb is *qwm* in the hiphil with God as its subject.

## CHAPTER 98 · The One Shepherd, and the Number Problem

Ezekiel 34:23 and 37:24 both say *roʿeh ʾeḥad*, one shepherd. Jeremiah 23:4 says *roʿim*, shepherds, plural, two verses before the singular Branch. This chapter takes the discrepancy seriously because it bears on how singular the corpus's expectation is.

**The singular sites.** Ezekiel 34:23: *wa-haqimoti ʿaleyhem roʿeh ʾeḥad we-raʿah ʾethen ʾet ʿavdi Dawid.* Ezekiel 37:24: *we-ʿavdi Dawid melekh ʿaleyhem we-roʿeh ʾeḥad yihyeh le-khullam.* Both use *ʾeḥad* and both name David.

**The plural sites.** Jeremiah 3:15: *we-natatti lakhem roʿim ke-libbi we-raʿu ʾetkhem deʿah we-haskel.* And I will give you shepherds after my own heart, who will feed you with knowledge and understanding. Jeremiah 23:4: *wa-haqimoti ʿaleyhem roʿim we-raʿum.*

**Jeremiah 3:15 deserves separate notice** because of what the shepherds are said to feed with. *De'ah we-haskel*, knowledge and understanding. That is the deficit inventory of Book IV supplied by shepherds, in the plural, in a passage with no singular figure. It is the closest the corpus comes anywhere to a transfer of the missing faculty through a human office, and it is plural and unnamed.

**Two readings of the number problem.**

**The developmental reading.** Jeremiah's plural is earlier and Ezekiel's singular is a later concentration of the expectation onto one figure. This is a common view and it is compatible with the standard datings.

**The functional reading.** The plural is the ordinary provision and the singular is a claim about unity: *ʾeḥad* in Ezekiel 34:23 and 37:24 is doing work against division, since 37:15-23 is the oracle of the two sticks joined into one, and 37:22 has *u-melekh ʾeḥad yihyeh le-khullam le-melekh*, one king for all of them. On this reading *ʾeḥad* is a numeral answering the two kingdoms rather than an assertion of singularity as such.

**The second reading has textual support in the immediate context** and this book prefers it while not requiring it. Ezekiel 37:22's one king stands in a sentence that also has *goy ʾeḥad*, one nation, and *loʾ yeḥaṣu ʿod li-shtey mamlakhot*, they shall no longer be divided into two kingdoms. Three occurrences of oneness in one verse, all of them about the reunification of a divided people.

**What the chapter establishes for the argument.** The corpus's shepherd expectation is not uniformly singular. It carries a plural provision in Jeremiah, a unifying singular in Ezekiel, and in the one case where a shepherd is said to supply the missing faculties, the shepherds are plural and anonymous.

That does not diminish the singular material. It fixes the range of what the corpus says, and a reading that presented the singular as the corpus's only shape would be selecting.

## CHAPTER 99 · Micah 5 · The One from Bethlehem, and Whose Strength

*We-ʾattah Beyt Leḥem ʾEfratah ṣaʿir li-hyot be-ʾalfey Yehudah, mimmekha li yeṣeʾ li-hyot moshel be-Yisraʾel, u-moṣaʾotaw mi-qedem mi-mey ʿolam.*

And you, Bethlehem Ephrathah, little to be among the clans of Judah, from you shall come forth for me one who is to be ruler in Israel, whose goings forth are from of old, from ancient days. Micah 5:1, which is 5:2 in English versions.

**The preposition is the datum.** *Mimmekha li yeṣeʾ*, from you shall come forth **for me**. The lamed of advantage on the divine first person. The figure comes out for God's benefit, which is 2 Chronicles 9:8's *la-YHWH ʾeloheykha* in a different book.

**The place is named as small.** *Ṣaʿir li-hyot be-ʾalfey Yehudah*, little to be among the thousands of Judah. The oracle begins with a diminishment.

**The origin clause is contested and this book does not build on it.** *U-moṣaʾotaw mi-qedem mi-mey ʿolam* can be read as a claim about the figure's antiquity, about the antiquity of his line, or about the ancient origin of the Bethlehem descent, since *qedem* and *ʿolam* both carry a durative rather than necessarily an eternal sense in this corpus. Compare Amos 9:11's *ki-mey ʿolam*, as in the days of old, which is plainly historical. Nothing in this chapter requires a decision.

**5:3 states the mode of his rule and it is entirely dependent.** *We-ʿamad we-raʿah be-ʿoz YHWH bi-geʾon shem YHWH ʾelohaw, we-yashavu ki ʿattah yigdal ʿad ʾafsey ʾareṣ.*

And he shall stand and shepherd **in the strength of the LORD**, in the majesty of the name of the LORD his God; and they shall dwell, for now he shall be great to the ends of the earth.

**Four features of that verse.**

*Be-ʿoz YHWH*, in the strength of the LORD. Not in his own.
*Bi-geʾon shem YHWH ʾelohaw*, in the majesty of the name of the LORD his God. The possessive: his God.
*We-yashavu*, and they shall dwell, using *yšb*, the settling verb of Deuteronomy 12:10's *wi-shavtem beṭaḥ*.
And *yigdal*, he shall be great, which is the one verb in the verse with the figure as subject, and it is intransitive.

**5:4 opens *we-hayah zeh shalom*, and this shall be peace**, which is one of the corpus's few statements identifying a figure with a state rather than describing his acts.

**The structural result.** Micah 5 is the corpus's most specific messianic oracle in the sense of naming a place, and its central verse states that the ruler shepherds in a strength that is named as somebody else's. The conferral grammar holds in the one passage most often read as a bare prediction.

## CHAPTER 100 · The Flock That Is Not Gathered by a Shepherd

Book X closes on a negative survey, which is the complement of Chapter 41's.

**The question.** Where the corpus states the gathering of the scattered flock, who gathers?

**Ezekiel 34:11-16.** God, eleven verbs, before any shepherd is mentioned.

**Jeremiah 23:3.** *Wa-ʾani ʾaqabbeṣ ʾet sheʾerit ṣoʾni mi-kol ha-ʾaraṣot.* And I will gather the remnant of my flock from all the countries. First person divine, and the shepherds are appointed in the next verse, after the gathering.

**Isaiah 40:11.** *Ke-roʿeh ʿedro yirʿeh, bi-zroʿo yeqabbeṣ ṭelaʾim u-ve-ḥeyqo yissaʾ, ʿalot yenahel.* He will feed his flock like a shepherd; with his arm he will gather the lambs and carry them in his bosom and gently lead those with young. The subject from 40:10 is *ʾAdonay YHWH*.

**Isaiah 56:8.** *Neʾum ʾAdonay YHWH meqabbeṣ nidḥey Yisraʾel, ʿod ʾaqabbeṣ ʿalaw le-niqbaṣaw.* Thus says the Lord GOD who gathers the outcasts of Israel: I will gather yet others to him besides those already gathered.

**Deuteronomy 30:3-4.** *We-shav YHWH ʾeloheykha ʾet shevutekha we-riḥamekha we-shav we-qibbeṣkha mi-kol ha-ʿammim.* Divine subject throughout.

**Ezekiel 36:24.** *We-laqaḥti ʾetkhem min ha-goyim we-qibbaṣti ʾetkhem mi-kol ha-ʾaraṣot.* First person divine.

**Micah 2:12.** *ʾAsof ʾeʾesof Yaʿaqov kullakh, qabbeṣ ʾaqabbeṣ sheʾerit Yisraʾel.* Two infinitive absolutes with first-person divine imperfects.

**Psalm 147:2.** *Boneh Yerushalayim YHWH, nidḥey Yisraʾel yekhannes.* The LORD builds Jerusalem; he gathers the outcasts of Israel.

**Eight sites in six books. In every one the gatherer is God.**

This book has found no passage in which a royal or messianic figure is the grammatical subject of the gathering. Chapter 41 stated the analogous negative about the terminus and stated how to break it. The same applies here: produce one verse in which a figure gathers, and the claim falls.

**Two near-cases, named so they are not mistaken for finds.**

**Ezekiel 34:23** appoints a shepherd who *feeds*, *we-raʿah ʾethen*, after the gathering has been narrated in first-person divine verbs at 34:11-16. Feeding after a gathering is not gathering.

**Jeremiah 23:4** appoints shepherds who *feed*, again after 23:3's divine gathering.

The corpus is consistent on the division of labour. God gathers; the appointed shepherd feeds. And the flock, throughout, is called God's.

## CHAPTER 101 · What the Shepherd Material Establishes

Five results, each checkable.

**The flock's ownership never transfers.** In every passage where a human shepherd is appointed, the flock is called God's in the same passage or the immediately surrounding one. Ezekiel 34 does it eleven times. 2 Samuel 5:2 does it in the appointing sentence. Jeremiah 23:1-3 does it three times before appointing.

**The appointing verb is causative with God as subject.** *Wa-haqimoti* at Ezekiel 34:23, Jeremiah 23:4, and Jeremiah 30:9. *We-natatti* at Jeremiah 3:15. The pattern of Chapter 62 holds in the pastoral register.

**The gathering is never a figure's act.** Eight sites, six books, one subject.

**God is himself the shepherd, in the same corpus, without reconciliation.** Psalm 23, Psalm 80, Genesis 48:15, Isaiah 40:11, and the eleven verbs of Ezekiel 34:11-16. The corpus holds the divine shepherd and the appointed shepherd together and Ezekiel 34:24 states both in one sentence.

**And the king appears as a sheep in the psalm the corpus attributes to him.** Psalm 23:1.

Two closing notes.

**This book does not claim the appointed shepherd is unimportant.** Ezekiel 34:23-24 and 37:24-25 are strong statements and Micah 5:1-4 is stronger. The claim is about the division of functions the corpus states, and the division is: God owns, God gathers, God is himself shepherd, and the appointed shepherd feeds and is a prince in their midst.

**And the pastoral material converges with Book VI from a different direction.** Book VI read conferral verbs in royal texts. Book X has read possessives and appointing verbs in pastoral texts. Two vocabularies, two image-fields, one result. That convergence is the same kind Chapter 62 noted between the census and the conferral grammar, and it is the reason this book's central claim is stated as a finding rather than as a reading.
