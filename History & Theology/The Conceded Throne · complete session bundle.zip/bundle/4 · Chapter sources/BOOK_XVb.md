# BOOK XVI · THE SILENCES

## CHAPTER 141 · What the Wisdom Books Do Not Say

Proverbs, Job, Ecclesiastes, and Song of Songs contain no messianic material. That is a large silence in a large body of writing and it deserves a chapter rather than an omission.

**Proverbs.** Thirty-one chapters. Kings appear constantly and always as present institutions to be advised, feared, or observed: 16:10-15, 20:2, 20:8, 20:26, 20:28, 21:1, 25:2-7, 29:4, 29:14, 31:1-9. Not one passage anticipates a coming king.

**And the book's statements about kingship are conditional and moral.** 16:12: *toʿavat melakhim ʿasot reshaʿ ki vi-ṣdaqah yikkon kisseʾ*, it is an abomination to kings to do wickedness, for the throne is established by righteousness. 29:14: *melekh shofeṭ be-ʾemet dallim kisʾo la-ʿad yikkon*, the king who judges the poor with truth, his throne shall be established forever.

The permanence of a throne is stated conditionally in Proverbs and unconditionally in 2 Samuel 7. The corpus carries both.

**Job.** Forty-two chapters on suffering, justice, and the limits of human understanding, with no royal figure and no future expectation of one. Its one contribution to this book is the tree of 14:7-9.

**And Job's answer is a whirlwind, not a deliverer.** Chapters 38 through 41 are a divine speech consisting almost entirely of questions about the natural world, and the resolution at 42:5 is *le-shemaʿ ʾozen shemaʿtikha we-ʿattah ʿeyni raʾatka*, I had heard of you by the hearing of the ear, but now my eye sees you.

**That verse belongs to Book IV.** The corpus's most sustained treatment of unexplained suffering resolves in a shift from hearing to seeing, using both organs of the deficit inventory, with no figure anywhere in the book.

**Ecclesiastes.** Twelve chapters. A king is the ostensible speaker and the book's judgment on royal achievement is 2:4-11's catalogue of works, houses, vineyards, gardens, pools, servants, herds, silver, gold, singers, and the verdict *hakkol havel u-reʿut ruaḥ we-ʾeyn yitron taḥat ha-shamesh*. No coming figure.

**Song of Songs.** Eight chapters, no figure, and no relevance to this book beyond its inclusion in the count.

**The count.** Four books, roughly ninety-three chapters, and no messianic material. That is a substantial fraction of the corpus's non-narrative bulk.

## CHAPTER 142 · Why the Silence Is Not an Argument, and What It Is

A silence proves nothing on its own and this chapter states what the wisdom silence can and cannot support.

**It cannot support a claim that the expectation is absent from the corpus.** Books VIII and XII documented eight stages across six books. The wisdom material's silence does not subtract from them.

**It cannot support a chronological claim.** The dating of the wisdom books is contested and a silence in an undated body of writing tells nothing about when anything was composed.

**It cannot support a claim that the wisdom writers rejected the expectation.** They do not discuss it. Non-discussion is not rejection.

**What it can support** is a claim about distribution, and distribution matters for one specific question.

The question is whether the messianic material is the corpus's organizing centre or one of its concerns. A reading on which it is the centre has to account for four books and ninety-three chapters that never mention it, in a corpus of twenty-four books.

**Two accounts are available and both are respectable.** On one, the wisdom books belong to a distinct genre with distinct concerns and their silence is generic rather than substantive, as a legal code's silence about poetry would be. On the other, the corpus contains multiple centres and the messianic material is one of them.

This book does not need to choose. It notes that the second account is the one its own argument fits, since Chapter 126 found six substantive contents and the terminus is one of six rather than the only one.

**And one positive finding sits inside the silence.** The wisdom books carry the corpus's densest treatment of the receiving faculty. Proverbs 2:2-5's *le-haqshiv la-ḥokhmah ʾoznekha taṭṭeh libbekha la-tevunah*, inclining your ear to wisdom and applying your heart to understanding. Proverbs 4:20-23's *li-devaray haṭṭeh ʾoznekha ... mi-kol mishmar neṣor libbekha*, incline your ear to my words, and keep your heart with all diligence. Proverbs 20:12: *ʾozen shomaʿat we-ʿayin roʾah, YHWH ʿasah gam sheneyhem*, the hearing ear and the seeing eye, the LORD made them both.

**That last verse is the deficit inventory's positive form**, and it attributes both organs to divine manufacture, in a book with no figure in it.

## CHAPTER 143 · The Covenant Formula, Across the Corpus

*We-hayiti lakhem le-ʾelohim we-ʾattem tihyu li le-ʿam.* I will be your God and you shall be my people.

The formula recurs across the corpus and it is worth counting, because Chapter 128 found it in the terminal position of two restoration sequences.

**Exodus 6:7.** *We-laqaḥti ʾetkhem li le-ʿam we-hayiti lakhem le-ʾelohim.* In the second commission to Moses, before the exodus.

**Leviticus 26:12.** *We-hithallakhti be-tokhekhem we-hayiti lakhem le-ʾelohim we-ʾattem tihyu li le-ʿam.* In the blessing section, before the curses that lead to the sabbath-accounting of 26:34.

**Deuteronomy 29:12.** *Le-maʿan haqim ʾotekha ha-yom lo le-ʿam we-huʾ yihyeh lekha le-ʾelohim.* In the covenant renewal, three verses before the not-given organ at 29:3 in the Hebrew numbering.

**Jeremiah 7:23.** *Shimʿu ve-qoli we-hayiti lakhem le-ʾelohim we-ʾattem tihyu li le-ʿam.* **Listen to my voice**, and I will be your God. The formula conditioned on the hearing.

**Jeremiah 11:4, 24:7, 30:22, 31:33, 32:38.** Five further occurrences, including the new covenant passage.

**Ezekiel 11:20, 14:11, 36:28, 37:23, 37:27.** Five occurrences, two of them in the terminal position Chapter 128 identified.

**Zechariah 8:8.** *We-hayu li le-ʿam wa-ʾani ʾehyeh lahem le-ʾelohim be-ʾemet u-vi-ṣdaqah.*

**Roughly fifteen occurrences across five books.**

**Three observations.**

**The formula is relational and contains no figure.** In fifteen occurrences there is no royal, priestly, or eschatological mediator anywhere in the clause.

**It stands at the terminal position of the two great restoration sequences.** Ezekiel 36:28 and 37:23, both after the gathering, the cleansing, and the new heart. Chapter 128 worked them.

**And Jeremiah 7:23 conditions it on the hearing.** *Shimʿu ve-qoli*, listen to my voice. The formula's one conditional statement makes the condition the faculty of Book IV.

**The relevance to this book's result.** Chapter 126 listed six substantive contents. The covenant formula is arguably a seventh, and it was not listed because it is a relation rather than a content and the criterion sorts contents. A reader who thinks it belongs in the list has a reasonable case and its addition would strengthen rather than change the result, since it is figure-free in all fifteen occurrences.

## CHAPTER 144 · The Places Where a Figure Would Have Fitted and Is Absent

A negative survey of a different kind. This chapter asks where in the corpus a royal figure would have been the natural thing to name, and finds him absent.

**At the covenant formula.** Fifteen occurrences, no mediator.

**At the direct remedies for the deficit.** Deuteronomy 30:6, Jeremiah 31:33-34, Ezekiel 36:26-27, Joel 3:1. Four passages, four books, no figure.

**At the gathering.** Eight sites, six books, God as subject in every one. Chapter 100.

**At the terminus.** Nine anchors across seven books with the strip as identity. Chapter 126.

**At Deuteronomy 30:11-14.** The passage that denies three modes of intermediation and states the word is in your mouth and in your heart.

**At Micah 6:8.** The corpus's answer to what is required, in three infinitives.

**At Jeremiah 9:22-23.** The subtraction of wisdom, might, and riches, leaving knowing God.

**At Deuteronomy 10:12-13.** The five infinitives.

**At Job's resolution.** 42:5, the shift from hearing to seeing.

**At Ecclesiastes' conclusion.** 12:13, *ʾet ha-ʾelohim yeraʾ we-ʾet miṣwotaw shemor ki zeh kol ha-ʾadam.*

**Ten locations.** Each is a place where the corpus states a requirement, a remedy, a terminus, or a resolution, and each is figure-free.

**What this establishes and does not.** It does not establish that the corpus lacks a messianic expectation; Books VIII and XII documented it in detail. It establishes that the corpus's statements of what is required, what is missing, what will fix it, and what it all arrives at are made, repeatedly and across the whole canon, without naming anyone.

That is the removability result of Chapter 126 restated as a survey rather than as a criterion's output, and it is offered as a second route to the same finding, since a result reachable two ways is worth more than a result reachable one.

## CHAPTER 145 · The Two Vocabularies, Set Side by Side

Book XVI closes with the comparison the whole study has been assembling.

**The figure vocabulary.** *Mashiaḥ*, anointed. *Melekh*, king. *Nagid*, prince or designate. *Nasiʾ*, prince. *Roʿeh*, shepherd. *Ṣemaḥ*, branch. *Ḥoṭer* and *neṣer*, shoot and branch. *Ben*, son. *ʿEved*, servant. *Bar ʾenash*, one like a son of man.

**Its characteristic grammar.** Passive or divine-subject. Fifteen sites at Appendix D, plus the escalation's eight stages at Appendix G, plus the pastoral appointments of Book X. No exception found.

**Its characteristic content.** A dominion, a throne, a name, a spirit, a portion, a task. What the figure is given.

**The terminus vocabulary.** *Menuḥah* and the four roots. *Deʿah*, knowledge. *Shalom* at the edge of the field. The war-cessation clauses. The knowledge-filling clauses.

**Its characteristic grammar.** Stative, agentless, or with the people as subject of an entering. *Baʾ ʾel* at Deuteronomy 12:9 and Psalm 95:11. *Maleʾah ha-ʾareṣ* at Isaiah 11:9. *Loʾ yilmedu ʿod milḥamah* at Isaiah 2:4.

**Its characteristic content.** A state. What is entered or not entered.

**The deficit vocabulary.** *Lev*, *ʿeynayim*, *ʾoznayim*. Heart, eyes, ears. Plus *shmʿ*, to hear, and *ydʿ*, to know, and *zkr*, to remember.

**Its characteristic grammar.** A negation attached to an organ. Not given, made heavy, shut, possessed and not functioning, hardened, forgot.

**Three vocabularies. Three grammars. And the corpus keeps them apart.**

Where it addresses the deficit directly, it uses the deficit vocabulary with God as subject and no figure present. Where it escalates the figure, it uses the figure vocabulary with conferral grammar. Where it names the destination, it uses the terminus vocabulary with stative or entering grammar.

**The three meet in exactly one passage and the meeting is partial.** Isaiah 11: the figure receives a spirit of knowledge and does not judge by eyes or ears, at 11:2-3; and the earth is full of knowledge, at 11:9. Chapter 84 read the gap between them.

**That is the finding, stated at the end of the survey rather than at its beginning.** Not that the figure is unreal, not that the expectation is mistaken, not that the material is late. That the corpus maintains three vocabularies with three grammars, uses each for its own object, and does not join them.

The road is real and the corpus commands it. The destination is named separately and named often. And the deficit that keeps the two apart is stated in the same three organs, in the same words, from Deuteronomy to Ezekiel, and is never reported as met.
