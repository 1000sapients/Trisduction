# BOOK XVII · THE SERVANT

## CHAPTER 146 · Why the Servant Material Needs Its Own Book

The servant passages of Isaiah 40 through 55 are the most contested body of material in the Hebrew Bible and they are central to any account of the corpus's expectation. Book XII gave them one chapter. They need more, for three reasons.

**The identification is genuinely open and the corpus itself supplies evidence on both sides.** Isaiah 49:3 names the servant Israel. Isaiah 49:6 gives him a mission to Israel. The corpus states both, four verses apart, in one oracle, and this book's habit is to record such pairs rather than resolve them.

**The material carries the corpus's most extended account of a figure who suffers**, and any reading of the messianic position that omits it is omitting the passage most readers would name first.

**And the material contains the corpus's own application of the deficit inventory to the figure**, at Isaiah 42:19, which Chapter 34 worked and which forecloses a whole class of triumphal reading.

**Four passages are conventionally isolated as the servant songs**: 42:1-4, with 42:5-9 often attached; 49:1-6, with 49:7-13 often attached; 50:4-9, with 50:10-11 often attached; and 52:13-53:12. The isolation is Duhm's and it is a scholarly convention rather than a feature of the text. This book uses the convention as a convenience and notes that the servant appears outside the four songs as well, at 41:8-9, 43:10, 44:1-2, 44:21, 45:4, 48:20, and elsewhere, and that in most of those the servant is explicitly Israel or Jacob.

**That distribution is the first datum.** Outside the four songs, the servant is named Israel or Jacob roughly a dozen times. Inside them the identification is harder. Any reading has to account for both.

## CHAPTER 147 · The First Song · Isaiah 42:1-9

*Hen ʿavdi ʾetmokh bo, beḥiri raṣetah nafshi, natatti ruḥi ʿalaw mishpaṭ la-goyim yoṣiʾ.*

Behold my servant whom I uphold, my chosen in whom my soul delights; I have put my spirit upon him; he shall bring forth justice to the nations.

**Four divine verbs in the first line.** I uphold. My chosen. My soul delights. I have put my spirit upon him. The servant's own verb, *yoṣiʾ*, he shall bring forth, is the fifth and comes last.

**The mode of operation is stated negatively and it is striking.** 42:2: *loʾ yiṣʿaq we-loʾ yissaʾ we-loʾ yashmiaʿ ba-ḥuṣ qolo.* He shall not cry out, nor lift up, nor make his voice heard in the street.

*Loʾ yiṣʿaq*, he shall not cry out, uses the outcry verb of 1 Samuel 8:18 and the Judges cycle. The servant does not perform the covenant outcry.

**42:3.** *Qaneh raṣuṣ loʾ yishbor u-fishtah kehah loʾ yekhabbennah, le-ʾemet yoṣiʾ mishpaṭ.* A bruised reed he will not break, and a dimly burning wick he will not quench; he will bring forth justice in truth.

**42:4.** *Loʾ yikhheh we-loʾ yaruṣ ʿad yasim ba-ʾareṣ mishpaṭ.* He will not grow dim nor be bruised until he has established justice in the earth.

The two verbs of 42:4 are the two of 42:3 turned back on the servant: he will not be *dimmed*, as the wick, nor *bruised*, as the reed. The corpus writes the servant into the same categories as those he protects.

**And then 42:5-9 supplies the conferral.** 42:6: *ʾani YHWH qeratikha ve-ṣedeq we-ʾaḥzeq be-yadekha we-ʾeṣṣorkha we-ʾettenkha li-verit ʿam le-ʾor goyim.* I the LORD have called you in righteousness and will hold your hand and keep you and give you as a covenant of the people, a light to the nations.

**Five first-person divine verbs.** I have called. I will hold. I will keep. I will give. And 42:7's purpose: to open blind eyes, to bring out prisoners from the dungeon, those who sit in darkness from the prison house.

**To open blind eyes.** *Li-fqoaḥ ʿeynayim ʿiwrot.* The deficit inventory, and here the servant's stated task is to address it.

**That is the single strongest counterexample to Chapter 84's finding and it is stated here at full strength.** Chapter 84 asked for a passage in which a figure opens an ear or gives a heart. Isaiah 42:7 has a servant opening blind eyes.

**Three things bear on how much weight it carries.** The infinitive is subordinate to 42:6's divine giving, so the servant is given as the instrument of an opening whose agent is the giver. The blindness at 42:7 is paired with imprisonment and darkness, which suggests a release-image rather than the cognitive deficit of 42:19. And 42:19, twelve verses later, applies the blindness to the servant himself, which makes a straightforward reading of 42:7 as the servant curing what he does not have difficult.

**This book records the counterexample, states the three considerations, and does not claim they dispose of it.** Chapter 84's finding should be read as narrowed by Isaiah 42:7 rather than as untouched by it.

## CHAPTER 148 · Isaiah 42:19 · The Servant in the Category

Chapter 34 worked this verse and it is restated here because Book XVII is where it does the most work.

*Mi ʿiwwer ki ʾim ʿavdi, we-ḥeresh ke-malʾakhi ʾeshlaḥ.*

Who is blind but my servant, and deaf as my messenger whom I send?

**Twelve verses after 42:7's opening of blind eyes, the servant is the blind one.**

Two readings of the juxtaposition are available.

**The two-servant reading.** 42:1-9's servant and 42:19's servant are different figures, the first an individual and the second Israel. This is a common view and it makes the chapter coherent at the cost of positing two referents for one word in one chapter.

**The one-servant reading.** The chapter is doing something deliberate: the servant commissioned to open eyes is himself blind, and the corpus states it. This is harder and it is the reading the text as it stands most nearly supports, since 42:19 gives no signal of a change of referent.

**This book does not choose** and notes that on either reading the corpus has placed the two verses in one chapter and left the relation unstated.

**And on either reading the fence of Chapter 34 holds.** The corpus applies the deficit diagnostic to a figure it calls *ʿavdi*, *malʾakhi*, *meshullam*, and *ʿeved YHWH*. Whoever that is, the polemical use of the motif is foreclosed.

**42:20's final clause remains the sharpest formulation in the corpus.** *Paqoaḥ ʾoznayim we-loʾ yishmaʿ.* Opening the ears and he does not hear. The infinitive absolute describes a state of openness and the negation attaches to the function. The organ is not sealed; it is open and not receiving.

**And 42:18 issues the imperative to the deficient party.** *Ha-ḥershim shemaʿu we-ha-ʿiwrim habbiṭu lirʾot.* You deaf, hear; you blind, look and see. The same shape as Jeremiah 6:16: a command addressed to a party the corpus has just described as unable, with no acknowledgement of the difficulty.

## CHAPTER 149 · The Second Song · Isaiah 49:1-6

*Shimʿu ʾiyyim ʾelay we-haqshivu leʾummim me-raḥoq, YHWH mi-beṭen qeraʾani mi-meʿey ʾimmi hizkir shemi.*

Listen, coastlands, to me, and attend, peoples from afar. The LORD called me from the womb; from my mother's body he named my name.

**The song opens in the servant's own voice and its first clause is a hearing imperative addressed to the nations.**

**Two divine verbs in the first line.** He called me. He named my name. Both from before birth.

**49:2 supplies the equipment.** *Wa-yasem pi ke-ḥerev ḥaddah, be-ṣel yado heḥbiʾani, wa-yesimeni le-ḥeṣ barur, be-ʾashpato hisstirani.* He made my mouth like a sharp sword; in the shadow of his hand he hid me; he made me a polished arrow; in his quiver he concealed me.

**Four verbs, all divine, and two of them are concealments.** Hid me, concealed me. The servant is equipped and stored.

**49:3.** *Wa-yoʾmer li ʿavdi ʾattah, Yisraʾel ʾasher bekha ʾetpaʾar.* And he said to me: you are my servant, Israel, in whom I will be glorified.

**49:4 is the complaint.** *Wa-ʾani ʾamarti le-riq yagaʿti, le-tohu we-hevel koḥi khilleyti, ʾakhen mishpaṭi ʾet YHWH u-feʿullati ʾet ʾelohay.* And I said, I have laboured in vain, I have spent my strength for nothing and vanity; yet surely my judgment is with the LORD and my recompense with my God.

**The servant reports failure and locates his vindication elsewhere.** *Mishpaṭi ʾet YHWH*, my case is with the LORD. The verb *khilleyti*, I have spent or finished, is from *klh*, the verb of Genesis 2:2's *wa-yikhal ʾelohim*. The servant's strength is completed as the creation's work was.

**49:5-6 is the expansion.** *We-ʿattah ʾamar YHWH yoṣri mi-beṭen le-ʿeved lo le-shovev Yaʿaqov ʾelaw we-Yisraʾel lo yeʾasef.* And now the LORD says, who formed me from the womb to be his servant, to bring Jacob back to him and that Israel be gathered to him.

**49:6.** *Naqel mi-hyotekha li ʿeved le-haqim ʾet shivṭey Yaʿaqov u-neṣurey Yisraʾel le-hashiv, u-netattikha le-ʾor goyim li-hyot yeshuʿati ʿad qeṣeh ha-ʾareṣ.* It is too light a thing that you should be my servant to raise up the tribes of Jacob and restore the preserved of Israel; I will give you as a light to the nations, that my salvation may reach to the end of the earth.

**The pair.** Named Israel at 49:3. Given a mission to Jacob and Israel at 49:5-6. Appendix E counts it as the third of the thirteen.

**Three readings of the pair.**

*Israel at 49:3 is a corporate designation and the servant is an individual within it who has a mission to the whole.* This is coherent and requires the name to function as a title.

*49:3's Israel is a gloss.* One medieval manuscript is often cited as omitting it. The textual evidence is thin.

*The servant is Israel and the mission at 49:6 is to a remnant.* This requires a distinction inside Israel that the text does not state.

**This book takes none** and records that the corpus states both and reconciles neither, which by Book XIII's count is the corpus's habit and not an anomaly.

**And the conferral grammar holds throughout.** Called, named, made, hid, made, concealed, formed, and *u-netattikha*, I will give you. Eight divine verbs in six verses, with the servant's own verbs being a speaking and a complaining.

## CHAPTER 150 · The Third Song · Isaiah 50:4-9

*ʾAdonay YHWH natan li leshon limmudim la-daʿat la-ʿut ʾet yaʿef davar, yaʿir ba-boqer ba-boqer yaʿir li ʾozen li-shmoaʿ ka-limmudim.*

The Lord GOD has given me the tongue of the taught, to know how to sustain the weary with a word; he wakens morning by morning, he wakens my ear to hear as the taught.

**This is the corpus's most direct statement of the deficit being addressed in an individual, and it is worth taking word by word.**

*Natan li*, has given me. The verb of giving, with God as subject and the servant as recipient.

*Leshon limmudim*, the tongue of the taught, or of disciples. The noun *limmudim* is a passive participle: those who have been taught.

*La-daʿat*, to know. The faculty of Deuteronomy 29:3's *lev la-daʿat*.

*Yaʿir li ʾozen*, he wakens my ear. The organ of the deficit, wakened by another.

*Li-shmoaʿ*, to hear. The faculty of Psalm 95:7 and 1 Samuel 8:19.

*Ba-boqer ba-boqer*, morning by morning. Repeated, continuous, not once.

**Five of Book IV's terms in two verses, all of them supplied by God, and the supply is daily rather than permanent.**

**50:5.** *ʾAdonay YHWH pataḥ li ʾozen we-ʾanokhi loʾ mariti ʾaḥor loʾ nesugoti.* The Lord GOD has opened my ear, and I was not rebellious, I did not turn backward.

*Pataḥ li ʾozen*, opened my ear. The passive of Isaiah 35:5's *tippataḥnah*. And then the servant's own response, stated negatively: I was not rebellious, I did not turn back.

**That is the exact inverse of Jeremiah 6:16.** There the paths stood and the answer was *loʾ nelekh*, we will not walk. Here the ear is opened and the answer is *loʾ mariti*, I was not rebellious.

**50:6 is the cost.** *Gewi natatti le-makkim u-leḥayay le-morṭim, panay loʾ histarti mi-kelimmot wa-roq.* I gave my back to those who struck, and my cheeks to those who plucked out the beard; I did not hide my face from shame and spitting.

**And 50:7-9 is the confidence, stated forensically.** *ʾAdonay YHWH yaʿazor li ʿal ken loʾ nikhlamti ... qarov maṣdiqi mi yariv ʾitti.* The Lord GOD helps me, therefore I am not confounded; he who vindicates me is near; who will contend with me?

**The whole song is a statement of received capacity and its consequences.** The tongue is given, the ear is wakened and opened, the response is compliance, the cost is violence, and the vindication is another's. Every faculty in the song is supplied and every outcome is attributed.

**And the song's own closing verses at 50:10-11 turn to the audience.** *Mi vakhem yereʾ YHWH shomeaʿ be-qol ʿavdo?* Who among you fears the LORD and listens to the voice of his servant? Followed by 50:11's warning to those who kindle their own fire and walk in the light of their own sparks: *mi-yadi haytah zoʾt lakhem le-maʿaṣevah tishkavun*, this you shall have from my hand: you shall lie down in sorrow.

The hearing imperative again, and the alternative to it stated as self-supplied light.

## CHAPTER 151 · The Fourth Song · Isaiah 52:13-53:12, and What This Book Says About It

The fourth song is the most read, most contested, and most consequential passage in the Hebrew Bible for the history of the traditions that carry it. This chapter states what this book can say about it and where it stops.

**What this book does not do.** It does not identify the servant. It does not adjudicate between the corporate and individual readings. It does not engage the passage's reception in any later corpus, which the scope law of Chapter 1 excludes. And it does not offer a reading of the substitution language, which is the passage's centre and the point at which every interpretive tradition has done its heaviest work.

**What it can say is grammatical and it is limited.**

**The opening is a conferral.** 52:13: *hinneh yaskil ʿavdi yarum we-nissaʾ we-gavah meʾod.* Behold my servant shall prosper; he shall be exalted and lifted up and be very high. *Yarum* and *we-nissaʾ* are elevation verbs, the second a nifal and therefore passive in form. *We-gavah* is the verb of 2 Chronicles 26:16's *gavah libbo*, here without the negative sense.

**The report is stated as unbelieved.** 53:1: *mi heʾemin li-shmuʿatenu u-zeroaʿ YHWH ʿal mi nigletah?* Who has believed our report, and to whom has the arm of the LORD been revealed?

*Li-shmuʿatenu*, our hearing, from *šmʿ*. The passage opens on a failure of reception, and the second clause asks to whom the arm has been revealed, which makes the revealing a divine act with limited scope.

**The appearance is stated as unremarkable.** 53:2: *loʾ toʾar lo we-loʾ hadar we-nirʾehu we-loʾ marʾeh we-neḥmedehu.* He had no form or majesty that we should look at him, no beauty that we should desire him.

*Hadar*, majesty, is the noun of Psalm 8:6's crowning with *kavod we-hadar* and of Psalm 45:4-5's royal address. The servant is described by the absence of the royal quality.

**And 53:2's opening image is vegetable.** *Wa-yaʿal ka-yoneq le-fanaw we-kha-shoresh me-ʾereṣ ṣiyyah.* He grew up like a young plant before him, and like a root out of dry ground.

*Ke-shoresh*, like a root. The noun of Job 14:8's persisting part and of Isaiah 11:1's second colon. And *me-ʾereṣ ṣiyyah*, from dry ground, which is the opposite of Job 14:9's *reaḥ mayim*, the scent of water.

**The divine verbs are present throughout the passage.** 53:6: *wa-YHWH hifgiaʿ bo ʾet ʿawon kullanu*, the LORD has laid on him the iniquity of us all. 53:10: *wa-YHWH ḥafeṣ dakkeʾo*, the LORD was pleased to crush him. And 53:12: *lakhen ʾaḥalleq lo va-rabbim*, therefore I will divide him a portion with the great.

**The servant's own verbs are few and most are passives or endurances.** He was despised. He was wounded. He was oppressed and afflicted. He opened not his mouth. He was cut off. He poured out his soul. He bore the sin of many.

**53:12's final clause is the one active intercession.** *We-la-poshʿim yafgiaʿ*, and he made intercession for the transgressors, using the same verb *pgʿ* as 53:6's laying-on, in a different stem.

**What this book takes.** The passage's conferral grammar is consistent with the fifteen sites of Appendix D, its opening turns on a failure of hearing, and its vegetable image is the root from dry ground rather than the shoot from a stump.

**What it leaves.** Everything else, which is most of the passage and all of what makes it what it is.

**And it states plainly why it leaves it.** A book constrained to one corpus can describe this passage's grammar. It cannot adjudicate an identification that two millennia of reading have not settled, and a study that offered one in a chapter would be pretending to a competence it has not demonstrated anywhere else.

## CHAPTER 152 · The Servant Who Is Named Israel

Outside the four songs, the servant is named. This chapter counts the namings, because they are the strongest evidence for the corporate reading and a book that treated the songs in isolation would be hiding them.

**Isaiah 41:8-9.** *We-ʾattah Yisraʾel ʿavdi, Yaʿaqov ʾasher beḥartikha, zeraʿ ʾAvraham ʾohavi. ʾAsher heḥezaqtikha mi-qeṣot ha-ʾareṣ ... wa-ʾomar lekha ʿavdi ʾattah, beḥartikha we-loʾ meʾastikha.* You, Israel, my servant, Jacob whom I have chosen, seed of Abraham my friend, whom I took from the ends of the earth and said to you, you are my servant; I have chosen you and not rejected you.

**Isaiah 44:1-2.** *We-ʿattah shemaʿ Yaʿaqov ʿavdi we-Yisraʾel baḥarti vo ... ʾal tiraʾ ʿavdi Yaʿaqov wi-Yshurun baḥarti vo.*

**Isaiah 44:21.** *Zekhor ʾelleh Yaʿaqov we-Yisraʾel ki ʿavdi ʾattah, yeṣartikha ʿeved li ʾattah, Yisraʾel loʾ tinnasheni.*

**Isaiah 45:4.** *Le-maʿan ʿavdi Yaʿaqov we-Yisraʾel beḥiri.*

**Isaiah 48:20.** *Gaʾal YHWH ʿavdo Yaʿaqov.*

**Isaiah 43:10.** *ʾAttem ʿeday neʾum YHWH we-ʿavdi ʾasher baḥarti.* You are my witnesses and my servant whom I have chosen. Plural addressees and a singular servant in one clause.

**Six namings, all Israel or Jacob, all in the same section of the book as the four songs.**

**And every one of them carries the conferral grammar.** I have chosen. I took. I said. I formed. I redeemed. The corporate servant holds what he holds on the same terms as the individual one.

**The chapter's finding.** Whatever the songs' servant is, the surrounding material's servant is Israel and the corpus says so six times. A reading that treats the songs' servant as straightforwardly individual has to explain the six, and a reading that treats him as straightforwardly corporate has to explain 49:5-6. Both explanations exist and both are respectable.

**This book's position is the one it has held throughout.** The corpus states both and reconciles neither, and Appendix E counts the pair.

## CHAPTER 153 · What the Servant Material Establishes

Five results.

**The conferral grammar holds.** Across all four songs and all six namings: called, chosen, upheld, given a spirit, held by the hand, kept, given as a covenant, formed from the womb, named, made a sword, hidden, made an arrow, concealed, given a tongue, wakened, opened, laid upon, and given a portion. Every one has God as subject.

**The deficit is applied to the servant.** At 42:19-20, in the corpus's sharpest formulation of it.

**And the deficit is addressed in the servant.** At 50:4-5, by a daily wakening and an opening of the ear, both divine acts, with the servant's response stated as a not-turning-back.

**Those two are not contradictory on the corpus's own terms.** A figure can be described as blind in one oracle and as having his ear opened morning by morning in another, and the second does not cancel the first if the opening is daily rather than permanent. This book offers that as an observation about the two passages' compatibility and not as a resolution of the servant question.

**The one counterexample to Chapter 84 stands and is narrowed.** Isaiah 42:7's opening of blind eyes is a servant's stated task. Chapter 147 gave three considerations bearing on how much weight it carries and did not claim they dispose of it. **Chapter 84's finding should be read as: the corpus states no passage in which a figure gives a heart or supplies knowledge to a people, and it states one in which a servant is given as a covenant and a light with the opening of blind eyes among the purposes.** That is a narrower claim than Chapter 84 made and it is the correct one.

**And the servant material is the corpus's strongest single body of evidence against a simple version of this book's reading.** A study that had not looked at it would have produced a cleaner argument and a worse one.

One closing note. Book XVII has declined to identify the servant, declined to read the substitution language, and declined to engage the passage's reception. Those are three large declinings in the corpus's most important passage. They follow from the scope law and from Chapter 8's list of things this book does not do, and a reader who finds them unsatisfying is finding the scope law unsatisfying, which is a legitimate position stated at Chapter 1 with its costs named.
