# PART THREE · FIFTEEN APPENDICES

## APPENDIX A · The Rest-Field Census · Method and Full Result

**What this is.** A machine pass over an English witness to the Hebrew Bible, executed to discharge as much as possible of the debt the seed article of this project named at its own section 13 and on which it capped its terminal strength.

**What it is not.** The Hebrew concordance the debt names. Chapter 13 states why no machine-readable Hebrew text was available in the working environment, Chapter 19 states the five things that remain owed, and both statements should be read before any figure below is used.

**The witness.** The Companion Bible, the Authorised Version of 1611 with E. W. Bullinger's structures and notes, 1913, in a machine-readable text layer derived from optical character recognition of page images. Thirty-five files covering Genesis through Malachi. The text layer is uncorrected and the editor's notes are interleaved with the verse text.

**Pass one · the raw field.**

Search terms, chosen as the Authorised Version's renderings of the four roots and their inflections: rest, rested, resteth, rests, resting, quiet, quietly, quietness, quieted, cease, ceased, ceaseth, ceasing, sabbath, sabbaths, ease, eased, repose, settled.

Result: **878 candidate sites.**

| Token | n | Token | n | Token | n |
|---|---|---|---|---|---|
| rest | 399 | rested | 27 | rests | 6 |
| sabbath | 134 | settled | 21 | quieted | 5 |
| cease | 83 | resting | 13 | quietly | 3 |
| quiet | 47 | ceaseth | 11 | resteth | 3 |
| sabbaths | 46 | quietness | 10 | repose | 2 |
| ease | 34 | ceased | 32 | ceasing | 1 |
| | | | | eased | 1 |

Two books return zero: Joel and Obadiah.

**Pass two · terminal position.**

Filter: the site's window contains a governing construction of giving, entering, granting, swearing, inheriting, or possessing. Deliberately generous; the residue is hand-sorted.

Result: **114 terminal-position candidates.**

| Book | n | Book | n |
|---|---|---|---|
| Chronicles I-II | 16 | Genesis | 4 |
| The Psalms | 13 | Job | 3 |
| Isaiah | 13 | Leviticus | 2 |
| Jeremiah | 9 | Numbers | 1 |
| Ezekiel | 9 | Ruth | 1 |
| Joshua | 8 | Samuel I-II | 1 |
| Deut. | 7 | Esther | 1 |
| Ezra-Neh. | 7 | Proverbs | 1 |
| Exodus | 5 | Daniel | 1 |
| Kings I-II | 5 | Habakkuk | 1 |
| Lament. | 5 | Zephaniah | 1 |

Token distribution within the 114: rest 72, sabbath 14, ease 5, cease 5, quiet 4, rested 3, sabbaths 3, ceased 2, quietness 2, and one each of resteth, rests, ceaseth, quietly.

**Pass three · the marking test.**

Test: does any royal or eschatological token stand anywhere in a 220-character window? Tokens searched: king, kings, messiah, anointed, David, Solomon, branch, shoot, prince, son of man, shepherd, servant of the LORD, throne, sceptre, reign, kingdom, ruler, deliverer, redeemer.

Machine result: **23 marked, 91 unmarked. 20.2 percent marked.**

Hand-sort of the 23:

| Class | n | Members |
|---|---|---|
| Editor's notes, not scripture | 6 | Bullinger's apparatus, including the Psalm 101 gloss of Appendix B |
| Wrong sense of the English word | 6 | Deut 3:13 remainder; sabbath-watch rotations at 2 Kgs 11:5, 11:9, 2 Chr 23:4; sabbath-day observance at Jer 17:25, Ezek 46:1-2 |
| Genuine terminus sites, king as recipient | 11 | listed at Appendix B |

**Post-sort: 103 unmarked, 11 marked-as-recipient, 0 marked-as-agent.**

**Pass four · the subject test.**

Query, run over all thirty-five files: any clause in which a royal or eschatological noun stands as grammatical subject of a giving-verb governing rest, quiet, quietness, or repose.

Result: **two hits, both dissolve.**

1 Chronicles 22:9, where the subject of *I will give* is God and Solomon is named in the following clause. The regex caught a proximity, not a subject.

Bullinger's note on Psalm 101: *of David. Relating to the true David, and His coming rule to give "rest" to the earth.* A commentator's gloss of 1913.

**Zero verses.**

## APPENDIX B · The Eleven Marked Terminus Sites

The eleven sites at which a royal figure stands in the window of a genuine terminus site. Every one has been checked by hand against the text.

| Site | Clause | Subject of the giving | King's role |
|---|---|---|---|
| 2 Sam 7:1 | *wa-YHWH heniaḥ lo mi-saviv* | YHWH | David, recipient |
| 1 Chr 22:9a | *hu yihyeh ʾish menuḥah* | none (predicate) | Solomon, described |
| 1 Chr 22:9b | *wa-hanihoti lo* | God, 1cs | Solomon, recipient |
| 1 Chr 22:9c | *we-shalom wa-sheqeṭ ʾetten ʿal Yisraʾel* | God, 1cs | Israel, recipient |
| 1 Chr 22:18 | *wa-heniaḥ lakhem mi-saviv* | YHWH | the leaders, recipient |
| 1 Chr 23:25 | *heniaḥ YHWH ʾelohey Yisraʾel le-ʿammo* | YHWH | the people, recipient |
| 2 Chr 14:6 | *ki heniaḥ YHWH lo* | YHWH | Asa, recipient |
| 2 Chr 15:15 | *wa-yanaḥ YHWH lahem mi-saviv* | YHWH | the people, recipient |
| 2 Chr 20:30a | *wa-yanaḥ lo ʾelohaw mi-saviv* | his God | Jehoshaphat, recipient |
| 2 Chr 20:30b | *wa-tishqoṭ malkhut Yehoshafaṭ* | none (land/realm) | Jehoshaphat, beneficiary |
| 2 Sam 7:1 (repeat token) | as above | YHWH | as above |

**Eleven for eleven. The giver is named in the clause and it is God. The king is recipient, described, or beneficiary.**

## APPENDIX C · The Meshiaḥ Concordance, Sorted

Thirty-nine occurrences of the noun, sorted by referent.

**Saul, fifteen.** 1 Sam 12:3, 12:5, 24:7 (twice), 24:11, 26:9, 26:11, 26:16, 26:23; 2 Sam 1:14, 1:16, 19:22, 23:1; and the group at 1 Sam 16:6 where Samuel is mistaken about Eliab.

**David or the Davidic king.** 2 Sam 22:51; Ps 18:51, 20:7, 28:8, 84:10, 89:39, 89:52, 132:10, 132:17; Lam 4:20; Hab 3:13; 2 Chr 6:42.

**The priest, four.** Lev 4:3, 4:5, 4:16, 6:15, all as *ha-kohen ha-mashiaḥ*.

**The patriarchs, two, plural.** Ps 105:15; 1 Chr 16:22, both *meshiḥay*.

**Cyrus, one.** Isa 45:1, *li-meshiḥo*.

**Daniel, two, contested.** Dan 9:25, 9:26.

**Results.**

The largest single group is Saul, the rejected king, at fifteen.

Six occurrences fall in laments over the office's failure: Ps 89:39, 89:52, 84:10, 132:10, Lam 4:20, Hab 3:13.

No occurrence in a determinable context designates a coming eschatological deliverer. Daniel 9 is contested and the royal psalms have been read that way; in every case where the referent is fixed by context it is a historical person.

All thirty-nine are passive participles. There is no cognate active noun in the corpus.

## APPENDIX D · The Conferral Grammar · Fifteen Sites

| Site | Clause | Form |
|---|---|---|
| Deut 17:15 | *ʾasher yivḥar YHWH ʾeloheykha bo* | God as subject of choosing |
| 1 Sam 8:22 | *we-himlakhta lahem melekh* | Samuel commanded to make |
| 2 Sam 7:8 | *ʾani leqaḥtikha min ha-nawah* | 1cs divine, king as object |
| 2 Sam 7:11 | *ki vayit yaʿaseh lekha YHWH* | God builds for him |
| 2 Sam 7:14 | *ʾani ʾehyeh lo le-ʾav* | relation constituted by declaration |
| Ps 2:6 | *wa-ʾani nasakhti malki* | 1cs divine |
| Ps 2:7 | *ʾani ha-yom yelidtikha* | 1cs divine, dated |
| Ps 2:8 | *sheʾal mimmenni we-ʾettenah* | conditional on petition |
| Ps 45:8 | *meshaḥakha ʾelohim ʾeloheykha* | God as subject of anointing |
| Ps 110:1 | *shev li-mini ʿad ʾashit* | imperative from giver, 1cs |
| Ps 110:4 | *nishbaʿ YHWH … ʾattah khohen* | oath, God as subject |
| 1 Chr 28:5 | *wa-yivḥar bi-Shelomoh veni* | God as subject of choosing |
| 1 Chr 29:23 | *wa-yeshev ʿal kisseʾ YHWH* | seat belongs to another |
| 2 Chr 9:8 | *le-titkha ʿal kisʾo … la-YHWH* | set on his throne, for him |
| Ezek 34:23 | *wa-haqimoti ʿaleyhem roʿeh ʾeḥad* | 1cs divine causative |
| Dan 7:14 | *we-leh yehiv sholṭan* | Aramaic peʿil, passive |

Sixteen rows for fifteen sites, since Psalm 110 supplies two. Six books, two languages, one grammar.

## APPENDIX E · The Thirteen Retained Pairs

| # | Barred or prosecuted | Seated or restored |
|---|---|---|
| 1 | Deut 23:4-7, Moabite and Ammonite barred to the tenth generation | Ruth 4:18-22, line sealed through Ruth *ha-Moʾaviyyah*; 1 Kgs 14:21, Naamah *ha-ʿAmmonit* |
| 2 | Jer 22:24-30, signet plucked from Coniah, *ʿariri* | Hag 2:23, signet restored to Zerubbabel, grandson at 1 Chr 3:17 |
| 3 | Isa 49:3, servant named Israel | Isa 49:6, servant distinguished from the tribes, four verses later |
| 4 | Jer 7:22; 1 Sam 15:22; Hos 6:6; Isa 1:11 | Ezek 40-48, offerings restored, prince's six lambs at 46:4 |
| 5 | Judg 8:23; 1 Sam 8:7, kingship refused and named a rejection | 1 Chr 29:23, king seated on the throne of the LORD |
| 6 | 1 Sam 8:11-18, itemized prosecution | Ps 45:7, throne addressed as *ʾelohim* |
| 7 | Num 25:12-13; Ezek 44:15, perpetual Aaronide priesthood | Ps 110:4, perpetual non-Aaronide, pre-Israelite order |
| 8 | Deut 7:1-3; Exod 34:15-16, *loʾ titḥatten bam* | The ancestry seated through those nations in seven instances, Appendix F |
| 9 | Job 14:8, the stump dies in the dust | Isa 11:1, the shoot comes from the stump |
| 10 | Ps 23:1, the king says *YHWH roʿi*; 2 Sam 5:2 sets him over *ʿammi* | Ezek 34:24, *ʿavdi Dawid nasiʾ* while God remains *le-ʾelohim*, flock *ṣoʾni* throughout |
| 11 | 2 Sam 7:15, withdrawal barred unconditionally | Ps 132:12, *ʾim yishmeru vaneykha beriti*, conditional |
| 12 | 1 Sam 8:18, outcry will go unanswered | Ps 72:12, the king delivers the needy *meshawweaʿ*, when he cries |
| 13 | 2 Kgs 10:30, Jehu approved for the bloodshed | Hos 1:4, that blood visited on his house |

Pair 9 is the most contestable and Chapter 88 states the objection.

## APPENDIX F · The Ancestry Through the Bar · Seven Instances

**Inside the Davidic line, as Ruth 4:18-22 enumerates it.**

| Figure | Foreign connection | Sites |
|---|---|---|
| Judah | *bat ʾish Kenaʿani*, Shua's daughter; her sons not the line; the line routes through Tamar, origin unsupplied | Gen 38:2; Ruth 4:18 |
| Boaz | Ruth *ha-Moʾaviyyah*, designated five times | Ruth 1:22, 2:2, 2:21, 4:5, 4:10 |
| David | the household of *ʾUriyyah ha-Ḥitti*, designated nine times | 2 Sam 11:3-24; 12:9-10; 23:39; 1 Kgs 15:5 |
| Solomon | successor's mother *Naʿamah ha-ʿAmmonit* | 1 Kgs 14:21, 14:31 |

**Outside the Davidic line.**

| Figure | Foreign connection | Sites |
|---|---|---|
| Ishmael | Hagar *ha-Miṣrit* | Gen 16:1, 16:3, 21:9, 25:12 |
| Joseph's sons | Asenath *bat Poṭi-Feraʿ khohen ʾOn* | Gen 41:45, 46:20 |
| Moses | Zipporah, daughter of the priest of Midian; *ha-ʾishah ha-Kushit*, with the objectors rebuked and the marriage not | Exod 2:21; Num 12:1-15 |

**And the prohibition is quoted at the breach**, 1 Kings 11:2.

## APPENDIX G · The Eight Stages

| # | Stage | Locus | Conferral form |
|---|---|---|---|
| 1 | Refusal | Judg 8:23 | *YHWH yimshol bakhem* |
| 2 | Concession | 1 Sam 8:22 | *we-himlakhta lahem melekh* |
| 3 | Permanence, withdrawal barred | 2 Sam 7:12-16, 7:15 | four divine establishing verbs |
| 4 | Cosmic vocabulary | Ps 2:7; 45:8; 110:1 | I begot, God anointed you, sit at my right hand |
| 5 | Throne-name | Isa 9:5-6 | two passives; *qinʾat YHWH ṣevaʾot taʿaseh zoʾt* |
| 6 | Regrowth after felling | Isa 11:1-2, from a *gezaʿ* | *we-naḥah ʿalaw ruaḥ YHWH* |
| 7 | Split into two | Zech 4:14; 6:13 | *hinneni meviʾ ʾet ʿavdi Ṣemaḥ* |
| 8 | Celestial conferral | Dan 7:13-14 | *yehiv*, Aramaic passive |

Stages 1 to 3 stand in narrative sequence in the corpus. Stages 4 to 8 are ordered by content. **No compositional dating is claimed.**

## APPENDIX H · The Deficit Inventory · Eleven Passages

| Site | Organs named | Form of the statement |
|---|---|---|
| Deut 29:3 | heart, eyes, ears | not given, *ʿad ha-yom ha-zeh* |
| Isa 6:9-10 | heart, ears, eyes | make fat, make heavy, shut |
| Isa 42:19-20 | eyes, ears | blind servant, deaf messenger, ears open and not hearing |
| Jer 5:21 | heart, eyes, ears | organs possessed, functions absent |
| Ezek 12:2 | eyes, ears | organs possessed, functions absent |
| Isa 43:8 | eyes, ears | blind people that have eyes |
| Isa 29:10 | eyes | spirit of deep sleep poured out |
| Ps 95:7-11 | heart | hardened; did not know my ways; did not enter |
| Jer 6:16 | none named | a refusal spoken and quoted |
| Deut 8:12-14 | heart, memory | satisfied, heart lifted, forgot |
| Ps 115:5-8 / 135:15-18 | eyes, ears, mouth, nose, hands, feet | applied to idols; those who trust become like them |

**The reversal, stated in the passive.** Isa 35:5, *tippaqaḥnah* and *tippataḥnah*, both nifal. Isa 29:18, the eyes of the blind shall see.

**And the direct remedies, with no figure in any of them.** Deut 30:6, circumcise the heart. Jer 31:33-34, write on the heart, and they shall all know me. Ezek 36:26-27, a new heart and a new spirit. Joel 3:1, the spirit poured on all flesh.

## APPENDIX I · Errata and Withdrawn Claims

Recorded rather than removed, because a study that reports only its surviving positions reports half a method.

**Killed by the corpus.**

*The partial-removability claim.* An earlier version held that the messianic frame was only partly removable because the restoration material could not be stated without the act-layer. **Ezekiel 37:14 falsified it**: the corpus states the terminus in the settling-root at the end of the act-sequence. Chapter 28.

*An asymmetry claimed against a comparative case* that rested on the above and fell with it.

**Withdrawn readings.**

*Zechariah 6:13 as fusing two offices in one person.* Withdrawn against *beyn shenehem*, between them both. A counsel between a man and himself is not a counsel. Chapter 80.

*A misuse of the Tyre oracle of Ezekiel 28* in an earlier draft, withdrawn.

**Corrections made during this book's own preparation.**

*A scope claim about the source corpus.* Books II and III of a companion study were described as Hebrew-Bible-alone on the strength of a citation count whose instrument had no pattern for Second Temple sources and therefore scored Enochic and Qumran chapters as clean. Measured properly they carry 70 and 66 such references. The error was in the instrument, and the correction is the reason this book was built fresh rather than cut from that one. Chapter 13's insistence on stating what an instrument cannot do is downstream of it.

*The census's own overstatement risk.* Chapter 18 reports 11 marked-as-recipient sites clustering in two related books and states the skeptic's reply in the same chapter rather than leaving it to a reader.

## APPENDIX J · The Boundary · Where Another Corpus Begins

**Fenced. Nothing in this appendix is load-bearing for any claim in this book, and no chapter cites it.**

The scope law of Chapter 1 admits the Hebrew Bible alone. This appendix names what is on the other side of that line and where the line falls, so that a reader who wants to cross it knows at which sentence the crossing happens and that this book does not make it.

**The Second Temple material.** The Enochic corpus, principally the Book of Parables, develops a pre-existent figure seated on a throne of glory and called the Son of Man, and does so in a way that engages Daniel 7 directly. Jubilees rewrites Genesis and Exodus with a calendar. The Qumran library carries two anointed figures, one priestly and one royal, a heavenly Melchizedek executing judgment in a final jubilee, and a body of interpretation of the very passages Books VIII and XII of this study read. Ben Sira praises the fathers. 4 Ezra and 2 Baruch respond to the destruction of 70.

**The rabbinic material.** The Mishnah, the two Talmuds, and the midrashic collections supply the treasury of unborn souls, the sabbath of history, the messiah at the gates of Rome, the two messiahs of Joseph and David, and a vast interpretive apparatus on every passage this book uses.

**The New Testament.** An occupancy claim and an extended argument for it, and the earliest sustained reading of the Hebrew royal material by a community that held it to be fulfilled.

**The Qurʾān.** A redescription of the whole prophetic line, a seal, and a distinct account of the figure the Gospels claim.

**Where the line falls.** At the last verse of Malachi in the Masoretic arrangement, and at the last citation in Book XIX. Every claim in Chapters 1 through 166 is checkable inside that boundary. Every corpus named above lies outside it and is engaged nowhere.

**Why the fence is stated rather than left implicit.** Because a study that excludes material without saying what it excludes invites the assumption that nothing was excluded, and the excluded material here is not marginal. It contains, arguably, the most developed messianic thought in the history of the traditions that carry this corpus. Its absence is a methodological choice with a stated cost.

## APPENDIX K · Glossary of Hebrew and Aramaic Terms

**ʾaṭad** · bramble, the thorny scrub of Jotham's fable, Judg 9:14.
**baʾ ʾel** · to come to, the verb of arrival at Deut 12:9 and Ps 95:11.
**benei ha-yiṣhar** · sons of the oil, Zech 4:14, a hapax expression.
**deror** · liberty, proclaimed at the jubilee, Lev 25:10.
**gezaʿ** · stump, the cut base of a tree. Three occurrences: Job 14:8, Isa 11:1, Isa 40:24.
**ḥoṭer** · shoot, Isa 11:1.
**kisseʾ YHWH** · throne of the LORD, 1 Chr 29:23; with *malkhut*, 1 Chr 28:5.
**lev** · heart, in this corpus the seat of thought and intention rather than of emotion.
**maṣṣevet** · standing part or stump of a felled tree, Isa 6:13.
**mashiaḥ** · anointed, passive participle of *mšḥ*. Thirty-nine occurrences, Appendix C.
**menuḥah** · resting-place, settled condition, nominal of *nwḥ*.
**margoaʿ** · repose, nominal of *rgʿ*, Jer 6:16.
**mšl** · to rule, the verb Gideon declines at Judg 8:23 and the root of *u-mosholo* at Zech 9:10.
**nagid** · prince, designate, leader. Used of Saul at 1 Sam 10:1 and of David at 2 Sam 5:2 and 7:8.
**nasiʾ** · prince, Ezekiel's preferred term for the figure, from *nśʾ*, to lift.
**naḥalah** · inheritance, paired with *menuḥah* at Deut 12:9. From *nḥl*, a different root.
**neṣer** · branch, Isa 11:1.
**nwḥ** · to settle, alight and stay. The promise's own root.
**qeren / pakh** · horn and flask, the two vessels of the anointing rite.
**rgʿ** · to have relief, repose at the end of a walk.
**ṣemaḥ** · branch, sprout. The title at Jer 23:5, 33:15, Zech 3:8, 6:12.
**šbt** · to cease. The root at Gen 2:2 and of the sabbath.
**shoresh** · root, the part Job 14:8 says persists.
**šqṭ** · to be quiet, undisturbed. The Judges refrain's root, with the land as subject.
**yehiv** · Aramaic peʿil, was given. Dan 7:14.

## APPENDIX L · Transliteration, Citation, and Conventions

**Transliteration.** Broad and academic. *š* for shin, *ṣ* for tsade, *ḥ* for het, *ṭ* for tet, *ʾ* for aleph, *ʿ* for ayin. Vowel length is not marked. Where a form appears in the running text with a different but recognizable spelling, the two refer to the same word.

**Text.** BHS, which is to say the Leningrad Codex with its apparatus. Where a reading is contested the contest is named at the point of use.

**Versification.** Hebrew numbering throughout. Where the English differs, the English number is given at first occurrence within that book. The principal instance is Isaiah 9:5, English 9:6. Excursus I sets out the general problem.

**Citation of books.** Full names in the running text. Standard abbreviations in tables.

**Honorifics.** Prophetic names carry the traditional honorific throughout: Musa AS, Ibrahim AS, and so on where they appear. This is a convention of the author's and is not an interpretive claim about the corpus.

**Chapter cross-references** are to this book's chapters, numbered continuously 1 through 166 across the nineteen books.

**What is quoted.** Hebrew is given in transliteration with a translation, and the translation is the author's unless otherwise indicated. Where a translation is contested, the contest is stated and the argument is built to hold under the alternatives.

## APPENDIX M · The Twenty-Four Books, and What Each Carries

A reader's index to where the four bodies of material in this study actually sit. **T** marks terminus vocabulary in a terminal position, **D** the deficit inventory, **F** royal-figure material, and **C** a conferral-grammar site tabulated at Appendix D. A hollow mark means a single passage rather than a body.

| Book | T | D | F | C |
|---|:--:|:--:|:--:|:--:|
| Genesis | ● | | ○ | |
| Exodus | ● | | | |
| Leviticus | ● | | | |
| Numbers | | | ○ | |
| Deut. | ● | ● | ○ | ● |
| Joshua | ● | | | |
| Judges | ● | | ● | |
| Samuel | ● | ● | ● | ● |
| Kings | ● | | ● | ● |
| Isaiah | ● | ● | ● | ● |
| Jeremiah | | ● | ● | ● |
| Ezekiel | ● | ● | ● | ● |
| The Twelve | ● | ● | ● | ● |
| Psalms | ● | ● | ● | ● |
| Proverbs | | ○ | | |
| Job | | ○ | | |
| Song | | | | |
| Ruth | | | ○ | |
| Lament. | | | ● | |
| Eccles. | | | | |
| Esther | | | | |
| Daniel | | ● | ● | ● |
| Ezra-Neh. | | ● | | |
| Chronicles | ● | | ● | ● |

**The principal sites, book by book**, in the order of the table. *Genesis* 2:2, the seventh position; 8:4, the ark settles; 14:18-22, Melchizedek; 38, Tamar; 49:10, contested. *Exodus* 18:13-24, Jethro; 20:8-11, remember; 25:8, a sanctuary; 29:7, Aaron anointed. *Leviticus* 4:3, the anointed priest; 8:12; 25, the three scales; 26:34-35, the land's sabbaths. *Numbers* 12:1-15, the Cushite woman; 24:17, Balaam's star; 25:12-13, the Aaronide grant. *Deuteronomy* 8:12-14; 10:12-13; 12:9-10; 17:14-20; 29:3; 30:6, 30:11-14, 30:19. *Joshua* 10:1, Adoni-Ṣedeq; 11:23; 21:44-45; 22:4; 23:1. *Judges* 3:11, 3:30, 5:31, 8:28, the quiet refrain; 8:23, the refusal; 9, the fable. *Samuel* 7:8-16; 8:5-22, the concession; 10:1 and 16:13, the anointings; 12, the farewell. *Kings* 8:12-56, the dedication; 11:1-13, the apostasy; 19:15-16, three anointings; 2 Kings 9, Jehu. *Isaiah* 2:4; 6:9-13; 9:5-6; 11:1-9; 40:11; 42:1-9 and 42:19; 45:1; 49:1-6; 50:4-9; 52:13-53:12; 66:1-2. *Jeremiah* 5:21; 6:16; 8:8; 22:24-30; 23:1-6; 31:31-34; 33:15-18. *Ezekiel* 12:2; 17 and 31, the trees; 34 entire; 36:24-28; 37:1-28; 40-48, the prince. *The Twelve* Hosea 1:4, 8:4, 13:11; Amos 5:18-24, 9:11; Micah 5:1-4, 6:8; Habakkuk 2:14, 2:19; Zephaniah 3:15; Haggai 2:9, 2:23; Zechariah 3, 4, 6, 9:9; Malachi 3:1, 3:23-24. *Psalms* 2; 8; 23; 45; 72; 89; 93-99; 95; 110; 115:5-8; 132. *Proverbs* 2:2-5; 4:20-23; 16:12; 20:12; 27:2; 29:14. *Job* 14:7-9, the tree; 42:5, hearing to seeing. *Ruth* 4:18-22, the genealogy. *Lamentations* 2:9; 4:20; 5:20-22. *Ecclesiastes* 2:4-11; 12:13. *Daniel* 2:34 and 2:44; 7:9-27; 9:4-19, the confession; 9:25-26, contested. *Ezra-Nehemiah* Ezra 1:1-4; 3:10-13; Nehemiah 9, five statements of the hearing failure. *Chronicles* 1 Chronicles 22:9-18; 23:25; 28:2-5; 29:11-23; 2 Chronicles 9:8; 14:6; 15:15; 20:30; 26:16; 32:25; 36:21-23. *Song of Songs* and *Esther* carry nothing used here.

**Five observations from the table.**

The terminus vocabulary is distributed across the Torah, the Former Prophets, Isaiah, Ezekiel, the Twelve, the Psalter, and Chronicles. It is not a Deuteronomistic peculiarity.

The deficit inventory appears in Deuteronomy, Samuel, Isaiah, Jeremiah, Ezekiel, the Psalter, Daniel, and Ezra-Nehemiah, and in Proverbs and Job in its positive form. It is the most widely distributed of the four.

Royal-figure material concentrates in Isaiah, Jeremiah, Ezekiel, four of the Twelve, the Psalter, and Chronicles, and is absent from five of the Twelve and from all four wisdom books.

Conferral-grammar sites appear in nine of the twenty-four.

And two books carry none of the four: Song of Songs and Esther.

## APPENDIX N · The Nine Terminus Anchors

Chapter 159 listed the terminus among six substantive contents and gave it nine anchors, more than any other. They are set out here with the operative clause in each, so that the strip can be checked verse by verse.

| Site | Clause | Figure in the pericope? |
|---|---|:--:|
| Deut 12:9 | *loʾ vaʾtem ʿad ʿattah ʾel ha-menuḥah* | no |
| Josh 21:44 | *wa-yanaḥ YHWH lahem mi-saviv* | no |
| 1 Kgs 8:56 | *natan menuḥah le-ʿammo Yisraʾel* | speaker is a king; recipient is the people; no figure in the clause |
| 1 Chr 22:9 | *hu yihyeh ʾish menuḥah … wa-hanihoti lo* | yes; the king is the recipient and God the giver |
| Ezek 37:14 | *we-hinnaḥti ʾetkhem ʿal ʾadmatkhem* | no; the figure enters the chapter at 37:22, a separate oracle |
| Ps 95:11 | *ʾim yevoʾun ʾel menuḥati* | no |
| Isa 11:9 | *maleʾah ha-ʾareṣ deʿah ʾet YHWH* | yes in the pericope, no in the clause; Chapter 29 works the *ki* |
| Isa 2:4 | *loʾ yilmedu ʿod milḥamah* | no |
| Hab 2:14 | *ki timmaleʾ ha-ʾareṣ la-daʿat ʾet kevod YHWH* | no |

**Six of the nine carry no figure anywhere in the pericope.** One has a king as recipient with the giver named. One has a king as speaker and the people as recipient. And one has a figure in the pericope and none in the clause, with the scope of the conjunction contested and stated as contested.

**Habakkuk 2:14 is the cleanest anchor in the set** and Chapter 29 says why: it states the knowledge-filling in almost the words of Isaiah 11:9, in a different book, in an oracle about the fall of a plunderer, with no figure anywhere in the vicinity. Under the criterion the content is substantive on the strength of that verse alone.

## APPENDIX O · A Reader's Route

The book is long and not every reader wants all of it. Four routes.

**The argument in eight chapters.** Chapter 2, the criterion. Chapter 22, the terminus named. Chapter 26, Psalm 95. Chapter 32, the deficit. Chapter 46, the itemized bill. Chapter 62, the conferral grammar. Chapter 82, the category substitution. Chapter 166, the conclusion.

**The evidence in five.** Chapter 17, the census's subject test. Chapter 41, nowhere a withheld terminus. Chapter 62, fifteen conferral sites. Chapter 100, the flock nobody gathers. Chapter 161, the purpose clauses.

**The objections, for a reader who wants to break it.** Chapter 6, the three falsifiers stated in advance. Chapter 39, the hardening problem this book declines to solve. Chapter 88, the most contestable pair. Chapter 139, the counterexample at Isaiah 42:7. Chapter 143, the largest omission. Chapter 163, the falsifiers returned. Chapter 165, the limits. Appendix I, the claims that died.

**And for a reader who wants only the method**, Book I entire, eight chapters, and Chapter 19 for what the census could not do.

**One route this book does not offer.** There is no summary that carries the argument without the verses. The claim is about what a corpus says and the only form in which it can be checked is the form in which the verses are quoted. A reader who wants the conclusion without the evidence is welcome to Chapter 166, and should treat it as an assertion rather than as a finding.

# BIBLIOGRAPHY

Sorted by function rather than alphabetically, because a reader needs to know which sources carry weight and which do not, and an alphabetical list conceals exactly that. Four of the nine sections below name things this study did not use, could not obtain, or holds at arm's length, and they are here because a bibliography is also where a reader looks for what a work did not read.

## I · THE PRIMARY CORPUS

**The Hebrew Bible.** Masoretic text, BHS, cited by the Hebrew chapter and verse divisions. This is the study's only seal-eligible register and the only body of writing from which any load-bearing claim is drawn.

**Thirty-three of the thirty-nine books are cited by chapter and verse.** In order of citation density: Isaiah 198, Psalms 160, Deuteronomy 129, Jeremiah 100, Ezekiel 79, 1 Samuel 72, 2 Samuel 61, Genesis 56, 1 Chronicles 56, 1 Kings 46, Exodus 40, 2 Chronicles 38, Leviticus 30, Joshua 26, Zechariah 25, Judges 23, Job 20, Hosea 20, 2 Kings 18, Daniel 17, Habakkuk 17, Numbers 15, Micah 13, Amos 11, Ruth 10, Lamentations 8, Haggai 7, Proverbs 6, Joel 6, Malachi 6, Ezra 5, Zephaniah 5, Nahum 2. **One thousand three hundred and twenty-five citations.**

**Six books are named but carry no verse citation, and the reasons differ.** Nehemiah is discussed at Chapter 148 for its ninth chapter, whose five statements of the hearing failure are quoted by verse without the book name repeated. Ecclesiastes and Song of Songs are surveyed at Chapter 133 for the absence of royal-figure material, which is what they contribute. Esther appears only in the census distribution table and in Appendix M. Obadiah is read at Chapter 116 for its closing verse and is one of the two books returning zero in the rest-field census. Jonah is not discussed anywhere, and that is the one book of the canon this study neither read nor accounted for.

**The Aramaic portions are inside the corpus and are load-bearing once.** Daniel 7:14's *yehiv* at Chapter 81, whose voice the whole of Book VIII's closing argument turns on.

**The principal loci.** Genesis 2:2-3; 8:4; 14:18-22; 28:18; 38; 49:10. Exodus 18:13-24; 20:8-11; 25:8-9; 29:7; 31:2-5; 40:9-15. Leviticus 4:3; 8:10-12; 25:1-55; 26:12, 26:34-35. Numbers 9:15-23; 12:1-15; 24:17-19; 25:12-13. Deuteronomy 8:12-18; 10:12-13; 12:9-11; 17:14-20; 18:15-22; 29:3; 30:1-20; 32:15. Joshua 10:1; 11:23; 21:44-45; 22:4; 23:1. Judges 3:11, 3:30, 5:31, 8:22-28; 9:7-20. 1 Samuel 8:5-22; 10:1; 12:1-25; 15:22-28; 16:6-13; 24:7; 26:9. 2 Samuel 2:4; 5:2-3; 6:6-9; 7:1-29; 12:7-9; 24:24. 1 Kings 1:39; 3:5-14; 8:12-56; 11:1-13; 19:15-16. 2 Kings 9:1-10; 10:30-31; 11:12; 25:27-30. 1 Chronicles 22:8-18; 23:25; 28:2-5; 29:11-23. 2 Chronicles 3:1; 9:8; 13:8; 14:6; 15:15; 20:30; 26:16; 32:25-26; 36:21-23. Job 14:7-9; 42:5. Psalms 2; 8:5-7; 16:9; 23; 45:7-8; 72; 89; 93-99; 95:7-11; 101; 105:15; 110; 115:5-8; 132; 135:15-18; 144:3-4; 147:2. Proverbs 16:12; 20:12; 27:2; 29:14. Isaiah 2:2-4; 6:1-13; 7:14; 9:5-6; 11:1-10; 14:7; 29:10, 29:18; 35:5; 40:11, 40:24, 40:28; 41:8-9; 42:1-9, 42:18-20; 43:8, 43:10; 44:1-2, 44:21, 44:28; 45:1-6; 48:20; 49:1-6; 50:4-11; 52:13-53:12; 54:7-10; 56:8, 56:11; 61:1; 66:1-2. Jeremiah 2:27; 3:15; 5:21; 6:16; 7:22-23; 8:8; 9:22-23; 10:21; 22:24-30; 23:1-6; 25:11; 29:10-14; 30:10; 31:31-34; 33:14-18. Lamentations 2:9; 3:21-24; 4:20; 5:20-22. Ezekiel 8-11; 12:2; 17:1-24; 22:26; 29:21; 31:1-12; 34:1-31; 36:24-28; 37:1-28; 40-48. Daniel 2:34, 2:44; 7:9-27; 9:4-19, 9:25-26. Hosea 1:4; 6:6; 8:4; 13:6, 13:11; 14:2. Joel 2:11; 3:1. Amos 5:18-24; 8:4; 9:11. Micah 2:12; 3:11-12; 5:1-4; 6:8; 7:14. Nahum 3:18. Habakkuk 2:4, 2:14, 2:19-20; 3:13. Zephaniah 1:14-18; 3:14-17. Haggai 2:3-9, 2:23. Zechariah 1:4; 3:8-9; 4:2-14; 6:11-13; 8:8; 9:9-10; 10:2-3; 11:4-17; 13:7. Malachi 2:7-8; 3:1-2, 3:23-24.

## II · THE ENGLISH WITNESS, USED AS AN INSTRUMENT AND NOT AS A SOURCE

**[1]** Bullinger, E. W., editor. *The Companion Bible: The Authorised Version of 1611 with the Structures and Notes, Critical, Explanatory and Suggestive, and with 198 Appendixes.* London: Oxford University Press, 1909-1922.

Used at Book II as the machine-readable English witness over which the rest-field census was executed. Text layer derived from optical character recognition of page images and uncorrected; Appendix A carries the provenance and Chapter 19 the five things the witness cannot support.

**It is unusual to cite a 1913 commentary as a research instrument rather than as a source of readings**, and the reason is stated at Chapter 13: no machine-readable Hebrew text of the Masoretic canon was obtainable in the working environment, and this was the only complete machine-readable witness to the corpus that was. Its interpretive content is used nowhere in this study except at Chapter 17, where its note on Psalm 101 is quoted as the census's most instructive single result.

## III · SCHOLARLY POSITIONS ENGAGED

Named as positions. This study states its relation to each and argues with none by name. Chapter 162 carries the full statement.

**[2]** von Rad, Gerhard. "There Remains Still a Rest for the People of God: An Investigation of a Biblical Conception." In *The Problem of the Hexateuch and Other Essays*, translated by E. W. Trueman Dicken. Edinburgh and London: Oliver and Boyd, 1966; New York: McGraw-Hill, 1966. Translated from *Gesammelte Studien zum Alten Testament*. Munich: Kaiser Verlag, 1958. Reprinted in *From Genesis to Chronicles: Explorations in Old Testament Theology*, edited by K. C. Hanson. Minneapolis: Fortress Press, 2005.

*Menuḥah* as land-gift, with an unresolved already-and-not-yet between Joshua and Psalm 95. **This study is downstream of it.** The seam is not claimed as new. What is added is the removability criterion of Chapter 2, the executed census of Book II, and the resulting sort of the royal material as means.

**[3]** Mowinckel, Sigmund. *He That Cometh: The Messiah Concept in the Old Testament and Later Judaism.* Translated by G. W. Anderson. Oxford: Basil Blackwell; New York: Abingdon Press, 1956. Norwegian original *Han som kommer*, 1951. Reprinted with a foreword by John J. Collins. Grand Rapids: Eerdmans, 2005.

Messianism as a comparatively late development not present in the pre-exilic royal texts. **Compatible.** The escalation sequence of Book VIII redescribes the same material by content and commits to no dating beyond the corpus's own narrative order for its first three stages.

**[4]** Noth, Martin. *The Deuteronomistic History.* Translated and introduced by David J. A. Clines and Philip R. Davies. JSOT Supplement Series 15. Sheffield: JSOT Press, 1981. Translation of *Überlieferungsgeschichtliche Studien*, pages 1-110 of the second edition. Tübingen: Max Niemeyer, 1957; first published 1943.

The Joshua-to-Kings material as a single editorial project. **Used, not adjudicated.** This study does not enter the hypothesis and does use the fact that it is available and widely held as a reason to treat that material as one witness where it would otherwise be treating four.

**Three further bodies of literature are engaged and named without individual citation**, because the claims made are about their general shape rather than about any one contributor.

**The source-critical treatment of 1 Samuel 8 through 12**, and the classical division into pro-monarchic and anti-monarchic strands. **No position taken**, per Chapter 52; the final form's retention of both is the datum, and without this literature Chapter 52 would have nothing to say.

**The literature on the sabbath as institution and sign. Adjacent.** This study's interest is in *menuḥah* as the promise's terminus rather than in observance, and it connects the two only through the root-field of Book II. A reader whose subject is the sabbath will find one paragraph at Chapter 37 that they could have written better.

**The literature on the hardening motif at Isaiah 6:9-10. Used differently.** Chapter 33 takes 6:9-10 with Deuteronomy 29:3, Isaiah 42:19, and Jeremiah 6:16 as a converging diagnosis of reception rather than as a problem about divine intent, and Chapter 39 states at length why this study declines to solve the problem the literature exists to solve.

**A submission version would carry each of the three at full apparatus.**

## IV · THE SOURCE STUDY

Prior work by the same hand, on which this study's spine rests. It was itself built scripture-internally and is superseded by nothing here.

**[5]** *A Shoot from a Felled Stump: The Conceded Throne. Menuḥah as Terminus, the Monarchy as Concession, and the Roots of the Jewish Messiah in the Hebrew Bible.*

The article states four things this book expands: the four rest-roots and the terminus named in the second of them; the concession engine in the corpus's own sequence; the location of the failure at the receiver; and the removability criterion with its two calibration cases. It states one debt and caps its own terminal strength on it, and Book II here is the discharge of as much of that debt as the available instruments allowed. Its title is this book's title, and Chapter 7 states why the seam it works is not claimed as new.

## V · THE INSTRUMENT DEPENDENCY, DECLARED

Itemised rather than left as a general admission, because Chapter 165's account of this study's limits would be incomplete without it.

**Concordances, lexica, and grammars** for Biblical Hebrew and Aramaic were used throughout and are indispensable to every philological claim in this book. Every root identification, every stem parsing, every statement about a word's distribution, and every count in Appendix K rests on them.

**Critical editions and apparatus** for the Hebrew text, and the standard treatments of the versional evidence named at Excursus XIII.

**These are products of exactly the scholarly traditions Chapter 1's constraint holds at arm's length, and there is no version of this study that does without them.**

The constraint was never a claim that those traditions produced nothing reliable. It is a claim about what may **settle** a question, and the instruments do not settle questions; they make the text legible so that the text can. That distinction is what makes the dependency consistent with the rule rather than an exception to it, and a reader who finds the distinction too convenient has this study's own statement, at Chapter 19 and at Chapter 165, that the debt is partially paid and partially outstanding.

## VI · WHAT WAS NOT AVAILABLE

Recorded because a method chapter that names a limit without naming its cause is asking to be taken on trust.

**No machine-readable Hebrew text of the Masoretic canon** was obtainable in the working environment where Book II's census was executed. Every attempt to obtain one is recorded and every attempt failed: no such corpus was present locally, and no package registry reachable from that environment carried one.

**This is a fact about the working conditions and not about the world.** A reader with Accordance, Logos, BibleWorks, a Even-Shoshan concordance, or any of several open Hebrew corpora can run the Hebrew-side census in an afternoon and should. Chapter 19 states the five things it would settle.

## VII · WHAT IS ABSENT, BY NAME

Declared here as well as at Appendix J, because a bibliography is where a reader looks for what a work read.

**No Second Temple or pseudepigraphal material.** No Enochic corpus, no Jubilees, no 4 Ezra or 2 Baruch, no Ben Sira, no Wisdom of Solomon.

**No Qumran material.** No Community Rule, no Damascus Document, no 11QMelchizedek, no 4Q521, no sigla of any kind.

**No rabbinic corpus.** No Mishnah, no Talmud, no midrashic collection, no Targum.

**No Josephus and no Philo.**

**No New Testament.**

**No Qurʾān.**

**No patristic, conciliar, medieval Jewish, or Shiʿi material.**

None of the above is cited anywhere in Chapters 1 through 166, and a verification gate enforces the exclusion against the finished text. Appendix J names the boundary and says what stands on the other side of it; Chapter 1 states the cost.

## VIII · WHAT WAS NOT SEARCHED

Distinct from what is absent, and more uncomfortable, because these are gaps inside the corpus this study did read.

**The wisdom books were surveyed for the absence of royal-figure material and not for the presence of terminus vocabulary.** Proverbs in particular carries a substantial body of material on the heart, the ear, and knowledge that a fuller treatment would work; Chapter 134 quotes three verses and there are more.

**The Song of Songs was not read** beyond confirming that it contains no royal-figure material, and Jonah was not read at all.

**The census's complementary field was not run**: the count of where a royal figure appears without the terminus vocabulary, which would say whether the two vocabularies avoid each other or merely fail to coincide. Chapter 19 names it as the single most useful further study this method suggests.

**The northern kingdom's royal theology** is examined only through what a Judahite corpus preserves of it, which is a formula of condemnation and one failed conditional promise. Excursus IX states the gap.

## IX · A NOTE ON THE SHORTNESS OF THIS LIST

Five numbered entries is a small apparatus for a book of this length, and the smallness is a consequence of the method rather than of the reading.

A study constrained to one corpus, arguing from that corpus's own grammar, and testing its claims against falsifiers executable inside that corpus, has few places where a citation could do load-bearing work. Where a scholarly position bears on the argument it is named as a position and this study's relation to it is stated; where an instrument was used it is declared at section V; and where a claim rests on the corpus it rests on a verse a reader can check.

**Every entry above was checked against the published record before this list was finalised**, and one was checked only after it was first drafted from recall: the translator, place, and publisher of entry [2] were supplied from memory in a first draft, then confirmed, and the German source named on that volume's own title page was added at the same time. The check is what the entry now rests on, and the order in which it happened is stated because a list that certifies itself should say when the certifying was done.

# AUTHOR DISCLOSURE

**Affiliation and funding.** The author is an independent researcher with no institutional affiliation and holds a doctorate in an unrelated field. No funding was received for this work and there are no competing financial or professional interests.

**Method.** The analysis was developed through extended interaction with an AI system used as a philological and adversarial-audit instrument. The author set the direction, supplied the primary sources, made the corrections that moved the argument, and bears full responsibility for every claim. The assistant performed concordance assembly, drafting, structural auditing, and the census of Book II. This disclosure is offered because the working method is unusual and a reader is entitled to know it, not because the argument rests on it; every claim is stated so that a reader with a Hebrew Bible and a concordance can check it without reference to how it was produced.

**Audit history.** Two findings that earlier drafts treated as central were killed by the corpus and are recorded as dead rather than removed, at Appendix I. Two errata are likewise carried on the record there.

**Standing.** The author writes from outside the guild and from a position of religious commitment, and states this plainly rather than implying a neutrality he does not have. The method is designed to make that irrelevant: the single-corpus constraint of Chapter 1, the stated criterion of Chapter 2, the executed census of Book II with its stated debt at Chapter 19, and the falsification criteria of Chapter 163 are there so that the argument can be checked by a reader who shares none of the author's commitments and rejected by one who shares all of them.
