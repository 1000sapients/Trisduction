# BOOK XVIII · THE EXILE AND THE RETURN

## CHAPTER 154 · The Corpus Narrates Its Own Catastrophe

The Hebrew Bible is, among other things, a body of writing that records the destruction of the institutions it describes, and it records it more than once and in more than one voice.

**2 Kings 25.** The siege, the famine, the breach of the city, the flight of Zedekiah, his capture in the plains of Jericho, the killing of his sons before his eyes, and then *we-ʾet ʿeyney Ṣidqiyyahu ʿiwwer*, and they blinded the eyes of Zedekiah. The temple burned, the great houses burned, the walls broken down, the bronze pillars broken in pieces and carried to Babylon.

**And the book ends with a meal.** 25:27-30: in the thirty-seventh year of the exile Evil-merodach lifted up the head of Jehoiachin, spoke kindly to him, set his throne above the thrones of the kings with him in Babylon, changed his prison garments, and *ʾakhal leḥem tamid le-fanaw kol yemey ḥayyaw*, he ate bread continually before him all the days of his life.

**The Deuteronomistic History closes on a Davidide eating at a foreign king's table.** That is the last thing the corpus's great historical work says.

**2 Chronicles 36 tells it differently.** The sabbath-accounting at 36:21, worked at Chapter 30, and then the decree of Cyrus at 36:22-23, which is the last thing in the Hebrew canon's arrangement. *Mi vakhem mi-kol ʿammo, YHWH ʾelohaw ʿimmo we-yaʿal.* Whoever is among you of all his people, may the LORD his God be with him, and let him go up.

**The corpus ends, in the received Jewish arrangement, on a permission to go up granted by a Persian king.**

**Lamentations supplies the third voice.** Five poems, four of them acrostics, on the destruction. 2:9: *melekhah we-sareha va-goyim ʾeyn torah, gam nevi'eha loʾ maṣʾu ḥazon me-YHWH.* Her king and her princes are among the nations; the law is no more; her prophets find no vision from the LORD. And 4:20's capture of the anointed in the pit.

**Three accounts, three endings.** A meal at a foreign table. A permission from a foreign king. And a lament that closes at 5:20-22 with *lammah la-neṣaḥ tishkaḥenu ... ki ʾim maʾos meʾastanu qaṣafta ʿaleynu ʿad meʾod*, why do you forget us forever, unless you have utterly rejected us and are exceedingly angry with us.

**And that final verse uses *mʾs*.** The verb of 1 Samuel 8:7 and 15:23. Lamentations closes on the possibility that the rejection ran the other way.

## CHAPTER 155 · What the Exile Does to the Argument

The exile is the event that makes the escalation legible and it is worth stating how.

**Before the exile the corpus has a monarchy, a temple, a land, and a promise.** After it the corpus has none of the first three and a community under Persian administration.

**The eight stages are therefore not distributed evenly across that break.** Stages one through four are set before it in the narrative. Stage five is set in the eighth century by its own context. Stage six is set in the same book. Stage seven is securely post-exilic. And stage eight is set in the exile by its narrative frame.

**Whatever the composition, the received arrangement places the highest stages at or after the catastrophe.**

That is what a reader would expect on any account. A community that has lost a king is more likely to produce material about a coming one than a community that has one, and the observation is old and not this book's.

**What the observation costs this book's argument, and it should be stated.** If the escalation is a response to catastrophe rather than a category substitution, then Chapter 82's finding is redescribed rather than refuted: the corpus escalated because it had lost what it had, and the escalation's failure to address the deficit is then a fact about grief rather than about logic.

**Two responses.**

**The redescription and the finding are compatible.** A community escalating under loss can still be escalating in a category that does not address the stated deficit, and the corpus's own diagnosis at Deuteronomy 29:3 and Psalm 95:11 predates the loss.

**And the deficit texts are themselves distributed across the break.** Deuteronomy 29:3 is pre-exilic on any account of Deuteronomy's setting. Isaiah 6 is eighth-century by its own dating. Jeremiah 6:16 is late pre-exilic. Ezekiel 12:2 is exilic. The diagnosis does not cluster at one end.

**What the exile does establish for this book** is the setting of Books XI and XIII. Psalm 89's complaint, Lamentations 4:20's captured anointed, and the Chronicler's relocation of the throne's ownership are all responses to the loss, and all three are in the corpus.

## CHAPTER 156 · The Return, and Who Is Credited With It

The corpus credits the return to three parties and the distribution is informative.

**To God.** Deuteronomy 30:3, Jeremiah 23:3, Ezekiel 36:24, Isaiah 56:8, Micah 2:12, Psalm 147:2. Chapter 100 counted eight sites.

**To Cyrus.** Isaiah 44:28 and 45:1-6, worked at Chapter 71. And 2 Chronicles 36:22-23 and Ezra 1:1-4, the decree.

**To no royal figure of Israel.** There is no passage in the corpus attributing the return to a Davidic king, a messiah, a branch, or any Israelite royal figure.

**And Ezra-Nehemiah, the corpus's own account of the return, contains no messianic material at all.**

That last point deserves a paragraph because it is easy to miss. Ezra and Nehemiah narrate the return, the rebuilding of the altar, the laying of the foundation, the opposition, the completion of the temple, the reading of the law, the covenant renewal, and the rebuilding of the wall. Across roughly twenty-three chapters there is no coming figure, no anointed one, and no expectation of one.

**The leaders named are Sheshbazzar, Zerubbabel, Jeshua, Ezra, and Nehemiah.** Zerubbabel is a Davidide by the genealogy at 1 Chronicles 3:19 and Haggai 2:23 calls him a signet. Ezra-Nehemiah does not.

**Nehemiah 9 is the return's great confession** and it is the longest historical recital in the corpus outside the Torah. It runs from creation through Abraham, the exodus, Sinai, the wilderness, the conquest, the judges, the prophets, and the exile, and it locates the failure repeatedly in the same place.

9:16: *we-hem wa-ʾavoteynu heziḏu wa-yaqshu ʾet ʿorpam we-loʾ shameʿu ʾel miṣwoteykha.* They and our fathers acted presumptuously and stiffened their neck and did not listen to your commandments.

9:17: *wa-yemaʾanu li-shmoaʿ*, and they refused to listen. The verb of 1 Samuel 8:19.

9:26: *wa-yashlikhu ʾet toratekha ʾaḥarey gawwam.* They cast your law behind their back.

9:29: *we-hemmah heziḏu we-loʾ shameʿu le-miṣwoteykha.*

9:30: *wa-timshokh ʿaleyhem shanim rabbot wa-taʿad bam be-ruḥakha be-yad neviʾeykha we-loʾ heʾezinu.* You bore with them many years and warned them by your spirit through your prophets, and they would not give ear.

**Five statements of the hearing failure in one chapter, in the corpus's own retrospective account of its whole history.**

**And the chapter's conclusion is a covenant, not an expectation.** 10:1: *u-ve-khol zoʾt ʾanaḥnu korotim ʾamanah we-khotevim*, and because of all this we make a sure covenant and write it. Followed by the signatories and the terms.

**The corpus's own account of its return locates the failure in the hearing five times and responds with a written undertaking, and names no figure.**

## CHAPTER 157 · The Second Temple, and the Weeping

Ezra 3:10-13 records the laying of the foundation and it records two sounds.

*We-rabbim me-ha-kohanim we-ha-Lewiyyim we-rashey ha-ʾavot ha-zeqenim ʾasher raʾu ʾet ha-bayit ha-rishon be-yosdo zeh ha-bayit be-ʿeyneyhem bokhim be-qol gadol we-rabbim bi-truʿah ve-simḥah le-harim qol.*

Many of the priests and Levites and heads of fathers' houses, old men who had seen the first house, wept with a loud voice when the foundation of this house was laid before their eyes, and many shouted aloud for joy.

**3:13.** *We-ʾeyn ha-ʿam makkirim qol teruʿat ha-simḥah le-qol bekhi ha-ʿam, ki ha-ʿam meriʿim teruʿah gedolah we-ha-qol nishmaʿ ʿad le-me-raḥoq.* The people could not distinguish the sound of the shout of joy from the sound of the people's weeping, for the people shouted with a great shout and the sound was heard far away.

**Haggai 2:3 asks the question directly.** *Mi vakhem ha-nishʾar ʾasher raʾah ʾet ha-bayit ha-zeh bi-khvodo ha-rishon, u-mah ʾattem roʾim ʾoto ʿattah, ha-loʾ kamohu ke-ʾayin be-ʿeyneykhem.* Who is left among you who saw this house in its former glory? And how do you see it now? Is it not as nothing in your eyes?

**And Haggai's answer is a promise.** 2:9: *gadol yihyeh kevod ha-bayit ha-zeh ha-ʾaḥaron min ha-rishon ... u-va-maqom ha-zeh ʾetten shalom.* The glory of this latter house shall be greater than the former, and in this place I will give peace.

**Three features of the whole episode.**

**The corpus records disappointment at the restoration it had promised.** That is unusual and it is not concealed. Ezra 3:12's weeping is the response of the people who remembered.

**Zechariah 4:10 addresses it.** *Ki mi vaz le-yom qeṭannot?* Who has despised the day of small things? Asked in the vision that also gives Zerubbabel the plummet.

**And the promise Haggai makes is stated with a first-person divine verb and no figure.** *ʾEtten shalom*, I will give peace.

**The relevance to this book.** The one moment in the corpus at which an act-layer restoration actually happens produces weeping alongside joy, and the corpus records both and cannot distinguish the sounds. Chapter 128 argued that the corpus subordinates the acts to a state they move toward. Ezra 3:13 is what the acts look like when they arrive without the state.

## CHAPTER 158 · Malachi · The Corpus's Last Word in One Arrangement

The Christian arrangement of the canon ends with Malachi and the Jewish arrangement ends with Chronicles. Both endings are worth having.

**Malachi's content.** A disputation in six units, each opening with a divine statement, a quoted objection, and a reply. The priests despising the name, offering blind and lame animals. The covenant of Levi corrupted. Faithless marriages and divorce. The wearying of God with words. The robbing of God in tithes. And the book of remembrance written for those who feared the LORD.

**3:1.** *Hineni sholeaḥ malʾakhi u-finnah derekh le-fanay, u-fitʾom yavoʾ ʾel heykhalo ha-ʾadon ʾasher ʾattem mevaqshim u-malʾakh ha-berit ʾasher ʾattem ḥafeṣim.* Behold I send my messenger and he shall prepare the way before me; and suddenly the Lord whom you seek will come to his temple, and the messenger of the covenant whom you delight in.

**Two or three figures in one verse and the corpus does not disambiguate.** *Malʾakhi*, my messenger. *Ha-ʾadon*, the Lord. *Malʾakh ha-berit*, the messenger of the covenant. Whether the last is the first or a third party is unstated.

**And 3:2 asks the question that undoes an easy expectation.** *U-mi mekhalkel ʾet yom boʾo u-mi ha-ʿomed be-heraʾoto?* Who can endure the day of his coming, and who shall stand when he appears?

**That is Amos 5:18's question in a different vocabulary.** Amos asked why the audience wanted the day of the LORD. Malachi asks who can endure it. The corpus's first and last prophetic books both interrogate the expectation rather than confirming it.

**3:23.** *Hinneh ʾanokhi sholeaḥ lakhem ʾet ʾEliyyah ha-naviʾ lifney boʾ yom YHWH ha-gadol we-ha-noraʾ.* Behold I send you Elijah the prophet before the coming of the great and terrible day of the LORD.

**And 3:24 states the purpose.** *We-heshiv lev ʾavot ʿal banim we-lev banim ʿal ʾavotam, pen ʾavoʾ we-hikkeyti ʾet ha-ʾareṣ ḥerem.* And he shall turn the heart of the fathers to the children and the heart of the children to their fathers, lest I come and strike the land with utter destruction.

**The corpus's last sent figure has a task and the task is a heart.** *We-heshiv lev*, and he shall turn the heart. The organ of Book IV, and the one place in the corpus where a sent figure's stated function is to move it.

**And the figure sent is a prophet, not a king.** Elijah, named, from the past.

**Chapter 84 asked for a passage in which a figure supplies the missing faculty and Chapter 153 narrowed the finding against Isaiah 42:7.** Malachi 3:24 narrows it further. The turning of a heart is not the giving of one, and the hearts turned are turned toward each other rather than toward God, and the purpose clause is a prevention of destruction rather than an entering. But the verse has a sent figure and a heart-verb in one clause, and an honest survey reports it.

**Two verses. The corpus's last words in this arrangement.** A prophet sent, hearts turned, and a conditional destruction averted.

## CHAPTER 159 · Chronicles · The Corpus's Last Word in the Other

The Jewish arrangement places Chronicles last and the ending is a permission.

**2 Chronicles 36:22-23.** *U-vi-shnat ʾaḥat le-Khoresh melekh Paras li-khlot devar YHWH be-fi Yirmeyahu heʿir YHWH ʾet ruaḥ Koresh melekh Paras wa-yaʿaver qol be-khol malkhuto we-gam be-mikhtav leʾmor.*

In the first year of Cyrus king of Persia, to fulfil the word of the LORD by the mouth of Jeremiah, the LORD stirred up the spirit of Cyrus king of Persia, and he made a proclamation throughout all his kingdom, and also in writing.

**And the proclamation.** *Koh ʾamar Koresh melekh Paras, kol mamlekhot ha-ʾareṣ natan li YHWH ʾelohey ha-shamayim, we-huʾ faqad ʿalay li-vnot lo vayit bi-Yrushalayim ʾasher bi-Yhudah. Mi vakhem mi-kol ʿammo, YHWH ʾelohaw ʿimmo we-yaʿal.*

Thus says Cyrus king of Persia: all the kingdoms of the earth the LORD God of heaven has given me, and he has charged me to build him a house in Jerusalem which is in Judah. Whoever is among you of all his people, may the LORD his God be with him, and let him go up.

**The corpus's final sentence in this arrangement is *we-yaʿal*, and let him go up.** An imperfect with permissive force, addressed to whoever is willing, spoken by a foreign king.

**Four features.**

**The stirring is God's.** *HeʿIr YHWH ʾet ruaḥ Koresh.* The LORD stirred up the spirit of Cyrus. The conferral grammar at the corpus's last narrative act.

**The giving is stated in Cyrus's own mouth.** *Kol mamlekhot ha-ʾareṣ natan li YHWH.* All the kingdoms of the earth the LORD has given me. The Persian king, in the corpus's final quoted speech, states his empire as received.

**The charge is a building.** *Faqad ʿalay li-vnot lo vayit.* He has charged me to build him a house. Not a kingdom, not a throne. A house.

**And the permission is individual and voluntary.** *Mi vakhem*, whoever among you. Nobody is gathered, led, or brought. The corpus's last word is an invitation to go up, addressed to anyone willing, with no figure at its head.

**Set the two endings side by side.**

Malachi: a prophet sent, hearts turned toward each other, destruction averted.

Chronicles: a foreign king stirred, an empire acknowledged as given, a house to be built, and whoever is willing may go up.

**Neither ends on a king. Neither ends on an arrival. Both end on something a person does.**

## CHAPTER 160 · What the Exile Material Establishes

Four results.

**The corpus records its own catastrophe in three voices and none of them expects a royal deliverance from it.** Kings ends on a meal at a foreign table. Chronicles ends on a Persian decree. Lamentations ends on a question about rejection.

**The return is credited to God and to Cyrus and to no Israelite royal figure anywhere.** Eight divine-subject gathering sites and the Cyrus material, and nothing else.

**Ezra-Nehemiah, the corpus's own narrative of the return, contains no messianic material and locates the historic failure in the hearing five times in one chapter.**

**And both canonical endings close on a human act rather than an arrival.** A turning of hearts and a going up.

One closing observation, offered as an observation.

The corpus had, at the moment of the return, everything it would need to state a messianic expectation and attach it to a living Davidide. Zerubbabel was present, was of the line, and was called a signet by Haggai. Zechariah put him in a vision with a plummet in his hand and called him one of two sons of oil. And Ezra-Nehemiah, writing the return's own history, says nothing about it.

That silence is not evidence against the expectation, which Books VIII and XII documented across six books. It is evidence about where the expectation sits in the corpus's own account of what happened, and where it sits is not at the centre of the narrative of the restoration.

Books III and IV named a terminus and a deficit. Book V named a concession. Books VI through XII traced a figure who grows without limit and holds everything he holds by grant. Book XIII found a corpus that keeps its own prosecution. And Book XVIII finds that corpus, at the end of its own story, closing on a permission and a turning of hearts, with the deficit stated five times in the confession that precedes it and the terminus unmentioned.
