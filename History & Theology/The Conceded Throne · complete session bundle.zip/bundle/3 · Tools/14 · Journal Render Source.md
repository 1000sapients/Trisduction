---
edition: journal
title: The Conceded Throne
subtitle: The Unentered Rest, the Requested King, and the Escalation That Answered the Wrong Question
author_line: Mohammad F. Islam, PhD^1^
journal: Tractatus Historicus
article_type: History of Religion
goal: The rest was given. It was not entered.
doi: Hebrew Bible Series
short_title: The Conceded Throne
date: 2026
accent: forest
---

:::affiliations
^1^Independent Researcher. Correspondence: islamm@alumni.iu.edu
:::

:::abstract
This study reads the royal and future-royal material of the Hebrew Bible as the history of a position rather than the biography of a person, and it reads nothing else: every load-bearing claim rests on the Hebrew Bible alone, and a verification gate enforces the constraint against the finished text. The argument runs from a single observation. The corpus names the terminus of its promise in a root whose sense is settlement rather than recuperation, states that terminus as given at Joshua 21:44 and announced already given at 1 Kings 8:56, records it delivered four further times in Judges under four ordinary deliverers, and records at Psalm 95:11 that it was not entered. It locates the failure of entry in the same three organs at every stage and in every part of the canon, in identical language, and nowhere in a gift withheld. It then grants a visible monarchy against an itemized prosecution and a clause excluding the standard remedy, and when its kings fail it re-issues the concession at higher intensity eight times without ever withdrawing it and without ever returning to the terminus it had already named. A second finding runs beneath the first and is the study's principal result. However large the figure becomes, the grammar by which he receives what he holds never changes: the verb is passive or the subject is God, at 2 Samuel 7:8, Psalm 2:7, Psalm 45:8, Psalm 110:1, Isaiah 9:5, 1 Chronicles 29:23, Ezekiel 34:23 and Daniel 7:14 alike, across six books and two languages, and the central title is itself a passive participle. An executed census over the whole corpus, reported with its instrument's limits stated in the same place, returns zero clauses in which a royal figure is the grammatical subject of giving rest, and eleven in which a king receives it with the giver named. Three falsification criteria are stated before the evidence and returned with their results; two claims that earlier drafts treated as central were killed by the corpus and are carried as dead rather than removed. The argument runs to a boundary, describes what stands on this side of it, and names no man.
:::

:::keywords
menuhah; conferral grammar; Hebrew Bible; Deuteronomistic History; 1 Samuel 8; royal ideology; Isaiah 6:9-10; hardening; messianic expectation; single-corpus method
:::




## A NOTE ON WHAT THIS BOOK IS

This is a study of one corpus, read on its own terms, about one question.

The question is not who the messiah is, or whether anyone has been him, or whether anyone will be. It is what kind of object the Hebrew Bible says its promise terminates in, and what relation the royal and future-royal material bears to that object.

The answer this book defends can be stated in four sentences. The corpus names the terminus of its promise in a specific word whose sense is settlement rather than recuperation. It states that terminus as given, twice, in the perfect, under non-royal agents, and as not entered. It locates the failure of entry in the same three organs at every stage, in every part of the canon, in identical language: the heart that does not know, the eyes that do not see, the ears that do not hear. And when its kings fail it does not return to the terminus but re-issues the concession of monarchy at higher intensity, eight times, while the deficit stands exactly where it stood.

A second finding runs beneath the first and is, on the evidence assembled here, the more securely established of the two. However large the figure becomes, from a man anointed from a flask who hides among the baggage to one like a son of man receiving everlasting dominion from a court in the clouds, the grammar by which he receives what he holds never changes. The verb is passive, or the subject is God. That holds at 2 Samuel 7:8, at Psalm 2:7, at Psalm 45:8, at Psalm 110:1, at Isaiah 9:5, at 1 Chronicles 29:23, at Ezekiel 34:23, and at Daniel 7:14 alike, across six books and two languages. And the central title itself is morphologically a passive participle, naming what was done to its bearer.

**The single-corpus constraint.** Every load-bearing claim rests on the Hebrew Bible. Second Temple literature, the rabbinic corpus, the New Testament, and the Qurʾān are admitted nowhere in the argument. That is a methodological constraint with a stated cost, and Chapter 1 states it. Appendix J names the boundary and says where another corpus begins.

**The debt this book pays.** An earlier article behind this project stated one unexecuted census and capped its own strength on it. Book II executes as much of it as the available instruments allow, prints the result, and prints the residual debt in the same place. The result was stronger than the argument needed and was not the result being looked for.

**Three falsification criteria are stated at Chapter 6, before the evidence, and returned with their results at Chapter 163.** Two further falsifiers generated by the argument itself are recorded there. And two claims that earlier drafts treated as central were killed by the corpus and are carried at Appendix I as dead rather than removed.

**What would fall if a royal figure of the expected kind arrived tomorrow: nothing.** Chapter 164 states why. The argument is that the figure is a means, and a means that arrives is a means that has arrived. No claim here rests on non-arrival and none predicts arrival. A reader looking for a book that argues against a messiah has picked up the wrong one, and a reader looking for one that argues for a messiah has too.

## READING CONVENTIONS

**Text.** BHS, the Leningrad Codex with its apparatus. Hebrew versification throughout; where the English differs the English number is given at first occurrence in that book. Excursus I sets out the general problem and Isaiah 9:5, English 9:6, is the instance that matters most.

**Transliteration.** Broad and academic. *š* for shin, *ṣ* for tsade, *ḥ* for het, *ṭ* for tet, *ʾ* for aleph, *ʿ* for ayin. Vowel length is not marked. Appendix L sets out the full convention and Appendix K glosses the recurring terms.

**Translations** are the author's unless otherwise stated. Where a rendering is contested the contest is named and the argument is built to hold under the alternatives.

**Chapters** are numbered continuously, 1 through 166, across nineteen books. Cross-references are to those numbers.

**Honorifics.** Prophetic names carry the traditional honorific where they appear: Musa AS, Ibrahim AS, and so on. This is a convention of the author's and is not an interpretive claim about the corpus.

**Contested points are stated as contested and not silently resolved.** Two recur: the referent of *soferim* and the parsing of *ʿasah* at Jeremiah 8:8, and the subject of *wa-yitten* at Genesis 14:20. In both the argument holds under either reading.


:::contents
$ BOOK I · THE INSTRUMENT
. 1 | The Single-Corpus Constraint
. 2 | The Removability Criterion
. 3 | The Criterion Is One the Corpus Applies to Itself
. 4 | Two Calibrations and a Boundary
. 5 | What Counts as the Hebrew Bible Here
. 6 | The Three Falsifiers, Stated in Advance
. 7 | What Is Not New, and the Debt to von Rad
. 8 | What This Book Does Not Do
$ BOOK II · THE FOUR ROOTS
. 9 | Šbt · The Hand Comes Off the Work
. 10 | Nwḥ · The Alighting That Stays
. 11 | Šqṭ · The Land Is Quiet
. 12 | Rgʿ · Repose at the End of a Walk
. 13 | The Census, I · What Can and Cannot Be Executed
. 14 | The Census, II · The Raw Field
. 15 | The Census, III · Terminal Position
. 16 | The Census, IV · The Marking Test
. 17 | The Subject Test, and What It Returned
. 18 | What the Census Settles
. 19 | What the Census Leaves Open
. 20 | Šalom Beside the Four, and Why It Is Not a Fifth
$ BOOK III · THE TERMINUS
. 21 | Genesis 2:2 and the Seventh Position
. 22 | Deuteronomy 12:9 · Not Yet Come to the Rest
. 23 | Joshua 21:44 · He Gave Them Rest
. 24 | Judges · Four Deliveries by Ordinary Agents
. 25 | 1 Kings 8:56 · Announced as Already Given
. 26 | Psalm 95 · The Flock, the Hearing, the Non-Entry
. 27 | 1 Chronicles 22:9 · A Man of Rest, Named Before Birth
. 28 | Ezekiel 37:14 · The Ingathering's Own Terminal Clause
. 29 | Isaiah 11:9 and 2:4 · State Descriptions With No Agent
. 30 | Leviticus 26 and 2 Chronicles 36:21 · The Exile Priced in Sabbaths
. 31 | A State Is Entered, Not Delivered
$ BOOK IV · THE DEFICIT
. 32 | Deuteronomy 29:3 · The Organ Not Given
. 33 | Isaiah 6 · Commissioned Into Non-Reception
. 34 | Isaiah 42:19 · The Corpus Puts Its Own Messenger in the Category
. 35 | Jeremiah 6:16 · And They Said, We Will Not Walk
. 36 | Deuteronomy 8 · The Mechanism Is Prosperity
. 37 | Exodus 20:8 · The One Imperative of Memory
. 38 | The Three Organs, Counted Across the Corpus
. 39 | The Hardening Problem, and Why This Book Does Not Solve It
. 40 | Deuteronomy 30:19 · The Same Shape From the Other Side
. 41 | Nowhere a Withheld Terminus
$ BOOK V · THE CONCESSION
. 42 | Judges 8:23 · The Refusal
. 43 | Deuteronomy 17:14 · A Statute Conditioned on Being Asked For
. 44 | 1 Samuel 8:5 · Like All the Nations
. 45 | 1 Samuel 8:7 · Rejected, Not Ended
. 46 | 1 Samuel 8:11-18 · The Itemized Bill
. 47 | 1 Samuel 8:18 · The Unanswered-Outcry Clause
. 48 | 1 Samuel 8:19-22 · The Refusal to Hear, and the Grant
. 49 | 1 Samuel 12 · The Farewell, and the Rain Out of Season
. 50 | Hosea 13:11 · Priced in Anger
. 51 | Gideon, Abimelech, and the Fable of the Bramble
. 52 | The Two Strands, and Why the Final Form Is the Datum
$ BOOK VI · THE SEAT
. 53 | 1 Chronicles 29:23 · The Throne of YHWH
. 54 | Two More Chronicler Sites, and What Three Occurrences Establish
. 55 | Psalm 110:1 · The Seat Is Offered, and the Offerer Named
. 56 | Psalm 110:4 · A Priesthood Not Aaron's
. 57 | Melchizedek and Adoni-Ṣedeq · The Received Institution
. 58 | Deuteronomy 17:18-20 · The King Copies a Law He Did Not Write
. 59 | 2 Samuel 7:14-15 · Discipline Inside the Sonship Clause
. 60 | Psalm 2:7 · Dated in One Adverb
. 61 | Ezekiel 34:24 · Two Roles, One Verse, Distinguished
. 62 | The Passive Verb and the Named Giver
. 63 | Anointing Itself · The Morphology of a Passive Title
$ BOOK VII · THE OCCUPANTS
. 64 | The Anointing Rite · Oil, Horn, and Flask
. 65 | Aaron and the Priestly Anointing
. 66 | Saul · The First and the Rejected
. 67 | David · Anointed Three Times
. 68 | Solomon · The Man of Rest Who Was Not
. 69 | Jehu · The Anointing That Kills
. 70 | Hazael · An Anointing Outside Israel
. 71 | Cyrus · Meshiaḥ at Isaiah 45:1
. 72 | The Anointed Who Are Not Kings
. 73 | The Kings Who Are Not Anointed
. 74 | The Census of Meshiaḥ · Every Occurrence, Sorted
$ BOOK VIII · THE ESCALATION
. 75 | The Sequence, and What Ordering It by Content Means
. 76 | Stages One to Three · Refusal, Concession, Permanence
. 77 | Stage Four · Cosmic Vocabulary in the Royal Psalms
. 78 | Stage Five · Isaiah 9:5 and the Throne-Name
. 79 | Stage Six · Isaiah 11:1 and the Regrowth
. 80 | Stage Seven · Zechariah and the Split Into Two
. 81 | Stage Eight · Daniel 7 and the Passive Yehiv
. 82 | The Category Substitution, Performed Eight Times
. 83 | What the Escalation Is Not
. 84 | The One Stage That Aims at the Deficit, and What It Shows
$ BOOK IX · THE TREE
. 85 | Job 14:7-9 · Three Parts, Three Rulings
. 86 | The Stump Dies in the Dust
. 87 | The Root Persists, and the Trigger Is Water Already There
. 88 | Isaiah 11:1 · Two Sources, One Verse, Unreconciled
. 89 | Isaiah 6:13 · The Holy Seed Is Its Stump
. 90 | The Ṣemaḥ Field · Branch as a Title
. 91 | Jeremiah 2:27 and Habakkuk 2:19 · The Fenced Location
. 92 | Ezekiel 17 and 31 · The Cedar, the Sprig, and the Felling
. 93 | What the Tree Material Establishes
$ BOOK X · THE SHEPHERD AND THE FLOCK
. 94 | The Metaphor and Its Two Ends
. 95 | Ezekiel 34 · The Indictment and the Substitution
. 96 | Psalm 23 · The King Is the Sheep
. 97 | The Shepherds Who Failed, Book by Book
. 98 | The One Shepherd, and the Number Problem
. 99 | Micah 5 · The One from Bethlehem, and Whose Strength
. 100 | The Flock That Is Not Gathered by a Shepherd
. 101 | What the Shepherd Material Establishes
$ BOOK XI · THE PSALTER READ FOR ITS VERBS
. 102 | Why the Psalter Is Read Separately
. 103 | Psalm 72 · Give the King Your Judgments
. 104 | Psalm 89 · The Covenant and the Complaint
. 105 | Psalm 132 · The Oath and Its Condition
. 106 | The Enthronement Psalms · YHWH Malakh
. 107 | Psalm 8 and Psalm 144 · What a Man Is
. 108 | The Laments Over the Anointed
. 109 | What the Psalter Establishes
$ BOOK XII · THE PROPHETS AND THE FIGURE
. 110 | Reading the Prophets Book by Book
. 111 | Isaiah · The Densest Field
. 112 | Jeremiah · The Branch and the New Covenant
. 113 | Ezekiel · The Prince, and the Sanctuary in the Midst
. 114 | Hosea, Amos, and Micah
. 115 | Zechariah and Haggai · The Post-Exilic Pair
. 116 | The Prophets Who Say Nothing
. 117 | Daniel · The Aramaic Court and the Seventy Weeks
. 118 | The Day of the LORD
. 119 | What the Prophetic Survey Establishes
$ BOOK XIII · WHAT THE CORPUS PRESERVES
. 120 | Jeremiah 8:8 · The Scribes Indicted, the Deposit Held
. 121 | Ten Pairs · The First Five
. 122 | Ten Pairs · The Second Five
. 123 | The Line Seated Through the Standing Bar
. 124 | What Israel Holds Is Recorded as Received
. 125 | A Tradition Operating by Deletion Does Not Preserve Its Own Prosecution
$ BOOK XIV · THE TORAH'S OWN FIGURES
. 126 | Why the Torah Is Read Last
. 127 | Genesis 3:15 · The Seed and the Heel
. 128 | Genesis 49:10 · Shiloh, and the Sceptre
. 129 | Numbers 24:17 · The Star and the Sceptre
. 130 | The Patriarchal Promises · The Torah's Actual Future Material
. 131 | The Blessing of the Nations, and Its Grammar
. 132 | What the Torah Establishes and What It Does Not
$ BOOK XV · THE SILENCES
. 133 | What the Wisdom Books Do Not Say
. 134 | Why the Silence Is Not an Argument, and What It Is
. 135 | The Covenant Formula, Across the Corpus
. 136 | The Places Where a Figure Would Have Fitted and Is Absent
. 137 | The Two Vocabularies, Set Side by Side
$ BOOK XVI · THE SERVANT
. 138 | Why the Servant Material Needs Its Own Book
. 139 | The First Song · Isaiah 42:1-9
. 140 | Isaiah 42:19 · The Servant in the Category
. 141 | The Second Song · Isaiah 49:1-6
. 142 | The Third Song · Isaiah 50:4-9
. 143 | The Fourth Song · Isaiah 52:13-53:12, and What This Book Says About It
. 144 | The Servant Who Is Named Israel
. 145 | What the Servant Material Establishes
$ BOOK XVII · THE EXILE AND THE RETURN
. 146 | The Corpus Narrates Its Own Catastrophe
. 147 | What the Exile Does to the Argument
. 148 | The Return, and Who Is Credited With It
. 149 | The Second Temple, and the Weeping
. 150 | Malachi · The Corpus's Last Word in One Arrangement
. 151 | Chronicles · The Corpus's Last Word in the Other
. 152 | What the Exile Material Establishes
$ BOOK XVIII · THE DWELLING
. 153 | The Corpus's Other Menuḥah
. 154 | The Tabernacle · A Dwelling That Moves
. 155 | 2 Samuel 7 · The House Nobody Asked For
. 156 | 1 Kings 8 · Solomon's Own Qualification
. 157 | The Glory That Departs
. 158 | The Presence and the Terminus
$ BOOK XIX · THE RESULT
. 159 | The Removability Result · Six Substantive Contents
. 160 | What Fails the Strip · The Act-Layer
. 161 | The Purpose Clauses · Road and Destination in the Corpus's Own Grammar
. 162 | Positioning Against the Prior Literature
. 163 | Falsification · The Three Criteria and Their Results
. 164 | The Limit Case · What Would Fall If the Figure Arrived
. 165 | Limits, Debts, and What Is Carried as Contested
. 166 | Conclusion · The Rest Was Given, It Was Not Entered
$ PART TWO · TWENTY-ONE EXCURSUS
. Excursus I | The Versification Problem at Isaiah 9
. Excursus II | Why the Four Roots Are Four and Not One
. Excursus III | The Judges Cycle, Counted
. Excursus IV | Gideon's Ephod
. Excursus V | The Ark, and What It Is Not
. Excursus VI | Uzzah, and the Cost of Steadying
. Excursus VII | The Name at Jeremiah 23:6 and 33:16
. Excursus VIII | Solomon's Request, Read Against Book IV
. Excursus IX | What Happened to the Northern Kingdom's Expectation
. Excursus X | Sabbath, Sabbatical Year, and Jubilee
. Excursus XI | The Verb Šwv and the Two Returns
. Excursus XII | The Deuteronomy 18 Prophet
. Excursus XIII | What the Septuagint Does Differently, at Three Points
. Excursus XIV | The Two Names for the Corpus, and Why It Matters Here
. Excursus XV | The Four Royal Titles Compared
. Excursus XVI | What ʿOlam Means Here
. Excursus XVII | The Horn
. Excursus XVIII | Seven, and the Terminus
. Excursus XIX | The Passages This Book Did Not Use
. Excursus XX | Ṣedeq, and the Element in Two Jerusalemite Names
. Excursus XXI | The Criterion Applied to This Book
$ PART THREE · FIFTEEN APPENDICES
. Appendix A | The Rest-Field Census · Method and Full Result
. Appendix B | The Eleven Marked Terminus Sites
. Appendix C | The Meshiaḥ Concordance, Sorted
. Appendix D | The Conferral Grammar · Fifteen Sites
. Appendix E | The Thirteen Retained Pairs
. Appendix F | The Ancestry Through the Bar · Seven Instances
. Appendix G | The Eight Stages
. Appendix H | The Deficit Inventory · Eleven Passages
. Appendix I | Errata and Withdrawn Claims
. Appendix J | The Boundary · Where Another Corpus Begins
. Appendix K | Glossary of Hebrew and Aramaic Terms
. Appendix L | Transliteration, Citation, and Conventions
. Appendix M | The Twenty-Four Books, and What Each Carries
. Appendix N | The Nine Terminus Anchors
. Appendix O | A Reader's Route
$ BIBLIOGRAPHY
$ AUTHOR DISCLOSURE
:::

:::book I | THE INSTRUMENT


## 1. The Single-Corpus Constraint


Every load-bearing claim in this book rests on the Hebrew Bible. That is a methodological constraint and not a verdict on any other body of writing. Second Temple literature is not false because it is excluded here. The rabbinic corpus is not diminished by being absent. The Gospels and the Qurʾān are not answered by being left out. They are left out because a reading that must reach outside its corpus to stand cannot be checked inside it, and a book about what the Hebrew Bible says should be testable by a reader who owns a Hebrew Bible and nothing else.

The constraint has a cost and the cost is worth naming at the front, before a reader discovers it as an absence and takes the absence for an oversight. A great deal of the most interesting material about the messianic position sits outside this corpus. The Enochic literature builds a pre-existent figure seated on a throne of glory and calls him the Son of Man. The Qumran library carries two anointed figures, one priestly and one royal, and a heavenly Melchizedek who executes judgment in the last jubilee. The rabbinic corpus supplies the treasury of unborn souls, the sabbath of history, and the messiah who sits among the lepers at the gates of Rome binding and unbinding his wounds one at a time so as to be ready at any hour. The Gospels supply an occupant and an argument for the occupancy. The Qurʾān supplies a seal and a redescription of the whole line. Every one of those is a real object with real evidential weight for a reader asking a broader question, and every one of them is excluded here.

What the constraint buys is a specific kind of falsifiability, and it is worth being precise about what kind. When this book says the corpus states something, a reader can check whether it does. When it says the corpus never states something, a reader can look for a counterexample and produce one. There is no move available in these pages where a contested reading is rescued by an appeal to a text the reader cannot see, and no place where a chain of inference crosses from one canon into another and picks up warrant it did not have on the first side of the crossing. That second failure is the one worth guarding against most carefully, because it is invisible from inside. A claim about the Hebrew Bible that is actually being carried by a Qumran text will look, on the page, exactly like a claim about the Hebrew Bible.

The constraint is enforced mechanically rather than promised rhetorically. A verification gate runs against the finished text and fails the build on any citation to a source outside the Hebrew Bible inside the argument body. The bibliography cites modern scholarship, because scholarship is not scripture and citing Mowinckel is not reaching into a second canon. Appendix J names the boundary explicitly and says where another corpus begins, so that a reader who wants to cross it knows exactly at which sentence the crossing happens and that this book does not make it.

One further clarification about scope, since the phrase Hebrew Bible is used in more than one way and the differences matter at three points in this book. The corpus here is the twenty-four books of the Masoretic canon in their received arrangement, cited by the chapter and verse divisions of BHS. The Aramaic portions of Daniel and Ezra are inside it, which matters at Chapter 81 where the decisive verb is Aramaic. The deuterocanonical books are outside it, which matters nowhere in this book because no argument here wanted them. Where the Septuagint differs from the Masoretic Text in a way that bears on an argument, the divergence is named and the argument is constructed to hold under either reading, or the argument is dropped. Textual criticism is not this book's discipline and it will not be practised amateurishly to rescue a point.

The final form is the object. Where a passage is widely held to be composite, that view is noted and no position is taken on it. The argument of this book is about what the corpus as received says and preserves, which is a question that stands whatever the compositional history turns out to be. A redactor who assembled the material is a party to what the assembly says, and a redactor who placed an itemized prosecution of kingship on the same scroll as the royal psalms made a decision that a reader is entitled to notice. Noticing it commits one to nothing about who he was or when he worked.

A last word on the posture this constraint produces, because it can be mistaken for a hostile one. Reading a corpus on its own terms is a form of attention, not a form of suspicion. The reason to refuse the imported framework is not that the framework is corrupt but that an imported framework answers questions before they are asked, and the questions this book wants to ask are ones the corpus turns out to have answered in its own vocabulary. That vocabulary is the subject of the next several hundred pages. It is more precise than the tradition of paraphrase around it, and the precision is recoverable by anyone willing to read the words that are actually there.

## 2. The Removability Criterion


The instrument is a single question, and it can be stated in one line. Strip the singular-figure framing from a passage and ask what proposition remains.

Formally: a passage may be indexed to a figure, to a dated event, or to a state. Stripping is the deletion of the figure-and-event clause and the reading of whatever predicate survives. A content is substantive under this criterion if the corpus states it somewhere in a passage naming no eschatological figure and no dated event.

Four features of that definition carry weight and each has been misread in draft by at least one reader, so each is stated separately.

**The criterion is about availability, not frequency.** A content that the corpus states once without a figure is substantive under the test even if it states it fifty further times with one. The question is whether the corpus can hold the content when the figure is removed, and that question is settled by a single clean instance. This is why the test cannot be run by counting. A tally of figure-indexed against non-figure-indexed occurrences would measure emphasis, which is a different property and one this book makes no claims about.

**The criterion is about the corpus, not the passage.** A figure-indexed passage does not fail the test. It simply does not, on its own, establish that the content is available without the figure, and the test then looks elsewhere. A great many of the corpus's most famous statements about the terminus are figure-indexed, and none of them is thereby impeached. The test asks a question about the corpus's total resources and answers it from wherever the resources happen to be.

**The criterion measures one property and not importance.** A content can be substantive under this test and marginal in the corpus. A content can fail the test and be central. What the criterion measures is exactly whether the corpus, by its own statements, can carry the content when the figure is removed. That is a narrow question and the narrowness is the point. A wide instrument returns wide answers that cannot be checked, and an instrument that measures importance is an instrument that returns the operator's priors with a number attached.

**The criterion does not measure truth.** It has nothing to say about whether any content it sorts is true, whether any figure it strips is real, or whether any expectation it examines will be met. It sorts statements by a structural property. A reader who takes a substantive verdict as an endorsement and a failed strip as a debunking has read the instrument as a machine for producing verdicts it is constitutionally unable to produce.

The reason a criterion is needed at all is that the alternative is impression. A reader who has spent a lifetime with these texts will have a settled sense of what is central and what is decoration, and that sense will be a compound of three things: the text, the tradition the reader learned it in, and the arguments the reader has found persuasive. None of those three components is separable from the others by introspection. Nobody can look inward and determine which part of their sense of Isaiah comes from Isaiah. A stated criterion is not more objective than a trained sense. It is checkable in a way that a trained sense is not, and a reader who thinks it gives the wrong answer can say so at a specific verse rather than at the level of general disagreement. That is the entire advantage and it is sufficient.

The criterion is applied at the level of the pericope, not the verse and not the book. A verse is too small a unit, because a figure named in verse three governs verse four whether or not verse four repeats the name, and a criterion that ignored this would manufacture unmarked sites by cutting them out of marked contexts. A book is too large, because a figure named in Isaiah 9 does not govern Isaiah 41, and a criterion operating at book level would mark almost everything and cut nothing. The pericope is the natural unit and its boundaries are sometimes contested. Where they are, the contest is named and the argument is built to hold at either boundary, or the passage is set aside as undecidable under this instrument. Setting a passage aside is a permitted outcome and it happens four times in this book.

One anticipated objection deserves an answer here rather than later. The objection is that stripping a figure from a passage is a violent operation that produces a text nobody wrote, and that reading the residue is reading a fiction. The answer is that the criterion never reads a stripped passage as though it were a real passage. The strip is a test applied to a passage; the substantive verdict is then discharged onto a *different* passage, one the corpus actually contains, where the content stands without the figure already. Nothing in this book quotes a stripped text. The strip identifies what to go looking for; the corpus supplies the finding or does not.

## 3. The Criterion Is One the Corpus Applies to Itself


An instrument imported from outside a corpus and applied to it will find what the instrument was built to find. That is not a risk peculiar to this instrument; it is the standing condition of method. The defence available is to show that the corpus already runs the operation, which is what this chapter does. Four passages perform the strip, in four different ways, and none of them is doing it at the invitation of a modern reader.

**Deuteronomy 30:11-14 asserts reachability without an intermediary.** The commandment is not hidden, not in heaven, and not beyond the sea. *Ki qarov ʾeleykha ha-davar meʾod, be-fikha u-vilvavkha la-ʿasoto.* Three locations are named and each is ruled out, and the three are not arbitrary: hidden, high, and distant are the three ways a thing can require a fetcher. Something concealed requires a revealer. Something in heaven requires an ascender. Something across the sea requires a voyager. The passage names all three modes of intermediation and denies each, then states the positive: the word is in your mouth and in your heart, to do it. That is the removability criterion stated as a positive doctrine about a specific content.

**Micah 6:8 performs the strip and prints the residue.** *Higgid lekha ʾadam mah tov u-mah YHWH doresh mimmekha ki ʾim ʿasot mishpaṭ we-ʾahavat ḥesed we-haṣneaʿ lekhet ʿim ʾelohekha.* The verse is framed as an answer to a question about requirement, posed four verses earlier in a rhetorical escalation that runs from burnt offerings to calves a year old to thousands of rams to ten thousand rivers of oil to the firstborn. The escalation is a bidding war and the answer refuses the currency entirely. What the answer contains is three infinitives and no agent but the hearer. There is no figure-clause, no temporal condition, and no dated event. Stripping is the identity operation and the proposition stands unchanged.

**Jeremiah 9:22-23 performs it by subtraction, which is the most explicit form.** Let not the wise glory in wisdom, let not the strong glory in strength, let not the rich glory in riches. Three candidates are named and three are struck, in a syntactic pattern that makes the striking the point. What survives is *haskel we-yadoaʿ ʾoti*, understanding and knowing me. The rhetorical structure is a filter, and the corpus operates it in public.

**Deuteronomy 10:12-13 answers the question of requirement in five infinitives.** To fear, to walk in all his ways, to love, to serve with all the heart and all the soul, to keep the commandments and the statutes. The question is posed as *mah YHWH ʾeloheykha shoʾel me-ʿimmakh*, what does the LORD your God ask of you, which is the same question Micah asks in a different vocabulary and gets a compatible answer to. There is no eschatology among the five.

To these four should be added a fifth of a different kind, and it is the one that forestalls the most damaging objection. **Deuteronomy 30 marks its own pericope boundary.** The objection would be that a modern reader is cutting a continuous speech at a convenient point, taking verses eleven to fourteen out of a chapter whose opening verses are all gathering and restoration. But verses one through ten stand under *we-hayah ki yavoʾu ʿaleykha kol ha-devarim ha-ʾelleh*, a future-perfect frame carrying the gathering and the return. Verse eleven turns on *ki* into *ha-miṣwah ha-zot ʾasher ʾanokhi meṣawwekha ha-yom*, and *ha-yom* then recurs at 30:15, at 30:16, at 30:18, and at 30:19. Two temporal frames, marked lexically by the text itself, inside one chapter, with the second marked five separate times. The corpus draws the line this book will use, and it draws it four verses after drawing the other one.

The consequence is not that the criterion is thereby validated, and overstating this would be the first inflation in a book about inflation. A corpus that performs an operation is not endorsing every use a reader makes of it, and Deuteronomy 30 is not licensing a twenty-first-century sort of prophetic material. The consequence is narrower and it is sufficient: the operation is native. A reader who objects to the criterion is objecting to something the corpus does, and the objection has to be made at that level rather than at the level of methodological preference. That converts a debate about whether the instrument is legitimate into a debate about whether it has been applied correctly, which is a debate that can be conducted at specific verses and settled.

## 4. Two Calibrations and a Boundary


An instrument that passes everything is not an instrument. Before the criterion is used to decide anything, it needs a case it passes and a case it fails, so that a reader can see the cut before the cut is used on contested material.

**The pass. Micah 6:8.** No figure-clause, no dated event, no temporal condition. Stripping is the identity operation. The proposition after the strip is identical to the proposition before it. This is what a substantive content looks like under the test, and it looks like this because there was nothing to remove.

**The fail. Ezekiel 37:21.** *ʾAni loqeaḥ ʾet benei Yisraʾel mi-beyn ha-goyim ʾasher halkhu sham, we-qibbaṣti ʾotam mi-saviv we-heveʾti ʾotam ʾel ʾadmatam.* Here the gathering is the main verb and the whole content. Three verbs in sequence, all with the same divine subject, all naming acts. Delete the act-clause and there is no residual predicate at all. This is a real cut, and it cuts a passage no reader would call marginal, in the middle of the chapter that contains the valley of dry bones.

Two disciplinary notes follow from those two cases and both are load-bearing for everything downstream.

**The test is not vacuous on this corpus.** A whole class of material fails it, and the class that fails is the act-layer: gathering, rebuilding, restoration of offices, return to the land, reconstitution of the two houses under one shepherd. That class is enormous and it is not peripheral. It occupies large parts of Ezekiel, most of the second half of Isaiah, and the hinge chapters of Jeremiah. An instrument whose only demonstrated result is that everything passes has demonstrated nothing about the corpus and something embarrassing about itself. This one cuts, and it cuts in a place that costs the argument something, because the act-layer is precisely the material a reader might expect a book like this to want to keep.

**A failed strip is not a demotion.** This is the point most easily lost and it is worth stating twice in different words. Ezekiel 37:21 fails the criterion. Ezekiel 37:21 is not thereby unimportant, unreal, secondary, late, or dispensable. The criterion sorts by a single property, availability without a figure, and a content can lack that property entirely and be the most important thing in the book that contains it. What the criterion produces is a sort, not a ranking. Chapters 102 and 103 return to this at length, because the whole result of the book turns on it and a reader who takes the sort for a ranking will have read a book that was not written and will object to claims that were not made.

The boundary of the instrument should be stated here rather than discovered later. **The classification of passages by index-type is an instrument of this book and not a property claimed of the text.** The corpus supplies the members. The sorting is mine. There is no clause anywhere in the Hebrew Bible in which the corpus classifies its own passages as figure-indexed or state-indexed, and any reader who comes away thinking there is has been misled by the confidence of the presentation. What Chapter 3 established is that the corpus performs the *operation*. It does not perform the *taxonomy*. Those are different claims and the second one is mine alone.

A reader who accepts every member and rejects the sort has rejected the argument, and that is a legitimate move which the falsification criteria of Chapter 106 are designed to make available rather than to foreclose. The book is constructed so that its central claim has a specific shape a critic can attack: not that the royal material is secondary, which is unfalsifiable and uninteresting, but that the corpus states a terminus in clauses containing no figure and subordinates the act-layer to it grammatically. Both halves of that are checkable at named verses.

One last calibration, which is about the operator rather than the instrument. Where the strip produces a result I did not expect and did not want, the result stands and is reported. There are three such places in this book. At Chapter 30 the exile turns out to be accounted in the terminus's own currency, which is a stronger result than the argument needed and is therefore stated with the caution appropriate to a convenient finding. At Chapter 71 the census of *meshiaḥ* turns up a foreign king holding the title, which complicates a tidy reading and is left uncomplicated. And at Chapter 88 two images the corpus places in one verse turn out to be ruled on incompatibly by a third book, and the incompatibility is left standing rather than harmonized, because harmonizing it is exactly what the corpus declined to do.

## 5. What Counts as the Hebrew Bible Here


This chapter exists because a scope law that is not operationalized is a preference, and a preference can be relaxed silently at the one point where relaxing it would help.

**The canon.** The twenty-four books of the Masoretic tradition in their received arrangement, cited by the chapter and verse divisions of BHS. Where the English versification differs from the Hebrew, as it does across the Psalms and at scattered points in the prophets, the Hebrew numbering is used and the divergence is noted at first occurrence within each book. Isaiah 9:5 in the Hebrew is Isaiah 9:6 in most English versions, and that verse is load-bearing at Chapter 78, so the difference is flagged there again rather than left to a reader's memory of a note two hundred pages earlier.

**The text.** BHS, which is to say the Leningrad Codex with its apparatus. Where a reading is contested, the contest is named at the point of use. Where the Septuagint or a Qumran witness supports a variant that would change an argument, the argument is either constructed to hold under both readings or abandoned. There is no third option in this book and no place where a variant is quietly selected because it helps.

Two contested points recur and both are carried as contested rather than silently resolved. The first is Jeremiah 8:8, where the referent of *soferim* is disputed between manuscript copyists and a teaching class, and the parsing of *ʿasah* is likewise disputed. Chapter 94 shows why the argument holds under every combination of those two readings, which is a stronger position than picking one. The second is Genesis 14:20, where the subject of *wa-yitten* is unstated and the verse can be read with either Abram or Melchizedek as the one who gives the tenth. Chapter 57 shows that the relevant claim is settled independently by Psalm 110:4 regardless of who handed whom anything.

**A note on the Aramaic.** Daniel 2:4b through 7:28 and the Ezra documents are Aramaic and are inside the corpus. This matters exactly once and it matters a great deal. The decisive verb at Daniel 7:14 is *yehiv*, an Aramaic peʿil, and Chapter 81 turns on its voice. A scope law that excluded the Aramaic would have excluded the corpus's own final and highest instance of the pattern this book is tracing, which would have been convenient and wrong.

**Transliteration.** Broad and academic. *š* for shin, *ṣ* for tsade, *ḥ* for het, *ṭ* for tet, *ʾ* for aleph, *ʿ* for ayin. Vowel length is not marked, since nothing in this book turns on it and marking it would suggest a precision the transliteration does not have. The transliteration serves a reader who does not read pointed Hebrew and wants to follow the argument. It is not a substitute for the text, and every claim is stated so that a reader with the consonants can check it.

**What is outside.** Everything else, without exception. The deuterocanonical books. The pseudepigrapha, including the Enochic corpus, Jubilees, and the Testaments. The Qumran library. Josephus and Philo. The Mishnah, the two Talmuds, the midrashic collections, and the Targums. The New Testament. The Qurʾān. Not one of them appears as evidence for a claim in this book. Where one is named at all, it is named in the positioning chapters as a thing other readers have used, and marked as outside the base at the point of naming.

**Modern scholarship is a different category and is used freely.** Von Rad, Mowinckel, Noth, and the literatures on the sabbath as institution, on the hardening motif at Isaiah 6, and on the composition of 1 Samuel 8 through 12 are cited as scholarship. Citing an argument about the corpus is not reaching into a second canon. A book that refused to name the people whose work it stands on would be pretending to an originality it does not have, and the pretence would be visible to anyone who had read them.

**The one deliberate exception, named as an exception.** Appendix J discusses what happens at the boundary and therefore names material from outside it. That appendix is fenced, is not cited by any chapter as support, and carries a header stating that nothing in it is load-bearing. The verification gate excludes it by path rather than by content, which is a weaker guarantee than the gate provides elsewhere, and the weakness is disclosed here.

## 6. The Three Falsifiers, Stated in Advance


An argument that cannot say what would break it is not an argument. Three criteria are stated here, before the evidence, so that a reader can hold the book to them and so that the book cannot quietly adjust them later. Each is executable inside the Hebrew Bible by a reader with a concordance. Each is returned to at Chapter 106 with its result.

**F1, the terminus criterion.** If the *menuḥah*, *šqṭ*, knowledge-condition, and war-cessation clauses are systematically figure-indexed, requiring a royal or eschatological agent in the clause or its immediate pericope, then Book III fails and the frame is not removable. Everything downstream of Book III weakens with it, because the whole argument depends on the terminus being statable without the figure. This is the criterion the seed article behind this project could not execute and on which it explicitly capped its own strength. Book II executes it as far as the available instruments allow, prints the result, and prints the residual debt in the same place, because a partially discharged debt reported as discharged is worse than one reported as owed.

**F2, the concession criterion.** If the corpus at any point withdraws the concession of monarchy rather than re-issuing it at higher intensity, Books V and VIII both fail. This one is cheap to run: search for any withdrawal formula, any clause in which the grant of a king is revoked rather than a particular king removed. The distinction between those two is the whole question and Chapter 50 works it at Hosea 13:11, which is the strongest candidate for a withdrawal and turns out not to be one.

**F3, the receiver criterion.** If Deuteronomy 29:3, Psalm 95:11, Isaiah 6:9-10, and Isaiah 42:19-20 can be read as locating the failure in an absent or withheld terminus rather than in a deficient receiver, Book IV dissolves and Book VIII acquires a different and possibly adequate explanation. Note the shape of that: F3 failing would not merely damage the argument, it would supply the escalation with a rationale the argument denies it. A reader who wants to break this book should start here, because this is the criterion whose failure would be most productive.

To these three a fourth should be added, and it is the sharpest available because it is the one a critic would most want to press.

**The limit case.** If a royal figure of the expected kind arrived tomorrow, what in this book would fall? Nothing. Book III would still have a terminus named in the settling-root and delivered twice by ordinary agents and held four times in Judges. Book IV would still have the deficit at the receiver in five texts across three books. Book V would still have the bill printed in advance and itemized. Book VI would still have the seat conferred with the giver named in the clause. The argument is that the figure is a means, and a means that arrives is a means that has arrived. No claim here rests on non-arrival and none predicts arrival. A reader looking for a book that argues against a messiah has picked up the wrong one. A reader looking for a book that argues for one has too.

That fourth case is stated at the front rather than the back because it changes how the rest should be read. This is not a book with a stake in an outcome. It is a book about how a corpus files its own materials, and the filing is the same whatever happens next.

## 7. What Is Not New, and the Debt to von Rad


The observation that the Hebrew Bible says the rest was given and also says it was not entered is not new and is not claimed here as new. Saying so at the front is not modesty. It is the condition under which the actual contribution becomes visible, because a book that presented the seam as a discovery would be inviting a reader to spend their attention on the wrong thing.

Gerhard von Rad set the problem in the essay that supplies half of this book's vocabulary, and the seam he identified is the seam this book works. Joshua 21:44 states that the LORD gave Israel rest on every side. 1 Kings 8:56 states, at the dedication of the temple, that the rest has been given, and states it in the perfect. Psalm 95:11 states that they did not enter it. Any attentive reader of the Deuteronomistic material meets that tension, and a substantial literature has met it since, mostly by locating the resolution in a distinction between a partial rest already given and a full rest still awaited.

What is offered here is a sorting rather than a discovery. The claim is that the tension von Rad located is not an unresolved residue of the tradition but a structural feature with a determinate direction, and that the direction becomes visible once a different question is asked of the material. Not *when does the rest arrive*, but *what kind of object is it*, and therefore *what kind of relation does the royal and future-royal material bear to it*.

That question has an answer with consequences, and the consequences are the book. If the terminus is a state, then it is entered rather than delivered. If it is entered rather than delivered, then no enlargement of a deliverer addresses a failure of entry. And if the corpus escalates its deliverer eight times over while the entry problem stands undiminished and undiagnosed at every stage, then the escalation is doing something other than converging on a solution, and a reader is owed an account of what.

Three debts beyond von Rad are worth naming at the front rather than in a footnote.

**Mowinckel**, whose account of messianism as a comparatively late development this book is compatible with and does not need. The escalation sequence of Book VIII redescribes the same material by content and commits to no dating beyond the corpus's own narrative order for its first three stages. A reader who holds Mowinckel's chronology will find nothing here to contradict it. A reader who rejects it will find nothing here that depends on it.

**Noth**, whose Deuteronomistic History supplies the frame within which the Joshua and Kings statements can be read as parts of a single editorial project rather than as unrelated survivals from different centuries. This book does not adjudicate the hypothesis. It does use the fact that the hypothesis is available and widely held as a reason to treat the Joshua-to-Kings material as one witness where the argument would otherwise be treating four.

**The source-critical literature on 1 Samuel 8 through 12**, which this book takes no position on while depending entirely on its having been done. The classical division into pro-monarchic and anti-monarchic strands is what makes the final form's retention of both legible as a decision rather than as a muddle. Without that literature, Chapter 52 would have nothing to say.

A fourth debt is harder to name because it is diffuse. The sabbath literature is enormous and this book touches it at exactly one point, where the terminal root-field of Chapter 9 overlaps with the institution. That overlap is real and this book does not develop it. A reader whose interest is the sabbath as institution and sign will find this book adjacent to their subject and not about it, and will find one paragraph at Chapter 37 that they could have written better.

## 8. What This Book Does Not Do


Six disclaimers. Each will be violated by some reader's summary and each is therefore stated here in a form that can be pointed at.

**It does not propose a compositional history.** The escalation sequence of Book VIII is ordered by content, each stage answering the failure of the one beneath it. No dating is claimed for it beyond the narrative sequence the corpus itself supplies for its first three stages. A reader who takes the sequence as a chronology has taken more than is offered, and Chapter 84 says so again at the point where the temptation is strongest, which is the point at which the sequence looks most like a development.

**It does not resolve the source-critical question about the monarchy.** The classical division of 1 Samuel 8 through 12 remains available and this book takes no position on it. What it does claim is that the final form's preservation of both strands is itself the datum, and that a redaction which retains an itemized indictment of kingship on the same scroll as the royal psalms is doing something a reader should account for rather than dissolve. That claim is compatible with every account of how the material got there.

**It does not argue about the truth of any expectation.** Chapter 107 states at length why nothing in the argument depends on that, and Chapter 6 has already stated the limit case.

**It does not claim the royal material is late, secondary, unreal, or an intrusion.** The claim is about how the corpus files the material relative to a terminus it names separately. A thing can be filed as a means and be entirely real, entirely early, and entirely central to the community that carried it. A road is not less real than a destination and is usually more travelled.

**It does not read against the tradition in order to read against it.** This book declines to filter the text through later interpretive schools, and that decline is a methodological choice with a stated reason, which is testability. It is not a claim that those schools are wrong, and it is emphatically not the posture of a reader who finds it satisfying to disagree with everyone. Where a traditional reading and the reading here converge, the convergence is noted. There are considerably more such points than the framing of this chapter would suggest, and Chapter 105 lists them.

**It does not adjudicate any living religious claim.** The corpus is the object. The communities that hold it are not on trial here, and no sentence in this book should be quoted as though they were. That request will not be honoured by everyone and it is made anyway.

One positive statement to close a chapter of negations. What this book does is read a corpus closely enough to notice that it has a vocabulary for its own terminus, that the vocabulary is precise, that the corpus uses it consistently, and that the relation between that vocabulary and the royal material is stated by the corpus in its own grammar rather than left for a reader to supply. Everything after this page is that reading.

:::book II | THE FOUR ROOTS


## 9. Šbt · The Hand Comes Off the Work


The account of creation closes not on a seventh act of the same kind as the six but on a cessation. *Wa-yikhal ʾelohim ba-yom ha-shevi'i melaʾkto ʾasher ʿasah, wa-yishbot ba-yom ha-shevi'i mi-kol melaʾkto ʾasher ʿasah.*

The verb is *šbt*, and the first thing to establish about it is what it does not mean. It is not a fatigue word. There is no exhaustion in it, no recuperation, no restoration of a depleted capacity. The image in *šbt* is the hand coming off the work. A thing that was proceeding stops proceeding. Whether the one who stops is tired is not in the root and is not in the passage, and Genesis 2 supplies no predicate that would suggest it.

This matters because the English word rest carries fatigue as its dominant sense, and a reader working in English will import the fatigue without noticing the import. Once fatigue is in the picture, the seventh day becomes a recovery and the terminus of the promise becomes a reward for effort, which is a coherent theology and is not what the vocabulary says. The corpus has other resources for exhaustion. *Yaʿaf* and *yagaʿ* both carry it, and Isaiah 40:28 uses both to deny them of God in the same breath: *loʾ yiʿaf we-loʾ yigaʿ*. The denial is explicit and it is made with the words that would carry the sense. *Šbt* is not among them.

The root's ordinary usage confirms the reading. Manna ceases, *wa-yishbot ha-man*, on the day after they eat of the produce of the land at Joshua 5:12. A thing that had been happening stops happening; nobody rests. Leviticus 26:6 uses the hiphil for the removal of dangerous animals from the land, *we-hishbatti ḥayyah raʿah min ha-ʾareṣ*, causing them to cease. The land keeps its sabbaths at Leviticus 26:34 with the same root in a form that makes the land the subject of a cessation. Amos 8:4 has the merchants asking when the new moon will be over so they can sell grain, and when the sabbath will be over, *we-ha-shabbat we-niftaḥah bar*: for them the sabbath is precisely a stoppage of business, and their impatience with it is the point of the oracle.

Two further features of the root's placement in Genesis 2 are worth recording because they recur throughout this book.

First, the seventh day is the only day of the seven that is blessed and sanctified, *wa-yevarekh ʾelohim ʾet yom ha-shevi'i wa-yeqaddesh ʾoto*, and it is the only one with no evening-and-morning formula closing it. The other six each close. The seventh is not closed in the text. Whatever is intended by that, the text has left the seventh day grammatically open in a series where closure is the pattern, and a reader is entitled to notice a break in a pattern the author established six times.

Second, the object of the cessation is named twice in the same verse: *melaʾkto ʾasher ʿasah*, his work which he had made, appearing in both halves. The repetition fixes the referent. What ceases is the making. Nothing else is said to cease and nothing is said to begin.

The reason this root opens Book II rather than the one the promise actually uses is that *šbt* fixes the semantic field. The corpus has a word for the terminal position in its own foundational narrative, that word denotes cessation and not recuperation, and the terminus of the promise will be named in a cognate field. A reader who has understood that the seventh day is a stopping rather than a napping is in a position to read the rest of this book. A reader who has not will keep supplying a tiredness the text does not contain.

## 10. Nwḥ · The Alighting That Stays


The second root is *nwḥ*, and it is the one the promise uses.

Its image is settlement: a thing that was in motion comes to a place and stays there. The clearest instance in the corpus is not a theological one. At Genesis 8:4 the ark comes to rest on the mountains of Ararat, *wa-tanaḥ ha-tevah ʿal harey ʾAraraṭ*. The vessel has been afloat and moving; it grounds and stops moving; that grounding is *nwḥ*. Nothing about fatigue enters. The ark is not tired. It has arrived.

Compare the same chapter three verses earlier for the contrast that fixes the sense. The dove sent out at 8:9 finds no *manoaḥ le-khaf raglah*, no resting-place for the sole of her foot, and returns to the ark. The word is a nominal from the same root and it names a place a foot can settle on. The dove's problem is not weariness; it is that the waters are still over the face of the earth and there is nowhere to come down. *Nwḥ* is about a landing site.

That is the vocabulary in which the promise's terminus is named, and once the image is fixed the theological uses become legible rather than vague.

Deuteronomy 12:9 states the position negatively and in the perfect: *ki loʾ vaʾtem ʿad ʿattah ʾel ha-menuḥah we-ʾel ha-naḥalah ʾasher YHWH ʾeloheykha noten lakh*. You have not yet come to the resting-place and to the inheritance. The construction is *baʾ ʾel*, to come to, which is a verb of arrival at a location. *Ha-menuḥah* is the nominal of settlement and it stands in a pair with *ha-naḥalah*, the inheritance. Two nouns, one preposition, one motion-verb. Whatever else the terminus is, the grammar makes it a place one arrives at.

The very next verse supplies the causative: *we-heniaḥ lakhem mi-kol ʾoyeveykhem mi-saviv wi-shavtem beṭaḥ*. He will cause you to settle from all your enemies round about, and you will dwell in safety. The hiphil *heniaḥ* is the standard form for the divine act throughout the Deuteronomistic material, and it will recur at Joshua 21:44 and across Chronicles. It is worth naming its shape now, because Chapter 62 turns on it. The form is causative and its subject is God. Somebody causes the settling. The one settled is the object.

The nominal *menuḥah* is the noun this book will use most, and it is worth separating from its near neighbours. It is not *shalom*, which is a much wider word covering wholeness, welfare, and the absence of hostility, and which Chapter 20 addresses separately. It is not *beṭaḥ*, which is security or confidence and appears beside *menuḥah* at Deuteronomy 12:10 as a distinct predicate. It is not *nawah*, a pasture or habitation, though the roots are visually similar and are occasionally confused in translation. *Menuḥah* is the state of having settled, and the corpus uses it of a person, of a people, and of a place, and once, at 1 Chronicles 22:9, of a man who is to be characterized by it.

One further site fixes the root's range in a direction that will matter at Book VI. At Isaiah 11:2 the spirit of the LORD *we-naḥah ʿalaw*, settles upon him. The same root, the same image of a coming-down-and-staying, used of a spirit alighting on a figure. That is a real messianic use of *nwḥ* and this book will not pretend otherwise. What it is not is a use in which the figure gives rest. It is a use in which something settles on him. The direction of the verb is worth keeping in view from here on, because the direction turns out to be the whole finding of Chapter 17.

## 11. Šqṭ · The Land Is Quiet


The third root is *šqṭ*, and its subject is characteristically the land.

Its sense is undisturbedness: quiet from outside molestation. Not internal peace, not the absence of conflict in general, but the specific condition of not being troubled from without. The corpus's densest deployment of it is the refrain in Judges, and the refrain is worth setting out in full because it is one of the most underweighted facts in the whole discussion.

*Wa-tishqoṭ ha-ʾareṣ ʾarbaʿim shanah*, and the land was quiet forty years, at Judges 3:11 after Othniel. *Wa-tishqoṭ ha-ʾareṣ shemonim shanah*, eighty years, at 3:30 after Ehud. Forty years at 5:31 after Deborah and Barak. Forty years at 8:28 after Gideon. Four deliveries, two hundred years of quiet in aggregate, and the deliverers are a nephew of Caleb, a left-handed Benjaminite with a homemade dagger, a woman judging under a palm tree, and a man threshing wheat in a winepress because he was afraid.

The refrain is formulaic, which is sometimes taken as a reason to discount it. That gets the inference backwards. A formula is a statement the corpus makes repeatedly in fixed language, which is a mark of settled usage rather than of carelessness, and the fact that the same clause is used four times about four different deliverers is what makes it evidence about the category rather than about any one of them.

The root's non-theological uses confirm the sense. Joshua 11:23 closes the conquest with *we-ha-ʾareṣ shaqṭah mi-milḥamah*, the land had quiet from war, where the source of the disturbance is named and it is external. Judges 18:7 describes the people of Laish as *shoqeṭ u-voṭeaḥ*, quiet and secure, and the description is immediately followed by their being destroyed, which is a grim way of establishing that *šqṭ* is a condition and not a guarantee. Isaiah 14:7 has the whole earth at quiet, *naḥah shaqṭah kol ha-ʾareṣ*, on the fall of the king of Babylon, with both roots in one clause. Jeremiah 30:10 promises Jacob *we-shaqaṭ we-shaʾanan we-ʾeyn maḥarid*, quiet and at ease with none to make afraid, where the third clause glosses the first two by naming the absence of a disturber.

Two consequences follow and both bear directly on the argument of this book.

**The terminus is repeatedly delivered by ordinary agents.** Four times in one book, by four deliverers none of whom is a king, none of whom is anointed, and none of whom founds anything. That is not an incidental observation. It is a datum about what kind of agent the condition requires, and the answer the corpus gives is: not a special one.

**The condition is temporary and the corpus says so.** Forty years, eighty years, forty, forty. Each period ends and the cycle restarts with the people doing evil again. This is often read as a comment on the inadequacy of the judges, and it can be. It can also be read as a comment on the receiver, since in every case the corpus attributes the ending to what the people did and not to a failure in the deliverance. Book IV takes that up.

## 12. Rgʿ · Repose at the End of a Walk


The fourth root is *rgʿ*, and it is the smallest of the four and the most personal.

Its subject is a person and its sense is relief. The corpus's decisive site is Jeremiah 6:16 and the whole verse deserves setting out, because it is the single passage in this book that carries the most weight per word.

*Koh ʾamar YHWH, ʿimdu ʿal derakhim u-reʾu, we-shaʾalu li-netivot ʿolam ʾey zeh derekh ha-ṭov u-lekhu vah, u-miṣʾu margoaʿ le-nafshotekhem. Wa-yomeru loʾ nelekh.*

Stand at the roads and look, and ask for the ancient paths where the good way is, and walk in it, and find *margoaʿ* for your souls. And they said, we will not walk.

*Margoaʿ* is the nominal, and its image is the repose at the end of a walk. Not the absence of walking; the condition arrived at by walking. That is exactly the shape of the terminus this book will argue for, and it appears here in a verse that also supplies the diagnosis of why the terminus is unoccupied, in the last four words.

Three features of the verse are load-bearing and each is returned to later.

**The paths already exist.** *Netivot ʿolam*, ancient paths. Nothing is being built, revealed, or awaited. The instruction is to ask where they are and walk on them. Chapter 35 works this against the alternative reading, in which the deficit is something withheld.

**The instruction is an ordinary imperative addressed to the hearer.** Stand, look, ask, walk. Four verbs, all second person plural, no intermediary in any of them. This is the Deuteronomy 30:11-14 shape in a different book and a different vocabulary.

**The refusal is spoken by the hearers and quoted.** *Wa-yomeru loʾ nelekh.* The corpus does not describe them as unable. It quotes them declining. Whatever is to be said about the hardening texts of Isaiah 6 and Deuteronomy 29, and Chapter 39 says a good deal, this verse has nothing withheld and nothing made heavy. It has an offer and a refusal.

The root's other uses are few and they sharpen rather than complicate the sense. Deuteronomy 28:65 threatens that among the nations *loʾ targiaʿ*, you will find no repose, and pairs it with a trembling heart and failing eyes: the loss of *rgʿ* is stated as a psychological condition and not a physical one. Isaiah 34:14 has the night-creature finding *manoaḥ* in the ruins of Edom, using the *nwḥ* nominal in a parallel position, which shows the two roots overlapping at the edges without being interchangeable at the centre.

A homonym has to be flagged. *Regaʿ* meaning a moment is spelled identically and is common. Isaiah 54:7-8 uses it twice in two verses, *be-regaʿ qaṭon ʿazavtikh*, for a small moment I forsook you. Nothing in this book rests on a *rgʿ* site without the sense being checked, and the census of Chapter 15 excludes moment-sites explicitly.

## 13. The Census, I · What Can and Cannot Be Executed


The seed article behind this book named a single debt and capped its own strength on it. The debt was a census: the *nwḥ*, *menuḥah*, and *šqṭ* concordance across the whole corpus, with terminal-position sites isolated and the marked-to-unmarked ratio printed. This chapter and the six after it discharge as much of that debt as the available instruments allow and state precisely how much remains.

The statement of the limit comes first, because a partially discharged debt reported as discharged is worse than one reported as owed.

**What was not available.** No machine-readable Hebrew text of the Masoretic canon was accessible in the working environment where this census was executed, and no package registry reachable from that environment carried one. Every attempt to obtain one is recorded and every attempt failed. This is a fact about the working conditions and not about the world; a reader with Accordance, Logos, BibleWorks, or a printed Even-Shoshan can run the Hebrew census in an afternoon and should.

**What was available.** A complete English witness to the Hebrew Bible in machine-readable form: the Authorised Version of 1611 as printed in the Companion Bible, thirty-five files covering Genesis through Malachi. The text layer is uncorrected optical character recognition, which introduces noise, and the text is interleaved with an editor's notes, which introduces a different kind of noise. Both are handled and both are reported.

**What this instrument can and cannot do.** It can exhaustively isolate candidate sites in a way another reader can reproduce. It can answer a grammatical question about subject and object, because English preserves that relation. It cannot distinguish *šbt* from *nwḥ* from *šqṭ* from *rgʿ*, because the Authorised Version renders all four with rest, renders *nwḥ* also as quiet and set down and lay, and renders *šqṭ* also as rest. It therefore cannot produce the root-level ratio the debt names.

The honest summary is that this census narrows the debt rather than discharging it, and that the part it discharges is the part that turns out to matter most. The article's F1 asks whether the terminal sites are *systematically figure-indexed*, requiring a royal or eschatological agent. That is at bottom a question about who stands in the subject slot of the giving. English preserves subject and object. So the decisive question is answerable on the available witness even though the lexical question is not.

Every figure printed in the next six chapters is a count of English tokens. None is a count of Hebrew roots. Where a claim would require the Hebrew, the claim is not made.

## 14. The Census, II · The Raw Field


The first pass captures the English rest-field across all thirty-five Hebrew Bible files, deliberately over-generously, so that the filtering happens in the open at later passes rather than silently at the first one.

The search terms are the Authorised Version's renderings of the four roots and their obvious inflections: rest, rested, resteth, rests, resting, quiet, quietly, quietness, quieted, cease, ceased, ceaseth, ceasing, sabbath, sabbaths, ease, eased, repose, settled.

**The result is 878 candidate sites.**

The token distribution is as follows. Rest, 399. Sabbath, 134. Cease, 83. Quiet, 47. Sabbaths, 46. Ease, 34. Ceased, 32. Rested, 27. Settled, 21. Resting, 13. Ceaseth, 11. Quietness, 10. Rests, 6. Quieted, 5. Quietly, 3. Resteth, 3. Repose, 2. Ceasing, 1. Eased, 1.

Three observations about the raw field before it is filtered.

**The field is dominated by one token.** Rest and its inflections account for 448 of 878 sites, better than half. That concentration is itself the evidence for the conflation problem named in the last chapter: a single English word is doing the work of at least three Hebrew roots, and no amount of care with the English can separate them.

**The sabbath tokens are a large and mostly separate population.** 180 sites between sabbath and sabbaths, better than a fifth of the field. Most of these are the institution rather than the terminus: sabbath observance, sabbath offerings, sabbath violations, the sabbath-year and jubilee legislation, and the rotation of temple watches. They are excluded at the next pass by the governing-verb filter, which is the right way to exclude them, since the exclusion is then visible and reversible rather than a decision made at the search string.

**Two books return zero.** Joel and Obadiah carry no token in the field at all. Both are short. Nothing follows from this beyond a note that the field is not uniformly distributed, and the distribution is reported in the next chapter because uneven distribution is a fact a reader should be able to see.

## 15. The Census, III · Terminal Position


The second pass asks which of the 878 sites place the rest-word in terminal position, meaning as the object of a giving, an entering, a granting, a swearing, an inheriting, or a possessing. This is the position in which rest is the thing promised or arrived at rather than an ordinary pause, a weekly institution, or a stoppage of some other activity.

The filter is deliberately generous. It admits any site whose surrounding window contains one of the governing constructions, and the residue is then hand-sorted rather than trusted. A generous filter with a visible hand-sort is preferable to a tight filter whose exclusions nobody ever sees.

**114 of the 878 sites are terminal-position candidates.**

The distribution by book: Chronicles 16, Psalms 13, Isaiah 13, Jeremiah 9, Ezekiel 9, Joshua 8, Deuteronomy 7, Ezra-Nehemiah 7, Exodus 5, Kings 5, Lamentations 5, Genesis 4, Job 3, Leviticus 2, and one each in Numbers, Ruth, Samuel, Esther, Proverbs, Daniel, Habakkuk, and Zephaniah.

Three things in that distribution are worth stating.

**Chronicles leads.** Sixteen sites, more than any other book, in a work often treated as a late and theologically tidy retelling. Whatever else is true of the Chronicler, he is interested in this vocabulary and uses it more densely than his sources. Chapters 27 and 53 take that up, and the finding at Chapter 62 depends on it.

**The Deuteronomistic core is well represented but not dominant.** Joshua 8, Deuteronomy 7, Kings 5, Samuel 1. Twenty-one sites across the material where von Rad located the seam. That is a substantial share and it is not the whole field, which matters because an argument resting only on the Deuteronomistic History would be an argument about one editorial project rather than about the corpus.

**The prophets carry a third of the field.** Isaiah 13, Jeremiah 9, Ezekiel 9, Lamentations 5, plus the single sites in Daniel, Habakkuk, and Zephaniah: thirty-nine of 114. The terminus vocabulary is not confined to the historical books, which is the most common assumption about it.

Ezra-Nehemiah's seven is an artifact worth flagging honestly. Most of them are the sabbath-observance material of Nehemiah 13, which the governing-verb filter admitted on a construction and which the hand-sort removes. The number is reported before the hand-sort because reporting only post-sort numbers hides the sort.

## 16. The Census, IV · The Marking Test


The third pass is the one the debt was about. Of the 114 terminal-position candidates, how many carry a royal or eschatological agent?

The machine pass tests for the presence of any royal or eschatological token anywhere in a 220-character window around the site: king, kings, messiah, anointed, David, Solomon, branch, shoot, prince, son of man, shepherd, servant of the LORD, throne, sceptre, reign, kingdom, ruler, deliverer, redeemer.

**23 of the 114 carry such a token. 91 do not.** At the crude machine level that is 20.2 percent marked.

That figure is not the result, because a token in a window is not an index. The 23 have to be read, and reading them dissolves most of them.

**Six are the editor's own notes and not the biblical text.** Bullinger's 1913 apparatus is interleaved with the verse text in the OCR layer, and six of the twenty-three matches fall in his notes rather than in scripture. One of these is discussed separately at Chapter 17 because it is the most instructive item in the whole census.

**Six are the wrong sense of the English word.** Deuteronomy 3:13's the rest of Gilead is a remainder and not the root at all. The sabbath-watch rotations at 2 Kings 11:5, 2 Kings 11:9, and 2 Chronicles 23:4 are the day and not the terminus; the king appears in them because the watches are set at the king's house. Jeremiah 17:25 and Ezekiel 46:1-2 are sabbath-day observance passages in which kings and a prince appear in adjacent clauses about entering gates.

**Eleven are genuine terminus sites at which a king stands in the window.** These are the real cases and they are: 2 Samuel 7:1, 1 Chronicles 22:9 counted three times for three separate tokens in one verse, 1 Chronicles 22:18, 1 Chronicles 23:25, 2 Chronicles 14:6, 2 Chronicles 15:15, and 2 Chronicles 20:30 counted twice.

The eleven are the census's finding and the next chapter is about what they say.

## 17. The Subject Test, and What It Returned


Read the eleven.

2 Samuel 7:1. *Wa-YHWH heniaḥ lo mi-saviv mi-kol ʾoyevaw.* The LORD had given him rest round about from all his enemies. The king is present. He is the indirect object. The subject of the hiphil is YHWH.

1 Chronicles 22:9. *Hu yihyeh ʾish menuḥah wa-hanihoti lo mi-kol ʾoyevaw mi-saviv.* He shall be a man of rest, and I will give him rest from all his enemies round about. Solomon is named in the next clause. The subject of the giving is God, speaking in the first person.

1 Chronicles 22:18. *Ha-loʾ YHWH ʾeloheykhem ʿimmakhem wa-heniaḥ lakhem mi-saviv.* Has he not given you rest on every side. Subject named, and it is not the king; the addressees are the leaders of Israel.

1 Chronicles 23:25. *Heniaḥ YHWH ʾelohey Yisraʾel le-ʿammo.* The LORD God of Israel has given rest to his people. David is the speaker. The subject of the verb is God and the recipient is the people; no king occupies either slot.

2 Chronicles 14:6. *Ki heniaḥ YHWH lo.* Because the LORD had given him rest. Asa is the recipient.

2 Chronicles 15:15. *Wa-yanaḥ YHWH lahem mi-saviv.* The LORD gave them rest round about. The people are the recipient.

2 Chronicles 20:30. *Wa-yanaḥ lo ʾelohaw mi-saviv.* His God gave him rest round about. Jehoshaphat is the recipient.

**Eleven out of eleven. The king is the recipient. The giver is named in the same clause, and the giver is God.**

That is a stronger result than the argument required and it was not the result being looked for. The census was run to answer whether the terminus sites are figure-indexed, and the expected answer was that most are not. The answer that came back is that the ones which *are* marked are marked in the opposite direction: they are precisely the sites at which the corpus takes the trouble to say that the king received it.

A fourth pass tested the converse directly. Query: any clause anywhere in the corpus in which a royal or eschatological noun stands as the grammatical subject of a giving-verb governing rest, quiet, quietness, or repose.

**Two hits, and both dissolve.**

The first is 1 Chronicles 22:9 again, matched because Solomon's name precedes the second half of God's speech. The subject of *I will give* is God. The regex caught a proximity, not a subject.

The second is Bullinger's note on Psalm 101, and it is the most useful thing the census produced. His note reads: *of David. Relating to the true David, and His coming rule to give rest to the earth.* There it is: a royal figure as the subject of giving rest, in a sentence written in 1913 by an editor, attached to a psalm that does not say it.

**Zero verses. One commentator's gloss.** The figure-indexed reading of the terminus has to be supplied from outside the text because the text does not carry it, and the census caught the supply happening on the page.

## 18. What the Census Settles


Three results, stated at the strength the instrument supports and no higher.

**The terminus sites are overwhelmingly unmarked.** 91 of 114 carry no royal or eschatological token at all in a generous window. That is 80 percent at the crude level and higher after the hand-sort removes the six note-matches and the six wrong-sense matches, since both categories were counted as marked. Post-sort, 103 of 114 sites are unmarked and 11 are marked-as-recipient. **Marked-as-agent: zero.**

**Where a king appears at a terminus site, he appears as recipient.** Eleven for eleven, with the giver named in the clause. This is not the absence of a pattern. It is a pattern running the other way, and it converges with the conferral grammar Book VI documents from an entirely different direction, which is the strongest kind of convergence available: two instruments, no shared premise, one result.

**F1 does not fail.** The article's first falsification criterion asked whether the terminal clauses are systematically figure-indexed such that the frame is not removable. On the available witness they are not, and the sites that come closest are sites where the corpus explicitly makes the figure the object.

One caution about the second result, because it is the one most likely to be overstated by a sympathetic reader. Eleven sites is a small number and they cluster in two books, Samuel and Chronicles, which are related. A skeptic can reasonably say that the eleven are one editorial habit rather than a corpus-wide grammar. The reply is that Book VI reaches the same conclusion from Psalms, Deuteronomy, Ezekiel, and Daniel, none of which is in the Chronicler's ambit, and that the convergence is what carries the weight rather than the eleven alone. The eleven on their own would be suggestive. The eleven plus Book VI is a finding.

## 19. What the Census Leaves Open


The debt is narrowed and it is not paid. Five things remain owed and each is stated so that a reader with better tools can execute it.

**The root-level ratio.** The count that the article named is a Hebrew count and this is an English one. The Authorised Version renders all four roots with rest and renders two of them with quiet, so the ratio of *nwḥ* sites to *šqṭ* sites to *šbt* sites in terminal position is unknown here. It is straightforwardly recoverable by anyone with a Hebrew concordance.

**The pericope test.** The marking test here used a 220-character window, which is an arbitrary proxy for the pericope. A proper execution would mark pericope boundaries and test whether a royal figure stands anywhere within them. That test would return a higher marked count than 20 percent, since pericopes are longer than 220 characters, and the interesting question is how much higher.

**The negative field.** This census counted where the terminus vocabulary appears. It did not count where a royal figure appears without it, which is the complementary question and would say something about whether the two vocabularies avoid each other or merely fail to coincide.

**Verse identification.** The OCR text layer does not carry reliable chapter markers, so the census identifies sites by book and by an inferred verse number, and the inference fails in places. Every verse cited in Chapter 17 has been checked by hand against the text. The unquoted remainder has not been individually verified and no claim is made about any site not quoted.

**The noise floor is unmeasured.** Uncorrected OCR drops and mangles words. A word the OCR destroyed is a site this census never saw. There is no way to estimate the rate from inside the instrument, and the direction of the resulting error is unknown, so no correction is applied and the possibility is simply on the record.

The residual position is this. The census's central result is a grammatical one, and grammar is the part of the Hebrew that English preserves best. The direction of that result is unlikely to reverse under a better instrument. Every other figure in Book II should be treated as provisional and every one of them is recoverable.

## 20. Šalom Beside the Four, and Why It Is Not a Fifth


A reader who has followed four roots will ask about a fifth, and the answer is that *shalom* belongs to a different category and admitting it would wreck the census.

*Shalom* is not a rest-word. Its root *šlm* carries completeness, wholeness, and the settling of an account. It covers welfare in a greeting, the absence of hostility in a treaty, the soundness of a stone that has not been cut, the payment of a debt, and the state of a person who is unharmed. Genesis 43:27 uses it three times in one exchange about whether an old man is well. 2 Kings 4:26 has the Shunammite say *shalom* over her dead son. Job 9:4 asks who has hardened himself against God *wa-yishlam*, and prospered.

The word's range is wide enough that it can occupy the terminal position, and it does. Isaiah 9:6 gives the *sar shalom* as the fourth throne-name. Isaiah 54:10 has the covenant of *shalom* not removed. Ezekiel 34:25 and 37:26 both make a covenant of *shalom* with the restored people. Numbers 25:12 gives Phinehas the covenant of *shalom*. Micah 5:4 says of the ruler from Bethlehem *we-hayah zeh shalom*.

The reason it is excluded from the census is precisely that range. A word that can mean wholeness, welfare, treaty, payment, and safety cannot be used to test whether the corpus has a *specific* vocabulary for its terminus, because it will match everywhere and the match will carry no information. Including it would have inflated the field from 878 sites to something in the thousands and would have made the marking test meaningless, since *shalom* appears constantly in royal contexts for reasons that have nothing to do with the terminus.

The four roots were chosen because each is narrow. *Šbt* is cessation and its subject is a worker. *Nwḥ* is settlement and its subject is a mover. *Šqṭ* is undisturbedness and its subject is characteristically the land. *Rgʿ* is relief and its subject is a person. Four distinct offices with four distinct subjects and four distinct images, none of them synonyms, and this book does not treat them as such. A fifth word that overlaps all four and much else besides is not a fifth member of that set.

One consequence of the exclusion should be conceded rather than hidden. *Shalom* is the word the tradition most often uses for what this book calls the terminus, and a reader steeped in that tradition will feel its absence throughout. The exclusion is methodological and it is not a claim that *shalom* is unimportant or that the tradition is wrong to use it. It is a claim that a wide word cannot do a narrow test's work.

And there is a positive result inside the exclusion. Deuteronomy 12:10 puts *menuḥah*'s causative beside a different security-word, *wi-shavtem beṭaḥ*, and Jeremiah 30:10 puts *šqṭ* beside *shaʾanan*. The corpus itself distinguishes the settling from the security that follows it, using two words where one would have done. That is a small piece of evidence that the narrow reading of the four roots is the corpus's own and not an imposition, and it is offered at that weight.

:::book III | THE TERMINUS


## 21. Genesis 2:2 and the Seventh Position


The corpus opens with six days of making and a seventh of something else, and the something else is the position this book is about.

*Wa-yikhal ʾelohim ba-yom ha-shevi'i melaʾkto ʾasher ʿasah, wa-yishbot ba-yom ha-shevi'i mi-kol melaʾkto ʾasher ʿasah. Wa-yevarekh ʾelohim ʾet yom ha-shevi'i wa-yeqaddesh ʾoto, ki vo shavat mi-kol melaʾkto ʾasher baraʾ ʾelohim la-ʿasot.*

Four observations, each checkable against the text, and each bearing on everything downstream.

**The seventh day is not a seventh act of the same kind.** Days one through six each contain a divine speech, a making, and a naming or a blessing, and each closes with the formula *wa-yehi ʿerev wa-yehi voqer*. The seventh contains no speech of creation, no making, and no evening-and-morning formula. It contains a completing, a ceasing, a blessing, and a sanctifying. Three of those four have no parallel in the preceding six, and the one that does, the blessing, was previously applied to creatures and here is applied to a day.

**The seventh day is the only unclosed member of a closed series.** Six times the text says evening and morning. The seventh time it does not. Whatever is meant by that, a break in a pattern the author has established six times is a break the author made, and the reader who notices it is reading rather than importing. This book takes no position on what the omission signifies. It records that the omission exists and that it exists at the position the corpus is about to make its terminal one.

**The object of the cessation is stated three times.** *Melaʾkto ʾasher ʿasah* appears in the first half of verse two and again in the second. *Melaʾkto ʾasher baraʾ ʾelohim la-ʿasot* appears in verse three. Three statements of the same object across two verses. What ceases is the making, and the repetition forecloses any reading in which something else is what stops. Nothing is said to begin.

**The vocabulary is cessation and not recuperation.** Chapter 9 established this and the point bears repeating in situ, because the whole downstream argument is vulnerable to a reader who imports fatigue at Genesis 2 and never removes it. There is no exhaustion in *šbt*. Isaiah 40:28 explicitly denies of God the two words that would carry exhaustion, *loʾ yiʿaf we-loʾ yigaʿ*, and Genesis 2 does not use either.

What follows from the four is a single structural fact and it is worth naming precisely because it is easy to state too grandly. **The corpus places a cessation at the terminal position of its opening account, blesses and sanctifies that position, and describes it in a vocabulary that carries no fatigue and no reward.** That is all. It is not yet a claim about the promise, about the land, about the monarchy, or about any figure. It is a claim about what kind of thing occupies the last slot in the first story.

Two later texts pick that slot up and neither of them is subtle about it.

**Exodus 20:11** grounds the sabbath commandment in Genesis 2 by direct citation: *ki sheshet yamim ʿasah YHWH ʾet ha-shamayim we-ʾet ha-ʾareṣ ʾet ha-yam we-ʾet kol ʾasher bam wa-yanaḥ ba-yom ha-shevi'i*. The verb here is not *šbt* but *nwḥ*, the settling-root, which is a fact the English obscures completely and which matters for this book's argument. The Decalogue's own citation of Genesis 2 substitutes the second root for the first. The two are being treated as occupying one position.

**Deuteronomy 5:15** grounds the same commandment differently, in the exodus rather than in creation, and the difference between the two groundings is one of the standard problems of the Decalogue's transmission. This book takes no position on it. It notes that Exodus grounds the seventh position in a cessation from making and Deuteronomy grounds it in a deliverance from servitude, and that both are terminal positions of a completed action.

**Psalm 95:11** will name the object of the promise as *menuḥati*, my rest, using the nominal of the root Exodus 20:11 used for Genesis 2. Chapter 26 works that verse in full. What is established here is only that the vocabulary chain runs: Genesis 2 cessation, Exodus 20 settling, Psalm 95 my settling-place. Three books, one position, two roots the corpus treats as adjacent.

A reader may object that Genesis 2 is about a day and Psalm 95 is about a land, and that running a vocabulary chain between them is a conflation. The objection is good and the answer is that the corpus runs the chain, not this book. Exodus 20:11 puts the *nwḥ* root at Genesis 2's position. Hebrews is not available to this argument and is not needed for it; the citation is inside the Torah. What the corpus does with a vocabulary is evidence about that vocabulary, and a reader who wants to separate the day from the land has to separate them against Exodus 20:11 rather than in the absence of it.

## 22. Deuteronomy 12:9 · Not Yet Come to the Rest


*Ki loʾ vaʾtem ʿad ʿattah ʾel ha-menuḥah we-ʾel ha-naḥalah ʾasher YHWH ʾeloheykha noten lakh.*

For you have not yet come to the resting-place and to the inheritance which the LORD your God is giving you.

This is the promise's terminus named in the corpus's own words, and it is worth taking the sentence apart before taking it up.

**The verb is one of arrival.** *Baʾ ʾel*, to come to. It governs a destination. This is not a verb of receiving, of being granted, or of having conferred; it is a verb of getting somewhere. The people are the subject. What they have not done is arrive.

**The negation is temporal and it is marked twice.** *Loʾ ... ʿad ʿattah*, not until now. The construction states a present deficiency against an implied future sufficiency. Deuteronomy 12 is set on the plains of Moab and the not-yet is a statement about the position at that moment.

**Two objects stand in a pair.** *Ha-menuḥah we-ha-naḥalah*, the resting-place and the inheritance. Both definite. Both governed by the one preposition, repeated. The pairing is doing work: an inheritance is a possession and a resting-place is a condition, and the corpus puts them in apposition without merging them.

**The relative clause has God as the giver.** *ʾAsher YHWH ʾeloheykha noten lakh*, which the LORD your God is giving you. The participle is present-progressive in force. The giving is underway while the arriving has not happened. That is the whole shape of this book in one verse and it is present in the corpus at the first statement of the terminus.

The next verse supplies the causative and the sequel.

*Wa-ʿavartem ʾet ha-Yarden wi-shavtem ba-ʾareṣ ʾasher YHWH ʾeloheykhem manḥil ʾetkhem, we-heniaḥ lakhem mi-kol ʾoyeveykhem mi-saviv wi-shavtem beṭaḥ.*

You will cross the Jordan and dwell in the land which the LORD your God is causing you to inherit, and he will cause you to settle from all your enemies round about, and you will dwell in safety.

Four verbs and their subjects, in order. You cross. You dwell. He causes to inherit. He causes to settle. Then you dwell in safety. The alternation is exact and it is not accidental: the human verbs are motion and residence, the divine verbs are both causatives, and the second human verb depends on the second divine one.

Three consequences, each returned to later.

**The terminus is named rather than inferred.** It has a lexeme. The lexeme is a state-word from the settling-root. The corpus does not describe a condition and leave a reader to name it; it supplies the noun.

**The terminus is stated with no figure in the clause.** No king, no anointed one, no branch, no messenger, no eschatological agent of any kind stands anywhere in Deuteronomy 12:9-10 or in the surrounding pericope. Under the criterion of Chapter 2, the strip here is the identity operation. This is a substantive content by the test, at the first place the corpus states it.

**The giver is named and it is God.** Twice, in two causatives, in one verse. The census of Chapter 17 found this pattern holding at every terminus site where an agent appears at all. Here it is at the beginning, in the Torah, before any king exists.

One further note on the pair. *Naḥalah* and *menuḥah* are not from the same root; *naḥalah* is from *nḥl* and *menuḥah* from *nwḥ*, and the similarity is aural rather than etymological. Whether the pairing is a deliberate assonance is a question this book has no way to settle. What is settleable is that the corpus repeats the pairing. Chapter 27 finds it again at 1 Chronicles 22:9 in a different form, where the *menuḥah* root generates a man's characterization and the inheritance is a temple.

## 23. Joshua 21:44 · He Gave Them Rest


*Wa-yanaḥ YHWH lahem mi-saviv ke-khol ʾasher nishbaʿ la-ʾavotam, we-loʾ ʿamad ʾish bi-fneyhem mi-kol ʾoyeveyhem, ʾet kol ʾoyeveyhem natan YHWH be-yadam.*

And the LORD gave them rest round about, according to all that he swore to their fathers, and not a man of all their enemies stood before them; the LORD delivered all their enemies into their hand.

Deuteronomy 12 said not yet. Joshua 21 says done. The two verses use the same root and the corpus places them at the two ends of one narrative arc, which is the seam von Rad identified and this book works.

The verse deserves close attention because a great deal is packed into it.

**The verb is the same root in a different stem.** Deuteronomy 12:10 used the hiphil *heniaḥ*. Joshua 21:44 uses *wa-yanaḥ*, which is also causative in force here. The subject is YHWH. The recipient is *lahem*, to them. The pattern of Chapter 62 is already fully formed.

**The fulfilment is stated against the oath.** *Ke-khol ʾasher nishbaʿ la-ʾavotam*, according to all that he swore to their fathers. This is not a partial or provisional statement. The clause explicitly measures the delivery against the promise and finds it complete.

**Two further clauses reinforce it.** Not a man stood before them. All their enemies were given into their hand. The verse says three things where one would have sufficed, which is the mark of a summary statement rather than a passing note.

**The next verse goes further still.** *Loʾ nafal davar mi-kol ha-davar ha-ṭov ʾasher dibber YHWH ʾel beyt Yisraʾel, ha-kol baʾ.* Not a word failed of all the good word which the LORD spoke to the house of Israel; all came to pass. The Hebrew *ha-kol baʾ* is as absolute as the language permits: the whole thing arrived.

The statement is repeated twice more in the same book. **Joshua 22:4**: *we-ʿattah heniaḥ YHWH ʾeloheykhem la-ʾaḥeykhem ka-ʾasher dibber lahem*, now the LORD your God has given rest to your brothers as he said to them, spoken to the eastern tribes as they are sent home. And **Joshua 23:1**: *wa-yehi mi-yamim rabbim ʾaḥarey ʾasher heniaḥ YHWH le-Yisraʾel mi-kol ʾoyeveyhem mi-saviv*, after the LORD had given Israel rest from all their enemies round about, which opens Joshua's farewell.

Three statements, one book, one root, all in the perfect or with perfect force. The corpus is not hedging.

Now the difficulty, and it should be faced squarely rather than managed.

Joshua 13:1 opens the second half of the book with *we-ha-ʾareṣ nishʾarah harbeh meʾod le-rishtah*, and there remains very much land to be possessed. Judges 1 lists the places from which the tribes did not drive out the inhabitants. Judges 2:3 has the LORD declaring he will not drive them out. On any reading, the book that says all came to pass also says a great deal did not.

Three responses are available in the literature and this book takes none of them as its own.

The first is compositional: the statements come from different hands and the tension is a seam. That may be right and it is not this book's business.

The second is qualitative: the rest given was real but partial, and the full rest awaits. This is the majority reading and it is coherent. Its cost is that it requires the corpus to be using *heniaḥ* in the perfect, three times, with *ha-kol baʾ* attached, to mean something less than what those words say.

The third is the one this book will develop, and it is not a resolution of the tension but a relocation of it. **The corpus states the giving as complete and states elsewhere that the receiving did not happen.** Those are different predicates with different subjects. A gift can be given completely and not taken up, and the two statements are then both true without either being partial. Whether that is what the corpus means is the question Book IV takes up, and Psalm 95:11 is the hinge.

What Joshua 21:44 establishes for the present purpose is narrower and is not in dispute on any reading. **The delivery is attributed to God, stated in a completive form, measured against the oath, and delivered under a non-royal agent.** Joshua is not a king, is not anointed, founds no dynasty, and has no successor. The corpus attaches its strongest statement of the terminus to a man whose office ends when he dies.

## 24. Judges · Four Deliveries by Ordinary Agents


The book of Judges delivers the terminus four times, in a fixed formula, under four deliverers, and none of them is a king.

*Wa-tishqoṭ ha-ʾareṣ ʾarbaʿim shanah*, and the land was quiet forty years, at 3:11 after Othniel.
*Wa-tishqoṭ ha-ʾareṣ shemonim shanah*, eighty years, at 3:30 after Ehud.
*Wa-tishqoṭ ha-ʾareṣ ʾarbaʿim shanah*, forty years, at 5:31 after the battle at the Kishon.
*Wa-tishqoṭ ha-ʾareṣ ʾarbaʿim shanah*, forty years, at 8:28 after Gideon.

Two hundred years in aggregate. The formula is identical in three of the four and differs in the fourth only in the numeral.

The deliverers repay attention because the corpus goes out of its way to make them unimpressive.

**Othniel** is Caleb's younger brother or nephew, depending on how the genealogy is parsed, and his qualification in the narrative is that he took Kiriath-sepher and married Achsah. The text says the spirit of the LORD was upon him and he judged and went out to war, and gives no further detail.

**Ehud** is left-handed, which the text specifies as *ʾiṭṭer yad yemino*, restricted in his right hand, and which the narrative treats as an operational advantage because the guards checked the wrong thigh. He makes his own weapon, a cubit long, two-edged. The assassination is described in physical detail that has embarrassed commentators for two thousand years.

**Deborah** judges under a palm tree and Barak refuses to go without her. The victory is credited in the prose to a rainstorm and in the poetry to the stars fighting from their courses, and the killing blow is struck by Jael with a tent peg. Judges 5:31 attaches the quiet-formula to the end of that.

**Gideon** is threshing wheat in a winepress to hide it from the Midianites when he is called, asks for two signs with a fleece, is told his army is too large twice, and attacks with three hundred men carrying jars and torches.

None of the four is anointed. None founds a dynasty. Gideon is offered one and refuses, in the verse Chapter 42 will treat as the corpus's opening position on monarchy. Three of the four have successors only in the sense that the cycle restarts.

Three consequences.

**A terminus repeatedly delivered by ordinary agents is not a terminus requiring an extraordinary one.** This is the load-bearing inference and it should be stated carefully. The claim is not that no extraordinary agent could deliver it, nor that the corpus never associates the terminus with a great figure. The claim is that the corpus, four times, in fixed language, attributes the delivery of the condition to circumstances in which no such figure is present. That is an existence proof and existence proofs are cheap to state and hard to refute.

**The condition is temporary and the corpus says why.** Each period ends. In every case the text attributes the ending to the people's return to what they had been doing, in the formula *wa-yosifu benei Yisraʾel la-ʿasot ha-raʿ be-ʿeyney YHWH*. The corpus never attributes the ending to a defect in the deliverance or to the death of the deliverer as such, though the death is usually mentioned. The failure is located at the receiver, four times, in the book that delivers the terminus four times. Book IV will find the same location in five further texts across three other books.

**The root is *šqṭ* and not *nwḥ*.** The Judges refrain uses the third root, whose subject is characteristically the land, and the subject here is the land. This is a real lexical difference and this book does not pretend the four roots are one word. What connects the Judges refrain to Joshua 21:44 is not the root but the position: both are terminal statements about the condition of Israel in the land after deliverance, and Joshua 11:23 uses *šqṭ* of exactly the situation Joshua 21:44 will describe with *nwḥ*. The corpus itself puts the two roots at one position in one book.

## 25. 1 Kings 8:56 · Announced as Already Given


*Barukh YHWH ʾasher natan menuḥah le-ʿammo Yisraʾel ke-khol ʾasher dibber, loʾ nafal davar ʾeḥad mi-kol devaro ha-ṭov ʾasher dibber be-yad Mosheh ʿavdo.*

Blessed be the LORD, who has given rest to his people Israel according to all that he promised; not one word has failed of all his good promise which he spoke by the hand of Moses his servant.

The setting is the dedication of the temple, the speaker is Solomon, and the statement is in the perfect. This is the corpus's second completive announcement of the terminus and it is made at the high point of the monarchy by the king who built the house.

Four features.

**The noun is the nominal.** *Natan menuḥah*, gave rest, using the substantive rather than the causative verb. The construction is a giving with a thing given. That grammatical shape recurs across Chronicles and it is what makes the recipient-slot analysis of Chapter 17 possible.

**The recipient is the people, not the king.** *Le-ʿammo Yisraʾel*, to his people Israel. Solomon is speaking and Solomon is not the object of the verb. At the single moment in the corpus where a king might most naturally have claimed the delivery for himself or for his throne, the king assigns it to the people and the giver to God.

**The measurement is against Moses.** *ʾAsher dibber be-yad Mosheh ʿavdo.* The fulfilment is measured not against the Davidic covenant of 2 Samuel 7, which had been given to this speaker's father, but against the word spoken through Moses. Solomon is standing in a temple his father was forbidden to build, at the peak of a dynasty, and he dates the promise to the man who never entered the land.

**The formula echoes Joshua.** *Loʾ nafal davar ʾeḥad mi-kol devaro ha-ṭov* is Joshua 21:45's *loʾ nafal davar mi-kol ha-davar ha-ṭov* with one word added. The Deuteronomistic editor is quoting himself, and the quotation puts the temple dedication and the conquest summary in the same frame. Whatever one makes of the composition, the final form has two completive statements of the terminus in matching language, one at the end of the conquest and one at the dedication of the house.

The difficulty here is the same as at Joshua and is if anything sharper. This is Solomon speaking, and the corpus will spend 1 Kings 11 on his apostasy, the division of the kingdom, and the loss of ten tribes. A statement that the rest has been given, spoken by a man the same book will convict, is a statement placed under strain by its own book.

Two things can be said about that and neither is a resolution.

The strain is not hidden by the corpus. 1 Kings 8 and 1 Kings 11 are four chapters apart, in one book, by any account of the composition. Whoever assembled the material let both stand.

And the strain runs the direction this book will argue. If the terminus were a possession, then Solomon's announcement and Solomon's apostasy would be a contradiction requiring one of the two to be qualified. If the terminus is a state, then a man can stand inside a delivered condition and walk out of it, and the corpus can say both things about him without either being false. Deuteronomy 8:12-14 supplies exactly that mechanism and Chapter 36 works it: eating and being satisfied, building good houses and dwelling in them, and then *ram levavekha we-shakhaḥta*, your heart is lifted up and you forget. A state entered and unnoticed is, to the one standing in it, indistinguishable from a state never given.

## 26. Psalm 95 · The Flock, the Hearing, the Non-Entry


The psalm that supplies the corpus's statement of non-entry supplies the diagnosis in the same breath, and the sequence of the two is the most compressed statement of this book's argument anywhere in the Hebrew Bible.

**Verse 7.** *Ki huʾ ʾeloheynu wa-ʾanaḥnu ʿam marʿito we-ṣoʾn yado; ha-yom ʾim be-qolo tishmaʿu.*

For he is our God and we are the people of his pasture and the sheep of his hand; today, if you will hear his voice.

**Verse 11.** *ʾAsher nishbaʿti ve-ʾappi ʾim yevoʾun ʾel menuḥati.*

To whom I swore in my anger that they should not enter my rest.

Four verses apart. The relation of the two is the psalm's whole structure and it runs in a fixed order: relation, then condition, then failure, then non-entry.

**The relation is stated first and it is unconditional.** We are the people of his pasture and the sheep of his hand. Nothing in verse 7a is conditioned on anything. The flock-relation is asserted.

**The condition is a hearing.** *Ha-yom ʾim be-qolo tishmaʿu*, today if you will hear his voice. The protasis is left grammatically open; the sentence has no stated apodosis and breaks off into the warning of verse 8. That incompleteness is itself striking and old: the sentence begins a conditional and never finishes it, and what follows instead is *ʾal taqshu levavkhem*, do not harden your hearts.

**The failure is a hardening of the heart, and the site is Meribah and Massah.** Verses 8 through 10 recite it: forty years, a generation, *ʿam toʿey levav hem*, a people erring in heart, *we-hem loʾ yadʿu derakhay*, and they did not know my ways.

**The non-entry is the consequence and it is stated in the terminus vocabulary.** *Menuḥati*, my rest, the nominal of the settling-root with a first-person suffix. Not their rest. His.

Five observations.

**The object is the same object.** *Menuḥah* at Deuteronomy 12:9, *heniaḥ* at Joshua 21:44, *menuḥah* at 1 Kings 8:56, *menuḥati* here. One vocabulary across four books. The psalm is not introducing a new concept; it is stating a negative about the concept the historical books stated positively.

**The verb is one of entering.** *Yevoʾun ʾel*, they shall come to. This is Deuteronomy 12:9's verb, *baʾ ʾel*, in the same construction with the same preposition. The corpus states the not-yet and the never-did with the same verb and the same object across the two books.

**The failure is located in an organ.** Heart, twice: *ʾal taqshu levavkhem* at verse 8 and *ʿam toʿey levav* at verse 10. And in a knowing: *loʾ yadʿu derakhay*. Book IV will find heart, eyes, and ears in five further texts and the psalm supplies the first member.

**The condition is a hearing and it is offered today.** *Ha-yom.* The adverb is emphatic by position and it is the same adverb Deuteronomy 30 uses five times to mark the near frame at 30:11-19. Two books, one adverb, one position: the thing is available now and the condition is a reception.

**The oath is sworn in anger and it concerns a generation.** *Nishbaʿti ve-ʾappi.* The corpus is describing the wilderness generation at Numbers 14, and the psalm reapplies it to its own hearers by the *ha-yom*. The reapplication is the psalm's own move, not a reader's.

What Psalm 95 does not say is worth stating as carefully as what it says, because F3 turns on it. **It does not say the rest was withheld.** It does not say the rest was postponed, reserved, delayed, or given to another. It says they did not enter it, and it gives the reason in the four preceding verses, and the reason is on their side. There is no clause anywhere in the psalm placing a deficiency in the object.

## 27. 1 Chronicles 22:9 · A Man of Rest, Named Before Birth


*Hinneh ven nolad lakh, hu yihyeh ʾish menuḥah, wa-hanihoti lo mi-kol ʾoyevaw mi-saviv, ki Shelomoh yihyeh shemo, we-shalom wa-sheqeṭ ʾetten ʿal Yisraʾel be-yamaw.*

Behold, a son shall be born to you; he will be a man of rest, and I will give him rest from all his enemies round about, for Solomon will be his name, and I will give peace and quiet to Israel in his days.

This verse is the densest single site in the whole census and it repays being taken apart word by word.

**Three of the four roots appear in one verse.** *Menuḥah* from *nwḥ*. *Hanihoti* from *nwḥ* in the hiphil. *Sheqeṭ* from *šqṭ*. Plus *shalom*, which Chapter 20 held outside the four for good reason but which the corpus places here beside two of them. This is the corpus assembling its own vocabulary field in a single sentence, and it is the best evidence available that the roots this book has separated are ones the corpus itself groups.

**The man is characterized by the state, not the source of it.** *ʾIsh menuḥah*, a man of rest. The construct is descriptive: he is a man belonging to, or marked by, the condition. It is not *ʾish meniaḥ*, a man who causes rest, which the language could have formed. The distinction is exactly the one Chapter 17's census turned on and here it is in the morphology.

**The giving is God's and it is stated in the first person twice.** *Wa-hanihoti lo*, and I will cause him to settle. *ʾEtten ʿal Yisraʾel*, I will give upon Israel. Two first-person verbs, one recipient who is the king, one recipient who is the people.

**The name is an etymology and the corpus supplies it.** *Ki Shelomoh yihyeh shemo*, for Solomon will be his name. The *ki* is causal or explanatory: he will be a man of rest *because* his name will be Solomon, which is to say the name encodes the condition. The corpus is doing philology on itself.

**The whole verse is a prospective justification for a building permit.** The context is David explaining why he was not permitted to build the temple and Solomon will be. Verse 8: *dam la-rov shafakhta*, you have shed much blood, and made great wars; you shall not build. Verse 10: he shall build a house for my name. The *menuḥah* is the qualifying condition for the building, and the corpus states that the man of war is disqualified and the man of rest is qualified.

Three consequences.

**The corpus can name a man for the terminus without making him its source.** This is the finding, and it is the sharpest available answer to the objection that Chapter 17's census was reading grammar too finely. Here is the single verse in the entire Hebrew Bible where a named king is most tightly bound to the terminus vocabulary, and the verse takes the trouble, in first-person divine speech, to say who gives it to him.

**The terminus is a precondition rather than a product.** Solomon has the rest *before* he builds. The sequence in the passage is: he will be a man of rest, I will give him rest, therefore he will build. The house is downstream of the condition, not the means to it.

**The prospective naming is a real oddity and it is not this book's business.** A son named before birth, with the name explained, is a device the corpus uses rarely. Whether 1 Chronicles 22 is the Chronicler's composition or draws on older material is a question this book does not enter. The verse says what it says in the received text and that is the object.

One further point closes the chapter and it is uncomfortable for a tidy reading. The Chronicler is writing after the monarchy has ended. He puts into David's mouth a divine speech naming Solomon a man of rest, in a book whose readers know how Solomon ended and how the house ended. Whatever he thought he was doing, he was not writing a triumphalist account of a delivered terminus. He was recording a designation, and Chapter 62 will find him doing the same thing three more times with a throne.

## 28. Ezekiel 37:14 · The Ingathering's Own Terminal Clause


Ezekiel 37 is the chapter of the dry bones, and it is the chapter that most nearly refutes this book. It deserves a careful reading for that reason and not in spite of it.

The vision runs from verse 1 to verse 14 and its structure is a sequence of divine acts. I will open your graves. I will bring you up. I will bring you into the land. I will put my spirit in you and you shall live. And then the last clause of the last verse.

*We-hinnaḥti ʾetkhem ʿal ʾadmatkhem, wi-daʿtem ki ʾani YHWH dibbarti we-ʿasiti neʾum YHWH.*

And I will settle you upon your own land, and you shall know that I the LORD have spoken and performed it.

**The final verb of the ingathering sequence is the settling-root in the hiphil.** *We-hinnaḥti*, and I will cause you to settle. This is the same form as Deuteronomy 12:10's *we-heniaḥ*, and it stands at the end of a chain of acts as the thing the acts arrive at.

That is a significant finding and it cuts in two directions at once.

**It supports the argument.** The corpus, at the climax of its most famous restoration vision, terminates the sequence in the settling-root and then in a knowing. The gathering is not the end of the sentence. Two further clauses follow it and the second is *wi-daʿtem ki ʾani YHWH*, and you shall know that I am the LORD, which is the recognition-formula that closes scores of Ezekiel's oracles. The vision ends in a settling and a knowing.

**It cost the argument a claim.** An earlier version of this project held that the messianic frame was only partly removable, on the ground that the restoration material could not be stated without the act-layer. Ezekiel 37:14 falsified it. The corpus states the terminus at the end of the act-layer in the terminus's own vocabulary, so the terminus is available even inside the passage that most fully belongs to the acts. The earlier claim is recorded here as dead rather than quietly removed, because a book that reports only its surviving positions is reporting half a method.

Now the difficulty. Verses 21 through 28 continue the chapter and introduce a figure.

Verse 22: one nation, one king over them all, *u-melekh ʾeḥad yihyeh le-khullam le-melekh*. Verse 24: *we-ʿavdi Dawid melekh ʿaleyhem we-roʿeh ʾeḥad yihyeh le-khullam*, my servant David king over them and one shepherd for all of them. Verse 25: *we-Dawid ʿavdi nasiʾ lahem le-ʿolam*, and David my servant prince to them forever. Verse 26: a covenant of peace, an everlasting covenant, and the sanctuary in their midst forever.

So the chapter contains both the terminus in its own vocabulary at verse 14 and a royal figure of maximal permanence at verses 22 to 25. A reader who wants to say the corpus subordinates the figure to the state has to say something about that.

Three things can be said and each is checkable.

**The two passages are separate oracles.** Verse 15 opens *wa-yehi devar YHWH ʾelay leʾmor*, and the word of the LORD came to me, saying, which is Ezekiel's standard formula for the beginning of a new unit. The bones vision runs 1 to 14 and closes on the recognition-formula. The two sticks oracle runs 15 to 28. They are adjacent and they are not one pericope, and the criterion of Chapter 2 operates on pericopes.

**Verse 14 is unmarked and verse 24 is marked.** Under the criterion the corpus therefore holds the terminus available without the figure, since it states it at verse 14 in a pericope where no figure stands. That is the whole test and it returns a clean result here.

**Verse 24 itself separates the roles.** *We-ʿavdi Dawid melekh ʿaleyhem* stands beside Ezekiel 34:24's *wa-ʾani YHWH ʾehyeh lahem le-ʾelohim we-ʿavdi Dawid nasiʾ be-tokham*, and Chapter 61 works that verse at length. The two roles are distinguished in one sentence by the corpus.

What this chapter concedes, and it should be conceded plainly, is that Ezekiel 37 as a whole is a chapter in which the terminus and the figure sit close together and are both stated at maximum strength. A reader who finds the pericope division too convenient has a real objection. The reply is that the division is marked by the corpus's own formula and not chosen for the occasion, and that the reader is invited to check verse 15.

## 29. Isaiah 11:9 and 2:4 · State Descriptions With No Agent


Two verses in Isaiah describe the terminal condition with no agent in the clause at all, and they are the strongest instances in the corpus of a content stated without anyone to state it about.

**Isaiah 11:9.** *Loʾ yareʿu we-loʾ yashḥitu be-khol har qodshi, ki maleʾah ha-ʾareṣ deʿah ʾet YHWH ka-mayim la-yam mekhassim.*

They shall not hurt nor destroy in all my holy mountain, for the earth shall be full of the knowledge of the LORD as the waters cover the sea.

**Isaiah 2:4.** *We-shafaṭ beyn ha-goyim we-hokhiaḥ le-ʿammim rabbim, we-kittetu ḥarvotam le-ʾittim wa-ḥanitoteyhem le-mazmerot, loʾ yisaʾ goy ʾel goy ḥerev we-loʾ yilmedu ʿod milḥamah.*

Nation shall not lift sword against nation, neither shall they learn war any more.

Take the second first, because it carries a complication that the first does not.

**Isaiah 2:4 has a judging subject in its first clause.** *We-shafaṭ beyn ha-goyim*, and he shall judge between the nations. The antecedent is YHWH from 2:3, who teaches his ways from Zion. So the verse is not agentless in its opening. What is agentless is its closing: the beating of swords into ploughshares has the nations as subject, and *loʾ yisaʾ goy ʾel goy ḥerev we-loʾ yilmedu ʿod milḥamah* has the nations as subject twice more. The terminal clause of the passage describes a cessation whose subject is the nations themselves, and there is no figure anywhere in Isaiah 2:2-4.

The verb in the final clause is worth noticing. *Loʾ yilmedu*, they shall not learn. Not they shall not fight; they shall not learn. The cessation is stated at the level of the practice rather than the event, which is a way of stating a condition rather than an outcome. A world in which nobody fights this year is a lull. A world in which nobody learns war is a different kind of object.

**Isaiah 11:9 is fully agentless in its operative clause.** *Ki maleʾah ha-ʾareṣ deʿah ʾet YHWH.* The earth is full of the knowledge of the LORD. The verb is stative, the subject is the earth, and there is no one performing the filling. The simile that follows, *ka-mayim la-yam mekhassim*, as the waters cover the sea, is a picture of saturation rather than of an act. Water covering the sea is not something water does; it is what the sea is.

The complication here is the reverse of Isaiah 2's. Isaiah 11:9 sits eight verses after Isaiah 11:1, the shoot from the stump, which is the corpus's most famous single messianic verse. The chapter opens with a figure and closes with an agentless state.

That is the structure the criterion is built to read, and here it reads cleanly. **The pericope contains a figure. The terminus clause does not.** Under the test, the content is available without the figure because the corpus states it in a clause the figure does not occupy, in a grammar that has no room for an agent.

An objection is available and should be answered. Isaiah 11:9 opens with *ki*, for or because, which subordinates it to what precedes. If the *ki* is causal, then the fullness of knowledge is the consequence of the figure's activity in verses 3 through 5, and the clause is figure-indexed after all by subordination.

Three responses.

The *ki* attaches most immediately to 11:9a, the not-hurting and not-destroying, and gives the reason for that. Whether it reaches back past 11:6-8 to the figure of 11:1-5 is a question about the scope of the conjunction, and it is genuinely open.

Even on the reading most favourable to the objection, the content of the clause is a state with no agent. A causal chain terminating in an agentless state is exactly the structure this book argues for: the figure is a means and the state is what the means moves toward. The objection, if granted, supplies the argument rather than damaging it.

And the corpus states the same content elsewhere without any figure in the vicinity. Habakkuk 2:14: *ki timmaleʾ ha-ʾareṣ la-daʿat ʾet kevod YHWH ka-mayim yekhassu ʿal yam*. Almost the same words, in a different book, in a passage about the fall of a plunderer, with no figure anywhere near it. Under the criterion the content is substantive on the strength of Habakkuk alone.

## 30. Leviticus 26 and 2 Chronicles 36:21 · The Exile Priced in Sabbaths


The corpus accounts the length of the exile in a currency, and the currency is the terminus.

**2 Chronicles 36:21.** *Le-malloʾt devar YHWH be-fi Yirmeyahu ʿad raṣetah ha-ʾareṣ ʾet shabbetoteha, kol yemey ha-shammah shavatah le-malloʾt shivʿim shanah.*

To fulfil the word of the LORD by the mouth of Jeremiah, until the land had enjoyed her sabbaths; all the days of her desolation she kept sabbath, to fulfil seventy years.

**Leviticus 26:34-35.** *ʾAz tirṣeh ha-ʾareṣ ʾet shabbetoteha kol yemey hoshammah we-ʾattem be-ʾereṣ ʾoyeveykhem, ʾaz tishbat ha-ʾareṣ we-hirṣat ʾet shabbetoteha. Kol yemey hoshammah tishbot ʾet ʾasher loʾ shavtah be-shabbetoteykhem be-shivtekhem ʿaleha.*

Then the land shall enjoy her sabbaths as long as she lies desolate and you are in your enemies' land; then the land shall rest and enjoy her sabbaths. As long as she lies desolate she shall rest, because she did not rest in your sabbaths when you dwelt upon her.

Four observations.

**The exile's duration is denominated in unkept sabbaths.** Not in years of punishment, not in units of guilt, not in a ratio of offences to consequences. In sabbaths the land did not get. The Chronicler is explicit that the seventy years is the sum of that debt.

**The land is the subject of the resting verb.** *Tishbat ha-ʾareṣ*, the land shall rest, using *šbt*, the cessation root of Genesis 2. Not the people. The land. Both texts are consistent on this and both use the same root.

**The debt is a debt of cessation.** *ʾEt ʾasher loʾ shavtah be-shabbetoteykhem*, that which she did not rest in your sabbaths. The thing owed is a stopping that did not happen. This is the sharpest available demonstration that the corpus treats the terminus vocabulary as denoting something that can be owed, accumulated, and repaid, which is not how one talks about a reward.

**The catastrophe is priced in the currency of the terminus.** That is the finding and it should be stated at the right strength. The corpus had many available vocabularies for exile: covenant, curse, wrath, scattering, the sword, all of which it uses elsewhere and Leviticus 26 uses at length in the preceding thirty verses. At the point of stating the duration, it switches to the sabbath-root and states the whole thing as an account being settled.

This is a stronger result than the argument required, and a convenient finding deserves the caution appropriate to one. Three qualifications.

**The sabbath here is the sabbatical year and not the seventh day.** Leviticus 25 legislates the seventh year of rest for the land, and Leviticus 26:34 is referring to that legislation. The root is the same and the institution is not. Chapter 9 established that the root is cessation regardless of the interval; the interval here is seven years and not seven days.

**The Chronicler is making an interpretive move and the corpus shows him making it.** He cites Jeremiah for the seventy years, which Jeremiah 25:11 and 29:10 supply, and he cites the sabbath-accounting, which Leviticus 26 supplies, and he joins them. Jeremiah does not say the seventy years are unkept sabbaths. The joining is the Chronicler's. That is a datum about how a biblical writer read his own corpus, and it is offered at that weight rather than as a claim about Jeremiah.

**Nothing about a figure enters here at all.** Neither text carries a royal or eschatological agent, in the clause or in the surrounding pericope. The exile is opened, endured, and closed in the terminus vocabulary with no figure named anywhere, and the closing at 2 Chronicles 36:22-23 is credited to Cyrus, which Chapter 71 takes up because Cyrus holds a title that ought to complicate everything and turns out to complicate exactly one thing.

## 31. A State Is Entered, Not Delivered


Book III has established a set of facts and this chapter draws the inference they support and stops there.

**The facts.**

The corpus names its terminus in a lexeme rather than describing a condition and leaving the naming to a reader. The lexeme is *menuḥah* and its verbal forms, from a root whose image is settlement.

It states the terminus as not yet reached at Deuteronomy 12:9, in a verb of arrival, with God named as the one giving.

It states the terminus as delivered at Joshua 21:44, in the causative, with God as subject and a non-royal agent presiding, and repeats the statement twice more in the same book.

It delivers the terminus four times in Judges under four ordinary deliverers, using the third root, with the land as subject.

It announces the terminus as already given at 1 Kings 8:56, in the perfect, at the dedication of the temple, with the people as recipient and the measurement taken against Moses.

It states the terminus as not entered at Psalm 95:11, using the same verb of arrival as Deuteronomy 12:9 and the same nominal with a divine suffix, and supplies the reason in the four preceding verses, and the reason is a hearing that did not happen and a heart that hardened.

It names a man for the terminus at 1 Chronicles 22:9 and takes the trouble, in the same verse, to say who gives it to him.

It terminates its greatest restoration vision in the settling-root at Ezekiel 37:14.

It states the terminal condition twice in Isaiah with no agent in the operative clause, and states the same content again in Habakkuk with no figure anywhere near it.

And it prices the exile in the currency of the terminus, in two books, with the land as the subject of the resting.

**The inference.**

A state is entered rather than delivered. That is a claim about a category and it is the only inference Book III needs.

The corpus's own grammar carries it. Deuteronomy 12:9 uses a verb of arrival and Psalm 95:11 uses the same verb negated. Both make the people the subject of the entering. The giving-verbs, by contrast, have God as subject throughout: *heniaḥ*, *wa-yanaḥ*, *natan menuḥah*, *hanihoti*, *we-hinnaḥti*. Two grammatical patterns, two different subjects, consistently distributed. God gives; the people enter or do not.

**The consequence, stated at exactly its strength and no further.**

If the terminus is entered rather than delivered, then a failure of entry is not addressed by an improvement in delivery. That is not yet an argument about the monarchy or about any figure. It is a conditional whose antecedent Book III has established and whose consequent Books IV and VIII will test against the corpus.

Two things Book III has not shown, and saying so here forecloses two misreadings.

**It has not shown that the corpus never associates the terminus with a figure.** It does, at Isaiah 11, at Ezekiel 34 and 37, at 1 Chronicles 22. The claim is that the corpus also states it without one, repeatedly, in clauses where the strip is the identity operation.

**It has not shown that the act-layer is unimportant.** Ezekiel 37:1-14 is an act-sequence and it is one of the great passages of the corpus. The claim is that the corpus terminates the sequence in the settling-root, which is a statement about where the sequence points and not about whether it matters.

What remains is the question Book IV takes up. If the terminus was given and not entered, where does the corpus locate the failure? The answer turns out to be uniform across five texts in three books, and it is not where a reader expecting a theodicy would look.

:::book IV | THE DEFICIT


## 32. Deuteronomy 29:3 · The Organ Not Given


*We-loʾ natan YHWH lakhem lev la-daʿat we-ʿeynayim lirʾot we-ʾoznayim lishmoaʿ ʿad ha-yom ha-zeh.*

And the LORD has not given you a heart to know, and eyes to see, and ears to hear, unto this day.

This is the corpus's first full statement of the deficit and it names three organs. Every subsequent statement in this book uses at least one of the three and most use two or three. The triad is not a rhetorical flourish; it is a fixed inventory the corpus returns to across four centuries of its own internal chronology.

The setting is worth having in view because it makes the verse harder rather than easier. Deuteronomy 29 opens with Moses summoning all Israel and reciting what they have seen. Verse 1: *ʾAttem reʾitem ʾet kol ʾasher ʿasah YHWH le-ʿeyneykhem be-ʾereṣ Miṣrayim*, you have seen all that the LORD did before your eyes in the land of Egypt. Verse 2: the great trials, the signs, the wonders. Verse 4: forty years in the wilderness, clothes not worn out, sandals not worn out. Verse 5: no bread, no wine, no strong drink, *le-maʿan tedʿu ki ʾani YHWH ʾeloheykhem*, that you may know that I am the LORD your God.

So the deliverable is delivered, exhaustively, and the recitation of it stands immediately before the statement that the receiving organ was not given.

Four things follow.

**The failure is stated as a lack in the receiver, not a lack in the gift.** The verse does not say the signs were insufficient, ambiguous, or withheld. It recites them and then says the organ was not given.

**The three organs are cognitive, not moral.** A heart to know, eyes to see, ears to hear. The Hebrew *lev* is not the seat of emotion in this corpus but of thought, intention, and understanding; the deficiency named is an inability to register rather than an unwillingness to comply. That is a different diagnosis from disobedience and the corpus states it in different vocabulary.

**The subject of the not-giving is God.** *Loʾ natan YHWH lakhem.* This is the verse's difficulty and it will not be managed away here. On the face of it the corpus is saying God did not supply the organ needed to receive what God supplied, and Chapter 39 addresses the problem that raises rather than pretending it does not exist.

**The temporal marker leaves the situation open.** *ʿAd ha-yom ha-zeh*, unto this day. Not forever, not permanently, not by decree. The phrase records a state of affairs as of the moment of speaking. Whatever else is true, the verse does not close the case.

One further feature deserves attention because it is easily missed and bears on Book IV's whole argument. The three organs recur as a set in Isaiah 6:10 and the order is preserved: heart, eyes, ears. Isaiah 6:10 reverses the direction, hardening rather than not-giving, and adds a purpose clause. Isaiah 42:20 takes eyes and ears and drops the heart. Jeremiah 5:21 has *ʿeynayim lahem we-loʾ yirʾu ʾoznayim lahem we-loʾ yishmaʿu*, eyes they have and see not, ears they have and hear not, addressed to a *ʿam sakhal we-ʾeyn lev*, a foolish people without heart. Ezekiel 12:2 has almost identical language: *ʿeynayim lahem lirʾot we-loʾ raʾu ʾoznayim lahem lishmoaʿ we-loʾ shameʿu*. Psalm 115:5-6 applies the same inventory to idols. Psalm 135:16-17 repeats it.

Six sites, four books, one inventory. The corpus is not improvising a metaphor each time; it is using a fixed diagnostic and applying it to Israel, to the wilderness generation, to the exiles, and to the idols of the nations. Chapter 38 counts them.

The relation between Deuteronomy 29:3 and Jeremiah 5:21 is the sharpest instance. Deuteronomy says the organ was not given. Jeremiah says they have the organs and do not use them. Those are two different claims and the corpus makes both about the same population in the same vocabulary. It does not reconcile them, and Chapter 39 is about the fact that it does not.

## 33. Isaiah 6 · Commissioned Into Non-Reception


Isaiah 6 is the hardest text in this book and it is hard in a way that cannot be softened without losing what makes it evidence.

The chapter is a throne vision. The prophet sees the LORD high and lifted up, the seraphim call to one another, the doorposts shake, the house fills with smoke. Isaiah says *ʾoy li ki nidmeyti*, woe is me for I am undone, and names the reason: *ki ʾish ṭemeʾ sefatayim ʾanokhi u-ve-tokh ʿam ṭemeʾ sefatayim ʾanokhi yoshev*, a man of unclean lips dwelling among a people of unclean lips. A seraph takes a coal from the altar with tongs and touches his mouth. The guilt is removed. Then the commission.

*Wa-yoʾmer lekh we-ʾamarta la-ʿam ha-zeh, shimʿu shamoaʿ we-ʾal tavinu, u-reʾu raʾo we-ʾal tedaʿu.*

Go and say to this people: hear indeed, but do not understand; see indeed, but do not know.

*Hashmen lev ha-ʿam ha-zeh we-ʾoznaw hakhbed we-ʿeynaw hashaʿ, pen yirʾeh ve-ʿeynaw u-ve-ʾoznaw yishmaʿ u-levavo yavin wa-shav we-rafaʾ lo.*

Make the heart of this people fat, and their ears heavy, and shut their eyes, lest they see with their eyes and hear with their ears and understand with their heart and turn and be healed.

Four features.

**The three organs are the Deuteronomy 29:3 inventory, in the same order.** Heart, ears, eyes at 6:10a, then eyes, ears, heart at 6:10b in the reverse order for the purpose clause. The chiasm is deliberate and the inventory is fixed.

**The commission is a commission to deliver into non-reception and it says so at the moment of commissioning.** This is not a report after the fact that the message failed. It is the terms of the assignment, stated before the assignment begins. Whatever else is going on, the corpus is not claiming its prophet was surprised.

**The purpose clause is the difficulty.** *Pen ... wa-shav we-rafaʾ lo*, lest they turn and be healed. On the surface the hardening is instrumental to preventing a healing, which is a proposition that has generated two and a half millennia of commentary and will not be settled here.

**Verse 11 asks how long and receives a duration rather than a resolution.** *Wa-ʾomar ʿad matay ʾAdonay*, and I said, how long, Lord. The answer is: until cities lie waste without inhabitant, houses without people, and the land is utterly desolate. The prophet asks a question about termination and gets an answer about extent.

What this book takes from Isaiah 6 is narrow and it is worth separating from what this book does not take.

**What is taken.** The deficit is located in the three organs, in the same inventory as Deuteronomy 29:3, at the moment of a prophetic commissioning, in the corpus's own words. That is a datum about where the corpus puts the problem.

**What is not taken.** No position on the theology of the hardening. Whether the imperatives are prescriptive or descriptive-of-outcome, whether the prophet's preaching is the instrument of a judgment already determined, whether the purpose clause states an intention or an effect: these are the questions of the hardening literature, they are live, and this book has nothing to add to them. Chapter 39 says so at length and explains why the argument does not need them settled.

One feature of the chapter is directly load-bearing and is usually noticed late. **Isaiah 6 closes on the terminus imagery of Book IX.** Verse 13: *we-ʿod bah ʿasiriyah we-shavah we-haytah le-vaʿer, ka-ʾelah we-kha-ʾallon ʾasher be-shalleket maṣṣevet bam, zeraʿ qodesh maṣṣavtah.*

And yet a tenth shall be in it, and it shall return and be consumed; as a terebinth and as an oak whose stump remains when they are felled, the holy seed is its stump.

The commission into non-reception ends in a felled tree with a surviving stump, seven chapters before Isaiah 11:1 grows a shoot from a stump. The corpus places the deficit and the stump-image in the same chapter, and Chapter 89 works the relation.

## 34. Isaiah 42:19 · The Corpus Puts Its Own Messenger in the Category


*Mi ʿiwwer ki ʾim ʿavdi, we-ḥeresh ke-malʾakhi ʾeshlaḥ, mi ʿiwwer ki-meshullam we-ʿiwwer ke-ʿeved YHWH. Raʾot rabbot we-loʾ tishmor, paqoaḥ ʾoznayim we-loʾ yishmaʿ.*

Who is blind but my servant, and deaf as my messenger whom I send? Who is blind as he that is at peace with me, and blind as the servant of the LORD? Seeing many things, but you observe not; opening the ears, but he hears not.

This verse is the reason the deficit motif in this book cannot be read as a polemic.

**The corpus applies the diagnostic to its own messenger.** Not to the nations, not to idolaters, not to an opposing party. *ʿAvdi*, my servant. *Malʾakhi ʾeshlaḥ*, my messenger whom I send. *ʿEved YHWH*, the servant of the LORD. Four designations, all of them honorific, all of them the corpus's own vocabulary for the figure it most closely identifies with.

**The organs are two of the three.** Blind and deaf: eyes and ears. The heart is absent from this instance and present in most of the others.

**The final clause states the structure of the deficit exactly.** *Paqoaḥ ʾoznayim we-loʾ yishmaʿ*, opening the ears and he does not hear. The infinitive absolute *paqoaḥ* describes a state of openness. The organ is not sealed. It is open and not receiving. That is the sharpest formulation of the whole motif anywhere in the corpus, and it forecloses the reading in which the deficit is a physical obstruction.

The consequence for the argument is a fence rather than a support, and it is the more valuable for that.

**The polemical use of the motif is foreclosed by the corpus itself.** A reader could take the heart-eyes-ears diagnostic as a weapon: they do not see, we do. Isaiah 42:19 makes that unavailable, because the corpus assigns the condition to its own servant in the strongest possible terms and in a chapter that is otherwise about that servant's commission. Whoever the servant is, and the identification is contested at Isaiah 42 as it is throughout the servant material, the corpus is not exempting him.

That fence applies to this book too, and Chapter 108 says so.

A further observation on the immediate context. Isaiah 42:18 opens *ha-ḥershim shemaʿu we-ha-ʿiwrim habbiṭu lirʾot*, you deaf, hear; you blind, look and see. The imperative is addressed to the very organs said to be deficient. That is not a contradiction; it is the same shape as Jeremiah 6:16, where the instruction is to walk on paths that already exist and the answer recorded is a refusal. The corpus issues the command to the deficient party and records the outcome, and it does this repeatedly.

Isaiah 42:20's *we-loʾ tishmor* switches to second person in the middle of a third-person sequence, which is a well-known textual awkwardness. Some manuscripts and the versions regularize it. This book takes no position and the argument is unaffected either way, since the deficiency predicate holds of the servant in both readings.

## 35. Jeremiah 6:16 · And They Said, We Will Not Walk


Chapter 12 introduced this verse for its vocabulary. This chapter takes it for its argument, because it is the single passage that answers the strongest objection to Book IV.

The objection is this. Two of the four principal deficit texts describe an organ *not given* and one has the ears *made* heavy. So the deficit looks imposed rather than incurred, and if it is imposed then the failure is not at the receiver in any morally interesting sense, and Book IV's whole claim collapses into a claim about divine agency.

Jeremiah 6:16 is the answer, and it is an answer because nothing in it is withheld and nothing in it is made heavy.

*Koh ʾamar YHWH, ʿimdu ʿal derakhim u-reʾu, we-shaʾalu li-netivot ʿolam ʾey zeh derekh ha-ṭov u-lekhu vah, u-miṣʾu margoaʿ le-nafshotekhem. Wa-yomeru loʾ nelekh.*

Take it clause by clause.

**Stand at the roads and look.** *ʿImdu ʿal derakhim u-reʾu.* An imperative of position and an imperative of sight. The organ Isaiah 6:10 shut is here commanded to operate, with no indication that it cannot.

**Ask for the ancient paths.** *We-shaʾalu li-netivot ʿolam.* The paths already exist. *ʿOlam* here is durative rather than eternal: the long-standing ways. Nothing is being built, revealed, disclosed, or awaited. The instruction is to find out where something already standing is.

**Where the good way is, and walk in it.** *ʾEy zeh derekh ha-ṭov u-lekhu vah.* An interrogative and an imperative. The good way is one of the ancient paths and the task is to identify it and use it.

**And find repose for your souls.** *U-miṣʾu margoaʿ le-nafshotekhem.* The terminus, in the fourth root, as the outcome of the walking. Note the verb: *miṣʾu*, find. Not receive, not be given. Find. The terminus is at the end of the paths and the finding is the walker's.

**And they said, we will not walk.** *Wa-yomeru loʾ nelekh.*

Five features of that final clause carry the whole weight.

It is speech, quoted. The corpus does not describe an inability and does not narrate a failure. It quotes a sentence.

The verb is the same verb as the imperative. *Lekhu* in the command, *nelekh* in the refusal. The refusal is precise: it declines exactly what was asked.

The subject is first person plural. They speak for themselves.

There is no divine agent anywhere in the refusal. Nothing hardens, nothing is withheld, nothing is made heavy, nothing is shut.

And the whole exchange is compressed into a single verse, which puts the offer and the refusal in a relation a reader cannot separate.

Deuteronomy 30:19 has the same shape from the other side. *Ha-ʿidoti vakhem ha-yom ʾet ha-shamayim we-ʾet ha-ʾareṣ, ha-ḥayyim we-ha-mawet natati le-faneykha, ha-berakhah we-ha-qelalah, u-vaḥarta ba-ḥayyim.* I have set before you life and death, blessing and curse; therefore choose life. The imperative *u-vaḥarta* is a command to choose, addressed to a party the corpus assumes can.

**The corpus carries both an unfurnished organ and a declined offer, and reconciles neither.** That is the honest statement of the position and Chapter 39 defends the decision not to resolve it. What the corpus carries nowhere is a withheld terminus, and that is the claim Book IV is actually making.

## 36. Deuteronomy 8 · The Mechanism Is Prosperity


The corpus supplies a mechanism for the deficit and the mechanism is not what a reader would guess.

*Pen toʾkhal we-savaʿta u-vattim ṭovim tivneh we-yashavta. U-veqarkha we-ṣoʾnkha yirbeyun we-khesef we-zahav yirbeh lakh we-khol ʾasher lekha yirbeh. We-ram levavekha we-shakhaḥta ʾet YHWH ʾeloheykha ha-moṣiʾakha me-ʾereṣ Miṣrayim mi-beyt ʿavadim.*

Lest you eat and be satisfied, and build good houses and dwell in them, and your herds and flocks multiply, and your silver and gold multiply, and all you have multiplies. And your heart is lifted up and you forget the LORD your God who brought you out of the land of Egypt, from the house of slavery.

**The danger condition is prosperity, not hardship.** Every clause in the protasis is a benefit. Eating, satisfaction, good houses, dwelling, multiplying herds, multiplying silver, multiplying everything. The corpus lists eight good outcomes and then names the risk they carry.

**The failure is a lifted heart and a forgetting.** *Ram levavekha we-shakhaḥta.* The heart again, and the verb of the deficit here is memory rather than perception. The chapter has already supplied the positive form at 8:2: *we-zakharta ʾet kol ha-derekh*, and you shall remember all the way. And at 8:18: *we-zakharta ʾet YHWH ʾeloheykha ki huʾ ha-noten lekha koaḥ la-ʿasot ḥayil*, you shall remember that it is he who gives you power to get wealth.

**The mechanism is structural and it explains the shape of the whole problem.** A state entered and unnoticed is, to the one standing in it, indistinguishable from a state never given. That sentence is the hinge of Book IV. If the terminus is a condition rather than an object, then it can be occupied without being registered, and the failure to register it produces exactly the phenomenology of not having received it. The people in Deuteronomy 8 are not being warned that prosperity will be taken away. They are being warned that they will stop seeing it as given.

Exodus 20:8 guards the same position with the one imperative of memory in the Decalogue. *Zakhor ʾet yom ha-shabbat le-qaddesho.* Remember the sabbath day to keep it holy. Of ten commandments, one is a command to remember, and its object is the seventh position. Deuteronomy's version of the Decalogue substitutes *shamor*, keep, at 5:12, and the difference between the two verbs is one of the classical problems. Nothing here turns on which is prior. What both versions agree on is that the seventh position requires an act of attention that the corpus thought worth commanding.

Three further sites confirm that the corpus treats forgetting as the operative failure rather than as a lapse.

**Deuteronomy 6:10-12.** Cities you did not build, houses full of good things you did not fill, cisterns you did not dig, vineyards and olive trees you did not plant. Then: *hishamer lekha pen tishkaḥ ʾet YHWH*, take heed lest you forget the LORD. The list is a list of unearned goods and the warning attaches to the unearnedness.

**Deuteronomy 32:15.** *Wa-yishman Yeshurun wa-yivʿaṭ, shamanta ʿavita kasita, wa-yiṭṭosh ʾeloah ʿasahu.* Jeshurun grew fat and kicked; you grew fat, thick, gorged; and he forsook the God who made him. The verb *shaman* is the same root as Isaiah 6:10's *hashmen lev*, make the heart fat. The corpus uses one image for the hardening and for the effect of prosperity.

**Hosea 13:6.** *Ke-marʿitam wa-yisbaʿu, saveʿu wa-yarom libbam, ʿal ken shekheḥuni.* According to their pasture they were filled; they were filled and their heart was lifted up; therefore they forgot me. Three verbs in the exact sequence of Deuteronomy 8: satisfied, heart lifted, forgot.

Four books, one mechanism, stated in overlapping vocabulary. This is not a stray warning. It is the corpus's standing account of how a delivered condition goes unregistered.

## 37. Exodus 20:8 · The One Imperative of Memory


The Decalogue contains ten items and one of them is a command to remember. Its object is the seventh position, and that fact deserves a chapter rather than a clause.

*Zakhor ʾet yom ha-shabbat le-qaddesho. Sheshet yamim taʿavod we-ʿasita kol melaʾkhtekha, we-yom ha-shevi'i shabbat la-YHWH ʾeloheykha, loʾ taʿaseh khol melaʾkhah.*

Remember the sabbath day to keep it holy. Six days you shall labour and do all your work, but the seventh day is a sabbath to the LORD your God; you shall do no work.

Four observations, and the fourth is the one that matters for this book.

**The verb is an infinitive absolute functioning as an imperative.** *Zakhor*, remember, standing at the head of the clause. Deuteronomy 5:12 has *shamor*, keep or guard. The two versions differ and the difference is old, discussed within the tradition and unresolved. This book uses the Exodus form because the argument concerns memory, and notes that the Deuteronomy form would carry the same weight for a different reason, since guarding also implies a thing that can be lost by inattention.

**The grounding at 20:11 is Genesis 2.** *Ki sheshet yamim ʿasah YHWH ʾet ha-shamayim we-ʾet ha-ʾareṣ ... wa-yanaḥ ba-yom ha-shevi'i, ʿal ken berakh YHWH ʾet yom ha-shabbat wa-yeqaddeshehu.* The Decalogue cites the creation account explicitly. And as Chapter 21 noted, it cites it with the *nwḥ* root where Genesis used *šbt*. The two roots are being treated as one position by the corpus at the point where the corpus is most careful.

**The commandment is about a cessation and not about an activity.** *Loʾ taʿaseh khol melaʾkhah.* The content of the observance is a not-doing. Whatever is added by later practice, the commandment as stated prescribes the absence of an action and no positive act at all.

**A thing that must be remembered is a thing that can be forgotten while it stands.** This is the connection to Chapter 36 and it is the reason this chapter exists. Nobody commands the remembrance of a thing that is absent; absence enforces its own attention. The imperative of memory presupposes an object that is present and can go unregistered. The corpus places that imperative on the seventh position and on nothing else in the Decalogue.

Two further considerations, both offered at low weight.

The sabbath commandment is the longest of the ten in both versions, by a considerable margin, and it is the only one that supplies a reason grounded in a narrative. That is an emphasis a reader can notice without building on it.

And the extension of the commandment is total: son, daughter, male slave, female slave, cattle, and the resident alien within your gates. Deuteronomy 5:14 adds *le-maʿan yanuaḥ ʿavdekha wa-ʾamatekha kamokha*, so that your male and female slave may rest as you do, using the settling-root. The purpose clause makes the terminus available to a slave on the same terms as to the householder, which is a structural fact about the corpus's own distribution of the condition and one that no figure mediates.

## 38. The Three Organs, Counted Across the Corpus


The heart-eyes-ears inventory is not a metaphor the corpus improvises. It is a fixed diagnostic, and this chapter counts its occurrences so that the claim can be checked rather than felt.

**The full triad, all three organs in one passage.**

Deuteronomy 29:3. Heart to know, eyes to see, ears to hear. Stated as not given.

Isaiah 6:9-10. Heart, ears, eyes in the hardening clause; eyes, ears, heart in the purpose clause. Stated as an instruction to the prophet.

Jeremiah 5:21. *ʿAm sakhal we-ʾeyn lev, ʿeynayim lahem we-loʾ yirʾu, ʾoznayim lahem we-loʾ yishmaʿu.* A foolish people without heart; eyes they have and see not, ears they have and hear not. Stated as a present condition with the organs possessed.

Ezekiel 12:2. *Beyt meri huʾ ʾasher ʿeynayim lahem lirʾot we-loʾ raʾu ʾoznayim lahem lishmoaʿ we-loʾ shameʿu, ki beyt meri hem.* A rebellious house, which have eyes to see and see not, ears to hear and hear not. The heart is implied by *beyt meri* rather than named.

**Two of the three.**

Isaiah 42:19-20. Blind and deaf: eyes and ears. Applied to the servant.

Isaiah 43:8. *Hoṣiʾ ʿam ʿiwwer we-ʿeynayim yesh, we-ḥershim we-ʾoznayim lamo.* Bring out the blind people that have eyes, and the deaf that have ears. The same shape: organs present, function absent.

Isaiah 29:10. *Ki nasakh ʿaleykhem YHWH ruaḥ tardemah wa-yeʿaṣṣem ʾet ʿeyneykhem.* The LORD has poured out a spirit of deep sleep and closed your eyes. With 29:18: *we-shameʿu va-yom ha-huʾ ha-ḥershim divrey sefer u-me-ʾofel u-me-ḥoshekh ʿeyney ʿiwrim tirʾenah*, the deaf shall hear and the eyes of the blind shall see, which is the reversal.

Isaiah 35:5. *ʾAz tippaqaḥnah ʿeyney ʿiwrim we-ʾozney ḥershim tippataḥnah.* Then the eyes of the blind shall be opened and the ears of the deaf unstopped. Both organs, both in the passive.

**The idol application, which is the key to the whole inventory.**

Psalm 115:5-7. *Peh lahem we-loʾ yedabberu, ʿeynayim lahem we-loʾ yirʾu, ʾoznayim lahem we-loʾ yishmaʿu, ʾaf lahem we-loʾ yeriḥun, yedeyhem we-loʾ yemishun, ragleyhem we-loʾ yehallekhu.* Mouths and speak not, eyes and see not, ears and hear not, noses and smell not, hands and handle not, feet and walk not.

Psalm 135:15-17 repeats it in shortened form.

And then the sting, which both psalms deliver identically. Psalm 115:8: *kemohem yihyu ʿoseyhem, kol ʾasher boṭeaḥ bahem.* Those who make them shall be like them, and everyone who trusts in them.

**The count.** Eleven passages across five books: Deuteronomy, Isaiah, Jeremiah, Ezekiel, Psalms. Isaiah alone carries five. The inventory is stable, the vocabulary is stable, and the syntax is stable: an organ named, its function named, and the function negated.

Two structural results follow from the count.

**The idol texts supply the corpus's own explanation of the image.** An idol has the organs and no function. A people that trusts an idol becomes like it. So the deficit is not a random affliction; the corpus states a mechanism by which the condition is acquired, and it names the mechanism as resemblance to what one trusts. That is a diagnosis with a cause, offered by the corpus, in the same vocabulary as the deficit texts.

**The reversal is stated in the passive.** Isaiah 35:5's *tippaqaḥnah* and *tippataḥnah* are both nifal. Isaiah 29:18's *tirʾenah* has the eyes as subject. Nobody in these passages opens anybody's eyes; the eyes are opened. Chapter 62's finding about conferral grammar is visible here in a different domain, and the convergence is worth noting even though this book does not build on it.

## 39. The Hardening Problem, and Why This Book Does Not Solve It


The corpus says the organ was not given, at Deuteronomy 29:3. It says the heart was to be made fat and the eyes shut, at Isaiah 6:10. It says a spirit of deep sleep was poured out, at Isaiah 29:10. And it says the people have the organs and do not use them, at Jeremiah 5:21 and Ezekiel 12:2, and it quotes them refusing, at Jeremiah 6:16.

Those are two accounts and the corpus does not reconcile them. This chapter states why the book does not attempt to.

**The reconciliations available.** There are several and each is respectable.

The hardening can be read as judicial: a response to a prior refusal, so that the sequence is refusal first and hardening second, and the two accounts are stages rather than rivals. Exodus provides the pattern that supports this, since Pharaoh hardens his own heart before God is said to harden it, and the corpus alternates the subject deliberately across the plague cycle.

The hardening can be read as descriptive of outcome expressed in the idiom of intention, which is a recognized feature of the corpus's way of speaking about causation and appears in the prophetic commissioning formulas generally.

The hardening can be read as rhetorical: an assignment stated in its harshest terms to a prophet who will preach for decades to no visible effect, so that the commissioning inoculates him against the interpretation that he failed.

The hardening can be read straightforwardly, as the corpus's assertion that God did what the text says, with the theological consequences accepted rather than managed.

**Why this book takes none of them.** Because the argument does not need one and taking one would cost more than it bought.

The claim Book IV makes is a claim about location: the corpus places the deficit at the receiver rather than in the terminus. That claim holds under every one of the four readings above. On the judicial reading the deficit is at the receiver and incurred. On the descriptive reading it is at the receiver and reported. On the rhetorical reading it is at the receiver and stated harshly. On the straightforward reading it is at the receiver and imposed. In no case is it in the gift.

That is the whole point and it is worth stating in the form of a test. Take any of the four readings. Now ask: does the corpus, on that reading, say the terminus was withheld, delayed, reserved, or given to another? The answer is no on all four, because there is no such clause anywhere in the corpus to be read in any way.

**What the book does claim about the tension.** One thing, and it is a claim about the corpus's habit rather than about the theology. The corpus carries both an unfurnished organ and a declined offer, and reconciles neither. That is a feature of a corpus that preserves rather than harmonizes, and Book X finds nine further instances of the same behaviour. A tradition operating by deletion does not keep both.

**A concession.** A reader who holds that the hardening texts, properly read, make the whole deficit divine in origin will find Book IV's language occasionally more moralized than that reading permits. Where this book says the failure was at the receiver, such a reader should hear the failure was located at the receiver, which is the claim actually being made and is neutral on origin. Where the language slips, the slip is mine and the corrected form is the one just given.

## 40. Deuteronomy 30:19 · The Same Shape From the Other Side


*Ha-ʿidoti vakhem ha-yom ʾet ha-shamayim we-ʾet ha-ʾareṣ, ha-ḥayyim we-ha-mawet natati le-faneykha, ha-berakhah we-ha-qelalah, u-vaḥarta ba-ḥayyim le-maʿan tiḥyeh ʾattah we-zarʿekha.*

I call heaven and earth to witness against you this day: I have set before you life and death, blessing and curse; therefore choose life, that you may live, you and your seed.

Jeremiah 6:16 records an offer and a refusal. Deuteronomy 30:19 records an offer and a command to accept, and the command presupposes exactly what Jeremiah's refusal exercised.

**The verb of setting is in the perfect.** *Natati le-faneykha*, I have set before you. Done. The four items are placed and the placing is complete.

**The verb of choosing is a command addressed to the hearer.** *U-vaḥarta ba-ḥayyim.* Second person singular imperative in form, waw-consecutive perfect in function, and either way the subject is the person addressed. Nothing chooses on their behalf and nothing is said to prevent the choosing.

**The witnesses are heaven and earth.** The formula belongs to the covenant-lawsuit and it appears at Deuteronomy 4:26, 30:19, 31:28, and 32:1, and at Isaiah 1:2. The invocation of witnesses presupposes a party capable of breach, which presupposes a party capable of compliance.

**The frame is *ha-yom*.** Chapter 3 established that Deuteronomy 30 marks two temporal frames and that the near one is marked five times, at verses 11, 15, 16, 18, and 19. This verse carries the fifth. The choice is available today.

Set the two verses side by side and the shape is one shape from two sides.

Deuteronomy 30:19: the objects are placed, the command is to choose, and the corpus records no answer.
Jeremiah 6:16: the paths are standing, the command is to walk, and the corpus records the answer, and it is no.

Between them they cover the whole structure that Book IV is describing. Something available, an instruction to take it, and a party whose taking or not-taking is the operative variable. In neither passage does anything stand between the hearer and the object. In neither is anything withheld. In neither is an intermediary named.

One further verse belongs beside them and it is the strongest single statement of availability in the corpus. Deuteronomy 30:11-14, which Chapter 3 used to establish that the criterion is native. *Loʾ nifleʾt hiʾ mimmekha we-loʾ reḥoqah hiʾ. Loʾ va-shamayim hiʾ ... we-loʾ me-ʿever la-yam hiʾ ... ki qarov ʾeleykha ha-davar meʾod be-fikha u-vilvavkha la-ʿasoto.* It is not too hard for you, nor far off. It is not in heaven. It is not beyond the sea. It is very near to you, in your mouth and in your heart, to do it.

Three modes of intermediation named and denied, and then the positive: in your mouth and in your heart. The organ named as deficient at Deuteronomy 29:3 is named at 30:14 as the location of the near word, six chapters later in the same book.

The corpus places those two statements in one scroll and does not reconcile them. Chapter 39 has already said why this book does not either.

## 41. Nowhere a Withheld Terminus


Book IV closes with a negative claim, and a negative claim about a corpus is a claim a reader can break with one verse. It is stated here in a form precise enough to be broken.

**The claim.** In the Hebrew Bible there is no clause that attributes the non-entry into the terminus to an absent, withheld, delayed, reserved, or postponed terminus. Every clause that supplies a reason supplies one located in the heart, the eyes, the ears, the hearing, the memory, or a refusal spoken by the hearers.

**The evidence, gathered.**

Deuteronomy 29:3. The organ not given. Location: heart, eyes, ears.

Psalm 95:8-11. Do not harden your hearts; a people erring in heart; they did not know my ways; they shall not enter my rest. Location: heart, knowing.

Isaiah 6:9-10. Hear and do not understand, see and do not know; heart fat, ears heavy, eyes shut. Location: heart, ears, eyes.

Isaiah 42:19-20. Blind servant, deaf messenger, ears open and not hearing. Location: eyes, ears.

Jeremiah 6:16. The paths stand, the instruction is to walk, and they said we will not walk. Location: a spoken refusal.

Deuteronomy 8:12-14 with Deuteronomy 32:15 and Hosea 13:6. Satisfied, heart lifted, forgot. Location: heart, memory.

Judges, four times. The land was quiet forty years, and the children of Israel again did evil in the sight of the LORD. Location: the people's return to what they had been doing.

Jeremiah 5:21, Ezekiel 12:2, Isaiah 43:8. Organs possessed, functions absent. Location: the organs.

**What is not found.** No clause saying the rest was not yet given. No clause saying it was reserved for a later time. No clause saying it awaited a figure. No clause saying it was given to another party. No clause saying it was insufficient. No clause saying the giver delayed. The corpus's giving-verbs are in the perfect at Joshua 21:44, at 1 Kings 8:56, at 1 Chronicles 22:18, at 1 Chronicles 23:25, at 2 Chronicles 14:6, at 2 Chronicles 15:15, and at 2 Chronicles 20:30, and there is no corresponding set of clauses in which the giving is deferred.

**How to break it.** Produce one verse in which the failure of the terminus is attributed to the terminus. A verse in which the rest is said to be not yet given rather than not yet entered. A verse in which the object rather than the receiver carries the deficiency. One verse is enough and the claim falls.

**Two near-misses, named so that they are not mistaken for finds.**

Deuteronomy 12:9's *loʾ vaʾtem ʿad ʿattah*, you have not yet come. This is a not-yet and it is a not-yet of arrival, with the people as subject of the coming and God as subject of the giving in the same verse. It states that the arrival has not occurred, not that the object is absent. Chapter 22 works it.

Psalm 95:11's *ʾim yevoʾun ʾel menuḥati*, if they shall enter my rest. The oath excludes a generation from entry. It does not withdraw the rest, and the psalm's own *ha-yom* at verse 7 reopens the condition to the hearers. Chapter 26 works it.

Both are about entry. Neither is about the object. And that distinction, between the entering and the given, is the distinction Book III established from the grammar and Book IV has now traced through eleven passages in five books. What Book V takes up is what the corpus did instead.

:::book V | THE CONCESSION


## 42. Judges 8:23 · The Refusal


The corpus's opening position on monarchy is a refusal, it is spoken by a man who had just won, and it is spoken in a form that makes the refusal a positive assertion about somebody else.

*Wa-yoʾmeru ʾish Yisraʾel ʾel Gidʿon, meshol banu gam ʾattah gam binkha gam ben binkha, ki hoshaʿtanu mi-yad Midyan. Wa-yoʾmer ʾalehem Gidʿon, loʾ ʾemshol ʾani bakhem we-loʾ yimshol beni bakhem, YHWH yimshol bakhem.*

And the men of Israel said to Gideon: rule over us, you and your son and your son's son also, for you have saved us from the hand of Midian. And Gideon said to them: I will not rule over you, and my son will not rule over you; the LORD will rule over you.

**The offer is dynastic and the corpus makes that explicit.** *Gam ʾattah gam binkha gam ben binkha*, you and your son and your son's son. Three generations named. This is not an offer of leadership; it is an offer of a house, and the offer is made on the basis of a deliverance that has just occurred.

**The refusal is threefold and matches the offer clause by clause.** I will not rule. My son will not rule. Two of the three generations are declined explicitly and the third by implication. Gideon answers the structure of the offer and not merely its substance.

**The reason given is not modesty.** *YHWH yimshol bakhem.* The LORD will rule over you. The refusal is grounded in a positive claim about who does rule, in the imperfect, which in this construction carries present and future force alike. Gideon does not say the office is unnecessary or that he is unworthy. He says it is occupied.

**The verb is *mšl*, not *mlk*.** To rule rather than to reign as king. The distinction matters at the next chapter, because Abimelech's story uses *mlk* throughout and the corpus is not careless with the pair. Gideon declines to rule; his son will claim to be king.

The narrative immediately complicates the refusal and this book will not pretend otherwise.

Verses 24 to 27 have Gideon asking for the golden earrings of the spoil, receiving seventeen hundred shekels of gold, and making an ephod which he sets up in his city, *wa-yiznu khol Yisraʾel ʾaḥaraw sham wa-yehi le-Gidʿon u-le-veyto le-moqesh*, and all Israel went whoring after it there, and it became a snare to Gideon and to his house. Verse 30 says he had seventy sons, *ki nashim rabbot hayu lo*, for he had many wives. Verse 31 names a concubine in Shechem whose son is called Abimelech, which means my father is king.

So the man who refuses the crown accumulates gold, a cult object, a harem, seventy sons, and a son named my-father-is-king. The corpus records all of it in nine verses and offers no comment.

Two readings are available. On one, Gideon's refusal is pious words and the narrative exposes it. On the other, the refusal is genuine and the narrative shows how quickly the substance of kingship accrues to a man who has declined its name. This book does not adjudicate between them, and the argument does not require it. What is load-bearing is the sentence at 8:23, because the corpus puts it in the mouth of the man best placed to accept, at the moment he is offered the throne, and preserves it.

Judges 9 then supplies the corpus's own commentary in the form of a fable, and Chapter 51 takes it up.

Two closing observations.

**The offer is grounded in a deliverance and the deliverance produced the terminus.** Judges 8:28 closes the Gideon cycle with *wa-tishqoṭ ha-ʾareṣ ʾarbaʿim shanah bi-yemey Gidʿon*, and the land was quiet forty years in the days of Gideon. The people ask for a dynasty five verses before the corpus records that the condition they wanted a dynasty to secure had already been delivered under a man who refused one.

**The refusal is never retracted.** The corpus records the demand again at 1 Samuel 8, receives it differently, and never returns to Judges 8:23 to qualify it. The sentence stands unamended in the received text and no later passage says Gideon was wrong.

## 43. Deuteronomy 17:14 · A Statute Conditioned on Being Asked For


Before the demand is made, the law anticipates it, and the form of the anticipation is the datum.

*Ki tavoʾ ʾel ha-ʾareṣ ʾasher YHWH ʾeloheykha noten lakh wi-rishtah we-yashavtah bah, we-ʾamarta ʾasimah ʿalay melekh ke-khol ha-goyim ʾasher sevivotay. Som tasim ʿaleykha melekh ʾasher yivḥar YHWH ʾeloheykha bo.*

When you come into the land which the LORD your God is giving you, and possess it and dwell in it, and you say: I will set a king over me like all the nations that are round about me. You shall surely set a king over you whom the LORD your God chooses.

**The protasis contains a speech act.** *We-ʾamarta*, and you shall say. The statute is not conditioned on a circumstance, a need, or a threat. It is conditioned on the people saying a sentence. This is unusual in the Deuteronomic legislation, which typically conditions on situations rather than on utterances, and the exception is worth noticing.

**The sentence they will say is quoted in advance.** *ʾAsimah ʿalay melekh ke-khol ha-goyim ʾasher sevivotay.* I will set a king over me like all the nations round about me. The law records the demand verbatim before the demand is made, and 1 Samuel 8:5 will reproduce the operative phrase, *ke-khol ha-goyim*, almost word for word.

**The apodosis regulates rather than commands.** *Som tasim ʿaleykha melekh ʾasher yivḥar YHWH*, you shall surely set a king whom the LORD chooses. The infinitive absolute construction is emphatic and is often read as a positive command. Read against the protasis it is more naturally the regulation of a thing conditioned on being requested: if you say this, then the king you set shall be the one God chooses. A permission with constraints attached is not the same object as an instruction.

**The constraints are then itemized and they are all restrictions.** Verses 15 through 17: from among your brothers and not a foreigner; he shall not multiply horses for himself nor cause the people to return to Egypt to multiply horses; he shall not multiply wives lest his heart turn aside; he shall not greatly multiply silver and gold. Four prohibitions, three of them beginning *loʾ yarbeh*, he shall not multiply.

**And then the positive requirement, which is a copying.** Verses 18 through 20: *we-khatav lo ʾet mishneh ha-torah ha-zoʾt ʿal sefer mi-lifney ha-kohanim ha-Lewiyyim*, he shall write for himself a copy of this law in a book, from before the levitical priests. He shall read in it all the days of his life. Purpose clause: *le-vilti rum levavo me-ʾeḥaw*, that his heart be not lifted up above his brothers.

Chapter 58 works the copying requirement in full. Two things are established here.

**A statute that regulates an anticipated demand is not the same as a statute that establishes an office.** The corpus has forms for establishing offices and uses them: the priesthood at Exodus 28-29, the judges at Deuteronomy 16:18, the cities of refuge at Deuteronomy 19. None of those is conditioned on the people saying they want one. The monarchy alone carries that condition.

**The purpose clause names the same failure Deuteronomy 8 named.** *Rum levavo*, his heart lifted up, is the identical phrase as Deuteronomy 8:14's *ram levavekha*. The law of the king guards against exactly the mechanism the law of prosperity warned about, in the same words, and applies it to the one man most exposed to it. Chapter 58 shows the corpus executing the guard twice on named kings.

## 44. 1 Samuel 8:5 · Like All the Nations


The demand arrives and the corpus quotes it.

*Wa-yoʾmeru ʾelaw, hinneh ʾattah zaqanta u-vaneykha loʾ halkhu bi-derakheykha, ʿattah simah lanu melekh le-shofṭenu ke-khol ha-goyim.*

And they said to him: behold, you are old and your sons do not walk in your ways; now set us a king to judge us like all the nations.

**The stated grounds are two and both are real.** Samuel is old. His sons are corrupt, and the corpus has just said so at 8:3: *wa-yiṭṭu ʾaḥarey ha-baṣaʿ wa-yiqḥu shoḥad wa-yaṭṭu mishpaṭ*, they turned aside after gain, took bribes, and perverted judgment. The demand is not made out of nothing. It responds to a succession problem and to a documented failure of the existing arrangement.

**The office requested is judging.** *Le-shofṭenu*, to judge us. That is the function the judges of the previous book performed and that Samuel is performing and that his sons are performing badly. So the request is not for a new function.

**The requested form is foreign and the corpus quotes the phrase.** *Ke-khol ha-goyim*, like all the nations. Deuteronomy 17:14 predicted this phrase and 1 Samuel 8:5 delivers it. The people say it again at 8:20 in an expanded form: *we-hayinu gam ʾanaḥnu ke-khol ha-goyim u-shefaṭanu malkenu we-yaṣaʾ le-faneynu we-nilḥam ʾet milḥamoteynu*, that we also may be like all the nations, and our king may judge us and go out before us and fight our battles.

**Judges already existed.** This is the observation that fixes the character of the demand. Israel had judging. It had had judging for the whole span of the previous book, delivered by ordinary agents, with the terminus attached four times. The request replaces an existing function with a different form of the same function. The demand is therefore about form and not about function, and the form named is the neighbours'.

Two clarifications, because this reading can be pushed too far.

**The demand is not unreasonable and the corpus does not say it is.** A hereditary judiciary that has gone corrupt in one generation, with no mechanism for replacing it, is a real institutional failure. The people are asking for a solution to a problem the corpus has just documented. Nothing in 1 Samuel 8 suggests they were wrong about the problem.

**The added element at 8:20 is military and it is new.** Going out before us and fighting our battles is not the judges' function as Judges describes it, though several judges fought. The expanded demand at 8:20 asks for a standing military leader with a hereditary office, which is a different institution from an intermittently raised deliverer.

Samuel's reaction is recorded and is worth having. 8:6: *wa-yeraʿ ha-davar be-ʿeyney Shemuʾel ka-ʾasher ʾameru tenah lanu melekh le-shofṭenu, wa-yitpallel Shemuʾel ʾel YHWH.* The thing was evil in the eyes of Samuel when they said give us a king to judge us, and Samuel prayed to the LORD.

The corpus records the prophet's displeasure and then, in the next verse, has God tell him the displeasure is misdirected. That is the subject of the next chapter and it is the most quoted sentence in the whole transaction.

## 45. 1 Samuel 8:7 · Rejected, Not Ended


*Wa-yoʾmer YHWH ʾel Shemuʾel, shemaʿ be-qol ha-ʿam le-khol ʾasher yoʾmeru ʾeleykha, ki loʾ ʾotekha maʾasu ki ʾoti maʾasu mi-melokh ʿaleyhem.*

And the LORD said to Samuel: listen to the voice of the people in all that they say to you, for they have not rejected you but they have rejected me from reigning over them.

Every word of the second clause repays attention because the sentence is precise in a way its usual paraphrase is not.

**The verb is *mʾs*, to reject or refuse.** It is a verb of the receiver. One rejects an offer, a person, a proposal. It is not a verb of removal or of cessation.

**The object is the first person.** *ʾOti maʾasu*, me they have rejected. Not my rule as an institution, not the arrangement, not the covenant. The pronoun.

**The prepositional phrase specifies the respect.** *Mi-melokh ʿaleyhem*, from reigning over them. The rejection is of the reigning as it bears on them.

**What the clause does not say.** It does not say the reign ended. It does not say the reign was suspended, withdrawn, transferred, or replaced. It does not say God ceased to rule. It says they rejected him from reigning over them, which leaves the sovereignty untouched and changes only its acceptance.

That distinction is the whole of Chapter 45 and it is not a subtlety invented for the occasion. The corpus states the continuing sovereignty repeatedly and in the same period. 1 Samuel 12:12 has Samuel say *wa-YHWH ʾeloheykhem malkekhem*, and the LORD your God is your king, spoken after Saul has been made king. Psalm 93:1, Psalm 97:1, and Psalm 99:1 all open *YHWH malakh*, the LORD reigns, in a group of psalms whose whole subject is that reign. Isaiah 6:5 has the prophet say *ʾet ha-melekh YHWH ṣevaʾot raʾu ʿeynay*, my eyes have seen the King, the LORD of hosts, in a vision dated to the year king Uzziah died.

So the corpus asserts the reign continuing, during the monarchy, in three of its major divisions.

**The consequence.** What changed at 1 Samuel 8 was not the sovereignty but its acceptance, and therefore its visibility. That is a claim about the transaction, and it is the corpus's own claim rather than an inference from it. The people asked for a *visible* sovereign of the neighbours' kind, and the corpus says the request was a rejection of the one they had, whose reign the corpus goes on asserting.

Verse 8 supplies the precedent: *ke-khol ha-maʿasim ʾasher ʿasu mi-yom haʿaloti ʾotam mi-Miṣrayim we-ʿad ha-yom ha-zeh, wa-yaʿazvuni wa-yaʿavdu ʾelohim ʾaḥerim, ken hemah ʿosim gam lakh.* According to all the works they have done from the day I brought them up from Egypt until this day, forsaking me and serving other gods, so they do also to you.

The corpus categorizes the demand with the golden calf and its successors. That is a strong categorization and it is the corpus's, not this book's.

And then verse 9, which is the hinge of the whole passage. *We-ʿattah shemaʿ be-qolam, ʾakh ki haʿed taʿid bahem we-higgadta lahem mishpaṭ ha-melekh ʾasher yimlokh ʿaleyhem.* Now listen to their voice, only you shall solemnly warn them and tell them the manner of the king who will reign over them.

Grant, with a warning. The warning is the subject of the next chapter and it is itemized.

## 46. 1 Samuel 8:11-18 · The Itemized Bill


The corpus prints the cost of the monarchy in advance, item by item, in the voice of the prophet at the moment of the grant. There is nothing else like it in the ancient Near Eastern royal material and its preservation is the most striking editorial fact in the books of Samuel.

*Wa-yoʾmer, zeh yihyeh mishpaṭ ha-melekh ʾasher yimlokh ʿaleykhem.* This will be the manner of the king who will reign over you.

**Your sons.** He will take them for his chariots and his horsemen, and they will run before his chariots. He will appoint them commanders of thousands and of fifties, and to plough his ground and reap his harvest, and to make his weapons and the equipment of his chariots.

**Your daughters.** *We-ʾet benoteykhem yiqqaḥ le-raqqaḥot u-le-ṭabbaḥot u-le-ʾofot.* He will take for perfumers, cooks, and bakers.

**Your fields, vineyards, and olive groves.** *We-ʾet sedoteykhem we-ʾet karmeykhem we-zeyteykhem ha-ṭovim yiqqaḥ we-natan la-ʿavadaw.* The best of them, taken and given to his servants.

**A tenth of your seed and of your vineyards.** Given to his officers and servants.

**Your male and female servants, your best young men, and your donkeys.** *We-ʿasah li-melaʾkhto.* Put to his work.

**A tenth of your flocks.**

**And the summary.** *We-ʾattem tihyu lo la-ʿavadim.* And you shall be his servants.

The verb *lqḥ*, to take, appears six times in eight verses. It is the structural spine of the speech. Nothing in the list is given to the people; every item is a transfer from them.

Two features convert this from a warning into something with a different force.

**The tenth.** Two of the items are a tenth, on seed and vineyards at verse 15 and on flocks at verse 17. That is the tithe rate, and the tithe in this corpus belongs to the sanctuary and to the Levite. The king's claim is stated at the rate of a sacral due, which is a way of saying what kind of claim it is.

**The final clause, verse 18, which converts warning into contract.** *U-zeʿaqtem ba-yom ha-huʾ mi-lifney malkekhem ʾasher beḥartem lakhem, we-loʾ yaʿaneh YHWH ʾetkhem ba-yom ha-huʾ.*

And you will cry out in that day because of your king whom you have chosen for yourselves, and the LORD will not answer you in that day.

Chapter 47 is about that clause alone.

One further note on the whole speech. Samuel is instructed at 8:9 to *haʿed taʿid*, solemnly warn, using the same verb as Deuteronomy 30:19's *ha-ʿidoti*, I call to witness. The legal register is deliberate. The people are being told the terms before they accept, in a form the corpus uses for covenant witness, and 1 Samuel 12:17-19 will have them acknowledge afterwards that they had been told.

## 47. 1 Samuel 8:18 · The Unanswered-Outcry Clause


*U-zeʿaqtem ba-yom ha-huʾ mi-lifney malkekhem ʾasher beḥartem lakhem, we-loʾ yaʿaneh YHWH ʾetkhem ba-yom ha-huʾ.*

And you will cry out in that day because of your king whom you have chosen for yourselves, and the LORD will not answer you in that day.

This is the most consequential single clause in Book V and it is usually passed over as rhetorical emphasis. It is not rhetorical. It is a stated exclusion, and it excludes the mechanism the corpus had used for the whole preceding book.

**The verb *ṣʿq* is the corpus's technical term for the covenant outcry.** Exodus 2:23: *wa-yizʿaqu wa-taʿal shawʿatam ʾel ha-ʾelohim*, and they cried out and their cry went up to God. Exodus 22:22, of the widow and orphan: *ki ʾim ṣaʿoq yiṣʿaq ʾelay shamoaʿ ʾeshmaʿ ṣaʿaqato*, if he cries at all to me, I will surely hear his cry. And throughout Judges: *wa-yizʿaqu venei Yisraʾel ʾel YHWH* at 3:9, at 3:15, at 4:3, at 6:6, at 10:10. Five times in the book that delivers the terminus four times, and in each case the outcry is followed by a deliverer.

**The Judges cycle is: sin, oppression, outcry, deliverer, quiet.** The outcry is the mechanism by which the cycle turns. Remove it and the cycle cannot complete.

**1 Samuel 8:18 removes it, for this cause, in advance.** *We-loʾ yaʿaneh YHWH ʾetkhem.* The LORD will not answer you. Not will delay, not will answer differently. Will not answer.

Three consequences and each is checkable.

**The grant carries a stated exclusion from the remedy.** The people are told, before they choose, that the standard mechanism for relief from oppression will not operate against the oppression they are choosing. That converts the speech from a warning about consequences into a statement of terms.

**The exclusion is grounded in the choosing.** *ʾAsher beḥartem lakhem*, whom you have chosen for yourselves. The reflexive *lakhem* is emphatic: chosen by you, for you. The corpus attaches the exclusion to the fact that the thing was requested, which is the same structure as Deuteronomy 17:14's conditioning of the statute on the demand.

**The corpus does not repeat the exclusion and does not revoke it.** There is no later passage stating that the outcry-clause was lifted. There are, however, passages in which the corpus records outcry against kings and records a response: Elijah against Ahab, Nathan against David, and the whole prophetic tradition of indictment. Whether those constitute an answer in the sense 8:18 denies is a question the corpus does not address, and this book does not resolve it.

One reading should be set aside explicitly because it is available and this book does not take it. The clause could be read as a prediction that turned out false, since kings were opposed and prophets were sent. That reading requires taking *loʾ yaʿaneh* as a forecast rather than a term, and the surrounding legal register at 8:9 tells against it. But the reading exists, it is not absurd, and a reader who takes it will weaken this chapter without touching Chapters 44 through 46.

## 48. 1 Samuel 8:19-22 · The Refusal to Hear, and the Grant


*Wa-yemaʾanu ha-ʿam li-shmoaʿ be-qol Shemuʾel, wa-yoʾmeru loʾ ki ʾim melekh yihyeh ʿaleynu.*

And the people refused to listen to the voice of Samuel, and they said: no, but a king shall be over us.

**The verb of refusal is *mʾn*, to be unwilling.** It is not an inability. Compare Exodus 7:14 of Pharaoh, *meʾen le-shallaḥ ha-ʿam*, he is unwilling to let the people go, and Jeremiah 5:3, *meʾanu qaḥat musar*, they refused to take correction, and Jeremiah 6:16's *wa-yomeru loʾ nelekh*, which is the same shape with the refusal quoted rather than named.

**The refusal is to *hear*.** *Li-shmoaʿ be-qol.* This is the receiving organ of Book IV in the middle of the monarchy transaction. The corpus states the demand for a king as a failure of the same faculty it names at Deuteronomy 29:3, at Isaiah 6:10, and at Psalm 95:7.

**The refusal is quoted.** *Loʾ ki ʾim melekh yihyeh ʿaleynu.* No, but a king shall be over us. Two words of refusal and a declarative.

Verse 20 then expands the demand, as Chapter 44 noted: like all the nations, our king judging us, going out before us, fighting our battles.

Verse 21: Samuel hears all the words of the people and speaks them in the ears of the LORD. The corpus takes the trouble to say the demand was reported verbatim.

Verse 22: *wa-yoʾmer YHWH ʾel Shemuʾel, shemaʿ be-qolam we-himlakhta lahem melekh.* And the LORD said to Samuel: listen to their voice and make them a king.

**The grant is a command to Samuel and it is unconditional at this point.** No further warning, no further condition, no delay. The grant issues.

**The grammar of the whole transaction is now complete and it has a shape.** The people refuse to hear. God tells Samuel to hear them. The verb *shmʿ* appears on both sides of the transaction: *wa-yemaʾanu ha-ʿam li-shmoaʿ*, the people refused to hear, and *shemaʿ be-qolam*, listen to their voice. The corpus builds the reversal into the vocabulary.

Two things this chapter does not claim.

**It does not claim the grant was reluctant in a way the text states.** The text does not supply an adverb. Hosea 13:11 will supply one and Chapter 50 uses it, but 1 Samuel 8:22 is bare.

**It does not claim Saul's kingship was illegitimate.** The corpus proceeds immediately to anoint him at 10:1, has Samuel present him at Mizpah, and has Samuel defend him. Whatever the transaction was, its product is treated as real. The claim of Book V is about how the corpus characterizes the transaction, not about whether the institution it produced was valid.

## 49. 1 Samuel 12 · The Farewell, and the Rain Out of Season


Samuel's farewell speech is the corpus's own summary of the transaction it has just narrated, and it contains a scene that is easy to skip and hard to explain away.

The speech opens with an accounting. 12:3: *hinneni ʿanu vi neged YHWH we-neged meshiḥo, ʾet shor mi laqaḥti wa-ḥamor mi laqaḥti u-mi ʿashaqti ʾet mi raṣṣoti u-mi-yad mi laqaḥti khofer.* Here I am; testify against me before the LORD and before his anointed: whose ox have I taken, whose donkey have I taken, whom have I defrauded, whom have I oppressed, from whose hand have I taken a bribe?

The verb is *lqḥ*, taken, three times. It is the same verb that ran six times through the bill at 8:11-18. Samuel is answering the king's manner point by point with a denial in the same vocabulary, and the people answer at 12:4: *loʾ ʿashaqtanu we-loʾ raṣṣotanu we-loʾ laqaḥta mi-yad ʾish meʾumah*, you have not defrauded us nor oppressed us nor taken anything from any man's hand.

The corpus has just contrasted the judge who took nothing with the king who will take everything, using one verb, in four chapters.

Verse 12 supplies the diagnosis in Samuel's own words: *wa-tirʾu ki Naḥash melekh benei ʿAmmon baʾ ʿaleykhem wa-toʾmeru li loʾ ki melekh yimlokh ʿaleynu, wa-YHWH ʾeloheykhem malkekhem.* You saw that Nahash king of the Ammonites came against you, and you said to me: no, but a king shall reign over us; and the LORD your God is your king.

Two things there. The demand is dated to a military threat, which the narrative of chapter 8 did not mention and which supplies a further motive. And the final clause asserts the continuing reign in the present tense, after Saul has been made king, which Chapter 45 used.

Then the scene.

Verses 16 through 19. *Ha-loʾ qeṣir ḥiṭṭim ha-yom, ʾeqraʾ ʾel YHWH we-yitten qolot u-maṭar, u-deʿu u-reʾu ki raʿatkhem rabbah ʾasher ʿasitem be-ʿeyney YHWH li-shʾol lakhem melekh.* Is it not wheat harvest today? I will call to the LORD and he will send thunder and rain, that you may know and see that your wickedness is great which you have done in the sight of the LORD in asking for yourselves a king.

Wheat harvest in that climate falls in the dry season. Rain then is destructive and out of season, and the sign is chosen for that reason.

Verse 18: he called, and the LORD sent thunder and rain that day, and all the people greatly feared the LORD and Samuel.

Verse 19: *wa-yoʾmeru khol ha-ʿam ʾel Shemuʾel, hitpallel beʿad ʿavadeykha ʾel YHWH ʾeloheykha we-ʾal namut, ki yasafnu ʿal kol ḥaṭṭoʾteynu raʿah li-shʾol lanu melekh.* And all the people said to Samuel: pray for your servants to the LORD your God that we die not, for we have added to all our sins this evil, to ask for ourselves a king.

**The people name the asking an evil, after the fact, in their own words.** That is the corpus's own retrospective verdict on the transaction, placed in the mouths of the parties who made the demand, four chapters after they made it.

And then verse 20, which is the reason this chapter matters as much for what follows as for what precedes. *Wa-yoʾmer Shemuʾel ʾel ha-ʿam, ʾal tiraʾu, ʾattem ʿasitem ʾet kol ha-raʿah ha-zoʾt, ʾakh ʾal tasuru me-ʾaḥarey YHWH wa-ʿavadtem ʾet YHWH be-khol levavkhem.* Do not fear. You have done all this evil, yet do not turn aside from following the LORD, but serve the LORD with all your heart.

The evil is affirmed and the relation is not withdrawn. Verse 22: *ki loʾ yiṭṭosh YHWH ʾet ʿammo ba-ʿavur shemo ha-gadol*, the LORD will not forsake his people for his great name's sake. Verse 23: *gam ʾanokhi ḥalilah li me-ḥaṭoʾ la-YHWH me-ḥadol le-hitpallel baʿadkhem*, far be it from me that I should sin against the LORD in ceasing to pray for you.

That is the shape the corpus holds throughout: the transaction named as an evil, the parties named as having done it, the relation continued, the concession standing. Chapter 50 supplies the price and Chapter 76 supplies the permanence.

## 50. Hosea 13:11 · Priced in Anger


*ʾEtten lekha melekh be-ʾappi we-ʾeqqaḥ be-ʿevrati.*

I gave you a king in my anger and took him away in my wrath.

Four words carry the chapter and two of them are the adverbial phrases.

**The giving is stated in the first person with a prepositional phrase of manner.** *Be-ʾappi*, in my anger. The noun *ʾaf* is the nostril and by extension the flaring of anger, and the phrase is common in the corpus for divine wrath. The grant of monarchy is characterized by the giver, and the characterization is not favourable.

**The taking is likewise characterized.** *Be-ʿevrati*, in my wrath. *ʿEvrah* is overflow, the sense of anger passing a limit.

**The tenses are debated and the debate does not affect the point.** *ʾEtten* is imperfect and *ʾeqqaḥ* is imperfect; both can be read as past-durative, as present, or as future. The standard reading takes them as past with reference to the whole institution or as iterative with reference to the northern dynasties. Hosea's context at 13:10, *ʾehi malkekha ʾefo we-yoshiʿakha be-khol ʿareykha*, where now is your king that he may save you in all your cities, supports the reading that this is about kings failing to save. Nothing in this chapter depends on the choice.

**The critical question is what the taking takes.** This is F2, and it is the falsifier Book V's argument is most exposed to. If Hosea 13:11 records the withdrawal of the concession, then the corpus does withdraw and Chapter 75's account of an escalation that never withdraws is wrong.

Three reasons it does not.

**The object is a king, not the kingship.** *ʾEtten lekha melekh*, I gave you a king, singular, indefinite. *We-ʾeqqaḥ*, and I took, with the object supplied by the preceding noun. What is given and taken is an occupant. The corpus has vocabulary for institutions and does not use it here.

**Hosea's own context is a sequence of occupants.** 13:10 asks where the king is. 7:7 says *kol malkeyhem nafalu*, all their kings have fallen. 8:4 says *hem himlikhu we-loʾ mimmenni*, they set up kings and not from me. The northern kingdom went through nine dynasties in two centuries and Hosea's material is saturated with that instability. A statement about kings being given and removed reads naturally against it.

**The corpus states the non-withdrawal explicitly elsewhere and Hosea does not contradict it.** 2 Samuel 7:15, *we-ḥasdi loʾ yasur mimmennu ka-ʾasher hasiroti me-ʿim Shaʾul*, my covenant loyalty shall not depart from him as I took it from Saul. The clause names a removal from Saul, an occupant, and bars the corresponding removal from the house. That is the corpus distinguishing between removing a man and removing the grant, in one verse, using the same verb for both halves.

So the F2 search returns nothing. There is no withdrawal formula anywhere in the corpus. There are removals of kings, in quantity: Saul, the northern dynasties, Jehoiachin at Jeremiah 22:24-30, Zedekiah. Every one of them is the removal of an occupant.

What Hosea 13:11 does establish, and it is worth having, is that the corpus's own characterization of the grant is negative at the point of giving. That is a second witness to what 1 Samuel 8 said in narrative, delivered by a prophet in a different kingdom in a different vocabulary.

## 51. Gideon, Abimelech, and the Fable of the Bramble


Judges 9 is the corpus's own commentary on kingship and it takes the form of a fable told from a hilltop by a man expecting to be killed.

The narrative first. Abimelech, Gideon's son by the concubine at Shechem, persuades his mother's kin to back him, takes seventy pieces of silver from the temple of Baal-berith, hires *ʾanashim reqim u-foḥazim*, empty and reckless men, and kills his seventy brothers on one stone at Ophrah. Jotham, the youngest, escapes. Abimelech is made king at Shechem by the terebinth of the pillar.

Jotham then stands on the top of Mount Gerizim, lifts his voice, and tells the fable.

*Halokh halkhu ha-ʿeṣim li-mshoaḥ ʿaleyhem melekh.* The trees went out to anoint a king over them.

They ask the olive. *Wa-yoʾmer lahem ha-zayit, he-ḥodalti ʾet dishni ʾasher bi yekhabbedu ʾelohim wa-ʾanashim we-halakhti la-nuaʿ ʿal ha-ʿeṣim.* Should I leave my fatness, by which they honour God and man, and go to sway over the trees?

They ask the fig. Should I leave my sweetness and my good fruit, and go to sway over the trees?

They ask the vine. *He-ḥodalti ʾet tiroshi ha-mesammeaḥ ʾelohim wa-ʾanashim.* Should I leave my new wine, which cheers God and man, and go to sway over the trees?

Then they ask the bramble. *Wa-yoʾmer ha-ʾaṭad ʾel ha-ʿeṣim, ʾim be-ʾemet ʾattem moshḥim ʾoti le-melekh ʿaleykhem, boʾu ḥasu ve-ṣilli, we-ʾim ʾayin teṣeʾ ʾesh min ha-ʾaṭad we-toʾkhal ʾet ʾarzey ha-Levanon.* If in truth you anoint me king over you, come and take refuge in my shade; and if not, let fire come out of the bramble and devour the cedars of Lebanon.

Four observations.

**Three productive trees decline and each gives the same reason.** Each names what it produces, each names who benefits, and each uses the identical verb of the office: *la-nuaʿ*, to sway or wave. The word is not *mšl* or *mlk* but a verb of motion above others, and it is chosen to make the office sound like tossing in the wind.

**The three declines are the Judges 8:23 refusal repeated three times in a different register.** Gideon declined. The olive, fig, and vine decline. The corpus states the refusal four times in two chapters.

**The bramble accepts, and it has nothing to leave.** The *ʾaṭad* is a thorny scrub with no fruit and no useful product. It is the only candidate that surrenders nothing by taking the office, and the corpus makes that the qualification.

**Its offer of shade is the joke and its threat is the point.** A bramble casts no shade a person could shelter in. And the alternative it names is fire from itself devouring the cedars of Lebanon, which is a threat of total destruction from the least of the plants against the greatest.

Jotham's application is explicit at 9:16-20, and the narrative fulfils it at 9:56-57: God repaid the wickedness of Abimelech, and all the wickedness of the men of Shechem, and *wa-tavoʾ ʾalehem qilelat Yotam ben Yerubbaʿal*, the curse of Jotham came upon them.

Two structural notes for this book.

**The verb of the fable is *mšḥ*, to anoint.** *Li-mshoaḥ ʿaleyhem melekh*, to anoint a king over them, and *moshḥim ʾoti le-melekh*, anointing me king. The corpus's first use of the anointing verb for a king is in a fable ridiculing the exercise, spoken about a fratricide. Chapter 64 works the rite and notes this.

**The fable is preserved in a corpus that also preserves the royal psalms.** That is Book X's subject and this is one of its ten pairs. A tradition operating by selection does not keep Judges 9 and Psalm 45 on one scroll.

## 52. The Two Strands, and Why the Final Form Is the Datum


Book V has read 1 Samuel 8 through 12 as a single transaction with a determinate shape: refusal, demand, diagnosis, itemized bill, exclusion clause, refusal to hear, grant, retrospective confession, price. A reader trained in the source-critical treatment of these chapters will object that this reads as one thing what is demonstrably two.

The objection is serious and the response is not a rebuttal.

**The classical analysis.** Since Wellhausen the material has been divided into a pro-monarchic strand and an anti-monarchic one. The pro-monarchic material is usually located at 9:1-10:16, Saul's anointing in the search for the donkeys, at 11:1-11, the deliverance of Jabesh-gilead, and at 11:15, the kingship renewed at Gilgal. The anti-monarchic material is located at chapter 8, at 10:17-27, the selection by lot with Saul hiding among the baggage, and at chapter 12. The division is not arbitrary; the two bodies differ in vocabulary, in their attitude to the institution, and in their account of how Saul became king, and the second difference is the hardest to explain on a single-source reading.

**This book takes no position on it.** The analysis may be right in whole, in part, or not at all. Nothing in Book V depends on the outcome, and any position taken would be a position taken outside this book's competence.

**What this book does claim is that the final form's retention of both is the datum.**

That claim needs stating precisely because it is easily read as a dodge.

Somebody assembled this material. Whoever it was had the anti-monarchic material and the pro-monarchic material and produced a text containing both. Chapter 8's itemized bill sits four chapters before chapter 12's thunder and rain, and 9:1-10:16's warm account of Saul's anointing sits between them. That arrangement was made.

Three things follow from the arrangement itself, none of which requires a view about the sources.

**The result is not a smooth apologia and it was not made into one.** A redactor wanting a clean account of the founding of the monarchy had the material to produce one and did not. The bill, the exclusion clause, the divine categorization of the demand with the golden calf, and the people's own confession are all retained, in a work that goes on to celebrate David at length.

**The retention is a pattern rather than an accident, because the same corpus does it repeatedly.** Judges 8:23 and Judges 9's fable are retained beside 2 Samuel 7's permanence. Deuteronomy 23:4's bar on Moabites is retained beside Ruth 4:18-22's genealogy through a Moabite. Jeremiah 22:30's childless Coniah is retained beside Haggai 2:23's signet Zerubbabel. Book X counts ten such pairs. A corpus that does this once has had an accident. A corpus that does it ten times has a habit.

**A habit of retention is evidence about the corpus's relation to its own contents.** Specifically: the corpus is not optimized to produce a single coherent position on the monarchy, and a reader who extracts one has extracted it. This book extracts one too, and Chapter 108 says so under the heading of limits.

One last observation, offered as an observation and not as an argument. The two strands, if they exist, disagree about whether the monarchy was good. They do not disagree about the structure Book V has described. The pro-monarchic material has Samuel anoint Saul at God's direction, which is a conferral with a named giver, and has the kingdom renewed at Gilgal *lifney YHWH*, before the LORD. The anti-monarchic material has the throne granted under protest. Both have the office as something received from outside itself. Chapter 62's finding survives the source division, which is the strongest thing that can be said for a reading that declines to enter it.

:::book VI | THE SEAT


## 53. 1 Chronicles 29:23 · The Throne of YHWH


*Wa-yeshev Shelomoh ʿal kisseʾ YHWH le-melekh taḥat Dawid ʾaviv wa-yaṣlaḥ, wa-yishmeʿu ʾelaw kol Yisraʾel.*

And Solomon sat on the throne of the LORD as king in place of David his father, and prospered, and all Israel obeyed him.

The construct is *kisseʾ YHWH*. The throne of the LORD. Not the throne of Israel, not the throne of David, not the throne of the kingdom. The throne of the LORD, with Solomon sitting on it.

This is one of the most consequential three-word phrases in the Hebrew Bible for the argument of this book, and it is worth establishing first that it is not a slip.

**The Chronicler uses the construction three times in one work.**

**1 Chronicles 28:5**, of the son chosen to succeed: *wa-yivḥar bi-Shelomoh veni la-shevet ʿal kisseʾ malkhut YHWH ʿal Yisraʾel*. He chose Solomon my son to sit on the throne of the kingdom of the LORD over Israel. Here the construct is doubled: the throne of the kingdom of the LORD.

**1 Chronicles 29:23**, the seating itself, quoted above.

**2 Chronicles 9:8**, in the mouth of the queen of Sheba: *barukh YHWH ʾeloheykha ʾasher ḥafeṣ bekha le-titkha ʿal kisʾo le-melekh la-YHWH ʾeloheykha.* Blessed be the LORD your God who delighted in you, to set you on his throne as king for the LORD your God.

The third occurrence is the decisive one and it should be read slowly. *ʿAl kisʾo*, on his throne, with the pronoun referring to YHWH from the preceding clause. *Le-melekh*, as king. *La-YHWH ʾeloheykha*, for the LORD your God.

**The beneficiary of the kingship is named, and it is not the king.** The lamed of *la-YHWH* is a lamed of advantage or of purpose: king for the LORD your God. Solomon sits on a throne belonging to another, as king on behalf of that other.

Three attempts to soften this are available and each fails on a specific piece of evidence.

**The honorific reading**, on which throne of the LORD is a pious way of saying throne of Israel-under-God, a compliment rather than a statement of ownership. This does not survive being paired with an explicit assertion of ownership by the honoree's own predecessor, twelve verses earlier. **1 Chronicles 29:11**: *lekha YHWH ha-gedullah we-ha-gevurah we-ha-tifʾeret we-ha-neṣaḥ we-ha-hod ki khol ba-shamayim u-va-ʾareṣ, lekha YHWH ha-mamlakhah we-ha-mitnasseʾ le-khol le-roʾsh.* Yours, LORD, is the greatness and the power and the glory and the victory and the majesty, for all in heaven and earth is yours; yours, LORD, is the kingdom, and you are exalted as head above all. *Lekha YHWH ha-mamlakhah*: yours is the kingdom. Twelve verses later a man sits on the throne of it.

**The scribal-error reading**, on which the text is corrupt and should read throne of Israel. There is no manuscript support for this and the phrase occurs three times in variant forms, which is the opposite of what a single corruption looks like.

**The Chronicler's-idiosyncrasy reading**, on which this is one late writer's theological embellishment and not the corpus's position. This is the strongest of the three and it is partly right: the phrase is the Chronicler's and Samuel-Kings does not use it. What it cannot do is remove the phrase from the corpus. The Chronicler is inside the canon and his three statements are three statements. And Chapter 55 finds the same structure in a psalm that is not his, and Chapter 61 finds it in Ezekiel.

Two features of the immediate context sharpen the reading further.

**The seating is in the middle of a chapter about giving.** 1 Chronicles 29 is the account of the offerings for the temple, and its theological centre is David's prayer at 29:14: *ki mimmekha ha-kol u-mi-yadkha natannu lakh*, for all things come from you, and of your own have we given you. The chapter's argument is that nothing given to God originated with the giver. The seating at verse 23 falls inside that frame.

**The verb of sitting is ordinary.** *Wa-yeshev*, and he sat. The corpus does not use an elevated verb, does not describe an ascent, and does not narrate an enthronement rite. A man sits down on a piece of furniture that belongs to someone else, and the corpus says whose.

## 54. Two More Chronicler Sites, and What Three Occurrences Establish


Chapter 53 quoted the three occurrences. This chapter asks what three establishes that one would not.

**One occurrence is a phrase.** A single instance of *kisseʾ YHWH* could be idiom, hyperbole, a fossilized expression, or a scribal artefact. Any of those would make it unsafe to build on.

**Three occurrences in one work, in three different constructions, in three different speech situations, is a usage.** 28:5 is David speaking to the assembly about the choice of his successor. 29:23 is the narrator reporting the accession. 2 Chronicles 9:8 is a foreign queen speaking to Solomon in praise. Three registers, three speakers, one construction. That distribution is what distinguishes a writer's settled way of describing a thing from a phrase that slipped through.

**And the third occurrence adds a term the other two do not have.** *La-YHWH ʾeloheykha*, for the LORD your God. The queen of Sheba does not merely repeat the ownership; she states the purpose. Whoever composed her speech understood the construction well enough to extend it.

Two further sites in Chronicles belong beside the three and are usually not brought into the discussion.

**1 Chronicles 17:14**, the Chronicler's version of the dynastic oracle. Where 2 Samuel 7:16 reads *we-neʾman beytekha u-mamlakhtekha ʿad ʿolam le-faneykha*, your house and your kingdom shall be established forever before you, the Chronicler reads *we-haʿamadtihu be-veyti u-ve-malkhuti ʿad ha-ʿolam we-khisʾo yihyeh nakhon ʿad ʿolam*. I will set him in **my** house and in **my** kingdom forever, and his throne shall be established forever.

The pronouns have moved. Samuel has your house and your kingdom, addressed to David. Chronicles has my house and my kingdom, spoken by God, with the throne alone assigned to the son. That is a systematic change and it runs in the direction Chapter 53 described.

**2 Chronicles 13:8**, in the mouth of Abijah addressing the northern army: *we-ʿattah ʾattem ʾomerim le-hitḥazzeq lifney mamlekhet YHWH be-yad benei Dawid.* And now you think to withstand the kingdom of the LORD in the hand of the sons of David.

*Mamlekhet YHWH be-yad benei Dawid*: the kingdom of the LORD in the hand of the sons of David. Ownership and custody in one construct chain, with the Davidides holding rather than owning.

**Five sites.** Three with *kisseʾ*, one with the pronoun shift in the dynastic oracle, one with *mamlekhet YHWH* held in a hand. The Chronicler has a consistent position and states it five times in five ways.

One further consideration should be recorded because it cuts against a lazy reading of the Chronicler as a royalist. He is writing after the monarchy has ended, for a community without a king, under Persian administration. On the usual account his purpose is to legitimate the temple community by grounding it in the Davidic past. If that is right, then the systematic relocation of ownership from the dynasty to God is a strange move for a royalist to make, and a natural one for a writer explaining to a kingless community that what mattered about the kingdom was never in the dynasty's possession.

This book does not claim to know his purpose. It records that the five sites are consistent, that they run one direction, and that the direction is the one Books III through V have been tracing from entirely different material.

## 55. Psalm 110:1 · The Seat Is Offered, and the Offerer Named


*Neʾum YHWH la-ʾadoni, shev li-mini ʿad ʾashit ʾoyveykha hadom le-ragleykha.*

The utterance of the LORD to my lord: sit at my right hand until I make your enemies a footstool for your feet.

This is the corpus's most exalted single statement about a royal figure and it is also, read grammatically, its clearest statement of conferral. Both facts are in one verse and neither cancels the other.

**The opening formula is a prophetic one.** *Neʾum YHWH*, the utterance of the LORD, is the standard prophetic citation formula, used hundreds of times across the prophets to introduce divine speech. Here it introduces a speech addressed to a human figure by a speaker who is not that figure.

**The addressee is *ʾadoni*, my lord.** A human superior. The corpus uses *ʾadoni* constantly for a person of higher rank addressed by an inferior: Genesis 23:6 of Abraham, 1 Samuel 24:9 of Saul, 1 Kings 1:13 of David. The vocalization is not the divine one and the psalm's superscription attributes it to David, which sets up the well-known question of who is addressing whom that this book does not need to enter.

**The seat is offered by imperative.** *Shev li-mini*, sit at my right hand. The verb is a command from the speaker to the addressee, and the location is defined relative to the speaker. It is his right hand. The addressee is given a position at somebody else's side.

**The subjugation is the speaker's work.** *ʿAd ʾashit ʾoyveykha hadom le-ragleykha.* Until **I** make your enemies a footstool. The first person is the speaker's and the enemies are the addressee's. The addressee does not defeat them; he sits while they are made into furniture.

That grammatical arrangement is the whole finding of Book VI in one verse and it appears in the psalm the tradition has most consistently read as the high point of royal exaltation. The exaltation and the conferral are not competing readings. The verse says both and it says the second in the grammar.

**Verse 2 continues the pattern.** *Maṭṭeh ʿuzzekha yishlaḥ YHWH mi-Ṣiyyon.* The rod of your strength the LORD shall send from Zion. The rod is the addressee's, *ʿuzzekha*; the sending is YHWH's.

**Verse 3 is textually difficult and this book makes no use of it.** *ʿAmmekha nedavot be-yom ḥeylekha be-hadrey qodesh me-reḥem mishḥar lekha ṭal yalduteykha* is one of the most contested verses in the Psalter, with the Masoretic Text, the Septuagint, and the versions diverging substantially. No argument here depends on it and none is built on it.

**Verse 4 is the second conferral and Chapter 56 works it.**

**Verse 5 reverses the position.** *ʾAdonay ʿal yeminkha maḥaṣ be-yom ʾappo melakhim.* The Lord at your right hand shatters kings in the day of his wrath. In verse 1 the addressee sits at YHWH's right hand; in verse 5 the Lord is at the addressee's right hand. The relation is stated from both sides in one psalm, which is either a deliberate reciprocity or an indication that the two verses come from different hands. This book takes no position and notes that on either reading the shattering is not the addressee's act.

One observation to close, and it should be made carefully because it can be overstated. Psalm 110 is a psalm of enormous exaltation and this chapter has read it for its verbs. That is a partial reading and it is the reading the book's question requires. A reader whose question is what the psalm claims about the addressee's status will find this chapter says almost nothing about that, and will be right. The claim here is only that the psalm, in stating the status, states it as given, and states who gives it, in a grammar the corpus repeats at Daniel 7:14 and at 1 Chronicles 29:23 and at Psalm 2:7.

## 56. Psalm 110:4 · A Priesthood Not Aaron's


*Nishbaʿ YHWH we-loʾ yinnaḥem, ʾattah khohen le-ʿolam ʿal divrati Malki-Ṣedeq.*

The LORD has sworn and will not repent: you are a priest forever after the order of Melchizedek.

**The conferral is by oath and the oath is God's.** *Nishbaʿ YHWH*, the LORD has sworn. The perfect. And *we-loʾ yinnaḥem*, and he will not change his mind, which forecloses revocation in the same clause that makes the grant.

**The grant is a priesthood, given to the figure of verse 1.** The addressee of *ʾattah khohen* is the *ʾadoni* of verse 1. One psalm, one figure, two conferrals: a seat and a priesthood, both given, both by the same speaker.

**The order named is not Aaron's.** *ʿAl divrati Malki-Ṣedeq*, after the manner of Melchizedek. This is the striking feature and it is easily passed over by a reader who takes Melchizedek as a generic honorific.

Melchizedek appears in the Hebrew Bible exactly twice: at Genesis 14:18-20 and here. Nowhere else. At Genesis 14:18 he is *melekh Shalem* and *khohen le-ʾel ʿelyon*, king of Salem and priest of God Most High. He brings out bread and wine, blesses Abram, and receives a tenth. He is not an Israelite, he predates Sinai, he predates Aaron by five generations, and the corpus supplies him with no genealogy at all.

So the royal priesthood of Psalm 110:4 is patterned on a pre-Israelite, non-Aaronide, genealogically unplaced figure, in a corpus that legislates the priesthood as hereditary in Aaron's line at Exodus 28-29 and Numbers 3 and 18, and that executes kings for priestly acts at 2 Chronicles 26:16-21.

**The dynastic-form question, and the corpus's own answer to it.** A reader may suspect that *Malki-Ṣedeq* is a personal name invented for the passage, or a title, and that the psalm is reaching for an archaism. The corpus supplies the check independently. **Joshua 10:1** names the king of Jerusalem at the conquest *ʾAdoni-Ṣedeq*, my lord is Ṣedeq, or lord of righteousness. Two Jerusalemite kings, both with *ṣedeq* as the theophoric or predicative element, separated by centuries in the corpus's own chronology, in two different books with no literary relation. That is not an isolated anomaly. It is a local dynastic naming form, and the corpus preserves two instances of it.

The consequence is that Psalm 110:4 is not inventing a legendary priest-king. It is patterning the Davidic royal priesthood on the pre-Israelite Jerusalemite one, whose form the corpus attests twice.

Three notes on what this chapter does and does not claim.

**It does not claim the Davidic kings functioned as priests.** The evidence for royal priestly action is contested: David wearing an ephod and offering at 2 Samuel 6:14-18, Solomon offering at 1 Kings 3:4 and blessing at 8:14, and against them the Uzziah episode at 2 Chronicles 26. This book takes no position on the historical question.

**It does not claim the Aaronide priesthood is thereby displaced.** Numbers 25:12-13 gives Phinehas *berit kehunnat ʿolam*, a covenant of perpetual priesthood, and Ezekiel 44:15 restricts temple service to the sons of Zadok. The corpus carries both the perpetual Aaronide grant and the perpetual non-Aaronide one, and reconciles them nowhere. Book X counts this among its ten pairs.

**What it does claim is the conferral grammar.** The priesthood is sworn to the figure by God, in the perfect, with the revocation barred. The figure does not hold it in his own right and does not hold it by descent, since the order named has no descent. He holds it because it was sworn.

## 57. Melchizedek and Adoni-Ṣedeq · The Received Institution


Chapter 56 established that the royal priesthood is patterned on a non-Israelite order. This chapter takes the wider observation that the pattern belongs to: what Israel holds, the corpus records as received, with the source named.

**Four transfers, four foreign sources, none concealed.**

**A standing priestly order, from Melchizedek.** Genesis 14:18-20, made permanent for the Davidic figure at Psalm 110:4. The order is his and the corpus says so.

**A divine title, from the same encounter.** Melchizedek blesses Abram *le-ʾel ʿelyon qoneh shamayim wa-ʾareṣ*, by God Most High, possessor of heaven and earth, at Genesis 14:19. Four verses later, at 14:22, Abram swears *harimoti yadi ʾel YHWH ʾel ʿelyon qoneh shamayim wa-ʾareṣ*. I have lifted my hand to YHWH, God Most High, possessor of heaven and earth. The title spoken by the Canaanite priest is taken onto Abram's own oath, with the Name prefixed. The corpus narrates the acquisition of a divine epithet and shows the joining seam in the syntax.

**An administrative procedure, from Jethro.** Exodus 18:13-23. Moses judges the people alone from morning to evening. Jethro, priest of Midian, observes and says *loʾ ṭov ha-davar ʾasher ʾattah ʿoseh*, the thing you are doing is not good, and proposes the delegated judiciary: rulers of thousands, hundreds, fifties, and tens. And then 18:24: *wa-yishmaʿ Mosheh le-qol ḥoteno wa-yaʿas kol ʾasher ʾamar.* And Moses listened to the voice of his father-in-law and did all that he said.

The verb is *shmʿ be-qol*, to listen to the voice, which Book IV traced as the corpus's own idiom for the receiving Israel is repeatedly said to fail at. Here Moses performs it, and the voice is a Midianite priest's.

**The sanctuary's ground, from Ornan the Jebusite.** 2 Chronicles 3:1 places the temple *be-har ha-Moriyyah ... bi-meqom ʾasher hekhin be-Dawid bi-goren ʾOrnan ha-Yevusi*, on Mount Moriah, in the place David had prepared, at the threshing floor of Ornan the Jebusite. And the acquisition is recorded, at 2 Samuel 24:24, with David refusing a gift: *loʾ ki qano ʾeqneh me-ʾotekha bi-meḥir, we-loʾ ʾaʿaleh la-YHWH ʾelohay ʿolot ḥinnam.* No, but I will surely buy it from you at a price, and I will not offer to the LORD my God burnt offerings that cost me nothing.

Bought and not seized. The corpus records the price, fifty shekels of silver in Samuel and six hundred shekels of gold in Chronicles, and the discrepancy is a known problem that does not affect the point.

**What the four have in common.** In each case the corpus could have concealed the source and did not. It could have given the priestly order no antecedent. It could have had Abram coin the divine title. It could have had Moses devise the judiciary. It could have had the threshing floor be ancestral land. In every case it names an outsider, names the transfer, and in the fourth case names the sum.

Two disciplinary notes.

**The Genesis 14:20 subject is contested and nothing here depends on it.** *Wa-yitten lo maʿaser mi-kol*, and he gave him a tenth of everything, has no explicit subject and can be read either way: Abram tithing to Melchizedek, or Melchizedek giving Abram a tenth of the spoil. The majority reading is the first. This book takes no side, because Psalm 110:4 settles whose order the priesthood is independently of who handed whom a tenth.

**The observation is about the corpus's habit, not about historical dependence.** Whether Israelite institutions historically derive from Canaanite or Midianite ones is a question for a different discipline. The claim here is about what the corpus records, and what it records is a pattern of acknowledged receipt.

## 58. Deuteronomy 17:18-20 · The King Copies a Law He Did Not Write


Chapter 43 established that the law of the king regulates a demand. This chapter reads its single positive requirement.

*We-hayah khe-shivto ʿal kisseʾ mamlakhto we-khatav lo ʾet mishneh ha-torah ha-zoʾt ʿal sefer mi-lifney ha-kohanim ha-Lewiyyim. We-haytah ʿimmo we-qaraʾ vo kol yemey ḥayyaw, le-maʿan yilmad le-yirʾah ʾet YHWH ʾelohaw li-shmor ʾet kol divrey ha-torah ha-zoʾt we-ʾet ha-ḥuqqim ha-ʾelleh la-ʿasotam. Le-vilti rum levavo me-ʾeḥaw u-le-vilti sur min ha-miṣwah yamin u-semoʾl, le-maʿan yaʾarikh yamim ʿal mamlakhto huʾ u-vanaw be-qerev Yisraʾel.*

And when he sits on the throne of his kingdom, he shall write for himself a copy of this law in a book, from before the levitical priests. And it shall be with him, and he shall read in it all the days of his life, that he may learn to fear the LORD his God, to keep all the words of this law and these statutes, to do them. That his heart be not lifted up above his brothers, and that he turn not aside from the commandment to the right or the left, so that he may prolong days over his kingdom, he and his sons, in the midst of Israel.

Five features.

**The requirement attaches to the moment of sitting.** *Khe-shivto ʿal kisseʾ mamlakhto*, when he sits on the throne of his kingdom. The first act of the reign is a copying.

**The exemplar is in the custody of others.** *Mi-lifney ha-kohanim ha-Lewiyyim*, from before the levitical priests. The king does not hold the master text. He copies from a copy held by a different office. Two institutions, one dependent on the other for the document.

**He writes it himself.** *We-khatav lo*, and he shall write for himself. Not have written, not commission. The corpus makes the king perform the scribal act, which is the act of a man taking down what another has composed.

**He reads it all his life.** *We-qaraʾ vo kol yemey ḥayyaw.* Not once at accession. Continuously.

**The purpose clause names the failure mechanism.** *Le-vilti rum levavo me-ʾeḥaw*, that his heart be not lifted up above his brothers. That is Deuteronomy 8:14's *ram levavekha* applied to the king. The law of the king guards against the same mechanism the law of prosperity warned about, in the same words.

**And a guard erected against an impossibility is not a guard.** This is the inference and it is worth stating explicitly. The corpus does not legislate against risks it considers unreal. The presence of the clause is evidence that whoever composed it expected the failure, and the corpus supplies the executions.

**2 Chronicles 26:16.** *U-khe-ḥezqato gavah libbo ʿad le-hashḥit wa-yimʿal ba-YHWH ʾelohaw wa-yavoʾ ʾel heykhal YHWH le-haqṭir ʿal mizbaḥ ha-qeṭoret.* And when he was strong, his heart was lifted up to his destruction, and he trespassed against the LORD his God and went into the temple of the LORD to burn incense on the altar of incense. Uzziah, struck with a skin disease on the forehead, put out of the temple, and living in a separate house until his death, with his son over the household judging the people. The verb is *gavah* rather than *rum*, but the idiom is identical and the result is a king removed from function while alive.

**2 Chronicles 32:25.** *We-loʾ khe-gemul ʿalaw heshiv Yeḥizqiyyahu ki gavah libbo, wa-yehi ʿalaw qeṣef we-ʿal Yehudah wi-Yerushalayim.* But Hezekiah did not render according to the benefit done to him, for his heart was lifted up; and there was wrath upon him and upon Judah and Jerusalem. And then 32:26, the mitigation: *wa-yikkanaʿ Yeḥizqiyyahu be-govah libbo*, Hezekiah humbled himself for the pride of his heart.

Two named kings, one idiom, one book, both executions of a guard written into the law of the king.

The structural consequence for Book VI. **The king is subordinate to a document he did not author and cannot alter.** He copies it from another office's exemplar, reads it for life, and is held by its purpose clause to a station among his brothers rather than above them. That is a description of a delegated office with an external standard, and it is the Deuteronomic form of the same relation Chronicles states with *kisseʾ YHWH* and Psalm 110 states with *shev li-mini*.

## 59. 2 Samuel 7:14-15 · Discipline Inside the Sonship Clause


The dynastic oracle at 2 Samuel 7 is the corpus's foundational statement of the Davidic grant, and its most exalted verse carries a limit inside itself.

*ʾAni ʾehyeh lo le-ʾav we-huʾ yihyeh li le-ven, ʾasher be-haʿawoto we-hokhaḥtiv be-shevet ʾanashim u-ve-nigʿey benei ʾadam. We-ḥasdi loʾ yasur mimmennu ka-ʾasher hasiroti me-ʿim Shaʾul ʾasher hasiroti mi-lefaneykha.*

I will be to him a father and he will be to me a son; when he does wrong I will chasten him with the rod of men and with the strokes of the sons of men. But my covenant loyalty shall not depart from him, as I took it from Saul whom I removed from before you.

**The sonship is stated in the covenant formula.** *ʾAni ʾehyeh lo le-ʾav we-huʾ yihyeh li le-ven.* The construction *ʾehyeh le ... yihyeh li le* is the corpus's standard covenant formula, used of God and the people at Exodus 6:7, Leviticus 26:12, Jeremiah 7:23, Ezekiel 36:28, and elsewhere. Its application to a king is a narrowing of a relation the corpus elsewhere applies to a nation.

**The wrongdoing is anticipated in the same sentence.** *ʾAsher be-haʿawoto*, when he does wrong. Not if. The particle carries a temporal-conditional force, and the corpus does not hedge: the sonship clause and the misconduct clause are one sentence.

**The discipline is by ordinary means.** *Be-shevet ʾanashim u-ve-nigʿey benei ʾadam*, with the rod of men and the strokes of the sons of men. This is a striking specification. The chastening is not by plague, by prodigy, or by direct visitation. It is by human agency, which in the narrative that follows means Absalom, Sheba, Rezon, Hadad, Jeroboam, and eventually Nebuchadnezzar.

**The withdrawal is barred, and the bar is stated against a precedent.** *We-ḥasdi loʾ yasur mimmennu ka-ʾasher hasiroti me-ʿim Shaʾul.* The same verb *swr* in the qal for the not-departing and in the hiphil for the removal from Saul. The corpus uses one root on both sides of the contrast, which makes the contrast precise: the thing that was removed from Saul will not be removed from this house.

So the grant is unrevokable and the occupant is disciplinable. Those are two different objects and the verse distinguishes them in one sentence. Chapter 76 takes up the permanence and Chapter 50 has already used verse 15 to answer F2.

Two features of the wider chapter belong here.

**The oracle begins by refusing David's proposal.** 7:1-2 has David saying he dwells in a house of cedar while the ark dwells in curtains. 7:5: *ha-ʾattah tivneh li bayit le-shivti*, shall you build me a house to dwell in? And 7:11 turns the noun around: *we-higgid lekha YHWH ki vayit yaʿaseh lekha YHWH*, the LORD declares that the LORD will make you a house. The whole oracle is a reversal of who builds what for whom, and the reversal is its structure.

**The verse before the sonship clause carries the same reversal.** 7:8: *ʾani leqaḥtikha min ha-nawah me-ʾaḥar ha-ṣoʾn li-hyot nagid ʿal ʿammi ʿal Yisraʾel.* I took you from the pasture, from following the sheep, to be *nagid* over my people, over Israel. Three things: the taking is God's, the title is *nagid* rather than *melekh*, and the people are *ʿammi*, mine. Chapter 61 returns to that possessive because Ezekiel builds on it.

**And the whole grant is answered by David in the register of receipt.** 7:18: *mi ʾanokhi ʾAdonay YHWH u-mi veyti ki haviʾotani ʿad halom*, who am I, Lord GOD, and what is my house, that you have brought me this far. The response to a conferral is a question about desert, which is the response the grammar invites.

## 60. Psalm 2:7 · Dated in One Adverb


*ʾAsapperah ʾel ḥoq, YHWH ʾamar ʾelay beni ʾattah ʾani ha-yom yelidtikha.*

I will declare the decree: the LORD said to me, you are my son; today I have begotten you.

The verse is one of the corpus's highest statements about a king and it dates itself in a single word.

**The statement is a quotation of a decree.** *ʾAsapperah ʾel ḥoq*, I will recount the statute, or with the preposition read as concerning, I will tell of the decree. The speaker is reporting something enacted rather than describing a condition.

**The sonship is declared by the speaker's superior.** *YHWH ʾamar ʾelay*, the LORD said to me. The relation is constituted by an utterance and the utterance is quoted.

**And it is dated.** *ʾAni ha-yom yelidtikha*, today I have begotten you.

*Ha-yom* is the datum. A begetting that happens today is an event with a date, and a relation constituted on a date is a relation that did not obtain the day before. The corpus is not describing an eternal filiation; it is quoting a decree issued at a moment.

The moment is the coronation. That identification is not imported: the psalm supplies the setting in its own verses. 2:2, kings of the earth setting themselves against YHWH and against his anointed. 2:6, *wa-ʾani nasakhti malki ʿal Ṣiyyon har qodshi*, I have installed my king on Zion, my holy hill. 2:8, ask of me and I will give the nations as your inheritance. 2:9, you shall break them with a rod of iron. The furniture of the psalm is accession, installation, the submission of vassals, and the granting of territory, which is the standard content of an enthronement.

**The verb *nasakhti* at 2:6 is a second conferral in the same psalm.** Its root is disputed between *nsk*, to pour or install, and a by-form; either way the subject is God and the object is the king. *Malki*, my king, with the possessive. The king is God's king in the same psalm in which he is God's son.

**And 2:8 makes the inheritance conditional on a request.** *Sheʾal mimmenni we-ʾettenah goyim naḥalatekha.* Ask of me and I will give. The nations are not the king's by right; they are available on petition. The most expansive territorial claim in the Psalter is stated as a thing to be asked for.

Three notes.

**The adoption formula is the standard reading and it is a reading.** Comparative material from the ancient Near East uses similar language of kings, and the majority of scholarship reads Psalm 2:7 as a Judahite adoption formula at accession. This book uses the internal evidence and does not need the comparative material, though the comparative material supports it.

**The psalm's own frame is a threat and a warning.** It opens with nations raging and closes at 2:10-12 with an instruction to the kings of the earth: be wise, be warned, serve the LORD with fear, kiss the son lest he be angry. The exaltation of the king in verses 6 through 9 sits inside an address to other kings, which is the rhetorical situation of a suzerain announcing a vassal's installation.

**And the exaltation is real.** This book has no interest in diminishing it. A man is declared son of God, installed on a holy hill, and offered the nations. What the verse also does, in its central word, is date the declaration, and a dated sonship is a conferred one.

## 61. Ezekiel 34:24 · Two Roles, One Verse, Distinguished


*Wa-ʾani YHWH ʾehyeh lahem le-ʾelohim we-ʿavdi Dawid nasiʾ be-tokham, ʾani YHWH dibbarti.*

And I the LORD will be their God, and my servant David a prince in their midst; I the LORD have spoken.

One verse, two roles, one grammatical structure holding them apart. This is the sharpest statement in the prophetic corpus of the distinction Book VI is describing and it is worth reading against its whole chapter, because the chapter is a sustained argument about who the shepherd is.

**Ezekiel 34 opens against the shepherds of Israel.** 34:2: *hoy roʿey Yisraʾel ʾasher hayu roʿim ʾotam, ha-loʾ ha-ṣoʾn yirʿu ha-roʿim.* Woe to the shepherds of Israel who feed themselves; should not the shepherds feed the flock? The indictment runs through verse 10: they eat the fat, clothe themselves with the wool, kill the fatlings, and do not feed the flock; the weak are not strengthened, the sick not healed, the broken not bound, the strayed not brought back, the lost not sought.

**Then the removal.** 34:10: *hineni ʾel ha-roʿim we-darashti ʾet ṣoʾni mi-yadam we-hishbattim me-reʿot ṣoʾn.* Behold I am against the shepherds and will require my flock at their hand and cause them to cease from feeding the flock.

**Then the substitution, and the subject is God.** 34:11: *hineni ʾani we-darashti ʾet ṣoʾni u-viqqartim.* Behold I, even I, will search for my sheep and seek them out. Verses 11 through 16 are a sustained first-person sequence: I will seek, I will deliver, I will bring out, I will gather, I will bring in, I will feed, I will cause them to lie down, I will seek the lost, I will bring back the strayed, I will bind the broken, I will strengthen the sick. Eleven first-person verbs.

**And 34:15 uses the settling-root.** *ʾAni ʾerʿeh ṣoʾni wa-ʾani ʾarbiṣem*, I will feed my flock and I will make them lie down. The terminus vocabulary in the middle of the shepherd oracle, with God as subject.

**Then, after all that, the Davidic figure.** 34:23: *wa-haqimoti ʿaleyhem roʿeh ʾeḥad we-raʿah ʾethen ʾet ʿavdi Dawid, huʾ yirʿeh ʾothen we-huʾ yihyeh lahen le-roʿeh.* And I will set up over them one shepherd and he shall feed them, my servant David; he shall feed them and he shall be their shepherd.

And then 34:24, the verse.

**The possessive runs throughout and it never transfers.** *Ṣoʾni*, my flock, at 34:6, 34:8, 34:10 twice, 34:11, 34:12, 34:15, 34:17, 34:19, 34:22, and 34:31. Eleven occurrences. In the same chapter in which a shepherd is appointed, the flock is called God's eleven times and is never once called the shepherd's.

**The appointing verb is causative with God as subject.** *Wa-haqimoti ʿaleyhem*, and I will raise up over them.

**The title is *nasiʾ*, not *melekh*.** At 34:24 and again at 37:25, where 37:24 had used *melekh*. Ezekiel's preference for *nasiʾ* runs through the temple vision at 44:3, 45:7-8, 45:16-17, and 46:2-18, where the prince has assigned portions, brings his own offerings, enters by a specified gate, and is warned at 45:8 *we-loʾ yonu ʿod nesiʾay ʾet ʿammi*, my princes shall no more oppress my people. The word *nasiʾ* is a term for a tribal chief or leader and it is a step down from *melekh* in register.

**And the divine role is stated first and in the covenant formula.** *Wa-ʾani YHWH ʾehyeh lahem le-ʾelohim.* The same formula as 2 Samuel 7:14 but with the people as the second party, which is its usual application. The verse gives God the covenant relation and the prince a location, *be-tokham*, in their midst.

The finding: **the corpus places both roles in one sentence and assigns them different predicates.** God is their God. David is a prince among them. Not two names for one office; two offices in one clause, with a comma between them that the corpus supplies as a waw.

## 62. The Passive Verb and the Named Giver


Book VI has read eleven passages across six books. This chapter states what they have in common, because the commonality is the book's principal finding and it is a grammatical one.

**The pattern.** Wherever the corpus states what a royal or exalted figure holds, the verb is passive, or the verb is active with God as its subject and the figure as its object or beneficiary. There is no exception in the passages examined.

**The evidence, gathered.**

Deuteronomy 17:15. *Som tasim ʿaleykha melekh ʾasher yivḥar YHWH ʾeloheykha bo.* The king is the one God chooses. The choosing verb has God as subject.

1 Samuel 8:22. *We-himlakhta lahem melekh.* Samuel is commanded to make them a king. The king does not take the office.

2 Samuel 7:8. *ʾAni leqaḥtikha min ha-nawah.* I took you from the pasture. First person divine, second person object.

2 Samuel 7:11. *Ki vayit yaʿaseh lekha YHWH.* The LORD will make you a house. The house is made for him.

2 Samuel 7:14. *ʾAni ʾehyeh lo le-ʾav.* The relation is constituted by divine declaration.

Psalm 2:6. *Wa-ʾani nasakhti malki.* I have installed my king.

Psalm 2:7. *ʾAni ha-yom yelidtikha.* Today I have begotten you.

Psalm 2:8. *Sheʾal mimmenni we-ʾettenah.* Ask of me and I will give.

Psalm 110:1. *Shev li-mini.* Sit at my right hand. Imperative from the giver, and *ʾashit ʾoyveykha*, I will make your enemies, first person divine.

Psalm 110:4. *Nishbaʿ YHWH ... ʾattah khohen.* The LORD has sworn; you are a priest.

1 Chronicles 28:5. *Wa-yivḥar bi-Shelomoh veni.* He chose Solomon.

1 Chronicles 29:23. *Wa-yeshev Shelomoh ʿal kisseʾ YHWH.* He sat on a throne belonging to another.

2 Chronicles 9:8. *Le-titkha ʿal kisʾo le-melekh la-YHWH.* To set you on his throne as king for the LORD.

Ezekiel 34:23. *Wa-haqimoti ʿaleyhem roʿeh ʾeḥad.* I will raise up over them one shepherd.

Daniel 7:14, which Chapter 81 works in full. *We-leh yehiv sholṭan.* And to him was given dominion. Aramaic peʿil, passive, with no agent expressed.

**Fifteen sites. Six books. Two languages. One grammar.**

Three things follow.

**The grammar is not a coincidence of one editor.** The sites span the Torah, the Former Prophets, the Latter Prophets, the Psalter, and the Writings, in Hebrew and in Aramaic. No single hand produced them and no single school is plausible for all of them.

**The grammar survives the escalation.** Book VIII will show the figure growing from a man anointed with oil to a being receiving everlasting dominion in a night vision. Across that whole escalation, the verb does not change. At Deuteronomy 17:15 God chooses; at Daniel 7:14 it is given. The magnitude of what is held rises steeply and the mode of holding does not move at all.

**And the grammar is independent of the census.** Chapter 17 found, from an entirely different instrument on an entirely different question, that where a king appears at a terminus site he appears as recipient with the giver named. This chapter finds the same relation in the conferral material by reading verbs. Two instruments, no shared premise, one result. That convergence is the strongest evidence Book VI has and it is worth naming as such.

One qualification, because the claim is a universal and universals are fragile. The claim is about the passages examined, which are the principal conferral passages of the corpus. It is not a claim that no verse anywhere has a king as the subject of an acquiring verb; kings take cities, take wives, take spoil, and take the kingdom by force in the northern narratives constantly. The claim is narrower and is about what the corpus says a royal figure holds *by grant*, and there the grammar is uniform.

## 63. Anointing Itself · The Morphology of a Passive Title


The title itself is a passive participle and this chapter is about that fact.

*Mashiaḥ* is the passive participle of *mšḥ*, to smear or anoint. Morphologically it is a qatil-form functioning as a passive adjective: anointed, one who has been smeared. It is not an agent noun. There is no form in the corpus meaning one who anoints applied to the figure, and the corpus's agent-forms for the rite are always the officiant: Samuel anoints, Zadok anoints, the elders anoint.

Three observations follow from the morphology alone and each is checkable.

**The title names what was done to the bearer.** A *mashiaḥ* is defined by having received an application. The word contains no claim about what he does, only about what happened to him. In this it differs from every other Hebrew royal title. *Melekh* is from a root of ruling. *Nagid* is from a root of being in front or being told. *Moshel* is an active participle, one who rules. *Nasiʾ* is from *nśʾ*, to lift, and is usually taken as one lifted up, which is itself passive in force, and which is Ezekiel's preferred term.

**The rite is performed by another.** Every anointing narrative in the corpus has an officiant distinct from the anointed. Samuel anoints Saul at 1 Samuel 10:1, pouring a flask of oil on his head and kissing him. Samuel anoints David at 16:13, taking the horn of oil and anointing him in the midst of his brothers. Zadok the priest and Nathan the prophet anoint Solomon at 1 Kings 1:39, Zadok taking the horn of oil from the tent. Jehoiada's people anoint Joash at 2 Kings 11:12. A prophet's servant anoints Jehu at 2 Kings 9:6. The men of Judah anoint David at 2 Samuel 2:4 and the elders of Israel at 5:3.

Seven anointings, seven officiants, no self-anointing anywhere in the corpus.

**The substance is external and the source is named.** Oil, in a flask at 1 Samuel 10:1 (*pakh ha-shemen*) or a horn at 16:13 and 1 Kings 1:39 (*qeren ha-shemen*). At 1 Kings 1:39 the horn is taken *min ha-ʾohel*, from the tent, which is to say from the sanctuary. The substance conferring the office comes from a place the office does not control.

The consequence for this book is one sentence and it should be stated exactly. **The corpus's central royal title is morphologically a record of something received.** That is not an argument, since morphology does not settle theology, and a passive title can be borne by a figure who acts with total sovereignty. What it is is a convergence: the title's form, the rite's structure, the conferral verbs of Chapter 62, and the census result of Chapter 17 all point one direction, and the title is the smallest and hardest of the four data.

One further note, and it is a genuine complication rather than a supporting detail. **The rite is not confined to kings.** Aaron and his sons are anointed at Exodus 29:7 and Leviticus 8:12. The tabernacle and its furniture are anointed at Exodus 40:9-11. Elisha is to be anointed prophet at 1 Kings 19:16. And Hazael, king of Aram, is to be anointed at the same verse, which Chapter 70 works because it is the strangest item in the whole field.

So *mashiaḥ* is not a royal title exclusively, and a book that presented it as one would be overstating. Chapter 74's census sorts every occurrence and finds the distribution is wider than the tradition's usage suggests. What holds across the whole distribution, kings and priests and furniture and a foreign king alike, is the passive: everything anointed in the Hebrew Bible had the oil applied to it by somebody else.

:::book VII | THE OCCUPANTS


## 64. The Anointing Rite · Oil, Horn, and Flask


Before the occupants, the rite, because the rite is described in enough physical detail that its structure can be read rather than assumed.

**The substance.** Oil, *shemen*. For the sanctuary and the priesthood the corpus specifies a compounded oil at Exodus 30:22-33: myrrh, sweet cinnamon, sweet calamus, cassia, and olive oil, in stated weights, compounded *maʿaseh roqeaḥ*, the work of a perfumer. It is called *shemen mishḥat qodesh*, holy anointing oil, and its replication for common use is prohibited on pain of being cut off, at 30:32-33. For the royal anointings the corpus does not specify the composition and refers simply to oil.

**The vessel.** Two are named and the difference has been noticed since antiquity. Saul is anointed from *pakh ha-shemen*, a flask or vial, at 1 Samuel 10:1. David is anointed from *qeren ha-shemen*, a horn of oil, at 16:13. Solomon from *ha-qeren shemen* at 1 Kings 1:39. Jehu from *pakh ha-shemen* at 2 Kings 9:1 and 9:3. The pattern, flask for Saul and Jehu, horn for David and Solomon, is suggestive and this book does not build on it, since two instances on each side is thin.

**The gesture.** *Wa-yiṣoq ʿal roʾsho*, and he poured on his head, at 1 Samuel 10:1. *Wa-yimshaḥ ʾoto be-qerev ʾeḥaw*, and he anointed him in the midst of his brothers, at 16:13. The oil goes on the head and the corpus says so where it says anything.

**The officiant.** Always another. Chapter 63 counted seven anointings and seven officiants. The categories are: a prophet (Samuel for Saul and David, a prophet's servant for Jehu), a priest with a prophet (Zadok and Nathan for Solomon), a priest (Jehoiada for Joash), and a body of men (the men of Judah and the elders of Israel for David, twice more).

**The accompanying acts.** At 1 Samuel 10:1 Samuel kisses Saul and states the reason: *ha-loʾ ki meshaḥakha YHWH ʿal naḥalato le-nagid*, has not the LORD anointed you prince over his inheritance? Note the two possessives: the LORD anoints, and the people are *naḥalato*, his inheritance. At 1 Kings 1:39-40 the trumpet is blown and the people say *yeḥi ha-melekh Shelomoh*, long live king Solomon, with piping and rejoicing so that the earth split with the sound. At 2 Kings 11:12 Jehoiada brings out the king's son, puts the crown on him and gives him *ha-ʿedut*, the testimony, then they anoint him and clap and say long live the king.

That last detail repays attention. **Joash receives the crown and the testimony before the anointing.** *Ha-ʿedut* is most naturally a document, the covenant or law-book, and Deuteronomy 17:18's copying requirement stands behind it. The corpus's most fully described coronation puts a text into the king's hands as part of the installation.

**What the rite does not include.** No self-application anywhere. No acquisition of the oil by the anointed. No statement that the anointing confers anything the anointed then owns. And no instance of a king anointing his own successor: Solomon is anointed at David's instruction but by Zadok and Nathan, which is the closest the corpus comes and is not the thing itself.

Two structural results carry into the rest of Book VII.

**Anointing is applied, not assumed.** The whole vocabulary of the rite is one of application by an agent to a recipient.

**The rite is not exclusively royal**, and this matters for the census of Chapter 78. Priests are anointed. The tabernacle and its vessels are anointed. Elisha is to be anointed prophet. And a foreign king is to be anointed, which is the item that most resists tidy accounts.

## 65. Aaron and the Priestly Anointing


The corpus's first anointing of a person is priestly, not royal, and it is worth having in view before the kings because it establishes the vocabulary the royal narratives inherit.

**Exodus 29:7.** *We-laqaḥta ʾet shemen ha-mishḥah we-yaṣaqta ʿal roʾsho u-mashaḥta ʾoto.* And you shall take the anointing oil and pour it on his head and anoint him. Addressed to Moses, concerning Aaron. The verbs are take, pour, anoint, in that order, and the same sequence appears at 1 Samuel 10:1 for Saul.

**Leviticus 8:12.** The execution. *Wa-yiṣoq mi-shemen ha-mishḥah ʿal roʾsh ʾAharon wa-yimshaḥ ʾoto le-qaddesho.* And he poured of the anointing oil on Aaron's head and anointed him to sanctify him. The purpose is stated: *le-qaddesho*, to sanctify him, which is a setting-apart rather than an empowering.

**Exodus 30:30 and Leviticus 8:30 extend it to the sons**, and Exodus 40:15 makes it perpetual: *we-haytah li-hyot lahem moshḥatam li-khehunnat ʿolam le-dorotam*, and their anointing shall be to them for a perpetual priesthood throughout their generations.

**And the objects are anointed too.** Exodus 40:9-11: the tabernacle and all in it, the altar of burnt offering and all its vessels, the laver and its base. Leviticus 8:10-11 executes it. The same verb, the same oil, applied to furniture.

Three consequences for the argument.

**The rite sanctifies rather than empowers.** The stated purpose at Leviticus 8:12 is *le-qaddesho*. Nothing in the priestly anointing texts says the oil confers ability, authority in itself, or status independent of the office it inducts into. It marks a transfer into a category.

**A rite applicable to furniture is not a rite that constitutes a personal quality.** This observation is sometimes taken as diminishing and it is not meant so. It is a fact about the semantics of the operation: whatever anointing does, the corpus does it to a laver. The anointed thing becomes the sanctuary's, and the anointed man becomes the sanctuary's, and in neither case does the anointing describe an intrinsic property.

**The priestly anointing is prior in the corpus's own order.** Exodus and Leviticus precede Samuel in the canonical arrangement and in every account of composition. When Samuel pours oil on Saul's head, the corpus has already established what that operation means, and it means induction by another into a service that is not one's own.

One further site closes the chapter and it is the one that keeps the priestly anointing from being merely background. **Leviticus 4:3, 4:5, 4:16, and 6:15 all use the phrase *ha-kohen ha-mashiaḥ*, the anointed priest.** Four occurrences of *mashiaḥ* as a title, in the Torah, all of them priestly, all of them before any king exists. Chapter 78's census has to reckon with that, and the tradition's later concentration of the term on a royal figure is a narrowing the corpus itself does not perform.

## 66. Saul · The First and the Rejected


Saul is the corpus's first anointed king and the account of him is structured around receiving and losing.

**The anointing.** 1 Samuel 10:1. *Wa-yiqqaḥ Shemuʾel ʾet pakh ha-shemen wa-yiṣoq ʿal roʾsho wa-yishaqehu wa-yoʾmer, ha-loʾ ki meshaḥakha YHWH ʿal naḥalato le-nagid.* Samuel took the flask of oil and poured it on his head and kissed him and said: has not the LORD anointed you prince over his inheritance?

Three things in the sentence. The subject of the anointing is stated as YHWH even though the hand is Samuel's. The title is *nagid*, prince or designate, not *melekh*. And the people are *naḥalato*, his inheritance, with the possessive on God.

**The signs that follow are received rather than performed.** 10:5-6: you will meet a band of prophets, *we-ṣalḥah ʿaleykha ruaḥ YHWH we-hitnabbita ʿimmam we-nehpakhta le-ʾish ʾaḥer*, and the spirit of the LORD will rush upon you and you will prophesy with them and be turned into another man. The verbs describing Saul are all things that happen to him: the spirit rushes, he is turned. 10:9 confirms it: *wa-yahafokh lo ʾelohim lev ʾaḥer*, God turned him another heart.

**The public presentation is by lot and Saul is hiding.** 10:20-22. The lot falls on Benjamin, then on the family of Matri, then on Saul, and he cannot be found. They inquire of the LORD and the answer is *hinneh huʾ neḥbaʾ ʾel ha-kelim*, behold he is hidden among the baggage. They run and fetch him.

**The rejection is stated twice and in the same verb as 1 Samuel 8:7.** 15:23: *yaʿan maʾasta ʾet devar YHWH wa-yimʾaskha mi-melekh.* Because you have rejected the word of the LORD, he has rejected you from being king. And 15:26: *ki maʾastah ʾet devar YHWH wa-yimʾaskha YHWH mi-hyot melekh ʿal Yisraʾel.*

The verb *mʾs* on both sides. At 8:7 the people rejected God from reigning. At 15:23 Saul rejects the word and is rejected from reigning. The corpus uses one verb for both movements and constructs the second as an answer to the first.

**And the tearing.** 15:27-28. Saul seizes the skirt of Samuel's robe and it tears, and Samuel says *qaraʿ YHWH ʾet mamlekhut Yisraʾel me-ʿaleykha ha-yom u-netanah le-reʿakha ha-ṭov mimmekka.* The LORD has torn the kingdom of Israel from you today and given it to your neighbour who is better than you. Torn from, given to. Both verbs with God as subject.

**The spirit departs and another comes.** 16:14: *we-ruaḥ YHWH sarah me-ʿim Shaʾul u-viʿatattu ruaḥ raʿah me-ʾet YHWH.* The spirit of the LORD departed from Saul and an evil spirit from the LORD terrified him. The verse is theologically difficult and this book does not attempt it. What it records grammatically is a departure and an arrival, neither of them Saul's act.

**And yet the title holds after the rejection.** This is the fact that most complicates any tidy account and the corpus insists on it. David refuses twice to strike Saul, and both refusals are stated in the anointing vocabulary. 1 Samuel 24:7: *ḥalilah li me-YHWH ʾim ʾeʿeseh ʾet ha-davar ha-zeh la-ʾadoni li-meshiaḥ YHWH.* Far be it from me to do this thing to my lord, the anointed of the LORD. And 26:9: *ki mi shalaḥ yado bi-meshiaḥ YHWH we-niqqah.* Who can stretch out his hand against the LORD's anointed and be guiltless? And 26:11 and 26:23, and 2 Samuel 1:14 and 1:16, where David executes the Amalekite who claimed to have killed Saul, on that ground.

Seven occurrences of *meshiaḥ YHWH* applied to a king the corpus has already said was rejected. The title survives the rejection of the man, which is exactly the distinction 2 Samuel 7:15 will make in the other direction, and Chapter 74 counts it.

## 67. David · Anointed Three Times


David is anointed three times in the corpus and the three are by different parties for different constituencies, which is a fact usually flattened into one event.

**First, by Samuel, privately, at Bethlehem.** 1 Samuel 16:13. *Wa-yiqqaḥ Shemuʾel ʾet qeren ha-shemen wa-yimshaḥ ʾoto be-qerev ʾeḥaw, wa-tiṣlaḥ ruaḥ YHWH ʾel Dawid me-ha-yom ha-huʾ wa-maʿlah.* Samuel took the horn of oil and anointed him in the midst of his brothers, and the spirit of the LORD rushed upon David from that day forward.

The setting is a domestic sacrifice, the audience is his family, and the narrative has spent the preceding six verses on the rejection of his seven brothers, with 16:7's *ki ha-ʾadam yirʾeh la-ʿeynayim wa-YHWH yirʾeh la-levav*, man looks at the eyes and the LORD looks at the heart. The organ of Book IV appears here as the divine faculty of selection.

**Second, by the men of Judah, at Hebron.** 2 Samuel 2:4. *Wa-yavoʾu ʾanshey Yehudah wa-yimshehu sham ʾet Dawid le-melekh ʿal beyt Yehudah.* The men of Judah came and anointed David there king over the house of Judah. Seven years and six months, over one tribe.

**Third, by the elders of all Israel, at Hebron.** 2 Samuel 5:3. *Wa-yavoʾu kol ziqney Yisraʾel ʾel ha-melekh Ḥevronah wa-yikhrot lahem ha-melekh Dawid berit be-Ḥevron lifney YHWH, wa-yimshehu ʾet Dawid le-melekh ʿal Yisraʾel.* The elders came, the king made a covenant with them before the LORD, and they anointed David king over Israel.

**Three observations on the three.**

**Two of the three are performed by bodies of men, not by a prophet.** The tribal and national anointings are corporate acts, and the third involves a covenant cut between the king and the elders. That is a constitutional arrangement and the corpus records it without comment.

**The first is prophetic and the spirit follows it.** *Wa-tiṣlaḥ ruaḥ YHWH ʾel Dawid.* The same verb *ṣlḥ* as at Saul's 10:6 and 10:10. Whatever the corpus takes the anointing to accomplish, it associates the spirit's arrival with the prophetic one and not with the corporate ones.

**And the corpus states the reason for the northern accession in the vocabulary of Book VI.** 2 Samuel 5:2, the elders speaking: *wa-yoʾmer YHWH lekha ʾattah tirʿeh ʾet ʿammi ʾet Yisraʾel we-ʾattah tihyeh le-nagid ʿal Yisraʾel.* The LORD said to you: you shall shepherd my people Israel, and you shall be *nagid* over Israel.

*ʿAmmi*, my people, with the possessive on God, in the mouth of the men who are about to make David king. And the title in the divine speech is *nagid* rather than *melekh*, though the anointing in the next verse is *le-melekh*. The corpus places the two titles one verse apart with the higher one in the human act and the lower one in the divine speech.

**Psalm 23 belongs here.** *YHWH roʿi loʾ ʾeḥsar.* The LORD is my shepherd, I shall not want. The superscription attributes it to David; the corpus makes the king a sheep in the psalm the tradition most closely associates with him. And 2 Samuel 5:2 has appointed the same man shepherd over God's flock. Both statements stand and Book X counts the pair.

**One further site, and it is the one that shows the corpus applying its own standard to David.** 2 Samuel 12:7-9, Nathan's indictment. *ʾAnokhi meshaḥtikha le-melekh ʿal Yisraʾel we-ʾanokhi hiṣṣaltikha mi-yad Shaʾul, wa-ʾettenah lekha ʾet beyt ʾadoneykha we-ʾet neshey ʾadoneykha be-ḥeyqekha wa-ʾettenah lekha ʾet beyt Yisraʾel wi-Yhudah, we-ʾim meʿaṭ we-ʾosifah lekha ka-hennah we-kha-hennah.*

I anointed you king over Israel and I delivered you from the hand of Saul, and I gave you your master's house and your master's wives into your bosom and I gave you the house of Israel and Judah, and if that were too little I would have added to you this and that.

Five first-person verbs of giving in one sentence, listing everything the king holds. And then the charge at 12:9: *maddua baziita ʾet devar YHWH la-ʿasot ha-raʿ be-ʿeynay*, why have you despised the word of the LORD to do evil in my sight. The indictment is constructed as an inventory of gifts followed by the charge, which is the form of a suzerain's lawsuit against a vassal.

## 68. Solomon · The Man of Rest Who Was Not


Solomon is the only figure in the corpus named for the terminus and the corpus records both the naming and the end.

**The designation.** 1 Chronicles 22:9, worked at Chapter 27. A man of rest, God giving him rest, the name explaining it, peace and quiet to Israel in his days.

**The anointing.** 1 Kings 1:39. Zadok takes the horn of oil from the tent and anoints him; the trumpet is blown; the people say long live king Solomon. The setting is a coup countered: Adonijah has already declared himself at En-rogel with Joab and Abiathar, and Solomon's accession is engineered by Nathan and Bathsheba while David is old and cold in his bed. The corpus's most exalted king is installed in a palace intrigue and the corpus narrates it in detail.

**The seating, in the Chronicler's terms.** 1 Chronicles 29:23, worked at Chapter 53. He sat on the throne of the LORD.

**The request.** 1 Kings 3:5-12. At Gibeon God appears in a dream: ask what I shall give you. Solomon's answer is 3:7-9: *ʾanokhi naʿar qaṭon loʾ ʾedaʿ ṣeʾt wa-voʾ*, I am a little child, I do not know how to go out or come in, and the request is *lev shomeaʿ li-shpoṭ ʾet ʿammekha*, a hearing heart to judge your people.

Two of Book IV's three organs in one phrase, requested rather than possessed. And *ʿammekha*, your people, with the possessive again on God, in the king's own mouth.

**The announcement of the terminus.** 1 Kings 8:56, worked at Chapter 25. Blessed be the LORD who has given rest to his people Israel, spoken at the dedication, with the giver named and the recipient the people.

**The apostasy.** 1 Kings 11:1-8. *We-ha-melekh Shelomoh ʾahav nashim nokhriyyot rabbot*, and king Solomon loved many foreign women, and the list runs Moabite, Ammonite, Edomite, Sidonian, Hittite. 11:2 quotes the prohibition at the point of the breach and Chapter 99 works that. 11:3: seven hundred wives, princesses, and three hundred concubines, *wa-yaṭṭu nashaw ʾet libbo*, and his wives turned away his heart. 11:4: *we-lo hayah levavo shalem ʿim YHWH ʾelohaw ki-levav Dawid ʾaviv*, his heart was not whole with the LORD his God as the heart of David his father.

The heart, four times in four verses.

**The judgment.** 11:11: *yaʿan ʾasher haytah zoʾt ʿimmakh we-loʾ shamarta beriti we-ḥuqqotay ʾasher ṣiwwiti ʿaleykha, qaroaʿ ʾeqraʿ ʾet ha-mamlakhah me-ʿaleykha u-netattiha le-ʿavdekha.* Because this is with you and you have not kept my covenant and my statutes, I will surely tear the kingdom from you and give it to your servant.

*Qaroaʿ ʾeqraʿ ... u-netattiha.* Tear and give. The same pair of verbs as Samuel's words to Saul at 1 Samuel 15:28, in the same order, with the same divine subject. The corpus uses one formula for the loss of the kingdom at both ends of the united monarchy.

**And the mitigation preserves the grant while removing the occupant's holding.** 11:12-13: not in your days, for David your father's sake; and not the whole, one tribe for David's sake and for Jerusalem's. The grant of 2 Samuel 7 holds and the kingdom divides.

The structural point for this book. **The corpus names a man for the terminus, states that God gives it to him, has him announce it in the temple, and then records that he did not remain in it.** The three statements are not in tension if the terminus is a state, since a state can be occupied and departed. They are in flat contradiction if it is a possession. Chapter 36's mechanism, the heart lifted and the forgetting, is the corpus's own account of how the departure happens, and 1 Kings 11:4's *loʾ hayah levavo shalem* is its application to this man.

Deuteronomy 17:17's prohibition, *we-loʾ yarbeh lo nashim we-loʾ yasur levavo*, he shall not multiply wives lest his heart turn aside, is quoted almost verbatim by 1 Kings 11:2-4's account of what happened. The law of the king named the mechanism and the narrative executes it on the corpus's greatest king.

## 69. Jehu · The Anointing That Kills


Jehu is anointed and the anointing is a commission to slaughter. The episode is the corpus's most disturbing use of the rite and it belongs in any honest census.

**The commission.** 2 Kings 9:1-3. Elisha calls one of the sons of the prophets, gives him *pakh ha-shemen ha-zeh*, this flask of oil, and sends him to Ramoth-gilead. Find Jehu, take him into an inner chamber, pour the oil on his head and say: *koh ʾamar YHWH meshaḥtikha le-melekh ʾel Yisraʾel*, thus says the LORD, I have anointed you king over Israel. Then open the door and flee, and do not wait.

**The execution and the expanded charge.** 9:6-10. The young man pours the oil and delivers a longer speech than he was given: *we-hikkitah ʾet beyt ʾAḥʾav ʾadoneykha we-niqqamti demey ʿavaday ha-neviʾim*, and you shall strike the house of Ahab your master, and I will avenge the blood of my servants the prophets. Jezebel is named: dogs shall eat her in the portion of Jezreel and none shall bury her.

**And then he flees**, as instructed, and Jehu's fellow officers ask *maddua baʾ ha-meshuggaʿ ha-zeh ʾeleykha*, why did this madman come to you.

**The slaughter.** Joram shot through the heart between the arms and thrown into Naboth's field, with the corpus recalling Naboth by name at 9:25-26. Ahaziah of Judah pursued and killed. Jezebel thrown from a window, trampled by horses, and eaten by dogs. The seventy sons of Ahab beheaded, their heads sent in baskets and piled in two heaps at the gate of Jezreel. Forty-two kinsmen of Ahaziah killed at the pit of the shearing house. The worshippers of Baal gathered into the temple by a ruse, counted, and killed to a man.

**And the corpus's verdict is double.** 2 Kings 10:30: *wa-yoʾmer YHWH ʾel Yehuʾ, yaʿan ʾasher heṭivota la-ʿasot ha-yashar be-ʿeynay ke-khol ʾasher bi-levavi ʿasita le-veyt ʾAḥʾav, benei reviʿim yeshevu lekha ʿal kisseʾ Yisraʾel.* Because you have done well in doing what is right in my eyes, sons of the fourth generation shall sit on the throne of Israel for you. A four-generation dynastic grant, awarded for the killing.

And 10:31: *we-Yehuʾ loʾ shamar la-lekhet be-torat YHWH ʾelohey Yisraʾel be-khol levavo, loʾ sar me-ʿal ḥaṭṭoʾt Yarovʿam.* But Jehu did not take heed to walk in the law of the LORD with all his heart; he did not depart from the sins of Jeroboam.

Approval for the act and condemnation for the reign, in two consecutive verses.

**And then Hosea 1:4**, generations later: *u-faqadti ʾet demey Yizreʿel ʿal beyt Yehuʾ*, I will visit the blood of Jezreel upon the house of Jehu. The corpus condemns the bloodshed it had commissioned, in a different book, without reconciling the two.

Book X counts this among its retained pairs. What Book VII takes from it is narrower and it is three things.

**The anointing is a sending.** The oil is poured and a commission is delivered in the same act, and the commission is entirely a set of instructions.

**The officiant is the least of the parties.** Not Elisha but *ʾaḥad mi-benei ha-neviʾim*, one of the sons of the prophets, a man whose name the corpus does not give and whom Jehu's colleagues call a madman. The rite does not require rank in the one performing it.

**And the dynastic grant is given for performance, uniquely.** Every other conferral in Book VI is unmotivated in the text or grounded in divine choice. Jehu's four generations are stated as payment, *yaʿan ʾasher heṭivota*, because you have done well. That is the single clearest exception to the pattern of unearned conferral in the corpus, and an honest census reports it rather than passing over it.

## 70. Hazael · An Anointing Outside Israel


*U-mashaḥta ʾet Ḥazaʾel le-melekh ʿal ʾAram.* And you shall anoint Hazael king over Aram.

1 Kings 19:15. It is one clause in a three-clause commission and it is the strangest item in the whole anointing field.

**The setting.** Elijah at Horeb after the flight from Jezebel, in the cave, after the wind and the earthquake and the fire and the *qol demamah daqqah*. He states his complaint twice, identically, and receives a threefold commission at 19:15-16.

*Lekh shuv le-darkekha midbarah Dammaseq, u-vaʾta u-mashaḥta ʾet Ḥazaʾel le-melekh ʿal ʾAram. We-ʾet Yehuʾ ben Nimshi timshaḥ le-melekh ʿal Yisraʾel, we-ʾet ʾElishaʿ ben Shafaṭ mi-ʾAvel Meḥolah timshaḥ le-naviʾ taḥteykha.*

Go, return on your way to the wilderness of Damascus; and when you come, anoint Hazael king over Aram. And Jehu son of Nimshi you shall anoint king over Israel, and Elisha son of Shaphat of Abel-meholah you shall anoint prophet in your place.

**Three anointings in two verses, and they are of three different kinds.** A foreign king. An Israelite usurper. A prophet.

Each is worth a sentence.

**Hazael is king of Aram, Israel's enemy, and the corpus is explicit about what he will do.** 2 Kings 8:12, Elisha weeping before him: *ki yadaʿti ʾet ʾasher taʿaseh li-vney Yisraʾel raʿah, mivṣereyhem teshallaḥ ba-ʾesh u-vaḥureyhem ba-ḥerev taharog we-ʿolaleyhem teraṭṭesh we-haroteyhem tevaqqeaʿ.* Because I know the evil you will do to the children of Israel: their strongholds you will set on fire, their young men you will kill with the sword, their infants you will dash in pieces, and their pregnant women you will rip open.

And Hazael's reply at 8:13 and Elisha's answer: *hiraʾani YHWH ʾotekha melekh ʿal ʾAram*, the LORD has shown me that you will be king over Aram.

**Jehu's anointing is executed by a proxy**, as Chapter 69 described, and not by Elijah.

**Elisha's anointing is prophetic and its execution is a mantle.** 19:19: Elijah passes by and casts his cloak on him. The corpus does not record oil for Elisha, which is a divergence between the instruction and the narration that this book notes and does not resolve.

**Two of the three commissions are not executed by the man commissioned.** Elijah anoints neither Hazael nor Jehu in the narrative; Elisha's word to Hazael at 2 Kings 8 and Elisha's servant's act at 2 Kings 9 do the work. That is a well-known feature of the Elijah-Elisha material and this book takes no position on it.

**What the Hazael clause establishes for the census.** The anointing verb, applied by divine instruction, to a foreign king, over a foreign nation, whose stated function is to devastate Israel. Whatever *mšḥ* means in this corpus, it does not mean membership in Israel, it does not mean piety, and it does not mean benefit to Israel.

That is a hard fact and it constrains every account of the vocabulary, including the one this book is giving. The most it will support is the conclusion Chapter 63 drew from the morphology: the term records that something was applied to the bearer by another. It supports nothing about the bearer's character, allegiance, or destiny. Chapter 71 finds the same conclusion forced by a second foreign figure, in a different book, with the title itself.

## 71. Cyrus · Meshiaḥ at Isaiah 45:1


*Koh ʾamar YHWH li-meshiḥo le-Khoresh ʾasher heḥezaqti vi-mino le-rad le-fanaw goyim u-motney melakhim ʾafatteaḥ, li-ftoaḥ le-fanaw delatayim u-sheʿarim loʾ yissageru.*

Thus says the LORD to his anointed, to Cyrus, whose right hand I have held, to subdue nations before him and to loose the loins of kings, to open before him the two-leaved gates, and the gates shall not be shut.

**The title is applied to a Persian.** *Li-meshiḥo*, to his anointed, with the possessive on God, and the referent named immediately: *le-Khoresh*. This is the only occurrence in the Hebrew Bible of *mashiaḥ* applied to a non-Israelite ruler, and it is applied with the divine possessive.

**The passage is saturated with conferral verbs and every one has God as subject.**

45:1: *heḥezaqti vi-mino*, whose right hand I have held.
45:1: *le-rad le-fanaw goyim*, to subdue nations before him.
45:1: *u-motney melakhim ʾafatteaḥ*, I will loose the loins of kings.
45:2: *ʾani le-faneykha ʾelekh*, I will go before you.
45:2: *wa-hadurim ʾayasher*, and I will level the rough places.
45:2: *daltot neḥushah ʾashabber*, I will break in pieces the doors of bronze.
45:3: *we-natatti lekha ʾoṣrot ḥoshekh*, I will give you the treasures of darkness.

Seven first-person divine verbs in three verses, describing what Cyrus will hold.

**And the reason is stated, twice, and it is not Cyrus.** 45:4: *le-maʿan ʿavdi Yaʿaqov we-Yisraʾel beḥiri, wa-ʾeqraʾ lekha bi-shmekha ʾakhannekha we-loʾ yedaʿtani.* For the sake of my servant Jacob and Israel my chosen, I have called you by your name, I have surnamed you, though you have not known me. And 45:5: *ʾaʾazzerkha we-loʾ yedaʿtani*, I gird you though you have not known me.

*We-loʾ yedaʿtani*, twice. The anointed of the LORD does not know the LORD, and the corpus says so twice in two verses.

**The purpose is stated at 45:6.** *Le-maʿan yedʿu mi-mizraḥ shemesh u-mi-maʿaravah ki ʾefes bilʿaday, ʾani YHWH we-ʾeyn ʿod.* That they may know from the rising of the sun and from the west that there is none besides me; I am the LORD and there is no other.

**Four consequences for the census and for the argument.**

**The title does not require knowledge of the giver.** Stated explicitly, twice.

**The title does not require Israelite identity.** Cyrus is a Persian and the corpus names him.

**The title does not carry an eschatological content in itself.** Isaiah 45 is about a specific historical policy: the return from Babylon and the rebuilding, which 44:28 states in advance, *ha-ʾomer le-Khoresh roʿi we-khol ḥefṣi yashlim, we-le-ʾmor li-Yrushalayim tibbaneh we-heykhal tiwwased*, saying of Cyrus he is my shepherd and shall perform all my pleasure, saying of Jerusalem she shall be built and of the temple your foundation shall be laid.

*Roʿi*, my shepherd, applied to Cyrus at 44:28. Both of the corpus's principal royal metaphors, anointed and shepherd, applied to a foreign king in two adjacent verses.

**And the conferral grammar holds at its purest here.** A man who does not know God is given a right hand held, nations subdued, kings loosed, gates opened, doors broken, and treasures given, and the reason given is somebody else's benefit, and the purpose given is a knowledge that others will have.

This chapter complicates the argument and the complication is left standing. A tidy account of the corpus's messianic vocabulary would prefer Cyrus not to be there. He is there, in the corpus's most exalted prophetic material, holding the title with the divine possessive on it. Any account of *mashiaḥ* has to accommodate him, and the only account that does is the minimal one: the word says something was applied by another, and it says nothing else on its own.

## 72. The Anointed Who Are Not Kings


Chapter 63 noted that the rite is not exclusively royal. This chapter sets out the non-royal field, because the tradition's concentration of *mashiaḥ* on a royal eschatological figure is a narrowing the corpus itself does not perform.

**The anointed priest.** *Ha-kohen ha-mashiaḥ* at Leviticus 4:3, 4:5, 4:16, and 6:15. Four occurrences of the noun as a title, all priestly, all in the Torah. In each case the context is the sin offering: if the anointed priest sins, bringing guilt on the people, he shall bring a bull. The title marks the officiant whose sin has corporate effect.

**The priesthood generally.** Exodus 29:7, Leviticus 8:12 for Aaron; Exodus 30:30 and Leviticus 8:30 for his sons; Exodus 40:15 for the perpetual grant. Numbers 3:3 calls Aaron's sons *ha-kohanim ha-meshuḥim ʾasher milleʾ yadam le-khahen*, the anointed priests whose hand was filled to serve.

**The prophet.** 1 Kings 19:16, Elisha to be anointed *le-naviʾ taḥteykha*, prophet in your place. And Isaiah 61:1: *ruaḥ ʾAdonay YHWH ʿalay yaʿan mashaḥ YHWH ʾoti le-vasser ʿanawim*, the spirit of the Lord GOD is upon me because the LORD has anointed me to bring good news to the poor. The verb here is *mšḥ* and the commission that follows is a set of announcements: liberty to captives, opening to the bound, the year of the LORD's favour, comfort to mourners.

**The patriarchs, in a psalm.** Psalm 105:15, repeated at 1 Chronicles 16:22: *ʾal tigʿu vi-meshiḥay we-li-neviʾay ʾal tareʿu.* Touch not my anointed ones, and do my prophets no harm. The plural, applied to Abraham, Isaac, and Jacob in their wanderings, in a psalm whose preceding verses have them as few in number and sojourners.

That plural is significant and it is often overlooked. **The corpus uses *meshiḥay* in the plural of the patriarchs**, none of whom held any office, none of whom was anointed with oil in any narrative, and none of whom was a king. The term is being used of persons under divine protection.

**The objects.** Exodus 40:9-11 and Leviticus 8:10-11: the tabernacle, its furniture, the altar and its vessels, the laver and its base. Numbers 7:1 records the anointing and sanctifying of the tabernacle, its furniture, the altar, and all its vessels at the completion of the setting up.

**Even a stone.** Genesis 28:18, Jacob at Bethel: *wa-yiqqaḥ ʾet ha-ʾeven ʾasher sam meraʾashotaw wa-yasem ʾotah maṣṣevah wa-yiṣoq shemen ʿal roʾshah.* He took the stone he had put under his head and set it up as a pillar and poured oil on its top. The verb here is *yṣq*, poured, the same verb as at 1 Samuel 10:1, and the phrase *ʿal roʾshah*, on its top or head, is the same as *ʿal roʾsho* for Saul.

**The distribution, summarized.** Kings, priests, at least one prophet by instruction and one by claim, the patriarchs in the plural, the sanctuary and everything in it, and a stone. That is the corpus's field.

Two consequences.

**A term with that distribution cannot carry a technical eschatological sense in the Hebrew Bible.** The later tradition's usage is a development and this book takes no position on whether it is a legitimate one. What it records is that the corpus's own usage is wide, physical, and not restricted to a coming figure.

**And the one thing every member of the field shares is the passive.** A stone does not anoint itself. Neither does a laver, a priest, a prophet, or a king.

## 73. The Kings Who Are Not Anointed


The complement is as informative as the field. Most of Israel's and Judah's kings are never said to be anointed, and the corpus's silences have a pattern.

**Explicitly anointed in the narrative books.** Saul at 1 Samuel 10:1. David at 1 Samuel 16:13, 2 Samuel 2:4, and 2 Samuel 5:3. Absalom, in a report at 2 Samuel 19:11, *wa-ʾAvshalom ʾasher mashaḥnu ʿaleynu met ba-milḥamah*, and Absalom whom we anointed over us is dead in battle. Solomon at 1 Kings 1:39. Jehu at 2 Kings 9:6. Joash at 2 Kings 11:12. Jehoahaz at 2 Kings 23:30, *wa-yimshehu ʾoto wa-yamlikhu ʾoto taḥat ʾaviw*. And Hazael by instruction at 1 Kings 19:15.

**That is the list.** Seven Israelite or Judahite figures across two books covering roughly four centuries and some forty reigns.

Three observations on the pattern.

**Anointing is narrated at discontinuities.** Saul is the first king. David succeeds a rejected house. Absalom usurps. Solomon accedes against a rival claimant. Jehu overthrows a dynasty. Joash is restored after Athaliah. Jehoahaz is chosen by the people of the land over an elder brother, which 2 Kings 23:31 and 23:36 make clear by the ages given. Every anointing in the historical books is at a break in the ordinary succession.

**Ordinary successions are not narrated as anointings.** Rehoboam, Abijah, Asa, Jehoshaphat, Jehoram, Amaziah, Uzziah, Jotham, Ahaz, Hezekiah, Manasseh, Amon, Josiah: the formula is *wa-yimlokh X beno taḥtaw*, and X his son reigned in his place. The corpus is not saying they were not anointed. It is saying that when the succession is uncontested the corpus does not mention it.

**The northern kings are almost entirely unanointed in the text.** Jehu is the exception. Jeroboam receives a torn garment from Ahijah at 1 Kings 11:29-31 with ten pieces, and a dynastic promise at 11:38, but no oil. Baasha, Zimri, Omri, Ahab, and the rest accede by killing or by descent and the corpus records no rite.

**The consequence for the census.** The relation between the anointing rite and the office of king is looser in the corpus than the tradition's usage implies. Anointing is a legitimation performed where legitimation is in question. That is a functional account and it fits every case in the list, including Hazael, whose legitimation was in question in the strongest possible way since he acquired the throne by smothering his predecessor with a wet cloth at 2 Kings 8:15.

One caution. **An argument from silence is weak and this one is offered at that weight.** The corpus's failure to mention anointings at ordinary successions is compatible with their having occurred routinely and not being newsworthy, which is probably the historical truth. The observation is about the corpus's narration, not about the practice.

## 74. The Census of Meshiaḥ · Every Occurrence, Sorted


The noun *mashiaḥ* occurs thirty-nine times in the Hebrew Bible. This chapter sorts them, and the sort is the point.

**Applied to Saul: fifteen occurrences**, all in 1 and 2 Samuel, and the great majority in David's mouth refusing to strike him. 1 Samuel 12:3 and 12:5, Samuel calling on the LORD and his anointed as witnesses to his own accounting. 1 Samuel 24:7 twice, 24:11, 26:9, 26:11, 26:16, 26:23. 2 Samuel 1:14, 1:16. And the group at 2 Samuel 19:22 and 23:1.

**Applied to David or the Davidic king: a substantial group**, including 1 Samuel 16:6, where Samuel sees Eliab and says *ʾakh neged YHWH meshiḥo*, surely the LORD's anointed is before him, and is wrong. 2 Samuel 22:51 and its parallel Psalm 18:51: *ʿoseh ḥesed li-meshiḥo le-Dawid u-le-zarʿo ʿad ʿolam*. Psalm 20:7, Psalm 28:8, Psalm 84:10, Psalm 89:39 and 89:52, Psalm 132:10 and 132:17, Lamentations 4:20, Habakkuk 3:13, 2 Chronicles 6:42.

**Applied to the priest: four**, at Leviticus 4:3, 4:5, 4:16, and 6:15.

**Applied to the patriarchs: two**, Psalm 105:15 and 1 Chronicles 16:22, both plural.

**Applied to Cyrus: one**, Isaiah 45:1.

**Applied to a figure in Daniel: two**, at Daniel 9:25 and 9:26, in a passage whose interpretation is contested at every level and which this book does not enter.

**Applied to the king generally, in the Psalms of lament and in Habakkuk**, where the referent is the reigning king in distress.

Four results from the sort, and each is checkable against a concordance.

**The largest single group is Saul, and Saul is the rejected king.** Fifteen of thirty-nine, and they cluster in narratives about refusing to harm him after his rejection. The corpus's densest use of its central royal title is in service of an argument that a rejected king may not be struck.

**Several occurrences are in laments over the title's failure.** Psalm 89:39: *ʾakh zanaḥta wa-timʾas, hitʿabbarta ʿim meshiḥekha*, but you have cast off and rejected, you have been wroth with your anointed. Psalm 89:52: the enemies reproach the footsteps of your anointed. Lamentations 4:20: *ruaḥ ʾappeynu meshiaḥ YHWH nilkad bi-shḥitotam*, the breath of our nostrils, the anointed of the LORD, was taken in their pits. The title appears at the moments of its greatest failure and the corpus does not withdraw it.

**No occurrence in the Hebrew Bible unambiguously designates a future eschatological deliverer.** That is a strong claim and it is stated with the two qualifications it requires. The Daniel 9 occurrences are contested and could bear such a reading on some interpretations. And the royal psalms have been read eschatologically by many communities for a long time, on grounds this book does not adjudicate. What can be said from the sort is that in every case where the referent is determinable from the immediate context, it is a historical person: Saul, David, a Davidic king, a priest, a patriarch, or Cyrus.

**And every occurrence is a passive participle.** Thirty-nine for thirty-nine. There is no cognate active noun in the corpus for the figure and none was ever formed.

The census's finding, stated once. **The corpus's central royal title names a passive condition, is applied to a rejected king more often than to any other referent, appears in laments over its own failure, is extended to priests and patriarchs and a Persian, and never once in a determinable context designates a coming deliverer.** That is a description of the vocabulary and it is not an argument against anyone's expectation. What it is is the base against which Book VIII's escalation has to be read.

:::book VIII | THE ESCALATION


## 75. The Sequence, and What Ordering It by Content Means


Eight stages are present in the corpus. This chapter states them, states how they are ordered, and states what the ordering is not.

**The eight.**

One, refusal. Judges 8:23.
Two, concession. 1 Samuel 8.
Three, permanence, with withdrawal barred. 2 Samuel 7:12-16, with 7:15.
Four, cosmic vocabulary. Psalm 2:7, Psalm 45:7, Psalm 110:1.
Five, the throne-name. Isaiah 9:5.
Six, regrowth after felling. Isaiah 11:1, from a *gezaʿ*.
Seven, the split into two. Zechariah 4:14, 6:13.
Eight, celestial conferral. Daniel 7:13-14.

**The ordering is by content.** Each stage answers the failure of the one beneath it, in the sense that its additional content is the kind of content that would address the preceding stage's deficiency. Refusal is answered by concession. A concession that can be regretted is answered by permanence. A permanence held by ordinary men is answered by cosmic vocabulary. Cosmic vocabulary attached to a failing dynasty is answered by a throne-name. A throne-name on a felled house is answered by regrowth from the stump. A single office that failed is answered by a split into two. And two offices in a demolished polity are answered by conferral from a court that is not on earth.

**No compositional dating is claimed for it.** This is the disclaimer of Chapter 8 restated at the point where it matters most. The first three stages stand in narrative sequence in the corpus itself: Judges precedes Samuel, and 1 Samuel 8 precedes 2 Samuel 7, on any account. The remaining five are ordered logically and the canonical arrangement is not the compositional order. Isaiah 9 and Isaiah 11 are dated variously across the literature. Zechariah 4 and 6 are securely post-exilic. Daniel 7 is dated by most scholarship to the second century and by some traditions to the sixth. Psalm 2, Psalm 45, and Psalm 110 are contested across a range of several centuries.

A reader who takes the sequence as a chronology has taken more than is offered. The sequence is an argument about content and it would hold if the material were composed in the reverse order.

**What the ordering does establish, if the content-relations hold.** Two things.

**The direction is monotonic.** At no point does a later stage contain less than an earlier one. The figure does not shrink. There is no stage at which the corpus scales back the claim, qualifies the permanence, or replaces a large figure with a small one.

**And the deficit does not move.** This is the finding the sequence exists to display and it is the reason the eight stages are set out at all. Book IV established that the corpus locates the failure at the receiver, in the same three organs, in five texts across three books. Those five texts are distributed across the whole span of the escalation: Deuteronomy 29:3 stands before stage one, Isaiah 6:9-10 stands between stages four and five in canonical position, Jeremiah 6:16 stands with stage six or after it, and Psalm 95:11 is undatable. At no point does the corpus report the deficit shrinking, being addressed, or being met.

**A figure rising against a deficit that does not move.** That is the structure and the rest of Book VIII sets it out stage by stage.

## 76. Stages One to Three · Refusal, Concession, Permanence


The first three stages are the ones the corpus itself sequences, and Book V has worked two of them. This chapter takes the third and states the relation of the three.

**Stage one, refusal.** Judges 8:23. Gideon declines a dynastic offer and grounds the refusal in a claim that the office is occupied. Chapter 42.

**Stage two, concession.** 1 Samuel 8. The demand, the diagnosis, the itemized bill, the exclusion clause, the refusal to hear, the grant. Chapters 44 to 48.

**Stage three, permanence.** 2 Samuel 7:12-16.

*Ki yimleʾu yameykha we-shakhavta ʾet ʾavoteykha, wa-haqimoti ʾet zarʿakha ʾaḥareykha ʾasher yeṣeʾ mi-meʿeykha, wa-hakhinoti ʾet mamlakhto. Huʾ yivneh bayit li-shmi, we-khonanti ʾet kisseʾ mamlakhto ʿad ʿolam.*

When your days are fulfilled and you lie down with your fathers, I will raise up your seed after you who shall come from your body, and I will establish his kingdom. He shall build a house for my name, and I will establish the throne of his kingdom forever.

And 7:16: *we-neʾman beytekha u-mamlakhtekha ʿad ʿolam le-faneykha, kisʾakha yihyeh nakhon ʿad ʿolam.* Your house and your kingdom shall be established forever before you; your throne shall be established forever.

**The escalation between stage two and stage three is total and it is worth measuring.** At 1 Samuel 8 the monarchy is granted under an itemized prosecution with a clause excluding the standard remedy. At 2 Samuel 7 the same institution, in the same books, four chapters and one dynasty later, is made unrevokable forever with the withdrawal barred by name against a precedent.

Nothing in the intervening narrative retracts 1 Samuel 8. Nothing in 2 Samuel 7 acknowledges it. The corpus places the itemized bill and the everlasting grant in one work and does not reconcile them, which is Book X's subject and one of its ten pairs.

**Four verbs of establishment, all with God as subject.** *Wa-haqimoti*, I will raise up. *Wa-hakhinoti*, I will establish. *We-khonanti*, I will establish. And at 7:16 the passives *we-neʾman* and *nakhon*. Five conferral forms in five verses, which Chapter 62 counted.

**The permanence is stated four times in five verses.** *ʿAd ʿolam* at 7:13, at 7:16 twice, and the sense again at 7:15's *loʾ yasur*. The corpus is not stating this once.

**And the discipline clause sits inside it**, at 7:14, which Chapter 59 worked. The permanence is of the grant and the discipline is of the occupant, and one sentence holds both.

**The structural observation for Book VIII.** Stage three does not address anything stage two identified as a problem. 1 Samuel 8 identified a rejection of divine reign, an itemized cost, and a coming outcry that would go unanswered. 2 Samuel 7 makes the granted institution permanent. That is an escalation in magnitude and it is not a response to the stated defect.

A reader may object that stage three is a promise to a particular house and not a general statement about monarchy, and that is correct. It is nonetheless an escalation of the institution's standing: what was conceded under protest to a people is now covenanted forever to a line.

**And Psalm 89 is the corpus's own record of what happened to stage three.** 89:4-5 restates the covenant: *karatti verit li-vḥiri nishbaʿti le-Dawid ʿavdi, ʿad ʿolam ʾakhin zarʿekha u-vaniti le-dor wa-dor kisʾakha.* And 89:20-38 elaborate it at length, with 89:35-36's *loʾ ʾaḥallel beriti u-moṣaʾ sefatay loʾ ʾashanneh, ʾaḥat nishbaʿti ve-qodshi ʾim le-Dawid ʾakhazzev*, I will not profane my covenant nor alter what has gone out of my lips; once I have sworn by my holiness, I will not lie to David.

And then 89:39-46. *ʾAkh zanaḥta wa-timʾas, hitʿabbarta ʿim meshiḥekha. Neʾartah berit ʿavdekha, ḥillalta la-ʾareṣ nizro.* But you have cast off and rejected, you have been wroth with your anointed. You have renounced the covenant of your servant, you have profaned his crown to the ground.

The psalm states the everlasting covenant at maximum strength and then states, in the same psalm, that it has been renounced. And it closes at 89:47-52 with *ʿad mah YHWH tissater la-neṣaḥ*, how long, LORD, will you hide yourself forever, and *ʾayyeh ḥasadeykha ha-rishonim ʾAdonay nishbaʿta le-Dawid be-ʾemunatekha*, where are your former mercies, Lord, which you swore to David.

The corpus preserves the promise and the complaint that it failed, in one composition, unresolved. That is the datum stage four inherits.

## 77. Stage Four · Cosmic Vocabulary in the Royal Psalms


Three psalms carry the fourth stage and each takes the king's language a register higher than the historical books ever do.

**Psalm 2:7.** *Beni ʾattah ʾani ha-yom yelidtikha.* Chapter 60 worked it. Sonship, declared, dated.

**Psalm 110:1.** *Shev li-mini.* Chapter 55 worked it. A seat at the right hand of God.

**Psalm 45:7.** *Kisʾakha ʾelohim ʿolam wa-ʿed, sheveṭ mishor sheveṭ malkhutekha.*

This is the escalation at its sharpest and the verse requires care, because its translation is genuinely contested and the argument must not rest on the contested part.

**The problem.** *Kisʾakha ʾelohim ʿolam wa-ʿed* can be read at least three ways. Your throne, O God, is forever and ever, with *ʾelohim* vocative, addressing the king as *ʾelohim*. Your throne is God, forever and ever, with *ʾelohim* predicative. Your divine throne is forever, taking *ʾelohim* as a genitive of quality. Each has defenders and each has difficulties.

**What is not contested.** The psalm is a royal wedding song. Its superscription is *shir yedidot*, a song of loves, and its content is a marriage: the king's beauty, his sword, his majesty, his ivory palaces, the daughter of Tyre with a gift, the princess in gold of Ophir, the virgins in her train, and the sons who will be princes in all the earth. Whatever *ʾelohim* is doing at verse 7, it is doing it in a wedding poem addressed to a reigning king.

**And what is not contested is the next verse.** 45:8: *ʾahavta ṣedeq wa-tisnaʾ reshaʿ, ʿal ken meshaḥakha ʾelohim ʾeloheykha shemen sasson me-ḥavereykha.*

You have loved righteousness and hated wickedness; therefore God, your God, has anointed you with the oil of gladness above your fellows.

**Four things in that verse and they settle what Book VIII needs.**

*Meshaḥakha*, has anointed you. The verb, with the king as object.

*ʾElohim ʾeloheykha*, God your God. Whatever verse 7 says, verse 8 has the addressee possessing a God, which is not something said of a deity.

*Shemen sasson*, oil of gladness. The substance.

*Me-ḥavereykha*, above your fellows. He has fellows. He is above them and he is of their number.

So the psalm that most nearly addresses a king as *ʾelohim* states in the next verse that God is his God and that he has been anointed above his fellows. The escalation and the conferral are one verse apart, and the conferral is in the unambiguous verse.

**The structural point for the sequence.** Stage four raises the vocabulary to its highest available register: sonship, a seat at the right hand, and a throne addressed with the divine name. And in every one of the three psalms the grammar of Chapter 62 holds. Psalm 2:6-8: I have installed, I have begotten, ask and I will give. Psalm 110:1-4: sit, I will make, the LORD has sworn. Psalm 45:8: God your God has anointed you.

**The magnitude rises and the mode of holding does not move.** That sentence is the whole of Book VIII and stage four is where it first becomes visible, because stage four is the first stage at which a reader would expect the mode to change.

## 78. Stage Five · Isaiah 9:5 and the Throne-Name


*Ki yeled yullad lanu ben nittan lanu, wa-tehi ha-misrah ʿal shikhmo, wa-yiqraʾ shemo peleʾ yoʿeṣ ʾel gibbor ʾavi ʿad sar shalom.*

For a child is born to us, a son is given to us, and the government shall be on his shoulder, and his name is called Wonderful Counsellor, Mighty God, Everlasting Father, Prince of Peace.

**A note on versification.** This is Isaiah 9:5 in the Hebrew and 9:6 in most English versions, as Chapter 5 warned.

**The escalation.** This is the highest name applied to a royal figure in the prophetic corpus. *ʾEl gibbor*, mighty God, is used of God directly at Isaiah 10:21, *sheʾar yashuv sheʾar Yaʿaqov ʾel ʾel gibbor*, and at Jeremiah 32:18. *ʾAvi ʿad*, father of eternity or everlasting father, has no parallel applied to a human anywhere in the corpus.

**And the first two clauses are the passive.** *Yeled yullad lanu*, a child is born to us, pual. *Ben nittan lanu*, a son is given to us, nifal. Two passives in six words, at the opening of the corpus's highest royal name. And the beneficiary in both is *lanu*, to us.

**The government is placed on him.** *Wa-tehi ha-misrah ʿal shikhmo*, the government shall be upon his shoulder. The construction is one of placement: the *misrah* comes to be on him. He does not take it up.

**And the naming is passive too.** *Wa-yiqraʾ shemo*, and his name is called, which can be read as an impersonal active, one calls his name, or as a passive. Either way the naming is not his act.

**Verse 6 states the source explicitly and closes the passage.** *Le-marbeh ha-misrah u-le-shalom ʾeyn qeṣ, ʿal kisseʾ Dawid we-ʿal mamlakhto le-hakhin ʾotah u-le-saʿadah be-mishpaṭ u-vi-ṣdaqah me-ʿattah we-ʿad ʿolam, qinʾat YHWH ṣevaʾot taʿaseh zoʾt.*

Of the increase of the government and of peace there shall be no end, upon the throne of David and upon his kingdom, to establish it and to uphold it with judgment and with righteousness from now and forever. **The zeal of the LORD of hosts will do this.**

*Qinʾat YHWH ṣevaʾot taʿaseh zoʾt.* The zeal of the LORD of hosts will do this. The final clause of the passage names the agent, and it is not the child.

**Two textual and interpretive notes, both carried as open.**

The four names can be read as one long theophoric throne-name of the type attested for Egyptian and Mesopotamian kings, which is a well-established reading and would make the divine elements descriptive of the god who grants rather than of the king. Or they can be read as four titles predicated of the child. This book takes no position and does not need one, because both readings leave the passives at 9:5a and the agent-clause at 9:6b untouched.

The passage's original reference is contested: an accession oracle for Hezekiah, a birth oracle, or a purely future expectation. Again no position is taken.

**The structural point.** Stage five is the highest name in the prophetic corpus and it arrives inside a sentence with two passives, a placement, an impersonal naming, and a closing clause attributing the whole to the zeal of the LORD of hosts. The escalation is maximal and the conferral grammar is unbroken.

## 79. Stage Six · Isaiah 11:1 and the Regrowth


*We-yaṣaʾ ḥoṭer mi-gezaʿ Yishay we-neṣer mi-shorashaw yifreh.*

And a shoot shall come out from the stump of Jesse, and a branch shall grow from his roots.

**The image is regrowth after felling.** *Gezaʿ* is a stump, the cut base of a tree. The word occurs three times in the Hebrew Bible: here, at Isaiah 40:24 where the princes are scarcely planted before their stock takes no root, and at Job 14:8 where the stump dies in the dust. Book IX works the tree at length; here the point is what the image does in the sequence.

**The felling is presupposed and it is not stated as a defeat of the promise.** The oracle does not say the tree will be cut. It begins after the cutting and says a shoot will come from the remains. So stage six is the promise re-issued over the wreckage of the earlier grant, and the wreckage is assumed rather than argued.

**Note the ancestor named.** *Mi-gezaʿ Yishay*, from the stump of Jesse. Not from the stump of David. The oracle goes behind the dynasty to its father, which is a way of starting the line again from before its royal history. That is a deliberate choice and the corpus makes it.

**The equipment is given.** 11:2: *we-naḥah ʿalaw ruaḥ YHWH, ruaḥ ḥokhmah u-vinah, ruaḥ ʿeṣah u-gevurah, ruaḥ daʿat we-yirʾat YHWH.* And the spirit of the LORD shall settle upon him: the spirit of wisdom and understanding, the spirit of counsel and might, the spirit of knowledge and the fear of the LORD.

Three observations. The verb is *nwḥ*, the settling-root, used of a spirit coming down and staying, as Chapter 10 noted. The direction is onto him. And the content is six qualities in three pairs, all of them faculties, and the second pair, counsel and might, is the vocabulary of Isaiah 9:5's *peleʾ yoʿeṣ* and *ʾel gibbor* redistributed as gifts.

**The equipment includes the organ of Book IV.** *Ruaḥ daʿat*, the spirit of knowledge. And 11:3: *wa-hariḥo be-yirʾat YHWH, we-loʾ le-marʾeh ʿeynaw yishpoṭ we-loʾ le-mishmaʿ ʾoznaw yokhiaḥ.* He shall not judge by what his eyes see, nor decide by what his ears hear.

**That is the deficit inventory, applied to the figure, in the negative.** Eyes and ears, the two organs of Isaiah 6:10 and 42:19, named as the faculties by which he will *not* judge. The corpus equips its figure by giving him a spirit of knowledge and then specifying that the two organs it elsewhere reports as defective are not what he will use.

Whatever else is going on there, the corpus is aware of the connection. Isaiah 6:10 shut the eyes and stopped the ears. Isaiah 11:3 has the figure judging by neither.

**And 11:4 supplies the mode of action.** *We-shafaṭ be-ṣedeq dallim we-hokhiaḥ be-mishor le-ʿanwey ʾareṣ, we-hikkah ʾereṣ be-sheveṭ piw u-ve-ruaḥ sefataw yamit rashaʿ.* He shall judge the poor with righteousness and decide with equity for the meek of the earth, and he shall strike the earth with the rod of his mouth and with the breath of his lips slay the wicked.

**And 11:9 closes on an agentless state**, which Chapter 29 worked: the earth full of the knowledge of the LORD as the waters cover the sea.

**The structural point for the sequence.** Stage six is the first stage at which the corpus equips the figure with the faculties whose absence Book IV diagnosed. That is the closest the escalation comes to addressing the actual deficit, and it is worth marking as such rather than passing over. What it does is give the figure the organs the people lack. What it does not do is give the people the organs the people lack.

That distinction is the hinge of Chapter 84 and it is stated here so that it is not read as a rhetorical flourish arriving late. The oracle is explicit: the spirit settles on *him*, singular, throughout 11:2-5. The state at 11:9 is universal. Nothing in the passage supplies the transition from the one to the other, and this book does not claim the corpus owed one.

## 80. Stage Seven · Zechariah and the Split Into Two


*Wa-yoʾmer ʾelleh shenei venei ha-yiṣhar ha-ʿomedim ʿal ʾadon kol ha-ʾareṣ.*

And he said: these are the two sons of oil who stand by the Lord of all the earth. Zechariah 4:14.

**The vision.** A lampstand of gold with a bowl on top, seven lamps, seven pipes, and two olive trees, one on the right of the bowl and one on the left. The prophet asks twice what they are and is answered at 4:14.

**The phrase is unique.** *Benei ha-yiṣhar*, sons of the oil, occurs nowhere else in the Hebrew Bible. *Yiṣhar* is fresh oil, the product word, distinct from *shemen*, the substance word used in the anointing rite. The corpus coins an expression here and does not reuse it.

**Two, and they stand.** *Shenei*, two, and *ha-ʿomedim ʿal ʾadon kol ha-ʾareṣ*, standing by the Lord of all the earth. The posture is attendance.

**The second site.** Zechariah 6:13. *We-huʾ yivneh ʾet heykhal YHWH we-huʾ yissaʾ hod we-yashav u-mashal ʿal kisʾo, we-hayah khohen ʿal kisʾo, wa-ʿaṣat shalom tihyeh beyn shenehem.*

And he shall build the temple of the LORD, and he shall bear majesty and sit and rule upon his throne, and there shall be a priest upon his throne, and a counsel of peace shall be between them both.

**The last clause requires two parties.** *Beyn shenehem*, between them both. A counsel of peace between them both cannot be a description of one person holding two offices, because a counsel between a man and himself is not a counsel.

That reading has to be stated with a correction attached, because this project made the opposite error and the error is on the record. An earlier draft read 6:13 as fusing two offices in one person, which is a common reading and is available on some construals of *we-hayah khohen ʿal kisʾo*. The clause *beyn shenehem* falsified it. The withdrawal is recorded here rather than silently corrected.

**The context supplies the two.** Zechariah 3 is a vision of Joshua the high priest, standing before the angel of the LORD with the accuser at his right hand, in filthy garments which are removed and replaced. Zechariah 4:6-10 is addressed to Zerubbabel: *loʾ ve-ḥayil we-loʾ ve-khoaḥ ki ʾim be-ruḥi*, not by might nor by power but by my spirit, and his hands have laid the foundation and shall finish it. The two figures of the period are a priest and a governor of Davidic descent, and 4:14's two sons of oil are naturally the two.

**And 3:8 introduces the branch.** *Ki hinneni meviʾ ʾet ʿavdi Ṣemaḥ.* Behold I am bringing my servant Branch. With 6:12: *hinneh ʾish Ṣemaḥ shemo u-mi-taḥtaw yiṣmaḥ u-vanah ʾet heykhal YHWH*, behold a man whose name is Branch, and he shall branch out from his place and build the temple of the LORD.

**The structural point.** Stage seven splits the office. Where stages three through six had one figure carrying everything, Zechariah has two standing by the Lord of all the earth with a counsel of peace between them.

Two readings of the split are available and this book takes neither.

On one, the split is a diminishment: the post-exilic community has no king and distributes what a king held between a governor and a priest, and the vision dignifies the arrangement.

On the other, the split is an escalation: one office had failed, so the corpus doubles it, adding the priestly to the royal and thereby covering a function the monarchy had never held. Psalm 110:4's non-Aaronide priesthood stands behind this reading.

**What is not contested is the conferral grammar, which holds here as everywhere.** *Hinneni meviʾ ʾet ʿavdi Ṣemaḥ*, I am bringing my servant Branch, first person divine, at 3:8. *Not by might nor by power but by my spirit* at 4:6. And the crowns of 6:11 are made by the prophet at instruction and set on Joshua's head, then deposited in the temple at 6:14 as a memorial.

## 81. Stage Eight · Daniel 7 and the Passive Yehiv


*Ḥazeh hawet be-ḥezwey leylyaʾ wa-ʾaru ʿim ʿananey shemayyaʾ ke-var ʾenash ʾateh hawah, we-ʿad ʿattiq yomayyaʾ meṭah u-qodamohi haqrevuhi. We-leh yehiv sholṭan wi-qar u-malkhu, we-khol ʿammayyaʾ ʾumayyaʾ we-lishshanayyaʾ leh yifleḥun; sholṭaneh sholṭan ʿalam di laʾ yeʿdeh u-malkhuteh di laʾ titḥabbal.*

I saw in the night visions, and behold, with the clouds of heaven one like a son of man was coming, and he came to the Ancient of Days and they brought him near before him. And to him was given dominion and glory and a kingdom, and all peoples, nations, and languages shall serve him; his dominion is an everlasting dominion which shall not pass away, and his kingdom one which shall not be destroyed.

This is the corpus's highest statement about a figure and it is in Aramaic and its central verb is passive.

**The magnitude.** Everlasting dominion. All peoples, nations, and languages serving. A kingdom that will not be destroyed. Nothing in the Hebrew Bible exceeds this and nothing else approaches it.

**The verb.** *Yehiv*, peʿil, the Aramaic passive. To him was given. No agent is expressed and none is grammatically required, though the context supplies one: the Ancient of Days is the only party in the scene who could give.

**The approach is likewise passive.** *Haqrevuhi*, they brought him near. The figure does not present himself; he is brought.

**And the arrival is stated with a verb of reaching.** *We-ʿad ʿattiq yomayyaʾ meṭah*, and he came to the Ancient of Days. The motion is toward a throne that is already occupied and was described in the preceding verses: 7:9, thrones were placed and the Ancient of Days took his seat, his garment white as snow, the hair of his head like pure wool, his throne flames of fire, its wheels burning fire.

**So the highest conferral in the corpus is a passive verb, in a court scene, before a seated figure, with the recipient brought in by others.**

That is the finding and it should be set against Chapter 62's list. Deuteronomy 17:15 God chooses. 2 Samuel 7:8 I took you. Psalm 2:7 I begot you. Psalm 110:1 sit at my right hand. Psalm 45:8 God your God anointed you. Isaiah 9:5 a son is given. 1 Chronicles 29:23 he sat on the throne of the LORD. Daniel 7:14 to him was given.

**Eight stages, two languages, six books, one grammar.**

**The identification of the figure is contested and this book does not enter it.** Daniel 7:18 has *we-yeqabbelun malkhutaʾ qaddishey ʿelyonin*, the saints of the Most High shall receive the kingdom, and 7:22 and 7:27 repeat it, which supports a collective reading. The individual reading has an equally long history. Note only that 7:18's verb is *yeqabbelun*, they shall receive, which is a verb of reception, so the collective reading preserves the conferral grammar exactly.

**Two further features of the chapter.**

**The four beasts precede.** 7:3-7. The dominion given to the figure follows the destruction of the fourth beast, and 7:12 records that the rest of the beasts had their dominion taken away, *heʿdiw sholṭanhon*, while their lives were prolonged for a season. The corpus places the conferral inside a sequence of dominions given and removed.

**And the court sits and books are opened.** 7:10: *dinaʾ yetiv we-sifrin petiḥu.* Judgment was set and the books were opened. The scene is judicial. Whatever is given at 7:14 is given by a court after a hearing, which is another way of saying it is not seized.

## 82. The Category Substitution, Performed Eight Times


Book VIII has set out the stages. This chapter states what the sequence is doing, and the statement is the book's central claim.

**The problem, as Book IV established it.** The terminus is a state. A state is entered rather than delivered. The corpus locates the failure of entry in the receiver, in three organs, in five texts across three books, and nowhere in a withheld terminus.

**The response, as Book VIII has set it out.** Eight stages of increasing magnitude in the deliverer.

**The mismatch.** No enlargement of the agent addresses a deficiency in the entering.

That sentence is doing all the work and it should be tested rather than asserted, because it is the kind of claim that sounds decisive and can be empty.

**Test it against the stages.** Take each and ask what the additional content does for the deficit.

Stage two, a visible king rather than intermittent judges. Does a visible king supply a heart to know? Nothing in 1 Samuel 8-12 suggests it and 1 Samuel 12:19's confession suggests the opposite.

Stage three, permanence. Does an unrevokable dynasty supply eyes to see? Psalm 89's complaint is that the dynasty failed; the psalm nowhere claims the people's perception was at stake in it.

Stage four, cosmic vocabulary. Does a king addressed as son and seated at the right hand supply ears to hear? Isaiah 6 stands in the same corpus and reports the ears heavy.

Stage five, the throne-name. Does a child named Mighty God supply the organs? Isaiah 6:9-10 is three chapters earlier in the same book.

Stage six, the shoot with the sevenfold spirit. **This one comes closest and Chapter 79 said so.** The figure is given the spirit of knowledge and is said not to judge by what his eyes see or his ears hear. But the equipment is his. The passage supplies no transfer, and Isaiah 11:9's universal knowledge is stated as a state with no agent rather than as his achievement.

Stage seven, the split into two. Does doubling the office address a receiving failure? Zechariah's own audience is addressed at 1:4 with *ʾal tihyu kha-ʾavoteykhem ʾasher qarʾu ʾalehem ha-neviʾim ha-rishonim ... we-loʾ shameʿu we-loʾ hiqshivu ʾelay*, do not be like your fathers to whom the former prophets cried, and they did not hear or listen to me. The deficit is stated in the same book as stage seven, in its opening oracle.

Stage eight, everlasting dominion conferred in a heavenly court. Does dominion given to a figure supply a heart to a people? Nothing in Daniel 7 addresses the question and nothing claims to.

**Seven of the eight do not touch the deficit at all, and the eighth equips the figure rather than the receiver.**

**The claim, stated at its exact strength.** The sequence is not a development toward an answer. It is the same category substitution performed eight times at rising magnitude: a delivery solution offered to an entry problem.

**Two qualifications.**

**The corpus does address the receiver, elsewhere, and in the act-layer.** Deuteronomy 30:6: *u-mal YHWH ʾeloheykha ʾet levavekha we-ʾet levav zarʿekha le-ʾahavah ʾet YHWH ʾeloheykha be-khol levavkha*, and the LORD your God will circumcise your heart and the heart of your seed. Jeremiah 31:33: *natatti ʾet torati be-qirbam we-ʿal libbam ʾekhtavennah*, I will put my law within them and write it on their hearts. Ezekiel 36:26: *we-natatti lakhem lev ḥadash we-ruaḥ ḥadashah ʾetten be-qirbekhem*, I will give you a new heart and a new spirit I will put within you.

**Those three are the corpus's actual answer to the deficit and none of them contains a figure.** Deuteronomy 30:6 has God as subject and the people as object. Jeremiah 31:31-34 has God as subject throughout and closes at 31:34 with *ki khullam yedʿu ʾoti le-miq-qaṭannam we-ʿad gedolam*, for they shall all know me from the least to the greatest, with no intermediary in the clause. Ezekiel 36:26-27 has God as subject and specifies the mechanism: a new heart, a heart of flesh for a heart of stone, and my spirit within you.

That is the strongest result Book VIII produces and it was not sought. **Where the corpus addresses the deficit directly, it does so with God as subject and no figure in the clause.** Where it escalates a figure, it does not address the deficit. Two vocabularies, two grammars, and they do not overlap.

**And this book does not claim the corpus intended the contrast.** It records that the contrast is there and is checkable at named verses.

## 83. What the Escalation Is Not


Four readings of the sequence are available and this book rejects three of them for stated reasons. Setting them out is a way of stating what the fourth claims.

**It is not evidence that the royal material is late.** The sequence is ordered by content and Chapter 75 said so. Several of its stages are dated early by good scholarship. A content-ordering is compatible with any chronology, including one in which the highest stages are the oldest.

**It is not evidence that the royal material is inauthentic, secondary, or an intrusion.** A means is not less real than a destination, and the corpus's own most sustained compositions are about the means. A reader who takes Book VIII as a demotion of Isaiah 11 or Daniel 7 has taken a sort for a ranking, which Chapter 4 warned about and Chapter 103 warns about again.

**It is not evidence that the expectation is mistaken.** Chapter 6's limit case stated why. If a figure of the expected kind arrives, every stage of the escalation is vindicated and every claim in this book stands unchanged, because the claim is about what the corpus's escalation does relative to a deficit it names separately, and an arrival does not alter that relation.

**What it is.** A structural observation about the corpus's own arrangement, and it has two parts.

**The figure grows monotonically.** From a man anointed with a flask of oil who hides among the baggage, to a dynastic guarantee, to a king addressed as son and seated at a right hand, to a child named Mighty God, to a shoot from a felled stump carrying a sevenfold spirit, to two figures standing by the Lord of all the earth, to one like a son of man receiving everlasting dominion from a court in the clouds.

**And the deficit does not move.** Deuteronomy 29:3's heart, eyes, and ears. Isaiah 6:10's heart, ears, and eyes. Isaiah 42:19's blind servant and deaf messenger. Jeremiah 5:21's eyes that do not see. Ezekiel 12:2's eyes to see that have not seen. Psalm 95's hardened heart. Jeremiah 6:16's we will not walk. Same organs, same vocabulary, distributed across the whole span, never reported as addressed.

**Two shapes, one corpus, and the corpus states both without comment.** That is the observation. Everything else in Book VIII is the evidence for it.

## 84. The One Stage That Aims at the Deficit, and What It Shows


Chapter 82 named stage six as the closest approach and this chapter takes it alone, because the exception is more instructive than the rule.

Isaiah 11:2-3 equips the figure with a spirit of knowledge and specifies that he will not judge by what his eyes see or what his ears hear. That is the deficit inventory addressed, in the corpus's own vocabulary, in the middle of a messianic oracle.

**Three features of the equipment.**

**It is a settling.** *We-naḥah ʿalaw*, and it shall settle upon him, using *nwḥ*. The terminus root, applied to a spirit coming to rest on a person. The corpus uses the vocabulary of arriving-and-staying for the equipping.

**It is sixfold or sevenfold depending on the count.** Wisdom, understanding, counsel, might, knowledge, and the fear of the LORD, in three pairs, with *ruaḥ YHWH* standing at the head as either a seventh or a summary.

**And its content is faculties, not powers.** Every item is a mode of knowing or a disposition. There is no strength, no longevity, no invulnerability, no throne. The corpus equips its figure with the capacity Book IV said the people lacked.

**Now the question the chapter exists to ask.** Does the equipping transfer?

Read 11:2-5 and the answer is that the passage is entirely singular. *ʿAlaw*, upon him. *Wa-hariḥo*, and his delight. *Yishpoṭ*, he shall judge. *Yokhiaḥ*, he shall decide. *We-hikkah*, and he shall strike. *Yamit*, he shall slay. *We-hayah ṣedeq ʾezor motnaw*, righteousness shall be the belt of his loins. Every verb and every suffix is third masculine singular.

Read 11:6-8 and the subject changes to the animals: wolf and lamb, leopard and kid, calf and lion, cow and bear, lion eating straw, the nursing child at the hole of the asp.

Read 11:9 and the subject is the earth: *maleʾah ha-ʾareṣ deʿah ʾet YHWH*.

**The passage moves from a singular equipped figure to a universal state and supplies no clause connecting them.** There is no *le-maʿan*, no purpose clause, no consequence formula, no statement that he teaches, imparts, opens, or gives. The *ki* at 11:9b is causal for the not-hurting, and Chapter 29 discussed how far it reaches.

**Two honest readings of that gap.**

**The gap is not a defect.** Prophetic poetry moves between registers without connective tissue as a matter of course, and demanding a transfer clause is demanding a genre the passage is not.

**And the gap is a datum.** Whatever the genre, the corpus had available the vocabulary for a transfer and used it elsewhere: Deuteronomy 30:6 circumcises the heart, Jeremiah 31:33 writes on it, Ezekiel 36:26 replaces it. In each of those, God is the subject. In Isaiah 11, where the figure stands, no transfer is stated in either direction.

**The result.** The one stage that aims at the deficit equips the figure and stops there. The three passages that supply the deficit's remedy contain no figure. The two vocabularies do not meet anywhere in the corpus.

That is the sharpest form of Book VIII's finding and it is stated here rather than at the book's opening because it requires all eight stages to be visible before it can be checked. A reader who wants to break it should look for a passage in which a figure gives a heart, opens an ear, or supplies knowledge to a people. This book has not found one and does not claim none exists.

:::book IX | THE TREE


## 85. Job 14:7-9 · Three Parts, Three Rulings


The corpus divides the felled tree into three parts and rules on each in three successive clauses, and the ruling is in a book nobody reads for messianic material.

*Ki yesh la-ʿeṣ tiqwah, ʾim yikkaret ʿod yaḥalif we-yonaqto loʾ teḥdal. ʾIm yazqin ba-ʾareṣ shorsho u-ve-ʿafar yamut gizʿo. Me-reaḥ mayim yafriaḥ we-ʿasah qaṣir kemo naṭaʿ.*

For there is hope for a tree: if it is cut down it will sprout again, and its shoot will not cease. Though its root grows old in the earth and its stump dies in the dust, at the scent of water it will bud and put out branches like a plant.

**Clause one: the tree has hope.** *Yesh la-ʿeṣ tiqwah.* Stated as a general proposition about trees, in a speech whose whole burden is that man has no such hope: 14:10 continues *we-gever yamut wa-yeḥelash, wa-yigwaʿ ʾadam we-ʾayyo*, but man dies and is laid low; man breathes his last, and where is he? The tree-image in Job is a contrast, not a promise.

**Clause two divides the underground parts and rules on each separately.** *ʾIm yazqin ba-ʾareṣ shorsho*, though its root grow old in the earth. *U-ve-ʿafar yamut gizʿo*, and its stump die in the dust.

**The root persists. The stump dies.** Two nouns, two verbs, in one verse, distinguished.

**Clause three names the trigger.** *Me-reaḥ mayim yafriaḥ*, at the scent of water it buds. The verb *rwḥ* in this form is a hapax construction and the sense is a perceiving of moisture. What revives the tree is not planting, watering, or tending. It is the presence of water already in the ground, detected.

Three observations, each of which the next chapters develop.

**The corpus has ruled on the stump and the ruling is that it dies.** That is a statement in the corpus's own words, in a wisdom book, about the part of a felled tree named *gezaʿ*.

**The corpus has ruled on the root and the ruling is that it persists.** *Shoresh*, root, growing old in the earth but not said to die.

**And the trigger is a presence rather than an arrival.** The water is already there. The tree does not receive it; it detects it. Chapter 87 works that.

One methodological note. Job is speaking in a lament and the passage is an argument for human hopelessness by contrast with vegetable resilience. Reading it as botanical doctrine would be reading a lament as a treatise. What this book takes from it is narrower: the corpus, at some point, in some register, distinguished the fate of a stump from the fate of a root, and used the words *gezaʿ* and *shoresh* to do it. That distinction is available to the corpus and Isaiah 11:1 uses both nouns in one verse.

## 86. The Stump Dies in the Dust


*U-ve-ʿafar yamut gizʿo.*

The word *gezaʿ* occurs three times in the Hebrew Bible and this chapter takes all three, because a three-occurrence word can be surveyed completely.

**Job 14:8.** The stump dies in the dust.

**Isaiah 40:24.** *ʾAf bal niṭṭaʿu ʾaf bal zoraʿu ʾaf bal shoresh ba-ʾareṣ gizʿam, we-gam nashaf bahem wa-yivashu u-seʿarah ka-qash tissaʾem.* Scarcely are they planted, scarcely sown, scarcely has their stock taken root in the earth, when he blows on them and they wither and the storm carries them away like stubble. The subject is the princes and judges of the earth at 40:23, whom God brings to nothing. The *gezaʿ* here is the stock that fails to root.

**Isaiah 11:1.** *We-yaṣaʾ ḥoṭer mi-gezaʿ Yishay.* A shoot shall come out from the stump of Jesse.

**Three occurrences. Two of them state the stock's failure and one states a shoot coming from it.**

That is the tension and this book neither resolves it nor treats it as a fatal problem for anyone's reading. Three observations frame it.

**The two negative sites are not about the same object as Isaiah 11.** Job 14 is a general proposition about felled trees. Isaiah 40:24 is about the princes of the earth. Isaiah 11:1 is about the house of Jesse. A word can behave differently in three contexts and usually does.

**But the vocabulary is the corpus's own and it is narrow.** Three occurrences is a small enough field that the corpus's usage can be surveyed, and what the survey shows is that in two of three the *gezaʿ* is the part that does not carry on.

**And Isaiah 11:1 names a second source in its second half.** *We-neṣer mi-shorashaw yifreh*, and a branch from his roots shall grow. Stump in the first colon, roots in the second. Chapter 88 takes that up and it is the chapter this book most expects to be disagreed with.

Two further terms belong in the field and are worth distinguishing so that they are not conflated.

**Maṣṣevet**, at Isaiah 6:13, which Chapter 89 works. A different noun, usually taken as the stump or the standing part of a felled tree, and used in the corpus's other passage about a cut tree with a surviving element.

**Geza and gezaʿ are not to be confused with *shoresh*, root, which is common** and appears throughout in both literal and figurative senses: the root of the righteous at Proverbs 12:12, the root of Jesse at Isaiah 11:10, roots dried up at Hosea 9:16, and the root and branch formula at Malachi 3:19.

The point of the survey is not to settle Isaiah 11:1's botany. It is to establish that the corpus has a specific and small vocabulary for the parts of a felled tree, that it uses that vocabulary with some care, and that it says different things about different parts.

## 87. The Root Persists, and the Trigger Is Water Already There


Job 14:8-9 rules that the root grows old in the earth without dying and that the trigger for regrowth is *reaḥ mayim*, the scent of water.

Both halves of that repay attention because both are counter-intuitive.

**The root's persistence is stated as endurance rather than as vitality.** *ʾIm yazqin ba-ʾareṣ shorsho*, though its root grow old in the earth. The verb is *zqn*, to age. The root is not described as vigorous, hidden, or protected. It is described as old. What it does is remain.

**The trigger is detection, not supply.** *Me-reaḥ mayim yafriaḥ.* At the scent of water it buds. The preposition *min* is causal here: from, or on account of, the scent. Water in the ground is perceived and the perception is sufficient.

**Nothing arrives.** No rain is mentioned. No planter waters it. No agent acts on the stump. The water is present and the tree responds to its presence.

Three connections to the argument of this book, each offered at its own weight.

**The strongest is structural and it is offered as an image rather than as an argument.** Book III established that the terminus is a state, present and unentered. Book IV established that the corpus locates the failure in a receiving faculty. Job 14:9 supplies a picture of exactly that arrangement: a resource already in the ground, a perception of it, and a response. Whether Job intended any such connection is unknowable and this book does not claim it. The picture is in the corpus and it is the corpus's own.

**The second is lexical and it is checkable.** The verb behind *reaḥ* is the same root as *wa-hariḥo be-yirʾat YHWH* at Isaiah 11:3, usually rendered his delight shall be in the fear of the LORD and literally something like his smelling. The corpus uses a scent-verb for the equipped figure's mode of discernment and for the felled tree's mode of detecting water. Two sites, one unusual verb, both about perceiving something not seen. This book records the coincidence and builds nothing on it, since two occurrences of a rare verb in two genres is thin evidence for anything.

**The third is negative and it is a fence.** Job 14 is a lament and the tree is a contrast to man. Building a doctrine of resurrection or of national restoration on it would be reading against its argument. This book takes the botany and leaves the polemic.

One further observation about the direction of the passage. Job's point is that the tree has what man lacks. If the tree-image is then applied to Israel, as Isaiah 11 applies a related image to Jesse's house, the application is a claim that the nation has what an individual does not. Whether the corpus intends that is unknown. That the two passages use overlapping vocabulary about a cut tree is a fact.

## 88. Isaiah 11:1 · Two Sources, One Verse, Unreconciled


*We-yaṣaʾ ḥoṭer mi-gezaʿ Yishay we-neṣer mi-shorashaw yifreh.*

This chapter makes the observation this book most expects to be contested, and states the objection to it as clearly as the observation.

**The verse names two sources in two cola.** A shoot from the stump. A branch from the roots. *Gezaʿ* and *shorashaw*. Two different nouns for two different parts of a tree.

**And Job 14:8 has ruled on both, distinguishing them.** The root grows old and persists. The stump dies in the dust.

**So the corpus states both, and reconciles them nowhere.** Isaiah 11:1 grows a shoot from a part that Job 14:8 says dies. The corpus contains both sentences and no passage anywhere addresses the relation.

**The objection, stated at full strength.** Hebrew poetry is parallelistic. The two cola of Isaiah 11:1 are a standard synonymous parallelism, in which the second colon restates the first in different words. On that reading *gezaʿ* and *shorashaw* are not two sources but one source named twice, and the whole observation dissolves into a failure to recognize a poetic convention.

That objection is good and it may be right. Three things can be said in reply and none of them is decisive.

**Synonymous parallelism is rarely purely synonymous.** The dominant view in the study of Hebrew poetry for the last half-century has been that the second colon typically sharpens, specifies, intensifies, or advances the first rather than merely repeating it. On that view the shift from *gezaʿ* to *shorashaw* is doing something, and what it is doing is a question rather than a non-question.

**The corpus uses the two nouns differently elsewhere.** *Shoresh* is common and is used of persistence: Isaiah 37:31, *we-yasfah peleyṭat beyt Yehudah ha-nishʾarah shoresh le-maṭṭah we-ʿasah feri le-maʿlah*, the remnant shall again take root downward and bear fruit upward. *Gezaʿ* occurs three times and twice denotes a part that fails. That is not a strong distributional argument, since three occurrences cannot carry much, but it is not nothing.

**And Isaiah 11:10 uses *shoresh* alone.** *We-hayah ba-yom ha-huʾ shoresh Yishay ʾasher ʿomed le-nes ʿammim.* And in that day the root of Jesse, which stands as a signal to the peoples. Nine verses after the two-noun verse, the passage returns to the figure with one noun, and it is the root.

**What this book claims and does not claim.**

It does not claim that Isaiah 11:1 is a two-source oracle, that the corpus intends a contrast, or that Job is being alluded to.

It claims that the corpus contains a verse growing a shoot from a *gezaʿ* and a verse saying a *gezaʿ* dies in the dust, and that no passage in the corpus addresses the relation between them. Whether that is a real tension or an artifact of reading poetry too literally is a question a reader can decide, and the decision does not affect anything else in this book. Chapter 97 counts the pair among the ten and marks it as the most contestable of them.

## 89. Isaiah 6:13 · The Holy Seed Is Its Stump


The commission into non-reception ends in a felled tree, and the placement is worth as much as the content.

*We-ʿod bah ʿasiriyah we-shavah we-haytah le-vaʿer, ka-ʾelah we-kha-ʾallon ʾasher be-shalleket maṣṣevet bam, zeraʿ qodesh maṣṣavtah.*

And yet a tenth shall be in it, and it shall return and be consumed; as a terebinth and as an oak whose *maṣṣevet* remains when they are felled, the holy seed is its *maṣṣevet*.

**The verse is textually and lexically difficult and the difficulty is named rather than managed.** *Maṣṣevet* is usually taken as the stump or the standing trunk of a felled tree, from *nṣb*, to stand. *Be-shalleket* is a hapax, usually taken as a felling or a casting down. And the final clause *zeraʿ qodesh maṣṣavtah* is absent from the Septuagint and from 1QIsa-a according to a common assessment, and is therefore held by many to be a later addition. This book does not adjudicate the text-critical question and its argument does not require the final clause.

**What the verse establishes without the disputed clause.** After the commission into non-reception, after *ʿad matay*, and after the answer about desolation, the chapter ends in an image of a felled tree with something remaining. That is the placement and it is not disputed.

**And the placement is seven chapters before Isaiah 11:1.** The commission that shuts eyes and stops ears ends in a stump. Seven chapters later a shoot comes from a stump. Whatever the compositional history, the received arrangement puts the deficit and the regrowth in the same book with the tree-image at both ends.

**Three observations.**

**The tenth returns and is consumed.** *We-shavah we-haytah le-vaʿer.* The verb *shwv* is the return-word, used throughout the corpus for repentance and for coming back from exile, and here what returns is consumed. Whatever comfort the verse offers is offered after a second destruction.

**The trees named are the terebinth and the oak**, *ʾelah* and *ʾallon*, both of them long-lived hardwoods that do in fact resprout from the base. The image is botanically apt and the corpus chose species that suit it.

**And the surviving element is called a seed, not a shoot.** *Zeraʿ qodesh*, holy seed, in the disputed clause. A seed and a stump are different objects: a seed is a beginning and a stump is a remainder. The clause identifies them, which is either a striking compression or an indication that the clause is a gloss.

**One structural point for Book IX.** The corpus's two great stump-passages, Isaiah 6:13 and Isaiah 11:1, use different nouns for the stump: *maṣṣevet* and *gezaʿ*. That is a lexical fact and this book makes nothing of it beyond recording it, since the two passages are seven chapters apart in a book whose composition is contested and the vocabulary of stumps is small enough that variation is unremarkable.

## 90. The Ṣemaḥ Field · Branch as a Title


A second vegetable image runs through the prophetic corpus and becomes a title. This chapter surveys it.

**The noun is *ṣemaḥ*, from *ṣmḥ*, to sprout.** As a common noun it means growth or a sprout: Genesis 19:25 of the growth of the ground, Hosea 8:7 of standing grain, Ezekiel 16:7 of a plant of the field.

**As a title it occurs at five sites.**

**Jeremiah 23:5.** *Hinneh yamim baʾim neʾum YHWH wa-haqimoti le-Dawid ṣemaḥ ṣaddiq u-malakh melekh we-hiskil we-ʿasah mishpaṭ u-ṣedaqah ba-ʾareṣ.* Behold days are coming, says the LORD, when I will raise up for David a righteous Branch, and he shall reign as king and deal wisely and execute justice and righteousness in the land. And 23:6 gives the name: *we-zeh shemo ʾasher yiqreʾo YHWH ṣidqenu*, and this is his name by which he shall be called, the LORD our righteousness.

**Jeremiah 33:15.** *ʾAṣmiaḥ le-Dawid ṣemaḥ ṣedaqah we-ʿasah mishpaṭ u-ṣedaqah ba-ʾareṣ.* I will cause a Branch of righteousness to sprout for David. The verb and the noun are cognate: I will cause to sprout a sprout.

**Zechariah 3:8.** *Ki hinneni meviʾ ʾet ʿavdi Ṣemaḥ.* Behold I am bringing my servant Branch.

**Zechariah 6:12.** *Hinneh ʾish Ṣemaḥ shemo u-mi-taḥtaw yiṣmaḥ u-vanah ʾet heykhal YHWH.* Behold a man whose name is Branch, and he shall sprout from his place and build the temple of the LORD.

**Isaiah 4:2** is usually included and is different in character. *Ba-yom ha-huʾ yihyeh ṣemaḥ YHWH li-ṣvi u-le-khavod u-feri ha-ʾareṣ le-gaʾon u-le-tifʾeret li-fleyṭat Yisraʾel.* In that day the Branch of the LORD shall be for beauty and glory, and the fruit of the land for pride and honour, for the survivors of Israel. The parallelism with *peri ha-ʾareṣ*, fruit of the land, suggests a literal agricultural sense here, and many read it so.

**The conferral grammar holds at every site.**

Jeremiah 23:5: *wa-haqimoti*, I will raise up. First person divine.
Jeremiah 33:15: *ʾaṣmiaḥ*, I will cause to sprout. First person divine.
Zechariah 3:8: *hinneni meviʾ*, behold I am bringing. First person divine.
Zechariah 6:12: *u-mi-taḥtaw yiṣmaḥ*, he shall sprout from his place, which is the one site with the figure as grammatical subject, and the verb is intransitive growth rather than an act.

**Four of five have God as the subject of the raising, and the fifth has a plant growing.**

**Two further observations.**

**The name at Jeremiah 23:6 is a sentence and it is about God.** *YHWH ṣidqenu*, the LORD our righteousness. Compare Jeremiah 33:16, where the identical name is applied to Jerusalem rather than to a person: *we-zeh ʾasher yiqraʾ lah YHWH ṣidqenu*. The corpus gives the same theophoric name to the Branch and to the city, which tells against reading it as a claim about the bearer's nature and for reading it as a confession the bearer's existence occasions.

**And the field overlaps with Isaiah 11's without sharing its vocabulary.** Isaiah 11 uses *ḥoṭer*, *neṣer*, *gezaʿ*, and *shoresh*. The Branch material uses *ṣemaḥ*. Both are vegetable images for a Davidic figure and they share no noun. That is evidence that the image is a live metaphor in the corpus rather than a fixed term, which matters for how much weight any single occurrence can carry.

## 91. Jeremiah 2:27 and Habakkuk 2:19 · The Fenced Location


The corpus is emphatic about a tree-image it forbids, and the prohibition sharpens what the permitted images are doing.

**Jeremiah 2:27.** *ʾOmerim la-ʿeṣ ʾavi ʾattah we-la-ʾeven ʾat yelidtani, ki fanu ʾelay ʿoref we-loʾ fanim; u-ve-ʿet raʿatam yoʾmeru qumah we-hoshiʿenu.*

Saying to the wood, you are my father, and to the stone, you gave me birth; for they have turned their back to me and not their face; but in the time of their trouble they will say, arise and save us.

**Habakkuk 2:19.** *Hoy ʾomer la-ʿeṣ haqiṣah, ʿuri le-ʾeven dumam, huʾ yoreh; hinneh huʾ tafus zahav wa-khesef we-khol ruaḥ ʾeyn be-qirbo.*

Woe to him who says to the wood, awake; to the silent stone, arise, it shall teach. Behold, it is overlaid with gold and silver and there is no breath at all within it.

**And the answer, one verse later.** Habakkuk 2:20: *wa-YHWH be-heykhal qodsho, has mi-panaw kol ha-ʾareṣ.* But the LORD is in his holy temple; let all the earth keep silence before him.

**Read the two verses together and the structure is exact.** A thing told to get up, which has no breath in it, against one already present who requires silence rather than summoning. Habakkuk sets the two side by side and the contrast is the whole point of the placement.

**Three observations.**

**The verbs addressed to the wood are all rousing-verbs.** *Qumah*, arise. *Haqiṣah*, awake. *ʿUri*, rouse yourself. The corpus's parody of idolatry is a parody of summoning: the worshipper's characteristic act toward the manufactured thing is to try to wake it.

**And the answer to the present God is silence.** *Has mi-panaw kol ha-ʾareṣ.* The interjection *has* is a hushing sound. Where the false object requires rousing, the real one requires quiet.

**Two objects are denoted by *ʿeṣ* and the shift must be marked rather than traded on.** At Job 14 and Isaiah 11 it is a felled tree, a living root system with a dead crown. At Jeremiah 2 and Habakkuk 2 it is carved timber, a manufactured article with no root at all. Those are different objects sharing a noun, and an argument that slid between them would be equivocating.

**What the fence establishes.** The corpus is not against tree-imagery; it uses it constantly and positively. What it fences is a location: the address of a rousing-summons to a made thing. The felled tree of Job 14 is not summoned; it detects water. The shoot of Isaiah 11:1 is not summoned; it comes out. Neither passage has anyone calling to a piece of wood.

That distinction is checkable and it is the corpus's own. It is also the reason this book's account of the escalation is not an argument against the figure. A figure whose coming is stated in the corpus's own grammar of conferral is categorically distinct from a thing a worshipper tries to wake. The fence at Habakkuk 2:19 is a fence against the second, and nothing in Book VIII places the messianic material on the wrong side of it.

## 92. Ezekiel 17 and 31 · The Cedar, the Sprig, and the Felling


Two extended tree-allegories in Ezekiel supply the corpus's fullest development of the image and both are about a felling.

**Ezekiel 17.** The riddle of the eagles. A great eagle comes to Lebanon, takes the top of the cedar, crops off the topmost of its young twigs, and carries it to a land of merchants. Then it takes seed of the land and plants it in fertile soil beside abundant waters, and it becomes a spreading vine of low stature. A second eagle comes and the vine bends its roots toward it.

The interpretation is given at 17:12-21 and it is political: Nebuchadnezzar, Jehoiachin taken to Babylon, Zedekiah installed and bound by oath, and the turning to Egypt. The oath and its breach are the burden: 17:19, *ḥay ʾani ʾim loʾ ʾalati ʾasher bazah u-veriti ʾasher hefir u-netattiw be-roʾsho*, as I live, my oath which he despised and my covenant which he broke, I will bring upon his head.

**And then 17:22-24, which reverses the images.** *Wa-laqaḥti ʾani mi-ṣammeret ha-ʾerez ha-ramah we-natatti, me-roʾsh yoneqotaw rakh ʾeqṭof we-shatalti ʾani ʿal har gavoah we-talul.* I myself will take from the lofty top of the cedar and set it; from the topmost of its young twigs I will crop a tender one and I myself will plant it on a high and lofty mountain.

**The first eagle took a twig. God takes a twig.** The same act, narrated twice, once by a foreign king and once by God, with the pronoun *ʾani* emphatic in both clauses of the divine version: I myself will take, I myself will plant.

**And 17:24 states the principle.** *We-yadʿu kol ʿaṣey ha-sadeh ki ʾani YHWH hishpalti ʿeṣ gavoah higbahti ʿeṣ shafal, hovashti ʿeṣ laḥ we-hifraḥti ʿeṣ yavesh.* And all the trees of the field shall know that I the LORD have brought down the high tree and exalted the low tree, dried up the green tree and made the dry tree flourish.

Four verbs, all causative, all first person. The high brought down, the low raised, the green dried, the dry made to flourish. The corpus states its principle about trees in the vocabulary of reversal and puts every verb in the divine first person.

**Ezekiel 31.** Assyria as a cedar in Lebanon, fair of branches, its top among the clouds, the waters making it great, all the birds of heaven nesting in its boughs, all the beasts bringing forth under its shadow, and no tree in the garden of God like it.

And then 31:10-12: because it was high and lifted up and its heart was lifted up in its height, *wa-ram levavo be-govho*, God gives it into the hand of the mighty one of the nations, and strangers cut it down and leave it.

**The mechanism is Deuteronomy 8:14's again.** *Ram levavo*, his heart was lifted up. The identical idiom as the law of the king's purpose clause at Deuteronomy 17:20 and Deuteronomy 8:14's warning and 2 Chronicles 26:16's execution on Uzziah. Here it fells a cedar that stands for an empire.

**Two structural results for Book IX.**

**Every felling in the corpus's tree-allegories is attributed to God, and every planting too.** Ezekiel 17:24's four causatives state it as a principle.

**And the corpus's own reason for a felling, where it gives one, is the lifted heart.** That is the mechanism Book IV located in the receiver, applied here to nations and to trees, in one idiom across four books.

## 93. What the Tree Material Establishes


Book IX has read six passages and this chapter states what they support.

**The corpus's tree-vocabulary is small, specific, and used with some care.** *ʿEṣ* for tree and for timber, with the two senses distinguishable by context and fenced at Habakkuk 2:19. *Gezaʿ* for stump, three occurrences. *Shoresh* for root, common. *Ḥoṭer* and *neṣer* for shoot and branch at Isaiah 11:1. *Maṣṣevet* at Isaiah 6:13. *Ṣemaḥ* for the Branch title at five sites. *ʾErez* for cedar and *ʾelah* and *ʾallon* for the resprouting hardwoods.

**Every regrowth is stated as coming from a remainder.** Isaiah 11:1 from a stump and roots. Isaiah 6:13 from a *maṣṣevet* after a felling. Job 14:7 from a cut tree. Ezekiel 17:22 from a twig cropped off a cedar top. None of the corpus's regrowth images is a new planting from nothing.

**Every planting and every felling in the allegories has God as subject.** Ezekiel 17:22-24 makes it a principle in four causatives. Jeremiah 23:5's *wa-haqimoti* and 33:15's *ʾaṣmiaḥ* have the same grammar in the Branch field. The conferral grammar of Book VI holds in the vegetable register without exception.

**And the corpus states one ruling about a stump that its most famous stump-verse does not observe.** Job 14:8 has the *gezaʿ* dying in the dust. Isaiah 11:1 grows a shoot from a *gezaʿ*. The corpus contains both and reconciles neither, and Chapter 88 stated the objection to making anything of it.

Two closing observations, both of which look forward.

**The tree material supplies the corpus's own picture of a resource present and unregistered.** Job 14:9's water is already in the ground; the tree detects it. That is Book III's terminus and Book IV's receiving faculty, in a vegetable image, in a wisdom book. This book offers the picture as a picture and claims nothing about intent.

**And the fenced location at Habakkuk 2:19 tells against reading this book as an argument about the figure.** The corpus prohibits addressing a summons to a piece of manufactured wood. It does not prohibit expecting a shoot from a felled stump, and it states the shoot in the same grammar it uses for every other conferral. Book IX ends where Book VIII ended: the figure is real in the corpus's own terms, and the terms are terms of receipt.

:::book X | THE SHEPHERD AND THE FLOCK


## 94. The Metaphor and Its Two Ends


The corpus's most sustained image for the relation between God, the ruler, and the people is a flock, and the image has a fixed structure that survives every use.

**The flock is God's.** This is the constant. *Ṣoʾni*, my flock, eleven times in Ezekiel 34 alone. *ʿAmmi*, my people, throughout the corpus. *Ṣoʾn marʿito*, the sheep of his pasture, at Psalm 100:3. *ʿAm marʿito we-ṣoʾn yado*, the people of his pasture and the sheep of his hand, at Psalm 95:7.

**The shepherd is appointed.** Every human shepherd in the corpus is placed over a flock that is not his. 2 Samuel 5:2: you shall shepherd *ʿammi*, my people. Ezekiel 34:23: I will raise up over them one shepherd. Jeremiah 3:15: *we-natatti lakhem roʿim ke-libbi*, I will give you shepherds after my own heart.

**And God is the shepherd too, in the same corpus, without the two claims being reconciled.** Psalm 23:1: *YHWH roʿi*. Psalm 80:2: *roʿeh Yisraʾel haʾazinah, noheg ka-ṣoʾn Yosef*. Genesis 48:15, Jacob blessing: *ha-ʾelohim ha-roʿeh ʾoti me-ʿodi ʿad ha-yom ha-zeh*, the God who has shepherded me all my life to this day. Isaiah 40:11: *ke-roʿeh ʿedro yirʿeh, bi-zroʿo yeqabbeṣ ṭelaʾim u-ve-ḥeyqo yissaʾ*, he will feed his flock like a shepherd, gather the lambs in his arm, and carry them in his bosom.

**Two shepherds, one flock, no reconciliation.** That is the structure and Ezekiel 34 is the passage that states both in one chapter and leaves them standing.

Three observations before the chapters that follow.

**The metaphor is agricultural and the corpus does not romanticize it.** Sheep are property. A shepherd who eats the fat and clothes himself with the wool is doing what a shepherd is for; Ezekiel 34:3's indictment is not that he takes the produce but that he does not feed the flock. The image carries an economics.

**The metaphor is applied to foreign rulers too.** Isaiah 44:28 calls Cyrus *roʿi*, my shepherd. Jeremiah 25:34-36 addresses the shepherds and the principals of the flock in an oracle against the nations. Nahum 3:18 has the shepherds of Assyria slumbering.

**And the metaphor's most famous instance has the king as the sheep.** Psalm 23, attributed to David. Chapter 96 works it.

## 95. Ezekiel 34 · The Indictment and the Substitution


The chapter has been used at Chapter 61 for one verse. This chapter reads it whole, because it is the corpus's most complete statement of the shepherd relation and its structure is an argument.

**Part one, the indictment.** 34:1-10. Woe to the shepherds of Israel who feed themselves. They eat the fat, clothe themselves with the wool, kill the fatlings, and do not feed the flock. The weak are not strengthened, the sick not healed, the broken not bound, the strayed not brought back, the lost not sought. *U-ve-ḥozqah reditem ʾotam u-ve-farekh*, and with force and with harshness you have ruled them.

The result at 34:5-6: *wa-tefuṣeynah mi-beli roʿeh wa-tihyeynah le-ʾokhlah le-khol ḥayyat ha-sadeh*, they were scattered for lack of a shepherd and became food for every beast of the field. They wandered on every mountain and hill, scattered on the face of the earth, *we-ʾeyn doresh we-ʾeyn mevaqqesh*, with none searching and none seeking.

**Part two, the removal.** 34:10. *Hineni ʾel ha-roʿim we-darashti ʾet ṣoʾni mi-yadam we-hishbattim me-reʿot ṣoʾn.* Behold I am against the shepherds and I will require my flock at their hand and cause them to cease from feeding the flock.

Two verbs there. *Darashti*, I will require, which is the verb the shepherds failed to perform at 34:6 where *ʾeyn doresh*, none searching. God does the searching the shepherds did not. And *hishbattim*, I will cause them to cease, from *šbt*, the cessation root of Genesis 2 used here for the termination of an office.

**Part three, the substitution, and it is the longest.** 34:11-16, eleven first-person verbs. I will search. I will seek out. I will deliver. I will bring out from the peoples. I will gather. I will bring in. I will feed. I will cause them to lie down. I will seek the lost. I will bring back the strayed. I will bind the broken. I will strengthen the sick.

**And 34:15 uses the terminus vocabulary.** *ʾAni ʾerʿeh ṣoʾni wa-ʾani ʾarbiṣem, neʾum ʾAdonay YHWH.* I will feed my flock and I will make them lie down. The verb *rbṣ* is the lying down of an animal at rest and it stands in the same field as the four roots without being one of them.

**Part four, the judgment within the flock.** 34:17-22. Between sheep and sheep, rams and goats. The fat sheep who have drunk the clear water and fouled the rest with their feet, who push with side and shoulder and thrust the weak with their horns. *We-hoshaʿti le-ṣoʾni we-loʾ tihyeynah ʿod la-vaz we-shafaṭti beyn seh la-seh.* I will save my flock and judge between sheep and sheep.

**Part five, the shepherd appointed.** 34:23-24. And I will raise up over them one shepherd and he shall feed them, my servant David. And I the LORD will be their God, and my servant David a prince in their midst.

**Part six, the covenant of peace and the terminus.** 34:25-31. A covenant of peace, evil beasts removed, dwelling securely in the wilderness and sleeping in the woods, showers of blessing, the tree of the field yielding fruit, the earth its increase, no more a prey to the nations, *we-yashvu la-veṭaḥ we-ʾeyn maḥarid*, dwelling securely with none making afraid.

**And the chapter closes on the possessive one last time.** 34:31: *we-ʾatten ṣoʾni ṣoʾn marʿiti ʾadam ʾattem, ʾani ʾeloheykhem.* And you are my flock, the flock of my pasture; you are men, and I am your God.

**The structure is the argument.** The shepherds fail. God removes them and does the work himself, in eleven verbs. Then he appoints a shepherd. Then he restates that he is their God and the flock is his.

**The appointment falls between two divine claims and is bracketed by them.** That is a placement, and this book takes it as one. The corpus could have run the sequence differently: failure, appointment, restoration. It runs it as failure, divine action, appointment, divine claim. The shepherd is installed inside a frame already occupied.

## 96. Psalm 23 · The King Is the Sheep


*YHWH roʿi loʾ ʾeḥsar.*

The superscription is *mizmor le-Dawid*, a psalm of David, and whatever the preposition means, the corpus's tradition attaches the psalm to the king.

**The psalm makes its speaker a sheep and the whole of it follows from that.** He makes me lie down in green pastures, *bi-nʾot desheʾ yarbiṣeni*, using the same *rbṣ* as Ezekiel 34:15. He leads me beside still waters, *ʿal mey menuḥot yenahaleni*, and the noun is *menuḥot*, the plural of the settling-root nominal, in the terminus vocabulary. He restores my soul, *nafshi yeshovev*. He leads me in paths of righteousness *le-maʿan shemo*, for his name's sake.

**Three of the four opening clauses are causatives with God as subject.** He makes me lie down. He leads me. He restores. The speaker's verbs are the passive experience of being pastured.

**And the corpus has appointed this same speaker shepherd over God's flock.** 2 Samuel 5:2, the elders quoting divine speech: *ʾattah tirʿeh ʾet ʿammi ʾet Yisraʾel*. You shall shepherd my people Israel.

**So the corpus has one man as shepherd of the flock and as a sheep in it, and it states both.** That is the fifth of the ten pairs Book XIII counts, and it is the one that most resists being read as a redactional accident, since both statements attach to the same figure by the corpus's own attributions.

**The psalm's second half changes the metaphor.** Verses 5-6 move from pasture to table: *taʿarokh le-fanay shulḥan neged ṣoreray, dishanta va-shemen roʾshi kosi rewayah.* You prepare a table before me in the presence of my enemies; you anoint my head with oil; my cup overflows.

**The anointing verb here is *dšn*, not *mšḥ***, and it means to make fat or to enrich, used of the oil of hospitality rather than of installation. But the phrase is *va-shemen roʾshi*, oil on my head, which is the physical gesture of 1 Samuel 10:1's *wa-yiṣoq ʿal roʾsho*. The psalm attributed to the anointed king has God performing the oil-on-the-head gesture in the register of a host.

**And the closing verb is a dwelling.** *We-shavti be-veyt YHWH le-ʾorekh yamim.* The Masoretic pointing gives *we-shavti* from *yšb*, and I shall dwell, though the consonants also allow *šwb*, and I shall return. Either reading closes the psalm in a settling, in a house belonging to another.

**What the psalm establishes for Book X.** The corpus's most beloved statement of the shepherd relation is spoken by the sheep, and the corpus attributes it to the king. That is not an argument for anything by itself. Set beside Ezekiel 34's eleven possessives and 2 Samuel 5:2's *ʿammi*, it is a third witness that the corpus consistently holds the flock to be God's however many shepherds it appoints.

## 97. The Shepherds Who Failed, Book by Book


The indictment of shepherds is not confined to Ezekiel and this chapter surveys the field, because a motif in four books is different from a motif in one.

**Jeremiah 23:1-2.** *Hoy roʿim meʾabbedim u-mefiṣim ʾet ṣoʾn marʿiti neʾum YHWH.* Woe to the shepherds who destroy and scatter the sheep of my pasture. And 23:2: *ʾattem hafiṣotem ʾet ṣoʾni wa-taddiḥum we-loʾ feqadtem ʾotam, hineni foqed ʿaleykhem ʾet roaʿ maʿalleykhem.* You have scattered my flock and driven them away and have not attended to them; behold, I attend to you for the evil of your doings.

The verb *pqd* used twice with opposite force: you did not attend to them, I attend to you. And *ṣoʾn marʿiti* and *ṣoʾni*, the possessive twice in two verses.

**Jeremiah 23:3-4 is the substitution, and it precedes the Branch oracle at 23:5.** *Wa-ʾani ʾaqabbeṣ ʾet sheʾerit ṣoʾni ... wa-hashivoti ʾethen ʿal nawehen ... wa-haqimoti ʿaleyhem roʿim we-raʿum.* And I will gather the remnant of my flock and bring them back to their fold, and I will set up shepherds over them who will feed them.

Note the plural: *roʿim*, shepherds, at 23:4, followed two verses later by the singular Branch at 23:5. The corpus places a plural restoration of the office and a singular figure in one oracle without harmonizing the number.

**Jeremiah 10:21.** *Ki nivʿaru ha-roʿim we-ʾet YHWH loʾ darashu, ʿal ken loʾ hiskilu we-khol marʿitam nafoṣah.* The shepherds are stupid and have not sought the LORD; therefore they have not prospered and all their flock is scattered. The failure is stated as a failure to seek, using *drš*, the same verb Ezekiel 34:6 uses for the searching the shepherds did not do.

**Zechariah 10:2-3 and 11:4-17.** 10:3: *ʿal ha-roʿim ḥarah ʾappi we-ʿal ha-ʿattudim ʾefqod*, my anger is kindled against the shepherds and I will punish the leaders. And chapter 11 is the extended sign-act of the worthless shepherd, with the two staves named *noʿam* and *ḥovelim*, favour and union, both broken, and the thirty pieces of silver weighed out as the shepherd's wages and thrown to the potter in the house of the LORD.

**Zechariah 13:7.** *Ḥerev ʿuri ʿal roʿi we-ʿal gever ʿamiti neʾum YHWH ṣevaʾot, hakh ʾet ha-roʿeh u-tefuṣeynah ha-ṣoʾn.* Awake, sword, against my shepherd and against the man who is my associate; strike the shepherd and the sheep shall be scattered.

That verse is difficult in every direction and this book does not attempt it. What it records is that the corpus contains an instruction to strike a shepherd whom it calls *roʿi*, my shepherd, and that the consequence stated is the scattering of the flock.

**Nahum 3:18 and Isaiah 56:11** carry the motif against Assyria and against Israel's watchmen respectively. Isaiah 56:11: *we-hemmah roʿim loʾ yadʿu havin, kullam le-darkam panu ʾish le-viṣʿo mi-qaṣehu*, and they are shepherds who cannot understand; they have all turned to their own way, each to his gain.

**The survey's result.** Five books carry the shepherd indictment: Jeremiah, Ezekiel, Zechariah, Isaiah, Nahum. The vocabulary is stable: scattering, not seeking, not attending, feeding themselves. And in every case the corrective is stated with God as subject, and where a new shepherd is appointed the appointing verb is *qwm* in the hiphil with God as its subject.

## 98. The One Shepherd, and the Number Problem


Ezekiel 34:23 and 37:24 both say *roʿeh ʾeḥad*, one shepherd. Jeremiah 23:4 says *roʿim*, shepherds, plural, two verses before the singular Branch. This chapter takes the discrepancy seriously because it bears on how singular the corpus's expectation is.

**The singular sites.** Ezekiel 34:23: *wa-haqimoti ʿaleyhem roʿeh ʾeḥad we-raʿah ʾethen ʾet ʿavdi Dawid.* Ezekiel 37:24: *we-ʿavdi Dawid melekh ʿaleyhem we-roʿeh ʾeḥad yihyeh le-khullam.* Both use *ʾeḥad* and both name David.

**The plural sites.** Jeremiah 3:15: *we-natatti lakhem roʿim ke-libbi we-raʿu ʾetkhem deʿah we-haskel.* And I will give you shepherds after my own heart, who will feed you with knowledge and understanding. Jeremiah 23:4: *wa-haqimoti ʿaleyhem roʿim we-raʿum.*

**Jeremiah 3:15 deserves separate notice** because of what the shepherds are said to feed with. *De'ah we-haskel*, knowledge and understanding. That is the deficit inventory of Book IV supplied by shepherds, in the plural, in a passage with no singular figure. It is the closest the corpus comes anywhere to a transfer of the missing faculty through a human office, and it is plural and unnamed.

**Two readings of the number problem.**

**The developmental reading.** Jeremiah's plural is earlier and Ezekiel's singular is a later concentration of the expectation onto one figure. This is a common view and it is compatible with the standard datings.

**The functional reading.** The plural is the ordinary provision and the singular is a claim about unity: *ʾeḥad* in Ezekiel 34:23 and 37:24 is doing work against division, since 37:15-23 is the oracle of the two sticks joined into one, and 37:22 has *u-melekh ʾeḥad yihyeh le-khullam le-melekh*, one king for all of them. On this reading *ʾeḥad* is a numeral answering the two kingdoms rather than an assertion of singularity as such.

**The second reading has textual support in the immediate context** and this book prefers it while not requiring it. Ezekiel 37:22's one king stands in a sentence that also has *goy ʾeḥad*, one nation, and *loʾ yeḥaṣu ʿod li-shtey mamlakhot*, they shall no longer be divided into two kingdoms. Three occurrences of oneness in one verse, all of them about the reunification of a divided people.

**What the chapter establishes for the argument.** The corpus's shepherd expectation is not uniformly singular. It carries a plural provision in Jeremiah, a unifying singular in Ezekiel, and in the one case where a shepherd is said to supply the missing faculties, the shepherds are plural and anonymous.

That does not diminish the singular material. It fixes the range of what the corpus says, and a reading that presented the singular as the corpus's only shape would be selecting.

## 99. Micah 5 · The One from Bethlehem, and Whose Strength


*We-ʾattah Beyt Leḥem ʾEfratah ṣaʿir li-hyot be-ʾalfey Yehudah, mimmekha li yeṣeʾ li-hyot moshel be-Yisraʾel, u-moṣaʾotaw mi-qedem mi-mey ʿolam.*

And you, Bethlehem Ephrathah, little to be among the clans of Judah, from you shall come forth for me one who is to be ruler in Israel, whose goings forth are from of old, from ancient days. Micah 5:1, which is 5:2 in English versions.

**The preposition is the datum.** *Mimmekha li yeṣeʾ*, from you shall come forth **for me**. The lamed of advantage on the divine first person. The figure comes out for God's benefit, which is 2 Chronicles 9:8's *la-YHWH ʾeloheykha* in a different book.

**The place is named as small.** *Ṣaʿir li-hyot be-ʾalfey Yehudah*, little to be among the thousands of Judah. The oracle begins with a diminishment.

**The origin clause is contested and this book does not build on it.** *U-moṣaʾotaw mi-qedem mi-mey ʿolam* can be read as a claim about the figure's antiquity, about the antiquity of his line, or about the ancient origin of the Bethlehem descent, since *qedem* and *ʿolam* both carry a durative rather than necessarily an eternal sense in this corpus. Compare Amos 9:11's *ki-mey ʿolam*, as in the days of old, which is plainly historical. Nothing in this chapter requires a decision.

**5:3 states the mode of his rule and it is entirely dependent.** *We-ʿamad we-raʿah be-ʿoz YHWH bi-geʾon shem YHWH ʾelohaw, we-yashavu ki ʿattah yigdal ʿad ʾafsey ʾareṣ.*

And he shall stand and shepherd **in the strength of the LORD**, in the majesty of the name of the LORD his God; and they shall dwell, for now he shall be great to the ends of the earth.

**Four features of that verse.**

*Be-ʿoz YHWH*, in the strength of the LORD. Not in his own.
*Bi-geʾon shem YHWH ʾelohaw*, in the majesty of the name of the LORD his God. The possessive: his God.
*We-yashavu*, and they shall dwell, using *yšb*, the settling verb of Deuteronomy 12:10's *wi-shavtem beṭaḥ*.
And *yigdal*, he shall be great, which is the one verb in the verse with the figure as subject, and it is intransitive.

**5:4 opens *we-hayah zeh shalom*, and this shall be peace**, which is one of the corpus's few statements identifying a figure with a state rather than describing his acts.

**The structural result.** Micah 5 is the corpus's most specific messianic oracle in the sense of naming a place, and its central verse states that the ruler shepherds in a strength that is named as somebody else's. The conferral grammar holds in the one passage most often read as a bare prediction.

## 100. The Flock That Is Not Gathered by a Shepherd


Book X closes on a negative survey, which is the complement of Chapter 41's.

**The question.** Where the corpus states the gathering of the scattered flock, who gathers?

**Ezekiel 34:11-16.** God, eleven verbs, before any shepherd is mentioned.

**Jeremiah 23:3.** *Wa-ʾani ʾaqabbeṣ ʾet sheʾerit ṣoʾni mi-kol ha-ʾaraṣot.* And I will gather the remnant of my flock from all the countries. First person divine, and the shepherds are appointed in the next verse, after the gathering.

**Isaiah 40:11.** *Ke-roʿeh ʿedro yirʿeh, bi-zroʿo yeqabbeṣ ṭelaʾim u-ve-ḥeyqo yissaʾ, ʿalot yenahel.* He will feed his flock like a shepherd; with his arm he will gather the lambs and carry them in his bosom and gently lead those with young. The subject from 40:10 is *ʾAdonay YHWH*.

**Isaiah 56:8.** *Neʾum ʾAdonay YHWH meqabbeṣ nidḥey Yisraʾel, ʿod ʾaqabbeṣ ʿalaw le-niqbaṣaw.* Thus says the Lord GOD who gathers the outcasts of Israel: I will gather yet others to him besides those already gathered.

**Deuteronomy 30:3-4.** *We-shav YHWH ʾeloheykha ʾet shevutekha we-riḥamekha we-shav we-qibbeṣkha mi-kol ha-ʿammim.* Divine subject throughout.

**Ezekiel 36:24.** *We-laqaḥti ʾetkhem min ha-goyim we-qibbaṣti ʾetkhem mi-kol ha-ʾaraṣot.* First person divine.

**Micah 2:12.** *ʾAsof ʾeʾesof Yaʿaqov kullakh, qabbeṣ ʾaqabbeṣ sheʾerit Yisraʾel.* Two infinitive absolutes with first-person divine imperfects.

**Psalm 147:2.** *Boneh Yerushalayim YHWH, nidḥey Yisraʾel yekhannes.* The LORD builds Jerusalem; he gathers the outcasts of Israel.

**Eight sites in six books. In every one the gatherer is God.**

This book has found no passage in which a royal or messianic figure is the grammatical subject of the gathering. Chapter 41 stated the analogous negative about the terminus and stated how to break it. The same applies here: produce one verse in which a figure gathers, and the claim falls.

**Two near-cases, named so they are not mistaken for finds.**

**Ezekiel 34:23** appoints a shepherd who *feeds*, *we-raʿah ʾethen*, after the gathering has been narrated in first-person divine verbs at 34:11-16. Feeding after a gathering is not gathering.

**Jeremiah 23:4** appoints shepherds who *feed*, again after 23:3's divine gathering.

The corpus is consistent on the division of labour. God gathers; the appointed shepherd feeds. And the flock, throughout, is called God's.

## 101. What the Shepherd Material Establishes


Five results, each checkable.

**The flock's ownership never transfers.** In every passage where a human shepherd is appointed, the flock is called God's in the same passage or the immediately surrounding one. Ezekiel 34 does it eleven times. 2 Samuel 5:2 does it in the appointing sentence. Jeremiah 23:1-3 does it three times before appointing.

**The appointing verb is causative with God as subject.** *Wa-haqimoti* at Ezekiel 34:23, Jeremiah 23:4, and Jeremiah 30:9. *We-natatti* at Jeremiah 3:15. The pattern of Chapter 62 holds in the pastoral register.

**The gathering is never a figure's act.** Eight sites, six books, one subject.

**God is himself the shepherd, in the same corpus, without reconciliation.** Psalm 23, Psalm 80, Genesis 48:15, Isaiah 40:11, and the eleven verbs of Ezekiel 34:11-16. The corpus holds the divine shepherd and the appointed shepherd together and Ezekiel 34:24 states both in one sentence.

**And the king appears as a sheep in the psalm the corpus attributes to him.** Psalm 23:1.

Two closing notes.

**This book does not claim the appointed shepherd is unimportant.** Ezekiel 34:23-24 and 37:24-25 are strong statements and Micah 5:1-4 is stronger. The claim is about the division of functions the corpus states, and the division is: God owns, God gathers, God is himself shepherd, and the appointed shepherd feeds and is a prince in their midst.

**And the pastoral material converges with Book VI from a different direction.** Book VI read conferral verbs in royal texts. Book X has read possessives and appointing verbs in pastoral texts. Two vocabularies, two image-fields, one result. That convergence is the same kind Chapter 62 noted between the census and the conferral grammar, and it is the reason this book's central claim is stated as a finding rather than as a reading.

:::book XI | THE PSALTER READ FOR ITS VERBS


## 102. Why the Psalter Is Read Separately


The Psalter carries the corpus's highest royal language and it carries it in a genre the historical books do not use. This book reads it separately for three reasons.

**The genre is address, not narration.** A narrative reports what a king did. A psalm speaks to God about a king, or speaks as the king to God, or speaks about the king to an audience. The grammatical subjects therefore fall differently and the fall is informative.

**The royal psalms are the strongest single body of evidence against this book's reading.** Psalm 2, Psalm 45, Psalm 72, Psalm 89, Psalm 110, and Psalm 132 together contain the corpus's most exalted claims about a king, and any account that plays them down is selecting. This book does not play them down. It reads their verbs.

**And the Psalter contains the corpus's clearest statements of the divine kingship**, in the group at Psalms 93 to 99, which stand in the same book as the royal psalms and are never reconciled with them.

The method is the one used throughout. Take the passage at full strength. Ask what the corpus says the figure holds. Ask who the grammatical subject is of the verb by which he holds it.

## 103. Psalm 72 · Give the King Your Judgments


*ʾElohim mishpaṭeykha le-melekh ten, we-ṣidqatkha le-ven melekh.*

O God, give your judgments to the king, and your righteousness to the king's son. Psalm 72:1.

**The psalm opens with an imperative addressed to God asking for a transfer.** *Ten*, give. The objects are *mishpaṭeykha* and *ṣidqatkha*, your judgments and your righteousness, both with the divine possessive. The king does not have them and the psalm asks that he be given them.

That is the whole of Book VI in the first verse of the psalm most concerned with royal justice.

**What the king will then do is stated in a long sequence and it is the corpus's best account of what a good king is for.** 72:2-4: judge your people with righteousness and your poor with justice; the mountains bring peace and the hills righteousness; he shall judge the poor of the people, save the children of the needy, and crush the oppressor.

**72:12-14 is the psalm's centre and it is worth quoting.** *Ki yaṣṣil ʾevyon meshawweaʿ we-ʿani we-ʾeyn ʿozer lo. Yaḥos ʿal dal we-ʾevyon we-nafshot ʾevyonim yoshiaʿ. Mi-tokh u-me-ḥamas yigʾal nafsham we-yeqar damam be-ʿeynaw.*

For he delivers the needy when he cries, and the poor who has no helper. He spares the weak and needy and saves the souls of the needy. From oppression and violence he redeems their soul, and precious is their blood in his sight.

**Note *meshawweaʿ*, when he cries.** This is the outcry vocabulary of 1 Samuel 8:18, in the cognate root *šwʿ*, and here the king answers it. The psalm assigns to the king exactly the function 1 Samuel 8:18 said would go unanswered. Book XIII counts the pair.

**And the psalm's closing verses relocate everything.** 72:18-19: *barukh YHWH ʾelohim ʾelohey Yisraʾel ʿoseh niflaʾot levaddo. U-varukh shem kevodo le-ʿolam we-yimmaleʾ khevodo ʾet kol ha-ʾareṣ.* Blessed be the LORD God, the God of Israel, who alone does wondrous things. And blessed be his glorious name forever, and let the whole earth be filled with his glory.

*Levaddo*, alone. In the closing doxology of the psalm that has just described a king doing everything, the corpus says God alone does wondrous things.

The doxology at 72:18-19 is usually taken as the closing formula for Book Two of the Psalter rather than as part of the psalm proper, and 72:20 confirms it: *kallu tefillot Dawid ben Yishay*, the prayers of David son of Jesse are ended. So the *levaddo* may be editorial rather than authorial. This book records that the corpus's arrangement places it there, and takes it at that weight.

**Two further observations.**

**The psalm's superscription is *li-Shelomoh*, for or of Solomon**, and its content maps onto 1 Kings 3's request for a hearing heart and 1 Kings 10's account of tribute from Sheba and Seba, which 72:10 names.

**And the psalm's terminal image is agricultural and agentless.** 72:16: *yehi fissat bar ba-ʾareṣ be-roʾsh harim, yirʿash ka-Levanon piryo we-yaṣiṣu me-ʿir ke-ʿesev ha-ʾareṣ.* Let there be abundance of grain in the land on the top of the mountains; let its fruit wave like Lebanon, and let them blossom from the city like the grass of the earth.

## 104. Psalm 89 · The Covenant and the Complaint


Chapter 76 used this psalm for the covenant's failure. This chapter reads it whole, because it is the corpus's most sustained treatment of the Davidic grant and it contains its own refutation.

**Part one, the covenant stated.** 89:2-5 and 89:20-38. *Karatti verit li-vḥiri nishbaʿti le-Dawid ʿavdi, ʿad ʿolam ʾakhin zarʿekha u-vaniti le-dor wa-dor kisʾakha.* I have made a covenant with my chosen, I have sworn to David my servant: forever I will establish your seed and build up your throne to all generations.

**And 89:20-30 is the fullest statement of conferral in the Psalter.** *ʾAz dibbarta ve-ḥazon la-ḥasideykha wa-toʾmer shiwwiti ʿezer ʿal gibbor, harimoti vaḥur me-ʿam. Maṣaʾti Dawid ʿavdi, be-shemen qodshi meshaḥtiw. ʾAsher yadi tikkon ʿimmo ʾaf zeroʿi teʾammeṣennu.*

Then you spoke in a vision to your faithful ones and said: I have laid help on a mighty one, I have exalted one chosen from the people. I have found David my servant; with my holy oil I have anointed him. My hand shall be established with him, my arm also shall strengthen him.

**Count the first-person divine verbs in that passage.** I have laid. I have exalted. I have found. I have anointed. My hand shall establish. My arm shall strengthen. And it continues: 89:23, the enemy shall not outwit him; 89:24, I will beat down his foes; 89:25, my faithfulness and mercy shall be with him; 89:26, I will set his hand on the sea; 89:28, I will make him firstborn, highest of the kings of the earth.

**89:27 is the psalm's highest claim and it is put in the king's mouth as an address.** *Huʾ yiqraʾeni ʾavi ʾattah, ʾeli we-ṣur yeshuʿati.* He shall call to me: you are my father, my God, and the rock of my salvation.

The sonship of Psalm 2:7 restated from the other direction. In Psalm 2 God says you are my son. Here the king says you are my father, and adds *ʾeli*, my God. The corpus's highest filial claim about a king includes the king calling God his God.

**89:28.** *ʾAf ʾani bekhor ʾettenehu, ʿelyon le-malkhey ʾareṣ.* I also will make him firstborn, highest of the kings of the earth. *ʾEttenehu*, I will make him, first person.

**Part two, the discipline clause, which is 2 Samuel 7:14 in verse.** 89:31-34: if his sons forsake my law, I will visit their transgression with the rod and their iniquity with stripes, *we-ḥasdi loʾ ʾafir me-ʿimmo we-loʾ ʾashaqqer be-ʾemunati*, but my covenant loyalty I will not take from him, nor will I be false to my faithfulness.

**Part three, the complaint.** 89:39-46. You have cast off and rejected. You have been wroth with your anointed. You have renounced the covenant of your servant. You have profaned his crown to the ground. You have broken down all his walls. You have made his strongholds a ruin. You have exalted the right hand of his foes. You have turned back the edge of his sword. You have made his splendour to cease and cast his throne to the ground. You have shortened the days of his youth and covered him with shame.

**Eleven second-person verbs of destruction, addressed to God, about the covenant the psalm has just stated at maximum strength.**

**Part four, the question.** 89:47-52. *ʿAd mah YHWH tissater la-neṣaḥ.* How long, LORD, will you hide yourself forever? And 89:50: *ʾayyeh ḥasadeykha ha-rishonim ʾAdonay nishbaʿta le-Dawid be-ʾemunatekha.* Where are your former mercies, Lord, which you swore to David in your faithfulness?

**The psalm ends unanswered.** 89:53's *barukh YHWH le-ʿolam ʾamen we-ʾamen* is the doxology closing Book Three of the Psalter, not a resolution.

**What the psalm establishes.** The corpus's fullest statement of the Davidic conferral and the corpus's fullest complaint that it failed stand in one composition. The conferral is stated in eleven first-person divine verbs and the failure in eleven second-person ones. And the corpus preserves both, in one psalm, with a question at the end and no answer.

## 105. Psalm 132 · The Oath and Its Condition


*Zekhor YHWH le-Dawid ʾet kol ʿunnoto.* Remember, LORD, for David, all his affliction. Psalm 132:1.

**The psalm has two oaths and the pairing is its structure.**

**David's oath**, 132:2-5. He swore to the LORD, vowed to the Mighty One of Jacob: I will not come into the tent of my house, nor go up to my bed, nor give sleep to my eyes or slumber to my eyelids, until I find a place for the LORD, a dwelling for the Mighty One of Jacob.

**God's oath**, 132:11-12. *Nishbaʿ YHWH le-Dawid ʾemet loʾ yashuv mimmennah, mi-peri viṭnekha ʾashit le-khisseʾ lakh. ʾIm yishmeru vaneykha beriti we-ʿedoti zo ʾalammedem, gam beneyhem ʿadey ʿad yeshevu le-khisseʾ lakh.*

The LORD has sworn to David a truth from which he will not turn back: of the fruit of your body I will set on your throne. **If your sons keep my covenant and my testimony which I shall teach them, their sons also forever shall sit on your throne.**

**The conditional at 132:12 is the datum.** *ʾIm yishmeru vaneykha beriti.* If your sons keep my covenant. The corpus's second full statement of the Davidic oath carries a condition that 2 Samuel 7 does not.

**Two readings.**

On one, the two statements are in tension: 2 Samuel 7:15 bars the withdrawal unconditionally and Psalm 132:12 conditions the continuation. Book XIII counts the pair.

On the other, the two are compatible if the unconditional element is the grant to the house and the conditional element is any given son's occupancy, which is precisely the distinction 2 Samuel 7:14-15 makes between disciplining the occupant and not removing the loyalty. On this reading Psalm 132 is stating the same structure from the occupant's side.

**This book prefers the second and does not require it**, because either way the psalm supplies a conditional clause attached to the throne, in the corpus's own words.

**Two further features.**

**The psalm's centre is a dwelling, not a dynasty.** 132:13-14: *ki vaḥar YHWH be-Ṣiyyon, ʾiwwah le-moshav lo. Zoʾt menuḥati ʿadey ʿad, poh ʾeshev ki ʾiwwitiha.* For the LORD has chosen Zion, he has desired it for his dwelling. **This is my resting place forever; here I will dwell, for I have desired it.**

*Zoʾt menuḥati.* This is my *menuḥah*. The terminus vocabulary, with the divine first-person suffix, as at Psalm 95:11. Two psalms use *menuḥati* and one says they did not enter it and the other says here I will dwell.

**And the psalm closes on a horn and a lamp.** 132:17: *sham ʾaṣmiaḥ qeren le-Dawid, ʿarakhti ner li-meshiḥi.* There I will cause a horn to sprout for David; I have prepared a lamp for my anointed.

*ʾAṣmiaḥ*, I will cause to sprout, the causative of the Branch root, first person divine. *ʿArakhti*, I have prepared or arranged, first person divine. *Li-meshiḥi*, for my anointed, with the divine possessive.

Three conferral verbs in one verse at the close of the psalm.

## 106. The Enthronement Psalms · YHWH Malakh


Psalms 93, 95, 96, 97, 98, and 99 form a group whose subject is the divine kingship, and they stand in the same book as the royal psalms without any passage relating the two.

**Psalm 93:1.** *YHWH malakh geʾut laveš, laveš YHWH ʿoz hitʾazzar, ʾaf tikkon tevel bal timmoṭ.* The LORD reigns; he is clothed with majesty; the LORD is clothed, he has girded himself with strength; the world is established, it shall not be moved.

**Psalm 97:1.** *YHWH malakh tagel ha-ʾareṣ, yismeḥu ʾiyyim rabbim.* The LORD reigns; let the earth rejoice; let the many coastlands be glad.

**Psalm 99:1.** *YHWH malakh yirgezu ʿammim, yoshev keruvim tanuṭ ha-ʾareṣ.* The LORD reigns; let the peoples tremble; he sits enthroned upon the cherubim; let the earth quake.

**Psalm 96:10.** *ʾImru va-goyim YHWH malakh.* Say among the nations: the LORD reigns.

**Psalm 95, which is the group's outlier**, has the flock-relation, the hearing condition, and the non-entry, and Chapter 26 worked it. Its opening at 95:3 belongs with the group: *ki ʾel gadol YHWH u-melekh gadol ʿal kol ʾelohim.* For the LORD is a great God and a great king above all gods.

**Four observations.**

**The formula is a perfect and the sense is contested.** *YHWH malakh* can be read as the LORD has become king, the LORD reigns, or the LORD is king, and the choice bears on whether these are enthronement psalms marking an annual accession or declarations of a standing sovereignty. This book does not adjudicate.

**Whatever the reading, the reign is asserted during the monarchy's currency in the corpus's arrangement.** These psalms stand in a Psalter that also contains Psalm 2, Psalm 45, Psalm 89, and Psalm 110. The corpus asserts both kingships and never states the relation between them.

**And the assertion converges with 1 Samuel 8:7.** Chapter 45 argued that the rejection at 8:7 leaves the sovereignty untouched and changes only its acceptance. The enthronement psalms assert the sovereignty in the strongest terms, in the same corpus, during the period of the human monarchy, with no acknowledgement that anything happened to it. That is the corpus supplying its own evidence for the reading.

**The group's characteristic verbs are all divine.** He reigns. He is clothed. He has girded. He has established. He sits enthroned. He comes to judge. He has made known his salvation. There is no human figure anywhere in Psalms 93, 96, 97, 98, or 99.

**And Psalm 98:9 and 96:13 both close on the same clause.** *Ki vaʾ li-shpoṭ ha-ʾareṣ, yishpoṭ tevel be-ṣedeq we-ʿammim be-meysharim.* For he comes to judge the earth; he will judge the world with righteousness and the peoples with equity.

The judging function that Psalm 72:1-4 asks God to give to the king is here performed by God directly, in two psalms three compositions apart, with no figure in either.

## 107. Psalm 8 and Psalm 144 · What a Man Is


Two psalms ask what a human being is and both answer in the vocabulary of grant.

**Psalm 8:5-7.** *Mah ʾenosh ki tizkerennu u-ven ʾadam ki tifqedennu. Wa-teḥasserehu meʿaṭ me-ʾelohim we-khavod we-hadar teʿaṭṭerehu. Tamshilehu be-maʿasey yadeykha, kol shattah taḥat raglaw.*

What is man that you remember him, and the son of man that you attend to him? Yet you have made him a little lower than *ʾelohim* and crowned him with glory and honour. You have made him rule over the works of your hands; you have put all things under his feet.

**Every verb has God as subject.** You remember. You attend. You have made him lack. You crown him. You make him rule. You have put.

**The vocabulary is royal.** *Kavod we-hadar*, glory and honour, is the pair used of the king at Psalm 21:6. *Tamshilehu*, you make him rule, is the causative of *mšl*, the verb Gideon refused at Judges 8:23. *Kol shattah taḥat raglaw* is the footstool image of Psalm 110:1 in different words.

**And the referent is generic.** *ʾEnosh* and *ben ʾadam*, man and son of man, in a psalm whose frame at 8:2 and 8:10 is *YHWH ʾadoneynu mah ʾaddir shimkha be-khol ha-ʾareṣ*, how majestic is your name in all the earth.

The corpus applies its royal conferral vocabulary to humanity as such, in a psalm about the moon and the stars and the beasts of the field, with God as the subject of every verb.

**Psalm 144:3-4 asks the same question and answers differently.** *YHWH mah ʾadam wa-tedaʿehu, ben ʾenosh wa-teḥashevehu. ʾAdam la-hevel damah, yamaw ke-ṣel ʿover.* LORD, what is man that you know him, the son of man that you think of him? Man is like a breath; his days are like a passing shadow.

**Same question, opposite answer, in one Psalter.** Psalm 8 crowns him. Psalm 144 makes him a breath. Book XIII does not count this among its ten pairs because the two are not contradictory propositions, but the juxtaposition is worth having: the corpus asks its anthropological question twice and gives two answers, and Psalm 144's superscription attributes it to David and its verses 10-11 are about delivering David from the sword.

**What this chapter adds to Book XI.** The conferral grammar is not confined to kings. Where the corpus states what a human being holds, in the most general terms it has, the verbs are the same verbs. That is the widest form of Chapter 62's finding and it suggests the grammar is a feature of how the corpus talks about creatures rather than a feature of how it talks about kings.

## 108. The Laments Over the Anointed


Chapter 74's census noted that several occurrences of *mashiaḥ* fall in laments. This chapter reads them, because a title used at the moment of its failure is being used in a way that tells against a triumphal reading of the vocabulary.

**Psalm 89:39.** *ʾAkh zanaḥta wa-timʾas, hitʿabbarta ʿim meshiḥekha.* You have cast off and rejected, you have been wroth with your anointed. The verb *mʾs* is 1 Samuel 8:7's and 1 Samuel 15:23's, and it is here applied by the psalmist to God's treatment of the anointed.

**Psalm 89:52.** *ʾAsher ḥerfu ʾoyveykha YHWH, ʾasher ḥerfu ʿiqvot meshiḥekha.* With which your enemies have reproached, LORD, with which they have reproached the footsteps of your anointed.

**Lamentations 4:20.** *Ruaḥ ʾappeynu meshiaḥ YHWH nilkad bi-shḥitotam, ʾasher ʾamarnu be-ṣillo niḥyeh va-goyim.*

The breath of our nostrils, the anointed of the LORD, was taken in their pits, of whom we said: under his shadow we shall live among the nations.

**That verse is the sharpest.** The title *meshiaḥ YHWH*, at its full strength with the divine possessive, applied to a king who has been captured in a pit. And the relative clause quotes the expectation that failed: *be-ṣillo niḥyeh va-goyim*, in his shadow we shall live among the nations.

The corpus preserves both the title and the quotation of the hope, in a book of laments over the destruction, and does not qualify either.

**Psalm 84:10.** *Maginnenu reʾeh ʾelohim we-habbeṭ pney meshiḥekha.* Behold our shield, God, and look upon the face of your anointed. A petition, which presupposes a situation requiring one.

**Psalm 132:10.** *Ba-ʿavur Dawid ʿavdekha ʾal tashev pney meshiḥekha.* For the sake of David your servant, do not turn away the face of your anointed.

**Habakkuk 3:13.** *Yaṣaʾta le-yeshaʿ ʿammekha, le-yeshaʿ ʾet meshiḥekha.* You went forth for the salvation of your people, for the salvation of your anointed. The anointed is the object of the salvation, not its agent.

**Six sites and a pattern.** In every one the anointed is the object of petition, of reproach, of capture, or of salvation. In not one is he the agent of a deliverance.

That is a distributional observation about a small field and it is offered at that weight. What it establishes is that the corpus's use of its central royal title includes, prominently, the title's use at the moments of the office's greatest failure, and that the corpus does not withdraw the title at those moments. Saul keeps it after the rejection, at fifteen sites. The captured king of Lamentations 4:20 keeps it in the pit.

A title that survives the failure of its bearer is a title that names something other than the bearer's success. Chapter 63 said what: it names that something was applied by another.

## 109. What the Psalter Establishes


Six results.

**The royal psalms state the highest claims and state them as conferred.** Psalm 2:6-8, five conferral forms. Psalm 45:8, God your God has anointed you. Psalm 72:1, give the king your judgments. Psalm 89:20-28, eleven first-person divine verbs. Psalm 110:1-4, sit, I will make, the LORD has sworn. Psalm 132:11-17, I will set, I will cause to sprout, I have prepared.

**The Psalter contains the corpus's clearest assertion that the covenant failed**, at Psalm 89:39-46, in eleven second-person verbs, in the same psalm as the fullest statement of it.

**It contains a conditional attached to the throne**, at Psalm 132:12, that 2 Samuel 7 does not have.

**It contains the divine kingship asserted at full strength in six psalms with no human figure anywhere in them.**

**It applies the royal conferral vocabulary to humanity as such at Psalm 8.**

**And it uses the royal title most densely in laments over the office's failure.**

Two closing observations.

**The Psalter is the strongest evidence against this book's reading and it is also, read for its verbs, the strongest evidence for it.** That is not a paradox. The exaltation and the conferral are two properties of the same sentences, and a reader who takes only the first has taken half of what is there.

**And the Psalter contains the corpus's other use of *menuḥati*.** Psalm 95:11 says they did not enter my rest. Psalm 132:14 says this is my resting place forever, here I will dwell. Two psalms, one word, one divine suffix, and two statements: the place is unentered, and the one whose place it is dwells there. The corpus states both and reconciles neither, which by now is the expected finding.

:::book XII | THE PROPHETS AND THE FIGURE


## 110. Reading the Prophets Book by Book


The prophetic corpus is where the messianic material is usually sought and it is the body this book has drawn on most heavily without yet treating systematically. This book of chapters surveys it, prophet by prophet, asking one question of each: what does this book say about a coming figure, and in what grammar.

The survey is not exhaustive. It takes the passages a reader would expect and it names the ones it omits. Its purpose is to establish whether the pattern of Books VI, VIII, and X holds across the prophetic corpus as a whole or only in the passages this book has selected.

Three procedural notes.

**The books are taken in canonical order**, Isaiah through Malachi, with the Twelve treated as a group and its members taken individually where they carry relevant material.

**Where a book carries nothing, that is reported.** Several prophetic books contain no royal-figure material at all and the silence is a datum.

**And where a passage is contested in its reference, the contest is named and the argument does not depend on the outcome.** Almost all of this material has been read in more than one way by serious readers over two millennia, and a survey that presented single readings as settled would be misrepresenting the field.

## 111. Isaiah · The Densest Field


Isaiah carries more royal-figure material than any other prophetic book and it carries it in three distinguishable groups.

**Group one, the Immanuel and throne-name material of chapters 7 through 11.**

7:14, *hinneh ha-ʿalmah harah we-yoledet ben we-qaraʾt shemo ʿImmanu ʾEl*. The sign is given to Ahaz in the context of the Syro-Ephraimite crisis and 7:16 dates its significance: before the child knows to refuse the evil and choose the good, the land of the two kings will be forsaken. The reference is contested at every level and this book takes no position. Note only the conferral form: *YHWH huʾ yitten lakhem ʾot*, the Lord himself will give you a sign, at 7:14a.

9:5-6, the throne-name, worked at Chapter 78. Two passives and a closing agent-clause.

11:1-9, the shoot, worked at Chapters 79 and 84. The spirit settles on him; the state at 11:9 is agentless.

**Group two, the servant material of chapters 42 through 53.**

42:1, *hen ʿavdi ʾetmokh bo beḥiri raṣetah nafshi, natatti ruḥi ʿalaw mishpaṭ la-goyim yoṣiʾ*. Behold my servant whom I uphold, my chosen in whom my soul delights; I have put my spirit upon him; he shall bring forth justice to the nations. Four divine verbs in the opening line: I uphold, I have chosen, my soul delights, I have put my spirit.

49:3, *wa-yoʾmer li ʿavdi ʾattah Yisraʾel ʾasher bekha ʾetpaʾar*, you are my servant, Israel, in whom I will be glorified. And 49:6, four verses later, *naqel mi-hyotekha li ʿeved le-haqim ʾet shivṭey Yaʿaqov*, it is too light a thing that you should be my servant to raise up the tribes of Jacob. The servant is named Israel at 49:3 and distinguished from the tribes at 49:6. The corpus states both and Book XIII counts the pair.

50:4-9, the servant who is taught: *ʾAdonay YHWH natan li leshon limmudim la-daʿat la-ʿut ʾet yaʿef davar, yaʿir ba-boqer ba-boqer yaʿir li ʾozen li-shmoaʿ ka-limmudim.* The Lord GOD has given me the tongue of the taught, to know how to sustain the weary with a word; morning by morning he wakens my ear to hear as the taught.

**That verse belongs in Book IV and is placed here.** The servant's ear is wakened by another, morning by morning, to hear. The deficit inventory addressed, in the servant, by a divine act, repeatedly.

52:13-53:12, the fourth song. Its opening is conferral: *hinneh yaskil ʿavdi yarum we-nissaʾ we-gavah meʾod*, behold my servant shall prosper, he shall be exalted and lifted up and be very high. Three verbs of elevation, two of them in forms that can be read as passive or as intransitive. And 53:12: *lakhen ʾaḥalleq lo va-rabbim we-ʾet ʿaṣumim yeḥalleq shalal*, therefore I will divide him a portion with the great, first person divine.

**Group three, Cyrus at 44:28 and 45:1**, worked at Chapter 71.

**And 42:19's blind servant**, worked at Chapter 34, which belongs to group two and which forecloses any triumphal reading of the servant material.

**The result for Isaiah.** Three groups, all of them stating what the figure holds with divine verbs, and one of them applying the deficit diagnostic to the figure himself.

## 112. Jeremiah · The Branch and the New Covenant


Jeremiah carries two bodies of relevant material and they sit in different registers.

**The Branch material**, at 23:5-6 and 33:14-16, worked at Chapter 90. *Wa-haqimoti* and *ʾaṣmiaḥ*, both first person divine.

**And 33:17-18 extends the promise to two offices**, which is the split of stage seven anticipated: *loʾ yikkaret le-Dawid ʾish yoshev ʿal kisseʾ veyt Yisraʾel, we-la-kohanim ha-Lewiyyim loʾ yikkaret ʾish mi-lefanay*, David shall never lack a man to sit on the throne of the house of Israel, and the levitical priests shall never lack a man before me. Two perpetual offices in two verses, with the priestly one stated in the same form as the royal.

**The Coniah oracle at 22:24-30 is the counter-testimony and Jeremiah supplies it himself.** *Ḥay ʾani neʾum YHWH ki ʾim yihyeh Konyahu ven Yehoyaqim melekh Yehudah ḥotam ʿal yad yemini ki mi-sham ʾettekekka.* As I live, though Coniah son of Jehoiakim king of Judah were the signet on my right hand, yet I would pluck you from there.

And 22:30: *kitvu ʾet ha-ʾish ha-zeh ʿariri gever loʾ yiṣlaḥ be-yamaw, ki loʾ yiṣlaḥ mi-zarʿo ʾish yoshev ʿal kisseʾ Dawid u-moshel ʿod bi-Yhudah.* Write this man down as childless, a man who shall not prosper in his days; for none of his seed shall prosper sitting on the throne of David and ruling again in Judah.

**And Haggai 2:23 restores the signet to Coniah's grandson.** *Ba-yom ha-huʾ neʾum YHWH ṣevaʾot ʾeqqaḥakha Zerubbavel ben Sheʾaltiʾel ʿavdi neʾum YHWH we-samtikha ka-ḥotam ki vekha vaḥarti.* In that day I will take you, Zerubbabel son of Shealtiel my servant, and make you as a signet, for I have chosen you.

The genealogy at 1 Chronicles 3:17-19 makes Zerubbabel the grandson of Jehoiachin, who is Coniah. Book XIII counts the pair, and notes that Haggai's verbs are three first-person divine ones: I will take, I will make, I have chosen.

**The new covenant at 31:31-34.** *Hinneh yamim baʾim neʾum YHWH we-kharatti ʾet beyt Yisraʾel we-ʾet beyt Yehudah berit ḥadashah.* And 31:33: *natatti ʾet torati be-qirbam we-ʿal libbam ʾekhtavennah, we-hayiti lahem le-ʾelohim we-hemmah yihyu li le-ʿam.* I will put my law within them and write it on their hearts, and I will be their God and they shall be my people.

And 31:34: *we-loʾ yelammedu ʿod ʾish ʾet reʿehu we-ʾish ʾet ʾaḥiw leʾmor deʿu ʾet YHWH, ki khullam yedʿu ʾoti le-miq-qaṭannam we-ʿad gedolam neʾum YHWH.* And they shall no longer teach each his neighbour and each his brother, saying, know the LORD, for they shall all know me from the least of them to the greatest.

**Chapter 82 used this passage and the point bears repeating here in its own book.** Jeremiah's answer to the deficit is a writing on the heart, with God as subject, and its stated result is a knowing that requires no teacher. There is no figure in the pericope. The Branch oracle stands eight chapters earlier and the two are never connected by the book.

## 113. Ezekiel · The Prince, and the Sanctuary in the Midst


Ezekiel's royal material has been worked at Chapters 28, 61, and 95. This chapter states the book's overall position.

**The book prefers *nasiʾ* to *melekh*.** Chapter 61 counted the occurrences. In the temple vision of chapters 40 through 48 the term is *nasiʾ* throughout: 44:3, 45:7-8, 45:16-17, 45:22, 46:2-18, 48:21-22.

**The prince's portion is assigned and bounded.** 45:7: *we-la-nasiʾ mi-zzeh u-mi-zzeh li-trumat ha-qodesh we-la-ʾaḥuzzat ha-ʿir*, and to the prince on one side and the other of the holy portion and of the possession of the city. His land is defined relative to the sanctuary's and the city's, and 45:8 states the purpose: *le-maʿan loʾ yonu ʿod nesiʾay ʾet ʿammi*, so that my princes shall no more oppress my people.

*Nesiʾay*, my princes, and *ʿammi*, my people. Both possessives on God, in the verse restricting the prince's holding.

**The prince brings his own offerings.** 45:22: *we-ʿasah ha-nasiʾ ba-yom ha-huʾ baʿado u-veʿad kol ʿam ha-ʾareṣ par ḥaṭṭaʾt.* On that day the prince shall prepare for himself and for all the people of the land a bull for a sin offering. The prince offers a sin offering for himself, which places him among those needing one.

**His movement in the sanctuary is regulated.** 46:2: he enters by the porch of the gate from outside and stands by the post of the gate; the priests prepare his offering; he worships at the threshold and goes out; the gate is not shut until evening. 46:8-10: he enters and goes out by the same way; the people entering by the north gate go out by the south. Whatever else the prince is, he is a man whose route through a building is prescribed.

**And 46:16-18 limits his estate.** He may give a gift to a son and it becomes the son's inheritance; a gift to a servant reverts at the year of liberty. And 46:18: *we-loʾ yiqqaḥ ha-nasiʾ mi-naḥalat ha-ʿam le-honotam me-ʾaḥuzzatam*, the prince shall not take of the people's inheritance to thrust them out of their possession.

**That verse is 1 Samuel 8:14 answered.** The bill at 1 Samuel 8:14 had the king taking the best fields and vineyards and olive groves. Ezekiel 46:18 forbids exactly that, using the same verb *lqḥ*, in the temple vision, of the prince. The corpus states the abuse and states its prohibition, four centuries apart in its own chronology, in one vocabulary.

**And the vision's final word is a name for a city.** 48:35: *u-shem ha-ʿir mi-yom YHWH shammah.* And the name of the city from that day: **the LORD is there.**

The book that most carefully bounds its prince's portion, route, and estate closes on a sentence naming the city for a divine presence.

## 114. Hosea, Amos, and Micah


**Hosea.** Chapter 50 worked 13:11's giving and taking in anger. Two further sites belong here.

3:5: *ʾaḥar yashuvu benei Yisraʾel u-viqshu ʾet YHWH ʾeloheyhem we-ʾet Dawid malkam, u-faḥadu ʾel YHWH we-ʾel ṭuvo be-ʾaḥarit ha-yamim.* Afterward the children of Israel shall return and seek the LORD their God and David their king, and shall come in fear to the LORD and to his goodness in the latter days.

Two objects of seeking, God and David, with God first and the fear-clause naming only God.

8:4: *hem himlikhu we-loʾ mimmenni, hesiru we-loʾ yadaʿti.* They made kings and not from me; they removed and I did not know. The book's position on the northern monarchies stated in one verse: made without divine appointment, and the corpus's word for that is *loʾ mimmenni*.

**Amos.** The book carries almost no royal-figure material, which is itself a datum for a prophet of the eighth century. Its one relevant passage is at the very end.

9:11: *ba-yom ha-huʾ ʾaqim ʾet sukkat Dawid ha-nofelet we-gadarti ʾet pirṣeyhen wa-harisotaw ʾaqim u-venitiha ki-mey ʿolam.* In that day I will raise up the booth of David that is fallen, and repair its breaches, and raise up its ruins, and build it as in the days of old.

**Four first-person divine verbs and no figure.** I will raise, I will repair, I will raise, I will build. The object is *sukkat Dawid*, the booth or hut of David, which is a diminutive: not a house, not a throne, a booth. And the whole restoration is stated with God as subject and no occupant named.

**Micah.** Chapter 99 worked 5:1-4. Two further observations.

3:11-12 is the book's indictment and it names three offices: *raʾsheyha be-shoḥad yishpoṭu we-khohaneyha bi-meḥir yoru u-neviʾeyha be-khesef yiqsomu*, her heads judge for a bribe, her priests teach for hire, her prophets divine for money. And 3:12: *ṣiyyon sadeh teḥaresh wi-Yrushalayim ʿiyyin tihyeh*, Zion shall be plowed as a field and Jerusalem shall become heaps.

And 6:8, which Chapter 3 used as the calibration case, stands three chapters later in the same book: what does the LORD require, and the answer contains no figure and no date.

**Micah therefore contains, in six chapters, the corpus's most specific naming of a birthplace and the corpus's cleanest figure-free statement of requirement.** The book holds both without relating them.

## 115. Zechariah and Haggai · The Post-Exilic Pair


The two prophets of the rebuilding carry the corpus's most concrete royal material, addressed to a named living man, and it is worth reading for that reason.

**Haggai.** Two oracles.

2:6-9: *ʿod ʾaḥat meʿaṭ hiʾ wa-ʾani marʿish ʾet ha-shamayim we-ʾet ha-ʾareṣ*, once more, in a little while, I will shake the heavens and the earth. And 2:9: *gadol yihyeh kevod ha-bayit ha-zeh ha-ʾaḥaron min ha-rishon ʾamar YHWH ṣevaʾot, u-va-maqom ha-zeh ʾetten shalom.* The glory of this latter house shall be greater than the former, and in this place I will give peace.

*ʾEtten shalom*, I will give peace, first person divine, with no figure in the clause.

2:23, the signet oracle to Zerubbabel, quoted at Chapter 112. Three first-person divine verbs.

**Zechariah.** Beyond the material at Chapters 80 and 90, two passages.

**4:6.** *Loʾ ve-ḥayil we-loʾ ve-khoaḥ ki ʾim be-ruḥi ʾamar YHWH ṣevaʾot.* Not by might nor by power but by my spirit, says the LORD of hosts. Addressed to Zerubbabel, the Davidic governor, in a book that also gives him the temple foundation and the plummet in his hand at 4:9-10.

**9:9.** *Gili meʾod bat Ṣiyyon hariʿi bat Yerushalayim, hinneh malkekh yavoʾ lakh ṣaddiq we-noshaʿ huʾ, ʿani we-rokhev ʿal ḥamor we-ʿal ʿayir ben ʾatonot.*

Rejoice greatly, daughter of Zion; shout, daughter of Jerusalem; behold, your king comes to you, righteous and **saved**, humble and riding on a donkey, on a colt the foal of a donkey.

**The participle at the centre of that verse is the datum.** *We-noshaʿ*, nifal of *yšʿ*, and the nifal is passive: saved, delivered, having been given victory. Not saving. The Septuagint and several English versions render it actively as saviour, and the Hebrew form does not support that. The corpus's most quoted announcement of an arriving king describes him as righteous and saved.

And the two adjectives beside it: *ʿani*, poor or humble, and the mount, a donkey rather than a horse. 9:10 completes it: *we-hikhratti rekhev me-ʾEfrayim we-sus mi-Yrushalayim we-nikhretah qeshet milḥamah*, and I will cut off the chariot from Ephraim and the horse from Jerusalem and the battle bow shall be cut off. First person divine, cutting off the instruments of war, in the verse after the king arrives on a donkey.

**And 9:10 closes on the terminus.** *We-dibber shalom la-goyim u-mosholo mi-yam ʿad yam.* And he shall speak peace to the nations, and his dominion from sea to sea.

*U-mosholo*, and his dominion, from *mšl*, the verb Gideon declined. The corpus's arriving king is saved, humble, mounted on a donkey, and his dominion is stated in the verb refused at Judges 8:23. The corpus is not shy of the connection and does not comment on it.

## 116. The Prophets Who Say Nothing


Several prophetic books contain no material about a coming royal figure, and a survey that reported only the books that do would be misrepresenting the field.

**Joel.** The book's subject is a locust plague, a call to repentance, the pouring out of the spirit at 3:1-2, and the day of the LORD. *We-hayah ʾaḥarey khen ʾeshpokh ʾet ruḥi ʿal kol basar we-nibbeʾu beneykhem u-venoteykhem*, I will pour out my spirit on all flesh and your sons and your daughters shall prophesy. First person divine, all flesh as recipient, and no figure anywhere in the book.

**Obadiah.** Twenty-one verses against Edom, closing at v. 21 with *we-ʿalu moshiʿim be-har Ṣiyyon li-shpoṭ ʾet har ʿEsaw, we-haytah la-YHWH ha-melukhah.* And saviours shall go up on Mount Zion to judge the mount of Esau, and the kingdom shall be the LORD's.

*Moshiʿim*, plural, saviours. And the closing clause assigns the kingdom to God. The book's one relevant sentence has a plural of deliverers and a divine kingship.

**Nahum.** Against Nineveh. No figure.

**Habakkuk.** The dialogue about the prosperity of the wicked, the Chaldeans, the woes, and the closing psalm. 3:13's *le-yeshaʿ meshiḥekha* is the one occurrence and Chapter 108 read it as an object of salvation. And 2:4's *we-ṣaddiq be-ʾemunato yiḥyeh*, the righteous shall live by his faithfulness, is the book's positive statement and it contains no figure.

**Zephaniah.** The day of the LORD, the judgment of the nations, and the closing at 3:14-17. *YHWH ʾelohayikh be-qirbekh gibbor yoshiaʿ*, the LORD your God is in your midst, a mighty one who saves. And 3:15: *melekh Yisraʾel YHWH be-qirbekh loʾ tirʾi raʿ ʿod*, the king of Israel, the LORD, is in your midst; you shall fear evil no more.

**The king of Israel is named and it is YHWH.** In a post-monarchic oracle of restoration, the corpus supplies a king and the king is God.

**Malachi.** The last book. It carries a messenger at 3:1, *hineni sholeaḥ malʾakhi u-finnah derekh le-fanay*, behold I send my messenger and he shall prepare the way before me, and 3:23, *hinneh ʾanokhi sholeaḥ lakhem ʾet ʾEliyyah ha-naviʾ lifney boʾ yom YHWH*, behold I send you Elijah the prophet before the coming of the great and terrible day of the LORD. Two sendings, both first person divine, and the figure sent is a messenger and a prophet rather than a king.

**The survey's result.** Of the twelve minor prophets, five carry no royal-figure material at all, one carries a plural of saviours and a divine kingship, one names the king of Israel as YHWH, and one sends a prophet. The concentration of royal-figure material in Isaiah, Jeremiah, Ezekiel, Micah, Zechariah, and Haggai is real and the distribution is uneven, and the uneven distribution is part of what the prophetic corpus is.

## 117. Daniel · The Aramaic Court and the Seventy Weeks


Daniel has been used at Chapter 81 for 7:13-14. This chapter takes the book's other relevant material and states what it does and does not settle.

**The four kingdoms.** Chapters 2 and 7, the statue and the beasts. In both the sequence ends in a divine act. 2:44: *u-ve-yomeyhon di malkhayyaʾ ʾinnun yeqim ʾelah shemayyaʾ malkhu di le-ʿalmin laʾ titḥabbal.* And in the days of those kings the God of heaven will set up a kingdom which shall never be destroyed. *Yeqim*, he will set up, with God as subject.

**And 2:34's stone.** *Ḥazeh hawayta ʿad di hitgezeret ʾeven di laʾ vidayin.* You watched until a stone was cut out **not by hands**. The passive *hitgezeret* and the qualifying phrase together specify that the agent is not human and is not named.

**The seventy weeks at 9:24-27.** Two occurrences of *mashiaḥ*, at 9:25 and 9:26, and the passage is among the most contested in the Hebrew Bible. Its numbers, its starting point, its punctuation, and the identity of its figures have been read in more ways than can be summarized. This book takes no position on any of it and uses the passage for nothing.

What can be said without entering the dispute is that 9:26's *yikkaret mashiaḥ we-ʾeyn lo*, an anointed one shall be cut off and have nothing, is a passive of a violent verb applied to a bearer of the title, and belongs with the laments of Chapter 108 as another site where the corpus uses the title at a moment of failure.

**Chapter 9's prayer is the book's longest continuous passage and it contains no figure.** 9:4-19 is a confession: we have sinned, we have done wickedly, we have rebelled, we have not listened to your servants the prophets. *Loʾ shamaʿnu* at 9:6, *we-loʾ shamaʿnu be-qol YHWH* at 9:10, *we-loʾ ḥillinu ʾet peney YHWH* at 9:13. The hearing failure of Book IV, confessed three times in the prayer that precedes the corpus's most contested messianic passage.

And 9:18's petition: *ki loʾ ʿal ṣidqoteynu ʾanaḥnu mappilim taḥanuneynu le-faneykha ki ʿal raḥameykha ha-rabbim*, for we do not present our supplications before you on the ground of our righteousness but on the ground of your great mercies.

**The result for Daniel.** The book's two great visions end in divine acts stated with God as subject or in the passive. Its longest prayer confesses a hearing failure. And its most contested passage uses the royal title of a figure who is cut off.

## 118. The Day of the LORD


The corpus's other great future-oriented motif is the day of the LORD, and it is worth setting beside the figure because it is more widely distributed and structurally different.

**The sites are numerous and span the prophetic corpus.** Amos 5:18-20, Isaiah 2:12 and 13:6-9, Joel 1:15 and 2:1-11 and 3:4 and 4:14, Obadiah 15, Zephaniah 1:7-18, Ezekiel 13:5 and 30:3, Malachi 3:23.

**Amos 5:18-20 is the earliest and it is a reversal.** *Hoy ha-mitʾawwim ʾet yom YHWH, lammah zeh lakhem yom YHWH, huʾ ḥoshekh we-loʾ ʾor.* Woe to you who desire the day of the LORD; why would you have it? It is darkness and not light. And 5:19: as if a man fled from a lion and a bear met him, or went into the house and leaned his hand on the wall and a serpent bit him.

The corpus's first extended treatment of the motif is a warning to people looking forward to it.

**Zephaniah 1:14-18 is the fullest description.** *Qarov yom YHWH ha-gadol qarov u-maher meʾod.* A day of wrath, of trouble and distress, of devastation and desolation, of darkness and gloom, of clouds and thick darkness, of trumpet and battle cry.

**And the day's characteristic grammar is that it has no human agent.** Across every site, what happens on the day is done by God or happens impersonally. The sun is darkened, the moon does not give its light, the stars withdraw their shining, the earth quakes, the heavens tremble. Where an agent is named it is YHWH: *ki gadol yom YHWH we-noraʾ meʾod u-mi yekhilennu*, at Joel 2:11, for the day of the LORD is great and very terrible, and who can endure it.

**Two structural observations for this book.**

**The day motif and the figure motif are largely disjoint in the corpus.** The passages that describe the day do not name a royal figure, and the passages that name a royal figure do not usually describe the day. Malachi 3:23 is the closest they come, sending Elijah before the day, and the figure sent there is a prophet.

**And the day is not a delivery.** It is stated as an arrival of God, or of God's action, and its characteristic effect on the hearers is that they cannot endure it. Amos 5:18's *lammah zeh lakhem yom YHWH* asks the audience why they want it, which presupposes that they do and implies they have misunderstood what it is.

That is a second corpus-internal case of the pattern Book VIII described: an expectation directed at an arrival, and a corpus responding by asking what the expectant party thinks the arrival will do for them.

## 119. What the Prophetic Survey Establishes


Five results.

**The pattern holds across the corpus and not only in the selected passages.** Every prophetic statement of what a coming figure holds, in Isaiah, Jeremiah, Ezekiel, Micah, Zechariah, and Haggai, states it with a divine verb or a passive. The survey found no exception, and it looked in the books where an exception would be most likely.

**The distribution is uneven and five of the Twelve carry nothing.** A reader whose impression is that the prophetic corpus is saturated with messianic expectation has an impression formed by selection, and the selection is ancient and understandable and is still a selection.

**Two prophetic books name a king and the king is God.** Zephaniah 3:15's *melekh Yisraʾel YHWH be-qirbekh*, and Obadiah 21's *we-haytah la-YHWH ha-melukhah*. Both are post-monarchic in setting.

**The corpus's direct remedies for the deficit are prophetic and contain no figure.** Jeremiah 31:33-34 writes on the heart and produces a universal knowing. Ezekiel 36:26-27 replaces the heart and puts a spirit within. Joel 3:1 pours the spirit on all flesh. Three passages, three books, one grammar, and no figure in any of them.

**And the corpus's most quoted arrival-announcement describes the arriving king with a passive participle.** Zechariah 9:9's *we-noshaʿ*, saved.

One closing note. This book of chapters has been a survey rather than an argument, and its value is exactly that it looked systematically rather than selectively. The reading of Books VI through XI was built from passages this book chose. Book XII asked whether the pattern survives being tested against the whole prophetic corpus including the parts that were not chosen. It does, and the strongest single piece of evidence for that is Zechariah 9:9, which was not part of the original reading and which turned out on inspection to carry a passive participle at its centre.

:::book XIII | WHAT THE CORPUS PRESERVES


## 120. Jeremiah 8:8 · The Scribes Indicted, the Deposit Held


*ʾEykhah tomeru ḥakhamim ʾanaḥnu we-torat YHWH ʾittanu, ʾaken hinneh la-sheqer ʿasah ʿeṭ sheqer soferim.*

How do you say, we are wise and the law of the LORD is with us, when behold, the false pen of the scribes has made it into a lie?

**Two philological points are contested and both are carried as contested.**

**The referent of *soferim*.** The word can mean manuscript copyists or a teaching class with a professional function. Both readings have long support.

**The parsing of *ʿasah*.** It can be read with *ʿeṭ sheqer*, the false pen, as subject: the false pen of the scribes has made it a lie. Or *ʿasah* can be taken with a different subject or in a different construction, and the versions diverge.

**This book takes no side, because the argument holds under every combination.** Both readings of *soferim* place the fault at the carriage, and neither places it at the deposit. And *we-torat YHWH ʾittanu*, the law of the LORD is with us, stands in the same sentence under every parsing.

**That clause is the datum.** The verse is an indictment and its target is the handling. What is not indicted, and what the verse's own quoted claim asserts, is that the thing is in hand.

**Two parallel indictments in other books carry the identical shape at the priestly office.**

**Ezekiel 22:26.** *Kohaneyha ḥamesu torati wa-yeḥallelu qodashay, beyn qodesh le-ḥol loʾ hivdilu u-veyn ha-ṭameʾ le-ṭahor loʾ hodiʿu.* Her priests have done violence to my law and profaned my holy things; they have made no distinction between the holy and the common, nor taught the difference between the unclean and the clean.

*Torati*, my law, with the divine possessive, in the verse that indicts the priests for violence against it. The thing violated remains God's.

**Malachi 2:7-8.** *Ki siftey khohen yishmeru daʿat we-torah yevaqshu mi-pihu ki malʾakh YHWH ṣevaʾot huʾ. We-ʾattem sartem min ha-derekh, hikhshaltem rabbim ba-torah, shiḥattem berit ha-Lewi.* The lips of a priest should guard knowledge, and men should seek instruction from his mouth, for he is the messenger of the LORD of hosts. But you have turned aside from the way; you have caused many to stumble by the instruction; you have corrupted the covenant of Levi.

Same shape a third time: the office stated at its proper function, the office indicted for failing it, and the deposit named as intact.

**And Deuteronomy 4:2 and 13:1 belong here.** *Loʾ tosifu ʿal ha-davar ʾasher ʾanokhi meṣawweh ʾetkhem we-loʾ tigreʿu mimmennu.* You shall not add to the word which I command you, nor take from it.

**A prohibition on adding and subtracting is issued where adding and subtracting are anticipated.** That is the same inference as Chapter 58's about the law of the king: a guard erected against an impossibility is not a guard. The corpus expects tampering and legislates against it, twice, in one book.

**What this establishes for Book XIII.** The corpus indicts its own transmitting offices three times, in three books, and in every case names the deposit as held. That is a corpus with a specific and unusual relation to its own custodians, and it is the relation that makes the ten pairs of the next chapters legible.

## 121. Ten Pairs · The First Five


The corpus states ten propositions on both ends and resolves neither end. This chapter takes five and the next takes five.

**Pair one. Deuteronomy 23:4-7 against Ruth 4:18-22 and 1 Kings 14:21.**

The bar: *loʾ yavoʾ ʿAmmoni u-Moʾavi bi-qhal YHWH gam dor ʿasiri loʾ yavoʾ lahem bi-qhal YHWH ʿad ʿolam.* No Ammonite or Moabite shall enter the assembly of the LORD, even to the tenth generation, forever.

The seating: Ruth 4:18-22 gives the genealogy Perez to David and runs it through Boaz, whose wife is Ruth *ha-Moʾaviyyah*, the Moabitess, so designated five times in the book. And 1 Kings 14:21 names Rehoboam's mother *Naʿamah ha-ʿAmmonit*, the Ammonitess, repeated at 14:31.

Both barred nations, both inside the Davidic line, both designated by nationality at the point of seating.

**Pair two. Jeremiah 22:24-30 against Haggai 2:23.**

The plucking: though Coniah were the signet on my right hand, I would pluck you from there; write this man childless.

The restoration: I will take you, Zerubbabel, and make you as a signet, for I have chosen you.

Same image, opposite direction, two generations apart in the genealogy at 1 Chronicles 3:17.

**Pair three. Isaiah 49:3 against Isaiah 49:6.**

*ʿAvdi ʾattah Yisraʾel*, you are my servant, Israel, at 49:3.

*Naqel mi-hyotekha li ʿeved le-haqim ʾet shivṭey Yaʿaqov*, it is too light a thing that you should be my servant to raise up the tribes of Jacob, at 49:6.

The servant is named Israel and given a mission to Israel, four verses apart, in one oracle.

**Pair four. Jeremiah 7:22 with 1 Samuel 15:22, Hosea 6:6, Isaiah 1:11, against Ezekiel 40 through 48.**

Jeremiah 7:22: *ki loʾ dibbarti ʾet ʾavoteykhem we-loʾ ṣiwwitim be-yom hoṣiʾi ʾotam me-ʾereṣ Miṣrayim ʿal divrey ʿolah wa-zavaḥ.* I did not speak to your fathers nor command them in the day I brought them out of Egypt concerning burnt offerings and sacrifices.

1 Samuel 15:22: *hinneh shemoaʿ mi-zevaḥ ṭov*, to obey is better than sacrifice.
Hosea 6:6: *ki ḥesed ḥafaṣti we-loʾ zavaḥ*, I desire covenant loyalty and not sacrifice.
Isaiah 1:11: *lammah li rov zivḥeykhem*, what to me is the multitude of your sacrifices.

Against them, Ezekiel's temple vision restores the whole apparatus in detail, with the prince's six lambs and a ram without blemish on the sabbath at 46:4, and the offerings specified through chapters 45 and 46.

**Pair five. Judges 8:23 and 1 Samuel 8:7 against 1 Chronicles 29:23.**

Kingship refused, and the demand for it named a rejection of the divine reign. And a king seated on the throne of the LORD.

Chapters 42, 45, and 53 worked all three.

## 122. Ten Pairs · The Second Five


**Pair six. 1 Samuel 8:11-18 against Psalm 45:7.**

The itemized prosecution: your sons, your daughters, your fields, your vineyards, your olive groves, a tenth, a tenth, your servants, your best young men, your donkeys, and you shall be his servants.

And a king's throne addressed as *ʾelohim*, forever and ever.

The same institution, prosecuted in one book and exalted in another, in one canon.

**Pair seven. Numbers 25:12-13 and Ezekiel 44:15 against Psalm 110:4.**

The Aaronide grant: *hineni noten lo ʾet beriti shalom, we-haytah lo u-le-zarʿo ʾaḥaraw berit kehunnat ʿolam*, a covenant of perpetual priesthood to Phinehas and his seed. And Ezekiel 44:15's restriction of temple service to the sons of Zadok.

Against them, a perpetual priesthood conferred by divine oath on a non-Aaronide and pre-Israelite order.

**Pair eight. Deuteronomy 7:1-3 and Exodus 34:15-16 against the ancestry.**

The prohibition: *we-loʾ titḥatten bam, bittekha loʾ titten li-vno u-vitto loʾ tiqqaḥ li-vnekha.* You shall not intermarry with them.

Against it, the line and its neighbours run through the barred nations in seven instances across three registers, which Chapter 123 sets out.

**Pair nine. Job 14:8 against Isaiah 11:1.**

The stump dies in the dust. A shoot comes from the stump.

Chapter 88 stated the objection to this one and it is the most contestable of the ten.

**Pair ten. Psalm 23:1 with 2 Samuel 5:2 against Ezekiel 34:24.**

The king says the LORD is my shepherd. The elders say you shall shepherd my people. And Ezekiel has David a prince in their midst while God remains their God, with the flock called *ṣoʾni* eleven times in the chapter.

**Three further pairs belong in the count and are recorded here rather than promoted, because ten is a convenient number and the corpus does not stop at it.**

**Psalm 132:12's conditional against 2 Samuel 7:15's bar on withdrawal.** Chapter 105.

**1 Samuel 8:18's unanswered outcry against Psalm 72:12's king who delivers the needy when he cries.** Chapter 103.

**And 2 Kings 10:30's approval of Jehu's bloodshed against Hosea 1:4's visiting of that blood on his house.** Chapter 69.

**Thirteen pairs.** The number is not the point. The point is the habit.

## 123. The Line Seated Through the Standing Bar


Pair eight requires its own chapter because the instances are numerous and the corpus quotes its own prohibition at the breach.

**Four instances stand inside the Davidic line as Ruth 4:18-22 enumerates it.**

**Judah**, at the head of the genealogy. Genesis 38:2 has him take *bat ʾish Kenaʿani u-shemo Shuaʿ*, the daughter of a Canaanite man named Shua. Her sons Er and Onan die and Shelah is not the line. The line routes instead through Tamar, whose origin the corpus does not supply, in the episode at Genesis 38 that produces Perez, and Ruth 4:18 begins the genealogy at Perez.

**Boaz through Ruth**, designated *ha-Moʾaviyyah* at Ruth 1:22, 2:2, 2:21, 4:5, and 4:10.

**David through the household of Uriah**, designated *ha-Ḥitti*, the Hittite, at 2 Samuel 11:3, 11:6, 11:17, 11:21, 11:24, 12:9, 12:10, 23:39, and 1 Kings 15:5. Bathsheba is introduced as his wife and the corpus repeats his nationality nine times.

**Solomon**, whose successor at 1 Kings 14:21 is the son of Naamah the Ammonitess.

**Three instances stand outside the Davidic line.**

**Ishmael through Hagar *ha-Miṣrit***, the Egyptian, at Genesis 16:1, 16:3, 21:9, and 25:12.

**Joseph through Asenath *bat Poṭi-Feraʿ khohen ʾOn***, daughter of Potiphera priest of On, at Genesis 41:45 and 46:20. The mother of Ephraim and Manasseh is the daughter of an Egyptian priest and the corpus states his office.

**Moses through Zipporah**, daughter of the priest of Midian, and through *ha-ʾishah ha-Kushit* at Numbers 12:1. And in that episode **the objectors are rebuked and the marriage is not**. Miriam and Aaron speak against Moses because of the Cushite woman; the LORD comes down in a pillar of cloud; Miriam becomes leprous. Nothing in the chapter says the marriage was wrong and the chapter's argument at 12:6-8 is about Moses's prophetic standing.

**And 1 Kings 11:2 quotes the prohibition verbatim at the point of the breach.**

*Min ha-goyim ʾasher ʾamar YHWH ʾel benei Yisraʾel loʾ tavoʾu vahem we-hem loʾ yavoʾu vakhem, ʾakhen yaṭṭu ʾet levavkhem ʾaḥarey ʾeloheyhem.* From the nations concerning which the LORD said to the children of Israel, you shall not go among them, neither shall they come among you, for surely they will turn away your heart after their gods.

**The corpus is therefore neither unaware nor approving.** It bars. It records the breach as a breach and quotes the bar while doing so. And it continues the line through it.

That combination is the datum. A tradition editing for consistency would have removed the bar, removed the designations, or removed the genealogy. This one keeps all three and prints the prohibition at the moment of its violation.

## 124. What Israel Holds Is Recorded as Received


Chapter 57 set out the four transfers. This chapter states what the pattern is evidence for.

**The four.** A standing priestly order from Melchizedek. A divine title from the same encounter, taken onto Abram's oath four verses later with the Name prefixed. An administrative procedure from Jethro, with Moses recorded as listening to the voice of his father-in-law. And the sanctuary's ground from Ornan the Jebusite, bought at a named price with David refusing to offer what cost him nothing.

**A fifth belongs with them and is not usually counted.** The alphabet and the language are Canaanite, and the corpus knows it: Isaiah 19:18 calls Hebrew *sefat Kenaʿan*, the language of Canaan.

**And a sixth is arguable and is recorded at low confidence.** The temple's construction is executed with Tyrian labour and materials, and 1 Kings 5 records the treaty with Hiram and 1 Kings 7:13-14 names Hiram the craftsman as the son of a widow of Naphtali and a Tyrian father, a worker in bronze.

**What the pattern shows.** In each case the corpus could have concealed the source and did not. It could have given the priestly order no antecedent, had Abram coin the divine title, had Moses devise the judiciary, made the threshing floor ancestral land, and said nothing about the language.

**And the pattern converges with Books VI and X from a different direction.** Those books found the corpus stating what a king holds as received from God. This chapter finds the corpus stating what the nation holds as received from its neighbours. The two are different claims about different objects and they share a shape: a habit of recording provenance where a tradition optimizing for prestige would not.

**Two disciplinary notes.**

**The observation is about the corpus's narration, not about historical dependence.** Whether Israelite institutions historically derive from Canaanite, Midianite, or Egyptian ones is a question for archaeology and comparative religion. The claim here is about what the received text records.

**And the observation is not a claim of unique virtue.** Other traditions record borrowings too. What is being noted is that this corpus does it repeatedly, in the case of its most sacred institutions, and at points where concealment would have been easy.

## 125. A Tradition Operating by Deletion Does Not Preserve Its Own Prosecution


Book XIII closes on the inference the preceding chapters support.

**The evidence.** Thirteen pairs, each stated on both ends and resolved by neither. Three indictments of the corpus's own transmitting offices with the deposit named as intact in each. Seven instances of the ancestry running through a standing bar with the bar quoted at the breach. Six recorded receipts from outside. And, from Book V, the itemized prosecution of the monarchy preserved on the same scroll as the royal psalms.

**The inference.** A tradition operating by deletion does not preserve its own prosecution thirteen times.

That is a claim about editorial behaviour and it should be stated carefully because it can be inflated in two directions.

**It does not establish that nothing was ever removed.** Deuteronomy 4:2's prohibition on adding and subtracting is evidence that both were anticipated, and Jeremiah 8:8 is evidence that the corpus itself alleged tampering. The claim is not that the corpus is unedited.

**It does not establish that the corpus is true.** A retained contradiction is evidence of an editorial policy, not of accuracy about anything.

**What it does establish** is that the corpus's characteristic response to material that tells against its own institutions is retention rather than removal, and that this response is repeated often enough to be a habit rather than an accident.

**Three consequences for the argument of this book.**

**The final form is a reliable object of study for a question about what the corpus says.** If the assembly is retentive, then what is in it is evidence about what the tradition held rather than about what a redactor wanted the tradition to appear to hold.

**The retained tensions are not problems to be solved.** Chapter 39 declined to resolve the hardening problem and this chapter supplies the general form of that decision. Where the corpus states two things and reconciles neither, a reader who reconciles them has added something. That addition may be right and it is an addition.

**And this book's own reading is subject to the same standard.** Chapter 108 will say so under the heading of limits. A book that extracts a single coherent position from a corpus that declined to state one has done something the corpus did not do, and the honest form of that is to name it rather than to present the extraction as a discovery.

One closing observation. The habit has a cost and the corpus pays it. A retentive tradition is harder to use. It cannot be quoted cleanly on the monarchy, on sacrifice, on the priesthood, on intermarriage, or on the fate of a stump, because it says two things about each. Every reader of it, ancient and modern, has had to choose, and every choosing has been an interpretation. That is the situation the whole history of reading this corpus has taken place inside, and it is a situation the corpus created for itself and did not have to.

:::book XIV | THE TORAH'S OWN FIGURES


## 126. Why the Torah Is Read Last


The Torah stands first in the corpus and is read last in this book, and the ordering is deliberate.

The Torah's royal-figure material is sparse, contested at every site, and has been read through the later material for so long that a reader coming to it first will bring the later readings with them. Reading it after Books III through XIII means arriving with a vocabulary drawn from the corpus's own later usage, which is the only vocabulary this book has authority to use.

**Four passages are conventionally counted as the Torah's messianic material.** Genesis 3:15, Genesis 49:10, Numbers 24:17, and Deuteronomy 18:15. The fourth is treated at Excursus XII and set aside. The first three are taken here.

**A fifth body belongs with them and is usually not counted**: the patriarchal promises, which are the Torah's actual future-oriented material and which contain no figure at all.

**And a sixth observation frames the whole.** The Torah is where the terminus vocabulary is established, at Genesis 2:2, Exodus 20:11, Leviticus 25 and 26, and Deuteronomy 12:9. It is also where the deficit is first stated, at Deuteronomy 29:3. And it is where the law of the king anticipates the demand, at Deuteronomy 17:14. The Torah supplies Books III, IV, and V with their foundations and supplies Book VIII with almost nothing.

That asymmetry is a datum about the corpus's arrangement and it is the reason this book of chapters is short.

## 127. Genesis 3:15 · The Seed and the Heel


*We-ʾeyvah ʾashit beynkha u-veyn ha-ʾishah u-veyn zarʿakha u-veyn zarʿah, huʾ yeshufkha roʾsh we-ʾattah teshufennu ʿaqev.*

And I will put enmity between you and the woman, and between your seed and her seed; he shall bruise you on the head and you shall bruise him on the heel.

**The verse's messianic reading is ancient and this book does not adjudicate it.** What can be said from the Hebrew is limited and is set out here.

**The subject of the first verb is God.** *ʾEyvah ʾashit*, I will put enmity. The whole arrangement is stated as a divine act, using the same verb *šyt* as Psalm 110:1's *ʿad ʾashit ʾoyveykha hadom le-ragleykha*, until I make your enemies a footstool.

**The noun *zeraʿ* is collective and singular in form.** It takes singular agreement throughout the corpus even where it plainly means descendants, as at Genesis 13:16 and 22:17. So the singular pronoun *huʾ* at 3:15b is grammatically expected and does not by itself establish an individual referent. It also does not exclude one.

**The verb *šwf* occurs three times in the Hebrew Bible** and its sense is uncertain. Genesis 3:15 twice, and Job 9:17, *ʾasher bi-seʿarah yeshufeni*, who crushes me with a tempest, and Psalm 139:11, *ʾakh ḥoshekh yeshufeni*, where the sense may be different. The corpus is using a rare verb and using it twice in one clause, with the same verb for both parties.

**The symmetry is the striking feature.** *Huʾ yeshufkha roʾsh we-ʾattah teshufennu ʿaqev.* One verb, two subjects, two body-parts. The asymmetry, if there is one, is entirely in the anatomy: a head-wound and a heel-wound are not equivalent injuries. That asymmetry is real and it is not in the verbs.

**What this book takes.** The enmity is instituted by a divine act stated in the first person. Beyond that the verse is too contested and too lexically uncertain to carry an argument, and no argument in this book rests on it.

## 128. Genesis 49:10 · Shiloh, and the Sceptre


*Loʾ yasur sheveṭ mi-Yhudah u-meḥoqeq mi-beyn raglaw ʿad ki yavoʾ Shiloh we-lo yiqqehat ʿammim.*

The sceptre shall not depart from Judah, nor the ruler's staff from between his feet, until Shiloh comes; and to him shall be the obedience of the peoples.

**Every clause of that verse is contested.**

*Shiloh* is the crux. The consonantal text *šylh* has been read as a place name, as *shelo*, that which is his, as *shay lo*, tribute to him, as a personal name, and as a corruption. The versions diverge. There is no settled reading.

*Yiqqehat* is a hapax and its sense is inferred from context and from a possible Arabic cognate.

*Meḥoqeq* can be the ruler's staff or the ruler himself; the participle of *ḥqq*, to inscribe or decree, is used both ways.

**This book uses the verse for nothing** and says so plainly rather than offering a reading and then hedging it.

**Two observations that do not require settling the crux.**

**The verb *swr*, to depart, is the verb of 2 Samuel 7:15.** *We-ḥasdi loʾ yasur mimmennu*, my covenant loyalty shall not depart from him. The same root, in the same negative construction, of a thing not departing from a Judahite line. Whether the connection is deliberate is unknowable and the shared vocabulary is a fact.

**And the blessing is a father's deathbed speech, not an oracle.** Genesis 49:1: *heʾasfu we-ʾaggidah lakhem ʾet ʾasher yiqraʾ ʾetkhem be-ʾaḥarit ha-yamim*, gather and I will tell you what shall befall you in the latter days. The frame is a testament, and the other eleven sayings in the chapter are a mixture of blessing, curse, and geographical prediction, several of them unflattering. Reuben is unstable as water. Simeon and Levi are cursed for their anger. Issachar is a strong ass couching between the burdens. Reading Judah's saying as categorically different in kind from its eleven neighbours is a decision, and this book makes no decision about it.

## 129. Numbers 24:17 · The Star and the Sceptre


*ʾErʾennu we-loʾ ʿattah, ʾashurennu we-loʾ qarov; darakh kokhav mi-Yaʿaqov we-qam sheveṭ mi-Yisraʾel u-maḥaṣ paʾatey Moʾav we-qarqar kol benei Shet.*

I see him, but not now; I behold him, but not near. A star shall come forth from Jacob and a sceptre shall rise from Israel, and shall crush the corners of Moab and destroy all the sons of Sheth.

**The speaker is Balaam**, a foreign diviner hired to curse Israel, whose donkey has spoken to him three chapters earlier. That is the corpus's setting for its clearest Torah statement of a coming ruler and it is worth registering.

**The immediate reference is military and directional.** Moab crushed, the sons of Sheth destroyed, Edom and Seir dispossessed at 24:18, and 24:19's *we-yerd mi-Yaʿaqov we-heʾevid sarid me-ʿir*. The oracle names neighbouring peoples and their defeat.

**The star and the sceptre are a pair of images and both are stated with intransitive verbs.** *Darakh kokhav*, a star treads or comes forth. *We-qam sheveṭ*, and a sceptre rises. No agent causes either. They come forth and rise.

**The temporal frame is a distancing.** *We-loʾ ʿattah*, and not now. *We-loʾ qarov*, and not near. Balaam's own framing places the vision at a remove.

**Two observations.**

**The oracle is spoken by an outsider and the corpus records it as true.** Numbers 23:5 and 23:16 have God putting a word in Balaam's mouth, and 24:2 has the spirit of God coming upon him. The Torah's clearest statement of a rising sceptre is delivered by a hired foreign diviner under divine compulsion.

That is not a diminishment. It belongs with Chapter 57's pattern of acknowledged receipt and with Chapter 71's Cyrus: the corpus repeatedly puts significant material in foreign mouths and does not hide the provenance.

**And the oracle's content is a conquest, not a terminus.** Nothing in Numbers 24:17-19 addresses the heart, the eyes, the ears, the knowledge, or the rest. It is an oracle of military supremacy over named neighbours.

## 130. The Patriarchal Promises · The Torah's Actual Future Material


The Torah's sustained future-oriented material is the promise to the patriarchs, and it contains no figure.

**Genesis 12:1-3.** Go from your country to the land that I will show you. And I will make of you a great nation, and I will bless you and make your name great, and be a blessing. And I will bless those who bless you and curse him who curses you, and in you all the families of the earth shall be blessed.

**Count the first-person divine verbs.** I will show. I will make. I will bless. I will make great. I will bless. I will curse. Six, in three verses, with Abram as recipient.

**Genesis 15:5-6.** Look toward heaven and number the stars if you are able to number them; so shall your seed be. *We-heʾemin ba-YHWH wa-yaḥsheveha lo ṣedaqah.* And he believed in the LORD, and he counted it to him as righteousness.

**Genesis 15:18.** *Ba-yom ha-huʾ karat YHWH ʾet ʾAvram berit leʾmor, le-zarʿakha natatti ʾet ha-ʾareṣ ha-zoʾt.* On that day the LORD made a covenant with Abram, saying, to your seed I have given this land. The verb is perfect: I have given.

**And the covenant-cutting ceremony at 15:9-17 has the smoking fire-pot and flaming torch passing between the pieces alone.** Abram is in a deep sleep, *tardemah*, and a great darkness. The party that passes between the divided animals in the corpus's covenant ceremony is the divine one, and Abram sleeps through it.

**Genesis 17:1-8.** The covenant restated with circumcision as its sign, the name changed from Abram to Abraham, and 17:8's *we-natatti lekha u-le-zarʿakha ʾaḥareykha ʾet ʾereṣ megureykha ... la-ʾaḥuzzat ʿolam*, and I will give to you and your seed after you the land of your sojournings for an everlasting possession.

**Genesis 22:16-18**, after the binding: *bi nishbaʿti neʾum YHWH*, by myself I have sworn. And the blessing multiplied, and 22:18's *we-hitbarakhu ve-zarʿakha kol goyey ha-ʾareṣ ʿeqev ʾasher shamaʿta be-qoli*, and in your seed all the nations of the earth shall be blessed, **because you have obeyed my voice.**

*ʿEqev ʾasher shamaʿta be-qoli.* Because you listened to my voice. The hearing of Book IV, performed, and stated as the ground of the promise's confirmation.

**The result for Book XIV.** The Torah's future material is a promise of land, descendants, and blessing to the nations, stated in first-person divine verbs, with a human party who believes, who sleeps through the covenant ceremony, and who is commended for having listened. There is no royal figure anywhere in it.

## 131. The Blessing of the Nations, and Its Grammar


Four times the Torah states that the nations will be blessed through Abraham's line and the grammar of the verb is contested each time.

**Genesis 12:3.** *We-nivrekhu vekha kol mishpeḥot ha-ʾadamah.* Nifal.
**Genesis 18:18.** *We-nivrekhu vo kol goyey ha-ʾareṣ.* Nifal.
**Genesis 22:18.** *We-hitbarakhu ve-zarʿakha kol goyey ha-ʾareṣ.* Hitpael.
**Genesis 26:4**, to Isaac, and **Genesis 28:14**, to Jacob, repeat the formula.

**The contest.** The nifal can be passive, shall be blessed, or reflexive, shall bless themselves. The hitpael is more naturally reflexive. On the passive reading the line is a channel of blessing to the nations. On the reflexive reading the nations will invoke Abraham's name in blessing themselves, as at Genesis 48:20's *bekha yevarekh Yisraʾel*, by you Israel will bless.

**This book takes no position** and notes that the two readings differ substantially in what they claim about the line's function.

**What holds under both.** The blessing's source is stated in every instance as God, and the line is the location or the instance rather than the agent. Even on the strongest passive reading, *nivrekhu vekha* is blessed **in you**, a prepositional phrase, not blessed **by you**.

**And the corpus supplies its own gloss at Genesis 22:18.** *ʿEqev ʾasher shamaʿta be-qoli*, because you listened to my voice. The blessing's confirmation is grounded in a hearing.

That is the Torah's one statement connecting the promise to the nations with the faculty Book IV traced, and it grounds the connection in the patriarch's hearing rather than in any figure's action.

## 132. What the Torah Establishes and What It Does Not


**What it establishes**, and each is worked in an earlier book.

The terminus, named at Genesis 2:2 in the cessation root, restated at Exodus 20:11 in the settling root, legislated at three scales in Leviticus 25, and stated as the promise's object at Deuteronomy 12:9.

The deficit, at Deuteronomy 29:3, in three organs, immediately after a recitation of forty years of signs.

The mechanism, at Deuteronomy 8:12-14: satisfied, heart lifted, forgot.

The criterion, at Deuteronomy 30:11-14 and 10:12-13, performed by the corpus itself.

The choice, at Deuteronomy 30:19.

The law of the king, at Deuteronomy 17:14-20, conditioned on a demand and containing four prohibitions and one positive requirement, which is a copying.

The anointing rite, at Exodus 29:7 and Leviticus 8:12, priestly and prior to any king.

And the covenant formula, at Exodus 6:7 and Leviticus 26:12, which Ezekiel 36:28 and 37:23 will use to close their restoration sequences.

**What it does not establish.**

No royal figure of the kind Books VIII and XII trace. The three candidate passages are contested at every level: Genesis 3:15's verb is a hapax-adjacent rarity and its referent is a collective noun, Genesis 49:10's crux is unsolved, and Numbers 24:17 is an oracle of military supremacy spoken by a foreign diviner.

**And the asymmetry is the chapter's finding.** The Torah supplies the terminus, the deficit, the mechanism, the criterion, the choice, and the constitutional restraint on kingship. It supplies almost nothing to the escalation.

That distribution is what a reader would expect if the escalation is, as Book VIII argued, a response to the failure of a monarchy the Torah anticipates and regulates rather than establishes. It is not what a reader would expect if the royal figure were the corpus's organizing centre from its opening.

The observation is offered at that weight. Distribution arguments are weak, the Torah is not the corpus's earliest material on any account, and a reader who holds that the messianic expectation was always implicit will not be moved by a count of explicit passages. What the count establishes is where the explicit passages are, which is a fact about the received arrangement.

:::book XV | THE SILENCES


## 133. What the Wisdom Books Do Not Say


Proverbs, Job, Ecclesiastes, and Song of Songs contain no messianic material. That is a large silence in a large body of writing and it deserves a chapter rather than an omission.

**Proverbs.** Thirty-one chapters. Kings appear constantly and always as present institutions to be advised, feared, or observed: 16:10-15, 20:2, 20:8, 20:26, 20:28, 21:1, 25:2-7, 29:4, 29:14, 31:1-9. Not one passage anticipates a coming king.

**And the book's statements about kingship are conditional and moral.** 16:12: *toʿavat melakhim ʿasot reshaʿ ki vi-ṣdaqah yikkon kisseʾ*, it is an abomination to kings to do wickedness, for the throne is established by righteousness. 29:14: *melekh shofeṭ be-ʾemet dallim kisʾo la-ʿad yikkon*, the king who judges the poor with truth, his throne shall be established forever.

The permanence of a throne is stated conditionally in Proverbs and unconditionally in 2 Samuel 7. The corpus carries both.

**Job.** Forty-two chapters on suffering, justice, and the limits of human understanding, with no royal figure and no future expectation of one. Its one contribution to this book is the tree of 14:7-9.

**And Job's answer is a whirlwind, not a deliverer.** Chapters 38 through 41 are a divine speech consisting almost entirely of questions about the natural world, and the resolution at 42:5 is *le-shemaʿ ʾozen shemaʿtikha we-ʿattah ʿeyni raʾatka*, I had heard of you by the hearing of the ear, but now my eye sees you.

**That verse belongs to Book IV.** The corpus's most sustained treatment of unexplained suffering resolves in a shift from hearing to seeing, using both organs of the deficit inventory, with no figure anywhere in the book.

**Ecclesiastes.** Twelve chapters. A king is the ostensible speaker and the book's judgment on royal achievement is 2:4-11's catalogue of works, houses, vineyards, gardens, pools, servants, herds, silver, gold, singers, and the verdict *hakkol havel u-reʿut ruaḥ we-ʾeyn yitron taḥat ha-shamesh*. No coming figure.

**Song of Songs.** Eight chapters, no figure, and no relevance to this book beyond its inclusion in the count.

**The count.** Four books, roughly ninety-three chapters, and no messianic material. That is a substantial fraction of the corpus's non-narrative bulk.

## 134. Why the Silence Is Not an Argument, and What It Is


A silence proves nothing on its own and this chapter states what the wisdom silence can and cannot support.

**It cannot support a claim that the expectation is absent from the corpus.** Books VIII and XII documented eight stages across six books. The wisdom material's silence does not subtract from them.

**It cannot support a chronological claim.** The dating of the wisdom books is contested and a silence in an undated body of writing tells nothing about when anything was composed.

**It cannot support a claim that the wisdom writers rejected the expectation.** They do not discuss it. Non-discussion is not rejection.

**What it can support** is a claim about distribution, and distribution matters for one specific question.

The question is whether the messianic material is the corpus's organizing centre or one of its concerns. A reading on which it is the centre has to account for four books and ninety-three chapters that never mention it, in a corpus of twenty-four books.

**Two accounts are available and both are respectable.** On one, the wisdom books belong to a distinct genre with distinct concerns and their silence is generic rather than substantive, as a legal code's silence about poetry would be. On the other, the corpus contains multiple centres and the messianic material is one of them.

This book does not need to choose. It notes that the second account is the one its own argument fits, since Chapter 159 found six substantive contents and the terminus is one of six rather than the only one.

**And one positive finding sits inside the silence.** The wisdom books carry the corpus's densest treatment of the receiving faculty. Proverbs 2:2-5's *le-haqshiv la-ḥokhmah ʾoznekha taṭṭeh libbekha la-tevunah*, inclining your ear to wisdom and applying your heart to understanding. Proverbs 4:20-23's *li-devaray haṭṭeh ʾoznekha ... mi-kol mishmar neṣor libbekha*, incline your ear to my words, and keep your heart with all diligence. Proverbs 20:12: *ʾozen shomaʿat we-ʿayin roʾah, YHWH ʿasah gam sheneyhem*, the hearing ear and the seeing eye, the LORD made them both.

**That last verse is the deficit inventory's positive form**, and it attributes both organs to divine manufacture, in a book with no figure in it.

## 135. The Covenant Formula, Across the Corpus


*We-hayiti lakhem le-ʾelohim we-ʾattem tihyu li le-ʿam.* I will be your God and you shall be my people.

The formula recurs across the corpus and it is worth counting, because Chapter 161 found it in the terminal position of two restoration sequences.

**Exodus 6:7.** *We-laqaḥti ʾetkhem li le-ʿam we-hayiti lakhem le-ʾelohim.* In the second commission to Moses, before the exodus.

**Leviticus 26:12.** *We-hithallakhti be-tokhekhem we-hayiti lakhem le-ʾelohim we-ʾattem tihyu li le-ʿam.* In the blessing section, before the curses that lead to the sabbath-accounting of 26:34.

**Deuteronomy 29:12.** *Le-maʿan haqim ʾotekha ha-yom lo le-ʿam we-huʾ yihyeh lekha le-ʾelohim.* In the covenant renewal, three verses before the not-given organ at 29:3 in the Hebrew numbering.

**Jeremiah 7:23.** *Shimʿu ve-qoli we-hayiti lakhem le-ʾelohim we-ʾattem tihyu li le-ʿam.* **Listen to my voice**, and I will be your God. The formula conditioned on the hearing.

**Jeremiah 11:4, 24:7, 30:22, 31:33, 32:38.** Five further occurrences, including the new covenant passage.

**Ezekiel 11:20, 14:11, 36:28, 37:23, 37:27.** Five occurrences, two of them in the terminal position Chapter 161 identified.

**Zechariah 8:8.** *We-hayu li le-ʿam wa-ʾani ʾehyeh lahem le-ʾelohim be-ʾemet u-vi-ṣdaqah.*

**Roughly fifteen occurrences across five books.**

**Three observations.**

**The formula is relational and contains no figure.** In fifteen occurrences there is no royal, priestly, or eschatological mediator anywhere in the clause.

**It stands at the terminal position of the two great restoration sequences.** Ezekiel 36:28 and 37:23, both after the gathering, the cleansing, and the new heart. Chapter 161 worked them.

**And Jeremiah 7:23 conditions it on the hearing.** *Shimʿu ve-qoli*, listen to my voice. The formula's one conditional statement makes the condition the faculty of Book IV.

**The relevance to this book's result.** Chapter 159 listed six substantive contents. The covenant formula is arguably a seventh, and it was not listed because it is a relation rather than a content and the criterion sorts contents. A reader who thinks it belongs in the list has a reasonable case and its addition would strengthen rather than change the result, since it is figure-free in all fifteen occurrences.

## 136. The Places Where a Figure Would Have Fitted and Is Absent


A negative survey of a different kind. This chapter asks where in the corpus a royal figure would have been the natural thing to name, and finds him absent.

**At the covenant formula.** Fifteen occurrences, no mediator.

**At the direct remedies for the deficit.** Deuteronomy 30:6, Jeremiah 31:33-34, Ezekiel 36:26-27, Joel 3:1. Four passages, four books, no figure.

**At the gathering.** Eight sites, six books, God as subject in every one. Chapter 100.

**At the terminus.** Nine anchors across seven books with the strip as identity. Chapter 159.

**At Deuteronomy 30:11-14.** The passage that denies three modes of intermediation and states the word is in your mouth and in your heart.

**At Micah 6:8.** The corpus's answer to what is required, in three infinitives.

**At Jeremiah 9:22-23.** The subtraction of wisdom, might, and riches, leaving knowing God.

**At Deuteronomy 10:12-13.** The five infinitives.

**At Job's resolution.** 42:5, the shift from hearing to seeing.

**At Ecclesiastes' conclusion.** 12:13, *ʾet ha-ʾelohim yeraʾ we-ʾet miṣwotaw shemor ki zeh kol ha-ʾadam.*

**Ten locations.** Each is a place where the corpus states a requirement, a remedy, a terminus, or a resolution, and each is figure-free.

**What this establishes and does not.** It does not establish that the corpus lacks a messianic expectation; Books VIII and XII documented it in detail. It establishes that the corpus's statements of what is required, what is missing, what will fix it, and what it all arrives at are made, repeatedly and across the whole canon, without naming anyone.

That is the removability result of Chapter 159 restated as a survey rather than as a criterion's output, and it is offered as a second route to the same finding, since a result reachable two ways is worth more than a result reachable one.

## 137. The Two Vocabularies, Set Side by Side


Book XV closes with the comparison the whole study has been assembling.

**The figure vocabulary.** *Mashiaḥ*, anointed. *Melekh*, king. *Nagid*, prince or designate. *Nasiʾ*, prince. *Roʿeh*, shepherd. *Ṣemaḥ*, branch. *Ḥoṭer* and *neṣer*, shoot and branch. *Ben*, son. *ʿEved*, servant. *Bar ʾenash*, one like a son of man.

**Its characteristic grammar.** Passive or divine-subject. Fifteen sites at Appendix D, plus the escalation's eight stages at Appendix G, plus the pastoral appointments of Book X. No exception found.

**Its characteristic content.** A dominion, a throne, a name, a spirit, a portion, a task. What the figure is given.

**The terminus vocabulary.** *Menuḥah* and the four roots. *Deʿah*, knowledge. *Shalom* at the edge of the field. The war-cessation clauses. The knowledge-filling clauses.

**Its characteristic grammar.** Stative, agentless, or with the people as subject of an entering. *Baʾ ʾel* at Deuteronomy 12:9 and Psalm 95:11. *Maleʾah ha-ʾareṣ* at Isaiah 11:9. *Loʾ yilmedu ʿod milḥamah* at Isaiah 2:4.

**Its characteristic content.** A state. What is entered or not entered.

**The deficit vocabulary.** *Lev*, *ʿeynayim*, *ʾoznayim*. Heart, eyes, ears. Plus *shmʿ*, to hear, and *ydʿ*, to know, and *zkr*, to remember.

**Its characteristic grammar.** A negation attached to an organ. Not given, made heavy, shut, possessed and not functioning, hardened, forgot.

**Three vocabularies. Three grammars. And the corpus keeps them apart.**

Where it addresses the deficit directly, it uses the deficit vocabulary with God as subject and no figure present. Where it escalates the figure, it uses the figure vocabulary with conferral grammar. Where it names the destination, it uses the terminus vocabulary with stative or entering grammar.

**The three meet in exactly one passage and the meeting is partial.** Isaiah 11: the figure receives a spirit of knowledge and does not judge by eyes or ears, at 11:2-3; and the earth is full of knowledge, at 11:9. Chapter 84 read the gap between them.

**That is the finding, stated at the end of the survey rather than at its beginning.** Not that the figure is unreal, not that the expectation is mistaken, not that the material is late. That the corpus maintains three vocabularies with three grammars, uses each for its own object, and does not join them.

The road is real and the corpus commands it. The destination is named separately and named often. And the deficit that keeps the two apart is stated in the same three organs, in the same words, from Deuteronomy to Ezekiel, and is never reported as met.

:::book XVI | THE SERVANT


## 138. Why the Servant Material Needs Its Own Book


The servant passages of Isaiah 40 through 55 are the most contested body of material in the Hebrew Bible and they are central to any account of the corpus's expectation. Book XII gave them one chapter. They need more, for three reasons.

**The identification is genuinely open and the corpus itself supplies evidence on both sides.** Isaiah 49:3 names the servant Israel. Isaiah 49:6 gives him a mission to Israel. The corpus states both, four verses apart, in one oracle, and this book's habit is to record such pairs rather than resolve them.

**The material carries the corpus's most extended account of a figure who suffers**, and any reading of the messianic position that omits it is omitting the passage most readers would name first.

**And the material contains the corpus's own application of the deficit inventory to the figure**, at Isaiah 42:19, which Chapter 34 worked and which forecloses a whole class of triumphal reading.

**Four passages are conventionally isolated as the servant songs**: 42:1-4, with 42:5-9 often attached; 49:1-6, with 49:7-13 often attached; 50:4-9, with 50:10-11 often attached; and 52:13-53:12. The isolation is Duhm's and it is a scholarly convention rather than a feature of the text. This book uses the convention as a convenience and notes that the servant appears outside the four songs as well, at 41:8-9, 43:10, 44:1-2, 44:21, 45:4, 48:20, and elsewhere, and that in most of those the servant is explicitly Israel or Jacob.

**That distribution is the first datum.** Outside the four songs, the servant is named Israel or Jacob roughly a dozen times. Inside them the identification is harder. Any reading has to account for both.

## 139. The First Song · Isaiah 42:1-9


*Hen ʿavdi ʾetmokh bo, beḥiri raṣetah nafshi, natatti ruḥi ʿalaw mishpaṭ la-goyim yoṣiʾ.*

Behold my servant whom I uphold, my chosen in whom my soul delights; I have put my spirit upon him; he shall bring forth justice to the nations.

**Four divine verbs in the first line.** I uphold. My chosen. My soul delights. I have put my spirit upon him. The servant's own verb, *yoṣiʾ*, he shall bring forth, is the fifth and comes last.

**The mode of operation is stated negatively and it is striking.** 42:2: *loʾ yiṣʿaq we-loʾ yissaʾ we-loʾ yashmiaʿ ba-ḥuṣ qolo.* He shall not cry out, nor lift up, nor make his voice heard in the street.

*Loʾ yiṣʿaq*, he shall not cry out, uses the outcry verb of 1 Samuel 8:18 and the Judges cycle. The servant does not perform the covenant outcry.

**42:3.** *Qaneh raṣuṣ loʾ yishbor u-fishtah kehah loʾ yekhabbennah, le-ʾemet yoṣiʾ mishpaṭ.* A bruised reed he will not break, and a dimly burning wick he will not quench; he will bring forth justice in truth.

**42:4.** *Loʾ yikhheh we-loʾ yaruṣ ʿad yasim ba-ʾareṣ mishpaṭ.* He will not grow dim nor be bruised until he has established justice in the earth.

The two verbs of 42:4 are the two of 42:3 turned back on the servant: he will not be *dimmed*, as the wick, nor *bruised*, as the reed. The corpus writes the servant into the same categories as those he protects.

**And then 42:5-9 supplies the conferral.** 42:6: *ʾani YHWH qeratikha ve-ṣedeq we-ʾaḥzeq be-yadekha we-ʾeṣṣorkha we-ʾettenkha li-verit ʿam le-ʾor goyim.* I the LORD have called you in righteousness and will hold your hand and keep you and give you as a covenant of the people, a light to the nations.

**Five first-person divine verbs.** I have called. I will hold. I will keep. I will give. And 42:7's purpose: to open blind eyes, to bring out prisoners from the dungeon, those who sit in darkness from the prison house.

**To open blind eyes.** *Li-fqoaḥ ʿeynayim ʿiwrot.* The deficit inventory, and here the servant's stated task is to address it.

**That is the single strongest counterexample to Chapter 84's finding and it is stated here at full strength.** Chapter 84 asked for a passage in which a figure opens an ear or gives a heart. Isaiah 42:7 has a servant opening blind eyes.

**Three things bear on how much weight it carries.** The infinitive is subordinate to 42:6's divine giving, so the servant is given as the instrument of an opening whose agent is the giver. The blindness at 42:7 is paired with imprisonment and darkness, which suggests a release-image rather than the cognitive deficit of 42:19. And 42:19, twelve verses later, applies the blindness to the servant himself, which makes a straightforward reading of 42:7 as the servant curing what he does not have difficult.

**This book records the counterexample, states the three considerations, and does not claim they dispose of it.** Chapter 84's finding should be read as narrowed by Isaiah 42:7 rather than as untouched by it.

## 140. Isaiah 42:19 · The Servant in the Category


Chapter 34 worked this verse and it is restated here because Book XVI is where it does the most work.

*Mi ʿiwwer ki ʾim ʿavdi, we-ḥeresh ke-malʾakhi ʾeshlaḥ.*

Who is blind but my servant, and deaf as my messenger whom I send?

**Twelve verses after 42:7's opening of blind eyes, the servant is the blind one.**

Two readings of the juxtaposition are available.

**The two-servant reading.** 42:1-9's servant and 42:19's servant are different figures, the first an individual and the second Israel. This is a common view and it makes the chapter coherent at the cost of positing two referents for one word in one chapter.

**The one-servant reading.** The chapter is doing something deliberate: the servant commissioned to open eyes is himself blind, and the corpus states it. This is harder and it is the reading the text as it stands most nearly supports, since 42:19 gives no signal of a change of referent.

**This book does not choose** and notes that on either reading the corpus has placed the two verses in one chapter and left the relation unstated.

**And on either reading the fence of Chapter 34 holds.** The corpus applies the deficit diagnostic to a figure it calls *ʿavdi*, *malʾakhi*, *meshullam*, and *ʿeved YHWH*. Whoever that is, the polemical use of the motif is foreclosed.

**42:20's final clause remains the sharpest formulation in the corpus.** *Paqoaḥ ʾoznayim we-loʾ yishmaʿ.* Opening the ears and he does not hear. The infinitive absolute describes a state of openness and the negation attaches to the function. The organ is not sealed; it is open and not receiving.

**And 42:18 issues the imperative to the deficient party.** *Ha-ḥershim shemaʿu we-ha-ʿiwrim habbiṭu lirʾot.* You deaf, hear; you blind, look and see. The same shape as Jeremiah 6:16: a command addressed to a party the corpus has just described as unable, with no acknowledgement of the difficulty.

## 141. The Second Song · Isaiah 49:1-6


*Shimʿu ʾiyyim ʾelay we-haqshivu leʾummim me-raḥoq, YHWH mi-beṭen qeraʾani mi-meʿey ʾimmi hizkir shemi.*

Listen, coastlands, to me, and attend, peoples from afar. The LORD called me from the womb; from my mother's body he named my name.

**The song opens in the servant's own voice and its first clause is a hearing imperative addressed to the nations.**

**Two divine verbs in the first line.** He called me. He named my name. Both from before birth.

**49:2 supplies the equipment.** *Wa-yasem pi ke-ḥerev ḥaddah, be-ṣel yado heḥbiʾani, wa-yesimeni le-ḥeṣ barur, be-ʾashpato hisstirani.* He made my mouth like a sharp sword; in the shadow of his hand he hid me; he made me a polished arrow; in his quiver he concealed me.

**Four verbs, all divine, and two of them are concealments.** Hid me, concealed me. The servant is equipped and stored.

**49:3.** *Wa-yoʾmer li ʿavdi ʾattah, Yisraʾel ʾasher bekha ʾetpaʾar.* And he said to me: you are my servant, Israel, in whom I will be glorified.

**49:4 is the complaint.** *Wa-ʾani ʾamarti le-riq yagaʿti, le-tohu we-hevel koḥi khilleyti, ʾakhen mishpaṭi ʾet YHWH u-feʿullati ʾet ʾelohay.* And I said, I have laboured in vain, I have spent my strength for nothing and vanity; yet surely my judgment is with the LORD and my recompense with my God.

**The servant reports failure and locates his vindication elsewhere.** *Mishpaṭi ʾet YHWH*, my case is with the LORD. The verb *khilleyti*, I have spent or finished, is from *klh*, the verb of Genesis 2:2's *wa-yikhal ʾelohim*. The servant's strength is completed as the creation's work was.

**49:5-6 is the expansion.** *We-ʿattah ʾamar YHWH yoṣri mi-beṭen le-ʿeved lo le-shovev Yaʿaqov ʾelaw we-Yisraʾel lo yeʾasef.* And now the LORD says, who formed me from the womb to be his servant, to bring Jacob back to him and that Israel be gathered to him.

**49:6.** *Naqel mi-hyotekha li ʿeved le-haqim ʾet shivṭey Yaʿaqov u-neṣurey Yisraʾel le-hashiv, u-netattikha le-ʾor goyim li-hyot yeshuʿati ʿad qeṣeh ha-ʾareṣ.* It is too light a thing that you should be my servant to raise up the tribes of Jacob and restore the preserved of Israel; I will give you as a light to the nations, that my salvation may reach to the end of the earth.

**The pair.** Named Israel at 49:3. Given a mission to Jacob and Israel at 49:5-6. Appendix E counts it as the third of the thirteen.

**Three readings of the pair.**

*Israel at 49:3 is a corporate designation and the servant is an individual within it who has a mission to the whole.* This is coherent and requires the name to function as a title.

*49:3's Israel is a gloss.* One medieval manuscript is often cited as omitting it. The textual evidence is thin.

*The servant is Israel and the mission at 49:6 is to a remnant.* This requires a distinction inside Israel that the text does not state.

**This book takes none** and records that the corpus states both and reconciles neither, which by Book XIII's count is the corpus's habit and not an anomaly.

**And the conferral grammar holds throughout.** Called, named, made, hid, made, concealed, formed, and *u-netattikha*, I will give you. Eight divine verbs in six verses, with the servant's own verbs being a speaking and a complaining.

## 142. The Third Song · Isaiah 50:4-9


*ʾAdonay YHWH natan li leshon limmudim la-daʿat la-ʿut ʾet yaʿef davar, yaʿir ba-boqer ba-boqer yaʿir li ʾozen li-shmoaʿ ka-limmudim.*

The Lord GOD has given me the tongue of the taught, to know how to sustain the weary with a word; he wakens morning by morning, he wakens my ear to hear as the taught.

**This is the corpus's most direct statement of the deficit being addressed in an individual, and it is worth taking word by word.**

*Natan li*, has given me. The verb of giving, with God as subject and the servant as recipient.

*Leshon limmudim*, the tongue of the taught, or of disciples. The noun *limmudim* is a passive participle: those who have been taught.

*La-daʿat*, to know. The faculty of Deuteronomy 29:3's *lev la-daʿat*.

*Yaʿir li ʾozen*, he wakens my ear. The organ of the deficit, wakened by another.

*Li-shmoaʿ*, to hear. The faculty of Psalm 95:7 and 1 Samuel 8:19.

*Ba-boqer ba-boqer*, morning by morning. Repeated, continuous, not once.

**Five of Book IV's terms in two verses, all of them supplied by God, and the supply is daily rather than permanent.**

**50:5.** *ʾAdonay YHWH pataḥ li ʾozen we-ʾanokhi loʾ mariti ʾaḥor loʾ nesugoti.* The Lord GOD has opened my ear, and I was not rebellious, I did not turn backward.

*Pataḥ li ʾozen*, opened my ear. The passive of Isaiah 35:5's *tippataḥnah*. And then the servant's own response, stated negatively: I was not rebellious, I did not turn back.

**That is the exact inverse of Jeremiah 6:16.** There the paths stood and the answer was *loʾ nelekh*, we will not walk. Here the ear is opened and the answer is *loʾ mariti*, I was not rebellious.

**50:6 is the cost.** *Gewi natatti le-makkim u-leḥayay le-morṭim, panay loʾ histarti mi-kelimmot wa-roq.* I gave my back to those who struck, and my cheeks to those who plucked out the beard; I did not hide my face from shame and spitting.

**And 50:7-9 is the confidence, stated forensically.** *ʾAdonay YHWH yaʿazor li ʿal ken loʾ nikhlamti ... qarov maṣdiqi mi yariv ʾitti.* The Lord GOD helps me, therefore I am not confounded; he who vindicates me is near; who will contend with me?

**The whole song is a statement of received capacity and its consequences.** The tongue is given, the ear is wakened and opened, the response is compliance, the cost is violence, and the vindication is another's. Every faculty in the song is supplied and every outcome is attributed.

**And the song's own closing verses at 50:10-11 turn to the audience.** *Mi vakhem yereʾ YHWH shomeaʿ be-qol ʿavdo?* Who among you fears the LORD and listens to the voice of his servant? Followed by 50:11's warning to those who kindle their own fire and walk in the light of their own sparks: *mi-yadi haytah zoʾt lakhem le-maʿaṣevah tishkavun*, this you shall have from my hand: you shall lie down in sorrow.

The hearing imperative again, and the alternative to it stated as self-supplied light.

## 143. The Fourth Song · Isaiah 52:13-53:12, and What This Book Says About It


The fourth song is the most read, most contested, and most consequential passage in the Hebrew Bible for the history of the traditions that carry it. This chapter states what this book can say about it and where it stops.

**What this book does not do.** It does not identify the servant. It does not adjudicate between the corporate and individual readings. It does not engage the passage's reception in any later corpus, which the scope law of Chapter 1 excludes. And it does not offer a reading of the substitution language, which is the passage's centre and the point at which every interpretive tradition has done its heaviest work.

**What it can say is grammatical and it is limited.**

**The opening is a conferral.** 52:13: *hinneh yaskil ʿavdi yarum we-nissaʾ we-gavah meʾod.* Behold my servant shall prosper; he shall be exalted and lifted up and be very high. *Yarum* and *we-nissaʾ* are elevation verbs, the second a nifal and therefore passive in form. *We-gavah* is the verb of 2 Chronicles 26:16's *gavah libbo*, here without the negative sense.

**The report is stated as unbelieved.** 53:1: *mi heʾemin li-shmuʿatenu u-zeroaʿ YHWH ʿal mi nigletah?* Who has believed our report, and to whom has the arm of the LORD been revealed?

*Li-shmuʿatenu*, our hearing, from *šmʿ*. The passage opens on a failure of reception, and the second clause asks to whom the arm has been revealed, which makes the revealing a divine act with limited scope.

**The appearance is stated as unremarkable.** 53:2: *loʾ toʾar lo we-loʾ hadar we-nirʾehu we-loʾ marʾeh we-neḥmedehu.* He had no form or majesty that we should look at him, no beauty that we should desire him.

*Hadar*, majesty, is the noun of Psalm 8:6's crowning with *kavod we-hadar* and of Psalm 45:4-5's royal address. The servant is described by the absence of the royal quality.

**And 53:2's opening image is vegetable.** *Wa-yaʿal ka-yoneq le-fanaw we-kha-shoresh me-ʾereṣ ṣiyyah.* He grew up like a young plant before him, and like a root out of dry ground.

*Ke-shoresh*, like a root. The noun of Job 14:8's persisting part and of Isaiah 11:1's second colon. And *me-ʾereṣ ṣiyyah*, from dry ground, which is the opposite of Job 14:9's *reaḥ mayim*, the scent of water.

**The divine verbs are present throughout the passage.** 53:6: *wa-YHWH hifgiaʿ bo ʾet ʿawon kullanu*, the LORD has laid on him the iniquity of us all. 53:10: *wa-YHWH ḥafeṣ dakkeʾo*, the LORD was pleased to crush him. And 53:12: *lakhen ʾaḥalleq lo va-rabbim*, therefore I will divide him a portion with the great.

**The servant's own verbs are few and most are passives or endurances.** He was despised. He was wounded. He was oppressed and afflicted. He opened not his mouth. He was cut off. He poured out his soul. He bore the sin of many.

**53:12's final clause is the one active intercession.** *We-la-poshʿim yafgiaʿ*, and he made intercession for the transgressors, using the same verb *pgʿ* as 53:6's laying-on, in a different stem.

**What this book takes.** The passage's conferral grammar is consistent with the fifteen sites of Appendix D, its opening turns on a failure of hearing, and its vegetable image is the root from dry ground rather than the shoot from a stump.

**What it leaves.** Everything else, which is most of the passage and all of what makes it what it is.

**And it states plainly why it leaves it.** A book constrained to one corpus can describe this passage's grammar. It cannot adjudicate an identification that two millennia of reading have not settled, and a study that offered one in a chapter would be pretending to a competence it has not demonstrated anywhere else.

## 144. The Servant Who Is Named Israel


Outside the four songs, the servant is named. This chapter counts the namings, because they are the strongest evidence for the corporate reading and a book that treated the songs in isolation would be hiding them.

**Isaiah 41:8-9.** *We-ʾattah Yisraʾel ʿavdi, Yaʿaqov ʾasher beḥartikha, zeraʿ ʾAvraham ʾohavi. ʾAsher heḥezaqtikha mi-qeṣot ha-ʾareṣ ... wa-ʾomar lekha ʿavdi ʾattah, beḥartikha we-loʾ meʾastikha.* You, Israel, my servant, Jacob whom I have chosen, seed of Abraham my friend, whom I took from the ends of the earth and said to you, you are my servant; I have chosen you and not rejected you.

**Isaiah 44:1-2.** *We-ʿattah shemaʿ Yaʿaqov ʿavdi we-Yisraʾel baḥarti vo ... ʾal tiraʾ ʿavdi Yaʿaqov wi-Yshurun baḥarti vo.*

**Isaiah 44:21.** *Zekhor ʾelleh Yaʿaqov we-Yisraʾel ki ʿavdi ʾattah, yeṣartikha ʿeved li ʾattah, Yisraʾel loʾ tinnasheni.*

**Isaiah 45:4.** *Le-maʿan ʿavdi Yaʿaqov we-Yisraʾel beḥiri.*

**Isaiah 48:20.** *Gaʾal YHWH ʿavdo Yaʿaqov.*

**Isaiah 43:10.** *ʾAttem ʿeday neʾum YHWH we-ʿavdi ʾasher baḥarti.* You are my witnesses and my servant whom I have chosen. Plural addressees and a singular servant in one clause.

**Six namings, all Israel or Jacob, all in the same section of the book as the four songs.**

**And every one of them carries the conferral grammar.** I have chosen. I took. I said. I formed. I redeemed. The corporate servant holds what he holds on the same terms as the individual one.

**The chapter's finding.** Whatever the songs' servant is, the surrounding material's servant is Israel and the corpus says so six times. A reading that treats the songs' servant as straightforwardly individual has to explain the six, and a reading that treats him as straightforwardly corporate has to explain 49:5-6. Both explanations exist and both are respectable.

**This book's position is the one it has held throughout.** The corpus states both and reconciles neither, and Appendix E counts the pair.

## 145. What the Servant Material Establishes


Five results.

**The conferral grammar holds.** Across all four songs and all six namings: called, chosen, upheld, given a spirit, held by the hand, kept, given as a covenant, formed from the womb, named, made a sword, hidden, made an arrow, concealed, given a tongue, wakened, opened, laid upon, and given a portion. Every one has God as subject.

**The deficit is applied to the servant.** At 42:19-20, in the corpus's sharpest formulation of it.

**And the deficit is addressed in the servant.** At 50:4-5, by a daily wakening and an opening of the ear, both divine acts, with the servant's response stated as a not-turning-back.

**Those two are not contradictory on the corpus's own terms.** A figure can be described as blind in one oracle and as having his ear opened morning by morning in another, and the second does not cancel the first if the opening is daily rather than permanent. This book offers that as an observation about the two passages' compatibility and not as a resolution of the servant question.

**The one counterexample to Chapter 84 stands and is narrowed.** Isaiah 42:7's opening of blind eyes is a servant's stated task. Chapter 139 gave three considerations bearing on how much weight it carries and did not claim they dispose of it. **Chapter 84's finding should be read as: the corpus states no passage in which a figure gives a heart or supplies knowledge to a people, and it states one in which a servant is given as a covenant and a light with the opening of blind eyes among the purposes.** That is a narrower claim than Chapter 84 made and it is the correct one.

**And the servant material is the corpus's strongest single body of evidence against a simple version of this book's reading.** A study that had not looked at it would have produced a cleaner argument and a worse one.

One closing note. Book XVI has declined to identify the servant, declined to read the substitution language, and declined to engage the passage's reception. Those are three large declinings in the corpus's most important passage. They follow from the scope law and from Chapter 8's list of things this book does not do, and a reader who finds them unsatisfying is finding the scope law unsatisfying, which is a legitimate position stated at Chapter 1 with its costs named.

:::book XVII | THE EXILE AND THE RETURN


## 146. The Corpus Narrates Its Own Catastrophe


The Hebrew Bible is, among other things, a body of writing that records the destruction of the institutions it describes, and it records it more than once and in more than one voice.

**2 Kings 25.** The siege, the famine, the breach of the city, the flight of Zedekiah, his capture in the plains of Jericho, the killing of his sons before his eyes, and then *we-ʾet ʿeyney Ṣidqiyyahu ʿiwwer*, and they blinded the eyes of Zedekiah. The temple burned, the great houses burned, the walls broken down, the bronze pillars broken in pieces and carried to Babylon.

**And the book ends with a meal.** 25:27-30: in the thirty-seventh year of the exile Evil-merodach lifted up the head of Jehoiachin, spoke kindly to him, set his throne above the thrones of the kings with him in Babylon, changed his prison garments, and *ʾakhal leḥem tamid le-fanaw kol yemey ḥayyaw*, he ate bread continually before him all the days of his life.

**The Deuteronomistic History closes on a Davidide eating at a foreign king's table.** That is the last thing the corpus's great historical work says.

**2 Chronicles 36 tells it differently.** The sabbath-accounting at 36:21, worked at Chapter 30, and then the decree of Cyrus at 36:22-23, which is the last thing in the Hebrew canon's arrangement. *Mi vakhem mi-kol ʿammo, YHWH ʾelohaw ʿimmo we-yaʿal.* Whoever is among you of all his people, may the LORD his God be with him, and let him go up.

**The corpus ends, in the received Jewish arrangement, on a permission to go up granted by a Persian king.**

**Lamentations supplies the third voice.** Five poems, four of them acrostics, on the destruction. 2:9: *melekhah we-sareha va-goyim ʾeyn torah, gam nevi'eha loʾ maṣʾu ḥazon me-YHWH.* Her king and her princes are among the nations; the law is no more; her prophets find no vision from the LORD. And 4:20's capture of the anointed in the pit.

**Three accounts, three endings.** A meal at a foreign table. A permission from a foreign king. And a lament that closes at 5:20-22 with *lammah la-neṣaḥ tishkaḥenu ... ki ʾim maʾos meʾastanu qaṣafta ʿaleynu ʿad meʾod*, why do you forget us forever, unless you have utterly rejected us and are exceedingly angry with us.

**And that final verse uses *mʾs*.** The verb of 1 Samuel 8:7 and 15:23. Lamentations closes on the possibility that the rejection ran the other way.

## 147. What the Exile Does to the Argument


The exile is the event that makes the escalation legible and it is worth stating how.

**Before the exile the corpus has a monarchy, a temple, a land, and a promise.** After it the corpus has none of the first three and a community under Persian administration.

**The eight stages are therefore not distributed evenly across that break.** Stages one through four are set before it in the narrative. Stage five is set in the eighth century by its own context. Stage six is set in the same book. Stage seven is securely post-exilic. And stage eight is set in the exile by its narrative frame.

**Whatever the composition, the received arrangement places the highest stages at or after the catastrophe.**

That is what a reader would expect on any account. A community that has lost a king is more likely to produce material about a coming one than a community that has one, and the observation is old and not this book's.

**What the observation costs this book's argument, and it should be stated.** If the escalation is a response to catastrophe rather than a category substitution, then Chapter 82's finding is redescribed rather than refuted: the corpus escalated because it had lost what it had, and the escalation's failure to address the deficit is then a fact about grief rather than about logic.

**Two responses.**

**The redescription and the finding are compatible.** A community escalating under loss can still be escalating in a category that does not address the stated deficit, and the corpus's own diagnosis at Deuteronomy 29:3 and Psalm 95:11 predates the loss.

**And the deficit texts are themselves distributed across the break.** Deuteronomy 29:3 is pre-exilic on any account of Deuteronomy's setting. Isaiah 6 is eighth-century by its own dating. Jeremiah 6:16 is late pre-exilic. Ezekiel 12:2 is exilic. The diagnosis does not cluster at one end.

**What the exile does establish for this book** is the setting of Books XI and XIII. Psalm 89's complaint, Lamentations 4:20's captured anointed, and the Chronicler's relocation of the throne's ownership are all responses to the loss, and all three are in the corpus.

## 148. The Return, and Who Is Credited With It


The corpus credits the return to three parties and the distribution is informative.

**To God.** Deuteronomy 30:3, Jeremiah 23:3, Ezekiel 36:24, Isaiah 56:8, Micah 2:12, Psalm 147:2. Chapter 100 counted eight sites.

**To Cyrus.** Isaiah 44:28 and 45:1-6, worked at Chapter 71. And 2 Chronicles 36:22-23 and Ezra 1:1-4, the decree.

**To no royal figure of Israel.** There is no passage in the corpus attributing the return to a Davidic king, a messiah, a branch, or any Israelite royal figure.

**And Ezra-Nehemiah, the corpus's own account of the return, contains no messianic material at all.**

That last point deserves a paragraph because it is easy to miss. Ezra and Nehemiah narrate the return, the rebuilding of the altar, the laying of the foundation, the opposition, the completion of the temple, the reading of the law, the covenant renewal, and the rebuilding of the wall. Across roughly twenty-three chapters there is no coming figure, no anointed one, and no expectation of one.

**The leaders named are Sheshbazzar, Zerubbabel, Jeshua, Ezra, and Nehemiah.** Zerubbabel is a Davidide by the genealogy at 1 Chronicles 3:19 and Haggai 2:23 calls him a signet. Ezra-Nehemiah does not.

**Nehemiah 9 is the return's great confession** and it is the longest historical recital in the corpus outside the Torah. It runs from creation through Abraham, the exodus, Sinai, the wilderness, the conquest, the judges, the prophets, and the exile, and it locates the failure repeatedly in the same place.

9:16: *we-hem wa-ʾavoteynu heziḏu wa-yaqshu ʾet ʿorpam we-loʾ shameʿu ʾel miṣwoteykha.* They and our fathers acted presumptuously and stiffened their neck and did not listen to your commandments.

9:17: *wa-yemaʾanu li-shmoaʿ*, and they refused to listen. The verb of 1 Samuel 8:19.

9:26: *wa-yashlikhu ʾet toratekha ʾaḥarey gawwam.* They cast your law behind their back.

9:29: *we-hemmah heziḏu we-loʾ shameʿu le-miṣwoteykha.*

9:30: *wa-timshokh ʿaleyhem shanim rabbot wa-taʿad bam be-ruḥakha be-yad neviʾeykha we-loʾ heʾezinu.* You bore with them many years and warned them by your spirit through your prophets, and they would not give ear.

**Five statements of the hearing failure in one chapter, in the corpus's own retrospective account of its whole history.**

**And the chapter's conclusion is a covenant, not an expectation.** 10:1: *u-ve-khol zoʾt ʾanaḥnu korotim ʾamanah we-khotevim*, and because of all this we make a sure covenant and write it. Followed by the signatories and the terms.

**The corpus's own account of its return locates the failure in the hearing five times and responds with a written undertaking, and names no figure.**

## 149. The Second Temple, and the Weeping


Ezra 3:10-13 records the laying of the foundation and it records two sounds.

*We-rabbim me-ha-kohanim we-ha-Lewiyyim we-rashey ha-ʾavot ha-zeqenim ʾasher raʾu ʾet ha-bayit ha-rishon be-yosdo zeh ha-bayit be-ʿeyneyhem bokhim be-qol gadol we-rabbim bi-truʿah ve-simḥah le-harim qol.*

Many of the priests and Levites and heads of fathers' houses, old men who had seen the first house, wept with a loud voice when the foundation of this house was laid before their eyes, and many shouted aloud for joy.

**3:13.** *We-ʾeyn ha-ʿam makkirim qol teruʿat ha-simḥah le-qol bekhi ha-ʿam, ki ha-ʿam meriʿim teruʿah gedolah we-ha-qol nishmaʿ ʿad le-me-raḥoq.* The people could not distinguish the sound of the shout of joy from the sound of the people's weeping, for the people shouted with a great shout and the sound was heard far away.

**Haggai 2:3 asks the question directly.** *Mi vakhem ha-nishʾar ʾasher raʾah ʾet ha-bayit ha-zeh bi-khvodo ha-rishon, u-mah ʾattem roʾim ʾoto ʿattah, ha-loʾ kamohu ke-ʾayin be-ʿeyneykhem.* Who is left among you who saw this house in its former glory? And how do you see it now? Is it not as nothing in your eyes?

**And Haggai's answer is a promise.** 2:9: *gadol yihyeh kevod ha-bayit ha-zeh ha-ʾaḥaron min ha-rishon ... u-va-maqom ha-zeh ʾetten shalom.* The glory of this latter house shall be greater than the former, and in this place I will give peace.

**Three features of the whole episode.**

**The corpus records disappointment at the restoration it had promised.** That is unusual and it is not concealed. Ezra 3:12's weeping is the response of the people who remembered.

**Zechariah 4:10 addresses it.** *Ki mi vaz le-yom qeṭannot?* Who has despised the day of small things? Asked in the vision that also gives Zerubbabel the plummet.

**And the promise Haggai makes is stated with a first-person divine verb and no figure.** *ʾEtten shalom*, I will give peace.

**The relevance to this book.** The one moment in the corpus at which an act-layer restoration actually happens produces weeping alongside joy, and the corpus records both and cannot distinguish the sounds. Chapter 161 argued that the corpus subordinates the acts to a state they move toward. Ezra 3:13 is what the acts look like when they arrive without the state.

## 150. Malachi · The Corpus's Last Word in One Arrangement


The Christian arrangement of the canon ends with Malachi and the Jewish arrangement ends with Chronicles. Both endings are worth having.

**Malachi's content.** A disputation in six units, each opening with a divine statement, a quoted objection, and a reply. The priests despising the name, offering blind and lame animals. The covenant of Levi corrupted. Faithless marriages and divorce. The wearying of God with words. The robbing of God in tithes. And the book of remembrance written for those who feared the LORD.

**3:1.** *Hineni sholeaḥ malʾakhi u-finnah derekh le-fanay, u-fitʾom yavoʾ ʾel heykhalo ha-ʾadon ʾasher ʾattem mevaqshim u-malʾakh ha-berit ʾasher ʾattem ḥafeṣim.* Behold I send my messenger and he shall prepare the way before me; and suddenly the Lord whom you seek will come to his temple, and the messenger of the covenant whom you delight in.

**Two or three figures in one verse and the corpus does not disambiguate.** *Malʾakhi*, my messenger. *Ha-ʾadon*, the Lord. *Malʾakh ha-berit*, the messenger of the covenant. Whether the last is the first or a third party is unstated.

**And 3:2 asks the question that undoes an easy expectation.** *U-mi mekhalkel ʾet yom boʾo u-mi ha-ʿomed be-heraʾoto?* Who can endure the day of his coming, and who shall stand when he appears?

**That is Amos 5:18's question in a different vocabulary.** Amos asked why the audience wanted the day of the LORD. Malachi asks who can endure it. The corpus's first and last prophetic books both interrogate the expectation rather than confirming it.

**3:23.** *Hinneh ʾanokhi sholeaḥ lakhem ʾet ʾEliyyah ha-naviʾ lifney boʾ yom YHWH ha-gadol we-ha-noraʾ.* Behold I send you Elijah the prophet before the coming of the great and terrible day of the LORD.

**And 3:24 states the purpose.** *We-heshiv lev ʾavot ʿal banim we-lev banim ʿal ʾavotam, pen ʾavoʾ we-hikkeyti ʾet ha-ʾareṣ ḥerem.* And he shall turn the heart of the fathers to the children and the heart of the children to their fathers, lest I come and strike the land with utter destruction.

**The corpus's last sent figure has a task and the task is a heart.** *We-heshiv lev*, and he shall turn the heart. The organ of Book IV, and the one place in the corpus where a sent figure's stated function is to move it.

**And the figure sent is a prophet, not a king.** Elijah, named, from the past.

**Chapter 84 asked for a passage in which a figure supplies the missing faculty and Chapter 145 narrowed the finding against Isaiah 42:7.** Malachi 3:24 narrows it further. The turning of a heart is not the giving of one, and the hearts turned are turned toward each other rather than toward God, and the purpose clause is a prevention of destruction rather than an entering. But the verse has a sent figure and a heart-verb in one clause, and an honest survey reports it.

**Two verses. The corpus's last words in this arrangement.** A prophet sent, hearts turned, and a conditional destruction averted.

## 151. Chronicles · The Corpus's Last Word in the Other


The Jewish arrangement places Chronicles last and the ending is a permission.

**2 Chronicles 36:22-23.** *U-vi-shnat ʾaḥat le-Khoresh melekh Paras li-khlot devar YHWH be-fi Yirmeyahu heʿir YHWH ʾet ruaḥ Koresh melekh Paras wa-yaʿaver qol be-khol malkhuto we-gam be-mikhtav leʾmor.*

In the first year of Cyrus king of Persia, to fulfil the word of the LORD by the mouth of Jeremiah, the LORD stirred up the spirit of Cyrus king of Persia, and he made a proclamation throughout all his kingdom, and also in writing.

**And the proclamation.** *Koh ʾamar Koresh melekh Paras, kol mamlekhot ha-ʾareṣ natan li YHWH ʾelohey ha-shamayim, we-huʾ faqad ʿalay li-vnot lo vayit bi-Yrushalayim ʾasher bi-Yhudah. Mi vakhem mi-kol ʿammo, YHWH ʾelohaw ʿimmo we-yaʿal.*

Thus says Cyrus king of Persia: all the kingdoms of the earth the LORD God of heaven has given me, and he has charged me to build him a house in Jerusalem which is in Judah. Whoever is among you of all his people, may the LORD his God be with him, and let him go up.

**The corpus's final sentence in this arrangement is *we-yaʿal*, and let him go up.** An imperfect with permissive force, addressed to whoever is willing, spoken by a foreign king.

**Four features.**

**The stirring is God's.** *HeʿIr YHWH ʾet ruaḥ Koresh.* The LORD stirred up the spirit of Cyrus. The conferral grammar at the corpus's last narrative act.

**The giving is stated in Cyrus's own mouth.** *Kol mamlekhot ha-ʾareṣ natan li YHWH.* All the kingdoms of the earth the LORD has given me. The Persian king, in the corpus's final quoted speech, states his empire as received.

**The charge is a building.** *Faqad ʿalay li-vnot lo vayit.* He has charged me to build him a house. Not a kingdom, not a throne. A house.

**And the permission is individual and voluntary.** *Mi vakhem*, whoever among you. Nobody is gathered, led, or brought. The corpus's last word is an invitation to go up, addressed to anyone willing, with no figure at its head.

**Set the two endings side by side.**

Malachi: a prophet sent, hearts turned toward each other, destruction averted.

Chronicles: a foreign king stirred, an empire acknowledged as given, a house to be built, and whoever is willing may go up.

**Neither ends on a king. Neither ends on an arrival. Both end on something a person does.**

## 152. What the Exile Material Establishes


Four results.

**The corpus records its own catastrophe in three voices and none of them expects a royal deliverance from it.** Kings ends on a meal at a foreign table. Chronicles ends on a Persian decree. Lamentations ends on a question about rejection.

**The return is credited to God and to Cyrus and to no Israelite royal figure anywhere.** Eight divine-subject gathering sites and the Cyrus material, and nothing else.

**Ezra-Nehemiah, the corpus's own narrative of the return, contains no messianic material and locates the historic failure in the hearing five times in one chapter.**

**And both canonical endings close on a human act rather than an arrival.** A turning of hearts and a going up.

One closing observation, offered as an observation.

The corpus had, at the moment of the return, everything it would need to state a messianic expectation and attach it to a living Davidide. Zerubbabel was present, was of the line, and was called a signet by Haggai. Zechariah put him in a vision with a plummet in his hand and called him one of two sons of oil. And Ezra-Nehemiah, writing the return's own history, says nothing about it.

That silence is not evidence against the expectation, which Books VIII and XII documented across six books. It is evidence about where the expectation sits in the corpus's own account of what happened, and where it sits is not at the centre of the narrative of the restoration.

Books III and IV named a terminus and a deficit. Book V named a concession. Books VI through XII traced a figure who grows without limit and holds everything he holds by grant. Book XIII found a corpus that keeps its own prosecution. And Book XVII finds that corpus, at the end of its own story, closing on a permission and a turning of hearts, with the deficit stated five times in the confession that precedes it and the terminus unmentioned.

:::book XVIII | THE DWELLING


## 153. The Corpus's Other Menuḥah


Psalm 95:11 says they did not enter my rest. Psalm 132:14 says this is my resting place forever, here I will dwell. One word, one divine suffix, two psalms, two statements.

*Zoʾt menuḥati ʿadey ʿad, poh ʾeshev ki ʾiwwitiha.*

This is my resting place forever; here I will dwell, for I have desired it.

The referent is Zion, named in the preceding verse: *ki vaḥar YHWH be-Ṣiyyon, ʾiwwah le-moshav lo*, for the LORD has chosen Zion, he has desired it for his dwelling.

**Two verbs of desiring in two verses, both with God as subject.** *ʾIwwah* and *ʾiwwitiha*, from *ʾwh*, to desire or long for. The corpus's statement about why the place is chosen is a divine wanting, repeated.

**And the seated verb is *yšb*.** *Poh ʾeshev*, here I will dwell or sit. The same root as Deuteronomy 12:10's *wi-shavtem beṭaḥ*, you shall dwell in safety, and as 1 Chronicles 29:23's *wa-yeshev Shelomoh*, and Solomon sat.

**The relation between the two menuḥah-statements.** Psalm 95:11's is the people's unentered rest. Psalm 132:14's is God's own resting place, occupied.

Two readings.

**They are different objects sharing a word.** One is a condition and the other is a location. On this reading the coincidence of vocabulary is unremarkable.

**They are the same object read from two sides.** God's dwelling is where the people's rest is, and the corpus states that one party is in it and the other did not enter.

**This book prefers the first and records the second**, because the second is attractive and the corpus supplies no clause connecting the two psalms.

**What is not in doubt is the vocabulary's range.** *Menuḥah* denotes, in the corpus's own usage, a condition delivered to a people at Deuteronomy 12:9 and 1 Kings 8:56, a characterization of a man at 1 Chronicles 22:9, an unentered object at Psalm 95:11, and a place God dwells at Psalm 132:14. That is a wide range for a narrow word and it is worth having in view before the temple material is read.

## 154. The Tabernacle · A Dwelling That Moves


*We-ʿasu li miqdash we-shakhanti be-tokham.* And let them make me a sanctuary, that I may dwell among them. Exodus 25:8.

**The verb is *škn*, to dwell or tent**, and it is the root behind *mishkan*, the tabernacle, and behind the later term for the divine presence that this book does not use because it is post-biblical.

**Two features of the commission.**

**The making is theirs and the dwelling is his.** *We-ʿasu li*, and they shall make for me. *We-shakhanti*, and I will dwell. Two subjects, two verbs, and the second is not conditional on the first in the grammar though it follows it in the sequence.

**The specification is total and it is given.** Exodus 25:9: *ke-khol ʾasher ʾani marʾeh ʾotekha ʾet tavnit ha-mishkan we-ʾet tavnit kol kelaw we-khen taʿasu.* According to all that I show you, the pattern of the tabernacle and the pattern of all its furniture, so shall you make it. The word *tavnit*, pattern, recurs at 25:40 and 26:30 and 27:8.

**And the craftsmen are equipped.** Exodus 31:2-5: *reʾeh qaraʾti ve-shem Beṣalʾel ... wa-ʾamalleʾ ʾoto ruaḥ ʾelohim be-ḥokhmah u-vi-tvunah u-ve-daʿat u-ve-khol melaʾkhah.* See, I have called by name Bezalel, and I have filled him with the spirit of God, in wisdom and understanding and knowledge and all craftsmanship.

**Wisdom, understanding, and knowledge.** Three of the six qualities of Isaiah 11:2, given by a filling, to a metalworker, for the making of furniture. The corpus's first person equipped with a divine spirit for a task is a craftsman.

**And the tabernacle moves.** Numbers 9:15-23: the cloud covers it, and when the cloud is taken up they journey, and where the cloud settles they camp. *ʿAl pi YHWH yisʿu u-ʿal pi YHWH yaḥanu*, at the command of the LORD they journeyed and at the command of the LORD they camped, repeated five times in nine verses.

**The verb at 9:17 for the cloud's settling is *škn*.** *U-vi-meqom ʾasher yishkon sham he-ʿanan sham yaḥanu*. In the place where the cloud settled, there they camped.

**The structural point.** The corpus's first dwelling is portable, its pattern is shown rather than devised, its craftsmen are filled with a spirit, and its location is determined by a cloud. Nothing about it is held.

## 155. 2 Samuel 7 · The House Nobody Asked For


The dynastic oracle begins with a refusal of a building project and Chapter 59 noted the reversal. This chapter reads it as a temple text.

**7:1-2.** David sits in his house, the LORD has given him rest from all his enemies, and he says to Nathan: *ʾanokhi yoshev be-veyt ʾarazim wa-ʾaron ha-ʾelohim yoshev be-tokh ha-yeriʿah.* I dwell in a house of cedar and the ark of God dwells within curtains.

**Both verbs are *yšb*.** The king dwells and the ark dwells, in one sentence, and the contrast is between the materials.

**7:5-7 is the refusal and it is a question.** *Ha-ʾattah tivneh li vayit le-shivti?* Shall you build me a house to dwell in? And 7:6: *ki loʾ yashavti be-vayit le-mi-yom haʿaloti ʾet benei Yisraʾel mi-Miṣrayim we-ʿad ha-yom ha-zeh, wa-ʾehyeh mithallekh be-ʾohel u-ve-mishkan.* I have not dwelt in a house since the day I brought up the children of Israel from Egypt to this day, but have been moving about in a tent and a tabernacle.

**7:7.** *Ha-davar dibbarti ʾet ʾaḥad shivṭey Yisraʾel ʾasher ṣiwwiti lirʿot ʾet ʿammi ʾet Yisraʾel leʾmor lammah loʾ venitem li beyt ʾarazim?* Did I ever speak a word to any of the tribes of Israel whom I commanded to shepherd my people Israel, saying, why have you not built me a house of cedar?

**Three things in that verse.** The shepherding vocabulary of Book X. *ʿAmmi*, my people. And a rhetorical question establishing that no house was ever requested.

**Then the reversal at 7:11.** *We-higgid lekha YHWH ki vayit yaʿaseh lekha YHWH.* The LORD declares that the LORD will make you a house.

**The word *bayit* carries two senses and the oracle turns on the pun.** A building and a dynasty. David proposes to build a building; God says he will build a dynasty; and the building will be built by the son.

**7:13.** *Huʾ yivneh bayit li-shmi.* He shall build a house for my name.

*Li-shmi*, for my name. Not for me. The formula recurs at 1 Kings 8:17-20 five times in David's and Solomon's speeches, and Deuteronomy uses it throughout for the chosen place: *ha-maqom ʾasher yivḥar YHWH le-shakken shemo sham*, the place the LORD will choose to make his name dwell there, at Deuteronomy 12:11, 14:23, 16:2, 16:6, 16:11, 26:2.

**The name-formula is the corpus's own qualification of the dwelling.** What is in the house is the name.

## 156. 1 Kings 8 · Solomon's Own Qualification


The dedication prayer is the corpus's most extended treatment of what a temple is and it contains its own disclaimer.

**8:12-13, the opening.** *YHWH ʾamar li-shkon ba-ʿarafel. Banoh vaniti beyt zevul lakh, makhon le-shivtekha ʿolamim.* The LORD said he would dwell in thick darkness. I have surely built you an exalted house, a place for you to dwell in forever.

**And 8:27, fifteen verses later.** *Ki ha-ʾumnam yeshev ʾelohim ʿal ha-ʾareṣ? Hinneh ha-shamayim u-shmey ha-shamayim loʾ yekhalkelukha, ʾaf ki ha-bayit ha-zeh ʾasher baniti.*

But will God indeed dwell on the earth? Behold, heaven and the heaven of heavens cannot contain you; how much less this house that I have built.

**The builder states, in the dedication, that the building cannot contain the one it is built for.** That is the corpus placing its own qualification in the mouth of the man at the moment of completion.

**And the prayer's operative request is not for presence but for attention.** 8:29: *li-hyot ʿeynekha fetuḥot ʾel ha-bayit ha-zeh laylah wa-yom ʾel ha-maqom ʾasher ʾamarta yihyeh shemi sham, li-shmoaʿ ʾel ha-tefillah.* That your eyes may be open toward this house night and day, toward the place of which you said, my name shall be there, to listen to the prayer.

**Eyes open and a listening.** The two organs of Book IV, requested of God rather than of the people, in the temple's dedication.

**And the prayer's structure is seven petitions, each following the same shape.** A situation, a turning toward the house, and then *we-ʾattah tishmaʿ ha-shamayim*, and you shall hear in heaven. The formula recurs at 8:32, 8:34, 8:36, 8:39, 8:43, 8:45, and 8:49.

**Seven hearings, all located in heaven, all requested toward a house that cannot contain the hearer.**

**8:41-43 extends it to the foreigner.** *We-gam ʾel ha-nokhri ʾasher loʾ me-ʿammekha Yisraʾel huʾ u-vaʾ me-ʾereṣ reḥoqah le-maʿan shemekha ... we-ʾattah tishmaʿ ha-shamayim ... we-ʿasita ke-khol ʾasher yiqraʾ ʾeleykha ha-nokhri.* And also the foreigner who is not of your people Israel, when he comes from a far country for your name's sake, you shall hear in heaven and do according to all the foreigner calls to you for.

**And the stated purpose is knowledge.** 8:43: *le-maʿan yedʿun kol ʿammey ha-ʾareṣ ʾet shemekha le-yirʾah ʾotekha ke-ʿammekha Yisraʾel.* That all the peoples of the earth may know your name and fear you as your people Israel.

**The temple's stated function in its own dedication is to be a direction for prayer whose hearing happens elsewhere, and its stated reach includes the foreigner, and its stated purpose is a knowing.**

**And then 8:56, worked at Chapter 25.** Blessed be the LORD who has given rest to his people Israel.

The dedication ends on the terminus vocabulary, with the giver named, the recipient the people, and the measurement taken against Moses.

## 157. The Glory That Departs


Ezekiel narrates the presence leaving, in stages, and the staging is the point.

**Ezekiel 8-11 is one vision.** The prophet is taken by a lock of his head to Jerusalem, shown four abominations in the temple in escalating order, and then shown the departure.

**9:3.** *U-khevod ʾelohey Yisraʾel naʿalah me-ʿal ha-keruv ʾasher hayah ʿalaw ʾel miftan ha-bayit.* The glory of the God of Israel went up from the cherub on which it was, to the threshold of the house.

**10:4.** *Wa-yarom kevod YHWH me-ʿal ha-keruv ʿal miftan ha-bayit.* Repeated.

**10:18.** *Wa-yeṣeʾ kevod YHWH me-ʿal miftan ha-bayit wa-yaʿamod ʿal ha-keruvim.* The glory went out from the threshold and stood over the cherubim.

**10:19.** They lifted their wings and went up from the earth, and stood at the door of the east gate.

**11:23.** *Wa-yaʿal kevod YHWH me-ʿal tokh ha-ʿir wa-yaʿamod ʿal ha-har ʾasher mi-qedem la-ʿir.* The glory of the LORD went up from the midst of the city and stood on the mountain which is east of the city.

**Five stages.** From the cherub to the threshold. At the threshold. From the threshold to the cherubim. To the east gate. To the mountain east of the city.

**The departure is slow and the corpus narrates every stage.** That is not how the corpus narrates most things and the deliberateness is worth noticing.

**And 11:16 supplies the interim provision.** *Ki hirḥaqtim ba-goyim we-khi hafiṣotim ba-ʾaraṣot, wa-ʾehi lahem le-miqdash meʿaṭ ba-ʾaraṣot ʾasher baʾu sham.* Though I have removed them far off among the nations and scattered them among the countries, yet I have been to them a sanctuary in small measure in the countries where they have come.

*Miqdash meʿaṭ*, a sanctuary in small measure, or a little sanctuary. The corpus supplies, in the middle of the departure vision, a statement that the sanctuary function continues without the building.

**And the return is narrated at 43:1-5**, by the same gate. *We-hinneh kevod ʾelohey Yisraʾel baʾ mi-derekh ha-qadim ... wa-yavoʾ kevod YHWH ʾel ha-bayit derekh shaʿar ʾasher panaw derekh ha-qadim.* The glory came from the way of the east and entered the house by the gate facing east.

**43:7.** *Wa-yoʾmer ʾelay ben ʾadam ʾet meqom kisʾi we-ʾet meqom kappot raglay ʾasher ʾeshkon sham be-tokh benei Yisraʾel le-ʿolam.* And he said to me: son of man, the place of my throne and the place of the soles of my feet, where I will dwell among the children of Israel forever.

*Meqom kisʾi*, the place of my throne. In the temple vision of the book that gives its prince a bounded portion and a prescribed route.

## 158. The Presence and the Terminus


Book XVIII closes by relating the dwelling material to the argument.

**The corpus's dwelling vocabulary and its terminus vocabulary overlap at three points.**

**Psalm 132:14.** *Zoʾt menuḥati ʿadey ʿad, poh ʾeshev.* The terminus noun applied to the divine dwelling.

**1 Chronicles 28:2.** David's speech: *ʾani ʿim levavi li-vnot beyt menuḥah la-ʾaron berit YHWH we-la-hadom ragley ʾeloheynu.* I had it in my heart to build a house of rest for the ark of the covenant of the LORD and for the footstool of our God.

*Beyt menuḥah*, a house of rest. The terminus noun in a construct with a building, in the Chronicler's version of the 2 Samuel 7 scene.

**And Isaiah 66:1.** *Koh ʾamar YHWH, ha-shamayim kisʾi we-ha-ʾareṣ hadom raglay, ʾey zeh vayit ʾasher tivnu li we-ʾey zeh maqom menuḥati?*

Thus says the LORD: heaven is my throne and the earth is my footstool; where is the house you would build for me, and where is the place of my rest?

*Meqom menuḥati*, the place of my rest, in a rhetorical question denying that a built house can be it.

**Three sites. One says the place is Zion and God dwells there. One has a king proposing a house of rest for the ark. And one asks where such a place could possibly be.**

**And Isaiah 66:2 supplies the answer, and it is not a location.** *We-ʾet kol ʾelleh yadi ʿasatah wa-yihyu khol ʾelleh neʾum YHWH, we-ʾel zeh ʾabbiṭ ʾel ʿani u-nekheh ruaḥ we-ḥared ʿal devari.*

All these things my hand has made, and so all these things came to be, says the LORD. But to this one will I look: to the poor and contrite in spirit, and who trembles at my word.

**The corpus's sharpest question about where its own rest could be located is answered with a description of a person.** *ʿAni u-nekheh ruaḥ we-ḥared ʿal devari.* Poor, contrite in spirit, and trembling at the word.

**And *ḥared ʿal devari*, trembling at my word, is a reception.** The organ of Book IV, functioning.

**What Book XVIII establishes.**

The corpus's dwelling is portable before it is fixed, is qualified by its own builder at the moment of dedication, is described as containing a name rather than a presence, departs in five narrated stages, is replaced in the interim by a sanctuary in small measure, and is finally denied as a location for the divine rest in a verse that answers the question with a person's disposition.

**That is the same structure the whole book has been tracing, in a fourth register.** Not a possession. Not a container. A relation, stated in the corpus's own vocabulary, with the deficit's own organ as the condition.

:::book XIX | THE RESULT


## 159. The Removability Result · Six Substantive Contents


The criterion of Chapter 2 is now applied and this chapter states what survives the strip.

**Six contents are substantive under the test**, meaning the corpus states each somewhere in a passage naming no eschatological figure and no dated event.

**Covenant fidelity.** Deuteronomy 30:19-20: I have set before you life and death; choose life; to love the LORD your God, to obey his voice, and to cleave to him. Deuteronomy 10:12-13: what does the LORD your God ask of you, answered in five infinitives.

**Subordination of power to the teaching.** Deuteronomy 17:18-20: the king writes a copy, reads it all his days, and his heart is not lifted above his brothers. 1 Samuel 12:14-15: if you fear the LORD and serve him and obey his voice, then both you and the king who reigns over you shall follow the LORD your God.

**Refusal of self-certification.** Deuteronomy 13:2-6: a prophet or dreamer who gives a sign that comes to pass and says let us go after other gods shall not be heeded. Deuteronomy 18:21-22: the test of a word not spoken by the LORD is that it does not come to pass. Proverbs 27:2: *yehallelkha zar we-loʾ fikha*, let another praise you and not your own mouth. Jeremiah 9:22-23: the subtraction of wisdom, might, and riches.

**Hope preserved under collapse.** Ezekiel 37:11: *ʾaveda tiqwatenu nigzarnu lanu*, our hope is lost, we are cut off, quoted by God as the people's own words and answered in the following verses. Lamentations 3:21-24: *zoʾt ʾashiv ʾel libbi ʿal ken ʾoḥil, ḥasdey YHWH ki loʾ tamnu*, this I recall to my heart, therefore I have hope: the mercies of the LORD are not consumed. Jeremiah 29:11-14: *ki ʾanokhi yadaʿti ʾet ha-maḥashavot ʾasher ʾanokhi ḥoshev ʿaleykhem ... maḥshevot shalom we-loʾ le-raʿah la-tet lakhem ʾaḥarit we-tiqwah.*

**The justice-arc.** Amos 5:24: *we-yiggal ka-mayim mishpaṭ u-ṣedaqah ke-naḥal ʾeytan*, let justice roll down like waters and righteousness like an ever-flowing stream. Psalm 72:12-14, though that psalm is figure-indexed and its content is stated elsewhere without one. Isaiah 1:17: *dirshu mishpaṭ ʾashsheru ḥamoṣ shifṭu yatom rivu ʾalmanah.* Micah 6:8.

**And the terminus.** Deuteronomy 12:9. Joshua 21:44. 1 Kings 8:56. 1 Chronicles 22:9. Ezekiel 37:14. Psalm 95:11. Isaiah 11:9. Isaiah 2:4. Habakkuk 2:14.

**One note on the fifth entry.** Amos 5:24's anchor is the strongest of the justice-arc's because Amos contains no royal-figure material at all, so the content is stated in a book where the strip is vacuous. That is the cleanest form of a substantive verdict: a whole book carrying the content and no figure.

**And one note on the sixth.** The terminus has nine anchors across seven books, which is more than any of the other five. The content this book has been tracing is the one the corpus states most often without a figure.

## 160. What Fails the Strip · The Act-Layer


The criterion cuts and this chapter states what it cuts.

**What fails is the act-layer**: the gathering, the return to the land, the rebuilding, the restoration of offices, the reunification of the two houses.

**The failing sites.** Ezekiel 37:21, worked at Chapter 4. Ezekiel 36:24. Deuteronomy 30:3-5. Jeremiah 23:3. Isaiah 56:8. Micah 2:12. Psalm 147:2. Amos 9:11. In every case the act is the main verb and the whole content, and deleting the act leaves no residual predicate.

**A failed strip is not a demotion and Chapter 4 said so.** This chapter says it again because it is the point at which the whole book is most likely to be misread.

Ezekiel 37 is one of the great passages of the corpus. Its failure under a test that measures availability-without-a-figure says nothing about its importance, its truth, its centrality, or its standing. It says that the corpus does not state that content in a figure-free clause, which is a fact about the content's grammar and nothing else.

**And the criterion's verdict here is the least interesting thing about these passages.** What is interesting is what the corpus does with them, which is the subject of the next chapter.

## 161. The Purpose Clauses · Road and Destination in the Corpus's Own Grammar


The act-layer fails the strip. The corpus subordinates it grammatically wherever it states it. This chapter sets out the evidence, and it is the strongest single body of evidence in the book because the subordination is syntactic rather than interpretive.

**Deuteronomy 30:3-6.** The LORD will return your captivity and have compassion and gather you from all the peoples. If your outcasts are at the ends of heaven, from there he will gather you and from there he will take you. And he will bring you into the land your fathers possessed, and you shall possess it, and he will do you good and multiply you above your fathers.

**And then 30:6.** *U-mal YHWH ʾeloheykha ʾet levavekha we-ʾet levav zarʿekha le-ʾahavah ʾet YHWH ʾeloheykha be-khol levavkha u-ve-khol nafshekha **le-maʿan ḥayyekha**.*

And the LORD your God will circumcise your heart and the heart of your seed, to love the LORD your God with all your heart and all your soul, **that you may live**.

**The gathering runs for three verses and lands on a heart-circumcision, and the heart-circumcision carries a purpose clause whose object is life.** The acts are stated and then subordinated, in the corpus's own syntax, by *le-maʿan*.

**Ezekiel 36:24-28.** I will take you from among the nations and gather you from all the countries and bring you into your own land. I will sprinkle clean water on you and you shall be clean. I will give you a new heart and put a new spirit within you; I will remove the heart of stone and give you a heart of flesh. I will put my spirit within you and cause you to walk in my statutes. And you shall dwell in the land I gave your fathers.

**And then 36:28b.** *Wi-hyitem li le-ʿam wa-ʾanokhi ʾehyeh lakhem le-ʾelohim.* And you shall be my people and I will be your God.

**The sequence lands on the covenant formula.** Six acts and a relation, in that order, with the relation last.

**Ezekiel 37:21-23.** I will take the children of Israel from among the nations and gather them and bring them into their own land. And I will make them one nation. And one king shall be king over them all. They shall not defile themselves any more with their idols. I will save them and cleanse them.

**And then 37:23b.** *We-hayu li le-ʿam wa-ʾani ʾehyeh lahem le-ʾelohim.* Same formula, same position.

**And 37:14 supplies the terminus in the settling-root**, at the end of the preceding oracle, which Chapter 28 worked.

**Three sequences, three books' worth of act-material, and each lands somewhere else.** Deuteronomy 30 lands on a purpose clause. Ezekiel 36 and 37 land on the covenant formula. None of the three ends on the act.

**The result, stated exactly.** The corpus files the acts as road and states the destination separately. That is not a claim that the acts are unreal, unimportant, or optional. It is a claim about where the corpus's own grammar puts them, and the grammar is checkable at three named passages in two books.

## 162. Positioning Against the Prior Literature


Six positions and this book's relation to each.

**Menuḥah as land-gift, with an unresolved already-and-not-yet between Joshua and Psalm 95.** Von Rad and the literature following him. **This book is downstream of it.** The seam is not claimed as new. What is added is the removability criterion, the executed census of Book II, and the resulting sort of the royal material as means.

**The monarchy tension resolved by source division into pro- and anti-monarchic strands.** Classical source criticism on 1 Samuel 8 through 12, and the Deuteronomistic History hypothesis. **No position taken.** The book treats the final form's retention of both as the datum, which is compatible with any account of how it got there.

**Messianism as a comparatively late development not present in the pre-exilic royal texts.** Mowinckel and successors. **Compatible.** The escalation sequence redescribes the same material by content and commits to no dating beyond the corpus's own narrative order for its first three stages.

**The royal and future-royal texts as the interpretive centre toward which the corpus tends.** Much confessional and canonical-critical reading. **Directly opposed at the sorting**, though not on the reality or importance of the material. This book argues the corpus itself subordinates the acts to a state it names independently, and does so in three purpose clauses.

**The sabbath as institution and sign, studied on its own.** The extensive sabbath literature. **Adjacent.** This book's interest is in *menuḥah* as the promise's terminus rather than in sabbath observance as such, and it connects the two only through the root-field of Book II.

**Isaiah 6:9-10 as a hardening motif to be explained theologically or redactionally.** The hardening literature. **Used differently.** The book takes 6:9-10 with Deuteronomy 29:3, Isaiah 42:19, and Jeremiah 6:16 as a converging diagnosis of reception rather than as a problem about divine intent, and Chapter 39 states why it declines to solve the problem.

**A seventh position deserves naming because it is the one closest to this book.** The reading on which the Deuteronomistic material is fundamentally about obedience and its consequences, with the monarchy a subordinate theme. This book is adjacent to that and differs in one respect: it locates the corpus's terminus in a specific lexeme rather than in a general condition, and the specificity is what makes the census of Book II possible.

## 163. Falsification · The Three Criteria and Their Results


Chapter 6 stated three criteria before the evidence. This chapter returns them with results.

**F1, the terminus criterion.** If the terminal clauses are systematically figure-indexed, Book III fails.

**Executable:** run the concordance across the corpus, isolate terminal-position sites, and count agent-requirements.

**Result: does not fail, on the available instrument.** Book II executed an English-side census over the whole corpus: 878 field sites, 114 terminal-position candidates, 23 machine-marked. Of the 23, six were the editor's notes, six were the wrong sense of the English word, and eleven were genuine terminus sites at which a king stood as recipient with God named as giver. A direct subject test over the whole corpus returned zero verses in which a royal figure is the grammatical subject of giving rest.

**The residual debt is stated at Chapter 19 and is not discharged.** The Hebrew-side census is still owed and a reader with a Hebrew concordance can execute it.

**F2, the concession criterion.** If the corpus withdraws the concession rather than re-issuing it at higher intensity, Books V and VIII fail.

**Executable:** search for any withdrawal formula.

**Result: none exists.** 2 Samuel 7:15 explicitly bars the withdrawal against a named precedent. Hosea 13:11's taking is a taking of a king rather than a repeal of the institution, and Chapter 50 gave three reasons. Every removal in the corpus is the removal of an occupant: Saul, the northern dynasties, Coniah, Zedekiah.

**F3, the receiver criterion.** If Deuteronomy 29:3, Psalm 95:11, Isaiah 6:9-10, and Isaiah 42:19-20 can be read as locating the failure in an absent or withheld terminus, Book IV dissolves.

**Executable:** identify the subject of the deficiency in each.

**Result: all four place it in the heart, the ears, the eyes, or the hearing.** And Chapter 41 extended the search across eleven passages in five books and found no clause anywhere attributing the non-entry to the terminus. Chapter 41 also stated how to break the claim: produce one verse.

**Two further falsifiers were generated by the argument itself and are recorded here.**

**Chapter 100's negative.** Produce one verse in which a royal or messianic figure is the grammatical subject of the gathering. Eight sites in six books were surveyed and in every one the gatherer is God.

**Chapter 84's negative.** Produce one passage in which a figure gives a heart, opens an ear, or supplies knowledge to a people. This book has not found one. Jeremiah 3:15's shepherds who feed with knowledge and understanding is the closest, and it is plural and unnamed.

**And two claims that were falsified during the work are recorded as dead rather than removed.**

**The partial-removability claim.** An earlier version held that the messianic frame was only partly removable because the restoration material could not be stated without the act-layer. Ezekiel 37:14 falsified it: the corpus states the terminus in the settling-root at the end of the act-sequence.

**The Zechariah 6:13 fusion reading.** An earlier version read 6:13 as fusing two offices in one person. *Beyn shenehem*, between them both, falsified it.

## 164. The Limit Case · What Would Fall If the Figure Arrived


The sharpest question a critic can ask is what this book has at stake, and the answer is nothing.

**Suppose a royal figure of the expected kind arrives.** What in this book falls?

**Book II's census stands.** 878 field sites, 114 terminal candidates, zero verses with a royal subject of giving rest. An arrival does not change what the corpus says.

**Book III's terminus stands.** Named in the settling-root, delivered under Joshua, announced under Solomon, held four times in Judges, recorded as unentered at Psalm 95:11.

**Book IV's deficit stands.** Eleven passages, five books, three organs, and no clause attributing the failure to the terminus.

**Book V's concession stands.** The refusal at Judges 8:23, the demand quoted in advance at Deuteronomy 17:14, the itemized bill, the unanswered-outcry clause, the confession at 1 Samuel 12:19.

**Book VI's conferral grammar stands.** Fifteen sites, six books, two languages. An arriving figure who received what he holds would be the sixteenth.

**Books VIII and XII stand.** The escalation is a description of what the corpus does across eight stages, and an arrival at the end of it is the arrival of a means.

**The argument is that the figure is a means, and a means that arrives is a means that has arrived.**

No claim in this book rests on non-arrival. None predicts arrival. None adjudicates whether any historical claimant met the description. A reader looking for a book that argues against a messiah has picked up the wrong one, and a reader looking for a book that argues for one has too.

**And the converse case.** Suppose no figure ever arrives. Does that vindicate the book? No, and for the same reason. The book's claims are about the corpus's arrangement of its own materials, and non-arrival would be as irrelevant to them as arrival.

**What would actually falsify the book** is stated at Chapter 163 and is entirely internal: a verse. One verse with a royal subject of giving rest. One verse attributing the non-entry to the terminus. One verse with a figure gathering. One withdrawal formula. Any of them and the corresponding book fails.

That is the appropriate stake for a study of a corpus, and it is the only stake this book has.

## 165. Limits, Debts, and What Is Carried as Contested


**The principal debt is the Hebrew census.** Book II executed an English-side pass and stated at Chapter 19 exactly what it cannot do. The root-level ratio, the pericope-boundary test, the negative field, the verse identification beyond the quoted sites, and the OCR noise floor are all owed. The central result is a grammatical one and grammar is what English preserves best, so the direction is unlikely to reverse, but every figure in Book II should be treated as provisional.

**Two philological points are carried as contested and not silently resolved.** The referent of *soferim* and the parsing of *ʿasah* at Jeremiah 8:8. The subject of *wa-yitten* at Genesis 14:20. In each case the argument is constructed to hold under either reading.

**The index-type classification is an instrument of this book and not a property of the text.** Chapter 4 said so and it bears repeating at the end. The corpus performs the stripping operation, at Deuteronomy 30, Micah 6, Jeremiah 9, and Deuteronomy 10. It does not perform the taxonomy. The taxonomy is mine.

**The escalation sequence is ordered by content and not by date.** Chapters 8 and 75 said so twice and a reader who takes it as a compositional claim has taken more than is offered.

**The pair at Chapter 88 is the most contestable in the book.** Isaiah 11:1's two nouns may be a synonymous parallelism, and if they are, the Job 14:8 tension dissolves. The observation is offered with the objection stated at full strength.

**Chapter 39's decision not to resolve the hardening problem is a limit and not a finding.** A reader who holds that the hardening texts make the deficit wholly divine in origin will find this book's language occasionally more moralized than that reading permits, and the corrected form is given there.

**Chapter 125's standard applies to this book.** A corpus that states two things and reconciles neither has been read here by a reader who extracted one coherent position from it. That extraction is an interpretation. It is offered as one and the falsifiers of Chapter 163 are the form in which it can be tested.

**And one further limit, which is about the author rather than the argument.** This book is written from outside the guild and from a position of religious commitment, and states this plainly rather than implying a neutrality it does not have. The method is designed to make that irrelevant: the single-corpus constraint, the stated criterion, the executed census with its stated debt, and the falsification criteria are there so that the argument can be checked by a reader who shares none of the author's commitments and rejected by one who shares all of them.

## 166. Conclusion · The Rest Was Given, It Was Not Entered


The Hebrew Bible names the terminus of its promise in a root whose sense is settlement and not recuperation. It states that terminus as not yet reached at Deuteronomy 12:9, as delivered at Joshua 21:44 and twice more in that book, as held four times in Judges under four ordinary deliverers, as announced already given at 1 Kings 8:56 at the dedication of the temple, and as not entered at Psalm 95:11.

It locates the failure of entry in the hearing, the heart, the eyes, and a refusal spoken by the hearers themselves, across eleven passages in five books, and nowhere in a gift withheld.

It grants a visible monarchy against an itemized prosecution and a notice that the resulting outcry will go unanswered, seats the king on a throne it repeatedly calls God's, and subordinates the occupant to a written law he copies from another office's exemplar and reads for life.

When kings fail it re-issues the grant at higher intensity, eight times, without ever withdrawing it and without ever pointing back to the terminus it had already named.

And across the whole of that escalation, from a man anointed from a flask who hides among the baggage to one like a son of man receiving everlasting dominion in a night vision, the grammar by which the figure holds what he holds never changes. The verb is passive or the subject is God. At 2 Samuel 7:8, at Psalm 2:7, at Psalm 45:8, at Psalm 110:1, at Isaiah 9:5, at 1 Chronicles 29:23, at Ezekiel 34:23, and at Daniel 7:14 alike. And the title itself is a passive participle, naming what was done to its bearer.

**What the corpus does not do is confuse the two.** It states the destination in clauses containing no figure and no date, and it places the acts of gathering and restoration under purpose clauses whose object is the state those acts move toward. The road is real and the corpus commands it. It is simply not the destination, and the corpus says so in its own grammar.

That the shoot grows and the stump dies in the dust. That the persisting part is the root and the trigger is water already in the ground. That the paths are ancient and the instruction is to walk them and the answer recorded is *loʾ nelekh*, we will not walk. That the man named for the rest announced it in the temple and did not remain in it. That a king wrote a psalm calling himself a sheep. That the exile was priced in sabbaths the land did not get.

These are the corpus's own images for a gift that stands and is not taken up.

The census found no verse in which a king gives rest, and found eleven in which a king receives it. The subject test over the whole corpus returned one apparent counterexample and it was a commentator's note written in 1913.

**The rest was given. It was not entered. And on the corpus's own account the failure was never in the giving.**

:::book PART TWO | TWENTY-ONE EXCURSUS


Short studies that belong to the argument but would have interrupted it. Each is self-contained and each states its own weight.

## Excursus I. The Versification Problem at Isaiah 9


Isaiah 9:5 in the Hebrew is Isaiah 9:6 in most English versions, and the offset runs through the chapter because the Hebrew begins the chapter one verse earlier than the English. The Hebrew 8:23 is the English 9:1.

The difference matters here because Chapter 78 turns on the verse and a reader checking it in an English Bible will find the throne-name at 9:6 and the closing agent-clause at 9:7.

The general phenomenon is wider. The Psalms carry superscriptions as verse 1 in the Hebrew where English versions treat them as unnumbered headings, so Psalm 51:3 in the Hebrew is 51:1 in English and the offset is one or two depending on the length of the superscription. Joel is divided into four chapters in the Hebrew and three in most English versions, so the Hebrew 3:1's pouring out of the spirit is the English 2:28.

This book uses the Hebrew numbering throughout. Where a passage is likely to be checked, the English number is given at first occurrence in that book.

## Excursus II. Why the Four Roots Are Four and Not One


A reader may reasonably ask whether *šbt*, *nwḥ*, *šqṭ*, and *rgʿ* are genuinely distinct or whether the distinctions are an artifact of a modern reader's desire for precision.

Three tests support the distinction and one complicates it.

**The subjects differ systematically.** *Šbt*'s subject is a worker or an activity: God at Genesis 2:2, the manna at Joshua 5:12, the land at Leviticus 26:34. *Nwḥ*'s subject is a mover: the ark at Genesis 8:4, the spirit at Isaiah 11:2, the people as the object of the causative. *Šqṭ*'s subject is characteristically the land: Judges 3:11, 3:30, 5:31, 8:28, Joshua 11:23. *Rgʿ*'s subject is a person or a soul: Jeremiah 6:16, Deuteronomy 28:65.

**The corpus uses two of them side by side where a synonym would be redundant.** Isaiah 14:7: *naḥah shaqṭah kol ha-ʾareṣ*, two roots in one clause. 1 Chronicles 22:9: *menuḥah*, *hanihoti*, and *sheqeṭ* in one verse.

**They take different objects in the causative.** *Heniaḥ* takes a person or people. *Hishbit* takes an activity or a class of things: wild beasts at Leviticus 26:6, the shepherds at Ezekiel 34:10.

**The complication.** The distinctions are tendencies rather than absolutes. *Nwḥ* is used of the land at Isaiah 14:7 and *šbt* is used of persons in the sabbath legislation. A reader who wants to press the distinctions further than tendencies will be pressing them past what the data supports, and this book has tried not to.

## Excursus III. The Judges Cycle, Counted


The cycle in Judges has five elements and they recur with enough regularity to be counted.

Israel does evil in the sight of the LORD. The LORD gives them into the hand of an oppressor. They cry out. The LORD raises a deliverer. The land is quiet.

**The doing-evil formula** *wa-yaʿasu venei Yisraʾel ha-raʿ be-ʿeyney YHWH* occurs at 2:11, 3:7, 3:12, 4:1, 6:1, 10:6, and 13:1. Seven occurrences.

**The outcry formula** *wa-yizʿaqu venei Yisraʾel ʾel YHWH* occurs at 3:9, 3:15, 4:3, 6:6, and 10:10. Five occurrences.

**The raising formula** *wa-yaqem YHWH ... moshiaʿ* or *shofeṭ* occurs at 2:16, 2:18, 3:9, and 3:15.

**The quiet formula** *wa-tishqoṭ ha-ʾareṣ* occurs at 3:11, 3:30, 5:31, and 8:28. Four occurrences.

The four terminus-deliveries therefore stand inside a cycle whose other elements occur five to seven times each. The quiet formula is the rarest of the four elements, which means the corpus records more oppressions and more outcries than deliverances into quiet, and the ratio is a fact worth having.

**And the raising verb is *qwm* in the hiphil with God as subject**, which is Chapter 62's verb in Ezekiel 34:23 and Jeremiah 23:4.

## Excursus IV. Gideon's Ephod


Judges 8:24-27 records that Gideon, having refused the crown, asked for the golden earrings of the spoil, received seventeen hundred shekels of gold, and made an ephod which he set up in his city.

*Wa-yizu khol Yisraʾel ʾaḥaraw sham wa-yehi le-Gidʿon u-le-veyto le-moqesh.* And all Israel went whoring after it there, and it became a snare to Gideon and to his house.

Three readings are available.

**The cynical reading.** The refusal was pious words and the ephod is the substance of the office acquired under another name. On this reading the narrative is an exposure.

**The tragic reading.** The refusal was genuine and the narrative shows how quickly the apparatus of a cult and a household accrues to a man who has declined the title. Seventy sons, many wives, a gold object, and a son named my-father-is-king.

**The compositional reading.** The refusal and the ephod come from different hands and the tension is a seam.

This book takes none of them. What is load-bearing at Chapter 42 is the sentence at 8:23, and the sentence stands in the received text whatever the narrative does with the man afterwards.

One observation the three readings share. **The corpus put both in the same chapter.** Whatever the composition, the assembly retained the refusal and the ephod, nine verses apart, without comment. That is Book XIII's habit operating in Judges.

## Excursus V. The Ark, and What It Is Not


The ark is the corpus's most portable holy object and it is worth a note because it resists the conclusion a reader might draw from Book VI.

Books VI and X argued that what Israel holds is stated as received and that the flock's ownership never transfers. A reader might extend that to conclude that the corpus never states Israel as possessing anything.

The ark complicates that. It is made to specification at Exodus 25:10-22, carried by Israel, and 1 Samuel 4 has it taken into battle as though it guaranteed victory. It does not: Israel is defeated, thirty thousand foot soldiers fall, the ark is captured, and Eli falls backward and breaks his neck at the news.

**And the corpus's judgment on the episode is delivered by the enemy.** 1 Samuel 4:7-8, the Philistines: *baʾ ʾelohim ʾel ha-maḥaneh ... mi yaṣṣilenu mi-yad ha-ʾelohim ha-ʾaddirim ha-ʾelleh.* God has come into the camp; who will deliver us from the hand of these mighty gods?

**And then the ark defeats them without Israel.** 1 Samuel 5: Dagon falls on his face before it twice, the second time with head and hands cut off on the threshold; the people of Ashdod and Gath and Ekron are struck; and 1 Samuel 6 has the Philistines return it on a new cart drawn by two milk cows with a guilt offering of golden tumours and mice.

The episode is the corpus's clearest statement that the object is not a possession that can be deployed. Israel takes it out and loses; the Philistines take it home and are afflicted; it returns without anyone fetching it.

**The relevance to this book is one sentence.** The corpus has a category for a holy thing that Israel carries and does not control, and the ark is it. That is the same category the throne of 1 Chronicles 29:23 falls into and the flock of Ezekiel 34 falls into.

## Excursus VI. Uzzah, and the Cost of Steadying


2 Samuel 6:6-7. The ark on a new cart, the oxen stumbling at the threshing floor of Nacon, Uzzah putting out his hand to steady it, and dying there.

*Wa-yiḥar ʾaf YHWH be-ʿUzzah wa-yakkehu sham ha-ʾelohim ʿal ha-shal.* The reading of *ha-shal* is uncertain and the parallel at 1 Chronicles 13:10 has *ʿal ʾasher shalaḥ yado*, because he put out his hand.

David's response is recorded and it is not pious. 6:8: *wa-yiḥar le-Dawid ʿal ʾasher paraṣ YHWH pereṣ be-ʿUzzah*, and David was angry because the LORD had broken out against Uzzah. And 6:9: *wa-yiraʾ Dawid ʾet YHWH ba-yom ha-huʾ wa-yoʾmer ʾeykh yavoʾ ʾelay ʾaron YHWH.* And David feared the LORD that day and said, how shall the ark of the LORD come to me?

The episode is included here for one reason. It is the corpus's sharpest instance of a category error being fatal: a man treats a holy object as a thing requiring his assistance, and the corpus records the outcome without explaining it, and records the king's anger about it.

Chapter 91's fence at Habakkuk 2:19 is the same distinction from the other side. The manufactured thing has to be told to get up. The real one requires silence and does not require steadying.

This excursus makes no argument. It records that the corpus has a story about the difference and that the story is unresolved in the text.

## Excursus VII. The Name at Jeremiah 23:6 and 33:16


*We-zeh shemo ʾasher yiqreʾo YHWH ṣidqenu*, and this is his name by which he shall be called, the LORD our righteousness, at Jeremiah 23:6, of the Branch.

*We-zeh ʾasher yiqraʾ lah YHWH ṣidqenu*, and this is what she shall be called, the LORD our righteousness, at Jeremiah 33:16, of Jerusalem.

The same name, applied to a person in one chapter and to a city in another, in one book.

**That distribution tells against reading the name as a claim about the bearer's nature.** A theophoric name applied to a city is a confession about God made in connection with the city, not an assertion that the city is God. The corpus's own second application supplies the control.

**The construction is common in Israelite naming.** Personal names of the form divine-element plus predicate are ordinary: Elijah, my God is YHWH. Ezekiel, God strengthens. Isaiah, YHWH saves. Zedekiah, YHWH is my righteousness, which is the same elements as Jeremiah 23:6 with a first-person singular suffix, and Zedekiah is the last king of Judah whose reign the same book narrates.

**That last point is worth having.** Jeremiah gives the Branch a name that is Zedekiah's name pluralized, in a book that records Zedekiah's blinding at 39:7 and 52:11. Whether the wordplay is deliberate is unknowable and the elements are there.

## Excursus VIII. Solomon's Request, Read Against Book IV


1 Kings 3:5-14. The dream at Gibeon, the offer, the request, and the grant.

*We-natatta le-ʿavdekha lev shomeaʿ li-shpoṭ ʾet ʿammekha le-havin beyn ṭov le-raʿ.* Give your servant a hearing heart to judge your people, to discern between good and evil.

**Three of Book IV's terms are in that clause.** *Lev*, heart, the organ of Deuteronomy 29:3. *Shomeaʿ*, hearing, the faculty of Psalm 95:7 and 1 Samuel 8:19. And *le-havin*, to discern, from *byn*, the verb Isaiah 6:9 negates: *shimʿu shamoaʿ we-ʾal tavinu*.

**And the request is for a giving.** *We-natatta*, and you shall give. The king asks for the organ Deuteronomy 29:3 says was not given.

**The divine response grants it and adds what was not asked.** 3:12: *hinneh natatti lekha lev ḥakham we-navon*, behold I have given you a wise and discerning heart. And 3:13: *we-gam ʾasher loʾ shaʾalta natatti lakh gam ʿosher gam kavod*, and also what you did not ask I have given you, both riches and honour.

**And 3:14 attaches a condition.** *We-ʾim telekh bi-drakhay li-shmor ḥuqqay u-miṣwotay ka-ʾasher halakh Dawid ʾavikha we-haʾarakhti ʾet yameykha.* And if you walk in my ways, keeping my statutes and my commandments as David your father walked, then I will lengthen your days.

The conditional applies to the length of days, not to the wisdom. The gift is unconditional and the tenure is not, which is the same structure as 2 Samuel 7:14-15 and Psalm 132:12.

**And 1 Kings 11:4's verdict uses the same organ.** *Loʾ hayah levavo shalem ʿim YHWH.* His heart was not whole with the LORD. The corpus gives the man the organ he asked for and reports at the end that the organ failed.

## Excursus IX. What Happened to the Northern Kingdom's Expectation


The corpus is a Judahite document in its final form and the northern kingdom's own royal theology is largely absent from it. This excursus records what can be said and what cannot.

**What is recorded.** Nine dynasties in roughly two centuries, most of them founded by assassination: Jeroboam, Baasha, Zimri, Omri, Jehu, and the rest. 1 Kings 16 alone records three changes of dynasty. The corpus's judgment on all of them is a formula: *wa-yaʿas ha-raʿ be-ʿeyney YHWH wa-yelekh be-derekh Yarovʿam*, he did evil in the sight of the LORD and walked in the way of Jeroboam.

**Hosea 8:4's statement.** *Hem himlikhu we-loʾ mimmenni, hesiru we-loʾ yadaʿti.* They made kings and not from me; they removed and I did not know. That is the corpus's clearest statement about northern kingship and it denies divine appointment for the whole institution there.

**And Jeroboam did receive a dynastic promise.** 1 Kings 11:38, from Ahijah: *we-hayah ʾim tishmaʿ ʾet kol ʾasher ʾaṣawwekha ... u-vaniti lekha vayit neʾeman ka-ʾasher baniti le-Dawid.* If you listen to all I command you, I will build you a sure house as I built for David.

**A conditional dynastic promise to the northern founder, in the corpus, and it fails.** 1 Kings 14:7-11 records Ahijah's second oracle against him and 15:29 records the extermination of his house.

**What cannot be said.** Whether the northern kingdom carried its own royal ideology, whether it had messianic expectations, and what they looked like. The corpus does not preserve northern royal psalms as such, and any reconstruction would require material this book does not use.

The excursus exists to mark the gap. Half the population of the united monarchy is represented in this corpus by a formula of condemnation and a failed conditional promise, and a reader should know that the royal theology examined in this book is a Judahite one.

## Excursus X. Sabbath, Sabbatical Year, and Jubilee


The seventh position is legislated at three scales and the three are worth separating.

**The seventh day.** Exodus 20:8-11, Deuteronomy 5:12-15, Exodus 31:12-17, Leviticus 23:3. Cessation from work, extended to household, slaves, cattle, and the resident alien.

**The seventh year.** Exodus 23:10-11, Leviticus 25:1-7. *Shabbat shabbaton yihyeh la-ʾareṣ shabbat la-YHWH*, a sabbath of solemn rest for the land, a sabbath to the LORD. The field is not sown, the vineyard not pruned, and what grows of itself is for the owner, the servants, the hired hand, the resident alien, the cattle, and the beasts.

**The fiftieth year.** Leviticus 25:8-55. Seven sabbaths of years, forty-nine, and then the jubilee proclaimed on the day of atonement with the trumpet. *U-qeraʾtem deror ba-ʾareṣ le-khol yosheveha.* Liberty proclaimed throughout the land to all its inhabitants. Each returns to his possession and to his family. Land reverts. Israelite debt-slaves go free.

**And the ground given for the land legislation is ownership.** Leviticus 25:23: *we-ha-ʾareṣ loʾ timmakher li-ṣmitut ki li ha-ʾareṣ ki gerim we-toshavim ʾattem ʿimmadi.* The land shall not be sold in perpetuity, for the land is mine; you are strangers and sojourners with me.

**That verse belongs with Book VI.** The corpus's economic legislation about the land is grounded in a statement that the land is God's and Israel is resident on it. The same relation the throne texts state, in the register of property law.

**And the exile is priced against this legislation**, at 2 Chronicles 36:21 and Leviticus 26:34-35, which Chapter 30 worked. The land takes the sabbaths it was owed under Leviticus 25 while the people are away.

## Excursus XI. The Verb Šwv and the Two Returns


*Šwv* is one of the corpus's most frequent verbs and it carries two senses that both matter here: to return physically, and to turn back or repent.

**The physical sense.** Deuteronomy 30:3's *we-shav YHWH ʾeloheykha ʾet shevutekha*, and the LORD will return your captivity. Jeremiah 29:14, Ezekiel 39:25, and the whole restoration vocabulary.

**The repentance sense.** Hosea 14:2: *shuvah Yisraʾel ʿad YHWH ʾeloheykha*, return, Israel, to the LORD your God. Joel 2:12: *shuvu ʿaday be-khol levavkhem*, return to me with all your heart. Isaiah 6:10's *wa-shav we-rafaʾ lo*, lest they turn and be healed. Jeremiah 3, where the root occurs in various forms more than a dozen times in one chapter.

**And Deuteronomy 30 uses both in one passage.** 30:2: *we-shavta ʿad YHWH ʾeloheykha*, and you shall return to the LORD your God, which is the repentance sense with the people as subject. 30:3: *we-shav YHWH ʾeloheykha ʾet shevutekha we-riḥamekha we-shav we-qibbeṣkha*, the physical sense with God as subject, and the verb repeated.

Four occurrences of the root in two verses, alternating subjects.

**The relevance.** The corpus's word for the act it asks of the people and its word for the act it attributes to God in restoring them are the same word. That is a lexical fact and this book builds nothing on it, since a common verb doing double duty is unremarkable in any language. It is recorded because a reader tracking the argument's grammar will meet the alternation and should know it is there.

## Excursus XII. The Deuteronomy 18 Prophet


Deuteronomy 18:15-22 is sometimes brought into messianic discussions and this excursus states why this book does not use it.

*Naviʾ mi-qirbekha me-ʾaḥeykha kamoni yaqim lekha YHWH ʾeloheykha, ʾelaw tishmaʿun.* A prophet from your midst, from your brothers, like me, the LORD your God will raise up for you; to him you shall listen.

**The conferral grammar holds**, as everywhere: *yaqim lekha YHWH*, the LORD will raise up for you, hiphil with God as subject.

**But the passage's own frame is institutional rather than singular.** 18:9-14 forbids divination, soothsaying, augury, sorcery, and consulting the dead. 18:15 then supplies the alternative: a prophet. And 18:20-22 gives the test for distinguishing a true prophet from a false one, which presupposes plural prophets and an ongoing problem of identification.

A passage that supplies a test for telling prophets apart is legislating for a category, not announcing an individual.

**The singular is generic.** The construction is the same as Deuteronomy 17:15's *som tasim ʿaleykha melekh*, which no one reads as announcing a single king.

**The passage has been read messianically for a long time and this book does not say that reading is wrong.** It says the passage's internal evidence supports an institutional reading, that the institutional reading is the majority scholarly one, and that nothing in this book's argument requires either.

**One feature is worth taking.** *ʾElaw tishmaʿun*, to him you shall listen, is the hearing imperative of Book IV, attached to a prophetic office. And 18:19: *we-hayah ha-ʾish ʾasher loʾ yishmaʿ ʾel devaray ʾasher yedabber bi-shmi ʾanokhi ʾedrosh me-ʿimmo.* And whoever does not listen to my words which he speaks in my name, I will require it of him.

The corpus attaches a sanction to the failure of hearing at the one place it institutes a mediating office, which is the strongest thing this book can say about a passage it otherwise sets aside.

## Excursus XIII. What the Septuagint Does Differently, at Three Points


This book uses the Masoretic Text and does not practise textual criticism. Three divergences are worth noting because they bear on passages the argument uses.

**Isaiah 7:14.** The Hebrew *ha-ʿalmah* is a young woman of marriageable age; the Septuagint renders it *parthenos*, which carries a narrower sense. The divergence is old and its consequences are enormous for the history of interpretation. Nothing in this book depends on the verse.

**Zechariah 9:9.** The Hebrew *we-noshaʿ* is a nifal participle and passive: saved. The Septuagint renders with an active sense and many English versions follow. Chapter 115 uses the Hebrew and states the divergence there.

**Isaiah 6:13.** The final clause *zeraʿ qodesh maṣṣavtah*, the holy seed is its stump, is commonly held to be absent from the Septuagint and from the great Isaiah scroll. Chapter 89 states that the argument does not require the clause.

**And a fourth, of a different kind.** The Septuagint's Jeremiah is roughly one-eighth shorter than the Masoretic and its chapters are ordered differently, with the oracles against the nations in a different position. This is the largest divergence between the two traditions in any prophetic book and it is a live area of study. Nothing in this book turns on the order of Jeremiah's chapters.

The excursus exists to mark that the textual situation is not simple and that a reader checking this book's claims against a translation may be checking against a different base text.

## Excursus XIV. The Two Names for the Corpus, and Why It Matters Here


The body of writing this book examines is called the Hebrew Bible, the Tanakh, the Old Testament, and the Miqra, and the choice among those names is not neutral.

**Old Testament** presupposes a New one and therefore presupposes a canon this book excludes. Using it would contradict the scope law of Chapter 1 in the act of stating it.

**Tanakh** is an acronym for Torah, Neviʾim, Ketuvim, and it names the corpus by its own internal division. It is accurate and it is a term of the Jewish tradition, which carries an implication this book cannot honour, since this book declines to read through that tradition's interpretive corpus.

**Miqra**, that which is read, is likewise internal.

**Hebrew Bible** is the term most nearly neutral among readers who do not share a canon, and it is the term this book uses. It is not perfectly neutral: Bible is a Christian-inflected word in English usage, and the corpus contains Aramaic. Both objections are real and neither has a better alternative attached.

The excursus is included because a book whose whole method is a scope law should say how it names the thing it has scoped, and should not pretend the naming was costless.

## Excursus XV. The Four Royal Titles Compared


The corpus has four principal words for a ruler and they are not interchangeable.

***Melekh*, king.** The common word, from a root meaning to rule or reign. Used of Israelite kings, foreign kings, and God. It is the word the people demand at 1 Samuel 8:5, the word Deuteronomy 17:14 regulates, and the word Zephaniah 3:15 applies to YHWH.

***Nagid*, prince, designate, or leader.** From *ngd*, to be in front or to be told. Its distribution is striking. It is the word in the divine speech at 1 Samuel 10:1 where Samuel anoints Saul, at 1 Samuel 13:14 where God seeks a man after his own heart, at 2 Samuel 5:2 where the elders quote God, and at 2 Samuel 7:8 where God recalls taking David from the pasture.

**In every one of those four the speaker is God or is quoting God, and the higher word *melekh* stands nearby in the human speech.** 2 Samuel 5:2-3 is the sharpest: the elders quote God saying *nagid*, and in the next verse they anoint him *le-melekh*. The corpus puts the lower title in the divine mouth and the higher in the human one.

***Nasiʾ*, prince or lifted one.** From *nśʾ*, to lift or carry, and therefore passive in force: one who has been lifted up. Common in the Priestly material for tribal chiefs, and Ezekiel's preferred term for the coming figure, at 34:24, 37:25, and throughout the temple vision.

***Moshel*, ruler.** An active participle from *mšl*, to rule. This is the word Gideon declines at Judges 8:23, the word Micah 5:1 uses of the one from Bethlehem, and the word behind Zechariah 9:10's *u-mosholo*, his dominion.

**Set the four side by side and the pattern is visible.** *Melekh* is the demanded word. *Nagid* is the divine word and is lower. *Nasiʾ* is passive in its morphology and is the exilic prophet's choice. And *moshel* is the one active participle, and it is the word the corpus's first refusal declines.

That distribution is offered as an observation and not as an argument, because title-usage in the corpus is not tidy and counterexamples exist. What it adds to Book VI is one more piece of evidence, at the level of vocabulary, running the same direction as the verbs.

## Excursus XVI. What ʿOlam Means Here


*ʿOlam* is usually rendered forever and the rendering is often right and sometimes not, and the difference matters at three points in this book.

**The root's sense is duration whose end is not in view.** It covers the remote past as readily as the remote future: *yemey ʿolam*, the days of old, at Deuteronomy 32:7, Isaiah 63:9, Amos 9:11, and Micah 7:14; *netivot ʿolam*, the ancient paths, at Jeremiah 6:16; *gevul ʿolam*, the ancient boundary, at Proverbs 22:28.

**It is used of bounded durations.** Exodus 21:6, the slave who declines manumission serves his master *le-ʿolam*, which is his lifetime. 1 Samuel 1:22, Hannah says Samuel will remain *ʿad ʿolam*, and 1:28 glosses it *kol ha-yamim ʾasher hayah*, all the days he lives.

**And it is used of the genuinely unbounded**, of God at Psalm 90:2, *me-ʿolam ʿad ʿolam ʾattah ʾel*, from everlasting to everlasting you are God.

**Where it matters here, three sites.**

**2 Samuel 7:13 and 7:16's *ʿad ʿolam*.** On the strongest reading the dynastic grant is unbounded. On the bounded reading it is a grant whose end is not in view, which is a weaker claim. Psalm 89:39-46's complaint that the covenant was renounced is the corpus's own evidence that at least one of its writers held the grant to have been terminable in fact whatever the formula said.

**Psalm 110:4's *le-ʿolam*.** A priesthood forever, sworn.

**Psalm 132:14's *ʿadey ʿad*.** A different and stronger formula, doubled, of the divine dwelling in Zion.

**This book does not adjudicate the sense at any of the three** and notes that the range exists. A reader who takes *ʿolam* as unbounded everywhere will find the corpus asserting several unbounded grants that its own laments say failed, which is a real problem and is Book XIII's habit operating on the largest possible object.

## Excursus XVII. The Horn


*Qeren*, horn, is the corpus's image for the strength of a royal or personal position and it runs through the material this book has read.

**As the anointing vessel.** *Qeren ha-shemen* at 1 Samuel 16:13 for David and 1 Kings 1:39 for Solomon, against *pakh ha-shemen* for Saul and Jehu.

**As the image of exaltation.** 1 Samuel 2:1, Hannah's song: *ramah qarni ba-YHWH*, my horn is exalted in the LORD. And 2:10, the song's close: *we-yitten ʿoz le-malko we-yarem qeren meshiḥo*, he will give strength to his king and exalt the horn of his anointed.

**That verse deserves notice.** It is the first occurrence of *meshiaḥ* in the books of Samuel, it is in a song sung before any king exists, and both of its verbs are divine: he will give, he will exalt.

**Psalm 132:17.** *Sham ʾaṣmiaḥ qeren le-Dawid.* There I will cause a horn to sprout for David. The Branch verb and the horn noun in one clause, with God as subject.

**Psalm 89:18 and 89:25.** *Ki tifʾeret ʿuzzamo ʾattah u-vi-rṣonekha tarum qarnenu*, and *u-vi-shmi tarum qarno*. In my name his horn shall be exalted.

**Psalm 92:11.** *Wa-tarem ki-rʾem qarni*, you have exalted my horn like that of a wild ox.

**Ezekiel 29:21.** *Ba-yom ha-huʾ ʾaṣmiaḥ qeren le-veyt Yisraʾel.* The same construction as Psalm 132:17, of the house of Israel rather than of David.

**Daniel 7 and 8** use the image for kingdoms, and Daniel 7:8's little horn is the passage's antagonist.

**The pattern.** In every instance where a horn is exalted for an Israelite figure, the exalting verb is divine. *Yarem*, *tarum*, *ʾaṣmiaḥ*, *wa-tarem*: the horn is raised, and the raiser is named.

That is Chapter 62's grammar in a fifth register, and it is offered at that weight: as one more small piece running the same direction, not as an independent argument.

## Excursus XVIII. Seven, and the Terminus


The number seven attaches to the terminus material with enough regularity to be worth recording, and with enough looseness that nothing is built on it.

**The seventh day.** Genesis 2:2-3, blessed and sanctified, the only member of a seven-part series left unclosed by the evening-and-morning formula.

**The seventh year.** Leviticus 25:1-7, a sabbath for the land.

**The seven-times-seven and the fiftieth.** Leviticus 25:8-10, the jubilee, liberty proclaimed.

**The seventy years.** Jeremiah 25:11 and 29:10, and 2 Chronicles 36:21's accounting of them as unkept sabbaths. Seventy is ten sevens and the Chronicler makes the sabbatical connection explicit.

**The seven petitions of Solomon's prayer.** 1 Kings 8:32, 34, 36, 39, 43, 45, 49, each closing *we-ʾattah tishmaʿ ha-shamayim*.

**The sevenfold spirit.** Isaiah 11:2, either six qualities in three pairs with *ruaḥ YHWH* as a summary, or seven with it as the first.

**The seven-branched lampstand** of Exodus 25:31-40 and of Zechariah 4:2, with its seven lamps and, in Zechariah, seven pipes.

**And Zechariah 3:9's seven eyes on one stone**, and 4:10's *shivʿah ʾelleh ʿeyney YHWH hemmah meshoṭeṭim be-khol ha-ʾareṣ*, these seven are the eyes of the LORD running to and fro through the whole earth.

**What can be said.** The number recurs at the terminus positions, in the sabbath legislation at three scales, in the exile's accounting, in the temple prayer's structure, in the equipping of the figure, and in the lampstand.

**What cannot.** Any inference from the recurrence. Seven is the corpus's most common structuring number and it recurs everywhere, including in material with no relation to this book's subject. A pattern that appears both where a thesis predicts it and where the thesis says nothing is not evidence for the thesis.

The excursus exists because a reader tracking the terminus vocabulary will notice the sevens and should know both that they are there and that this book declines to use them.

## Excursus XIX. The Passages This Book Did Not Use


An honest accounting of what was left out, because a study whose selection is invisible is a study whose selection cannot be checked.

**Set aside as too contested to carry weight.** Genesis 3:15, Genesis 49:10, Daniel 9:24-27. Chapters 127, 128, and 117 state the reasons in each case, and in each the reason is lexical or text-critical rather than theological.

**Set aside as belonging to a different question.** Deuteronomy 18:15-22, treated at Excursus XII and read as institutional rather than singular. Isaiah 7:14, named at Chapter 111 and used for nothing. Zechariah 13:7, quoted at Chapter 97 and explicitly not attempted.

**Set aside for want of competence.** Isaiah 52:13-53:12's substitution language, which Chapter 143 declines and says why at length. This is the largest single omission in the book and it is the one most likely to make a reader feel the study has evaded its subject. The reason is stated rather than concealed: a book that has declined to enter the servant identification cannot then adjudicate what the fourth song claims about the servant's suffering, and doing so in one chapter would have been pretending to a competence not demonstrated anywhere else.

**Set aside by the scope law.** Every reading of every passage above produced by any tradition after the closing of the Hebrew canon. Appendix J names them.

**Genuinely not searched.** The wisdom books were surveyed at Chapters 133 and 134 and the survey was for the absence of royal-figure material rather than for the presence of terminus vocabulary. Proverbs, in particular, carries a substantial body of material about the heart, the ear, and knowledge that a fuller treatment would work. Chapter 134 quotes three verses and there are more.

**And the Song of Songs was not read at all** beyond confirming that it contains no royal-figure material. That is a whole book of the canon dismissed in a clause, and the clause is honest about it.

**Two further gaps that a reader should know about.**

**The northern kingdom's royal theology**, addressed at Excursus IX, which reports that the corpus preserves almost nothing of it and that this book therefore examines a Judahite royal theology and says so.

**And the census's own unsearched field**, at Chapter 19: the complementary count of where a royal figure appears without the terminus vocabulary, which would say whether the two vocabularies avoid each other or merely fail to coincide. That is the single most useful further study this book's method suggests and it was not run.

## Excursus XX. Ṣedeq, and the Element in Two Jerusalemite Names


The root *ṣdq* runs through the royal material and its distribution is worth a note because it connects three passages this book treats separately.

**The two Jerusalemite kings.** *Malki-Ṣedeq* at Genesis 14:18 and *ʾAdoni-Ṣedeq* at Joshua 10:1. Chapter 56 used the pair to establish that the *ṣedeq* element is a local dynastic form and not an isolated anomaly, which is what makes Psalm 110:4's patterning of a royal priesthood on Melchizedek's order legible as a claim about a real institution rather than a legendary one.

**The Branch's name.** Jeremiah 23:5's *ṣemaḥ ṣaddiq*, a righteous Branch, and 33:15's *ṣemaḥ ṣedaqah*, a Branch of righteousness. And the name at 23:6, *YHWH ṣidqenu*, the LORD our righteousness, which Excursus VII noted is applied to Jerusalem at 33:16 as well.

**The last king's name.** *Ṣidqiyyahu*, Zedekiah, my righteousness is YHWH, the same elements with a first-person singular suffix. The corpus gives the Branch a name that is the last Davidic king's name in the plural, in a book that records that king's blinding at 39:7.

**The royal function.** Psalm 72:1-2's *mishpaṭeykha le-melekh ten we-ṣidqatkha le-ven melekh*, give the king your judgments and your righteousness to the king's son, followed by *yadin ʿammekha ve-ṣedeq*. Isaiah 9:6's establishing of the throne *be-mishpaṭ u-vi-ṣdaqah*. Isaiah 11:4-5's judging *be-ṣedeq* and *ṣedeq ʾezor motnaw*, righteousness the belt of his loins. Jeremiah 23:5's Branch executing *mishpaṭ u-ṣedaqah ba-ʾareṣ*.

**And the divine possession of it.** Psalm 72:1 asks God to give *ṣidqatkha*, your righteousness, to the king. The quality the royal material most consistently attributes to the figure is, in the psalm that most fully describes it, requested as a transfer from its owner.

**Two observations.**

**The element is Jerusalemite before it is Israelite**, on the corpus's own witness at Joshua 10:1, and the corpus does not conceal it. That belongs with Chapter 124's pattern of acknowledged receipt.

**And where the corpus states the figure's righteousness at its fullest, at Psalm 72:1, it states it as given.** Chapter 103 worked the verse. It is one more site for Appendix D's list and it was not included there because the object of the giving is a quality rather than an office, which is a distinction worth keeping.

## Excursus XXI. The Criterion Applied to This Book


Audit symmetry requires that a study submit to the instrument it runs, and this excursus does that.

**The question.** Apply the removability criterion to this book's own central claim. Strip the figure-framing and ask what proposition remains.

**The claim.** The Hebrew Bible names a terminus in a specific vocabulary, states it as given and unentered, locates the failure in the receiver, concedes a monarchy under protest, escalates a royal figure eight times, and states everything that figure holds in a conferral grammar.

**Strip the figure.** What remains is: the Hebrew Bible names a terminus in a specific vocabulary, states it as given and unentered, and locates the failure in the receiver.

**That residue is substantive**, and the corpus states it in nine anchors at Appendix N, six of which carry no figure anywhere in the pericope. So the book's own central content survives its own test, which is what a reader should expect since the whole argument was constructed to identify contents that do.

**Now the harder application.** Apply the test to the *second* half of the claim, the conferral grammar. Strip the figure and nothing at all remains, because the claim is about how a figure holds what he holds and there is no figure-free version of it.

**Book VI therefore fails this book's own criterion**, and the failure is instructive rather than damaging, for the same reason Chapter 4 gave about Ezekiel 37:21. A content that fails the strip is not demoted; it is sorted. The conferral grammar is a claim about the figure material and it is figure-indexed by construction, exactly as the act-layer is act-indexed. Neither failure says anything about importance.

**What the exercise establishes.** The criterion cuts this book's own material the same way it cuts the corpus's, which is the minimum a reader should require of an instrument before trusting its verdicts. An instrument that passed everything the operator wanted to keep and cut everything he wanted to lose would be a preference wearing a procedure.

**And a second application, less comfortable.** Apply Chapter 125's finding about retention to this book. Chapter 125 argued that a corpus which preserves its own prosecution thirteen times has a habit of retention, and that a reader who extracts a single coherent position from it has added something.

This book extracts one. It reads thirteen retained pairs, declines to resolve any of them, and then states a position the corpus does not state. Appendix I records four claims that died and Chapter 165 records six limits, which is the closest this book comes to the corpus's own habit and is not the same thing.

**The honest form of that.** The corpus preserves. This book argues. Those are different activities and the second is not licensed by the first. What licenses the second is the falsifiers of Chapter 163, which are the form in which an argument can be held to account, and which the corpus, preserving rather than arguing, does not need and does not have.

:::book PART THREE | FIFTEEN APPENDICES


## Appendix A. The Rest-Field Census · Method and Full Result


**What this is.** A machine pass over an English witness to the Hebrew Bible, executed to discharge as much as possible of the debt the seed article of this project named at its own section 13 and on which it capped its terminal strength.

**What it is not.** The Hebrew concordance the debt names. Chapter 13 states why no machine-readable Hebrew text was available in the working environment, Chapter 19 states the five things that remain owed, and both statements should be read before any figure below is used.

**The witness.** The Companion Bible, the Authorised Version of 1611 with E. W. Bullinger's structures and notes, 1913, in a machine-readable text layer derived from optical character recognition of page images. Thirty-five files covering Genesis through Malachi. The text layer is uncorrected and the editor's notes are interleaved with the verse text.

**Pass one · the raw field.**

Search terms, chosen as the Authorised Version's renderings of the four roots and their inflections: rest, rested, resteth, rests, resting, quiet, quietly, quietness, quieted, cease, ceased, ceaseth, ceasing, sabbath, sabbaths, ease, eased, repose, settled.

Result: **878 candidate sites.**

| Token | n | Token | n | Token | n |
|---|---|---|---|---|---|
| rest | 399 | rested | 27 | rests | 6 |
| sabbath | 134 | settled | 21 | quieted | 5 |
| cease | 83 | resting | 13 | quietly | 3 |
| quiet | 47 | ceaseth | 11 | resteth | 3 |
| sabbaths | 46 | quietness | 10 | repose | 2 |
| ease | 34 | ceased | 32 | ceasing | 1 |
| | | | | eased | 1 |

Two books return zero: Joel and Obadiah.

**Pass two · terminal position.**

Filter: the site's window contains a governing construction of giving, entering, granting, swearing, inheriting, or possessing. Deliberately generous; the residue is hand-sorted.

Result: **114 terminal-position candidates.**

| Book | n | Book | n |
|---|---|---|---|
| Chronicles I-II | 16 | Genesis | 4 |
| The Psalms | 13 | Job | 3 |
| Isaiah | 13 | Leviticus | 2 |
| Jeremiah | 9 | Numbers | 1 |
| Ezekiel | 9 | Ruth | 1 |
| Joshua | 8 | Samuel I-II | 1 |
| Deut. | 7 | Esther | 1 |
| Ezra-Neh. | 7 | Proverbs | 1 |
| Exodus | 5 | Daniel | 1 |
| Kings I-II | 5 | Habakkuk | 1 |
| Lament. | 5 | Zephaniah | 1 |

Token distribution within the 114: rest 72, sabbath 14, ease 5, cease 5, quiet 4, rested 3, sabbaths 3, ceased 2, quietness 2, and one each of resteth, rests, ceaseth, quietly.

**Pass three · the marking test.**

Test: does any royal or eschatological token stand anywhere in a 220-character window? Tokens searched: king, kings, messiah, anointed, David, Solomon, branch, shoot, prince, son of man, shepherd, servant of the LORD, throne, sceptre, reign, kingdom, ruler, deliverer, redeemer.

Machine result: **23 marked, 91 unmarked. 20.2 percent marked.**

Hand-sort of the 23:

| Class | n | Members |
|---|---|---|
| Editor's notes, not scripture | 6 | Bullinger's apparatus, including the Psalm 101 gloss of Appendix B |
| Wrong sense of the English word | 6 | Deut 3:13 remainder; sabbath-watch rotations at 2 Kgs 11:5, 11:9, 2 Chr 23:4; sabbath-day observance at Jer 17:25, Ezek 46:1-2 |
| Genuine terminus sites, king as recipient | 11 | listed at Appendix B |

**Post-sort: 103 unmarked, 11 marked-as-recipient, 0 marked-as-agent.**

**Pass four · the subject test.**

Query, run over all thirty-five files: any clause in which a royal or eschatological noun stands as grammatical subject of a giving-verb governing rest, quiet, quietness, or repose.

Result: **two hits, both dissolve.**

1 Chronicles 22:9, where the subject of *I will give* is God and Solomon is named in the following clause. The regex caught a proximity, not a subject.

Bullinger's note on Psalm 101: *of David. Relating to the true David, and His coming rule to give "rest" to the earth.* A commentator's gloss of 1913.

**Zero verses.**

## Appendix B. The Eleven Marked Terminus Sites


The eleven sites at which a royal figure stands in the window of a genuine terminus site. Every one has been checked by hand against the text.

| Site | Clause | Subject of the giving | King's role |
|---|---|---|---|
| 2 Sam 7:1 | *wa-YHWH heniaḥ lo mi-saviv* | YHWH | David, recipient |
| 1 Chr 22:9a | *hu yihyeh ʾish menuḥah* | none (predicate) | Solomon, described |
| 1 Chr 22:9b | *wa-hanihoti lo* | God, 1cs | Solomon, recipient |
| 1 Chr 22:9c | *we-shalom wa-sheqeṭ ʾetten ʿal Yisraʾel* | God, 1cs | Israel, recipient |
| 1 Chr 22:18 | *wa-heniaḥ lakhem mi-saviv* | YHWH | the leaders, recipient |
| 1 Chr 23:25 | *heniaḥ YHWH ʾelohey Yisraʾel le-ʿammo* | YHWH | the people, recipient |
| 2 Chr 14:6 | *ki heniaḥ YHWH lo* | YHWH | Asa, recipient |
| 2 Chr 15:15 | *wa-yanaḥ YHWH lahem mi-saviv* | YHWH | the people, recipient |
| 2 Chr 20:30a | *wa-yanaḥ lo ʾelohaw mi-saviv* | his God | Jehoshaphat, recipient |
| 2 Chr 20:30b | *wa-tishqoṭ malkhut Yehoshafaṭ* | none (land/realm) | Jehoshaphat, beneficiary |
| 2 Sam 7:1 (repeat token) | as above | YHWH | as above |

**Eleven for eleven. The giver is named in the clause and it is God. The king is recipient, described, or beneficiary.**

## Appendix C. The Meshiaḥ Concordance, Sorted


Thirty-nine occurrences of the noun, sorted by referent.

**Saul, fifteen.** 1 Sam 12:3, 12:5, 24:7 (twice), 24:11, 26:9, 26:11, 26:16, 26:23; 2 Sam 1:14, 1:16, 19:22, 23:1; and the group at 1 Sam 16:6 where Samuel is mistaken about Eliab.

**David or the Davidic king.** 2 Sam 22:51; Ps 18:51, 20:7, 28:8, 84:10, 89:39, 89:52, 132:10, 132:17; Lam 4:20; Hab 3:13; 2 Chr 6:42.

**The priest, four.** Lev 4:3, 4:5, 4:16, 6:15, all as *ha-kohen ha-mashiaḥ*.

**The patriarchs, two, plural.** Ps 105:15; 1 Chr 16:22, both *meshiḥay*.

**Cyrus, one.** Isa 45:1, *li-meshiḥo*.

**Daniel, two, contested.** Dan 9:25, 9:26.

**Results.**

The largest single group is Saul, the rejected king, at fifteen.

Six occurrences fall in laments over the office's failure: Ps 89:39, 89:52, 84:10, 132:10, Lam 4:20, Hab 3:13.

No occurrence in a determinable context designates a coming eschatological deliverer. Daniel 9 is contested and the royal psalms have been read that way; in every case where the referent is fixed by context it is a historical person.

All thirty-nine are passive participles. There is no cognate active noun in the corpus.

## Appendix D. The Conferral Grammar · Fifteen Sites


| Site | Clause | Form |
|---|---|---|
| Deut 17:15 | *ʾasher yivḥar YHWH ʾeloheykha bo* | God as subject of choosing |
| 1 Sam 8:22 | *we-himlakhta lahem melekh* | Samuel commanded to make |
| 2 Sam 7:8 | *ʾani leqaḥtikha min ha-nawah* | 1cs divine, king as object |
| 2 Sam 7:11 | *ki vayit yaʿaseh lekha YHWH* | God builds for him |
| 2 Sam 7:14 | *ʾani ʾehyeh lo le-ʾav* | relation constituted by declaration |
| Ps 2:6 | *wa-ʾani nasakhti malki* | 1cs divine |
| Ps 2:7 | *ʾani ha-yom yelidtikha* | 1cs divine, dated |
| Ps 2:8 | *sheʾal mimmenni we-ʾettenah* | conditional on petition |
| Ps 45:8 | *meshaḥakha ʾelohim ʾeloheykha* | God as subject of anointing |
| Ps 110:1 | *shev li-mini ʿad ʾashit* | imperative from giver, 1cs |
| Ps 110:4 | *nishbaʿ YHWH … ʾattah khohen* | oath, God as subject |
| 1 Chr 28:5 | *wa-yivḥar bi-Shelomoh veni* | God as subject of choosing |
| 1 Chr 29:23 | *wa-yeshev ʿal kisseʾ YHWH* | seat belongs to another |
| 2 Chr 9:8 | *le-titkha ʿal kisʾo … la-YHWH* | set on his throne, for him |
| Ezek 34:23 | *wa-haqimoti ʿaleyhem roʿeh ʾeḥad* | 1cs divine causative |
| Dan 7:14 | *we-leh yehiv sholṭan* | Aramaic peʿil, passive |

Sixteen rows for fifteen sites, since Psalm 110 supplies two. Six books, two languages, one grammar.

## Appendix E. The Thirteen Retained Pairs


| # | Barred or prosecuted | Seated or restored |
|---|---|---|
| 1 | Deut 23:4-7, Moabite and Ammonite barred to the tenth generation | Ruth 4:18-22, line sealed through Ruth *ha-Moʾaviyyah*; 1 Kgs 14:21, Naamah *ha-ʿAmmonit* |
| 2 | Jer 22:24-30, signet plucked from Coniah, *ʿariri* | Hag 2:23, signet restored to Zerubbabel, grandson at 1 Chr 3:17 |
| 3 | Isa 49:3, servant named Israel | Isa 49:6, servant distinguished from the tribes, four verses later |
| 4 | Jer 7:22; 1 Sam 15:22; Hos 6:6; Isa 1:11 | Ezek 40-48, offerings restored, prince's six lambs at 46:4 |
| 5 | Judg 8:23; 1 Sam 8:7, kingship refused and named a rejection | 1 Chr 29:23, king seated on the throne of the LORD |
| 6 | 1 Sam 8:11-18, itemized prosecution | Ps 45:7, throne addressed as *ʾelohim* |
| 7 | Num 25:12-13; Ezek 44:15, perpetual Aaronide priesthood | Ps 110:4, perpetual non-Aaronide, pre-Israelite order |
| 8 | Deut 7:1-3; Exod 34:15-16, *loʾ titḥatten bam* | The ancestry seated through those nations in seven instances, Appendix F |
| 9 | Job 14:8, the stump dies in the dust | Isa 11:1, the shoot comes from the stump |
| 10 | Ps 23:1, the king says *YHWH roʿi*; 2 Sam 5:2 sets him over *ʿammi* | Ezek 34:24, *ʿavdi Dawid nasiʾ* while God remains *le-ʾelohim*, flock *ṣoʾni* throughout |
| 11 | 2 Sam 7:15, withdrawal barred unconditionally | Ps 132:12, *ʾim yishmeru vaneykha beriti*, conditional |
| 12 | 1 Sam 8:18, outcry will go unanswered | Ps 72:12, the king delivers the needy *meshawweaʿ*, when he cries |
| 13 | 2 Kgs 10:30, Jehu approved for the bloodshed | Hos 1:4, that blood visited on his house |

Pair 9 is the most contestable and Chapter 88 states the objection.

## Appendix F. The Ancestry Through the Bar · Seven Instances


**Inside the Davidic line, as Ruth 4:18-22 enumerates it.**

| Figure | Foreign connection | Sites |
|---|---|---|
| Judah | *bat ʾish Kenaʿani*, Shua's daughter; her sons not the line; the line routes through Tamar, origin unsupplied | Gen 38:2; Ruth 4:18 |
| Boaz | Ruth *ha-Moʾaviyyah*, designated five times | Ruth 1:22, 2:2, 2:21, 4:5, 4:10 |
| David | the household of *ʾUriyyah ha-Ḥitti*, designated nine times | 2 Sam 11:3-24; 12:9-10; 23:39; 1 Kgs 15:5 |
| Solomon | successor's mother *Naʿamah ha-ʿAmmonit* | 1 Kgs 14:21, 14:31 |

**Outside the Davidic line.**

| Figure | Foreign connection | Sites |
|---|---|---|
| Ishmael | Hagar *ha-Miṣrit* | Gen 16:1, 16:3, 21:9, 25:12 |
| Joseph's sons | Asenath *bat Poṭi-Feraʿ khohen ʾOn* | Gen 41:45, 46:20 |
| Moses | Zipporah, daughter of the priest of Midian; *ha-ʾishah ha-Kushit*, with the objectors rebuked and the marriage not | Exod 2:21; Num 12:1-15 |

**And the prohibition is quoted at the breach**, 1 Kings 11:2.

## Appendix G. The Eight Stages


| # | Stage | Locus | Conferral form |
|---|---|---|---|
| 1 | Refusal | Judg 8:23 | *YHWH yimshol bakhem* |
| 2 | Concession | 1 Sam 8:22 | *we-himlakhta lahem melekh* |
| 3 | Permanence, withdrawal barred | 2 Sam 7:12-16, 7:15 | four divine establishing verbs |
| 4 | Cosmic vocabulary | Ps 2:7; 45:8; 110:1 | I begot, God anointed you, sit at my right hand |
| 5 | Throne-name | Isa 9:5-6 | two passives; *qinʾat YHWH ṣevaʾot taʿaseh zoʾt* |
| 6 | Regrowth after felling | Isa 11:1-2, from a *gezaʿ* | *we-naḥah ʿalaw ruaḥ YHWH* |
| 7 | Split into two | Zech 4:14; 6:13 | *hinneni meviʾ ʾet ʿavdi Ṣemaḥ* |
| 8 | Celestial conferral | Dan 7:13-14 | *yehiv*, Aramaic passive |

Stages 1 to 3 stand in narrative sequence in the corpus. Stages 4 to 8 are ordered by content. **No compositional dating is claimed.**

## Appendix H. The Deficit Inventory · Eleven Passages


| Site | Organs named | Form of the statement |
|---|---|---|
| Deut 29:3 | heart, eyes, ears | not given, *ʿad ha-yom ha-zeh* |
| Isa 6:9-10 | heart, ears, eyes | make fat, make heavy, shut |
| Isa 42:19-20 | eyes, ears | blind servant, deaf messenger, ears open and not hearing |
| Jer 5:21 | heart, eyes, ears | organs possessed, functions absent |
| Ezek 12:2 | eyes, ears | organs possessed, functions absent |
| Isa 43:8 | eyes, ears | blind people that have eyes |
| Isa 29:10 | eyes | spirit of deep sleep poured out |
| Ps 95:7-11 | heart | hardened; did not know my ways; did not enter |
| Jer 6:16 | none named | a refusal spoken and quoted |
| Deut 8:12-14 | heart, memory | satisfied, heart lifted, forgot |
| Ps 115:5-8 / 135:15-18 | eyes, ears, mouth, nose, hands, feet | applied to idols; those who trust become like them |

**The reversal, stated in the passive.** Isa 35:5, *tippaqaḥnah* and *tippataḥnah*, both nifal. Isa 29:18, the eyes of the blind shall see.

**And the direct remedies, with no figure in any of them.** Deut 30:6, circumcise the heart. Jer 31:33-34, write on the heart, and they shall all know me. Ezek 36:26-27, a new heart and a new spirit. Joel 3:1, the spirit poured on all flesh.

## Appendix I. Errata and Withdrawn Claims


Recorded rather than removed, because a study that reports only its surviving positions reports half a method.

**Killed by the corpus.**

*The partial-removability claim.* An earlier version held that the messianic frame was only partly removable because the restoration material could not be stated without the act-layer. **Ezekiel 37:14 falsified it**: the corpus states the terminus in the settling-root at the end of the act-sequence. Chapter 28.

*An asymmetry claimed against a comparative case* that rested on the above and fell with it.

**Withdrawn readings.**

*Zechariah 6:13 as fusing two offices in one person.* Withdrawn against *beyn shenehem*, between them both. A counsel between a man and himself is not a counsel. Chapter 80.

*A misuse of the Tyre oracle of Ezekiel 28* in an earlier draft, withdrawn.

**Corrections made during this book's own preparation.**

*A scope claim about the source corpus.* Books II and III of a companion study were described as Hebrew-Bible-alone on the strength of a citation count whose instrument had no pattern for Second Temple sources and therefore scored Enochic and Qumran chapters as clean. Measured properly they carry 70 and 66 such references. The error was in the instrument, and the correction is the reason this book was built fresh rather than cut from that one. Chapter 13's insistence on stating what an instrument cannot do is downstream of it.

*The census's own overstatement risk.* Chapter 18 reports 11 marked-as-recipient sites clustering in two related books and states the skeptic's reply in the same chapter rather than leaving it to a reader.

## Appendix J. The Boundary · Where Another Corpus Begins


**Fenced. Nothing in this appendix is load-bearing for any claim in this book, and no chapter cites it.**

The scope law of Chapter 1 admits the Hebrew Bible alone. This appendix names what is on the other side of that line and where the line falls, so that a reader who wants to cross it knows at which sentence the crossing happens and that this book does not make it.

**The Second Temple material.** The Enochic corpus, principally the Book of Parables, develops a pre-existent figure seated on a throne of glory and called the Son of Man, and does so in a way that engages Daniel 7 directly. Jubilees rewrites Genesis and Exodus with a calendar. The Qumran library carries two anointed figures, one priestly and one royal, a heavenly Melchizedek executing judgment in a final jubilee, and a body of interpretation of the very passages Books VIII and XII of this study read. Ben Sira praises the fathers. 4 Ezra and 2 Baruch respond to the destruction of 70.

**The rabbinic material.** The Mishnah, the two Talmuds, and the midrashic collections supply the treasury of unborn souls, the sabbath of history, the messiah at the gates of Rome, the two messiahs of Joseph and David, and a vast interpretive apparatus on every passage this book uses.

**The New Testament.** An occupancy claim and an extended argument for it, and the earliest sustained reading of the Hebrew royal material by a community that held it to be fulfilled.

**The Qurʾān.** A redescription of the whole prophetic line, a seal, and a distinct account of the figure the Gospels claim.

**Where the line falls.** At the last verse of Malachi in the Masoretic arrangement, and at the last citation in Book XIX. Every claim in Chapters 1 through 166 is checkable inside that boundary. Every corpus named above lies outside it and is engaged nowhere.

**Why the fence is stated rather than left implicit.** Because a study that excludes material without saying what it excludes invites the assumption that nothing was excluded, and the excluded material here is not marginal. It contains, arguably, the most developed messianic thought in the history of the traditions that carry this corpus. Its absence is a methodological choice with a stated cost.

## Appendix K. Glossary of Hebrew and Aramaic Terms


**ʾaṭad** · bramble, the thorny scrub of Jotham's fable, Judg 9:14.
**baʾ ʾel** · to come to, the verb of arrival at Deut 12:9 and Ps 95:11.
**benei ha-yiṣhar** · sons of the oil, Zech 4:14, a hapax expression.
**deror** · liberty, proclaimed at the jubilee, Lev 25:10.
**gezaʿ** · stump, the cut base of a tree. Three occurrences: Job 14:8, Isa 11:1, Isa 40:24.
**ḥoṭer** · shoot, Isa 11:1.
**kisseʾ YHWH** · throne of the LORD, 1 Chr 29:23; with *malkhut*, 1 Chr 28:5.
**lev** · heart, in this corpus the seat of thought and intention rather than of emotion.
**maṣṣevet** · standing part or stump of a felled tree, Isa 6:13.
**mashiaḥ** · anointed, passive participle of *mšḥ*. Thirty-nine occurrences, Appendix C.
**menuḥah** · resting-place, settled condition, nominal of *nwḥ*.
**margoaʿ** · repose, nominal of *rgʿ*, Jer 6:16.
**mšl** · to rule, the verb Gideon declines at Judg 8:23 and the root of *u-mosholo* at Zech 9:10.
**nagid** · prince, designate, leader. Used of Saul at 1 Sam 10:1 and of David at 2 Sam 5:2 and 7:8.
**nasiʾ** · prince, Ezekiel's preferred term for the figure, from *nśʾ*, to lift.
**naḥalah** · inheritance, paired with *menuḥah* at Deut 12:9. From *nḥl*, a different root.
**neṣer** · branch, Isa 11:1.
**nwḥ** · to settle, alight and stay. The promise's own root.
**qeren / pakh** · horn and flask, the two vessels of the anointing rite.
**rgʿ** · to have relief, repose at the end of a walk.
**ṣemaḥ** · branch, sprout. The title at Jer 23:5, 33:15, Zech 3:8, 6:12.
**šbt** · to cease. The root at Gen 2:2 and of the sabbath.
**shoresh** · root, the part Job 14:8 says persists.
**šqṭ** · to be quiet, undisturbed. The Judges refrain's root, with the land as subject.
**yehiv** · Aramaic peʿil, was given. Dan 7:14.

## Appendix L. Transliteration, Citation, and Conventions


**Transliteration.** Broad and academic. *š* for shin, *ṣ* for tsade, *ḥ* for het, *ṭ* for tet, *ʾ* for aleph, *ʿ* for ayin. Vowel length is not marked. Where a form appears in the running text with a different but recognizable spelling, the two refer to the same word.

**Text.** BHS, which is to say the Leningrad Codex with its apparatus. Where a reading is contested the contest is named at the point of use.

**Versification.** Hebrew numbering throughout. Where the English differs, the English number is given at first occurrence within that book. The principal instance is Isaiah 9:5, English 9:6. Excursus I sets out the general problem.

**Citation of books.** Full names in the running text. Standard abbreviations in tables.

**Honorifics.** Prophetic names carry the traditional honorific throughout: Musa AS, Ibrahim AS, and so on where they appear. This is a convention of the author's and is not an interpretive claim about the corpus.

**Chapter cross-references** are to this book's chapters, numbered continuously 1 through 166 across the nineteen books.

**What is quoted.** Hebrew is given in transliteration with a translation, and the translation is the author's unless otherwise indicated. Where a translation is contested, the contest is stated and the argument is built to hold under the alternatives.

## Appendix M. The Twenty-Four Books, and What Each Carries


A reader's index to where the four bodies of material in this study actually sit. **T** marks terminus vocabulary in a terminal position, **D** the deficit inventory, **F** royal-figure material, and **C** a conferral-grammar site tabulated at Appendix D. A hollow mark means a single passage rather than a body.

| Book | T | D | F | C |
|---|:--:|:--:|:--:|:--:|
| Genesis | ● | | ○ | |
| Exodus | ● | | | |
| Leviticus | ● | | | |
| Numbers | | | ○ | |
| Deut. | ● | ● | ○ | ● |
| Joshua | ● | | | |
| Judges | ● | | ● | |
| Samuel | ● | ● | ● | ● |
| Kings | ● | | ● | ● |
| Isaiah | ● | ● | ● | ● |
| Jeremiah | | ● | ● | ● |
| Ezekiel | ● | ● | ● | ● |
| The Twelve | ● | ● | ● | ● |
| Psalms | ● | ● | ● | ● |
| Proverbs | | ○ | | |
| Job | | ○ | | |
| Song | | | | |
| Ruth | | | ○ | |
| Lament. | | | ● | |
| Eccles. | | | | |
| Esther | | | | |
| Daniel | | ● | ● | ● |
| Ezra-Neh. | | ● | | |
| Chronicles | ● | | ● | ● |

**The principal sites, book by book**, in the order of the table. *Genesis* 2:2, the seventh position; 8:4, the ark settles; 14:18-22, Melchizedek; 38, Tamar; 49:10, contested. *Exodus* 18:13-24, Jethro; 20:8-11, remember; 25:8, a sanctuary; 29:7, Aaron anointed. *Leviticus* 4:3, the anointed priest; 8:12; 25, the three scales; 26:34-35, the land's sabbaths. *Numbers* 12:1-15, the Cushite woman; 24:17, Balaam's star; 25:12-13, the Aaronide grant. *Deuteronomy* 8:12-14; 10:12-13; 12:9-10; 17:14-20; 29:3; 30:6, 30:11-14, 30:19. *Joshua* 10:1, Adoni-Ṣedeq; 11:23; 21:44-45; 22:4; 23:1. *Judges* 3:11, 3:30, 5:31, 8:28, the quiet refrain; 8:23, the refusal; 9, the fable. *Samuel* 7:8-16; 8:5-22, the concession; 10:1 and 16:13, the anointings; 12, the farewell. *Kings* 8:12-56, the dedication; 11:1-13, the apostasy; 19:15-16, three anointings; 2 Kings 9, Jehu. *Isaiah* 2:4; 6:9-13; 9:5-6; 11:1-9; 40:11; 42:1-9 and 42:19; 45:1; 49:1-6; 50:4-9; 52:13-53:12; 66:1-2. *Jeremiah* 5:21; 6:16; 8:8; 22:24-30; 23:1-6; 31:31-34; 33:15-18. *Ezekiel* 12:2; 17 and 31, the trees; 34 entire; 36:24-28; 37:1-28; 40-48, the prince. *The Twelve* Hosea 1:4, 8:4, 13:11; Amos 5:18-24, 9:11; Micah 5:1-4, 6:8; Habakkuk 2:14, 2:19; Zephaniah 3:15; Haggai 2:9, 2:23; Zechariah 3, 4, 6, 9:9; Malachi 3:1, 3:23-24. *Psalms* 2; 8; 23; 45; 72; 89; 93-99; 95; 110; 115:5-8; 132. *Proverbs* 2:2-5; 4:20-23; 16:12; 20:12; 27:2; 29:14. *Job* 14:7-9, the tree; 42:5, hearing to seeing. *Ruth* 4:18-22, the genealogy. *Lamentations* 2:9; 4:20; 5:20-22. *Ecclesiastes* 2:4-11; 12:13. *Daniel* 2:34 and 2:44; 7:9-27; 9:4-19, the confession; 9:25-26, contested. *Ezra-Nehemiah* Ezra 1:1-4; 3:10-13; Nehemiah 9, five statements of the hearing failure. *Chronicles* 1 Chronicles 22:9-18; 23:25; 28:2-5; 29:11-23; 2 Chronicles 9:8; 14:6; 15:15; 20:30; 26:16; 32:25; 36:21-23. *Song of Songs* and *Esther* carry nothing used here.

**Five observations from the table.**

The terminus vocabulary is distributed across the Torah, the Former Prophets, Isaiah, Ezekiel, the Twelve, the Psalter, and Chronicles. It is not a Deuteronomistic peculiarity.

The deficit inventory appears in Deuteronomy, Samuel, Isaiah, Jeremiah, Ezekiel, the Psalter, Daniel, and Ezra-Nehemiah, and in Proverbs and Job in its positive form. It is the most widely distributed of the four.

Royal-figure material concentrates in Isaiah, Jeremiah, Ezekiel, four of the Twelve, the Psalter, and Chronicles, and is absent from five of the Twelve and from all four wisdom books.

Conferral-grammar sites appear in nine of the twenty-four.

And two books carry none of the four: Song of Songs and Esther.

## Appendix N. The Nine Terminus Anchors


Chapter 159 listed the terminus among six substantive contents and gave it nine anchors, more than any other. They are set out here with the operative clause in each, so that the strip can be checked verse by verse.

| Site | Clause | Figure in the pericope? |
|---|---|:--:|
| Deut 12:9 | *loʾ vaʾtem ʿad ʿattah ʾel ha-menuḥah* | no |
| Josh 21:44 | *wa-yanaḥ YHWH lahem mi-saviv* | no |
| 1 Kgs 8:56 | *natan menuḥah le-ʿammo Yisraʾel* | speaker is a king; recipient is the people; no figure in the clause |
| 1 Chr 22:9 | *hu yihyeh ʾish menuḥah … wa-hanihoti lo* | yes; the king is the recipient and God the giver |
| Ezek 37:14 | *we-hinnaḥti ʾetkhem ʿal ʾadmatkhem* | no; the figure enters the chapter at 37:22, a separate oracle |
| Ps 95:11 | *ʾim yevoʾun ʾel menuḥati* | no |
| Isa 11:9 | *maleʾah ha-ʾareṣ deʿah ʾet YHWH* | yes in the pericope, no in the clause; Chapter 29 works the *ki* |
| Isa 2:4 | *loʾ yilmedu ʿod milḥamah* | no |
| Hab 2:14 | *ki timmaleʾ ha-ʾareṣ la-daʿat ʾet kevod YHWH* | no |

**Six of the nine carry no figure anywhere in the pericope.** One has a king as recipient with the giver named. One has a king as speaker and the people as recipient. And one has a figure in the pericope and none in the clause, with the scope of the conjunction contested and stated as contested.

**Habakkuk 2:14 is the cleanest anchor in the set** and Chapter 29 says why: it states the knowledge-filling in almost the words of Isaiah 11:9, in a different book, in an oracle about the fall of a plunderer, with no figure anywhere in the vicinity. Under the criterion the content is substantive on the strength of that verse alone.

## Appendix O. A Reader's Route


The book is long and not every reader wants all of it. Four routes.

**The argument in eight chapters.** Chapter 2, the criterion. Chapter 22, the terminus named. Chapter 26, Psalm 95. Chapter 32, the deficit. Chapter 46, the itemized bill. Chapter 62, the conferral grammar. Chapter 82, the category substitution. Chapter 166, the conclusion.

**The evidence in five.** Chapter 17, the census's subject test. Chapter 41, nowhere a withheld terminus. Chapter 62, fifteen conferral sites. Chapter 100, the flock nobody gathers. Chapter 161, the purpose clauses.

**The objections, for a reader who wants to break it.** Chapter 6, the three falsifiers stated in advance. Chapter 39, the hardening problem this book declines to solve. Chapter 88, the most contestable pair. Chapter 139, the counterexample at Isaiah 42:7. Chapter 143, the largest omission. Chapter 163, the falsifiers returned. Chapter 165, the limits. Appendix I, the claims that died.

**And for a reader who wants only the method**, Book I entire, eight chapters, and Chapter 19 for what the census could not do.

**One route this book does not offer.** There is no summary that carries the argument without the verses. The claim is about what a corpus says and the only form in which it can be checked is the form in which the verses are quoted. A reader who wants the conclusion without the evidence is welcome to Chapter 166, and should treat it as an assertion rather than as a finding.

## Bibliography


Sorted by function rather than alphabetically, because a reader needs to know which sources carry weight and which do not, and an alphabetical list conceals exactly that. Four of the nine sections below name things this study did not use, could not obtain, or holds at arm's length, and they are here because a bibliography is also where a reader looks for what a work did not read.

## I · THE PRIMARY CORPUS

**The Hebrew Bible.** Masoretic text, BHS, cited by the Hebrew chapter and verse divisions. This is the study's only seal-eligible register and the only body of writing from which any load-bearing claim is drawn.

**Thirty-three of the thirty-nine books are cited by chapter and verse.** In order of citation density: Isaiah 198, Psalms 160, Deuteronomy 129, Jeremiah 100, Ezekiel 79, 1 Samuel 72, 2 Samuel 61, Genesis 56, 1 Chronicles 56, 1 Kings 46, Exodus 40, 2 Chronicles 38, Leviticus 30, Joshua 26, Zechariah 25, Judges 23, Job 20, Hosea 20, 2 Kings 18, Daniel 17, Habakkuk 17, Numbers 15, Micah 13, Amos 11, Ruth 10, Lamentations 8, Haggai 7, Proverbs 6, Joel 6, Malachi 6, Ezra 5, Zephaniah 5, Nahum 2. **One thousand three hundred and twenty-five citations.**

**Six books are named but carry no verse citation, and the reasons differ.** Nehemiah is discussed at Chapter 148 for its ninth chapter, whose five statements of the hearing failure are quoted by verse without the book name repeated. Ecclesiastes and Song of Songs are surveyed at Chapter 133 for the absence of royal-figure material, which is what they contribute. Esther appears only in the census distribution table and in Appendix M. Obadiah is read at Chapter 116 for its closing verse and is one of the two books returning zero in the rest-field census. Jonah is not discussed anywhere, and that is the one book of the canon this study neither read nor accounted for.

**The Aramaic portions are inside the corpus and are load-bearing once.** Daniel 7:14's *yehiv* at Chapter 81, whose voice the whole of Book VIII's closing argument turns on.

**The principal loci.** Genesis 2:2-3; 8:4; 14:18-22; 28:18; 38; 49:10. Exodus 18:13-24; 20:8-11; 25:8-9; 29:7; 31:2-5; 40:9-15. Leviticus 4:3; 8:10-12; 25:1-55; 26:12, 26:34-35. Numbers 9:15-23; 12:1-15; 24:17-19; 25:12-13. Deuteronomy 8:12-18; 10:12-13; 12:9-11; 17:14-20; 18:15-22; 29:3; 30:1-20; 32:15. Joshua 10:1; 11:23; 21:44-45; 22:4; 23:1. Judges 3:11, 3:30, 5:31, 8:22-28; 9:7-20. 1 Samuel 8:5-22; 10:1; 12:1-25; 15:22-28; 16:6-13; 24:7; 26:9. 2 Samuel 2:4; 5:2-3; 6:6-9; 7:1-29; 12:7-9; 24:24. 1 Kings 1:39; 3:5-14; 8:12-56; 11:1-13; 19:15-16. 2 Kings 9:1-10; 10:30-31; 11:12; 25:27-30. 1 Chronicles 22:8-18; 23:25; 28:2-5; 29:11-23. 2 Chronicles 3:1; 9:8; 13:8; 14:6; 15:15; 20:30; 26:16; 32:25-26; 36:21-23. Job 14:7-9; 42:5. Psalms 2; 8:5-7; 16:9; 23; 45:7-8; 72; 89; 93-99; 95:7-11; 101; 105:15; 110; 115:5-8; 132; 135:15-18; 144:3-4; 147:2. Proverbs 16:12; 20:12; 27:2; 29:14. Isaiah 2:2-4; 6:1-13; 7:14; 9:5-6; 11:1-10; 14:7; 29:10, 29:18; 35:5; 40:11, 40:24, 40:28; 41:8-9; 42:1-9, 42:18-20; 43:8, 43:10; 44:1-2, 44:21, 44:28; 45:1-6; 48:20; 49:1-6; 50:4-11; 52:13-53:12; 54:7-10; 56:8, 56:11; 61:1; 66:1-2. Jeremiah 2:27; 3:15; 5:21; 6:16; 7:22-23; 8:8; 9:22-23; 10:21; 22:24-30; 23:1-6; 25:11; 29:10-14; 30:10; 31:31-34; 33:14-18. Lamentations 2:9; 3:21-24; 4:20; 5:20-22. Ezekiel 8-11; 12:2; 17:1-24; 22:26; 29:21; 31:1-12; 34:1-31; 36:24-28; 37:1-28; 40-48. Daniel 2:34, 2:44; 7:9-27; 9:4-19, 9:25-26. Hosea 1:4; 6:6; 8:4; 13:6, 13:11; 14:2. Joel 2:11; 3:1. Amos 5:18-24; 8:4; 9:11. Micah 2:12; 3:11-12; 5:1-4; 6:8; 7:14. Nahum 3:18. Habakkuk 2:4, 2:14, 2:19-20; 3:13. Zephaniah 1:14-18; 3:14-17. Haggai 2:3-9, 2:23. Zechariah 1:4; 3:8-9; 4:2-14; 6:11-13; 8:8; 9:9-10; 10:2-3; 11:4-17; 13:7. Malachi 2:7-8; 3:1-2, 3:23-24.

## II · THE ENGLISH WITNESS, USED AS AN INSTRUMENT AND NOT AS A SOURCE

**[1]** Bullinger, E. W., editor. *The Companion Bible: The Authorised Version of 1611 with the Structures and Notes, Critical, Explanatory and Suggestive, and with 198 Appendixes.* London: Oxford University Press, 1909-1922.

Used at Book II as the machine-readable English witness over which the rest-field census was executed. Text layer derived from optical character recognition of page images and uncorrected; Appendix A carries the provenance and Chapter 19 the five things the witness cannot support.

**It is unusual to cite a 1913 commentary as a research instrument rather than as a source of readings**, and the reason is stated at Chapter 13: no machine-readable Hebrew text of the Masoretic canon was obtainable in the working environment, and this was the only complete machine-readable witness to the corpus that was. Its interpretive content is used nowhere in this study except at Chapter 17, where its note on Psalm 101 is quoted as the census's most instructive single result.

## III · SCHOLARLY POSITIONS ENGAGED

Named as positions. This study states its relation to each and argues with none by name. Chapter 162 carries the full statement.

**[2]** von Rad, Gerhard. "There Remains Still a Rest for the People of God: An Investigation of a Biblical Conception." In *The Problem of the Hexateuch and Other Essays*, translated by E. W. Trueman Dicken. Edinburgh and London: Oliver and Boyd, 1966; New York: McGraw-Hill, 1966. Translated from *Gesammelte Studien zum Alten Testament*. Munich: Kaiser Verlag, 1958. Reprinted in *From Genesis to Chronicles: Explorations in Old Testament Theology*, edited by K. C. Hanson. Minneapolis: Fortress Press, 2005.

*Menuḥah* as land-gift, with an unresolved already-and-not-yet between Joshua and Psalm 95. **This study is downstream of it.** The seam is not claimed as new. What is added is the removability criterion of Chapter 2, the executed census of Book II, and the resulting sort of the royal material as means.

**[3]** Mowinckel, Sigmund. *He That Cometh: The Messiah Concept in the Old Testament and Later Judaism.* Translated by G. W. Anderson. Oxford: Basil Blackwell; New York: Abingdon Press, 1956. Norwegian original *Han som kommer*, 1951. Reprinted with a foreword by John J. Collins. Grand Rapids: Eerdmans, 2005.

Messianism as a comparatively late development not present in the pre-exilic royal texts. **Compatible.** The escalation sequence of Book VIII redescribes the same material by content and commits to no dating beyond the corpus's own narrative order for its first three stages.

**[4]** Noth, Martin. *The Deuteronomistic History.* Translated and introduced by David J. A. Clines and Philip R. Davies. JSOT Supplement Series 15. Sheffield: JSOT Press, 1981. Translation of *Überlieferungsgeschichtliche Studien*, pages 1-110 of the second edition. Tübingen: Max Niemeyer, 1957; first published 1943.

The Joshua-to-Kings material as a single editorial project. **Used, not adjudicated.** This study does not enter the hypothesis and does use the fact that it is available and widely held as a reason to treat that material as one witness where it would otherwise be treating four.

**Three further bodies of literature are engaged and named without individual citation**, because the claims made are about their general shape rather than about any one contributor.

**The source-critical treatment of 1 Samuel 8 through 12**, and the classical division into pro-monarchic and anti-monarchic strands. **No position taken**, per Chapter 52; the final form's retention of both is the datum, and without this literature Chapter 52 would have nothing to say.

**The literature on the sabbath as institution and sign. Adjacent.** This study's interest is in *menuḥah* as the promise's terminus rather than in observance, and it connects the two only through the root-field of Book II. A reader whose subject is the sabbath will find one paragraph at Chapter 37 that they could have written better.

**The literature on the hardening motif at Isaiah 6:9-10. Used differently.** Chapter 33 takes 6:9-10 with Deuteronomy 29:3, Isaiah 42:19, and Jeremiah 6:16 as a converging diagnosis of reception rather than as a problem about divine intent, and Chapter 39 states at length why this study declines to solve the problem the literature exists to solve.

**A submission version would carry each of the three at full apparatus.**

## IV · THE SOURCE STUDY

Prior work by the same hand, on which this study's spine rests. It was itself built scripture-internally and is superseded by nothing here.

**[5]** *A Shoot from a Felled Stump: The Conceded Throne. Menuḥah as Terminus, the Monarchy as Concession, and the Roots of the Jewish Messiah in the Hebrew Bible.*

The article states four things this book expands: the four rest-roots and the terminus named in the second of them; the concession engine in the corpus's own sequence; the location of the failure at the receiver; and the removability criterion with its two calibration cases. It states one debt and caps its own terminal strength on it, and Book II here is the discharge of as much of that debt as the available instruments allowed. Its title is this book's title, and Chapter 7 states why the seam it works is not claimed as new.

## V · THE INSTRUMENT DEPENDENCY, DECLARED

Itemised rather than left as a general admission, because Chapter 165's account of this study's limits would be incomplete without it.

**Concordances, lexica, and grammars** for Biblical Hebrew and Aramaic were used throughout and are indispensable to every philological claim in this book. Every root identification, every stem parsing, every statement about a word's distribution, and every count in Appendix K rests on them.

**Critical editions and apparatus** for the Hebrew text, and the standard treatments of the versional evidence named at Excursus XIII.

**These are products of exactly the scholarly traditions Chapter 1's constraint holds at arm's length, and there is no version of this study that does without them.**

The constraint was never a claim that those traditions produced nothing reliable. It is a claim about what may **settle** a question, and the instruments do not settle questions; they make the text legible so that the text can. That distinction is what makes the dependency consistent with the rule rather than an exception to it, and a reader who finds the distinction too convenient has this study's own statement, at Chapter 19 and at Chapter 165, that the debt is partially paid and partially outstanding.

## VI · WHAT WAS NOT AVAILABLE

Recorded because a method chapter that names a limit without naming its cause is asking to be taken on trust.

**No machine-readable Hebrew text of the Masoretic canon** was obtainable in the working environment where Book II's census was executed. Every attempt to obtain one is recorded and every attempt failed: no such corpus was present locally, and no package registry reachable from that environment carried one.

**This is a fact about the working conditions and not about the world.** A reader with Accordance, Logos, BibleWorks, a Even-Shoshan concordance, or any of several open Hebrew corpora can run the Hebrew-side census in an afternoon and should. Chapter 19 states the five things it would settle.

## VII · WHAT IS ABSENT, BY NAME

Declared here as well as at Appendix J, because a bibliography is where a reader looks for what a work read.

**No Second Temple or pseudepigraphal material.** No Enochic corpus, no Jubilees, no 4 Ezra or 2 Baruch, no Ben Sira, no Wisdom of Solomon.

**No Qumran material.** No Community Rule, no Damascus Document, no 11QMelchizedek, no 4Q521, no sigla of any kind.

**No rabbinic corpus.** No Mishnah, no Talmud, no midrashic collection, no Targum.

**No Josephus and no Philo.**

**No New Testament.**

**No Qurʾān.**

**No patristic, conciliar, medieval Jewish, or Shiʿi material.**

None of the above is cited anywhere in Chapters 1 through 166, and a verification gate enforces the exclusion against the finished text. Appendix J names the boundary and says what stands on the other side of it; Chapter 1 states the cost.

## VIII · WHAT WAS NOT SEARCHED

Distinct from what is absent, and more uncomfortable, because these are gaps inside the corpus this study did read.

**The wisdom books were surveyed for the absence of royal-figure material and not for the presence of terminus vocabulary.** Proverbs in particular carries a substantial body of material on the heart, the ear, and knowledge that a fuller treatment would work; Chapter 134 quotes three verses and there are more.

**The Song of Songs was not read** beyond confirming that it contains no royal-figure material, and Jonah was not read at all.

**The census's complementary field was not run**: the count of where a royal figure appears without the terminus vocabulary, which would say whether the two vocabularies avoid each other or merely fail to coincide. Chapter 19 names it as the single most useful further study this method suggests.

**The northern kingdom's royal theology** is examined only through what a Judahite corpus preserves of it, which is a formula of condemnation and one failed conditional promise. Excursus IX states the gap.

## IX · A NOTE ON THE SHORTNESS OF THIS LIST

Five numbered entries is a small apparatus for a book of this length, and the smallness is a consequence of the method rather than of the reading.

A study constrained to one corpus, arguing from that corpus's own grammar, and testing its claims against falsifiers executable inside that corpus, has few places where a citation could do load-bearing work. Where a scholarly position bears on the argument it is named as a position and this study's relation to it is stated; where an instrument was used it is declared at section V; and where a claim rests on the corpus it rests on a verse a reader can check.

**Every entry above was checked against the published record before this list was finalised**, and one was checked only after it was first drafted from recall: the translator, place, and publisher of entry [2] were supplied from memory in a first draft, then confirmed, and the German source named on that volume's own title page was added at the same time. The check is what the entry now rests on, and the order in which it happened is stated because a list that certifies itself should say when the certifying was done.

## Author Disclosure


**Affiliation and funding.** The author is an independent researcher with no institutional affiliation and holds a doctorate in an unrelated field. No funding was received for this work and there are no competing financial or professional interests.

**Method.** The analysis was developed through extended interaction with an AI system used as a philological and adversarial-audit instrument. The author set the direction, supplied the primary sources, made the corrections that moved the argument, and bears full responsibility for every claim. The assistant performed concordance assembly, drafting, structural auditing, and the census of Book II. This disclosure is offered because the working method is unusual and a reader is entitled to know it, not because the argument rests on it; every claim is stated so that a reader with a Hebrew Bible and a concordance can check it without reference to how it was produced.

**Audit history.** Two findings that earlier drafts treated as central were killed by the corpus and are recorded as dead rather than removed, at Appendix I. Two errata are likewise carried on the record there.

**Standing.** The author writes from outside the guild and from a position of religious commitment, and states this plainly rather than implying a neutrality he does not have. The method is designed to make that irrelevant: the single-corpus constraint of Chapter 1, the stated criterion of Chapter 2, the executed census of Book II with its stated debt at Chapter 19, and the falsification criteria of Chapter 163 are there so that the argument can be checked by a reader who shares none of the author's commitments and rejected by one who shares all of them.

End of manuscript.
