#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Assemble the manuscript and generate the contents from the headers themselves,
so the contents can never drift from the body."""
import re, pathlib

body = pathlib.Path("_body.md").read_text(encoding="utf-8")
p2   = pathlib.Path("PART_TWO.renum.md").read_text(encoding="utf-8")
p3   = pathlib.Path("PART_THREE.renum.md").read_text(encoding="utf-8")
front= pathlib.Path("FRONT.md").read_text(encoding="utf-8")

def head(t, pat):
    return re.findall(pat, t, re.M)

n_ex = len(head(p2, r"^## EXCURSUS "))
n_ap = len(head(p3, r"^## APPENDIX "))
WORD = {14:"FOURTEEN",15:"FIFTEEN",19:"NINETEEN",21:"TWENTY-ONE",12:"TWELVE"}
p2 = re.sub(r"^# PART TWO · .*$", f"# PART TWO · {WORD[n_ex]} EXCURSUS", p2, count=1, flags=re.M)
p3 = re.sub(r"^# PART THREE · .*$", f"# PART THREE · {WORD[n_ap]} APPENDICES", p3, count=1, flags=re.M)

rows = ["# CONTENTS\n"]
for ln in body.split("\n"):
    m = re.match(r"^# BOOK ([IVX]+) · (.+)$", ln)
    if m: rows.append(f"\n**BOOK {m.group(1)} · {m.group(2)}**\n"); continue
    m = re.match(r"^## CHAPTER (\d+) · (.+)$", ln)
    if m: rows.append(f"{m.group(1)}. {m.group(2)}")
rows.append(f"\n**PART TWO · {WORD[n_ex]} EXCURSUS**\n")
for ln in p2.split("\n"):
    m = re.match(r"^## (EXCURSUS [IVX]+) · (.+)$", ln)
    if m: rows.append(f"{m.group(1)}. {m.group(2)}")
rows.append(f"\n**PART THREE · {WORD[n_ap]} APPENDICES**\n")
for ln in p3.split("\n"):
    m = re.match(r"^## (APPENDIX [A-Z]) · (.+)$", ln)
    if m: rows.append(f"{m.group(1)}. {m.group(2)}")
    m = re.match(r"^# (BIBLIOGRAPHY|AUTHOR DISCLOSURE)$", ln)
    if m: rows.append(f"\n**{m.group(1)}**")

full = (front.rstrip() + "\n\n" + "\n".join(rows) + "\n\n---\n\n"
        + body.rstrip() + "\n\n" + p2.rstrip() + "\n\n" + p3.rstrip() + "\n")
out = pathlib.Path("The Conceded Throne.md")
out.write_text(full, encoding="utf-8")
print(f"{out}: {len(full.split()):,} words, {len(full):,} bytes")
print(f"books {len(head(body, r'^# BOOK '))}, chapters {len(head(body, r'^## CHAPTER '))}, "
      f"excursus {n_ex}, appendices {n_ap}")
