#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reorder the books so THE RESULT stands last, and renumber every chapter
header and every cross-reference under one map. A renumbering that fixes the
headers and leaves the cross-references pointing at the old numbers is worse
than no renumbering, so both are done from one table."""
import re, pathlib

ORDER = [
    ("BOOK_I.md",    "I",     "THE INSTRUMENT"),
    ("BOOK_II.md",   "II",    "THE FOUR ROOTS"),
    ("BOOK_III.md",  "III",   "THE TERMINUS"),
    ("BOOK_IV.md",   "IV",    "THE DEFICIT"),
    ("BOOK_V.md",    "V",     "THE CONCESSION"),
    ("BOOK_VI.md",   "VI",    "THE SEAT"),
    ("BOOK_VII.md",  "VII",   "THE OCCUPANTS"),
    ("BOOK_VIII.md", "VIII",  "THE ESCALATION"),
    ("BOOK_IX.md",   "IX",    "THE TREE"),
    ("BOOK_X.md",    "X",     "THE SHEPHERD AND THE FLOCK"),
    ("BOOK_XI.md",   "XI",    "THE PSALTER READ FOR ITS VERBS"),
    ("BOOK_XII.md",  "XII",   "THE PROPHETS AND THE FIGURE"),
    ("BOOK_XIII.md", "XIII",  "WHAT THE CORPUS PRESERVES"),
    ("BOOK_XVa.md",  "XIV",   "THE TORAH'S OWN FIGURES"),
    ("BOOK_XVb.md",  "XV",    "THE SILENCES"),
    ("BOOK_XVII.md", "XVI",   "THE SERVANT"),
    ("BOOK_XVIII.md","XVII",  "THE EXILE AND THE RETURN"),
    ("BOOK_XIX.md",  "XVIII", "THE DWELLING"),
    ("BOOK_XIV.md",  "XIX",   "THE RESULT"),
]

# pass one: read every file, collect the old chapter numbers in the new order
seq = []
texts = {}
for fn, _, _ in ORDER:
    t = pathlib.Path(fn).read_text(encoding="utf-8")
    texts[fn] = t
    seq += [int(m) for m in re.findall(r"^## CHAPTER (\d+) · ", t, re.M)]

MAP = {old: new for new, old in enumerate(seq, start=1)}
moved = {k: v for k, v in MAP.items() if k != v}
print(f"{len(seq)} chapters; {len(moved)} renumbered")
print("map of the moved ranges:")
runs, cur = [], None
for old in sorted(moved):
    new = moved[old]
    if cur and old == cur[1] + 1 and new == cur[3] + 1:
        cur[1], cur[3] = old, new
    else:
        cur = [old, old, new, new]; runs.append(cur)
for a, b, c, d in runs:
    print(f"   {a}-{b}  ->  {c}-{d}")

def renum(t):
    # chapter headers
    t = re.sub(r"^## CHAPTER (\d+) · ",
               lambda m: f"## CHAPTER {MAP[int(m.group(1))]} · ", t, flags=re.M)
    # cross-references, singular and plural, including "Chapters 102 and 103"
    def one(m):
        n = int(m.group(2))
        return m.group(1) + str(MAP.get(n, n))
    t = re.sub(r"(Chapters?\s+)(\d{1,3})\b", one, t)
    t = re.sub(r"(Chapters?\s+\d{1,3}(?:,\s*\d{1,3})*\s+and\s+)(\d{1,3})\b", one, t)
    t = re.sub(r"(Chapters?\s+\d{1,3}\s+(?:to|through)\s+)(\d{1,3})\b", one, t)
    return t

out = []
for fn, num, title in ORDER:
    t = renum(texts[fn])
    t = re.sub(r"^# BOOK [IVX]+ · .*$", f"# BOOK {num} · {title}", t, count=1, flags=re.M)
    out.append(t.rstrip() + "\n")

pathlib.Path("_body.md").write_text("\n".join(out), encoding="utf-8")

# the two Parts also carry cross-references
for fn in ("PART_TWO.md", "PART_THREE.md"):
    p = pathlib.Path(fn)
    p.with_suffix(".renum.md").write_text(renum(p.read_text(encoding="utf-8")), encoding="utf-8")

print("wrote _body.md, PART_TWO.renum.md, PART_THREE.renum.md")
