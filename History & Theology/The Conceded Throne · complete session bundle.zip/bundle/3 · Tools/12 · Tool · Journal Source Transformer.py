#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Transform THE CONCEDED THRONE into Journal-edition source.

Master structure:
    # THE CONCEDED THRONE          -> front-matter title (dropped from body)
    ### subtitle / #### deck       -> dropped
    ## A NOTE ON WHAT THIS BOOK IS -> section
    ## READING CONVENTIONS         -> section
    # CONTENTS                     -> :::contents
    # BOOK I · THE INSTRUMENT      -> :::book I | THE INSTRUMENT
    # PART TWO · ...               -> :::book PART TWO | ...
    ## CHAPTER n · TITLE           -> ## n. Title
    ## EXCURSUS I · TITLE          -> ## Excursus I. Title
    ## APPENDIX A · TITLE          -> ## Appendix A. Title
    # BIBLIOGRAPHY / # AUTHOR ...  -> ## Bibliography / ## Author Disclosure
No body text is altered. Only structural markers are rewritten.
"""
import re, pathlib

SRC = pathlib.Path("hb/The Conceded Throne.md")
OUT = pathlib.Path("build_hb/source.md")
OUT.parent.mkdir(exist_ok=True)
lines = SRC.read_text(encoding="utf-8").split("\n")

FRONT = """---
edition: journal
title: The Conceded Throne
subtitle: The Unentered Rest, the Requested King, and the Escalation That Answered the Wrong Question
author_line: Mohammad F. Islam, PhD^1^
journal: Tractatus Historicus
article_type: History of Religion
goal: The rest was given. It was not entered.
doi: Hebrew Bible Series
short_title: The Conceded Throne
date: 2026
accent: forest
---

:::affiliations
^1^Independent Researcher. Correspondence: islamm@alumni.iu.edu
:::

:::abstract
This study reads the royal and future-royal material of the Hebrew Bible as the history of a position rather than the biography of a person, and it reads nothing else: every load-bearing claim rests on the Hebrew Bible alone, and a verification gate enforces the constraint against the finished text. The argument runs from a single observation. The corpus names the terminus of its promise in a root whose sense is settlement rather than recuperation, states that terminus as given at Joshua 21:44 and announced already given at 1 Kings 8:56, records it delivered four further times in Judges under four ordinary deliverers, and records at Psalm 95:11 that it was not entered. It locates the failure of entry in the same three organs at every stage and in every part of the canon, in identical language, and nowhere in a gift withheld. It then grants a visible monarchy against an itemized prosecution and a clause excluding the standard remedy, and when its kings fail it re-issues the concession at higher intensity eight times without ever withdrawing it and without ever returning to the terminus it had already named. A second finding runs beneath the first and is the study's principal result. However large the figure becomes, the grammar by which he receives what he holds never changes: the verb is passive or the subject is God, at 2 Samuel 7:8, Psalm 2:7, Psalm 45:8, Psalm 110:1, Isaiah 9:5, 1 Chronicles 29:23, Ezekiel 34:23 and Daniel 7:14 alike, across six books and two languages, and the central title is itself a passive participle. An executed census over the whole corpus, reported with its instrument's limits stated in the same place, returns zero clauses in which a royal figure is the grammatical subject of giving rest, and eleven in which a king receives it with the giver named. Three falsification criteria are stated before the evidence and returned with their results; two claims that earlier drafts treated as central were killed by the corpus and are carried as dead rather than removed. The argument runs to a boundary, describes what stands on this side of it, and names no man.
:::

:::keywords
menuhah; conferral grammar; Hebrew Bible; Deuteronomistic History; 1 Samuel 8; royal ideology; Isaiah 6:9-10; hardening; messianic expectation; single-corpus method
:::

"""

out, i, n, in_contents = [], 0, len(lines), False
while i < n:
    ln = lines[i]
    if ln.startswith("# THE CONCEDED THRONE") or ln.startswith("### The Unentered Rest") \
       or ln.startswith("#### A Study in the Hebrew Bible Alone"):
        i += 1; continue
    if ln.strip() == "---":
        i += 1; continue
    if ln.startswith("# CONTENTS"):
        in_contents = True; out.append(":::contents"); i += 1; continue
    if in_contents:
        if ln.startswith("# BOOK I ·"):
            out.append(":::"); out.append(""); in_contents = False; continue
        m = re.match(r"^(\d+)\.\s+(.*?)\s*$", ln)
        if m: out.append(". %s | %s" % (m.group(1), m.group(2))); i += 1; continue
        m = re.match(r"^(EXCURSUS) ([IVX]+)\.\s+(.*?)\s*$", ln)
        if m: out.append(". Excursus %s | %s" % (m.group(2), m.group(3))); i += 1; continue
        m = re.match(r"^(APPENDIX) ([A-Z])\.\s+(.*?)\s*$", ln)
        if m: out.append(". Appendix %s | %s" % (m.group(2), m.group(3))); i += 1; continue
        m = re.match(r"^\*\*(BOOK .*?|PART .*?|BIBLIOGRAPHY|AUTHOR DISCLOSURE)\*\*\s*$", ln)
        if m: out.append("$ %s" % m.group(1)); i += 1; continue
        i += 1; continue
    m = re.match(r"^# BOOK ([IVX]+) · (.+?)\s*$", ln)
    if m: out += [":::book %s | %s" % (m.group(1), m.group(2)), ""]; i += 1; continue
    m = re.match(r"^# (PART \w+) · (.+?)\s*$", ln)
    if m: out += [":::book %s | %s" % (m.group(1), m.group(2)), ""]; i += 1; continue
    m = re.match(r"^# (BIBLIOGRAPHY|AUTHOR DISCLOSURE)\s*$", ln)
    if m: out += ["## %s" % m.group(1).title(), ""]; i += 1; continue
    m = re.match(r"^## CHAPTER (\d+) · (.+?)\s*$", ln)
    if m: out += ["## %s. %s" % (m.group(1), m.group(2)), ""]; i += 1; continue
    m = re.match(r"^## EXCURSUS ([IVX]+) · (.+?)\s*$", ln)
    if m: out += ["## Excursus %s. %s" % (m.group(1), m.group(2)), ""]; i += 1; continue
    m = re.match(r"^## APPENDIX ([A-Z]) · (.+?)\s*$", ln)
    if m: out += ["## Appendix %s. %s" % (m.group(1), m.group(2)), ""]; i += 1; continue
    out.append(ln); i += 1

body = re.sub(r"\n{4,}", "\n\n\n", "\n".join(out)).rstrip() + "\n\nEnd of manuscript.\n"
OUT.write_text(FRONT + body, encoding="utf-8")
print("wrote", OUT, len(body.split()), "body words")
print("chapter heads:", len(re.findall(r"^## \d+\. ", body, re.M)),
      " book dividers:", len(re.findall(r"^:::book ", body, re.M)),
      " contents rows:", len(re.findall(r"^\. ", body, re.M)))
