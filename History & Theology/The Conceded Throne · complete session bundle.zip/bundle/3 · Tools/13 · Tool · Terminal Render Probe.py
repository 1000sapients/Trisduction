#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Module XII terminal verification.

WeasyPrint truncates long documents silently and returns success: a valid PDF
of the surviving pages, no warning. So the render is verified by its END.
Three checks: a terminal sentinel string, a page count against the source's
own scale, and every terminal section present by name.
"""
import re, subprocess, sys, pathlib

PDF = "The Conceded Throne.pdf"
txt = subprocess.run(["pdftotext", "-layout", PDF, "-"],
                     capture_output=True, text=True).stdout
src = pathlib.Path("source.md").read_text(encoding="utf-8")

fails = []
def ok(name, cond, note=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + (("   " + note) if note else ""))
    if not cond: fails.append(name)

pages = int(subprocess.run(["pdfinfo", PDF], capture_output=True, text=True)
            .stdout.split("Pages:")[1].split()[0])

print("TERMINAL SENTINEL")
low = txt.lower()
ok("sentinel 'end of manuscript' present", "end of manuscript" in low)
ok("sentinel is in the last 1% of the text",
   low.rindex("end of manuscript") > len(low) * 0.99 if "end of manuscript" in low else False)

print("\nEVERY TERMINAL SECTION PRESENT BY NAME")
for name in ["Conclusion", "The Rest Was Given", "Appendix O", "A Reader's Route",
             "Bibliography", "Author Disclosure", "Excursus XXI"]:
    ok(f"terminal section: {name}", name.lower() in low)
ok("last excursus present", "criterion applied to this" in low.replace("\n"," "))
ok("last appendix present", "reader's route" in low)

print("\nCHAPTER COVERAGE")
# A regex on the chapter NUMBER is the wrong instrument: in a two-column layout
# the number lands mid-line, and a character class tuned to Latin capitals misses
# heads that open on "Sbt", "Salom", or "1 Kings". Check the TITLES instead, which
# is what a missing chapter would actually take with it.
flat = " ".join(txt.split())
titles = dict(re.findall(r"^## (\d+)\. (.+)$", src, re.M))
absent = []
for n, title in titles.items():
    key = " ".join(title.split("\u00b7")[0].split())[:40]
    if key not in flat:
        absent.append((n, key))
ok(f"all {len(titles)} chapter titles reached", not absent, str(absent[:4]))
for n in ("1", "42", "84", "120", "166"):
    key = " ".join(titles[n].split("\u00b7")[0].split())[:40]
    ok(f"chapter {n} present", key in flat)

print("\nSCALE")
ok("page count plausible for 100k words", pages >= 110, f"{pages} pages")

print("\nRENDER HEALTH")
ok("no unrendered directive markers", ":::" not in txt)
ok("no raw markdown emphasis leaked", "**" not in txt)
ok("contents leader dots resolved", txt.count(".....") > 50 or "CONTENTS" in txt.upper())

print()
if fails:
    print(f"{len(fails)} CHECK(S) FAILED: " + "; ".join(fails)); sys.exit(1)
print(f"RENDER VERIFIED AT ITS END. {pages} pages.")
