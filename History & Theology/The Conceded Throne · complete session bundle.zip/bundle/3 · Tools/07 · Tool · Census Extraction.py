#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""English-side rest-field extraction over the Companion Bible (KJV) text layer.

Honest statement of what this is: a machine pass over an ENGLISH witness whose
text layer is uncorrected OCR. It is not the Hebrew concordance the article owes.
It exhaustively isolates CANDIDATE sites in a checkable way; root identification
and terminal-position classification are done by hand afterward and are marked
as such. Every count printed here is a count of English tokens, never of Hebrew
roots.
"""
import re, os, csv

CB = "kb/Bible/Companion Bible"
OUT = "hb/census/field_raw.tsv"

FIELD = re.compile(
    r"\b(rest|rested|resteth|rests|resting|quiet|quietly|quietness|quieted|"
    r"cease|ceased|ceaseth|ceasing|sabbath|sabbaths|ease|eased|repose|settled)\b",
    re.I)
VERSE = re.compile(r"(?:^|[\s.;:*°?!’\"\)\]])(\d{1,3})\s+(?=[A-Z“‘À-ÿ])")

files = sorted(f for f in os.listdir(CB) if re.match(r"^(0[1-9]|[12]\d|3[0-5]) ", f))
rows = []
for f in files:
    book = re.sub(r"^\d+\s+", "", f[:-3])
    t = open(os.path.join(CB, f), encoding="utf-8").read()
    for m in FIELD.finditer(t):
        a = max(0, m.start() - 260)
        back = t[a:m.start()]
        vs = VERSE.findall(back)
        v = vs[-1] if vs else ""
        ctx = re.sub(r"\s+", " ", t[max(0, m.start()-110): m.end()+110]).strip()
        rows.append((book, v, m.group(0).lower(), ctx))

with open(OUT, "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh, delimiter="\t")
    w.writerow(["book", "verse_hint", "token", "context"])
    w.writerows(rows)

from collections import Counter
c = Counter(r[2] for r in rows)
print(f"{len(rows)} candidate sites across {len(files)} books -> {OUT}")
print("token distribution:")
for k, n in c.most_common():
    print(f"   {n:>4}  {k}")
