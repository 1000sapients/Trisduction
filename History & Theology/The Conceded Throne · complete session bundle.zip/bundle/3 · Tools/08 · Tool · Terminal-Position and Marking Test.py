#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Second pass: isolate TERMINAL-POSITION candidates from the raw field.

A terminal-position site is one where the rest-word is the object of a giving,
an entering, a granting, a swearing, an inheriting, or a possessing, i.e. where
rest is the thing promised or arrived at rather than an ordinary pause. The
filter is deliberately generous; the residue is hand-sorted.

Then: for each terminal candidate, test whether a royal or eschatological AGENT
stands in the clause. That is the article's F1 question.
"""
import csv, re
from collections import Counter

GOVERN = re.compile(
    r"\b(gave|give|given|giveth|giving|enter|entered|entering|shall enter|"
    r"inherit|inheritance|possess|possessed|swar[en]|sworn|promise[sd]?|"
    r"caused? to rest|set(?:tle)?d? (?:you|them|him|us)|"
    r"unto the rest|to the rest|into (?:my|his|the) rest|my rest|his rest)\b", re.I)

AGENT = re.compile(
    r"\b(king|kings|messiah|messias|anointed|david|davids|solomon|branch|"
    r"shoot|prince|son of man|shepherd|servant of the lord|throne|sceptre|"
    r"reign|reigned|kingdom|ruler|deliverer|redeemer)\b", re.I)

rows = list(csv.DictReader(open("hb/census/field_raw.tsv", encoding="utf-8"), delimiter="\t"))
term = [r for r in rows if GOVERN.search(r["context"])]

print(f"raw field sites          : {len(rows)}")
print(f"terminal-position candid.: {len(term)}")

with_agent = [r for r in term if AGENT.search(r["context"])]
print(f"  of which carry a royal/eschatological token in the same window: {len(with_agent)}")
print(f"  of which carry none                                          : {len(term)-len(with_agent)}")
pct = 100.0 * len(with_agent) / len(term) if term else 0
print(f"  marked-to-unmarked, English window, 220 chars: {pct:.1f}% marked")
print()
print("book distribution of terminal candidates:")
for b, n in Counter(r["book"] for r in term).most_common():
    print(f"   {n:>3}  {b}")

with open("hb/census/terminal.tsv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh, delimiter="\t")
    w.writerow(["book", "verse_hint", "token", "agent_token_present", "context"])
    for r in term:
        a = AGENT.search(r["context"])
        w.writerow([r["book"], r["verse_hint"], r["token"], a.group(0).lower() if a else "", r["context"]])
print("\nwrote hb/census/terminal.tsv")
