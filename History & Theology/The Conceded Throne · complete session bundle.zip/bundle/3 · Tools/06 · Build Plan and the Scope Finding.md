# THE CONCEDED THRONE · build plan
Hebrew Bible alone. Fresh corpus. Nothing existing is deleted or reused wholesale.

## The scope finding that forced a fresh build
Measured across the History manuscript:

    BOOK I     20,560 w    Second-Temple / rabbinic refs:   6
    BOOK II    14,682 w    Second-Temple / rabbinic refs:  70
    BOOK III   17,543 w    Second-Temple / rabbinic refs:  66

Books II and III are Enoch, Qumran, and the Testaments. They are not the Hebrew
Bible. The earlier "Books I-III at 99% Hebrew" figure was an instrument artifact:
the regex counted Genesis/Matthew/Q citations and had no pattern for 1 Enoch,
4Q521, or 11QMelch, so it scored a Second Temple chapter as clean.

Consequence: the only genuinely Hebrew-Bible-alone material in hand is
Book I (20,560 w) plus the seed article (6,345 w). About 27,000 words.
A 110,000-word volume is therefore ~83,000 words of new writing, not a cut.

## Scope law, printed on the face of the book
Every load-bearing claim rests on the Hebrew Bible. Second Temple, rabbinic,
Christian and Qur'anic material is admitted nowhere in the argument. One fenced
appendix names the boundary and says where another corpus begins. A verification
gate fails the build on any such citation inside the body.

## The debt this volume pays
The seed article states at 13 that its terminal strength is capped by one
unexecuted census: the nwh / menuhah / sqt concordance across the whole corpus,
terminal-position sites isolated, marked-to-unmarked ratio printed. Book II
executes it. That is the single largest honest expansion available, and it
converts a capped claim into a measured one.

## Architecture · 11 books · 109 chapters · target 110,000-120,000 w

BOOK I    · THE INSTRUMENT              ch 1-8      method, criterion, scope
BOOK II   · THE FOUR ROOTS              ch 9-20     the rest-field, census executed
BOOK III  · THE TERMINUS                ch 21-31    the state itself
BOOK IV   · THE DEFICIT                 ch 32-41    the receiver
BOOK V    · THE CONCESSION              ch 42-52    the monarchy granted
BOOK VI   · THE SEAT                    ch 53-63    conferral grammar
BOOK VII  · THE OCCUPANTS               ch 64-74    every anointed figure
BOOK VIII · THE ESCALATION              ch 75-84    eight stages
BOOK IX   · THE TREE                    ch 85-93    stump, root, shoot
BOOK X    · WHAT THE CORPUS PRESERVES   ch 94-101   the retained prosecution
BOOK XI   · THE RESULT                  ch 102-109  removability, falsification, close

PART TWO   · TEN EXCURSUS
PART THREE · TEN APPENDICES  (census tables, meshiah concordance, ten pairs,
             semah field, the fenced boundary, glossary, transliteration)
BIBLIOGRAPHY

Per-chapter budget 900-1,300 w. Books 8,000-13,000 w each.
