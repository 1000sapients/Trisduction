# THE REST-FIELD CENSUS · executed result
Instrument: machine pass over the Companion Bible (A.V. 1611) text layer, 35 files
covering Genesis through Malachi. The text layer is uncorrected OCR and the witness
is English. This is NOT the Hebrew concordance the article owes. It narrows the
debt. It does not discharge it. Every figure below is a count of English tokens.

## Pass 1 · the raw field
878 candidate sites. Token distribution:
    rest 399 · sabbath 134 · cease 83 · quiet 47 · sabbaths 46 · ease 34
    ceased 32 · rested 27 · settled 21 · resting 13 · ceaseth 11 · quietness 10
    rests 6 · quieted 5 · quietly 3 · resteth 3 · repose 2 · ceasing 1 · eased 1

## Pass 2 · terminal position
114 of 878 sites place the rest-word as the object of a giving, entering,
swearing, inheriting, or possessing. Book distribution: Chronicles 16, Psalms 13,
Isaiah 13, Jeremiah 9, Ezekiel 9, Joshua 8, Deuteronomy 7, Ezra-Nehemiah 7,
Exodus 5, Kings 5, Lamentations 5, Genesis 4, Job 3, Leviticus 2, and one each in
Numbers, Ruth, Samuel, Esther, Proverbs, Daniel, Habakkuk, Zephaniah.

## Pass 3 · the F1 question, agent-marking
23 of the 114 carry a royal or eschatological token anywhere in the 220-character
window. Hand-sorted, those 23 resolve as:

    6   Bullinger's own notes, not the biblical text
    6   the wrong sense of the English word: "the rest of Gilead" is a remainder,
        and the sabbath-watch rotations of 2 Kgs 11, 2 Chr 23, Jer 17, Ezek 46
        are the day and not the terminus
    11  genuine terminus sites in which a king stands in the window AS RECIPIENT,
        with God named as the giver in the same clause:
        2 Sam 7:1 · 1 Chr 22:9 (x3) · 1 Chr 22:18 · 1 Chr 23:25
        2 Chr 14:6 · 2 Chr 15:15 · 2 Chr 20:30 (x2)

## Pass 4 · the subject test, run over the whole corpus
Query: any clause in which a royal or eschatological noun stands as subject of a
giving-verb governing rest, quiet, quietness, or repose.
    Result: 2 hits, both dissolve on inspection.
    1 Chr 22:9  the subject of "I will give" is God; Solomon is the recipient
                named in the following clause
    Ps 101      Bullinger's 1913 gloss, "Relating to the true David, and His
                coming rule to give rest to the earth" - a commentator's note,
                not a verse

## The executed result
ZERO clauses in the Hebrew Bible, on this English witness, in which a royal or
eschatological figure is the grammatical subject of giving rest. The single
apparent instance is supplied by a commentator, and its presence in the census is
itself the finding: the figure-indexed reading has to be added because the text
does not carry it.

Where a king appears at a terminus site at all, he appears eleven times out of
eleven as the one who receives it, and the giver is named in the same clause.

## Residual debt, stated
The Hebrew-side census is still owed. This pass cannot distinguish sbt from nwh
from sqt from rg, because the A.V. renders all four with "rest" and renders nwh
also as "quiet" and sqt also as "rest". A Hebrew concordance would sharpen every
figure above and could move some. The direction of the result is unlikely to
reverse, since the subject test is a grammatical question the English preserves,
but the article's cap is narrowed rather than lifted.
