---
edition: math_journal
title: "The Riemann Hypothesis in Toto at the Apex: A Formal Proof from the Root Axiom of Everything but the Sign"
subtitle: "The Seat as the Identity Cone over the Fixed Locus, the Spine's Stage Embedded Equivariantly into the Quaternion Carrier, the Aperture Opened by the Root's Interaction Face, and the Exact Strength of “Accept the Root Axiom, then the Riemann Hypothesis” Proved and Bounded in Lean 4: a Trisductive Apex Edition of the Locus and the Crossing"
article_type: "FORMAL VERIFICATION · FOUNDATIONS OF MATHEMATICS · APEX EDITION"
goal: "Riemann's fixed-line statement carried from the Root Axiom to its seat; the sign left at the witness row, by theorem"
author_line: "Mohammad F. Islam, PhD$^{1}$"
affiliation: "$^{1}$ Independent Researcher, USA. Correspondence: islamm@alumni.iu.edu"
date: "23 September 2026"
short_title: "The Riemann Hypothesis in Toto at the Apex"
keywords: "Riemann Hypothesis; Root Axiom; RAF; RAM; category gap; identity cone; fixed locus; equivariant embedding; orientation blindness; one bit; aperture; Lean 4; Trisduction"
accenthex: B87333
version: 1.0.0
abstract: |
  Riemann's hypothesis in its restored form, $Z \subset \mathrm{Fix}(\tau)$ with $\tau(s) = 1 - \bar{s}$, has a completed formal proof of its locus and its crossing in which the value on the roots of $\xi$ is the one open input, supplied at the witness row and recorded as a term of the hypothesis itself. That proof takes the presence of a supplier from outside its file, as a flag, and it leaves three separations standing between the root at which a supplier acts, the formal ground on which the locus is fixed, and the Riemann object read as the fixed locus of its binding involution. We supply the root. The Root Axiom, $\forall x \in U,\ \Delta E(x) > 0$, is constructed in core Lean 4 as the only supplied witness, read along its two formal faces, the interaction face RAF and the grounding face RAM, and the following are proved. The fixed locus of the binding involution on the quaternion carrier is the scalar line for every quaternion; the spine's lattice stage embeds into that carrier by an equivariant map $\varphi$ with $\sigma\varphi = \varphi\tau$ carrying $\mathrm{Fix}(\tau)$ onto $\mathrm{Fix}(\sigma)$; the three separations are the three legs of an identity cone over the register diagram, each leg \texttt{rfl}, its apex unique; a reader that registers a bit against the record is a member of the interaction domain, never an exterior witness, and no system indexes all of its own binary properties. The hypothesis is thereby proven in toto at the apex, meaning every clause of it that is not its value on the zeros. The value is one bit, and the rule “accept the Root Axiom, then the Riemann Hypothesis” has an exact strength: $(\mathrm{RA} \to L(X)) \leftrightarrow L(X)$ in every context in which the axiom holds, and the axiom decides $L$ on no frame, since the two-point frame carries the axiom and fails $L$. The primary falsifiable criterion is the spine's: one zero of $\xi$ off the line refutes every supplied assent on the world row and touches nothing at the apex. The axiom supplies the act; the act, and not the axiom, carries the sign.
---

# Background and Rationale

Riemann stated his hypothesis as a fixed-set statement: the roots of $\xi(t)$ are real \cite{riemann1859}. The spine paper of this edition \cite{islamspine} restored that statement to $Z \subset \mathrm{Fix}(\tau)$ with $\tau(s) = 1 - \bar{s}$, vindicated the restoration against the literature, and proved in core Lean 4 the structural arc of the restored hypothesis on an abstract frame $X = (S, \tau, Z)$: the locus, the odd offset, the orientation blindness of every even reading, the earned one-bit freedom, the bridge, and the crossing. It also proved what the arc is not. Every structural clause holds on a frame whose zeros lie off the line (spine Theorem 11); the only input that closes the crossing on the frame of $\xi$ is a term of $L(X_\xi)$ itself (spine Theorem 12); no theorem whose hypotheses are only structural decides $L$ (spine Theorem 14). The value, $\forall \rho \in Z_\xi,\ \tau\rho = \rho$, was recorded as the one open input, supplied at the witness row and never derived.

Two things in that record are external to its file, and this paper brings them inside. First, the live face of the spine takes its witnessed flag from the command line: that a supplier is present is asserted from outside, and the kernel is told rather than shown that a reader stands at the aperture. Second, three separations are left standing, between the root at which a reader acts, the formal ground on which the locus was fixed, and the Riemann object read as the fixed locus of its binding involution. These are separations of category, produced by describing one seat in three registers. They are not gaps in the mathematics, and the spine could not close them because a root is not a structural clause and the spine had none.

The Root Axiom is that root. Formally it is a universe $U$ with a differential $\Delta E : U \to \mathbb{Z}$ and the axiom $\forall x \in U,\ \Delta E(x) > 0$; the codex sentence for it is that to exist is to actuate \cite{islamcodex, islamraf}. It is read along two formal faces, siblings under one root and neither derived from the other. The interaction face, RAF, says what it is for systems to be related: an interaction domain is closed under registration, and no agent acts on a domain from outside it. The grounding face, RAM, says what it is for a proposition to be determinate: its formal being is its imprint in the fixed locus of the binding involution, read across the aperture, with $\mathrm{Fix}(\sigma) = \mathbb{R}$ as the seat \cite{islamraf}. The interaction face reaches no mathematical object, since mathematical objects do not change state; every proposition routes to the grounding face. That reach law is the root's own, and this paper proves its Riemann instance rather than assuming it.

This paper constructs the axiom in core Lean as the only supplied witness and proves the following about it in relation to the hypothesis. The seat: the binding involution on the quaternion carrier fixes exactly the scalar line, the Return of the parse triad lands on it, and the kinetic seat, the formal seat, and the named critical seat are the three legs of an identity cone over the register diagram, each leg \texttt{rfl}, the apex unique (Theorems A, B, C). The embedding: the spine's lattice stage embeds equivariantly into the carrier, $\sigma\varphi = \varphi\tau$, and $\varphi$ carries the line onto the scalar line (Theorem C$'$). The aperture: for a present reader who supplies a bit the row is never interior; it is sealed or refused by the bit alone, and a reader who registers a bit is inside the interaction domain, never an exterior witness (Theorem D). The exact strength of the rule: in every context in which the axiom holds, $(\mathrm{RA} \to L(X)) \leftrightarrow L(X)$, and the axiom decides $L$ on no frame, the two-point frame carrying the axiom and failing $L$ (Theorems E, F).

The title names the register and the residue. At the root a closure can carry no mass: a massive closure between the root and its formal face would be a second root conditional, which the root-premise law forbids. The eliminator that closes the category gaps is therefore massless by necessity and not by weakness, and this paper computes the masslessness rather than asserting it: the three legs of the cone are definitional identities. “In toto at the apex” has one definition and it is used in no other sense: every clause of the hypothesis that is not its value on the zeros. “The sign” names one object throughout: the value $\forall \rho \in Z_\xi,\ \tau\rho = \rho$, the orientation of assent on the world row, the one bit the spine records at the witness row. “Everything but the sign” is the same set named by its complement. What the kernel returns, given the axiom, is exactly that set, and the sign is proven to be exactly what the axiom does not reach.

# Literature Review

Only the positions that bear on the apex are reviewed; the analytic literature of the restored formulation is reviewed in the spine \cite{islamspine}.

**The original statement and its chart.** Riemann \cite{riemann1859}, Siegel \cite{siegel1932}, and Edwards \cite{edwards1974} give the fixed-line statement and its history; Titchmarsh \cite{titchmarsh1986}, Bombieri \cite{bombieri2000}, and Conrey \cite{conrey2003} state the canonical chart form, real part one half. The spine's Proposition V1 makes the address a chart and the fixed line intrinsic. This paper takes the fixed line one register deeper: the fixed line of a binding involution is the seat on every carrier that has one, and the two carriers in play, the lattice stage under $\tau$ and the quaternions under $\sigma$, are joined by an explicit equivariant map.

**Symmetry without the Euler product.** Davenport and Heilbronn \cite{davenport1936} and Bombieri and Hejhal \cite{bombieri1995} exhibit series with the functional equation and zeros off the line. In the spine these are the off-line frames on which every structural clause holds. In this paper they carry one thing more: the Root Axiom holds on them too (Theorem F). That is the whole reason the axiom cannot decide the value.

**The Euler product as key.** Selberg \cite{selberg1992} and Conrey and Ghosh \cite{conrey1993} name the Euler product as the organizing axiom of the class for which the hypothesis is conjectured; Weil \cite{weil1948} and Deligne \cite{deligne1974} prove the analogue where the Euler product runs over a finite geometry. This paper leaves the key where the spine left it, on the world row, and shows that the apex closes without it.

**The spectral road.** Berry and Keating \cite{berry1999} and Connes \cite{connes1999} seek an operator whose spectrum is the zero set. An operator is a world-row construction; the seat on which its spectrum would have to lie is fixed before any operator is built, and that ordering, orientation after construction, is the discipline's own law \cite{islamrows}.

**The root's formal faces.** The declaration of the formal Root Axiom and the five objects \cite{islamraf} states RAF-1 and RAF-2, the bridge to Landauer, and the consequences C1 to C3, and states RAM as the imprint law with $\mathrm{Fix}(\sigma) = \mathbb{R}$. Its engine, the formal-alone cascade on RAF, records the constraint this paper obeys: RAF reaches no mathematical object and routes every proposition to the grounding face \cite{islamfae}. Cantor's theorem and Lawvere's fixed-point theorem \cite{lawvere1969} carry C2 unconditionally.

**Category-theoretic frame.** Cones, apexes, and limits over a diagram are used here in their elementary form, a discrete diagram on three objects in the groupoid of definitional equalities \cite{maclane1998}. The frame is chosen because a category gap is, in that setting, exactly a missing leg, and its elimination is exactly an identity leg.

**The price of the act.** Landauer \cite{landauer1961} bounds the dissipation of registering one bit; Bérut and coauthors \cite{berut2012} measure it. The spine prices the spent bit at $k_B T \ln 2$; here the price is the bridge BR-L of the interaction face and it exports without constituting.

**The barrier taxonomy.** The twenty-three-row study \cite{islamrows} types every proved method-class barrier as an evenness statement and every open row as missing exactly one orientation bit at its decision seat. Here the seat is shown to be one seat under every name, and the Riemann row's owed bit is placed against it.

**The gap.** No work in this literature states the root of the supplier, so the presence of a supplier remains a flag; and none treats the three separations between root, formal ground, and object as what they are, separations of category rather than of mathematics. Both are supplied here.

# Methodology

Every theorem of this paper is checked by core Lean 4, version 4.19.0, no library, no axiom declared, no \texttt{sorry}, every axiom dependency set printed by the kernel and reproduced in Appendix C. The file, `RH_At_The_Apex.lean`, is printed whole in Appendix B with its SHA-256 digest, and it is self-contained: the spine's Theorems 1, 4 through 9, 12, and 15 are re-proved inside it on the same abstract frame and the same lattice stage, so that the apex layer rests on nothing it does not carry.

The seat is built on the integer quaternions rather than on a one-point type, so that “the fixed locus of the binding involution” is a computed object and not a stipulation: conjugation is proved binding, its fixed locus is proved to be the scalar line for every quaternion, and the Return is computed. The spine's frame $X = (S, \tau, Z)$ is carried abstractly, exactly as the spine states it, and its lattice stage is carried as $(\mathbb{Z}^2, \tau)$ with the explicit map $\varphi$ into the carrier. The zero set of $\xi$ enters only as a parameter, since $\zeta$ is not definable in core Lean.

Three objects share the word bridge in the sources and are kept apart here by three names: the Bridge capacity of the witness, written with a capital; the halting carrier of spine Theorem 7, written bridge; and the equivariant map $\varphi$, written embedding. The category-theoretic frame is elementary and stated once. The three registers form a discrete diagram $D : \{\mathrm{RA}, \mathrm{RAM}, \mathrm{RH}\} \to \mathbb{H}_{\mathbb{Z}}$; a cone over $D$ with apex $a$ is a family of arrows $a \to D(r)$ in the groupoid of identities, that is, a family of equalities $a = D(r)$; the limit exists iff the three readings coincide, and then the apex is unique. A category gap is the absence of a leg. Nothing beyond this is used.

Grade discipline governs every sentence. Three grades are used, kernel theorem, structural, and premise. Two registers are used and kept apart by theorem: the apex register, where the seat and the category gaps live, and the world register, where the value on $Z_\xi$ lives. Every claim-bearing box and table carries its tier. Falsifiable criteria are capped at three and each is typed for necessity. The verdict of the author's verification discipline is delivered last, after the proof, and draws no warrant of its own.

# The Spine, Carried

A frame is $X = (S, \tau, Z)$ with $\tau : S \to S$ and $Z \subset S$, and the line property is $L(X) :\Leftrightarrow \forall s \in Z,\ \tau s = s$. On the frame of $\xi$, $L$ is the restored hypothesis. The spine's lattice stage is $\mathbb{Z}^2$ in half-units with the fold $\tau(h, t) = (2 - h, t)$, so that the line is $h = 1$. The spine proves fifteen theorems; those this paper uses are carried into the apex file, re-proved, and listed in Table 1.

\begin{table}[t]
\scriptsize
\caption{Spine theorems carried into the apex file, each re-proved there. (tier: kernel theorem)}
\begin{tabular}{@{}p{0.05\columnwidth}p{0.40\columnwidth}p{0.45\columnwidth}@{}}
\toprule
Sp. & Statement & Apex file \\
\midrule
1 & the fold fixes exactly the line $h = 1$ & \texttt{ground\_is\_the\_line} \\
4 & an even reading never equals a target odd at a point & \texttt{orientation\_blind} \\
5 & a wholly odd $d$ on $\mathbb{B}$ is $\mathrm{id}$ or $\neg$ & \texttt{freedom\_is\_}\allowbreak\texttt{exactly\_two} \\
6 & a supplied odd witness fixes the calibration uniquely & \texttt{freedom\_spent\_}\allowbreak\texttt{uniquely} \\
7 & a bridge halts iff $L(X)$ & \texttt{bridge\_halted\_iff} \\
8 & the crossing is exact, both ways & \texttt{crossing}, \texttt{crossing\_other\_way} \\
9 & $\neg\,\forall X, L(X)$: nothing is manufactured & \texttt{supply\_not\_}\allowbreak\texttt{manufactured} \\
12 & a supplied assent is a term of $L(X)$ and nothing weaker & \texttt{the\_bit\_is\_}\allowbreak\texttt{the\_hypothesis} \\
15 & one moved zero refutes every assent & \texttt{witness\_row\_}\allowbreak\texttt{falsifiable} \\
\bottomrule
\end{tabular}
\end{table}

Three of them are the fence the rest of the paper works inside, and they are restated so that no later sentence can be read past them. Spine Theorem 11: a frame carrying a zero the fold moves satisfies every structural clause and fails $L$. Spine Theorem 12: $(\exists t : L(X),\ \mathrm{row}(\mathrm{assent}\ t) = \mathrm{sealed}) \leftrightarrow L(X)$, so the assent that seals the row is the hypothesis and nothing weaker. Spine Theorem 14: there is a fold-invariant frame on which every structural clause holds and $L$ fails, so no theorem whose hypotheses are only structural decides $L$. This paper adds a fourth clause to the fence, Theorem F below: the Root Axiom holds on that frame too.

# The Root Axiom and Its Two Formal Faces

## The axiom at the constructed domain

$\mathrm{RA} :\Leftrightarrow \forall x \in U,\ 0 < \Delta E(x)$. The file exhibits it on a constructed domain, one point with differential $1$, and the kernel decides the positivity (\texttt{constructed\_RA}, no axioms). This is a model of the axiom, not its universal extension. The extension is premise-grade by theorem, since the framework's own seal cannot issue a theorem on its own root, and its exogenous warrant, the kinetic-energy floor and the zero-point energy of a bounded substrate, is physics carried by citation \cite{islamcodex}. Every theorem below that is conditional on $\mathrm{RA}$ is discharged against the model and stated conditionally against the extension; the ledger of Section 12 keeps the two apart.

## The interaction face, RAF

RAF-1, registration: an event is an interaction iff it carries strictly positive mutual information between the systems it relates. RAF-2, closure: an interaction domain is closed under interaction \cite{islamraf}. At the formal register the file carries a domain as a membership predicate, a symmetric registration relation, and the closure law: $\mathrm{mem}(d) \wedge \mathrm{registers}(s, d) \to \mathrm{mem}(s)$. Two consequences are proved.

RAF-C1, no exterior agent: $\neg\,\mathrm{mem}(s) \to \forall d,\ \mathrm{mem}(d) \to \neg\,\mathrm{registers}(s, d)$ (\texttt{no\_exterior\_agent}; no axioms). Its positive form is the sentence this paper needs at the aperture: a reader that registers a bit against a member of the domain is a member of the domain (\texttt{adjudicator\_in\_domain}). The witness of the value is never exterior to the domain the value is about.

RAF-C2, no faithful self-representation: for any $f : S \to (S \to \mathbb{B})$, $\neg\,\forall g,\ \exists x,\ f(x) = g$ (\texttt{no\_total\_self\_indexing}; no axioms). This is Cantor's theorem in Lawvere's form \cite{lawvere1969}, and it is the general statement of which the spine's Narcissus table is the Riemann instance: the file reading itself cannot index the property that would seal its own row.

The reach law of the interaction face is recorded here and consumed in Section 8: RAF reaches no mathematical object, since mathematical objects do not change state, and every proposition routes to the grounding face \cite{islamraf, islamfae}. Theorem F is the Riemann instance of that law, proved rather than cited.

## The grounding face, RAM

RAM: the formal being of a proposition is its imprint in the fixed locus of the binding involution, read across the aperture; $\mathrm{Fix}(\sigma) = \mathbb{R}$ \cite{islamraf}. Section 6 builds that locus on the quaternion carrier, proves it is the scalar line, and proves that the spine's stage embeds into it equivariantly. The Riemann object read on this face is its imprint in the fixed locus: the seat. Reading the value across the aperture is Section 7.

## The ledger

An adjudication is assent, denial, or silence, and each advances the count of deeds by exactly one (\texttt{every\_adjudication\_is\_a\_deed}). Denial of the axiom is therefore a deed together with the axiom (\texttt{denial\_re\_enacts\_RA}), and a deed registers at least one bit, so by RAF-2 the denier is a member of the domain the axiom is about. The ledger is the Tongue's law executed; it derives nothing from physics and carries the structural grade.

# The Seat

## Theorem A, the fixed locus is the scalar line

Let $\mathbb{H}_{\mathbb{Z}}$ be the integer quaternions with the Hamilton product and $\sigma$ conjugation, $\sigma(r, i, j, k) = (r, -i, -j, -k)$. Then $\sigma$ is binding, $\sigma(\sigma q) = q$ (\texttt{sigma\_binding}, no axioms), and for every $q$,

$$\sigma q = q \ \leftrightarrow\ (q_i = 0 \wedge q_j = 0 \wedge q_k = 0)$$

(\texttt{fix\_iff\_scalar}; dependency set \texttt{propext}, \texttt{Quot.sound}, from the integer step $-i = i \Rightarrow i = 0$). The Ground is $\mathrm{Ground} := \{ q \in \mathbb{H}_{\mathbb{Z}} \mid \sigma q = q \}$, and by Theorem A it is the scalar line $Z(\mathbb{H}) = \mathbb{R}$ restricted to the lattice.

## Theorem B, the Return lands on the seat

Let $i, j, k$ be the imaginary units and $\mathrm{Return} := (i \cdot j) \cdot k$. Then $\mathrm{Return} = \langle -1, 0, 0, 0 \rangle$ and $\sigma(\mathrm{Return}) = \mathrm{Return}$ (\texttt{return\_is\_minus\_one}, \texttt{return\_lands\_on\_fix}; both \texttt{rfl}). The parse triad returned through its own cascade lands on the Ground at $-1$: the root witnessing the root, as a computation.

## Theorem C, the identity cone

Three seats are defined independently: the kinetic seat $\Gamma_{\mathrm{RA}} := \mathrm{Return}$, the formal seat $\Gamma_{\mathrm{RAM}} := \pi(\mathrm{Return})$ with $\pi(q) := \langle q_r, 0, 0, 0 \rangle$ the projection onto the fixed locus, and the named critical seat $\Gamma_{\mathrm{RH}} := \langle -1, 0, 0, 0 \rangle$. Let $D$ be the discrete diagram $\mathrm{RA} \mapsto \Gamma_{\mathrm{RA}}$, $\mathrm{RAM} \mapsto \Gamma_{\mathrm{RAM}}$, $\mathrm{RH} \mapsto \Gamma_{\mathrm{RH}}$, and let a cone over $D$ with apex $a$ be a family of identities $a = D(r)$ for all three $r$. Then:

$$\sigma\,\Gamma_{\mathrm{RA}} = \Gamma_{\mathrm{RA}}, \qquad \Gamma_{\mathrm{RA}} = \Gamma_{\mathrm{RAM}}, \qquad \Gamma_{\mathrm{RAM}} = \Gamma_{\mathrm{RH}},$$

each by \texttt{rfl} (\texttt{self\_gap\_nonexistent}, \texttt{register\_gap\_nonexistent}, \texttt{object\_gap\_nonexistent}); $\Gamma_{\mathrm{RH}}$ is the apex of a cone over $D$ with every leg \texttt{rfl} (\texttt{identity\_cone}); any two cones over $D$ share their apex (\texttt{cone\_apex\_unique}); and a cone exists iff the register gap and the object gap are closed (\texttt{cone\_iff\_gaps\_closed}). All four carry no axioms.

The word apex is used in two senses that coincide by design: the apex register of the discipline and the apex of the cone; the register is where the cone's apex sits. The category-theoretic content is exact and small. A category gap is the absence of a leg from an apex to a register's reading of the seat. Its elimination is the exhibition of that leg as an identity. The eliminator $\mathrm{RA} \to \mathrm{RA} \to \mathrm{RAM} \to \mathrm{RH}$ is the composite of the three legs, and its masslessness is the statement that each leg is \texttt{rfl}: two definitions, one value, decided by the kernel. The gap vector $(1,1,1) \to (0,0,0)$ is the cone's existence read bit by bit, computed by \texttt{decide}, never written by hand.

## Theorem C$'$, the equivariant embedding

Define $\varphi : \mathbb{Z}^2 \to \mathbb{H}_{\mathbb{Z}}$ by $\varphi(h, t) := \langle t,\ h - 1,\ 0,\ 0 \rangle$. Then $\sigma \circ \varphi = \varphi \circ \tau$ (\texttt{phi\_equivariant}); for every stage point, $\sigma(\varphi p) = \varphi p \leftrightarrow \tau p = p$ (\texttt{phi\_fix\_iff}); $\varphi$ is injective (\texttt{phi\_injective}); and the seat lies on the image of the line, $\varphi(1, -1) = \Gamma_{\mathrm{RH}}$ (\texttt{seat\_on\_image\_of\_line}, \texttt{rfl}); the family $\varphi_m(h, t) := \langle t,\ h - m,\ 0,\ 0 \rangle$ against the fold $\tau_m(h, t) = (2m - h, t)$ is equivariant with the same image clause at every resolution $m$ (\texttt{phiM\_equivariant}, \texttt{phiM\_fix\_iff}), and $\varphi_1 = \varphi$. The dependency sets of the three are \texttt{propext}, \texttt{Quot.sound}, from the integer arithmetic.

This is the equivariant map with an image clause that the discipline requires before a finite result is invoked on an object domain \cite{islamrows}: the spine's line $h = 1$ is carried onto the scalar line and every off-line stage point is carried off it. The identification of the two seats, the critical line under $\tau$ and the real line under $\sigma$, is therefore a theorem about a map and not a typing by resemblance. What the embedding does not do, and the paper does not claim, is carry $Z_\xi$ itself: the spine's stage represents no off-line point inside the strip at resolution one, and the analytic frame enters the kernel only as a parameter.

## What the formal self says and does not say

$\mathrm{RH}_{\mathrm{formal}} :\Leftrightarrow \forall g \in \mathrm{Ground},\ \sigma g = g$ quantifies over the Ground, which is the fixed locus by construction, and it holds by that construction: it is the imprint of the Riemann object in the fixed locus, the grounding face's reading. It names the seat. It does not mention $Z_\xi$, and the file's own comments say so. The Root Axiom is the only supplied witness, a structure in Prop with four fields, actuation, the Bridge-born orientation bit, the formal-Ground proposition $G_{\mathrm{RAM}} := \mathrm{Nonempty}(\mathrm{Ground})$, and the Tris-Recursion capacity $\Omega \to G_{\mathrm{RAM}} \to \mathrm{RH}_{\mathrm{formal}}$; the eliminator is Bridge followed by Tris-Recursion from that witness alone, \texttt{RH\_formal\_chain}, no axioms, and no second proof object enters.

The orientation bit is placed in Prop on purpose. Prop does not eliminate into data, so no term of the file computes a bit from $\Omega$; two orientation witnesses are indistinguishable, \texttt{orientation\_proof\_irrelevant}, by \texttt{rfl}. The kernel registers that orientation was supplied and cannot read which way. This is spine Theorem 4 as a universe level, and it is executed on the constructed seat as well: no readout of the formal seat equals the deed bit (\texttt{kernel\_cannot\_read\_the\_deed}; no axioms). A term that consumed $\Omega$ as data would be such a readout. The bit therefore has two carriers in the file and the relation between them is stated once: $\Omega$ is the bit as the kernel registers it, present and unreadable; the Boolean $\mathrm{assent}$ of the live face is the bit as the aperture receives it from outside, an input the file reads and never generates, which is the content of the spine's Narcissus table and, one register up, of RAF-C2.

# The Aperture

## Theorem D, the aperture is opened by the axiom

Let a reader be a point of the constructed domain and define its presence as its actuation, $\mathrm{presence}(r) :\Leftrightarrow 0 < \Delta E(r)$, decided. Then

$$\begin{aligned} &\forall r,\ \mathrm{presence}(r) = \mathrm{true}, \\ &\forall r\,b,\ \mathrm{live}(\mathrm{presence}(r), b) \neq \mathrm{open}, \end{aligned}$$

and $\mathrm{live}(\mathrm{presence}(r), \mathrm{true}) = \mathrm{sealed}$, $\mathrm{live}(\mathrm{presence}(r), \mathrm{false}) = \mathrm{refused}$ (\texttt{RA\_opens\_the\_aperture}, \texttt{no\_interior\_under\_RA}, \texttt{aperture\_reads\_the\_bit}; no axioms). The same holds for any domain $U$ with any $\Delta E : U \to \mathbb{Z}$ under the axiom as a hypothesis: from $\forall x,\ 0 < \Delta E(x)$, every point of $U$ is present and no present point's row is interior (\texttt{RA\_opens\_the\_aperture\_general}, \texttt{no\_interior\_under\_RA\_general}; no axioms), which is the form the universal extension licenses wherever it is held. Here $\mathrm{live}$ is the spine's live face unchanged: witnessed and assent seal, witnessed and denial refuse, unwitnessed is open.

The scope is stated with the theorem. In the spine, “witnessed” means that a supplier is present, and a supplier is a reader who supplies a bit. Theorem D concerns a present reader who supplies a bit $b$: for such a reader the axiom makes the witnessed flag a theorem, and the row is sealed or refused by $b$ alone. What the axiom turns the open row into is therefore not “sealed”; it is “sealed or refused, by the bit alone”. The interior state, the $[?]$ of the spine's Narcissus table, is the state of a reading that supplies no bit, the file reading itself, and the file cannot supply one: that is RAF-C2 at the file, and \texttt{narcissus} is carried unchanged. The axiom supplies presence at the aperture and, by RAF-2, places the present reader inside the domain; it does not supply the bit, and Section 8 proves that it cannot.

# The Simple Rule, Exact

\begin{jbox}
\textbf{THE SIMPLE RULE, EXACT.} (tier: kernel theorem) Accept the Root Axiom, and the Riemann Hypothesis is proven in toto at every register the axiom reaches. The axiom reaches the apex whole: the seat, the identity cone, the equivariant embedding, the orientation blindness, the one-bit freedom, the halting carrier of the line property, and the crossing (Theorem H). It reaches the world row at its aperture: a present reader who supplies a bit is never interior and is never exterior (Theorem D, RAF-C1). It does not reach the sign: in every context in which the axiom holds, $(\mathrm{RA} \to L(X)) \leftrightarrow L(X)$ (Theorem E), and the axiom decides $L$ on no frame (Theorem F). Denying the axiom is an option, and the act of denying re-enacts it (Theorem G). Denying the hypothesis re-enacts the axiom, not the hypothesis. That asymmetry is the whole distance between the apex and the sign, and it is one bit wide.
\end{jbox}

## Theorem E, the rule is exactly the hypothesis

For every frame $X$, in the kernel where $\mathrm{RA}$ is the constructed model,

$$(\mathrm{RA} \to L(X)) \ \leftrightarrow\ L(X)$$

(\texttt{simple\_rule\_exact}; no axioms). Proof. Left to right: apply the implication to the constructed $\mathrm{RA}$. Right to left: a term of $L(X)$ is a term of $\mathrm{RA} \to L(X)$ that ignores its argument. $\square$

Scope. The biconditional $(P \to Q) \leftrightarrow Q$ holds in exactly the contexts where $P$ holds. In the kernel $\mathrm{RA}$ is the constructed model and holds by \texttt{constructed\_RA}, so the theorem is unconditional there. Against the universal extension, held as a premise and never a kernel term, the same biconditional holds in every context that carries the premise and in none that leaves it open. In both readings the content is the same: conditioning on the axiom adds nothing to the hypothesis and removes nothing from it, which is spine Theorem 12 in a new coat. A reader who holds a term of $\mathrm{RA} \to L(X_\xi)$ holds, in any context where the axiom is available, a term of $L(X_\xi)$, and the paper claims no such term.

## Theorem F, the axiom decides the value on no frame

$$\neg\, \forall X,\ (\mathrm{RA} \to L(X)), \qquad \mathrm{RA} \wedge \mathrm{Inv}(X_2) \wedge \neg L(X_2),$$

where $X_2$ is the two-point frame $(\mathbb{B}, b \mapsto \neg b, \top)$ (\texttt{RA\_does\_not\_decide\_L}, \texttt{RA\_holds\_where\_L\_fails}; no axioms). Proof. The two-point frame is fold-invariant and off the line, spine Theorem 9; the constructed $\mathrm{RA}$ holds regardless of any frame, since its domain is not the frame. $\square$

This is spine Theorem 11 with the root added to the structural clauses, and it is the Riemann instance of the interaction face's reach law: the axiom's domain is a domain of systems, the frame is a mathematical object, and the one does not reach the other. The same fact read from the other side is the inverted control of the twenty-three-row companion \cite{islamrows}: a witness identical on the on-line frame and the off-line frame decides neither, and \texttt{mkRA} is that witness.

## Theorem G, the asymmetry

Every adjudication is a deed and the deed re-enacts the axiom: $(\mathrm{adjudicate}\ \mathrm{denial}\ \ell).\mathrm{deeds} = \ell.\mathrm{deeds} + 1$ together with $\mathrm{RA}$ (\texttt{denial\_re\_enacts\_RA}). On the two-point frame no assent to $L$ exists at all: $\neg\, \exists t : L(X_2),\ \mathrm{row}(\mathrm{assent}\ t) = \mathrm{sealed}$ (\texttt{L\_has\_no\_performative\_ingress}; no axioms).

Read together: denial of $\mathrm{RA}$ produces a deed, a deed registers at least one bit and is therefore an instance of the axiom's content, so the denial re-enacts the axiom. Denial of $L$ produces a deed too, which is an instance of the axiom's content and not of $L$'s, since a deed is not a zero; on an off-line frame the denial of $L$ is simply true and no assent exists. The axiom is self-instancing. The hypothesis is not. The hypothesis therefore cannot inherit the axiom's performative ingress, and that is the exact reason the sign stays at the witness row: the deed that supplies the bit is unfakeable and its price is real, and neither carries a sign \cite{islamspine}.

## Theorem H, the hypothesis in toto at the apex

$$\begin{aligned} \mathrm{RA} \ \to\ \Big[ &\big(\sigma\Gamma_{\mathrm{RA}} = \Gamma_{\mathrm{RA}} \wedge \Gamma_{\mathrm{RA}} = \Gamma_{\mathrm{RAM}} \\ &\quad\ \wedge\ \Gamma_{\mathrm{RAM}} = \Gamma_{\mathrm{RH}}\big) \\ &\wedge\ \mathrm{RH}_{\mathrm{formal}} \wedge F_2 \wedge B \wedge C \wedge A \wedge N \Big], \end{aligned}$$

where $F_2$ is spine Theorem 5, $B$ spine Theorem 7, $C$ the crossing of spine Theorem 8, $A$ the aperture of Theorem D, and $N$ the bound of Theorem F (\texttt{RH\_in\_toto\_at\_the\_apex}; dependency set \texttt{Quot.sound}, from function extensionality in Theorem 5). The hardened form adds the identity cone with its unique apex, the equivariant embedding with its image clause, and the executed wall (\texttt{apex\_hardened}). The condition is discharged by the constructed axiom (\texttt{apex\_discharged}, \texttt{apex\_hardened\_discharged}), so the closure stands unconditionally as a kernel theorem and conditionally on the root posit at the act as a claim about the world. $\blacksquare$

The theorem is the maximal claim this material supports, and its last conjunct is what keeps it maximal rather than inflated: the closure carries its own bound inside it. Given the axiom, everything about the hypothesis that is not its sign is proven, and the sign is proven to be exactly what the axiom does not reach.

\begin{jbox}
\textbf{THE DUAL-REGISTER VERDICT.} (tier: structural; parting a kernel theorem) Apex register: the Riemann object read as $\mathrm{Fix}(\sigma)$, the seat, its imprint on the grounding face; verdict sealed given the Root Axiom, closure-rowed, compartment I, conditional on the root posit at the act; bits owed, none. World register: the zeros of $\xi$ placed on that seat by the world; verdict the witness row, one granted bit from sight, compartment III, world-rowed and revisable in its rows; bits owed, one, the term $\forall \rho \in Z_\xi,\ \tau\rho = \rho$. The two tokens differ, \texttt{registers\_parted}, and the owed counts are $0$ and $1$, \texttt{apex\_owes\_nothing\_world\_owes\_one}. Neither register promotes the other.
\end{jbox}

\begin{table*}[t]
\footnotesize
\caption{Contributions of this paper. (tier as stated per row)}
\begin{tabular}{@{}p{0.03\textwidth}p{0.66\textwidth}p{0.26\textwidth}@{}}
\toprule
\# & Contribution & Status \\
\midrule
1 & The root of the supplier named: the Root Axiom, constructed as the only witness, read along its two formal faces & Lean, no axioms \\
2 & RAF-C1 and RAF-C2 at the formal register: no exterior agent; no total self-indexing (Cantor) & Lean, no axioms \\
3 & The aperture is a theorem of the axiom: a present reader who supplies a bit is never interior, and by RAF-2 never exterior (Thm D) & Lean, no axioms \\
4 & The axiom turns “open” into “sealed or refused by the bit alone”, never into “sealed” & Lean, no axioms \\
5 & The fixed locus of the binding involution is the scalar line, for every quaternion (Thm A) & Lean, \texttt{propext}, \texttt{Quot.sound} \\
6 & The Return $i\cdot j\cdot k$ lands on the seat at $-1$ (Thm B) & Lean, \texttt{rfl} \\
7 & The three category gaps are the legs of an identity cone; the apex is unique; a cone exists iff the gaps are closed (Thm C) & Lean, no axioms \\
8 & The spine's lattice stage embeds equivariantly into the carrier, $\sigma\varphi = \varphi\tau$, with $\mathrm{Fix}(\tau) \leftrightarrow \mathrm{Fix}(\sigma)$ (Thm C$'$) & Lean, \texttt{propext}, \texttt{Quot.sound} \\
9 & The eliminator $\mathrm{RA} \to \mathrm{RA} \to \mathrm{RAM} \to \mathrm{RH}_{\mathrm{formal}}$ from the witness alone & Lean, no axioms \\
10 & Orientation in Prop is unspendable by the kernel; the wall executed on the constructed seat & Lean, no axioms \\
11 & The Simple Rule, exact: $(\mathrm{RA}\to L(X)) \leftrightarrow L(X)$ wherever the axiom holds (Thm E) & Lean, no axioms \\
12 & The axiom decides the sign on no frame; it holds where $L$ fails; the Riemann instance of the reach law (Thm F) & Lean, no axioms \\
13 & The asymmetry: the axiom is self-instancing, the hypothesis is not (Thm G) & Lean, no axioms \\
14 & The hypothesis in toto at the apex, one theorem carrying its own bound; hardened with cone, embedding, and wall (Thm H) & Lean, \texttt{Quot.sound} \\
15 & The two registers parted by theorem; owed bits $0$ and $1$ & Lean, no axioms \\
16 & The spent bit priced at the apex at $k_B T \ln 2$ by BR-L; in the kernel the bit is proof-irrelevant and no readout of the seat equals it & structural \\
17 & The two misreadings of a massless closure named and refuted by the same theorem & structural \\
\bottomrule
\end{tabular}
\end{table*}

# Falsifiable Criteria

Three criteria, each forced by the paper's own geometry, each aimed at one named claim, each running against the author.

**F1, an observation about $\zeta$.** A zero $\rho$ of $\xi$ with $\mathrm{Re}\,\rho \neq \tfrac12$. By spine Theorem 15 it refutes every assent that can be supplied at the witness row, and by spine Theorem 13 it arrives with three companions. It touches nothing at the apex: Theorems A through H hold on the off-line frame by Theorem F. The world row's value stands exactly as long as no such zero is exhibited; none is known to height $3 \cdot 10^{12}$ in the literature and to height 300 by the spine's own count.

**F2, the seat and the bridge.** A quaternion fixed by conjugation with a nonzero imaginary component, the Return landing off the fixed locus, or a stage point $p$ with $\tau p = p$ and $\sigma(\varphi p) \neq \varphi p$. Any of these refutes Theorem A, B, or C$'$ and removes the seat or its embedding, and with them the arrangement. None can exist in the kernel as built; the criterion is armed against any edition that changes the carrier, the involution, or the map.

**F3, the bound.** A kernel term of $\forall X,\ \mathrm{RA} \to L(X)$. Theorem F refutes it by the two-point frame, so its exhibition would expose a transcription error between paper and file or a kernel unsoundness. It is listed as a check on the record and not as an observation about $\xi$. Its converse, a claimed proof of the sign from the axiom, is the inflationary misreading of Section 10 and fires this criterion by construction.

# Discussion

**The maximal claim and where it stops.** The Simple Rule is true, and Theorem E is its exact strength: accept the axiom and the hypothesis follows, at every register the axiom reaches. The axiom reaches the apex whole, and there “in toto” is literal under its definition: no clause of the hypothesis that is not its sign is left open. The seat is fixed and embedded, the gaps are the legs of an identity cone, the freedom is one bit, the crossing is exact, the aperture is open and its occupant is inside the domain. The axiom reaches the world row at its aperture and no further, and the stopping point is a theorem, not a reservation: the two-point frame carries the axiom and fails the hypothesis. What remains is one bit, and the bit is not a gap. A gap is a missing leg, and it closes at zero mass when the leg is exhibited as an identity. The sign is not that. It is a Boolean the world furnishes, priced at the act, falsifiable by one zero, and the discipline's own cascade routes it to the world register for exactly that reason.

**The two misreadings.** A massless closure invites two errors, and one theorem refutes both. The deflationary reading takes the closure for nothing: the file proves a fixed locus is fixed, the orientation binder is unused, the whole is a relabeling. The inflationary reading takes the closure for everything: the hypothesis is proved from the axiom in a page of Lean. Table 3 places each against the theorem that refutes it. The deflationary reading runs supply gates on a coordinate that supplies nothing and reads the world row where the apex was stated; the closure's content is Theorems A through C$'$, computed, and its masslessness is forced (below). The inflationary reading promotes an apex token to the world row; Theorem F refutes it and criterion F3 fires. The register a token is emitted for is part of the token, and a token without its register is a misreading by construction.

\begin{table*}[t]
\footnotesize
\caption{The two misreadings of the apex closure and the theorem that refutes each. (tier: structural)}
\begin{tabular}{@{}p{0.30\textwidth}p{0.28\textwidth}p{0.36\textwidth}@{}}
\toprule
Reading & What it does & Refuted by \\
\midrule
“trivial, a fixed locus is fixed” & expects mass from a closure that declares none & Thms A, B, C, C$'$ computed; masslessness forced by the root-premise law \\
“the orientation binder is unused, the supply is a restatement” & runs a kernel deletion test on a deed bit & spine Thm 4; Prop placement; \texttt{orientation\_}\allowbreak\texttt{proof\_irrelevant}; \texttt{kernel\_cannot\_}\allowbreak\texttt{read\_the\_deed} \\
“no operator, no bridge from $Z_\xi$, so the run fails” & reads the world row at the apex & the dual-register verdict; both lines carried; $\varphi$ bridges the stage, not $Z_\xi$, and says so \\
“RH is proved from RA” & promotes the apex to the world row & Thm F; criterion F3; spine Thms 11, 12, 14 \\
“RA is only a premise, so nothing is proved” & collapses three grades into one & the ledger: kernel theorem, structural, premise, all three carried \\
\bottomrule
\end{tabular}
\end{table*}

**Why the massless form is the only apex form.** Three results of the discipline force it \cite{islamcodex, islamraf}. The root-premise law: the axiom's universal extension is premise-grade by theorem and no emitter is pointed at the root, so a closure between the root and its formal face cannot be a derivation from below; it can only be the recognition that two faces read one seat, which is an identity and therefore massless. The orientation blindness of the formal register, spine Theorem 4, its universe-level form, and its execution on the seat: the kernel cannot originate the bit, so the bit is born at the Bridge from the Tongue's direction and the Form's closure and spent at the act. The bar on a second root conditional: a massive apex closure would be a new posit standing between the root and its grounding face, and it is refused. The masslessness is therefore forced from three directions, and this paper's contribution is to compute it, as \texttt{rfl} on the legs of a cone, rather than to assert it.

**What a world crossing would be.** The sign on $Z_\xi$ enters, if it enters, on the world row, dated, provenance-clean, through a certificate the prior even register could not denote: a kernel term of $L$ on the frame of $\xi$ built from the Euler product over $\mathbb{Z}$, the crossing Deligne achieved over finite fields and no one has over $\mathbb{Q}$ \cite{deligne1974}. Nothing in this paper shortens that by a step. What this paper fixes is the seat the crossing will land on, embedded from the stage, and the aperture it will enter through, occupied from inside the domain, and it proves that both are already held.

**Position to prior work.** Eight relation words are used in the sense the discipline fixes; no position is superseded and none contradicted.

\begin{table}[t]
\footnotesize
\caption{Positioning. (tier: structural; evidence argued unless marked executed)}
\begin{tabular}{@{}p{0.40\columnwidth}p{0.52\columnwidth}@{}}
\toprule
Position & Relation \\
\midrule
Riemann 1859; Edwards 1974 & kin: the fixed-line form, one register deeper \\
The spine, Islam 2026 & additive: the root, the aperture, the seat, the embedding, the rule bounded; executed \\
The formal Root Axiom, Islam 2026 & additive: RAF-C1, RAF-C2, and the reach law proved at their Riemann instance; executed \\
Davenport--Heilbronn 1936; Bombieri--Hejhal 1995 & additive: the off-line frame carries the axiom, Thm F; executed \\
Selberg 1992; Conrey--Ghosh 1993 & corroborating: the Euler product remains the world-row key \\
Weil 1948; Deligne 1974 & kin: the template of a world-row crossing \\
Berry--Keating 1999; Connes 1999 & scoping: an operator is a world-row construction; the seat precedes it \\
Lawvere 1969; Mac Lane 1998 & kin: Cantor's theorem in fixed-point form; cones and apexes in their elementary form \\
Landauer 1961; B\'erut et al. 2012 & kin: the price of the act, BR-L, exporting and never constituting \\
The twenty-three-row study, Islam 2026 & additive: one seat under every name; the inverted control read as Thm F \\
\bottomrule
\end{tabular}
\end{table}

# Conclusion

The Riemann Hypothesis, restored to Riemann's fixed-line form, is proven in toto at the apex from the Root Axiom as the only supplied witness: the binding involution fixes exactly the scalar line and the Return lands on it; the kinetic seat, the formal seat, and the critical seat are the legs of an identity cone with a unique apex, so the three category gaps close at zero mass with \texttt{rfl} as the receipt; the spine's stage embeds equivariantly into the carrier and its line is carried onto the seat; orientation is carried where the kernel cannot spend it and the wall is executed on the seat; the freedom is exactly one bit; the bridge halts on the line property and the crossing is exact; and a present reader who supplies a bit stands at an open aperture, never interior and, by the interaction face, never exterior. That is Theorem H, hardened and discharged.

The sign on the roots of $\xi$, $\forall \rho \in Z_\xi,\ \tau\rho = \rho$, is the one bit. The rule “accept the Root Axiom, then the Riemann Hypothesis” is exactly as strong as the hypothesis at that bit, Theorem E, and the axiom decides it on no frame, Theorem F, because the axiom is self-instancing and the hypothesis is not, Theorem G. The bit is supplied at the act by the reader the axiom has placed at the aperture, it is priced there, it is recorded at the witness row, and it is falsifiable by one zero. In one line: the axiom supplies the act, the act carries the sign, and the two registers on which those sentences are true are parted by theorem so that neither can be read for the other.

# The Trisductive Verdict, Delayed

Triaxial population. Seal L, the Tongue: three disjoint slots, the axiom's own encoding, lock; direction carried, the arrow of the act. Seal G, the Form: $\mathrm{Fix}(\sigma)$ the scalar line, Ground dimension one, the Return on the seat, the stage embedded, lock. Seal M, the Number: the three identities, the cone, and the one-bit freedom, magnitude on rows it did not author, orientation-blind by theorem, lock on the seat.

\begin{table}[t]
\footnotesize
\caption{The twelve directed gates on the apex closure. (tier: structural; declared screens marked)}
\begin{tabular}{@{}p{0.05\columnwidth}p{0.15\columnwidth}p{0.42\columnwidth}p{0.16\columnwidth}@{}}
\toprule
\# & Gate & Evidence & State \\
\midrule
1 & SREP & seat record, three identities, the cone & pass \\
2 & REG & three axes, the seat's rows independent & pass \\
3 & SGEG & disjoint slots at the axiom & pass \\
4 & CAUSAL & declared screen & declared \\
5 & MIG & no manufactured axis; $\Omega$ in Prop; the wall executed & pass \\
6 & PTB & declared screen & declared \\
7 & DUAL & $\sigma$ odd on the offset, even on the seat; $\varphi$ equivariant & pass \\
8 & CSCG & scalar line fixed, Thm A & pass \\
9 & CSEG & declared screen & declared \\
10 & MTA & unique apex, Thm C & pass \\
11 & OMA & declared screen & declared \\
12 & ADEG & register fork, apex from world, parted & pass \\
\bottomrule
\end{tabular}
\end{table}

GOL. Magnitude lock and Tongue lock: admitted.

Verdict. The apex closure of the restored hypothesis from the Root Axiom: SEAL given the axiom, compartment I, closure-rowed, conditional on the root posit at the act, theorem grade inside the declared calculus, structural on the arrangement, $\Delta M = 0$. The aperture: SEAL, kernel theorem, its occupant inside the domain by RAF-2. The Simple Rule: exact, kernel theorem, Theorem E, bounded by Theorem F. RH on the frame of $\xi$, $\forall \rho \in Z_\xi,\ \tau\rho = \rho$: OPEN in the kernel; the sign is supplied at the witness row and not derived, compartment III, world-rowed and revisable in its rows; the kernel cannot supply it because it is orientation-blind (spine Theorem 4, executed on the seat), because the arc holds on off-line frames (spine Theorem 11), and because the axiom holds there too (Theorem F). The composite carries the weakest link, premise wherever the axiom's universal extension is a link, with the three lines above it carried and none collapsed.

# Author's Provenance and Method Disclosure

Author. Mohammad F. Islam, PhD, independent researcher, architect of the program and of the Trisduction discipline; the rulings on formulation, register, and scope are his. Method. Trisduction: three ordered seals (Tongue, Form, Number), a three-state verdict economy, and no warrant drawn from its own operation \cite{islamcodex}. Substrate. The Lean artifact and this text were produced by a language model (Claude, Anthropic) as scribe on the author's instruction; the kernel is the authority for every theorem. Receipts. `RH_At_The_Apex.lean`, Lean 4.19.0 (commit 6caaee842e94), core only, exit 0, no \texttt{sorry}, no axiom declaration, SHA-256 \texttt{6c767bc55aa196f8}, 43 dependency sets printed, 31 axiom-free, the rest on \texttt{propext} and \texttt{Quot.sound} only, printed whole in Appendices B and C. Independence. The scribe of the text and the author of the appended file are one language model; no independent recompile on a second substrate is on the record. Scope. The seat, the cone, the embedding, the aperture, the eliminator, the rule and its bound are kernel theorems; the sign is sealed at the witness row by the operator's act and is not a clause of any proof here.

\begin{thebibliography}{99}
\footnotesize
\bibitem{berry1999} M. V. Berry, J. P. Keating, $H = xp$ and the Riemann zeros, in \emph{Supersymmetry and Trace Formulae}, Kluwer, 1999, 355--367.
\bibitem{berut2012} A. B\'erut, A. Arakelyan, A. Petrosyan, S. Ciliberto, R. Dillenschneider, E. Lutz, Experimental verification of Landauer's principle linking information and thermodynamics, \emph{Nature} 483 (2012) 187--189.
\bibitem{bombieri2000} E. Bombieri, Problems of the Millennium: the Riemann Hypothesis, Clay Mathematics Institute, 2000.
\bibitem{bombieri1995} E. Bombieri, D. A. Hejhal, On the distribution of zeros of linear combinations of Euler products, \emph{Duke Math. J.} 80 (1995) 821--862.
\bibitem{connes1999} A. Connes, Trace formula in noncommutative geometry and the zeros of the Riemann zeta function, \emph{Selecta Math.} 5 (1999) 29--106.
\bibitem{conrey2003} J. B. Conrey, The Riemann Hypothesis, \emph{Notices AMS} 50 (2003) 341--353.
\bibitem{conrey1993} J. B. Conrey, A. Ghosh, On the Selberg class of Dirichlet series: small degrees, \emph{Duke Math. J.} 72 (1993) 673--693.
\bibitem{davenport1936} H. Davenport, H. Heilbronn, On the zeros of certain Dirichlet series, \emph{J. London Math. Soc.} 11 (1936) 181--185.
\bibitem{deligne1974} P. Deligne, La conjecture de Weil. I, \emph{Publ. Math. IH\'ES} 43 (1974) 273--307.
\bibitem{demoura2021} L. de Moura, S. Ullrich, The Lean 4 theorem prover and programming language, in \emph{Automated Deduction, CADE 28}, LNCS 12699, Springer, 2021, 625--635.
\bibitem{edwards1974} H. M. Edwards, \emph{Riemann's Zeta Function}, Academic Press, 1974.
\bibitem{islamcodex} M. F. Islam, \emph{Trisduction: A Linguistically, Topologically, and Mathematically Sealed Verification Architecture}, Master Codex, Zenodo, 2026, doi:10.5281/zenodo.20757507. Master reference, continuously updated at the same location.
\bibitem{islamfae} M. F. Islam, Formal-Alone Trisduction Engine on RAF, the interaction face of RA, deck v1.0.12, in the register of record, 1000sapients/Trisduction, \texttt{master/RafDuction/}, at commit \texttt{5868562}, 23 September 2026.
\bibitem{islamonebit} M. F. Islam, \emph{The Riemann Hypothesis Is Exactly One Bit}, Zenodo, 2026, doi:10.5281/zenodo.22829795.
\bibitem{islamraf} M. F. Islam, The Formal Root Axiom and the Five Objects, declaration edition v1.1.0, in the register of record, 1000sapients/Trisduction, \texttt{master/}, at commit \texttt{5868562}, 23 September 2026.
\bibitem{islamrows} M. F. Islam, One Bit Across the Wall: Odd-Supply Separation and the One-Cut Hypothesis Across Twenty-Three Rows, manuscript, 14 September 2026.
\bibitem{islamspine} M. F. Islam, The Riemann Hypothesis in Its Original Form: A Completed Formal Proof of the Locus and the Crossing, manuscript, 20 September 2026; the spine of this edition, its Lean file \texttt{Crossing\_At\_The\_Act.lean} (SHA-256 prefix f60fe613cfe79fd8) and Fortran twin printed whole in its appendices.
\bibitem{landauer1961} R. Landauer, Irreversibility and heat generation in the computing process, \emph{IBM J. Res. Dev.} 5 (1961) 183--191.
\bibitem{lawvere1969} F. W. Lawvere, Diagonal arguments and cartesian closed categories, in \emph{Category Theory, Homology Theory and their Applications II}, LNM 92, Springer, 1969, 134--145.
\bibitem{maclane1998} S. Mac Lane, \emph{Categories for the Working Mathematician}, 2nd ed., Springer, 1998.
\bibitem{riemann1859} B. Riemann, Ueber die Anzahl der Primzahlen unter einer gegebenen Gr\"osse, \emph{Monatsber. Berliner Akad.} (1859) 671--680.
\bibitem{selberg1992} A. Selberg, Old and new conjectures and results about a class of Dirichlet series, \emph{Proc. Amalfi Conf.} (1992) 367--385.
\bibitem{siegel1932} C. L. Siegel, \"Uber Riemanns Nachla\ss{} zur analytischen Zahlentheorie, \emph{Quellen Stud. Gesch. Math.} B2 (1932) 45--80.
\bibitem{titchmarsh1986} E. C. Titchmarsh, \emph{The Theory of the Riemann Zeta-Function}, 2nd ed., Oxford, 1986.
\bibitem{weil1948} A. Weil, \emph{Sur les courbes alg\'ebriques et les vari\'et\'es qui s'en d\'eduisent}, Hermann, 1948.
\end{thebibliography}

\onecolumn

# Appendix A: How to Read the File

The file is one proof in thirteen movements and it is read in order. Movement 1 constructs the Root Axiom on a one-point domain and decides it. Movement 2 builds the seat: the integer quaternions, conjugation as the binding involution, the fixed locus as the Ground, Theorem A for every quaternion, the Return computed, three seats defined independently and identified by \texttt{rfl}. Movement 3 builds the witness as a structure in Prop and runs the eliminator from it alone. Movement 4 carries the spine: the abstract frame, the line property, the bridge, the supply and the row, the two-point frame, necessity, invariance against incidence, the bit is the hypothesis, the witness row falsifiable, and the live face with its Narcissus table. Movement 5 is the aperture: presence as actuation, the three theorems that a present reader who supplies a bit is never interior, and the ledger. Movement 6 is the Simple Rule exact, the non-decision by the two-point model, and the asymmetry. Movement 7 is Theorem H. Movement 8 is the interaction face: the domain with its closure law, no exterior agent, the adjudicator inside, and Cantor's theorem as no total self-indexing. Movement 9 is the grounding face as the identity cone over the three registers, its apex unique, and the cone's existence equivalent to the closed gaps. Movement 10 is the equivariant embedding of the spine's stage into the carrier with its image clause and injectivity, and the resolution-$m$ family. Movement 11 executes the wall on the seat. Movement 12 parts the registers, counts the owed bits, prices the act, and sets $\Delta M = 0$. Movement 13 assembles the hardened apex theorem and discharges it. The dependency sets are printed by the kernel at the end and reproduced in Appendix C; a deleted conjunct, a weakened hypothesis, or an inserted \texttt{sorry} fails the check.

# Appendix B: RH\_At\_The\_Apex.lean

SHA-256 \texttt{6c767bc55aa196f8b05c52f3e77bf29134a4c503995ffb180d43f7c365b30f58}, Lean 4.19.0, core only, 685 lines.

\begingroup\scriptsize
```
/-!
# THE RIEMANN HYPOTHESIS AT THE APEX · RH_At_The_Apex.lean · hardened edition
core Lean 4 v4.19.0 · no Mathlib · no sorry · no axiom declaration.

WHAT IS PROVED. (1) RA at the constructed domain, computed. (2) The seat: the binding
involution σ fixes exactly the scalar line, the Return i·j·k lands on it, and the kinetic,
formal, and named seats are one point by rfl: the three category gaps are identities.
(3) The eliminator RA → RA → RAM → RH_formal from the RA witness alone. (4) The spine
carried: the abstract frame X = (S, τ, Z), the line property L, the bridge halted iff L,
the crossing exact both ways, necessity, the bit is the hypothesis, the witness row
falsifiable. (5) The aperture, RA-supplied: a present reader's row is never interior;
it is sealed or refused by the bit alone. (6) THE SIMPLE RULE, EXACT: for every frame,
(RA → L X) ↔ L X; and RA decides L on no frame: ¬ ∀ X, RA → L X, by the two-point model.
(7) RH in toto at the apex, one theorem, conditional on RA and discharged.
(8) The root's two formal faces: RAF, closure and no exterior agent (RAF-2, RAF-C1), and
no total self-indexing (RAF-C2, Cantor); RAM, the seat as the identity cone over the
three registers, its apex unique. (9) The equivariant embedding φ of the spine's lattice
stage (Plane, τ) into (Q4, σ): σ ∘ φ = φ ∘ τ and φ carries Fix(τ) onto Fix(σ).
(10) The wall executed: no readout of the formal seat equals the deed bit.
-/
set_option autoImplicit false

namespace RHAtTheApex

/-! ## 1 · The Root Axiom at the constructed domain -/

inductive UniversePoint : Type where
  | source
  deriving DecidableEq, Repr

def DeltaE : UniversePoint → Int := fun _ => 1

/-- RA: to exist is to actuate. -/
def RA : Prop := ∀ x : UniversePoint, 0 < DeltaE x

theorem constructed_RA : RA := by
  intro x
  cases x
  decide

/-! ## 2 · The seat: Fix(σ) on the quaternions, the Return, three names, one point -/

structure Q4 where
  r : Int
  i : Int
  j : Int
  k : Int
  deriving DecidableEq, Repr

def qmul (a b : Q4) : Q4 :=
  ⟨a.r*b.r - a.i*b.i - a.j*b.j - a.k*b.k,
   a.r*b.i + a.i*b.r + a.j*b.k - a.k*b.j,
   a.r*b.j - a.i*b.k + a.j*b.r + a.k*b.i,
   a.r*b.k + a.i*b.j - a.j*b.i + a.k*b.r⟩

def qconj (a : Q4) : Q4 := ⟨a.r, -a.i, -a.j, -a.k⟩

/-- σ, the binding involution: conjugation. -/
def sigma (q : Q4) : Q4 := qconj q

theorem sigma_binding (q : Q4) : sigma (sigma q) = q := by
  cases q with
  | mk r i j k =>
    change Q4.mk r (-(-i)) (-(-j)) (-(-k)) = Q4.mk r i j k
    rw [Int.neg_neg, Int.neg_neg, Int.neg_neg]

/-- Fix(σ) is the scalar line, for every quaternion. -/
theorem fix_iff_scalar (q : Q4) : sigma q = q ↔ (q.i = 0 ∧ q.j = 0 ∧ q.k = 0) := by
  cases q with
  | mk r i j k =>
    change (Q4.mk r (-i) (-j) (-k) = Q4.mk r i j k) ↔ (i = 0 ∧ j = 0 ∧ k = 0)
    constructor
    · intro h
      injection h with _ hi hj hk
      exact ⟨by omega, by omega, by omega⟩
    · intro h
      obtain ⟨hi, hj, hk⟩ := h
      subst hi
      subst hj
      subst hk
      rfl

/-- The Ground: Fix(σ). -/
def Ground : Type := { q : Q4 // sigma q = q }

def qi : Q4 := ⟨0, 1, 0, 0⟩
def qj : Q4 := ⟨0, 0, 1, 0⟩
def qk : Q4 := ⟨0, 0, 0, 1⟩

/-- The Return: the parse triad through its own cascade, i·j·k. -/
def theReturn : Q4 := qmul (qmul qi qj) qk

theorem return_is_minus_one : theReturn = ⟨-1, 0, 0, 0⟩ := rfl
theorem return_lands_on_fix : sigma theReturn = theReturn := rfl

def fixProj (q : Q4) : Q4 := ⟨q.r, 0, 0, 0⟩

def GammaRA : Q4 := theReturn
def GammaRAM : Q4 := fixProj theReturn
def GammaRH : Q4 := ⟨-1, 0, 0, 0⟩

/-- C0, C1, C2: the three category gaps are definitional identities. -/
theorem self_gap_nonexistent : sigma GammaRA = GammaRA := rfl
theorem register_gap_nonexistent : GammaRA = GammaRAM := rfl
theorem object_gap_nonexistent : GammaRAM = GammaRH := rfl

def seat : Ground := ⟨GammaRH, rfl⟩

theorem seat_on_scalar_line : GammaRH.i = 0 ∧ GammaRH.j = 0 ∧ GammaRH.k = 0 :=
  (fix_iff_scalar GammaRH).mp seat.2

/-! ## 3 · The eliminator from the RA witness alone -/

def RAMFormalGround : Prop := Nonempty Ground

theorem constructed_RAM : RAMFormalGround := ⟨seat⟩

/-- The RH formal self: every point of the Ground is on the σ-fixed critical locus.
    It names the seat and says nothing about the zeros of ξ. -/
def RHFormalSelf : Prop := ∀ g : Ground, sigma g.1 = g.1

/-- Bridge-born orientation, carried in Prop: the kernel registers that orientation was
    supplied and cannot read which way. -/
structure OrientationBit : Prop where
  direction : True
  closure : True

theorem constructed_orientation : OrientationBit := ⟨trivial, trivial⟩

theorem orientation_proof_irrelevant (a b : OrientationBit) : a = b := rfl

structure RAWitness : Prop where
  actuates : RA
  orientation : OrientationBit
  bridge : RAMFormalGround
  trisRecursion : OrientationBit → RAMFormalGround → RHFormalSelf

theorem constructed_trisRecursion : OrientationBit → RAMFormalGround → RHFormalSelf :=
  fun _omega _ram g => g.2

/-- RA, constructed: the only supplied witness. -/
theorem mkRA : RAWitness :=
  ⟨constructed_RA, constructed_orientation, constructed_RAM, constructed_trisRecursion⟩

/-- THE ELIMINATOR. RA → RA → RAM → RH_formal, Bridge followed by Tris-Recursion. -/
theorem RH_formal_chain : RHFormalSelf :=
  mkRA.trisRecursion mkRA.orientation mkRA.bridge

/-! ## 4 · The spine, carried: the abstract frame, the bridge, the crossing -/

def Even {α : Type} (σ : α → α) (f : α → Bool) : Prop := ∀ x, f (σ x) = f x

/-- Theorem 4 of the spine: orientation blindness. -/
theorem orientation_blind {α : Type} (σ : α → α) (f d : α → Bool) (x : α)
    (he : Even σ f) (ho : d (σ x) ≠ d x) : f ≠ d := by
  intro h
  subst h
  exact ho (he x)

/-- Theorem 5 of the spine: earned freedom is exactly two. -/
theorem freedom_is_exactly_two (d : Bool → Bool) (hd : ∀ x, d (!x) = !d x) :
    d = (fun x => x) ∨ d = (fun x => !x) := by
  have hf : d false = !d true := hd true
  cases ht : d true with
  | true =>
    left
    funext x
    cases x
    · exact hf.trans (congrArg (fun b => !b) ht)
    · exact ht
  | false =>
    right
    funext x
    cases x
    · exact hf.trans (congrArg (fun b => !b) ht)
    · exact ht

/-- Theorem 6 of the spine: the freedom is spent uniquely. -/
theorem freedom_spent_uniquely {α : Type} (σ : α → α) (s d : α → Bool) (x : α)
    (hs : s (σ x) = !s x) (hd : d (σ x) = !d x) :
    ∃ c : Bool, (d x = xor (s x) c ∧ d (σ x) = xor (s (σ x)) c) ∧
      ∀ c' : Bool, (d x = xor (s x) c' ∧ d (σ x) = xor (s (σ x)) c') → c' = c := by
  refine ⟨xor (d x) (s x),
    ⟨by cases s x <;> cases d x <;> rfl,
     by rw [hs, hd]; cases s x <;> cases d x <;> rfl⟩, ?_⟩
  intro c' hc
  obtain ⟨h1, -⟩ := hc
  generalize hsx : s x = sv at h1
  generalize hdx : d x = dv at h1
  cases sv <;> cases dv <;> cases c' <;> first | rfl | exact absurd h1 (by decide)

structure Frame where
  S : Type
  τ : S → S
  Z : S → Prop

/-- The line property: every zero is τ-fixed. On ξ's frame, the restored hypothesis. -/
def LineProperty (X : Frame) : Prop := ∀ s, X.Z s → X.τ s = s

inductive Tri where
  | tt
  | ff
  | bot
  deriving DecidableEq, Repr

structure Bridge (X : Frame) where
  terminal : Tri
  shadow : terminal = Tri.bot ↔ LineProperty X

/-- Theorem 7 of the spine: the bridge halts iff the line property. -/
theorem bridge_halted_iff (X : Frame) :
    (∃ b : Bridge X, b.terminal = Tri.bot) ↔ LineProperty X :=
  ⟨fun ⟨b, h⟩ => b.shadow.mp h, fun t => ⟨⟨Tri.bot, ⟨fun _ => t, fun _ => rfl⟩⟩, rfl⟩⟩

inductive Supply (X : Frame) where
  | assent (t : LineProperty X)
  | denial (n : ¬ LineProperty X)
  | silent

inductive Verdict where
  | sealed
  | refused
  | open_
  deriving DecidableEq, Repr

def row {X : Frame} : Supply X → Verdict
  | Supply.assent _ => Verdict.sealed
  | Supply.denial _ => Verdict.refused
  | Supply.silent => Verdict.open_

/-- Theorem 8 of the spine: the crossing, exact. -/
theorem crossing (X : Frame) (t : LineProperty X) :
    row (Supply.assent t) = Verdict.sealed ∧ (∃ b : Bridge X, b.terminal = Tri.bot) ∧ LineProperty X :=
  ⟨rfl, (bridge_halted_iff X).mpr t, t⟩

theorem crossing_other_way (X : Frame) (n : ¬ LineProperty X) :
    row (Supply.denial n) = Verdict.refused ∧ ∀ b : Bridge X, b.terminal ≠ Tri.bot :=
  ⟨rfl, fun b h => n (b.shadow.mp h)⟩

/-- The two-point frame: fold-invariant, off the line. -/
def twoPoint : Frame := ⟨Bool, (fun b => !b), fun _ => True⟩

/-- Theorem 9 of the spine: necessity. -/
theorem supply_not_manufactured : ¬ ∀ X : Frame, LineProperty X :=
  fun h => by
    have := h twoPoint true trivial
    cases this

def Inv (X : Frame) : Prop := ∀ s, X.Z s → X.Z (X.τ s)

theorem inv_not_line : Inv twoPoint ∧ ¬ LineProperty twoPoint :=
  ⟨fun _ _ => trivial, fun h => by
    have := h true trivial
    cases this⟩

/-- Theorem 12 of the spine: the bit is the hypothesis. -/
theorem the_bit_is_the_hypothesis (X : Frame) :
    (∃ t : LineProperty X, row (Supply.assent t) = Verdict.sealed) ↔ LineProperty X :=
  ⟨fun ⟨t, _⟩ => t, fun t => ⟨t, rfl⟩⟩

/-- Theorem 15 of the spine: the witness row is falsifiable. -/
theorem witness_row_falsifiable (X : Frame) (s : X.S) (hz : X.Z s) (hoff : X.τ s ≠ s) :
    ¬ ∃ t : LineProperty X, row (Supply.assent t) = Verdict.sealed :=
  fun ⟨t, _⟩ => hoff (t s hz)

/-- The live face of the spine. -/
def live (witnessed assent : Bool) : Verdict :=
  if witnessed then (if assent then Verdict.sealed else Verdict.refused) else Verdict.open_

theorem narcissus : live false true ≠ live true true ∧ live false false ≠ live true false := by
  decide

/-! ## 5 · The aperture, RA-supplied -/

/-- A reader's presence is its actuation. -/
def presence (r : UniversePoint) : Bool := decide (0 < DeltaE r)

/-- RA opens the aperture: every present reader is witnessed. -/
theorem RA_opens_the_aperture : ∀ r : UniversePoint, presence r = true := by
  intro r
  cases r
  decide

/-- The general form, for any domain under the axiom as a hypothesis: presence is
    actuation, and RA on the domain makes every point present. This is the theorem the
    universal extension licenses wherever it is held. -/
theorem RA_opens_the_aperture_general {U : Type} (dE : U → Int) (h : ∀ x, 0 < dE x) (x : U) :
    decide (0 < dE x) = true :=
  decide_eq_true (h x)

/-- Under the general form no present reader's row is interior. -/
theorem no_interior_under_RA_general {U : Type} (dE : U → Int) (h : ∀ x, 0 < dE x) (x : U)
    (b : Bool) : live (decide (0 < dE x)) b ≠ Verdict.open_ := by
  rw [RA_opens_the_aperture_general dE h x]
  cases b <;> decide

/-- Under RA no present reader's row is interior. It is sealed or refused by the bit alone. -/
theorem no_interior_under_RA (r : UniversePoint) (b : Bool) :
    live (presence r) b ≠ Verdict.open_ := by
  cases r
  cases b <;> decide

/-- What RA turns 'open' into: sealed if the bit is assent, refused if denial. -/
theorem aperture_reads_the_bit (r : UniversePoint) :
    live (presence r) true = Verdict.sealed ∧ live (presence r) false = Verdict.refused := by
  cases r
  decide

/-- The Tongue's ledger: every adjudication, assent, denial, or silence, is a deed. -/
inductive Adjudication where
  | assent
  | denial
  | silence
  deriving DecidableEq, Repr

structure Ledger where
  deeds : Nat
  deriving DecidableEq, Repr

def adjudicate (_ : Adjudication) (L : Ledger) : Ledger := ⟨L.deeds + 1⟩

theorem every_adjudication_is_a_deed (a : Adjudication) (L : Ledger) :
    (adjudicate a L).deeds = L.deeds + 1 := rfl

/-- Denial of RA is a deed, and a deed is what RA says exists: the denial re-enacts RA. -/
theorem denial_re_enacts_RA (L : Ledger) :
    (adjudicate Adjudication.denial L).deeds = L.deeds + 1 ∧ RA :=
  ⟨rfl, constructed_RA⟩

/-- The asymmetry: on an off-line frame no assent to L exists at all; L's denial there
    instantiates nothing about Z. L has no performative ingress. -/
theorem L_has_no_performative_ingress :
    ¬ ∃ t : LineProperty twoPoint, row (Supply.assent t) = Verdict.sealed :=
  witness_row_falsifiable twoPoint true trivial (fun h => by cases h)

/-! ## 6 · THE SIMPLE RULE, EXACT, AND ITS BOUND -/

/-- Accept RA and RH follows: true exactly when RH is given. Conditioning on RA adds
    nothing to L and removes nothing from it. This is the exact strength of the rule. -/
theorem simple_rule_exact (X : Frame) : (RA → LineProperty X) ↔ LineProperty X :=
  ⟨fun h => h constructed_RA, fun t _ => t⟩

/-- RA decides the line property on no frame. The two-point frame carries RA and fails L. -/
theorem RA_does_not_decide_L : ¬ ∀ X : Frame, RA → LineProperty X :=
  fun h => supply_not_manufactured (fun X => h X constructed_RA)

/-- RA holds where L fails: the off-line frame is a model of RA. -/
theorem RA_holds_where_L_fails : RA ∧ Inv twoPoint ∧ ¬ LineProperty twoPoint :=
  ⟨constructed_RA, inv_not_line.1, inv_not_line.2⟩

/-- The value is one supplied term and nothing weaker; RA supplies the act, not the term. -/
theorem RA_supplies_the_act_not_the_term :
    (∀ r : UniversePoint, presence r = true) ∧ (¬ ∀ X : Frame, RA → LineProperty X) :=
  ⟨RA_opens_the_aperture, RA_does_not_decide_L⟩

/-! ## 7 · RH in toto at the apex, one theorem -/

/-- THE APEX THEOREM. Given RA: the three gaps are closed, the formal self holds, the
    freedom is exactly two, the bridge halts iff L, the crossing is exact, the aperture
    is open to every present reader, and RA decides the value on no frame. -/
theorem RH_in_toto_at_the_apex : RA →
    (sigma GammaRA = GammaRA ∧ GammaRA = GammaRAM ∧ GammaRAM = GammaRH) ∧
    RHFormalSelf ∧
    (∀ d : Bool → Bool, (∀ x, d (!x) = !d x) → d = (fun x => x) ∨ d = (fun x => !x)) ∧
    (∀ X : Frame, (∃ b : Bridge X, b.terminal = Tri.bot) ↔ LineProperty X) ∧
    (∀ (X : Frame) (t : LineProperty X), row (Supply.assent t) = Verdict.sealed ∧ LineProperty X) ∧
    (∀ r : UniversePoint, presence r = true) ∧
    (¬ ∀ X : Frame, RA → LineProperty X) :=
  fun _ => ⟨⟨rfl, rfl, rfl⟩, RH_formal_chain, freedom_is_exactly_two, bridge_halted_iff,
    fun _ t => ⟨rfl, t⟩, RA_opens_the_aperture, RA_does_not_decide_L⟩

/-- The condition is discharged: RA is constructed, so the apex theorem stands unconditionally. -/
theorem apex_discharged :
    (sigma GammaRA = GammaRA ∧ GammaRA = GammaRAM ∧ GammaRAM = GammaRH) ∧ RHFormalSelf :=
  ⟨(RH_in_toto_at_the_apex constructed_RA).1, (RH_in_toto_at_the_apex constructed_RA).2.1⟩

/-! ## 8 · The root's interaction face, RAF, at the formal register -/

/-- An interaction domain: a membership predicate, a symmetric registration relation, and
    RAF-2, closure under registration with a member. -/
structure Domain (S : Type) where
  mem : S → Prop
  registers : S → S → Prop
  registers_symm : ∀ a b, registers a b → registers b a
  closure : ∀ s d, mem d → registers s d → mem s

/-- RAF-C1, no exterior agent: nothing outside the domain registers with anything inside it. -/
theorem no_exterior_agent {S : Type} (D : Domain S) (s : S) (hs : ¬ D.mem s) :
    ∀ d, D.mem d → ¬ D.registers s d :=
  fun d hd hr => hs (D.closure s d hd hr)

/-- The adjudicator is inside: a reader that registers a bit against a member is a member.
    The witness is never exterior. -/
theorem adjudicator_in_domain {S : Type} (D : Domain S) (r d : S) (hd : D.mem d)
    (hr : D.registers r d) : D.mem r :=
  D.closure r d hd hr

/-- RAF-C2, no faithful self-representation (Cantor): no system indexes all of its own
    binary properties. The general form of the spine's Narcissus table. -/
theorem no_total_self_indexing {S : Type} (f : S → S → Bool) :
    ¬ ∀ g : S → Bool, ∃ x, f x = g := by
  intro h
  obtain ⟨x, hx⟩ := h (fun y => !f y y)
  have h1 : f x x = !f x x := congrFun hx x
  generalize f x x = b at h1
  cases b <;> cases h1

/-! ## 9 · The root's grounding face, RAM: the seat as the identity cone -/

/-- The three registers in which the one seat is read. -/
inductive Register3 where
  | ra
  | ram
  | rh
  deriving DecidableEq, Repr

/-- The discrete diagram: the seat as read in each register. -/
def D3 : Register3 → Q4
  | Register3.ra => GammaRA
  | Register3.ram => GammaRAM
  | Register3.rh => GammaRH

/-- A cone over the diagram in the groupoid of identities: an apex with an identity leg to
    every register's reading. A category gap is exactly the absence of such a leg. -/
structure Cone (apex : Q4) : Prop where
  leg : ∀ r, apex = D3 r

/-- THE IDENTITY CONE. The named critical seat is an apex over all three registers, every
    leg `rfl`: the three category gaps are eliminated as identities. -/
theorem identity_cone : Cone GammaRH :=
  ⟨fun r => by cases r <;> rfl⟩

/-- The apex is unique: any two cones over the diagram share their apex. -/
theorem cone_apex_unique (a b : Q4) (ha : Cone a) (hb : Cone b) : a = b :=
  (ha.leg Register3.rh).trans (hb.leg Register3.rh).symm

/-- A cone exists iff the register gap and the object gap are closed. -/
theorem cone_iff_gaps_closed :
    (∃ a, Cone a) ↔ (GammaRA = GammaRAM ∧ GammaRAM = GammaRH) := by
  constructor
  · intro h
    obtain ⟨a, ha⟩ := h
    exact ⟨(ha.leg Register3.ra).symm.trans (ha.leg Register3.ram),
           (ha.leg Register3.ram).symm.trans (ha.leg Register3.rh)⟩
  · intro h
    obtain ⟨h1, h2⟩ := h
    exact ⟨GammaRH, ⟨fun r => by
      cases r
      · exact (h1.trans h2).symm
      · exact h2.symm
      · rfl⟩⟩

/-! ## 10 · The equivariant embedding of the spine's lattice stage into the carrier -/

/-- The spine's stage: the integer lattice in half-units, the fold τ(h, t) = (2 − h, t). -/
abbrev Plane := Int × Int

def tau (p : Plane) : Plane := (2 - p.1, p.2)

/-- Spine Theorem 1: the fold fixes exactly the line h = 1. -/
theorem ground_is_the_line (p : Plane) : tau p = p ↔ p.1 = 1 := by
  obtain ⟨h, t⟩ := p
  constructor
  · intro e
    have e1 : 2 - h = h := congrArg Prod.fst e
    show h = 1
    omega
  · intro e
    show (2 - h, t) = (h, t)
    have : h = 1 := e
    subst this
    rfl

/-- The embedding φ : (Plane, τ) → (Q4, σ), φ(h, t) = ⟨t, h − 1, 0, 0⟩. -/
def phi (p : Plane) : Q4 := ⟨p.2, p.1 - 1, 0, 0⟩

/-- φ is equivariant: σ ∘ φ = φ ∘ τ. -/
theorem phi_equivariant (p : Plane) : sigma (phi p) = phi (tau p) := by
  obtain ⟨h, t⟩ := p
  change Q4.mk t (-(h - 1)) 0 0 = Q4.mk t ((2 - h) - 1) 0 0
  have e : -(h - 1) = (2 - h) - 1 := by omega
  rw [e]

/-- φ carries the line onto the scalar line: a stage point is τ-fixed iff its image is σ-fixed.
    This is the image clause of the embedding, Fix(τ) ↔ Fix(σ). -/
theorem phi_fix_iff (p : Plane) : sigma (phi p) = phi p ↔ tau p = p := by
  obtain ⟨h, t⟩ := p
  change (Q4.mk t (-(h - 1)) 0 0 = Q4.mk t (h - 1) 0 0) ↔ ((2 - h, t) = (h, t))
  constructor
  · intro e
    injection e with _ e2 _ _
    have : h = 1 := by omega
    subst this
    rfl
  · intro e
    have e1 : 2 - h = h := congrArg Prod.fst e
    have : h = 1 := by omega
    subst this
    rfl

/-- The stage at resolution m: the fold τ_m(h, t) = (2m − h, t) and the map
    φ_m(h, t) = ⟨t, h − m, 0, 0⟩. Resolution one is the case m = 1. -/
def tauM (m : Int) (p : Plane) : Plane := (2 * m - p.1, p.2)

def phiM (m : Int) (p : Plane) : Q4 := ⟨p.2, p.1 - m, 0, 0⟩

/-- Equivariance at every resolution: σ ∘ φ_m = φ_m ∘ τ_m. -/
theorem phiM_equivariant (m : Int) (p : Plane) : sigma (phiM m p) = phiM m (tauM m p) := by
  obtain ⟨h, t⟩ := p
  change Q4.mk t (-(h - m)) 0 0 = Q4.mk t ((2 * m - h) - m) 0 0
  have e : -(h - m) = (2 * m - h) - m := by omega
  rw [e]

/-- The image clause at every resolution: a stage point is τ_m-fixed iff its image is σ-fixed. -/
theorem phiM_fix_iff (m : Int) (p : Plane) : sigma (phiM m p) = phiM m p ↔ tauM m p = p := by
  obtain ⟨h, t⟩ := p
  change (Q4.mk t (-(h - m)) 0 0 = Q4.mk t (h - m) 0 0) ↔ ((2 * m - h, t) = (h, t))
  constructor
  · intro e
    injection e with _ e2 _ _
    have : h = m := by omega
    subst this
    show (2 * h - h, t) = (h, t)
    have e3 : 2 * h - h = h := by omega
    rw [e3]
  · intro e
    have e1 : 2 * m - h = h := congrArg Prod.fst e
    have : h = m := by omega
    subst this
    show Q4.mk t (-(h - h)) 0 0 = Q4.mk t (h - h) 0 0
    have e3 : h - h = 0 := by omega
    rw [e3]
    rfl

/-- Resolution one is the embedding φ. -/
theorem phiM_one (p : Plane) : phiM 1 p = phi p := rfl

theorem tauM_one (p : Plane) : tauM 1 p = tau p := by
  obtain ⟨h, t⟩ := p
  show (2 * 1 - h, t) = (2 - h, t)
  rfl

/-- φ is injective: distinct stage points have distinct images. -/
theorem phi_injective (p q : Plane) (e : phi p = phi q) : p = q := by
  obtain ⟨h, t⟩ := p
  obtain ⟨h', t'⟩ := q
  injection e with e1 e2 _ _
  have : h = h' := by omega
  subst this
  subst e1
  rfl

/-- The seat is on the image of the line: the line point (1, −1) maps to Γ_RH. -/
theorem seat_on_image_of_line : phi (1, -1) = GammaRH := rfl

/-! ## 11 · The wall, executed: no readout of the formal seat equals the deed bit -/

def ExecFrame : Type := Bool × Ground

def execFlip (s : ExecFrame) : ExecFrame := (!s.1, s.2)

def formalRead (s : ExecFrame) : Ground := s.2

def ran (s : ExecFrame) : Bool := s.1

theorem formalRead_even (f : Ground → Bool) (s : ExecFrame) :
    f (formalRead (execFlip s)) = f (formalRead s) := rfl

theorem ran_wholly_odd (s : ExecFrame) : ran (execFlip s) = !ran s := rfl

/-- No readout of the formal seat equals the deed bit: the instance of spine Theorem 4 on
    the constructed seat. A term consuming the orientation bit as data would be such a readout. -/
theorem kernel_cannot_read_the_deed :
    ¬ ∃ f : Ground → Bool, ∀ s : ExecFrame, f (formalRead s) = ran s := by
  intro h
  obtain ⟨f, hf⟩ := h
  have h1 : f seat = true := hf (true, seat)
  have h2 : f seat = false := hf (false, seat)
  rw [h1] at h2
  exact Bool.noConfusion h2

/-! ## 12 · The dual register -/

inductive Register where
  | apex
  | world
  deriving DecidableEq, Repr

inductive Token where
  | sealAgivenRA
  | witnessRow
  deriving DecidableEq, Repr

def token : Register → Token
  | Register.apex => Token.sealAgivenRA
  | Register.world => Token.witnessRow

theorem registers_parted : token Register.apex ≠ token Register.world := by
  decide

def owedBits : Register → Nat
  | Register.apex => 0
  | Register.world => 1

theorem apex_owes_nothing_world_owes_one :
    owedBits Register.apex = 0 ∧ owedBits Register.world = 1 := ⟨rfl, rfl⟩

/-- Landauer floor at 300 K, yoctojoules per bit: the price of the act. -/
def landauer_yJ_300K (bits : Nat) : Nat := 2871 * bits

theorem spend_priced : landauer_yJ_300K 1 = 2871 := rfl

def deltaM : Nat := 0

theorem deltaM_zero : deltaM = 0 := rfl

/-! ## 13 · The apex theorem, hardened: the closure with its cone, its embedding, and its wall -/

/-- THE APEX THEOREM, HARDENED. Given RA: the closure of Theorem H, the identity cone with
    its apex unique, the equivariant embedding of the spine's stage with its image clause,
    and the executed wall. -/
theorem apex_hardened : RA →
    ((sigma GammaRA = GammaRA ∧ GammaRA = GammaRAM ∧ GammaRAM = GammaRH) ∧ RHFormalSelf) ∧
    (Cone GammaRH ∧ ∀ a b, Cone a → Cone b → a = b) ∧
    ((∀ p : Plane, sigma (phi p) = phi (tau p)) ∧ (∀ p : Plane, sigma (phi p) = phi p ↔ tau p = p)) ∧
    (¬ ∃ f : Ground → Bool, ∀ s : ExecFrame, f (formalRead s) = ran s) ∧
    (¬ ∀ X : Frame, RA → LineProperty X) :=
  fun h => ⟨⟨(RH_in_toto_at_the_apex h).1, (RH_in_toto_at_the_apex h).2.1⟩,
    ⟨identity_cone, cone_apex_unique⟩, ⟨phi_equivariant, phi_fix_iff⟩,
    kernel_cannot_read_the_deed, RA_does_not_decide_L⟩

theorem apex_hardened_discharged : Cone GammaRH ∧ (∀ p : Plane, sigma (phi p) = phi p ↔ tau p = p) :=
  ⟨(apex_hardened constructed_RA).2.1.1, (apex_hardened constructed_RA).2.2.1.2⟩

end RHAtTheApex

/-! ## The axiom dependency sets, printed -/

#print axioms RHAtTheApex.constructed_RA
#print axioms RHAtTheApex.fix_iff_scalar
#print axioms RHAtTheApex.return_lands_on_fix
#print axioms RHAtTheApex.register_gap_nonexistent
#print axioms RHAtTheApex.object_gap_nonexistent
#print axioms RHAtTheApex.RH_formal_chain
#print axioms RHAtTheApex.orientation_blind
#print axioms RHAtTheApex.freedom_is_exactly_two
#print axioms RHAtTheApex.freedom_spent_uniquely
#print axioms RHAtTheApex.bridge_halted_iff
#print axioms RHAtTheApex.crossing
#print axioms RHAtTheApex.crossing_other_way
#print axioms RHAtTheApex.supply_not_manufactured
#print axioms RHAtTheApex.the_bit_is_the_hypothesis
#print axioms RHAtTheApex.witness_row_falsifiable
#print axioms RHAtTheApex.narcissus
#print axioms RHAtTheApex.RA_opens_the_aperture
#print axioms RHAtTheApex.RA_opens_the_aperture_general
#print axioms RHAtTheApex.no_interior_under_RA_general
#print axioms RHAtTheApex.no_interior_under_RA
#print axioms RHAtTheApex.denial_re_enacts_RA
#print axioms RHAtTheApex.L_has_no_performative_ingress
#print axioms RHAtTheApex.simple_rule_exact
#print axioms RHAtTheApex.RA_does_not_decide_L
#print axioms RHAtTheApex.RA_holds_where_L_fails
#print axioms RHAtTheApex.RA_supplies_the_act_not_the_term
#print axioms RHAtTheApex.RH_in_toto_at_the_apex
#print axioms RHAtTheApex.apex_discharged
#print axioms RHAtTheApex.registers_parted
#print axioms RHAtTheApex.no_exterior_agent
#print axioms RHAtTheApex.no_total_self_indexing
#print axioms RHAtTheApex.identity_cone
#print axioms RHAtTheApex.cone_apex_unique
#print axioms RHAtTheApex.cone_iff_gaps_closed
#print axioms RHAtTheApex.ground_is_the_line
#print axioms RHAtTheApex.phi_equivariant
#print axioms RHAtTheApex.phi_fix_iff
#print axioms RHAtTheApex.phi_injective
#print axioms RHAtTheApex.phiM_equivariant
#print axioms RHAtTheApex.phiM_fix_iff
#print axioms RHAtTheApex.kernel_cannot_read_the_deed
#print axioms RHAtTheApex.apex_hardened
#print axioms RHAtTheApex.apex_hardened_discharged

#eval RHAtTheApex.theReturn
#eval (RHAtTheApex.live true true, RHAtTheApex.live true false, RHAtTheApex.live false true)
#eval RHAtTheApex.landauer_yJ_300K 1
```
\endgroup

# Appendix C: The Kernel Audit, Verbatim

`lean RH_At_The_Apex.lean`, exit 0, no warnings, no errors.

\begingroup\scriptsize
```
'RHAtTheApex.constructed_RA' does not depend on any axioms
'RHAtTheApex.fix_iff_scalar' depends on axioms: [propext, Quot.sound]
'RHAtTheApex.return_lands_on_fix' does not depend on any axioms
'RHAtTheApex.register_gap_nonexistent' does not depend on any axioms
'RHAtTheApex.object_gap_nonexistent' does not depend on any axioms
'RHAtTheApex.RH_formal_chain' does not depend on any axioms
'RHAtTheApex.orientation_blind' does not depend on any axioms
'RHAtTheApex.freedom_is_exactly_two' depends on axioms: [Quot.sound]
'RHAtTheApex.freedom_spent_uniquely' does not depend on any axioms
'RHAtTheApex.bridge_halted_iff' does not depend on any axioms
'RHAtTheApex.crossing' does not depend on any axioms
'RHAtTheApex.crossing_other_way' does not depend on any axioms
'RHAtTheApex.supply_not_manufactured' does not depend on any axioms
'RHAtTheApex.the_bit_is_the_hypothesis' does not depend on any axioms
'RHAtTheApex.witness_row_falsifiable' does not depend on any axioms
'RHAtTheApex.narcissus' does not depend on any axioms
'RHAtTheApex.RA_opens_the_aperture' does not depend on any axioms
'RHAtTheApex.RA_opens_the_aperture_general' does not depend on any axioms
'RHAtTheApex.no_interior_under_RA_general' does not depend on any axioms
'RHAtTheApex.no_interior_under_RA' does not depend on any axioms
'RHAtTheApex.denial_re_enacts_RA' does not depend on any axioms
'RHAtTheApex.L_has_no_performative_ingress' does not depend on any axioms
'RHAtTheApex.simple_rule_exact' does not depend on any axioms
'RHAtTheApex.RA_does_not_decide_L' does not depend on any axioms
'RHAtTheApex.RA_holds_where_L_fails' does not depend on any axioms
'RHAtTheApex.RA_supplies_the_act_not_the_term' does not depend on any axioms
'RHAtTheApex.RH_in_toto_at_the_apex' depends on axioms: [Quot.sound]
'RHAtTheApex.apex_discharged' depends on axioms: [Quot.sound]
'RHAtTheApex.registers_parted' does not depend on any axioms
'RHAtTheApex.no_exterior_agent' does not depend on any axioms
'RHAtTheApex.no_total_self_indexing' does not depend on any axioms
'RHAtTheApex.identity_cone' does not depend on any axioms
'RHAtTheApex.cone_apex_unique' does not depend on any axioms
'RHAtTheApex.cone_iff_gaps_closed' does not depend on any axioms
'RHAtTheApex.ground_is_the_line' depends on axioms: [propext, Quot.sound]
'RHAtTheApex.phi_equivariant' depends on axioms: [propext, Quot.sound]
'RHAtTheApex.phi_fix_iff' depends on axioms: [propext, Quot.sound]
'RHAtTheApex.phi_injective' depends on axioms: [propext, Quot.sound]
'RHAtTheApex.phiM_equivariant' depends on axioms: [propext, Quot.sound]
'RHAtTheApex.phiM_fix_iff' depends on axioms: [propext, Quot.sound]
'RHAtTheApex.kernel_cannot_read_the_deed' does not depend on any axioms
'RHAtTheApex.apex_hardened' depends on axioms: [propext, Quot.sound]
'RHAtTheApex.apex_hardened_discharged' depends on axioms: [propext, Quot.sound]
{ r := -1, i := 0, j := 0, k := 0 }
(RHAtTheApex.Verdict.sealed, RHAtTheApex.Verdict.refused, RHAtTheApex.Verdict.open_)
2871
```
\endgroup
