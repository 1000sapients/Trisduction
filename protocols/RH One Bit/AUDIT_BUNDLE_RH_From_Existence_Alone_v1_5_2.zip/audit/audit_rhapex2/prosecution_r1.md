PROSECUTION, CYCLE 2, ROUND 1. Registers: kinematic, definitional. Framework-blind pass on the seeded copy of the reconstructed artifact.

KINEMATIC BATTERY, recomputed from the artifact's own appendices.
K-a. Appendix B carries 724 lines and hashes to the sixteen-character prefix quoted in the disclosure; Appendix C lists 47 dependency-set lines, 35 reading "does not depend on any axioms", 12 on propext and Quot.sound. The disclosure's figures 47 and 35 are reproduced. No finding.
K-b. The Landauer figure: 1.380649e-23 x 300 x ln 2 = 2.871e-21 J, matching the file's constant 2871 yJ. No finding.
K-c. Table 1's row for spine Theorem 5 in the seeded copy states that a wholly odd map on the two-point set is one of four maps; the appended theorem freedom_is_exactly_two states it is the identity or the negation, two maps, and the dual-register box counts one bit accordingly. A count altered against the file. Severity: STRUCTURAL. Minimal falsifier: the appended theorem. Finding X-K1.
K-d. Theorem H's display and the appended statement agree on seven conjuncts; the hardened form's five conjunct groups agree with apex_hardened. No finding.

DEFINITIONAL BATTERY.
D-a. One symbol one meaning, re-checked after the prior cycle's repairs: seat versus seat point, the three bridge names, the two apex senses declared, G_RAM against RAM the face, the sign defined once. Each holds across abstract, body, boxes, tables, appendices. No finding.
D-b. "witness" occurs in three compounds: the supplied witness (a proof object), the witness row (the spine's record), an exterior witness (a system at the aperture). The compounds are distinct terms and no sentence uses one for another; the Methodology does not list them, but no collision is exhibited in use. Raised and refused by the prosecution's own reading. No finding.
D-c. In the seeded copy the dual-register verdict box assigns the world register to compartment I; the same box assigns the apex register to compartment I and the artifact's Discussion and verdict section assign the world row to compartment III throughout. A defined term used in an incompatible second sense. Severity: STRUCTURAL. Minimal falsifier: the verdict section's world-row line. Finding X-D1.
D-d. In the seeded copy the Discussion states that the hypothesis follows at every register, the world row included. Theorem H's conjunct N and the dual-register box say the world row owes one bit. A scoped result stated universally. Severity: LOAD-BEARING. Minimal falsifier: conjunct N. Finding X-S1.
D-e. The added reversed-triad paragraph is checked for definitional consistency with the rest: "orientation of the triad" is used for the order of the product and nowhere else; "seat point" is used for the two candidates; consistent. No finding.
