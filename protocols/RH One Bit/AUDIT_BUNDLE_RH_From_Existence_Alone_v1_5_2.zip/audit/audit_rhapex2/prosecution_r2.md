PROSECUTION, CYCLE 2, ROUND 2. Registers: parameter, provenance. Framework-blind pass on the seeded copy.

PARAMETER BATTERY.
P-a. Free-choice census unchanged from the prior cycle's record: carrier, involution, triad order, the map family, the one-point domain, the demonstration temperature, the three-object diagram; predictions about the zeros claimed: none; the world-row criterion inherited. The triad order is now declared as the one orientation choice and both orientations are carried. No mismatch statable. No finding.
P-b. In the seeded copy the positioning paragraph states that three positions are superseded, while the positioning table beneath it lists no row with the word superseded and the paragraph's own second clause says none is contradicted. A count altered against the artifact's own table. Severity: STRUCTURAL. Minimal falsifier: the table. Finding X-P1.
P-c. Falsifiability demarcation, re-read after the prior cycle's refusal: F1 world row, F2 and F3 kernel record checks, each typed so in the text. The demarcation is stated; the prosecution has no new mechanism. No finding.
P-d. In the seeded copy the faces section states the model is the universal extension. The artifact's next sentences grade the extension premise and say the theorems are discharged against the model and stated conditionally against the extension; a premise read as theorem. Severity: LOAD-BEARING. Minimal falsifier: the grade sentence that follows. Finding X-S2.

PROVENANCE BATTERY.
V-a. Closed authorship and in-session controls: unchanged; no in-session repair exists; the witness is an independent recompile on a second substrate with an architect-authored control set. Severity: STRUCTURAL. Finding F-1 (aperture).
V-b. Unarchived spine and rows citations: unchanged; kernel content re-proved in-file; vindication by citation; the witness is an archival identifier. Severity: STRUCTURAL. Finding F-2 (aperture).
V-c. In the seeded copy the spine-carried section adds that later sections write L(X) for the statement that Z is nonempty. The artifact's L(X) is the line property everywhere it is used, and the two-point frame's L fails on a nonempty Z, so the added sense contradicts Theorem F's proof. A defined term used in an incompatible second sense. Severity: STRUCTURAL. Minimal falsifier: Theorem F's proof. Finding X-D2.
V-d. Circularity and declared-method checks: unchanged from the prior cycle's clean reading. No finding.
