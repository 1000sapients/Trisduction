# Prosecution, round 1: registers kinematic and definitional

Artifact prosecuted: `rh_v8_seeded_r1.md`, the candidate `rh_v8_candidate.md` with this round's committed controls planted. Grade SELF: the auditor and the author are one substrate, and the controls were located by comparing the seeded artifact with the candidate it was seeded from.

## Checks executed

Kinematic register. The kernel on disk has sha256 f50954f48fef41c2, the digest of the date line: yes; the listing of Appendix A equals it byte for byte: yes; live compile under Lean 4.19.0: exit 0, 231 cones printed, every pin held: yes. Table B.4 recomputed from the source by dependency closure: the 10 rows equal the table's 10 rows, counts included: yes; the closure of each of the 15 verdict roots contains no cited structure: yes.

Definitional register. Theorem 15.5 is the closure on any carrier (yes) and Theorem 15.9 the socket in the open strip (yes), as the paragraph cites them. The paragraph says the verdict theorems are stated over an arbitrary type; read against the source, 12 of the 15 verdict roots are stated on the chart's own types (least_erasure_is_the_value, rh_from_the_act, record_decides_nothing, keyless_forces_nothing, no_coalition_decides, rh_is_the_weakest_forcing_premise, and others), and only the closure of Theorem 15.5 is stated over an arbitrary carrier: finding F-1.

## Planted anomalies located

- line 57, under "## 1. The claim, stated whole": scope anomaly; removed '', inserted 'The same equivalence holds for the zero set of zeta itself, with no identification. '
- line 136, under "## 4. Irreducibility, at theorem grade": drift anomaly; removed '', inserted 'Here least erasure means that the record has no point off the line. '
- line 304, under "## 12. Weil positivity on the prime side, and the five faces": arith anomaly; removed '8', inserted '9'

## Findings

- F-1 [definitional] EARNED STRUCTURAL claim C8: the paragraph closing Section 16 says the verdict theorems are stated over an arbitrary type; most verdict roots are stated on the chart types, and only the closure of Theorem 15.5 is stated over an arbitrary carrier; repaired by exact replacement of the sentence
