# Prosecution, round 2: registers parameter and provenance

Artifact prosecuted: `rh_v8_seeded_r2.md`, the candidate `rh_v8_post1.md` with this round's committed controls planted. Grade SELF: the auditor and the author are one substrate, and the controls were located by comparing the seeded artifact with the candidate it was seeded from.

## Checks executed

Parameter register. Counts outside the listing, the receipts' lists and the history cards: 20, every one a count of kernel 3.1.1 or a section of it: yes; the counts of Table B.4 are those recomputed in round 1; the digest of the date line and the certificate of Appendix E is that of the unchanged kernel: yes.

Provenance register. Citations read both ways: 31 author-year citations, each with its entry and every entry cited: yes; the added text introduces no citation. History: C.4 heading yes; Appendix D names the fourth cycle and C.4 yes; certificate of edition 3.1.2 yes.

## Planted anomalies located

- line 160, under "## 5. The chart of the critical line, and the one cut": drift anomaly; removed '', inserted 'Here least erasure means that the record has no point off the line. '
- line 419, under "## 15. The four-face template, and the identity is not the l": arith anomaly; removed '', inserted 'That is two and two, five in all. '
- line 491, under "## 18. Falsifiers": scope anomaly; removed '', inserted 'The same equivalence holds for the zero set of zeta itself, with no identification. '

## Findings

- none
