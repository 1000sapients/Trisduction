# Prosecution, round 3: registers limit and symmetry

Artifact prosecuted: `rh_v8_seeded_r3.md`, the candidate `rh_v8_post1.md` with this round's committed controls planted. Grade SELF: the auditor and the author are one substrate, and the controls were located by comparing the seeded artifact with the candidate it was seeded from.

## Checks executed

Limit register. The paragraph states its own limits: the one fact about the object the verdict addresses, fold-closure from the functional equation yes; the vacuity of resolution one yes; the cone on a carrier where the line is not decidable, checked by compiling the operating system's classical form, whose printed cone is [propext, Classical.choice, Quot.sound]: yes; no sentence says a face is derived: yes.

Symmetry register. What stands without the faces and what is lost with them are both stated: yes; the faces are live, not decoration: 10 of the 10 structures are taken by at least one theorem, yes; the object fact is addressed to the object and never to the foundation: yes; after the repair of F-1 the carrier sentence names the closure alone as generic and the rest as chart-stated: yes.

## Planted anomalies located

- line 73, under "## 2. The foundation placed: what a set-theoretic base can a": scope anomaly; removed '', inserted 'The same equivalence holds for the zero set of zeta itself, with no identification. '
- line 256, under "## 10. Least erasure is the value; the mirror at eigenvalue ": drift anomaly; removed '', inserted 'Here least erasure means that the record has no point off the line. '
- line 447, under "## 16. The grade of the closure, stated whole": arith anomaly; removed '', inserted 'That is two and two, five in all. '

## Findings

- none
