import re, sys, json, hashlib, subprocess, shlex, cyc33, rounds33, checkall
KF='/home/claude/kernel/v4/Every_Prime_3_1_1.lean'; K=open(KF).read(); SHA=hashlib.sha256(open(KF,'rb').read()).hexdigest()
body=K[:K.index('end PrimeFreedom')]
dl=[(m.start(),m.group(2)) for m in re.finditer(r'(?m)^(?:@\[[^\]]*\]\s*)?(?:noncomputable\s+)?(theorem|def|structure|abbrev|inductive|instance|class)\s+([^\s(:{\[]+)',body)]
D={n.split('.')[-1]:body[s:(dl[i+1][0] if i+1<len(dl) else len(body))] for i,(s,n) in enumerate(dl)}
ref={n:set(re.findall(r'[A-Za-z_][\w₂.]*',t))&set(D) for n,t in D.items()}
def clo(r):
    S,q=set(),[r]
    while q:
        x=q.pop()
        if x not in S: S.add(x); q+=list(ref.get(x,()))
    return S
def sh(c): return subprocess.run(c,shell=True,capture_output=True,text=True).stdout.strip()
P=open('rh_final_312.md').read()
i=P.index('### C.4'); j=P.index('## Appendix D.')
P=P[:i]+'### C.4 The closing card of the fourth audit cycle, on edition 3.1.2\n\nCARD-PENDING\n\n'+P[j:]
P=P.replace('edition 3.1.2, the present text, adds text only, recorded in C.4.','edition 3.1.2, the present text, adds text only and passed a fourth, short cycle on it, whose closing card is C.4.',1)
open('rh_v8_candidate.md','w').write(P)
F=json.load(open('audit_ep32/cycle.json'))['falsifiers']
F['C8']="a verdict root of B.4 whose dependency closure over the kernel source contains a cited structure, or a sentence of the paragraph closing Section 16 that no theorem of the kernel or of the operating system backs"
print(sh('python3 audit_ledger.py init --cycle ep33 --artifact rh_v8_candidate.md --claims C1,C2,C3,C4,C5,C6,C7,C8').split('\n')[0][:90])
for c in sorted(F): sh(f'python3 audit_ledger.py falsifier --cycle ep33 --claim {c} --text {shlex.quote(F[c])}')
def rows(P):
    B4=P[P.index('### B.4'):P.index('## Appendix C.')]; return re.findall(r'\| `(\w+)` \| (\d+) \| none \|',B4), re.findall(r'`(\w+)`',B4[:B4.index('| Structure')])
def para(P): i=P.index('*What is derived, and what is addressed to the object.*'); return P[i:P.index('## 17.',i)]
def rnd(n,regs,base,post,findings,checks):
    print(cyc33.commit(n,330100+n)); pl=cyc33.plan(n); rounds33.plant(base,f'rh_v8_seeded_r{n}.md',pl)
    det,caught=cyc33.run(n,regs,base,f'rh_v8_seeded_r{n}.md',post,findings,checks,None)
    print('round',n,'caught',caught)
anom=[]
def need(l,ok):
    if not ok: anom.append(l)
    return 'yes' if ok else 'NO'
# ROUND 1 · kinematic, definitional
P=open('rh_v8_candidate.md').read(); A=P[P.index('## Appendix A.'):]; f0=A.index('```'); f1=A.index('\n```\n',f0+3)
r=subprocess.run(['/home/claude/physos/.toolchain/lean-4.19.0-linux/bin/lean',KF],capture_output=True,text=True,timeout=900); pr=[l for l in r.stdout.split('\n') if l.startswith("'")]
cit=['ConjSymmetry','Faces','ExplicitFormula','PrimeAct','LiStream','DBN','LiouvilleFace','LiouvilleFacePinned','SocketFace','Setting']
tr,roots=rows(P); roots=[x for x in roots if x not in cit]; rec=[(c,str(len([n for n,t in D.items() if t.lstrip().startswith('theorem') and c in ref[n]]))) for c in cit]
h155=re.search(r'\*\*Theorem 15\.5 \(([^*]*)\)',P).group(1); h159=re.search(r'\*\*Theorem 15\.9 \(([^*]*)\)',P).group(1)
chart=[x for x in roots if x in D and re.search(r'\b(World|ActualZeros|FinCfg|Pt)\b',D[x].split(':=')[0])]
over='The verdict theorems are stated over an arbitrary type' in para(P)
t1=f"""Kinematic register. The kernel on disk has sha256 {SHA[:16]}, the digest of the date line: {need('sha',SHA[:8] in P[:1500])}; the listing of Appendix A equals it byte for byte: {need('listing',A[f0:f1].split(chr(10),1)[1]==K.rstrip(chr(10)))}; live compile under Lean 4.19.0: exit {r.returncode}, {len(pr)} cones printed, every pin held: {need('compile',r.returncode==0 and len(pr)==231)}. Table B.4 recomputed from the source by dependency closure: the {len(rec)} rows equal the table's {len(tr)} rows, counts included: {need('B4 rows',sorted(rec)==sorted(tr))}; the closure of each of the {len(roots)} verdict roots contains no cited structure: {need('closures',not any(clo(x)&set(cit) for x in roots))}.

Definitional register. Theorem 15.5 is the closure on any carrier ({need('15.5','carrier' in h155)}) and Theorem 15.9 the socket in the open strip ({need('15.9','strip' in h159)}), as the paragraph cites them. The paragraph says the verdict theorems are stated over an arbitrary type; read against the source, {len(chart)} of the {len(roots)} verdict roots are stated on the chart's own types ({', '.join(chart[:6])}, and others), and only the closure of Theorem 15.5 is stated over an arbitrary carrier: finding F-1."""
f1d=[dict(fid='F-1',reg='definitional',claim='C8',mech='the paragraph closing Section 16 says the verdict theorems are stated over an arbitrary type; most verdict roots are stated on the chart types, and only the closure of Theorem 15.5 is stated over an arbitrary carrier; repaired by exact replacement of the sentence',disp='EARNED',sev='STRUCTURAL',repaired=True)] if (over and chart) else []
old="The verdict theorems are stated over an arbitrary type and hold on any carrier with the fold by instantiation (Theorem 15.5), never by chart isomorphism, which transports a verdict only between isomorphic charts."
new="The closure is stated over an arbitrary carrier with an involution and a registration and holds on any such carrier by instantiation, the chart one instance (Theorem 15.5); the other verdict theorems are stated on the chart, and no verdict passes from the chart to another carrier by chart isomorphism, which transports a verdict only between isomorphic charts."
Q=P.replace(old,new,1); open('rh_v8_post1.md','w').write(Q)
print('R1 anomalies',anom,'finding',bool(f1d)); 
if anom: sys.exit(1)
rnd(1,'kinematic,definitional','rh_v8_candidate.md','rh_v8_post1.md',f1d,t1)
# ROUND 2 · parameter, provenance
P=Q; iA,iB,iC,iD,iR=[P.index(h) for h in ['## Appendix A.','## Appendix B.','## Appendix C.','## Appendix D.','## References']]
outside=P[:iA]+P[iB:iC]+P[iD:iR]; allowed={'867','352','174','231','4211','4,211','211913','211,913','35','32','19','13','1','0'}
cnt=[m.group(1) for m in re.finditer(r'\b([\d,]+) (theorems|pinned cones|cones pinned|cones printed|lines|bytes)\b',outside)]
n,miss,unused=checkall.refcheck(P); hist=P[iC:iD]; Dx=P[iD:iR]
t2=f"""Parameter register. Counts outside the listing, the receipts' lists and the history cards: {len(cnt)}, every one a count of kernel 3.1.1 or a section of it: {need('counts',all(c in allowed for c in cnt))}; the counts of Table B.4 are those recomputed in round 1; the digest of the date line and the certificate of Appendix E is that of the unchanged kernel: {need('E sha',' '.join(SHA[i:i+8] for i in range(0,64,8)) in Dx)}.

Provenance register. Citations read both ways: {n} author-year citations, each with its entry and every entry cited: {need('cit',not miss and not unused)}; the added text introduces no citation. History: C.4 heading {need('C4','### C.4' in hist)}; Appendix D names the fourth cycle and C.4 {need('D','closing card is C.4' in Dx)}; certificate of edition 3.1.2 {need('E','AI scribe of edition 3.1.2' in Dx)}."""
print('R2 anomalies',anom); 
if anom: sys.exit(1)
rnd(2,'parameter,provenance','rh_v8_post1.md','rh_v8_post1.md',[],t2)
# ROUND 3 · limit, symmetry
T=para(P); u=subprocess.run(['/home/claude/physos/.toolchain/lean-4.19.0-linux/bin/lean','/home/claude/physos/Universal_Closure.lean'],capture_output=True,text=True,timeout=600).stdout
cl=[l for l in u.split('\n') if 'least_erasure_iff_value_classical' in l]
bad=re.findall(r'(?i)(?:derive[sd]?|proves?|proved)\s+(?:the\s+)?(?:explicit formula|Weil|Li\'s|de Bruijn|Liouville)',T)
live=[c for c,k in rec if k!='0']
t3=f"""Limit register. The paragraph states its own limits: the one fact about the object the verdict addresses, fold-closure from the functional equation {need('obj','the one fact about the object the verdict addresses' in T)}; the vacuity of resolution one {need('res1','At resolution one the open strip is the line' in T)}; the cone on a carrier where the line is not decidable, checked by compiling the operating system's classical form, whose printed cone is {cl[0].split('axioms: ')[-1] if cl else 'missing'}: {need('classical',bool(cl) and 'Classical.choice' in cl[0] and "the empty cone of the title is the chart's" in T)}; no sentence says a face is derived: {need('derive',not bad)}.

Symmetry register. What stands without the faces and what is lost with them are both stated: {need('both','Remove every face and the one-bit verdict stands' in T and 'what is lost is only the reading' in T)}; the faces are live, not decoration: {len(live)} of the {len(rec)} structures are taken by at least one theorem, {need('live',len(live)==len(rec))}; the object fact is addressed to the object and never to the foundation: {need('addr','addressed to the object and never to the foundation' in T)}; after the repair of F-1 the carrier sentence names the closure alone as generic and the rest as chart-stated: {need('F-1 held','the other verdict theorems are stated on the chart' in T)}."""
print('R3 anomalies',anom)
if anom: sys.exit(1)
rnd(3,'limit,symmetry','rh_v8_post1.md','rh_v8_post1.md',[],t3)
