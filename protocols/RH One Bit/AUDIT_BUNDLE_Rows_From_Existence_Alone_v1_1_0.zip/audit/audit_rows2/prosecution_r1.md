ROUND 1: the two external audits of v1.0.1 attached by the architect, filed as E-25 to E-36; uncalibrated by construction.
