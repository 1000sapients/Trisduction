PROSECUTION rh3 ROUND 4 · registers definitional, provenance (highest historical yield) · artifact rh3_v4_seeded_r4.md
Targets from round 3: the seed sites and the "given the imported inputs" sites. Full read of every sentence in the risk class (77 sentences) run.

P-1 provenance, Disclosure: "nine rounds" for the first cycle, which the ledger records as seven.
P-2 definitional, Section 6.7: "The width, meaning the imaginary part of every zero of zeta" gives the toy's natural-number width the sense of an analytic quantity the section says it does not model.
P-3 provenance, Section 7: "the halt criterion, which cannot fire" contradicts the criterion's stated firing condition and its blast radius.
P-4 provenance, Section 6.6 heading, Section 8 "What is proved", Section 9: "with Perelman as calibration", "calibrated against Perelman", "it contains Perelman's witness as a calibrated derivative". The round-1 repair demoted Perelman to a structural analogue at the abstract, 6.6 body, and the docstring; these three sites still assert calibration or derivation.
P-5 provenance, Section 8 "What is not proved": "the hypothesis is equivalent to Postulate M with its seed and to each of the five readings, those six are one proposition" states the equivalence without the imported inputs; the round-3 repair reached five sites and missed this one.
Targets prosecuted: the seed now appears at every Postulate M equivalence site other than P-5's; the five repaired sites carry the imported-inputs clause.
