PROSECUTION rh2 ROUND 4 · registers definitional, provenance (highest historical yield) · artifact rh2_v4_seeded_r4.md
Mandatory target from round 3: misaddressed_general and the Theorem 63 text; the moved receipts.
Whole-document scan: every cited identifier declared (hDef, hLam are structure fields); digest and 1018 lines match Appendix A; 75 sets, 53 free, 20 on propext and Quot.sound, 2 on propext, 0 Classical.choice.

P-1 definitional, Section 4: "two streams N -> Bool stay true"; the theorem it labels states one stream, the Li sign stream.
P-2 definitional, Section 8: "The time reading, meaning the heat-flow time of Section 6.7" conflates the Li index step of 6.2, which Theorem 15 concerns, with de Bruijn's heat time.
P-3 provenance, Section 9: "The open question is closed" contradicts the same paragraph and the terminal box, which locate it in the object.
P-4 provenance, the 6.9 verdict box and the Disclosure Method line: "(Theorems 58 to 67)" cite the collapse and its mark; the round-1 addition moved the collapse to Theorems 58 to 69 (rh_marked_dot6 is 69). Stale range at two sites; the addition's consumers were not all reached.
P-5 provenance, Abstract: "the value is located entirely in zeta". The round-2 exclusivity repair swept "located, entirely" with a comma and missed this phrasing; the exclusivity it states exceeds Theorems 63 and 64.
Target prosecuted: misaddressed_general quantifies over an arbitrary frame with a failed line property and matches the Theorem 63 text; receipts consistent. No defect in the target.
