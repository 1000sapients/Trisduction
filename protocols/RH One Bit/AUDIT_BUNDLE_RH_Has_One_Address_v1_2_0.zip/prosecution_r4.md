PROSECUTION ROUND 4 · registers definitional, provenance (highest historical yield) · artifact rh_v4_seeded_r4.md
Mandatory targets from round 3: Theorem 48 and its text, the zeta fold-invariance sentence in 6.2, the moved receipts.

P-1 definitional, Section 6.7: "certifies a record at t = 0.44" while the same paragraph and Section 2 give the bound as 0.22. The time does not follow from the printed bound.
P-2 definitional, Section 5: "the suspension token, meaning the seal" gives the suspension token the sense of the seal it is contrasted with in the same sentence.
P-3 provenance, Section 3: "The Root Axiom enters as a kernel-proved theorem on every substrate" contradicts the kernel audit and every theorem statement, where it is a hypothesis RA S.
P-4 provenance, Table 1, prior-paper row: "executed, Thms 44 to 47" and "the regress halts". After Theorem 48 the halt result is Theorems 44 to 48 and covers sufficient routes; the row still states the pre-repair range. The halt-scope repair of the prior round did not reach the table.
P-5 provenance, Sections 6.6 and Appendix A (docstring of Theorem 35): "Perelman's W-entropy, nondecreasing under Ricci flow". The cited monotonicity holds along Ricci flow only with the auxiliary function evolving by the conjugate heat equation and the scale parameter decreasing at unit rate; stated bare, the attribution is imprecise.
Targets prosecuted: Theorem 48 statement checked against its Lean term, (P -> RH) -> P -> all legs, correct; the stage map (h, t) = (2 Re s, Im s) agrees with rho = h/2 + i t; fold equals s -> 1 - conj(s) recomputed; receipts recomputed: 49 sets, 30 free, 17 on propext and Quot.sound, 2 on propext, 0 Classical.choice, 660 lines, digest matches Appendix A.
