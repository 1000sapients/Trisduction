PROSECUTION rh3 ROUND 3 · registers limit, symmetry · artifact rh3_v3_seeded_r3.md
Targets from round 2: the table's seed row and the rewritten identity cell.

P-1 limit, Section 3: "fifty-four axiom-free" against the kernel audit, 53, and the Disclosure receipts.
P-2 symmetry, Section 7: "F1, the stability criterion, meaning Postulate M's seed" gives the criterion the sense of an input the paper takes as computed; F1 is an off-line zero.
P-3 limit, Section 8: "complete, the hypothesis included" contradicts the paragraph's own statement that no derivation is claimed.
P-4 limit, Section 8 and Section 6.10: "the hypothesis is equivalent to Postulate M and to each of the five readings" and "once stated it is proved equivalent to the hypothesis" state the Postulate M equivalence without its seed; the round-1 seed repair missed these two sites.
P-5 limit, the 6.9 verdict box, the 6.11 terminal box, Section 8 "every reading reached is proved to be one proposition", and the 6.10 closing "are one proposition": each states the equivalence of the readings with the hypothesis as proved, without the imported inputs on which the legs rest (Li's criterion for four legs, hLam for the upstream leg, hDef and the seed for Postulate M). The Section 3 table now names those inputs, but these consumer sites still read as unconditional. Correspondence between the claims and the kernel statements fails at the hypotheses.
Targets prosecuted: the table's seed row names the input correctly; the identity cell now cites (6.2a) and renders with single bars.
