PROSECUTION rh2 ROUND 3 · registers limit, symmetry · artifact rh2_v3_seeded_r3.md
Targets from round 2: the restated terminal box and the scoped sentences; no additions declared.

P-1 limit, Section 1: "the Return i.j.k = +1" contradicts the prior paper's Theorem B and the file: (i.j).k = -1; the reversed triad gives +1.
P-2 symmetry, Section 9: a planted gloss renames "five programs" as "the six Lean parts", a second incompatible sense of the count the paragraph gives.
P-3 limit, Section 3: "Every theorem, the hypothesis included, is checked" asserts the hypothesis as a checked theorem, contradicting Section 8 and every verdict line.
P-4 limit, Section 6.11 Theorem 63: the text states it for "any resource ... that also holds on a frame where the line property fails". The kernel theorem misaddressed_to_foundation takes the hypothesis R twoPoint, one specific frame. The general statement follows by the same one-line argument, but the file does not state it; correspondence between the text and the kernel fails at the quantifier. Falsifier: search the file for a theorem quantified over an arbitrary frame with a failed line property. None.
Correspondence checks passed: Postulate M in the text matches PostulateM in the file, staging total, seed at stage 0; the Bridge-plane fold (h, t) -> (2 - h, t) in Parts IV and XI is one map; the two-point frame of Part XII matches the prior paper's; Hunt6 extends Hunt without altering its hypotheses; the terminal box cites only theorems whose statements carry its clauses.
