PROSECUTION rh3 ROUND 2 · registers kinematic, parameter · artifact rh3_v2_seeded_r2.md
Mandatory targets from round 1: the Grade K / A / C table in Section 3 and every rewritten sentence; the Lean docstrings for Theorems 35, 40, 46, 47; the moved digest.

P-1 kinematic, Section 8: "states that address in seven equivalent forms"; the cone has six readings (five plus Postulate M).
P-2 parameter, Section 6.2: "a mode is unitary, meaning an operator is self-adjoint" re-imports the operator sense the round-1 repair removed; |z| = 1 is a scalar condition.
P-3 parameter, Section 1: "This paper crosses that strip" contradicts the next paragraph and Section 8.
P-4 parameter, Section 3 table, imported inputs census: the grade-A row lists Li, Bombieri-Lagarias, Newman with Rodgers-Tao, hDef, and the Eisenstein coefficient. Theorems 49 and 68 also take the seed L(0), every zero located by stage 0 on the line, as a hypothesis; for zeta it is a computed fact supplied from verification, not a kernel theorem. The census omits an input the equivalence depends on.
P-5 kinematic, Section 3 table, grade-K cell: the identity is written with escaped pipes inside math, which renders as the norm symbol in the PDF (pandoc emits \|\rho-1\|) and as a literal backslash in the Blog edition; elsewhere the paper writes the modulus with single bars. Recomputed by converting the table alone.
Receipts recomputed: 75 sets, 53 free, 1018 lines, digest b5df64f9... matches Appendix A; kernel audit unchanged by the docstring edits (diff empty).
Targets prosecuted: Theorems 35, 40, 46, 47 docstrings now match their scoped prose; F-9 sentences carry scalar sense throughout, except the planted P-2.
