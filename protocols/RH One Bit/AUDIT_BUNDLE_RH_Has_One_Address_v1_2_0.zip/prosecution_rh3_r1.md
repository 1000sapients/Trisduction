PROSECUTION rh3 ROUND 1 · registers definitional, provenance · artifact rh3_v1_seeded_r1.md
Source: the external review supplied by the architect, carried finding by finding, plus the control catches.

X-1 kinematic, Section 4: "a structure with three fields" while the display shows two, the choice of existents and the reading.
X-2 definitional, Section 3: "premise, meaning a kernel theorem" collapses the premise grade into the kernel grade it is defined against.
X-3 provenance, Section 8: "The paper proves the hypothesis" contradicts every verdict line and the abstract.

E-1 Title: "A Formal Completed Proof That the Riemann Hypothesis Has One Address" read against Section 8 and the Hunt structure's hypotheses. A reader stopping at the title reads a completed proof; the formal development takes the analytic equivalences as inputs. Proposed alternative: "A Formal Lean Analysis Showing That the Riemann Hypothesis Has One Address, Not a Sequence of Independent Missing Pieces".
E-2 Theorem 46: the theorem takes P with P iff RH and returns P iff each reading. The prose "Any reformulation equivalent to the hypothesis lands on the same apex; a further search adds no new gap" can be read as quantifying over future reformulations; the theorem decides nothing about which propositions are equivalent.
E-3 Theorem 47: the theorem is (Q -> RH) iff RH given Q true. The prose "No true premise independent of the apex closes it for less" invokes an independence notion the file does not define; the consumers "nothing weaker than it closes it" and "no weaker premise ... closes it" repeat the unformalized claim.
E-4 Theorem 48: a corollary of the cone; the prose "It opens no new gap either" reads as a claim about future proof strategies.
E-5 Postulate M: postulateM_iff_line takes the seed L(0) as a hypothesis. The abstract, the 6.9 verdict box, Section 8, and the Conclusion state "Postulate M is equivalent to the hypothesis" and "Timeless Residual Monism is equivalent to the Riemann Hypothesis" with the seed omitted.
E-6 Monism witness: the uniform field carries the universal claim; flagged as repackaging if presented as a derivation.
E-7 Perelman: the file proves a generic monotone-sequence witness; the text calls Perelman's entropy "the calibrated instance" and his witness "a derivative of the monism witness", which reads as a formal link the file does not contain.
E-8 de Bruijn-Newman: Theorem 40's prose "The hypothesis is Lambda = 0: zeta sits exactly at the critical time of its own flow" is stated at theorem grade on a natural-number toy; the zeta equivalence is the cited hLam.
N-1 LiData: the text writes lambda_n as a sum over zeros; the formal object is an abstract predicate nonneg with no zeros, sums, or numbers.
N-2 Bombieri-Lagarias: the implication from a growing mode to a negative coefficient is imported.
N-3 and N-4 scalar versus operator: "the unitarity of zeta's time evolution" and "the Hilbert-Polya form of the hypothesis stated exactly" assert more than the scalar identity |z| = 1 gives; no operator or unitary group is constructed.
N-5 Eisenstein: zeta(s)zeta(s-k+1) is not primitive; the negative-coefficient property needs the normalization that centers its functional equation.
A-1 closed authorship: text and file by one model; no independent recompile on record.
