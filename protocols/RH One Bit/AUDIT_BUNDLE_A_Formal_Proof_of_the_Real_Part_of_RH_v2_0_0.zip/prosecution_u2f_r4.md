PROSECUTION u2f ROUND 4 · registers definitional, provenance (highest historical yield) · artifact u2f_v4_seeded_r4.md · targets: the round-3 repairs; every exclusivity statement carried from a separate edition; the Standard of Proof against the Lean appendices
X-1 kinematic, Part III, the unicorn identity: "All five are axiom-free" after four theorems.
X-2 definitional, Provenance: "SELF grade, meaning externally witnessed" inverts the grade; SELF grade is the absence of an external witness.
X-3 provenance, Falsifiable Criteria F1: "None can exist at any height" claims the Unicorn part; the certificate reaches 3 × 10^12 only.
P-4 provenance, Part II's discussion: "The paper's contribution is exactly the set of relations in Table 6 and nothing wider" carries the One Address edition's claim about itself; in the unified paper the contribution also includes Part I's contributions table and Part III's Table 7.
P-5 provenance, Part I: the table captioned "Contributions of this paper" carries the Existence Alone edition's contributions under a caption that now names the whole paper.
Checked against the Standard of Proof: no axiom declaration in any Lean appendix; every occurrence of the word sorry is in a header comment; no sorryAx in any audit; no Classical.choice in any audit.
