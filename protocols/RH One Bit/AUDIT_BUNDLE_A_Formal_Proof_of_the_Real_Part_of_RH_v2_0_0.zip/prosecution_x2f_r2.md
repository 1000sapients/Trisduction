PROSECUTION x2f ROUND 2 · registers kinematic, parameter · artifact x2f_v2_seeded_r2.md · targets: the round-1 repairs; every count in the completed audits and the twin's receipts
X-1 kinematic, Provenance: "79 axiom-free, 12 on propext and Quot.sound" for Part I's 91 sets; the runs give 78 and 13.
X-2 definitional, Part III: "meaning the Unicorn part is seeded too" attaches the seed to the Unicorn part; the seed is the Real part and the uniformity is the Unicorn part.
X-3 parameter, Conclusion: "the Unicorn part ... proved at every height the certificate reaches" hands the certificate to the Unicorn part; the certificate proves the Real part and nothing above it.
Recounted and clean: 61 + 30 = 91 sets for Part I, 49 + 29 = 78 axiom-free; 83 + 17 = 100 sets for Part II, 61 + 9 = 70 axiom-free, 30 on propext and Quot.sound; the twin's census 130,324 with 0 failures in both editions, its header now fourteen batteries and the file runs fourteen; Appendix H names the renamed arrow theorem in its source and its receipt; the referent, the seed condition, and the modal keystone read as repaired.
No new finding. The round is clean.
