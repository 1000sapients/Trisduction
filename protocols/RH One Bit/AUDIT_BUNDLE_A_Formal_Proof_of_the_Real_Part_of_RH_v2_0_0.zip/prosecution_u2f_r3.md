PROSECUTION u2f ROUND 3 · registers limit, symmetry · artifact u2f_v3_seeded_r3.md · targets: the round-2 repairs; every sentence of the whole text that could read as a claim of the hypothesis (scan run over the main text)
X-1 limit, abstract: "to height 3 × 10^13"; the certificate reaches 3 × 10^12.
X-2 definitional, Part I: "the Return lands on the seat, meaning on a zero of zeta"; the Return is a quaternion product landing on the scalar line, not a zero.
X-3 limit, Introduction: "Parts I and II prove the hypothesis" contradicts the paper's standard and every verdict.
P-4 symmetry, Part I, its notation paragraph: "The title names the first and excepts the second, and the exception is Theorem I" describes the title of the separate Existence Alone edition; the unified paper's title names the Real part and excepts nothing by that name.
P-5 limit, table numbering: Part I's five captioned tables number 1 to 5 automatically, while the positioning table carried from the One Address edition keeps its manual label "Table 1." and Part III's positioning table is labeled "Table 2."; two tables carry each of the labels 1 and 2, and "the relations in Table 1" points at two tables.
Scan result: every other sentence that mentions proving the hypothesis denies it, attributes it to a misreading, or concerns the seat.
