PROSECUTION v2f ROUND 2 · registers kinematic, parameter · artifact v2f_v2_seeded_r2.md · mandatory targets: every round-1 repair
X-1 parameter, section 2: "from proved to refuted"; the fused statement stands open, and the kernel's fused standing is open.
X-2 definitional, section 1: "Theorem I, the cure theorem, which it relaxes"; Part Two neither relaxes nor weakens Theorem I.
X-3 kinematic, section 6: "II.35 depends on propext and Quot.sound"; the kernel run prints propext alone.
P-4 kinematic, section 5, the massless-arrow paragraph: "All three are axiom-free" under Theorems II.31 to II.33, which carry four kernel theorems (II.32 names two); the file prints four dependency sets.
P-5 parameter, Table II.1 row on bounded completeness, and the Real-part box: "Lifts the certified Real part into ZFC" and "the certified statement is a theorem of ZFC" restate the lift without the cited analytic lemmas the round-1 repair of II.36 made explicit; completeness lifts the certificate's arithmetic checks, and the analytic lemmas carry them to the statement about the zeros.
Targets re-checked: II.12, II.17, II.18, II.20, II.28, II.36, the abstract, the reader's map and the Chapter 2 head read as repaired; receipts 37 / 34 / 3 recomputed against the eight runs; theorem counts per section recounted (6, 4, 4, 5, 7, 4, 4, 3).
