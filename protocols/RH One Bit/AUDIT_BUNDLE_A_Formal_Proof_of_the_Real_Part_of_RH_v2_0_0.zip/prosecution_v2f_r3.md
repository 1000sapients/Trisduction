PROSECUTION v2f ROUND 3 · registers limit, symmetry · artifact v2f_v3_seeded_r3.md · mandatory targets: F-12, F-13; full read of Part Two
X-1 limit, section 1: "numbered II.1 to II.38" against a text that ends at II.36.
X-2 symmetry, section 4: "that is, when the Real part holds above T" swaps the two parts; the Real part is by definition the region up to T.
X-3 limit, section 6: "closes the Real and Unicorn parts at 3 × 10^12" claims the open part closed.
P-4 limit, section 1: "Every result in Part Two is a kernel theorem ... Two results enter by citation" while the text now enters by citation the certificate, bounded completeness, the analytic lemmas that validate the certificate, the arithmetic form and absoluteness of the hypothesis, and the independence of Choice; the round-1 repair of the abstract did not reach this sentence.
P-5 symmetry, section 2: "A bounded statement about finitely many objects" uses "bounded" where the round-1 repair of II.36 reserved bounded completeness for the certificate's arithmetic checks; the Real part is a statement of analysis about finitely many zeros.
Targets re-checked: the four-theorem count in the massless paragraph and the two lift sites read as repaired. Full read of sections 5 to 9: no further mechanism found.
