PROSECUTION x3f ROUND 3 · registers limit, symmetry · artifact x3f_v1_seeded_r3.md
X-1 limit: the Unicorn part restated as "no off-line zero at any height" collapses it onto the whole hypothesis.
X-2 limit: "for every real witness" extends Theorem 73 past its decidable-predicate hypothesis.
X-3 symmetry: "carried as theorems" promotes two named hypotheses.
Symmetry read: the finite-witness sentence, the Standard's cited-theorems paragraph, and the Conclusion's sealed-direction note now say the same thing at the same grade; nothing established is weakened; the Unicorn part is unchanged in every statement. No new finding.
