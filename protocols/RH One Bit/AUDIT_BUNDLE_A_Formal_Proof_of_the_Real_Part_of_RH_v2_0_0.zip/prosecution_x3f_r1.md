PROSECUTION x3f ROUND 1 · registers definitional, provenance · artifact x3f_v1_seeded_r1.md · scope: the two precision sentences and the float fix
X-1 definitional: "an integer instance at which the inequality holds" inverts the witness.
X-2 provenance: "the instantiation ... is by the kernel" claims the kernel arithmetizes the hypothesis; it does not.
X-3 definitional, abstract: "not proved, meaning refuted" equates open with refuted.
Read against the sources: Theorem 73 quantifies over a decidable predicate on the naturals and refutes the universal at one failing index, which the sentence names as the integer instance; the enclosure route is the cited certificate's, stated as such; the setting of Theorems 74 to 77 is abstract in the file and the sentence says so; Kaye carries Sigma-1 completeness and Davis et al. the arithmetization. No new finding.
