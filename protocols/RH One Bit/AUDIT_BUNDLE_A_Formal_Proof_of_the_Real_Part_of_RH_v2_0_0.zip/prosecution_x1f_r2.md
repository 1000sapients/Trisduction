PROSECUTION x1f ROUND 2 · registers kinematic, parameter · artifact x1f_v2_seeded_r2.md · targets: the round-1 repair; every method, count and number stated in the answer to the external audit
X-1 kinematic, Part III road: "Theorem III.20 (ram_subsumes_by_placement)" renumbers the placement verdict; it is III.19 and III.20 is the next theorem.
X-2 definitional, Provenance: "SELF grade, meaning independently witnessed" inverts the grade.
X-3 parameter, Standard of Proof: "Two readings are established by the text itself" asserts the two readings the text excludes.
P-4 parameter, Part III testimony paragraph and the script's header: the count (b) is described as the argument principle with the argument tracked continuously along a path, Backlund's method; the library routine's documentation states only that it computes N(t), and neither the path nor Backlund's method is verified for it. The description asserts a mechanism the run does not exhibit.
Recounted and clean: 29 = 29 = 29 in the printed run; nine files, 45 / 42 / 3; five reports, two repairs; III.15 to III.30 sixteen road theorems; the Davis et al. entry seated in the bibliography.
