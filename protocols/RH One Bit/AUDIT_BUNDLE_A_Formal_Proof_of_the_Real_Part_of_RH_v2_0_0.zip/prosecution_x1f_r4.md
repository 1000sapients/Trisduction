PROSECUTION x1f ROUND 4 · registers definitional, provenance (second pass) · artifact x1f_v3_seeded_r4.md · targets: every citation and anchor added in the answer, re-read against its source
X-1 kinematic, Discussion: "Table 8" for Part III's positioning table; it is Table 7 and there is no Table 8.
X-2 definitional, Part III: the Omega floor called "the kernel's own cost of proof"; the Landauer floor prices a registered bit in a physical substrate, and the kernel prices nothing.
X-3 provenance, Provenance: "A recompile on a second machine is on the record"; none is.
Re-read and clean: Davis, Matiyasevich and Robinson 1976 give the Pi-0-1 (Diophantine) form of the hypothesis, as cited; Lawvere 1969 is the fixed-point theorem that generalizes Cantor's diagonal argument, as now worded at both sites; Kaye 1991 carries Sigma-1 completeness; Turing 1953 is cited for the method of record and no longer for the script's count; the Omega guard and the price bijection name the Codex kernel's OMEGA and FTOE namespaces; Theorem D is presence and Theorem E the rule.
No new finding. The round is clean.
