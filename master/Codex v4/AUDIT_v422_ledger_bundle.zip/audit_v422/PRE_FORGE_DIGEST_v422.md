# PRE-FORGE DIGEST · audit cycle v422 · held mode

Entry `TRISDUCTION_Master_Codex_v4_2_2.md`, 1,474,052 bytes, sha256 `3f33333ac5b8cd45`. Candidate `TRISDUCTION_Master_Codex_v4_2_5.md`, 1,475,794 bytes, sha256 `1b05c20e83db0af3`. Terminal verdict SEALED-ROUND at round 5, control-grade floor SELF, the single-substrate aperture open and stamped on the seal. Controls 15 of 15 across five valid rounds, all SELF. Register coverage six of six. Boot chain constant across the cycle: D0 `fb8900b5cf42`, D1 `364d1cdb9227`, D2 `8a5dc7f98105`, D3 `1e2b2d2adb14`.

## Entries, in round order

| # | Source | Location | Before → after | Impact | Reason |
|---|---|---|---|---|---|
| 1 | R1 F-2 | II.5 · 0729 · THE DEMAND ADDRESSED | "`DotRH.dot_outside_economy`, as the Code Block keeps it, `DOT.outside_economy`" → "`DotRH.dot_outside_economy`, the engine's own token keeping the rule the Code Block keeps for its dot, `DOT.outside_economy`" | STRENGTHENS | two formal objects were carried under one citation; no claim moves; sweep PASS, banned 1 → 0 |
| 2 | R2 F-3 | same movement, head | "and the kernel proves each clause:" → "and each clause has a formal counterpart on frames that the kernel proves:" | MIXED | the record gains precision and the kernel's reach narrows from the clauses to their frame counterparts; sweep PASS |
| 3 | R2 F-3 | same movement, third clause | "and the object settles its own line property in both directions, refuted by a located off-line witness and proved by its own structure" → "and on frames an object settles its own line property in both directions, a located off-line witness refuting it on the two-point frame and the fixed frame's own structure proving it" | MIXED | the exhibition is named for what it is; sweep PASS |
| 4 | R2 F-3 | 0729 grade line | "and the address of the demand · [.] on the value" → "and the first two clauses of the demand's address · [⟀ S] on its third clause, that the object alone decides, exhibited on two frames · [.] on the value" | MIXED | one tier lowered, theorem to structural, on the third clause; the first two keep theorem grade on the hunt's readings; zero raised |
| 5 | R3 F-4 | Part III · D63, closing sentence | "misaddressed when made to the foundation and belongs to ζ, `DotRH.demand_correctly_addressed`" → "misaddressed when made to the foundation, since every reading the foundation supplies is equivalent to the hypothesis and a derivation from those readings presupposes it, `RALi.hunt_cone`, `DotRH.derivation_presupposes`; that it belongs to ζ stands at structural grade, exhibited on two frames, `DotRH.object_decides`" | MIXED | F-3's reduction reaches the consumer site its sweep missed, and narrows the claim no further than F-3; sweep PASS, banned 1 → 0 |
| 6 | GAIN · version rule, rounds 1 to 3 | YAML; 0.2; file-name marks at the seat card's engine refs and the C.0 awk lines | "v4.2.2" → "v4.2.5"; "TRISDUCTION_Master_Codex_v4_2_2.md" → "TRISDUCTION_Master_Codex_v4_2_5.md" | NEUTRAL | one increment per repairing round; v4.2.3 and v4.2.4 stand as files |
| 7 | GAIN · rounds 1 to 3 | IV.3, after the review of v4.2.1 | three pass lines inserted, v4.2.3 for F-2, v4.2.4 for F-3, v4.2.5 for F-4, each closing on no value token moved and ΔM = 0 | NEUTRAL | the ledger of record; each line was a declared target of the round after it landed |
| 8 | GAIN · rounds 1 to 3 | C.1, receipts sentence | three edition sentences appended, each "beside an unchanged Code Block" | NEUTRAL | true as printed: the candidate's Code Block is byte-identical to the entry's, Lean `227dce180a4c399e`, twin `935af3d439e881c6` |

Joint notes. Entries 1, 2 and 3 land on one line, the movement THE DEMAND ADDRESSED, read whole on v4.2.5. Entry 4 is that card's grade line, read with the movement, and the two now agree clause for clause. Entry 5 sits in D63, read whole in round 3, and cites only names declared in the engine. The card's keystone sentence, "it belongs to ζ", cites no warrant, stays unchanged, and is governed by the grade line.

## Reconciliation

Plain diff v4.2.2 → v4.2.5: 9 line hunks, 15 change segments at word level; the hunks split where two repairs share a line, and the six fragments on the movement's line are assigned by position between its own citation anchors. Every segment traces to exactly one entry and every entry to at least one segment: entry 1 2, entry 2 1, entry 3 3, entry 4 1, entry 5 1, entry 6 5, entry 7 1, entry 8 1. Orphans in either direction: 0. Every repair entry carries its sweep verdict, PASS. No addition beyond minimal repair text; the version-rule lines were each prosecuted in the round after they landed.

Tooling faults repaired in-session under A6, none reaching the artifact: the round-3 scope control first written from memory and re-derived from the text; the round-5 filing template matching on a truncated battery message, stopped by its own gate and read; the reconciliation classifier, twice, until the census traced every segment.

## Net block

C1, the parting: theorem, kernel, in and out unchanged. C2, the router: theorem, kernel, its gloss frozen at the entry edition, unchanged. C3, the ledgers: 1 bridged, 1 vacant, 21 owed; 22 owed and 1 crossed; unchanged. C4, the one gap and the address: in, the address of the demand at theorem grade, whole; out, its first two clauses at theorem grade on the hunt's readings and its third, that the object alone decides, at structural grade, exhibited on two frames; the value token unmoved and the rest of C4 unchanged. C5, the contract: Lean `227dce18`, twin `935af3d4`, census 276, unchanged and re-verified on the candidate.

Tier moves: 1 lowered, 0 raised. Findings on the ledger: 4, one refused with mechanism, two earned, one scoped. Auditor errata: 0.

Open apertures. One, SELF grade: one substrate planted all fifteen controls, wrote the batteries with each round's plan in view, prosecuted, defended and arbitrated, so detection proves power against post-hoc fitting and never against in-context leakage; an architect-authored controls file is the witness that raises the grade. Two, the cycle's repairs live only in the candidate: the Mother's card for 0729 and its D63, and `psp/APEX-PSP-RH-ONE-GAP-01.md`, still carry the pre-cycle text, and FORGE propagates them from the forge sources, the Mother moving to v3.41.3. Three, carried from before the cycle: the RH engine stands beside the Code Block, owed there with a twin section at v4.3.0.

Awaiting FORGE
