#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Math Journal preprocessor for the Condensed Master Codex.
Markdown (codex master) -> pandoc-ready Markdown with raw LaTeX for the objects the
two-column LaTeX page needs: the title block (YAML), jbox text boxes (fenced divs for
the Lua filter), GOL derivation boxes (verbatim in a tinted tcolorbox), Lean excerpts
(listings with the line reference into Codex.lean), tables by the span rule, and the
two code surfaces as numbered two-column listings read from the companion files."""
import re, sys, os, json

SRC = sys.argv[1]
OUT = sys.argv[2]
LEAN = sys.argv[3]      # Codex.lean beside the source
FORT = sys.argv[4]      # Codex_Twin.f90 beside the source
SUBSET = os.environ.get('MJ_SUBSET')  # optional: 'test'

doc = open(SRC, encoding='utf-8').read()
lean_lines = open(LEAN, encoding='utf-8').read().split('\n')

# ---------------- front matter
m = re.match(r'^---\n(.*?)\n---\n', doc, re.S)
fm = {}
for l in m.group(1).split('\n'):
    k, _, v = l.partition(':')
    fm[k.strip()] = v.strip()
body = doc[m.end():]
abs_m = re.search(r':::abstract\n(.*?)\n:::\n', body, re.S)
kw_m = re.search(r':::keywords\n(.*?)\n:::\n', body, re.S)
abstract = abs_m.group(1).strip().replace('\n', ' ')
keywords = kw_m.group(1).strip()
body = body[:abs_m.start()] + body[kw_m.end():]

def tex_escape(s):
    return (s.replace('\\', '\\textbackslash{}').replace('&', '\\&').replace('%', '\\%')
             .replace('$', '\\$').replace('#', '\\#').replace('_', '\\_').replace('{', '\\{').replace('}', '\\}')
             .replace('~', '\\textasciitilde{}').replace('^', '\\textasciicircum{}'))

def esc_split(t):
    r = tex_escape(t)
    if os.environ.get('MJ_NOSPLIT') is None:
        r = re.sub(r'(?<![\\{])\b([A-Za-z0-9][A-Za-z0-9\\_.:\-]{22,})\b', lambda m: '\\seqsplit{' + m.group(1) + '}', r)
    return r

def inline(s):
    """Markdown inline -> LaTeX for table cells and titles: code, bold, italic, escapes.
    Long plain tokens are made breakable with seqsplit; code spans carry their own, never nested."""
    out = []
    pos = 0
    for mm in re.finditer(r'`([^`]+)`|\*\*(.+?)\*\*|\*(.+?)\*', s):
        out.append(esc_split(s[pos:mm.start()]))
        if mm.group(1) is not None:
            out.append('\\texttt{\\seqsplit{' + tex_escape(mm.group(1)) + '}}')
        elif mm.group(2) is not None:
            out.append('\\textbf{' + inline(mm.group(2)) + '}')
        else:
            out.append('\\emph{' + inline(mm.group(3)) + '}')
        pos = mm.end()
    out.append(esc_split(s[pos:]))
    return ''.join(out)

# ---------------- render-time substitutions (locks): em dash -> the codex separator
body = body.replace(' — ', ' · ').replace('—', ' · ')

# ---------------- public edition: short labels, no version strings, no internal ledgers
LABELS = json.load(open(os.path.join(os.path.dirname(LEAN), 'labels.json'), encoding='utf-8'))
def relabel(txt):
    for native in sorted(LABELS, key=len, reverse=True):
        txt = re.sub(r'(?<![A-Z0-9-])' + re.escape(native) + r'(?![A-Z0-9-])', LABELS[native], txt)
    return txt
# cut IV.3, IV.4, IV.5 from the page (they live in the Markdown master)
a = body.find('## IV.3'); b = body.find('# THE CODE BLOCK')
if a > 0 and b > a:
    body = body[:a] + body[b:]
# closing receipts that belong to the internal ledgers
body = '\n'.join(l for l in body.split('\n') if not re.match(r'^- (Verbatim integrity|Hedge scan|Fences):', l))
body = re.sub(r'This document is the Master Codex, v[0-9.]+,', 'This document is the Master Codex,', body)
PUB = [
 ('Seats added after v3.20-C', 'Seats added in this edition'),
 ('the 94 cards carried from v3.20-C keep their title tokens', 'the 94 cards carried from the prior condensed edition keep their title tokens'),
 ('unchanged from Codex v2.0.1:', 'unchanged from the sealed twin:'),
 (', it is an F5 survivor and is listed as such in the Scribal Ledger.', ', it is a positive boundary and nothing more.'),
 ('Removed coordinates are census rows in Part IV with their code.', 'Removed coordinates are census rows in Part IV.'),
 ('the Scribal Ledger', 'the Markdown master'),
 ('Part IV holds two tables.', 'Part IV holds two tables.'),
]
for a_, b_ in PUB:
    body = body.replace(a_, b_)
body = re.sub(r'(?:master codex |Master codex |codex )?v[23]\.\d+(?:\.\d+)?(?:-C)?\b', lambda m: 'the master codex' if m.group(0).lower().startswith(('master codex','codex')) else '', body)
def _clean_outside_code(txt):
    out, fence = [], False
    for ln in txt.split('\n'):
        if ln.startswith('```'):
            fence = not fence; out.append(ln); continue
        if not fence and not ln.startswith(' ') and not ln.startswith('|'):
            ln = re.sub(r'  +', ' ', ln).replace(' ,', ',').replace(' .', '.')
        out.append(ln)
    return '\n'.join(out)
body = _clean_outside_code(body)
body = relabel(body)
body = body.replace('\n# INTRODUCTION', '\n```{=latex}\n\\setcounter{tocdepth}{2}\\tableofcontents\n```\n\n# INTRODUCTION', 1)

lines = [('* * *' if re.match(r'^\s*(-{3,}|\.{3})\s*$', x) else x) for x in body.split('\n')]
out = []
i = 0
stats = {'golbox': 0, 'jbox': 0, 'excerpt': 0, 'table_span': 0, 'table_long': 0, 'table_col': 0, 'code': 0}
box_depth = 0
onecol = False

def find_lean_line(first):
    key = first.strip()
    for k, l in enumerate(lean_lines):
        if l.strip() == key:
            return k + 1
    return None

def emit_table(tbl, in_box):
    """tbl: list of pipe-table lines (header, sep, rows...)."""
    rows = []
    for l in tbl:
        cells = [c.strip() for c in l.strip().strip('|').split('|')]
        rows.append(cells)
    header, data = rows[0], rows[2:]
    ncol = len(header)
    data = [r + [''] * (ncol - len(r)) for r in data]
    # column spec: proportional widths by average cell length
    def w(c):
        ls = sorted(len(r[c]) for r in [header] + data)
        p90 = ls[int(0.9 * (len(ls) - 1))]
        return min(max(8, p90), 48)
    avg = [w(c) for c in range(ncol)]
    tot = sum(avg)
    def spec(width):
        return ''.join('>{\\raggedright\\arraybackslash}p{%.3f%s}' % (0.94 * a / tot, width) for a in avg)
    hdr = ' & '.join('\\textbf{' + inline(h) + '}' for h in header) + ' \\\\'
    body_rows = '\n'.join(' & '.join(inline(c) for c in r) + ' \\\\' for r in data)
    if onecol and not in_box:
        stats['table_long'] += 1
        if len(data) > 40:
            return ('```{=latex}\n\\begin{center}\\small\n\\begin{longtable}{' + spec('\\textwidth') + '}\n\\toprule\n' + hdr +
                    '\n\\midrule\n\\endfirsthead\n\\toprule\n' + hdr + '\n\\midrule\n\\endhead\n\\bottomrule\n\\endfoot\n' + body_rows +
                    '\n\\end{longtable}\n\\end{center}\n```\n')
        return ('```{=latex}\n\\begin{center}\\small\n\\begin{tabular}{' + spec('\\textwidth') + '}\n\\toprule\n' + hdr +
                '\n\\midrule\n' + body_rows + '\n\\bottomrule\n\\end{tabular}\n\\end{center}\n```\n')
    if ncol >= 3 and not in_box:
        stats['table_span'] += 1
        return ('```{=latex}\n\\begin{table*}[t]\\centering\\small\n\\begin{tabular}{' + spec('\\textwidth') + '}\n\\toprule\n' + hdr +
                '\n\\midrule\n' + body_rows + '\n\\bottomrule\n\\end{tabular}\n\\end{table*}\n```\n')
    stats['table_col'] += 1
    return ('```{=latex}\n\\begin{center}\\small\n\\begin{tabular}{' + spec('\\columnwidth') + '}\n\\toprule\n' + hdr +
            '\n\\midrule\n' + body_rows + '\n\\bottomrule\n\\end{tabular}\n\\end{center}\n```\n')

while i < len(lines):
    l = lines[i]
    # GOL derivation boxes -> verbatim in tinted box
    mb = re.match(r'^:::box (.*)$', l)
    if mb:
        title = mb.group(1).strip()
        j = i + 1
        buf = []
        while j < len(lines) and lines[j].strip() != ':::':
            buf.append(lines[j]); j += 1
        if title.startswith('GOL Derivation'):
            stats['golbox'] += 1
            content = '\n'.join(buf).strip('\n')
            out.append('```{=latex}\n\\begin{golbox}{' + tex_escape(title) + '}\n\\begin{lstlisting}[style=golv]\n' + content + '\n\\end{lstlisting}\n\\end{golbox}\n```\n')
            i = j + 1; continue
        else:
            stats['jbox'] += 1
            out.append('::: {.jbox title="' + title.replace('"', "'") + '"}\n')
            box_depth += 1
            i += 1; continue
    if l.strip() == ':::' and box_depth > 0:
        out.append(':::\n'); box_depth -= 1; i += 1; continue
    # Lean excerpts
    if l.startswith('```lean-excerpt'):
        j = i + 1; buf = []
        while j < len(lines) and lines[j] != '```':
            buf.append(lines[j]); j += 1
        stats['excerpt'] += 1
        # reference line: first non-doc line
        first = next((x for x in buf if re.match(r'^\s*(theorem|def|abbrev|structure|inductive)\b', x)), buf[0])
        n = find_lean_line(first)
        ref = f'Codex.lean, from line {n}' if n else 'Codex.lean'
        opts = f'style=leanx,firstnumber={n if n else 1}'
        out.append('```{=latex}\n\\begin{leanexcerpt}{' + tex_escape(ref) + '}\n\\begin{lstlisting}[' + opts + ']\n' + '\n'.join(buf) + '\n\\end{lstlisting}\n\\end{leanexcerpt}\n```\n')
        i = j + 1; continue
    # the two code surfaces
    if l == '```lean' or l == '```fortran':
        j = i + 1
        while j < len(lines) and lines[j] != '```':
            j += 1
        stats['code'] += 1
        if l == '```lean':
            out.append('```{=latex}\n\\codesurface{The Lean surface · Codex.lean · line numbers are the file\'s}\n\\lstinputlisting[style=leancode]{' + os.path.basename(LEAN) + '}\n```\n')
        else:
            out.append('```{=latex}\n\\codesurface{The Fortran twin · Codex\\_Twin.f90 · line numbers are the file\'s}\n\\lstinputlisting[style=fortcode]{' + os.path.basename(FORT) + '}\n```\n')
        i = j + 1; continue
    # pipe tables
    if l.startswith('|') and i + 1 < len(lines) and re.match(r'^\|\s*-', lines[i+1]):
        j = i
        tbl = []
        while j < len(lines) and lines[j].startswith('|'):
            tbl.append(lines[j]); j += 1
        out.append(emit_table(tbl, box_depth > 0))
        i = j; continue
    if l.startswith('# PART IV'):
        out.append('```{=latex}\n\\onecolumn\n```\n'); onecol = True
    if l.startswith('# THE CODE BLOCK'):
        out.append('```{=latex}\n\\twocolumn\n```\n'); onecol = False
    if l.startswith('# REFERENCES'):
        out.append('```{=latex}\n\\onecolumn\n```\n'); onecol = True
    out.append(l + '\n')
    i += 1

text = ''.join(out)
if SUBSET == 'test':
    # keep the introduction, one carried chapter, three defense units, part IV head, and the code surfaces
    a = text.find('# PART I')
    b = text.find('## CHAPTER 1 ')
    c = text.find('# PART III')
    d = text.find('### D4 ')
    e = text.find('# PART IV')
    f = text.find('## IV.2')
    g = text.find('# THE CODE BLOCK')
    h = text.find('## C.2')
    text = text[:b] + text[c:d] + text[e:f] + text[g:h] + '\n# THE CLOSING STATEMENT\n\nTest build.\n'

yaml = ['---', 'edition: math_journal',
        'title: "Trisduction: The Codex"',
        'subtitle: "' + fm['subtitle'].replace('"', "'") + '"',
        'article_type: "' + fm.get('article_type', 'Master Codex · the fourth genre') + '"',
        'author_line: "Mohammad F. Islam, PhD^1^"',
        'affiliation: "^1^ Architect of the Trisduction · Trisduction Research Group · ' + fm['journal'] + '"',
        'date: "' + fm['date'] + '"',
        'short_title: "Trisduction: The Codex"',
        'keywords: "' + keywords.replace('"', "'") + '"',
        'accenthex: B87333',
        'abstract: |', '  ' + abstract, '---', '']
open(OUT, 'w', encoding='utf-8').write('\n'.join(yaml) + text)
print(json.dumps(stats))
