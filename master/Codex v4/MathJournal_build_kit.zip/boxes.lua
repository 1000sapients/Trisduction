-- fenced div .jbox -> tcolorbox jbox with title; plain code blocks -> small verbatim
function Div(el)
  if el.classes:includes('jbox') then
    local t = el.attributes['title'] or ''
    t = t:gsub('([&%%$#_{}])', '\\%1')
    local blocks = {}
    table.insert(blocks, pandoc.RawBlock('latex', '\\begin{jbox}{' .. t .. '}'))
    for _, b in ipairs(el.content) do table.insert(blocks, b) end
    table.insert(blocks, pandoc.RawBlock('latex', '\\end{jbox}'))
    return blocks
  end
end
function CodeBlock(el)
  if #el.classes == 0 then
    return pandoc.RawBlock('latex', '\\begin{lstlisting}[style=plainv]\n' .. el.text .. '\n\\end{lstlisting}')
  end
end

local function esc(s)
  return (s:gsub('\\','\\textbackslash{}'):gsub('([&%%$#_{}])','\\%1'):gsub('~','\\textasciitilde{}'):gsub('%^','\\textasciicircum{}'))
end
function Code(el)
  if #el.text > 18 and not el.text:find(' ') then
    return pandoc.RawInline('latex', '\\texttt{\\seqsplit{' .. esc(el.text) .. '}}')
  end
end
function Header(el)
  el.content = el.content:walk({RawInline = function(r)
    if r.format == 'latex' and r.text:find('seqsplit') then
      return pandoc.RawInline('latex', (r.text:gsub('\\seqsplit{([^}]*)}', '%1')))
    end
  end})
  return el
end
