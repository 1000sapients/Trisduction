#!/bin/bash
# usage: build_mj.sh source.md out.pdf   (template mathjournal.tex, boxes.lua, Codex.lean, Codex_Twin.f90 beside the source)
set -e
src=$(readlink -f "$1"); out=$(readlink -f "$2"); dir=$(dirname "$src")
work=$dir/work; mkdir -p "$work"
pandoc "$src" -o "$work/paper.tex" --template "$dir/mathjournal.tex" --standalone --lua-filter "$dir/boxes.lua" --resource-path "$dir" -f markdown+fenced_divs+raw_attribute
cp "$dir/Codex.lean" "$dir/Codex_Twin.f90" "$work/"
cd "$work"
for pass in 1 2; do lualatex -interaction=nonstopmode -halt-on-error paper.tex > pass$pass.log 2>&1 || { echo BUILD FAILED; grep -n -A5 "^!" paper.log | head -40; exit 1; }; done
cp paper.pdf "$out"; cp paper.tex "${out%.pdf}.tex"
python3 -c "from pypdf import PdfReader; print('RESULT', '$out', len(PdfReader('$out').pages), 'pages')"
grep -c "Overfull" paper.log || true
