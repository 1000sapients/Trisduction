#!/usr/bin/env python3
"""THE VACUITY LINT for the codex twin. A check is vacuous when its condition names no variable and calls no
function: once the logical literals and operators are removed, no identifier remains. Two call forms are read,
`call assert(cond, label)` and `call check(label, cond)`, across continuation lines. The failure-branch pattern
`if (cond) call assert(.false., label)` is exempt, since its condition sits in the `if`. Exit 1 on any hit."""
import re, sys

OPS = re.compile(r"\.(and|or|not|eqv|neqv|true|false)\.", re.I)
IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")

def args_of(s):
    depth, out, cur, quote = 0, [], '', None
    for ch in s:
        if quote:
            cur += ch
            if ch == quote:
                quote = None
            continue
        if ch in "'\"":
            quote = ch; cur += ch; continue
        if ch == '(':
            depth += 1
        elif ch == ')':
            if depth == 0:
                break
            depth -= 1
        elif ch == ',' and depth == 0:
            out.append(cur); cur = ''; continue
        cur += ch
    out.append(cur)
    return [a.strip() for a in out]

def logical_lines(path):
    buf, start = '', None
    for n, raw in enumerate(open(path, encoding='utf-8').read().split('\n'), 1):
        s = raw.rstrip()
        body = s.lstrip()
        if body.startswith('&'):
            body = body[1:]
        if start is None:
            start = n
        if s.endswith('&'):
            buf += body[:-1] + ' '
            continue
        yield start, buf + body
        buf, start = '', None

def vacuous(cond):
    stripped = re.sub(r"_[a-z0-9]+\b", "", OPS.sub(' ', cond))
    return IDENT.search(stripped) is None

hits = []
for n, line in logical_lines(sys.argv[1]):
    s = line.strip()
    if s.startswith('!'):
        continue
    for form in ('assert', 'check'):
        m = re.search(r"call %s\(" % form, s)
        if not m:
            continue
        a = args_of(s[m.end():])
        cond = a[0] if form == 'assert' else (a[1] if len(a) > 1 else '')
        before = s[:m.start()].strip().lower()
        if cond.lower() == '.false.' and before.startswith('if'):
            continue
        if cond and vacuous(cond):
            hits.append((n, form, cond))
print(f'vacuity lint: {len(hits)} vacuous checks')
for n, form, c in hits:
    print(f'  line {n} ({form}): {c}')
sys.exit(1 if hits else 0)
