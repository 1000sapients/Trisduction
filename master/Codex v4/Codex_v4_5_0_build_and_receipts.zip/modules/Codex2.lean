import Codex1
set_option maxRecDepth 4000000

namespace GEO

structure Q4 where
  r : Int
  i : Int
  j : Int
  k : Int
  deriving DecidableEq, Repr, BEq

def qmul (a b : Q4) : Q4 :=
  ⟨a.r*b.r - a.i*b.i - a.j*b.j - a.k*b.k,
   a.r*b.i + a.i*b.r + a.j*b.k - a.k*b.j,
   a.r*b.j - a.i*b.k + a.j*b.r + a.k*b.i,
   a.r*b.k + a.i*b.j - a.j*b.i + a.k*b.r⟩

def qconj (a : Q4) : Q4 := ⟨a.r, -a.i, -a.j, -a.k⟩
def qadd (a b : Q4) : Q4 := ⟨a.r+b.r, a.i+b.i, a.j+b.j, a.k+b.k⟩
def qsub (a b : Q4) : Q4 := ⟨a.r-b.r, a.i-b.i, a.j-b.j, a.k-b.k⟩
def qnorm2 (a : Q4) : Int := a.r*a.r + a.i*a.i + a.j*a.j + a.k*a.k
def qhalve (a : Q4) : Q4 := ⟨a.r/2, a.i/2, a.j/2, a.k/2⟩
def qquarter (a : Q4) : Q4 := ⟨a.r/4, a.i/4, a.j/4, a.k/4⟩

def qcanon (a : Q4) : Q4 :=
  if a.r != 0 then (if a.r < 0 then ⟨-a.r,-a.i,-a.j,-a.k⟩ else a)
  else if a.i != 0 then (if a.i < 0 then ⟨-a.r,-a.i,-a.j,-a.k⟩ else a)
  else if a.j != 0 then (if a.j < 0 then ⟨-a.r,-a.i,-a.j,-a.k⟩ else a)
  else if a.k != 0 then (if a.k < 0 then ⟨-a.r,-a.i,-a.j,-a.k⟩ else a)
  else a

def q1 : Q4 := ⟨1,0,0,0⟩
def qi : Q4 := ⟨0,1,0,0⟩
def qj : Q4 := ⟨0,0,1,0⟩
def qk : Q4 := ⟨0,0,0,1⟩

theorem chirality : qmul (qmul qi qj) qk = ⟨-1,0,0,0⟩ := rfl

theorem noncommutative : qmul qi qj ≠ qmul qj qi := by decide

def hurwitz : List Q4 :=
  [⟨2,0,0,0⟩,⟨-2,0,0,0⟩,⟨0,2,0,0⟩,⟨0,-2,0,0⟩,
   ⟨0,0,2,0⟩,⟨0,0,-2,0⟩,⟨0,0,0,2⟩,⟨0,0,0,-2⟩,
   ⟨1,1,1,1⟩,⟨1,1,1,-1⟩,⟨1,1,-1,1⟩,⟨1,1,-1,-1⟩,
   ⟨1,-1,1,1⟩,⟨1,-1,1,-1⟩,⟨1,-1,-1,1⟩,⟨1,-1,-1,-1⟩,
   ⟨-1,1,1,1⟩,⟨-1,1,1,-1⟩,⟨-1,1,-1,1⟩,⟨-1,1,-1,-1⟩,
   ⟨-1,-1,1,1⟩,⟨-1,-1,1,-1⟩,⟨-1,-1,-1,1⟩,⟨-1,-1,-1,-1⟩]

theorem hurwitz_norm : (hurwitz.all (fun u => qnorm2 u == 4)) = true := by decide

theorem hurwitz_products_even :
    (hurwitz.all (fun a => hurwitz.all (fun b =>
      let p := qmul a b
      (p.r % 2 == 0) && (p.i % 2 == 0) && (p.j % 2 == 0) && (p.k % 2 == 0)))) = true := by
  decide

theorem hurwitz_closed :
    (hurwitz.all (fun a => hurwitz.all (fun b =>
      hurwitz.any (fun u => u == qhalve (qmul a b))))) = true := by
  decide

def hurwitzReps : List Q4 := (hurwitz.map qcanon).eraseDups

theorem units_mod_sign_twelve : hurwitzReps.length = 12 := by decide

def conjClass (r : Q4) : List Q4 :=
  (hurwitz.map (fun u => qcanon (qquarter (qmul (qmul u r) (qconj u))))).eraseDups

def classSizesAux : List Q4 → List Q4 → List Nat
  | [], _ => []
  | r :: rest, seen =>
    if seen.any (fun s => s == r) then classSizesAux rest seen
    else
      let cls := conjClass r
      cls.length :: classSizesAux rest (seen ++ cls)

def insNat (n : Nat) : List Nat → List Nat
  | [] => [n]
  | m :: ms => if n ≤ m then n :: m :: ms else m :: insNat n ms
def insSort : List Nat → List Nat
  | [] => []
  | n :: ns => insNat n (insSort ns)

theorem class_equation :
    insSort (classSizesAux hurwitzReps []) = [1, 3, 4, 4] := by decide

def shell2 : List Q4 :=
  let v : List Int := [-1, 0, 1]
  (v.flatMap (fun r => v.flatMap (fun i => v.flatMap (fun j =>
    v.map (fun k => ⟨r,i,j,k⟩))))).filter (fun q => qnorm2 q == 2)

theorem shell_twentyfour :
    (shell2.length == 24) &&
    ((shell2.filter (fun q => q.r == 0)).length == 12) &&
    ((shell2.filter (fun q => q.r != 0)).length == 12) = true := by decide

set_option maxRecDepth 8000 in

theorem no_half_integer_norm2 :
    (let v : List Int := [-3, -1, 1, 3]
     (v.flatMap (fun r => v.flatMap (fun i => v.flatMap (fun j =>
       v.map (fun k => ⟨r,i,j,k⟩))))).all (fun q => qnorm2 q != 8)) = true := by
  decide

def allGates : List (Nat × Nat) :=
  [(0,1),(0,2),(0,3),(1,0),(1,2),(1,3),(2,0),(2,1),(2,3),(3,0),(3,1),(3,2)]

theorem gates_twelve : allGates.length = 12 := rfl

theorem gates_valid :
    (allGates.all (fun g => (g.1 != g.2) && (g.1 < 4) && (g.2 < 4))) = true := by decide

theorem gates_complete : ∀ a b : Fin 4, a ≠ b → ((a : Nat), (b : Nat)) ∈ allGates := by
  decide

def invCount (σ : List Nat) : Nat :=
  let idx := List.range σ.length
  let pairs := idx.flatMap (fun a => (idx.filter (fun b => a < b)).map (fun b => (a, b)))
  (pairs.filter (fun p => σ.getD p.1 0 > σ.getD p.2 0)).length

def perms24 : List (List Nat) :=
  [[0,1,2,3],[0,1,3,2],[0,2,1,3],[0,2,3,1],[0,3,1,2],[0,3,2,1],
   [1,0,2,3],[1,0,3,2],[1,2,0,3],[1,2,3,0],[1,3,0,2],[1,3,2,0],
   [2,0,1,3],[2,0,3,1],[2,1,0,3],[2,1,3,0],[2,3,0,1],[2,3,1,0],
   [3,0,1,2],[3,0,2,1],[3,1,0,2],[3,1,2,0],[3,2,0,1],[3,2,1,0]]

def a4 : List (List Nat) := perms24.filter (fun σ => invCount σ % 2 == 0)

theorem a4_order : a4.length = 12 := by decide

def actG (σ : List Nat) (g : Nat × Nat) : Nat × Nat := (σ.getD g.1 0, σ.getD g.2 0)

set_option maxRecDepth 100000 in

theorem a4_simply_transitive :
    ∀ a b c d : Fin 4, a ≠ b → c ≠ d →
      (a4.filter (fun σ => actG σ ((a : Nat), (b : Nat)) == ((c : Nat), (d : Nat)))).length = 1 := by
  decide

def tetraVerts : List Nat := [0, 1, 2, 3]
def tetraEdges : List (Nat × Nat) := [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
def tetraFaces : List (Nat × Nat × Nat) := [(0,1,2),(0,1,3),(0,2,3),(1,2,3)]

theorem euler_closure :
    (tetraVerts.length : Int) - tetraEdges.length + tetraFaces.length = 2 := by decide

def basisU : List Q4 := [qi, qj, qk]

def perms6 : List (List Nat) :=
  [[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]]

theorem relabel_parity :
    (perms6.all (fun σ =>
      (qmul (qmul (basisU.getD (σ.getD 0 0) q1) (basisU.getD (σ.getD 1 0) q1)) (basisU.getD (σ.getD 2 0) q1)).r ==
        (if invCount σ % 2 == 0 then -1 else 1))) = true := by
  decide

abbrev O8 := Q4 × Q4

def omul (x y : O8) : O8 :=
  (qsub (qmul x.1 y.1) (qmul (qconj y.2) x.2),
   qadd (qmul y.2 x.1) (qmul x.2 (qconj y.1)))

def osub (x y : O8) : O8 := (qsub x.1 y.1, qsub x.2 y.2)
def onorm2 (x : O8) : Int := qnorm2 x.1 + qnorm2 x.2

def e8 (n : Nat) : O8 :=
  let q := fun k => if k == n then (1 : Int) else 0
  (⟨q 0, q 1, q 2, q 3⟩, ⟨q 4, q 5, q 6, q 7⟩)

theorem octonion_associator :
    osub (omul (omul (e8 1) (e8 2)) (e8 4)) (omul (e8 1) (omul (e8 2) (e8 4)))
      = (⟨0,0,0,0⟩, ⟨0,0,0,2⟩) := by
  decide

def hPairs : List (Q4 × Q4) :=
  let v : List Int := [-1, 0, 1]
  v.flatMap (fun i => v.flatMap (fun j => v.map (fun k =>
    (⟨i,j,k,1⟩, ⟨1,k,j,i⟩))))

theorem norm_composition_H :
    (hPairs.all (fun p => qnorm2 (qmul p.1 p.2) == qnorm2 p.1 * qnorm2 p.2)) = true := by
  decide

def oPairs : List (O8 × O8) :=
  let v : List Int := [-1, 0, 1]
  v.flatMap (fun i => v.flatMap (fun j => v.map (fun k =>
    ((⟨i,j,k,1⟩, ⟨j,k,i,1⟩), (⟨1,k,i,j⟩, ⟨1,i,j,k⟩)))))

theorem norm_composition_O :
    (oPairs.all (fun p => onorm2 (omul p.1 p.2) == onorm2 p.1 * onorm2 p.2)) = true := by
  decide
  
set_option maxRecDepth 1000000
  def det2 (r1 r2 r3 : Nat × Nat × Nat) : Nat :=
    (r1.1 * (r2.2.1 * r3.2.2 + r2.2.2 * r3.2.1)
       + r1.2.1 * (r2.1 * r3.2.2 + r2.2.2 * r3.1)
       + r1.2.2 * (r2.1 * r3.2.1 + r2.2.1 * r3.1)) % 2
  def gf2Mul (r1 r2 r3 : Nat × Nat × Nat) (v : Nat × Nat × Nat) : Nat × Nat × Nat :=
    ((r1.1 * v.1 + r1.2.1 * v.2.1 + r1.2.2 * v.2.2) % 2,
     (r2.1 * v.1 + r2.2.1 * v.2.1 + r2.2.2 * v.2.2) % 2,
     (r3.1 * v.1 + r3.2.1 * v.2.1 + r3.2.2 * v.2.2) % 2)
  
  def gf2Vecs : List (Nat × Nat × Nat) :=
    (List.range 8).map (fun n => (n / 4 % 2, n / 2 % 2, n % 2))
  def gf2Sols (r1 r2 r3 : Nat × Nat × Nat) (t : Nat × Nat × Nat) : List (Nat × Nat × Nat) :=
    gf2Vecs.filter (fun v => decide (gf2Mul r1 r2 r3 v = t))

  set_option maxRecDepth 1000000 in
  
  theorem triaxial_lock_gf2 :
      ∀ a1 a2 a3 b1 b2 b3 c1 c2 c3 t1 t2 t3 : Fin 2,
        (det2 ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
              ((c1 : Nat), (c2 : Nat), (c3 : Nat)) = 1 ↔
         (gf2Sols ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
                  ((c1 : Nat), (c2 : Nat), (c3 : Nat))
                  ((t1 : Nat), (t2 : Nat), (t3 : Nat))).length = 1) := by
    decide
  
  theorem triaxial_lock_gf2_count :
      ((List.range 4096).filter (fun n =>
        det2 (n / 2048 % 2, n / 1024 % 2, n / 512 % 2)
             (n / 256 % 2, n / 128 % 2, n / 64 % 2)
             (n / 32 % 2, n / 16 % 2, n / 8 % 2) = 1)).length = 1344 := by
    decide
  theorem triaxial_open_gf2_count :
      ((List.range 4096).filter (fun n =>
        det2 (n / 2048 % 2, n / 1024 % 2, n / 512 % 2)
             (n / 256 % 2, n / 128 % 2, n / 64 % 2)
             (n / 32 % 2, n / 16 % 2, n / 8 % 2) = 0)).length = 2752 := by
    decide
  
  abbrev V3 := Ratio × Ratio × Ratio
  abbrev M3 := V3 × V3 × V3

  def det3 (m : M3) : Ratio :=
    let ⟨a, b, c⟩ := m.1
    let ⟨d, e, f⟩ := m.2.1
    let ⟨g, h, i⟩ := m.2.2
    a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)

  
  def adj3 (m : M3) : M3 :=
    let ⟨a, b, c⟩ := m.1
    let ⟨d, e, f⟩ := m.2.1
    let ⟨g, h, i⟩ := m.2.2
    ((e * i - f * h, c * h - b * i, b * f - c * e),
     (f * g - d * i, a * i - c * g, c * d - a * f),
     (d * h - e * g, b * g - a * h, a * e - b * d))

  def mm3 (x y : M3) : M3 :=
    
    
    
    let row (r : V3) (c : Nat) : Ratio :=
      r.1 * (match c with | 0 => y.1.1 | 1 => y.1.2.1 | _ => y.1.2.2)
      + r.2.1 * (match c with | 0 => y.2.1.1 | 1 => y.2.1.2.1 | _ => y.2.1.2.2)
      + r.2.2 * (match c with | 0 => y.2.2.1 | 1 => y.2.2.2.1 | _ => y.2.2.2.2)
    ((row x.1 0, row x.1 1, row x.1 2),
     (row x.2.1 0, row x.2.1 1, row x.2.1 2),
     (row x.2.2 0, row x.2.2 1, row x.2.2 2))

  def diag3 (r : Ratio) : M3 := ((r, 0, 0), (0, r, 0), (0, 0, r))
  def mv3 (m : M3) (v : V3) : V3 :=
    (m.1.1 * v.1 + m.1.2.1 * v.2.1 + m.1.2.2 * v.2.2,
     m.2.1.1 * v.1 + m.2.1.2.1 * v.2.1 + m.2.1.2.2 * v.2.2,
     m.2.2.1 * v.1 + m.2.2.2.1 * v.2.1 + m.2.2.2.2 * v.2.2)
  def vscale (v : V3) (r : Ratio) : V3 := (v.1 * r, v.2.1 * r, v.2.2 * r)

  
  abbrev V3Z := Int × Int × Int
  abbrev M3Z := V3Z × V3Z × V3Z
  def det3Z (m : M3Z) : Int :=
    let ⟨a, b, c⟩ := m.1; let ⟨d, e, f⟩ := m.2.1; let ⟨g, h, i⟩ := m.2.2
    a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
  def adj3Z (m : M3Z) : M3Z :=
    let ⟨a, b, c⟩ := m.1; let ⟨d, e, f⟩ := m.2.1; let ⟨g, h, i⟩ := m.2.2
    ((e * i - f * h, c * h - b * i, b * f - c * e),
     (f * g - d * i, a * i - c * g, c * d - a * f),
     (d * h - e * g, b * g - a * h, a * e - b * d))
  def mm3Z (x y : M3Z) : M3Z :=
    let row (r : V3Z) (c : Nat) : Int :=
      r.1 * (match c with | 0 => y.1.1 | 1 => y.1.2.1 | _ => y.1.2.2)
      + r.2.1 * (match c with | 0 => y.2.1.1 | 1 => y.2.1.2.1 | _ => y.2.1.2.2)
      + r.2.2 * (match c with | 0 => y.2.2.1 | 1 => y.2.2.2.1 | _ => y.2.2.2.2)
    ((row x.1 0, row x.1 1, row x.1 2),
     (row x.2.1 0, row x.2.1 1, row x.2.1 2),
     (row x.2.2 0, row x.2.2 1, row x.2.2 2))
  def diag3Z (r : Int) : M3Z := ((r, 0, 0), (0, r, 0), (0, 0, r))

  theorem adjugate_identity_int (m : M3Z) :
      mm3Z m (adj3Z m) = diag3Z (det3Z m) ∧ mm3Z (adj3Z m) m = diag3Z (det3Z m) := by
    obtain ⟨⟨a, b, c⟩, ⟨d, e, f⟩, ⟨g, h, i⟩⟩ := m
    simp only [mm3Z, adj3Z, det3Z, diag3Z, Prod.mk.injEq]
    simp only [Int.mul_sub, Int.sub_mul, Int.mul_assoc]
    refine ⟨⟨⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩⟩, ⟨⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩⟩⟩ <;>
      (try simp only [Int.mul_comm, Int.mul_left_comm]) <;> omega

  
  def AdjugateIdentity3 : Prop :=
    ∀ m : M3, mm3 m (adj3 m) = diag3 (det3 m) ∧ mm3 (adj3 m) m = diag3 (det3 m)

  
  def adj3Samples : List M3 :=
    [((1, 0, 0), (0, 1, 0), (0, 0, 1)),
     ((2, 0, 0), (0, 3, 0), (0, 0, 5)),
     ((1, 2, 3), (4, 5, 6), (7, 8, 9)),
     ((1, 2, 0), (0, 1, 1), (2, 0, 1)),
     ((0, 1, 2), (3, 4, 5), (6, 7, 9)),
     ((2, 1, 1), (1, 2, 1), (1, 1, 2))]
  theorem adj3_executed :
      adj3Samples.all (fun m =>
        decide (mm3 m (adj3 m) = diag3 (det3 m) ∧
                mm3 (adj3 m) m = diag3 (det3 m))) = true := by
    decide

  
  def cramerSolve (m : M3) (t : V3) : Option V3 :=
    if det3 m == 0 then none
    else some (vscale (mv3 (adj3 m) t) (Ratio.inv (det3 m)))
  theorem cramer_executed :
      cramerSolve ((1, 2, 0), (0, 1, 1), (2, 0, 1)) (5, 3, 4)
        = some ((7 : Ratio) / 5, (9 : Ratio) / 5, (6 : Ratio) / 5) ∧
      mv3 ((1, 2, 0), (0, 1, 1), (2, 0, 1)) ((7 : Ratio) / 5, (9 : Ratio) / 5, (6 : Ratio) / 5)
        = (5, 3, 4) := by
    decide

  
  inductive LockState : Type
    | lock | opn | broken
    deriving DecidableEq, Repr, BEq
  inductive GolToken : Type
    | golX | golQ | golOK
    deriving DecidableEq, Repr, BEq

  
  def golAdmit (magnitude ling : LockState) : GolToken × String × Nat :=
    match magnitude with
    | .broken => (.golX, "geometric/math magnitude reports broken geometry; no GOL", 1)
    | .opn => (.golQ, "no geometric/math lock: orthogonal volume unestablished", 2)
    | .lock =>
      match ling with
      | .lock => (.golOK, "magnitude plus direction; proceed to witness and asymmetry", 4)
      | _ => (.golQ, "magnitude locks but Seal L open: determinant carries no direction", 3)
  
  def gateNames : List String :=
    ["SREP", "REG", "SGEG", "CAUSAL", "MIG", "PTB",
     "DUAL", "CSCG", "CSEG", "MTA", "OMA", "ADEG"]
  theorem gateNames_twelve : gateNames.length = 12 := rfl

  
  def gateScreenGo : List String → List Bool → Nat → Bool × String × Nat
    | [], [], _ => (true, "[G-OK] twelve directed gates passed", 0)
    | n :: _, false :: _, k => (false, s!"[X] gate {k} failed: {n}", k)
    | _ :: ns, true :: bs, k => gateScreenGo ns bs (k + 1)
    | _, _, _ => (false, "[X] arity violation: the screen reads exactly twelve gates", 0)

  def gateScreen (passes : List Bool) : Bool × String × Nat :=
    gateScreenGo gateNames passes 1

  theorem gateScreen_clean :
      gateScreen (List.replicate 12 true)
        = (true, "[G-OK] twelve directed gates passed", 0) := by
    decide
  theorem gateScreen_first_failure :
      gateScreen (false :: List.replicate 11 true)
        = (false, "[X] gate 1 failed: SREP", 1) := by
    decide
  theorem gateScreen_names_failed_gate :
      gateScreen (List.replicate 6 true ++ false :: List.replicate 5 true)
        = (false, "[X] gate 7 failed: DUAL", 7) := by
    decide
  theorem gateScreen_arity :
      gateScreen (List.replicate 11 true)
        = (false, "[X] arity violation: the screen reads exactly twelve gates", 0) := by
    decide

  
  inductive RAVerdict : Type
    | refused | iii | ii | void | aGivenRA | opn
    deriving DecidableEq, Repr, BEq

  
  structure ClaimInputRA where
    nonvacuous  : Audit.Ans
    veLive      : Audit.Ans
    forward     : Audit.Ans
    populated   : Audit.Ans
    worldlyRow  : Audit.Ans
    termsClosed : Audit.Ans
    termWorldly : Audit.Ans
    frameClosed : Audit.Ans
    annotate    : Audit.Ans
    deriving Repr

  def ClaimInputRA.anyUnknown (i : ClaimInputRA) : Bool :=
    [i.nonvacuous, i.veLive, i.forward, i.populated, i.worldlyRow,
     i.termsClosed, i.termWorldly, i.frameClosed, i.annotate].any
      (· == Audit.Ans.unknown)

  
  def rowCascadeRACore
      (nonvacuous veLive forward populated worldlyRow
       termsClosed termWorldly frameClosed annotate : Bool) :
      RAVerdict × String × Nat :=
    if !nonvacuous then
      (.refused, "F-0: contentless; a contentless residence verifies nothing", 1)
    else if veLive || forward then
      (.iii, "R-3: V_E live or Forward; world-rowed, revisability in the rows", 3)
    else if !populated then
      (.ii, "S-1: third axis unpopulated; two planes meet in a line, no lock", 2)
    else if worldlyRow then
      (.iii, "S-2: a load-bearing row is furnished by the world", 3)
    else if !termsClosed then
      if termWorldly then (.iii, "S-3: an unclosed term is worldly", 3)
      else (.ii, "S-3: an unclosed term is formal; no closure-rowed lock", 2)
    else if !frameClosed then
      (.iii, "S-4: existential import leaks past the closure", 3)
    else if !annotate then
      (.void, "RA rider absent: an unannotated absolute is void", 5)
    else
      (.aGivenRA, "compartment I, closure-rowed: [seal A . RA], conditional at the act", 4)

  
  def rowCascadeRA (i : ClaimInputRA) : RAVerdict × String × Nat :=
    if i.anyUnknown then
      (.opn, "nullity law: an unanswered gate routes open; the answer is never guessed", 0)
    else
      rowCascadeRACore i.nonvacuous.toBool i.veLive.toBool i.forward.toBool
        i.populated.toBool i.worldlyRow.toBool i.termsClosed.toBool
        i.termWorldly.toBool i.frameClosed.toBool i.annotate.toBool

  
  theorem unknown_routes_open_ra :
      ∀ i : ClaimInputRA, i.anyUnknown = true → (rowCascadeRA i).1 = .opn := by
    intro i h
    simp [rowCascadeRA, h]

  
  def raDecode (n : Nat) : RAVerdict × String × Nat :=
    rowCascadeRACore (n.testBit 8) (n.testBit 7) (n.testBit 6) (n.testBit 5)
      (n.testBit 4) (n.testBit 3) (n.testBit 2) (n.testBit 1) (n.testBit 0)

  
  def raBattery : List (Nat × RAVerdict) :=
    [(299, .aGivenRA), (443, .iii), (267, .ii), (298, .void), (43, .refused),
     (363, .iii), (315, .iii), (295, .iii), (291, .ii), (297, .iii)]
  theorem ra_battery_f2 :
      raBattery.all (fun p => decide ((raDecode p.1).1 = p.2)) = true := by
    decide

  
  theorem ra_ledger_refused :
      ((List.range 512).filter (fun n => decide ((raDecode n).1 = .refused))).length = 256 := by
    decide
  theorem ra_ledger_iii :
      ((List.range 512).filter (fun n => decide ((raDecode n).1 = .iii))).length = 216 := by
    decide
  theorem ra_ledger_ii :
      ((List.range 512).filter (fun n => decide ((raDecode n).1 = .ii))).length = 36 := by
    decide
  theorem ra_ledger_void :
      ((List.range 512).filter (fun n => decide ((raDecode n).1 = .void))).length = 2 := by
    decide
  theorem ra_ledger_aGivenRA :
      ((List.range 512).filter (fun n => decide ((raDecode n).1 = .aGivenRA))).length = 2 := by
    decide

  
  def RAVerdict.toToken : RAVerdict → Audit.Token
    | .refused => .refused
    | .iii => .determined
    | .ii => .determined
    | .void => .void
    | .aGivenRA => .aGivenRA
    | .opn => .opn

  
  def GolToken.toToken : GolToken → Audit.Token
    | .golX => .broken
    | .golQ => .opn
    | .golOK => .golok

  
  def gateScreenToken (r : Bool × String × Nat) : Audit.Token :=
    if r.1 then .gok else .broken

  
  def demoInputA : ClaimInputRA :=
    { nonvacuous := .yes, veLive := .no, forward := .no, populated := .yes,
      worldlyRow := .no, termsClosed := .yes, termWorldly := .no,
      frameClosed := .yes, annotate := .yes }
  def demoInputVoid : ClaimInputRA := { demoInputA with annotate := .no }
  def demoInputOpen : ClaimInputRA := { demoInputA with termsClosed := .unknown }

  #eval golAdmit .lock .lock
  #eval golAdmit .broken .lock
  #eval golAdmit .opn .lock
  #eval golAdmit .lock .opn
  #eval gateScreen (List.replicate 12 true)
  #eval gateScreen (List.replicate 6 true ++ false :: List.replicate 5 true)
  #eval rowCascadeRA demoInputA
  #eval rowCascadeRA demoInputVoid
  #eval rowCascadeRA demoInputOpen
  #eval cramerSolve ((1, 2, 0), (0, 1, 1), (2, 0, 1)) (5, 3, 4)

end GEO
