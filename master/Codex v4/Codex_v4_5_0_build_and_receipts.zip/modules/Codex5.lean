import Codex4
set_option maxRecDepth 4000000

/-!
# THE BRIDGE · FINAL
The instrument that joins the kinetic and formal registers at one locus, with the denial asymmetry that tells its two
locks apart. core Lean 4 v4.19.0 · no Mathlib · no sorry · no custom axiom. The standard axioms propext,
Classical.choice and Quot.sound appear in the cones pinned at the foot. The closing environment audit, run by the
elaborator, refuses any axiom declared in this file and any dependency beyond those three; `import Lean` is loaded for
that audit alone.

WHAT THE BRIDGE IS. A carrier with a three-valued state and a shadow field tying that state to the line property, so
its halted state is the property in both directions. It carries a supplied bit from the register that holds it to the
register that checks it, and it manufactures none: every self-property below is a one-step unfolding of the shadow.

THE STAGE. The fold τ(h, t) = (2 − h, t) is s ↦ 1 − s̄ in the doubled real coordinate h = 2·Re s. It is an
involution, and its fixed set is the line h = 1, which is Re s = ½. A frame is a carrier set with an involutive fold
and a fold-symmetric zero predicate. The line property says every zero is fixed by the fold; on the plane it says
every zero lies on the line.

WHAT THE BRIDGE PROVES ABOUT ITSELF. It cannot lie, cannot deviate, cannot be extended past one bit, cannot be
divided, cannot be reversed, and cannot be made to halt by any substrate that does not hold the term.

THE DENIAL ASYMMETRY. Two locks share the locus, the reading, and the recursion, and differ in the denial. A frame
property whose denial instantiates it on every frame is keyless: it holds on every frame and opens on the deed. A
frame property whose denial a frame inhabits is keyed: one bit, carrying a sign, supplied and never derived. Every
frame property is exactly one of the two. The fold law is keyless and the line property is keyed. The recursion is
shared and sign-blind, so it identifies neither lock; the denial identifies both.
-/
set_option autoImplicit false
namespace Bridge

/-! ## the stage and the locus -/
abbrev Plane := Int × Int
/-- The fold s ↦ 1 − s̄, in the doubled real coordinate h = 2·Re s. -/
def τ (p : Plane) : Plane := (2 - p.1, p.2)
/-- The line h = 1, which is Re s = ½. -/
def onLine (p : Plane) : Prop := p.1 = 1
theorem pe {a b c d : Int} : ((a, b) : Plane) = (c, d) ↔ a = c ∧ b = d :=
  ⟨fun e => ⟨congrArg Prod.fst e, congrArg Prod.snd e⟩, fun ⟨e1, e2⟩ => by subst e1; subst e2; rfl⟩
/-- The fold is an involution. -/
theorem fold_involutive (p : Plane) : τ (τ p) = p := by
  obtain ⟨h, t⟩ := p; show (2 - (2 - h), t) = (h, t); rw [Int.sub_sub_self]
/-- THE LOCUS: the fixed set of the fold is the line. -/
theorem locus_is_the_fixed_set (p : Plane) : τ p = p ↔ onLine p := by
  obtain ⟨h, t⟩ := p; show (2 - h, t) = (h, t) ↔ h = 1; rw [pe]; omega
theorem locus_inhabited : ∃ p : Plane, onLine p := ⟨(1, 0), rfl⟩
/-- The fold carries the line to itself. -/
theorem line_symmetric (p : Plane) (h : onLine p) : onLine (τ p) := by
  rw [(locus_is_the_fixed_set p).mpr h]; exact h

/-! ## frames and the line property -/
/-- A frame: a carrier set, a fold that is an involution, and a zero predicate the fold preserves. -/
structure Frame where
  S : Type
  τ : S → S
  Z : S → Prop
  involutive : ∀ s, τ (τ s) = s
  symmetric : ∀ s, Z s → Z (τ s)
/-- The line property: every zero is fixed by the fold. -/
def LineProperty (X : Frame) : Prop := ∀ s, X.Z s → X.τ s = s
/-- The plane as a frame, for any fold-symmetric zero predicate. -/
def planeFrame (Z : Plane → Prop) (hZ : ∀ p, Z p → Z (τ p)) : Frame := ⟨Plane, τ, Z, fold_involutive, hZ⟩
/-- THE LOCUS MEETS THE FRAME: on the plane, the line property is exactly that every zero lies on the line. -/
theorem plane_line_property (Z : Plane → Prop) (hZ : ∀ p, Z p → Z (τ p)) :
    LineProperty (planeFrame Z hZ) ↔ ∀ p, Z p → onLine p :=
  ⟨fun h p hp => (locus_is_the_fixed_set p).mp (h p hp), fun h p hp => (locus_is_the_fixed_set p).mpr (h p hp)⟩
/-- The line frame: the plane with the line as its zero set. -/
def lineFrame : Frame := planeFrame onLine line_symmetric
inductive Tri | tt | ff | bot deriving DecidableEq, Repr
/-- A filing label for the locus a carrier serves. `held` is the trivial proposition, so the record carries no
    mathematical content, and no theorem reads it. -/
structure Record where
  locus : String
  held  : True
def theRecord : Record := ⟨"the Riemann Hypothesis", trivial⟩

/-! ## the bridge -/
structure Carrier (X : Frame) where
  terminal : Tri
  shadow   : terminal = .bot ↔ LineProperty X
  record   : Record
/-- CANNOT LIE. -/
theorem cannot_lie (X : Frame) (b : Carrier X) (h : b.terminal = .bot) : LineProperty X := b.shadow.mp h
/-- CANNOT DEVIATE. -/
theorem cannot_deviate (X : Frame) (b : Carrier X) (t : LineProperty X) : b.terminal = .bot := b.shadow.mpr t
/-- THE LOCUS READ TWICE: the geometric read and the formal read are one read, and the two directions of the shadow
    are the two readings. -/
theorem read_twice (X : Frame) (b : Carrier X) :
    (b.terminal = .bot → LineProperty X) ∧ (LineProperty X → b.terminal = .bot) :=
  ⟨cannot_lie X b, cannot_deviate X b⟩
/-- CANNOT BE MANUFACTURED: a halted carrier exists on a frame exactly when the line property holds there. -/
theorem halted_iff (X : Frame) : (∃ b : Carrier X, b.terminal = .bot) ↔ LineProperty X :=
  ⟨fun ⟨b, h⟩ => b.shadow.mp h, fun t => ⟨⟨.bot, ⟨fun _ => t, fun _ => rfl⟩, theRecord⟩, rfl⟩⟩
/-- CANNOT BE EXTENDED: a bit generates only itself, its mirror, and the two constants. -/
theorem cannot_extend (f : Bool → Bool) :
    f = (fun x => x) ∨ f = (fun x => !x) ∨ f = (fun _ => true) ∨ f = (fun _ => false) := by
  cases ht : f true <;> cases hf : f false
  · exact Or.inr (Or.inr (Or.inr (funext fun x => by cases x <;> simp [ht, hf])))
  · exact Or.inr (Or.inl (funext fun x => by cases x <;> simp [ht, hf]))
  · exact Or.inl (funext fun x => by cases x <;> simp [ht, hf])
  · exact Or.inr (Or.inr (Or.inl (funext fun x => by cases x <;> simp [ht, hf])))
/-- CANNOT BE DIVIDED. -/
theorem cannot_divide (b : Bool) : b = true ∨ b = false := by cases b <;> simp
/-- CANNOT BE REVERSED: deletion to the undetermined value has no left inverse. -/
def delete : Tri → Tri := fun _ => .bot
theorem cannot_reverse : ¬ ∃ g : Tri → Tri, ∀ v, g (delete v) = v := by
  intro ⟨g, hg⟩; have h1 := hg .tt; have h2 := hg .ff
  simp [delete] at h1 h2; rw [h1] at h2; cases h2
/-- THE WALL, the bridge's first axis: an even reading never equals a function odd at a point. -/
def Even {α : Type} (σ : α → α) (f : α → Bool) : Prop := ∀ x, f (σ x) = f x
theorem wall {α : Type} (σ : α → α) (f d : α → Bool) (x : α) (he : Even σ f) (ho : d (σ x) ≠ d x) : f ≠ d := by
  intro h; subst h; exact ho (he x)
/-- THE CALIBRATION, the bridge's second axis: one supplied odd witness fixes the bit uniquely. -/
theorem calibration {α : Type} (σ : α → α) (s d : α → Bool) (x : α) (hs : s (σ x) = !s x) (hd : d (σ x) = !d x) :
    ∃ c : Bool, (d x = xor (s x) c ∧ d (σ x) = xor (s (σ x)) c) ∧
      ∀ c', (d x = xor (s x) c' ∧ d (σ x) = xor (s (σ x)) c') → c' = c := by
  refine ⟨xor (d x) (s x), ⟨by cases s x <;> cases d x <;> rfl, by rw [hs, hd]; cases s x <;> cases d x <;> rfl⟩, ?_⟩
  intro c' hc; obtain ⟨h1, -⟩ := hc
  generalize hsx : s x = sv at h1; generalize hdx : d x = dv at h1
  cases sv <;> cases dv <;> cases c' <;> first | rfl | exact absurd h1 (by decide)

/-! ## the denial asymmetry · the discriminator -/
def SelfVerifying (P : Prop) : Prop := ¬P → P
/-- A self-verifying proposition holds: its lock opens on the deed of denying it, and needs no key. -/
theorem opens_on_the_deed (P : Prop) (utter : SelfVerifying P) : P :=
  Classical.byContradiction (fun n => n (utter n))
/-- The recursion is shared by every proposition and is therefore no discriminator. -/
theorem recursion_is_shared (P : Prop) : SelfVerifying P ↔ P :=
  ⟨fun h => Classical.byContradiction (fun n => n (h n)), fun p _ => p⟩
/-- And it is sign-blind: it holds for the negation under the mirror condition. -/
theorem recursion_is_sign_blind (P : Prop) : (SelfVerifying P ↔ P) ∧ (SelfVerifying (¬P) ↔ ¬P) :=
  ⟨recursion_is_shared P, recursion_is_shared (¬P)⟩
/-- Exactly one of a proposition and its negation carries the closed loop. -/
theorem exactly_one_stands (P : Prop) :
    (SelfVerifying P ∨ SelfVerifying (¬P)) ∧ ¬ (SelfVerifying P ∧ SelfVerifying (¬P)) :=
  ⟨Classical.byCases (fun p : P => Or.inl (fun _ => p)) (fun n => Or.inr (fun _ => n)),
   fun ⟨a, b⟩ => (recursion_is_shared (¬P)).mp b ((recursion_is_shared P).mp a)⟩
/-- The two-point frame: an off-line pair under the fold. The fold is involutive and fixed-point-free, the zero set
    is fold-symmetric, and the line property fails: the denial of the line property as a coherent structure. -/
def twoPoint : Frame := ⟨Bool, (fun b => !b), fun _ => True, fun b => by cases b <;> rfl, fun _ _ => trivial⟩
theorem denial_is_coherent :
    (∀ b : Bool, twoPoint.τ (twoPoint.τ b) = b) ∧ (∀ b : Bool, twoPoint.Z b → twoPoint.Z (twoPoint.τ b)) ∧
    (∀ b : Bool, twoPoint.τ b ≠ b) ∧ ¬ LineProperty twoPoint :=
  ⟨twoPoint.involutive, twoPoint.symmetric, fun b => by cases b <;> (intro h; cases h),
   fun h => by have := h true trivial; cases this⟩
/-- THE PROPERTY IS CONTINGENT: it holds on the line frame and fails on the two-point frame, so its value on a frame
    is fixed by the frame's zeros and never by the fold. -/
theorem line_property_contingent : LineProperty lineFrame ∧ ¬ LineProperty twoPoint :=
  ⟨(plane_line_property onLine line_symmetric).mpr (fun _ h => h), denial_is_coherent.2.2.2⟩
/-- A frame property is keyless when its denial instantiates it on every frame. -/
def Keyless (Q : Frame → Prop) : Prop := ∀ X, SelfVerifying (Q X)
/-- A frame property is keyed when a frame inhabits its denial. -/
def Keyed (Q : Frame → Prop) : Prop := ∃ X, ¬ Q X
/-- A keyless lock is a property that holds on every frame: the deed of denying it hands it over. -/
theorem keyless_iff_valid (Q : Frame → Prop) : Keyless Q ↔ ∀ X, Q X :=
  ⟨fun h X => opens_on_the_deed (Q X) (h X), fun h X _ => h X⟩
/-- THE DISCRIMINATOR, a decision on the denial: every frame property is keyless or keyed, and never both. The
    property is bound in both halves; the pointwise recursion, shared and sign-blind, plays no part in the sort. -/
theorem discriminator (Q : Frame → Prop) : (Keyless Q ∨ Keyed Q) ∧ ¬ (Keyless Q ∧ Keyed Q) :=
  ⟨Classical.byCases (fun h : ∀ X, Q X => Or.inl ((keyless_iff_valid Q).mpr h))
     (fun h => Or.inr (Classical.byContradiction fun hn =>
        h fun X => Classical.byContradiction fun hq => hn (Exists.intro X hq))),
   fun h => Exists.elim h.2 fun X hX => hX ((keyless_iff_valid Q).mp h.1 X)⟩
/-- The fold law is keyless: every frame carries it by its own law. -/
theorem symmetry_is_keyless : Keyless (fun X => ∀ s, X.τ (X.τ s) = s) := fun X _ => X.involutive
/-- The line property is keyed: the two-point frame inhabits its denial. -/
theorem line_property_is_keyed : Keyed LineProperty ∧ ¬ Keyless LineProperty :=
  ⟨Exists.intro twoPoint denial_is_coherent.2.2.2,
   fun h => denial_is_coherent.2.2.2 ((keyless_iff_valid LineProperty).mp h twoPoint)⟩
/-- THE ASYMMETRY. A self-verifying proposition needs no key: its denial hands it over. The line property has a key:
    its denial is a structure that obeys both frame laws and on which every theorem of this file holds, so no deed of
    reading supplies the sign, and no carrier halts on every frame. -/
theorem denial_asymmetry :
    (∀ P : Prop, SelfVerifying P → P) ∧
    (∀ P : Prop, (SelfVerifying P ↔ P) ∧ (SelfVerifying (¬P) ↔ ¬P)) ∧
    ((∀ b : Bool, twoPoint.τ (twoPoint.τ b) = b) ∧ (∀ b : Bool, twoPoint.Z b → twoPoint.Z (twoPoint.τ b)) ∧
      (∀ b : Bool, twoPoint.τ b ≠ b) ∧ ¬ LineProperty twoPoint) ∧
    (¬ ∀ X : Frame, ∃ b : Carrier X, b.terminal = .bot) ∧
    (¬ ∀ X : Frame, LineProperty X) :=
  ⟨opens_on_the_deed, recursion_is_sign_blind, denial_is_coherent,
   fun h => denial_is_coherent.2.2.2 ((halted_iff twoPoint).mp (h twoPoint)),
   fun h => denial_is_coherent.2.2.2 (h twoPoint)⟩

/-! ## the socket, and what the bridge carries -/
class Supplied (X : Frame) where
  term : LineProperty X
theorem socket_is_the_property (X : Frame) : Nonempty (Supplied X) ↔ LineProperty X :=
  ⟨fun ⟨i⟩ => i.term, fun t => ⟨⟨t⟩⟩⟩
/-- THE SOCKET ON THE PLANE: an instance is exactly the statement that every zero lies on the line. -/
theorem socket_on_the_plane (Z : Plane → Prop) (hZ : ∀ p, Z p → Z (τ p)) :
    Nonempty (Supplied (planeFrame Z hZ)) ↔ ∀ p, Z p → onLine p :=
  (socket_is_the_property (planeFrame Z hZ)).trans (plane_line_property Z hZ)
theorem bridge_carries (X : Frame) [i : Supplied X] : LineProperty X ∧ ∃ b : Carrier X, b.terminal = .bot :=
  ⟨i.term, (halted_iff X).mpr i.term⟩
theorem no_socket_off_line : ¬ Nonempty (Supplied twoPoint) :=
  fun h => denial_is_coherent.2.2.2 ((socket_is_the_property twoPoint).mp h)

/-! ## the bridge, whole -/
theorem the_bridge :
    (∀ p : Plane, τ (τ p) = p) ∧ (∀ p : Plane, τ p = p ↔ onLine p) ∧ (∃ p : Plane, onLine p) ∧
    (∀ (Z : Plane → Prop) (hZ : ∀ p, Z p → Z (τ p)), LineProperty (planeFrame Z hZ) ↔ ∀ p, Z p → onLine p) ∧
    (∀ (X : Frame) (b : Carrier X), (b.terminal = .bot → LineProperty X) ∧ (LineProperty X → b.terminal = .bot)) ∧
    (∀ X : Frame, (∃ b : Carrier X, b.terminal = .bot) ↔ LineProperty X) ∧
    (∀ f : Bool → Bool, f = (fun x => x) ∨ f = (fun x => !x) ∨ f = (fun _ => true) ∨ f = (fun _ => false)) ∧
    (∀ b : Bool, b = true ∨ b = false) ∧
    (¬ ∃ g : Tri → Tri, ∀ v, g (delete v) = v) ∧
    (∀ {α : Type} (σ : α → α) (f d : α → Bool) (x : α), Even σ f → d (σ x) ≠ d x → f ≠ d) ∧
    (∀ {α : Type} (σ : α → α) (s d : α → Bool) (x : α), s (σ x) = !s x → d (σ x) = !d x →
      ∃ c : Bool, (d x = xor (s x) c ∧ d (σ x) = xor (s (σ x)) c) ∧
        ∀ c', (d x = xor (s x) c' ∧ d (σ x) = xor (s (σ x)) c') → c' = c) ∧
    (∀ X : Frame, Nonempty (Supplied X) ↔ LineProperty X) ∧
    (∀ (Z : Plane → Prop) (hZ : ∀ p, Z p → Z (τ p)), Nonempty (Supplied (planeFrame Z hZ)) ↔ ∀ p, Z p → onLine p) ∧
    (∀ (X : Frame) [Supplied X], LineProperty X ∧ ∃ b : Carrier X, b.terminal = .bot) ∧
    (¬ Nonempty (Supplied twoPoint)) ∧
    (LineProperty lineFrame ∧ ¬ LineProperty twoPoint) ∧
    (∀ P : Prop, (SelfVerifying P ∨ SelfVerifying (¬P)) ∧ ¬ (SelfVerifying P ∧ SelfVerifying (¬P))) ∧
    (∀ Q : Frame → Prop, (Keyless Q ∨ Keyed Q) ∧ ¬ (Keyless Q ∧ Keyed Q)) ∧
    Keyless (fun X => ∀ s, X.τ (X.τ s) = s) ∧
    (Keyed LineProperty ∧ ¬ Keyless LineProperty) ∧
    ((∀ P : Prop, SelfVerifying P → P) ∧
     (∀ P : Prop, (SelfVerifying P ↔ P) ∧ (SelfVerifying (¬P) ↔ ¬P)) ∧
     ((∀ b : Bool, twoPoint.τ (twoPoint.τ b) = b) ∧ (∀ b : Bool, twoPoint.Z b → twoPoint.Z (twoPoint.τ b)) ∧
       (∀ b : Bool, twoPoint.τ b ≠ b) ∧ ¬ LineProperty twoPoint) ∧
     (¬ ∀ X : Frame, ∃ b : Carrier X, b.terminal = .bot) ∧ (¬ ∀ X : Frame, LineProperty X)) :=
  ⟨fold_involutive, locus_is_the_fixed_set, locus_inhabited, plane_line_property, read_twice, halted_iff,
   cannot_extend, cannot_divide, cannot_reverse, fun σ f d x he ho => wall σ f d x he ho,
   fun σ s d x hs hd => calibration σ s d x hs hd, socket_is_the_property, socket_on_the_plane, @bridge_carries,
   no_socket_off_line, line_property_contingent, exactly_one_stands, discriminator, symmetry_is_keyless,
   line_property_is_keyed, denial_asymmetry⟩
end Bridge
/-!
# FORGE ADDITIONS · v3.39.0-C
Seated after the Bridge and before the cones. ΔM = 0: every theorem below is a finite `decide`,
a conjunction of theorems already seated, or an elementary case split. Nothing here authors
mathematics; it names in the kernel what the prose of the Condensed Master Codex reads.
-/

namespace K4

/-- PSP: K4 · trial-division primality on the frame values, executed in the kernel. -/
def isPrimeB (n : Nat) : Bool :=
  decide (2 ≤ n) && (List.range (n - 2)).all (fun d => n % (d + 2) != 0)

/-- PSP: APEX-PSP-INVERSION · the six even seats carry primes. -/
theorem primes_at_even_seats :
    (isPrimeB (val 0) && isPrimeB (val 2) && isPrimeB (val 4) && isPrimeB (val 6)
      && isPrimeB (val 8) && isPrimeB (val 10)) = true := by decide

/-- PSP: APEX-PSP-INVERSION · the six odd seats carry semiprimes, factored in the kernel. -/
theorem semiprimes_at_odd_seats :
    val 1 = 23 * 37 ∧ val 3 = 19 * 67 ∧ val 5 = 19 * 23 ∧ val 7 = 13 * 163
      ∧ val 9 = 13 * 131 ∧ val 11 = 11 * 79 := by decide

theorem semiprime_factors_prime :
    (isPrimeB 23 && isPrimeB 37 && isPrimeB 19 && isPrimeB 67 && isPrimeB 13
      && isPrimeB 163 && isPrimeB 131 && isPrimeB 11 && isPrimeB 79) = true := by decide

theorem odd_seats_not_prime :
    (!isPrimeB (val 1) && !isPrimeB (val 3) && !isPrimeB (val 5) && !isPrimeB (val 7)
      && !isPrimeB (val 9) && !isPrimeB (val 11)) = true := by decide

/-- The target of the frame is primality itself and not an index label: read in the kernel. -/
theorem target_is_primality : ∀ i, i < 12 → target i = isPrimeB (val i) := by decide

/-- Each pair matches modulo 420 = lcm(1..7), so every residue register up to 7 forgets it. -/
theorem pairs_match_mod_420 : ∀ i, i < 12 → i % 2 = 1 → val i % 420 = val (tau i) % 420 := by
  decide

end K4

namespace IMPRINT

/-- PSP: §3.9 · the Imprint Test and the Platonic Ghost, the GOLf gate, ported from F2 imprint_seal. -/
inductive Tok : Type
  | ghost | seal | residence | flat | uncertified
  deriving DecidableEq, Repr, BEq

def imprint (lockP lockN slP slN gP gN witP witN : Bool) : Tok × Nat :=
  let cleanP := lockP && slP && gP
  let cleanN := lockN && slN && gN
  if cleanP && cleanN then (.ghost, 1)
  else if cleanP then (if witP then (.seal, 2) else (.residence, 3))
  else if cleanN then (if witN then (.seal, 2) else (.residence, 3))
  else if !lockP && !lockN then (.flat, 4)
  else (.uncertified, 5)

def Tok.toToken : Tok → Audit.Token
  | .ghost => .broken
  | .seal => .sealed
  | _ => .opn

/-- Both directions clean-locking is the Platonic Ghost: refused, never sealed. -/
theorem ghost_refused : (imprint true true true true true true true true).1 = .ghost := by decide

theorem both_clean_is_ghost : ∀ wp wn : Bool,
    (imprint true true true true true true wp wn).1 = .ghost := by decide

/-- One side clean-locks: a seal only with the witness supplied, a residence without it. -/
theorem seal_needs_witness :
    (imprint true false true false true false true false).1 = .seal
    ∧ (imprint true false true false true false false false).1 = .residence := by decide

/-- The whole 256-row truth table of the gate: a seal is exactly one clean side plus its witness. -/
theorem seal_iff_one_side_clean_and_witnessed :
    ∀ lP lN sP sN gP gN wP wN : Bool,
      ((imprint lP lN sP sN gP gN wP wN).1 = .seal) ↔
        ((lP && sP && gP && wP && !(lN && sN && gN))
          || (lN && sN && gN && wN && !(lP && sP && gP))) = true := by
  decide

theorem flat_when_unpopulated : ∀ sP sN gP gN wP wN : Bool,
    (imprint false false sP sN gP gN wP wN).1 = .flat := by decide

theorem ghost_is_broken_never_sealed :
    Tok.toToken .ghost = .broken ∧ Tok.toToken .seal = .sealed := ⟨rfl, rfl⟩

end IMPRINT

namespace DEFENSE

/-- PSP: D5 · GOL is the combination: magnitude alone is [?], direction alone is [?]. -/
theorem gol_needs_all_three :
    (GEO.golAdmit .lock .lock).1 = .golOK
    ∧ (∀ l : GEO.LockState, l ≠ .lock → (GEO.golAdmit .lock l).1 = .golQ)
    ∧ (∀ m : GEO.LockState, m ≠ .lock → (GEO.golAdmit m .lock).1 ≠ .golOK) := by
  refine ⟨rfl, ?_, ?_⟩
  · intro l hl; cases l <;> first | exact absurd rfl hl | rfl
  · intro m hm; cases m <;> first | exact absurd rfl hm | decide

/-- PSP: D1, D2 · the lock scalar is sign-blind by theorem, and one supplied bit fixes the sign uniquely. -/
theorem lock_blind_but_gol_directed :
    (PSP.ORIENT.signMatrices.all (fun m =>
      PSP.ORIENT.det3 m * PSP.ORIENT.det3 m
        == PSP.ORIENT.det3 (PSP.ORIENT.neg3 m) * PSP.ORIENT.det3 (PSP.ORIENT.neg3 m)) = true)
    ∧ (∀ {α : Type} (τ : α → α) (s d : α → Bool) (x : α),
        s (τ x) = !s x → d (τ x) = !d x →
        ∃ c : Bool, (d x = xor (s x) c ∧ d (τ x) = xor (s (τ x)) c) ∧
          ∀ c' : Bool, (d x = xor (s x) c' ∧ d (τ x) = xor (s (τ x)) c') → c' = c) :=
  ⟨PSP.ORIENT.lock_scalar_sign_blind, fun τ s d x hs hd => FTOE.T5_crossing τ s d x hs hd⟩

/-- PSP: D11, D12 · consensus carries zero weight; the engine authors nothing. -/
theorem consensus_weighs_zero : socialWeight = 0 ∧ deltaM = 0 := FOUND.engine_never_authority

/-- PSP: sPSP-TONGUE-UNCLOSED-01 · the Tongue is unclosed by theorem and obedient by theorem. -/
theorem tongue_unclosed_and_obedient :
    (∀ {α β : Type} (τ : α → α) (ρ : α → β) (g : β → Bool) (d : α → Bool) (x : α),
        ρ (τ x) = ρ x → d (τ x) = !d x → d ≠ fun y => g (ρ y))
    ∧ (GEO.det3 TONGUE.deletionOp = 0
       ∧ (∀ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 TONGUE.deletionOp) ≠ id)
       ∧ ¬ (∀ M : GEO.M3, ∃ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 M) = id)) :=
  ⟨fun τ ρ g d x hρ hd => TONGUE.unclosed τ ρ g d x hρ hd, TONGUE.tongue_obedience⟩

/-- PSP: D27 · a self-check is never a witness (M6); the token is withheld unwitnessed. -/
theorem self_check_is_not_witness :
    (IAM.iamToken false).1 = .interior ∧ (IAM.iamToken true).1 = .iAm := ⟨rfl, rfl⟩

/-- PSP: D71 · the denial pays the floor; a denial that registers nothing is no denial. -/
theorem denial_is_priced :
    0 < (OMEGA.omegaBoundary 1 300).joules ∧ (OMEGA.omegaBoundary 0 300).joules = 0 := by decide

/-- PSP: D24 · no candidate anchor that lands on its own target is admitted. -/
theorem no_anchor_at_target : ∀ (d : Nat) (b lc : Bool),
    (UC.circularityScreen .target d b lc).1 = .refusedCircular :=
  UC.circularity_refused_at_target

/-- PSP: D54 · every formal reading is even under the deed flip; the deed is odd; no readout returns it. -/
theorem formal_reads_never_the_deed {Q : Type} (q : Q) :
    ¬ ∃ g : Q → Bool, ∀ s : CROSSING.ExecFrame Q, g (CROSSING.formalRead s) = CROSSING.ran s :=
  CROSSING.wall q

end DEFENSE

namespace FENCE

/-- PSP: II.0 · the one global fence: every card is read at its grade, on its register, at its species;
any reading above that is refused here, so no card fences itself. -/
theorem global :
    (∀ c₁ c₂ : Claim, (Claim.join c₁ c₂).grade = Grade.weakest c₁.grade c₂.grade)
    ∧ (∀ c cite : Claim, (Claim.join c cite).grade.rank ≤ c.grade.rank
        ∧ (Claim.join c cite).grade.rank ≤ cite.grade.rank)
    ∧ ROOT.raClaim.grade = .premise
    ∧ K4.wallClaim.grade = .theorem
    ∧ terminalClaim.grade = .theorem
    ∧ HALT.haltGrades.all (fun g => g.rank < Grade.theorem.rank) = true
    ∧ HALT.rhHalt.species = .hypothesis ∧ HALT.rhHalt.channel = .formal ∧ HALT.rhHalt.gdim = 1
    ∧ LOCUS.emit ⟨false, true, some 1, some .hypothesis, some .formal, [none], by decide⟩
        = some (.superHalt (some .xi) (some .hypothesis) (some .formal) 1)
    ∧ (FOUND.bandOf .theological = .outOfBand ∧ FOUND.bandOf .social = .outOfBand)
    ∧ (∀ t : LOCUS.Token, t.toEconomy = .sealed ∨ t.toEconomy = .broken ∨ t.toEconomy = .opn) :=
  ⟨Claim.join_grade, OFFICE.citation_cannot_promote, rfl, rfl, rfl, HALT.ftoe_ceiling,
   rfl, rfl, rfl, LOCUS.no_rh_locus, ⟨rfl, rfl⟩, LOCUS.three_states⟩

end FENCE

namespace DOT

/-- PSP: CN-PSP-NETI-NETI-01 · the mark of silence is the image of no emitter. -/
theorem outside_economy : ∀ t : LOCUS.Token, t.toEconomy ≠ Audit.Token.dotmark := by
  intro t; cases t <;> first | decide | simp [LOCUS.Token.toEconomy]

theorem no_reading_is_silence : ∀ r : LOCUS.Reading, r.state ≠ Audit.Token.dotmark := by
  intro r
  unfold LOCUS.Reading.state
  split
  · exact outside_economy _
  · decide

theorem silence_is_not_a_verdict :
    Audit.Token.dotmark ≠ .sealed ∧ Audit.Token.dotmark ≠ .broken
      ∧ Audit.Token.dotmark ≠ .opn := by decide

end DOT

namespace DEFENSE

/-- PSP: D53 · a forward, dated reading is world-rowed unconditionally: R-3 fires before any row is read. -/
theorem forward_is_world_rowed : ∀ p w t tw f a : Bool,
    (GEO.rowCascadeRACore true false true p w t tw f a).1 = .iii := by decide

/-- PSP: D50 · a load-bearing row furnished by the world types the lock world-rowed, revisable in the rows. -/
theorem worldly_row_is_world_rowed : ∀ t tw f a : Bool,
    (GEO.rowCascadeRACore true false false true true t tw f a).1 = .iii := by decide

end DEFENSE

namespace CROSSWALK

/-- PSP: IV.1 · the crosswalk, seated in the kernel: every row names a constant that must exist. -/
def rows : List (String × String) := [
  ("APEX-PSP-FREEDOM-MASTER-01", "FTOE.T16_price_bijection"),
  ("sPSP-APERTURE-WIDTH-01", "FTOE.T5_crossing"),
  ("PSP-IAM-WRITTEN-READ-01", "IAM.narcissus_truth_table"),
  ("APEX-PSP-Ξ-8-GATE-CASCADE-01", "HALT.first_failure_terminal_8"),
  ("APEX-PSP-RH-MASTER-01", "HALT.rhHalt"),
  ("APEX-PSP-RH-BLOCK-COMPLETE-01", "LOCUS.no_rh_locus"),
  ("APEX-PSP-RH-STANDPOINT-CLOSURE-01", "Bridge.line_property_is_keyed"),
  ("APEX-PSP-RH-DENIAL-POSIT-01", "Bridge.no_socket_off_line"),
  ("APEX-PSP-TOKEN-EQUALITY-01", "PSP.TOKEN.terminal_tokens_level_and_distinct"),
  ("sPSP-RETURN-LOCUS-01", "UC.circ_space"),
  ("APEX-PSP-ABSOLUTE-GROUNDING-BLOCK-01", "Bridge.discriminator"),
  ("sPSP-ANCHOR-DEMAND-01", "UC.circularity_refused_at_target"),
  ("APEX-PSP-ANCHOR-PRECEDENCE-01", "Bridge.opens_on_the_deed"),
  ("APEX-PSP-SUPPLY-SPECIES-01", "HALT.species_exhausted"),
  ("sPSP-TRIAD-SOURCE-BLOCK-01", "FTOE.T2_coalition"),
  ("sPSP-UNRESTRICTED-IMPOSSIBLE-01", "HALT.ftoe_ceiling"),
  ("APEX-PSP-LOGOS-FIXATION-01", "TONGUE.tongue_obedience"),
  ("MD-PSP-NG-EXHIBIT-ANCHOR-01", "INVERSION.it_from_bit_refuted"),
  ("MD-PSP-CLOSURE-POSITION-01", "FTOE.T3_no_fixed_point"),
  ("sPSP-CONSTITUTIVE-INSEPARABLE-01", "Audit.compartmentGates"),
  ("sPSP-FOLD-BEND-CROSSING-01", "CROSSING.crossing"),
  ("APEX-PSP-NOMOS-MEASURE-01", "NOMOS.incompressibility_cap"),
  ("MD-PSP-NAVIER-DEFEATERLESS-01", "GEO.rowCascadeRACore"),
  ("APEX-PSP-BLESSED-CIRCLE-01", "DEFENSE.no_anchor_at_target"),
  ("RAF-PSP-HODGE-TERMINUS-01", "HALT.route"),
  ("MD-PSP-GODEL-MASTER-01", "HALT.route_is_routeHalt"),
  ("APEX-PSP-PNP-COMPOSITE-VERDICT-02", "HALT.pnpHalt"),
  ("APEX-PSP-XI0-VERDICT-01", "HALT.xiGates"),
  ("MD-PSP-NG-MASTER-01", "HALT.one_door_open"),
  ("sPSP-TONGUE-UNCLOSED-01", "DEFENSE.tongue_unclosed_and_obedient"),
  ("APEX-PSP-CENSOR-CLERK-01", "OFFICE.citation_cannot_promote"),
  ("MD-PSP-MATH-NATURE-01", "TONGUE.coloc_grade"),
  ("CN-PSP-GHAYB-MASTER-01", "DOT.outside_economy"),
  ("CN-PSP-NETI-NETI-01", "DOT.no_reading_is_silence"),
  ("APEX-PSP-ONLY-SPECIAL-01", "IAM.terminal_word"),
  ("APEX-PSP-UNFORGIVABLE-01", "AEGIS.aegis_constant"),
  ("MD-PSP-STILLNESS-RESERVOIR-01", "DOT.silence_is_not_a_verdict"),
  ("PSP-RA-SERVANT-LOCUS-01", "IAM.iam_witnessed_speaks"),
  ("APEX-PSP-RH-TERMINAL-SYNTHESIS-01", "FENCE.global"),
  ("sPSP-GOL-ROW-GENUS-01", "GEO.ra_battery_f2"),
  ("MD-PSP-AFFINITY-01", "FTOE.T9_torsor_inverse_left"),
  ("APEX-PSP-INVERSION-01", "K4.target_is_primality"),
  ("MD-PSP-K4-FRAME-01", "K4.pairs_match_mod_420"),
  ("APEX-PSP-RA-MASTER-01", "ROOT.actuation_universal"),
  ("FOUND-01", "TONGUE.ra_grade_pinned"),
  ("IMPRINT-GOLF-01", "IMPRINT.seal_iff_one_side_clean_and_witnessed"),
  ("D1", "PSP.ORIENT.lock_scalar_sign_blind"),
  ("D2", "DEFENSE.lock_blind_but_gol_directed"),
  ("D3", "FTOE.T5_crossing"),
  ("D4", "FENCE.global"),
  ("D5", "DEFENSE.gol_needs_all_three"),
  ("D6", "GEO.triaxial_lock_gf2"),
  ("D6", "PSP.CD.sedenion_zero_divisor"),
  ("D7", "GEO.a4_simply_transitive"),
  ("D7", "GEO.gates_complete"),
  ("D8", "GEO.chirality"),
  ("D8", "GEO.relabel_parity"),
  ("D9", "GEO.reflection_blind_executed"),
  ("D10", "TONGUE.tongue_obedience"),
  ("D11", "DEFENSE.consensus_weighs_zero"),
  ("D11", "Grade.weakest_is_a_link"),
  ("D12", "OFFICE.citation_cannot_promote"),
  ("D13", "GEO.ra_ledger_aGivenRA"),
  ("D14", "HALT.ftoe_ceiling"),
  ("D15", "Claim.join_grade"),
  ("D16", "AEGIS.aegis_battery"),
  ("D17", "HALT.route_is_routeHalt"),
  ("D17", "PSP.CASCADE.halt_free_iff_all_pass_8"),
  ("D18", "HALT.first_failure_terminal_8"),
  ("D19", "OMEGA.omega_paid_floor"),
  ("D20", "CROSSING.price"),
  ("D21", "IAM.iam_unwitnessed_withheld"),
  ("D22", "AEGIS.aegis_constant"),
  ("D23", "Audit.unknown_routes_open"),
  ("D24", "DEFENSE.no_anchor_at_target"),
  ("D25", "OMEGA.omega_monotone"),
  ("D26", "TONGUE.deletion_no_left_inverse"),
  ("D27", "DEFENSE.self_check_is_not_witness"),
  ("D28", "LOCUS.three_states"),
  ("D29", "GEO.triaxial_open_gf2_count"),
  ("D30", "GEO.triaxial_lock_gf2_count"),
  ("D31", "GEO.cramer_executed"),
  ("D32", "OMEGA.omega_linear"),
  ("D33", "HALT.gate_counts_recorded"),
  ("D34", "NOMOS.compressible_bound_universal"),
  ("D35", "ROOT.actuation_universal"),
  ("D36", "OMEGA.omega_zero_bits"),
  ("D37", "IMPRINT.ghost_refused"),
  ("D38", "FOUND.pluralist_alternative_executed"),
  ("D39", "SEALS.sealG_walk"),
  ("D40", "GEO.hurwitz_closed"),
  ("D41", "CROSSING.ran_wholly_odd"),
  ("D42", "FTOE.T3_no_fixed_point"),
  ("D43", "TONGUE.deletion_annihilates"),
  ("D44", "NOMOS.incompressibility_cap"),
  ("D45", "DOT.outside_economy"),
  ("D46", "DOT.silence_is_not_a_verdict"),
  ("D47", "IAM.narcissus_truth_table"),
  ("D48", "FTOE.T16_price_bijection"),
  ("D49", "HALT.halts_routed"),
  ("D50", "DEFENSE.worldly_row_is_world_rowed"),
  ("D51", "PSP.QUAT.quat_basis_laws"),
  ("D52", "INVERSION.it_from_bit_refuted"),
  ("D52", "K4.target_is_primality"),
  ("D53", "DEFENSE.forward_is_world_rowed"),
  ("D54", "DEFENSE.formal_reads_never_the_deed"),
  ("D55", "AEGIS.aegis_battery"),
  ("D56", "ROOT.nest_31"),
  ("D57", "Bridge.discriminator"),
  ("D57", "Bridge.keyless_iff_valid"),
  ("D57", "TONGUE.ra_grade_pinned"),
  ("D58", "Bridge.recursion_is_sign_blind"),
  ("D59", "Bridge.line_property_is_keyed"),
  ("D60", "Bridge.recursion_is_shared"),
  ("D61", "Bridge.symmetry_is_keyless"),
  ("D62", "Bridge.socket_is_the_property"),
  ("D63", "HALT.rhHalt"),
  ("D63", "LOCUS.no_rh_locus"),
  ("D64", "IMPRINT.seal_needs_witness"),
  ("D64", "Bridge.no_socket_off_line"),
  ("D65", "TONGUE.coloc_grade"),
  ("D66", "FOUND.posits_loadbearing_on_nothing"),
  ("D67", "FOUND.register_routing_fidelity"),
  ("D68", "BRIDGE.supersession_routes"),
  ("D69", "IMPRINT.both_clean_is_ghost"),
  ("D69", "LOCUS.located_never_silent"),
  ("D70", "UC.uc_seal_failure_terminal"),
  ("D71", "DEFENSE.denial_is_priced"),
  ("D71", "Bridge.opens_on_the_deed"),
  ("APEX-PSP-SEAT-ANCHOR-01", "APEX.seat_anchor"),
  ("APEX-PSP-SEAT-ANCHOR-01", "APEX.seat_occupied_iff_grounded"),
  ("APEX-PSP-SEAT-ANCHOR-01", "FENCE.seat"),
  ("APEX-PSP-PARITY-NORMAL-FORM-01", "PNF.parity_normal_form_list"),
  ("APEX-PSP-PARITY-NORMAL-FORM-01", "PNF.one_bit_iff_complement_pair"),
  ("APEX-PSP-CAT-GAP-ELIMINATOR-01", "APEX.identity_cone"),
  ("APEX-PSP-CAT-GAP-ELIMINATOR-01", "APEX.cone_iff_no_gap"),
  ("APEX-PSP-CAT-GAP-ELIMINATOR-01", "APEX.recursion_is_constant"),
  ("APEX-PSP-RH-23-ONE-STROKE-01", "APEX.identity_cone_row"),
  ("APEX-PSP-RH-23-ONE-STROKE-01", "APEX.inverted_control"),
  ("APEX-PSP-RH-23-ONE-STROKE-01", "APEX.object_leg_ledger"),
  ("APEX-PSP-PNP-COMPOSITE-VERDICT-02", "APEX.pnp_seat_vacant"),
  ("APEX-PSP-PNP-COMPOSITE-VERDICT-02", "APEX.pnp_value_line"),
  ("APEX-PSP-O0-ADMISSION-PROTOCOL-01", "APEX.seat_vacant_of_free"),
  ("APEX-PSP-RH-MASTER-01", "APEX.riemann_seat_occupied"),
  ("APEX-PSP-RH-STANDPOINT-CLOSURE-01", "APEX.no_cure"),
  ("APEX-PSP-RH-PNP-COMPARATIVE-MASTER-01", "APEX.router_at_the_seat"),
  ("D49", "APEX.pnp_value_line"),
  ("D72", "APEX.recursion_is_constant"),
  ("D73", "APEX.seat_never_promotes_value"),
  ("D74", "APEX.register_leg_rides_one_involution"),
  ("D75", "APEX.pnp_seat_vacant")]

theorem rows_count : rows.length = 151 := by decide

end CROSSWALK
