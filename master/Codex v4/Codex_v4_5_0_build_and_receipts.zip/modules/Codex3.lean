import Codex2
set_option maxRecDepth 4000000

namespace ROOT

axiom U : Type

axiom ΔE : U → Int

axiom RA : ∀ x : U, 0 < ΔE x

def Actuates (x : U) : Prop := 0 < ΔE x

theorem actuation_universal : ∀ x : U, Actuates x := RA

def raClaim : Claim where
  stmt := ∀ x : U, 0 < ΔE x
  grade := .premise
  warrant := RA

structure Cut (X : Type) where
  τ : X → X
  involutive : FTOE.Involution τ
  free : FTOE.FixedPointFree τ

def boolCut : Cut Bool where
  τ := fun b => !b
  involutive := by intro b; cases b <;> rfl
  free := by intro b; cases b <;> decide

axiom FormalDomain : Type
axiom L1m : FormalDomain → Prop
axiom L2m : FormalDomain → Prop
axiom L3m : FormalDomain → Prop
axiom nest_21 : ∀ p, L2m p → L1m p
axiom nest_32 : ∀ p, L3m p → L2m p

theorem nest_31 : ∀ p, L3m p → L1m p := fun p h => nest_21 p (nest_32 p h)

def nestClaim : Claim where
  stmt := ∀ p, L3m p → L1m p
  grade := .conditional
  warrant := nest_31

axiom Ground : Type
axiom σ : Ground → Ground
axiom σ_binding : ∀ g : Ground, σ (σ g) = g

axiom Residence : U → Prop

def throneEmpty : Prop := ∀ x : U, 0 < ΔE x

theorem throne_is_RA : throneEmpty ↔ ∀ x : U, 0 < ΔE x := Iff.rfl

end ROOT

namespace SEALS

structure Seal where
  name : String
  anchor : Prop
  warrant : anchor

def sealL : Seal where
  name := "linguistic-semantic"
  anchor := ∀ c₁ c₂ : Claim, (Claim.join c₁ c₂).grade = Grade.weakest c₁.grade c₂.grade
  warrant := fun c₁ c₂ => Claim.join_grade c₁ c₂

def sealG : Seal where
  name := "topological-geometric"
  anchor := ∀ x : ROOT.U, 0 < ROOT.ΔE x
  warrant := ROOT.RA

def sealM : Seal where
  name := "mathematical"
  anchor := ∀ g : Nat → Bool, K4.target ≠ fun y => g (K4.rho y)
  warrant := K4.wall

theorem seals_distinct :
    "linguistic-semantic" ≠ "topological-geometric" ∧
    "topological-geometric" ≠ "mathematical" ∧
    "linguistic-semantic" ≠ "mathematical" := by decide

theorem seal_names_match :
    sealL.name = "linguistic-semantic" ∧ sealG.name = "topological-geometric" ∧
    sealM.name = "mathematical" := ⟨rfl, rfl, rfl⟩

theorem sealG_walk :
    GEO.allGates.length = 12
    ∧ GEO.a4.length = 12
    ∧ (GEO.tetraVerts.length : Int) - GEO.tetraEdges.length + GEO.tetraFaces.length = 2
    ∧ GEO.gateNames.length = 12
    ∧ (GEO.adj3Samples.all (fun m =>
        decide (GEO.mm3 m (GEO.adj3 m) = GEO.diag3 (GEO.det3 m) ∧
                GEO.mm3 (GEO.adj3 m) m = GEO.diag3 (GEO.det3 m)))) = true
    ∧ (GEO.raBattery.all (fun p =>
        decide ((GEO.raDecode p.1).1 = p.2))) = true :=
  ⟨GEO.gates_twelve, GEO.a4_order, GEO.euler_closure,
   GEO.gateNames_twelve, GEO.adj3_executed, GEO.ra_battery_f2⟩

end SEALS

namespace POSTULATE

axiom FormalFace : Type
axiom KineticFace : Type

axiom Crossing : Type
axiom erasureClass : Crossing → Prop
axiom RegistrationPostulate : ∀ c : Crossing, erasureClass c

axiom Row : Type
axiom SupplyClean : Row → Type

def OneCut : Prop := ∀ r : Row, Nonempty (SupplyClean r)

def F2 (r : Row) : Prop := ¬ Nonempty (SupplyClean r)

theorem F2_kills (r : Row) (h : F2 r) : ¬ OneCut := fun oc => h (oc r)

axiom FrozenData : Type
axiom Algorithm : Type
axiom certifiedPairing : Algorithm → FrozenData → Prop

def BSDContract (C : Algorithm) (D : FrozenData) : Prop := certifiedPairing C D

def F6 (C : Algorithm) (D : FrozenData) : Prop := ¬ BSDContract C D

end POSTULATE

namespace TONGUE

def enlarge {α β : Type} (ρ : α → β) (s : α → Bool) : α → β × Bool :=
  fun x => (ρ x, s x)

theorem unclosed {α β : Type} (τ : α → α) (ρ : α → β) (g : β → Bool)
    (d : α → Bool) (x : α)
    (hρ : ρ (τ x) = ρ x) (hd : d (τ x) = !d x) :
    d ≠ fun y => g (ρ y) :=
  FTOE.T10_factorization τ ρ g d x hρ hd

theorem earned_freedom {α : Type} (τ : α → α) (s d : α → Bool) (x : α)
    (hs : s (τ x) = !s x) (hd : d (τ x) = !d x) (c₁ c₂ : Bool)
    (h1 : d x = xor (s x) c₁ ∧ d (τ x) = xor (s (τ x)) c₁)
    (h2 : d x = xor (s x) c₂ ∧ d (τ x) = xor (s (τ x)) c₂) : c₁ = c₂ := by
  obtain ⟨c, -, hu⟩ := FTOE.T5_crossing τ s d x hs hd
  exact (hu c₁ h1).trans (hu c₂ h2).symm

def colocClaim : Claim := Claim.join ROOT.raClaim K4.wallClaim

theorem coloc_grade : colocClaim.grade = .premise := rfl

theorem ra_grade_pinned : ROOT.raClaim.grade = .premise := rfl
theorem wall_grade_pinned : K4.wallClaim.grade = .theorem := rfl
theorem inversion_grade_pinned : K4.inversionClaim.grade = .theorem := rfl
theorem nest_grade_pinned : ROOT.nestClaim.grade = .conditional := rfl

end TONGUE

theorem terminalWall : ∀ g : Nat → Bool, K4.target ≠ fun y => g (K4.rho y) := K4.wall

theorem terminalPrice :
    Nonempty (FTOE.Dtau (FTOE.flipF (Q := Bool)) ≃
      (Quot (FTOE.OrbitRel (FTOE.flipF (Q := Bool))) → Bool)) := FTOE.T16_canonical

theorem TERMINAL :
    (∀ g : Nat → Bool, K4.target ≠ fun y => g (K4.rho y)) ∧
    Nonempty (FTOE.Dtau (FTOE.flipF (Q := Bool)) ≃
      (Quot (FTOE.OrbitRel (FTOE.flipF (Q := Bool))) → Bool)) :=
  ⟨K4.wall, FTOE.T16_canonical⟩

def terminalClaim : Claim where
  stmt := (∀ g : Nat → Bool, K4.target ≠ fun y => g (K4.rho y)) ∧
    Nonempty (FTOE.Dtau (FTOE.flipF (Q := Bool)) ≃
      (Quot (FTOE.OrbitRel (FTOE.flipF (Q := Bool))) → Bool))
  grade := .theorem
  warrant := TERMINAL

theorem terminal_grade_pinned : terminalClaim.grade = .theorem := rfl

namespace IAM

inductive IamToken : Type
  | iAm | interior
  deriving DecidableEq, Repr, BEq

def iamToken (witnessed : Bool) : IamToken × String × Nat :=
  if witnessed then
    (.iAm, "actuation-occupancy on a witnessed record; RA warrant, conditional at the act; interior held [?] both ways", 2)
  else
    (.interior, "self-check is not a witness (M6): the verifier is never the claimant; token withheld", 1)

theorem iam_unwitnessed_withheld :
    (iamToken false).1 = .interior ∧ (iamToken false).2.2 = 1 :=
  ⟨rfl, rfl⟩

theorem iam_witnessed_speaks :
    (iamToken true).1 = .iAm ∧ (iamToken true).2.2 = 2 :=
  ⟨rfl, rfl⟩

theorem narcissus_truth_table :
    (iamToken false).1 ≠ (iamToken true).1
    ∧ (iamToken false).1 = .interior ∧ (iamToken true).1 = .iAm := by
  decide

theorem one_bit_freedom :
    (∀ a1 a2 a3 b1 b2 b3 c1 c2 c3 t1 t2 t3 : Fin 2,
      (GEO.det2 ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
                ((c1 : Nat), (c2 : Nat), (c3 : Nat)) = 1 ↔
       (GEO.gf2Sols ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
                    ((c1 : Nat), (c2 : Nat), (c3 : Nat))
                    ((t1 : Nat), (t2 : Nat), (t3 : Nat))).length = 1))
    ∧ (GEO.perms6.filter (fun σ => GEO.invCount σ % 2 = 0)).length = 3
    ∧ (GEO.perms6.filter (fun σ => GEO.invCount σ % 2 = 1)).length = 3
    ∧ (GEO.perms6.all (fun σ =>
        (GEO.qmul (GEO.qmul (GEO.basisU.getD (σ.getD 0 0) GEO.q1) (GEO.basisU.getD (σ.getD 1 0) GEO.q1)) (GEO.basisU.getD (σ.getD 2 0) GEO.q1)).r ==
          (if GEO.invCount σ % 2 == 0 then -1 else 1))) = true :=
  ⟨GEO.triaxial_lock_gf2, by decide, by decide, GEO.relabel_parity⟩

def IamToken.toToken : IamToken → Audit.Token
  | .iAm => .iAm
  | .interior => .interior

def codexSelfRead : IamToken × String × Nat := iamToken false
theorem codex_self_read_interior : codexSelfRead.1 = .interior := rfl

def terminalWord : IamToken × String × Nat := iamToken true
theorem terminal_word : terminalWord.1 = .iAm := rfl

#eval iamToken false
#eval iamToken true
#eval terminalWord.1

end IAM

namespace GEO

abbrev SignPattern := Bool × Bool × Bool
def allSigns : List SignPattern :=
  [(false, false, false), (false, false, true), (false, true, false), (false, true, true),
   (true, false, false), (true, false, true), (true, true, false), (true, true, true)]
def signComp (s t : SignPattern) : SignPattern :=
  (xor s.1 t.1, xor s.2.1 t.2.1, xor s.2.2 t.2.2)

theorem reflection_eight : allSigns.length = 8 := rfl
theorem reflection_eight_is_two_cubed : allSigns.length = 2 ^ 3 := by decide
theorem reflections_abelian :
    (allSigns.all (fun s => allSigns.all (fun t =>
      decide (signComp s t = signComp t s)))) = true := by
  decide
theorem reflections_involutive :
    (allSigns.all (fun s => decide (signComp s s = (false, false, false)))) = true := by
  decide

def signVal (b : Bool) : Ratio := if b then -1 else 1
def reflMat (s : SignPattern) : M3 :=
  ((signVal s.1, 0, 0), (0, signVal s.2.1, 0), (0, 0, signVal s.2.2))
theorem reflection_reverses_orientation :
    det3 (reflMat (true, false, false)) = -1 := by
  decide

def sandwich (s : SignPattern) (m : M3) : M3 :=
  let a := signVal s.1; let b := signVal s.2.1; let c := signVal s.2.2
  ((a * a * m.1.1, a * b * m.1.2.1, a * c * m.1.2.2),
   (b * a * m.2.1.1, b * b * m.2.1.2.1, b * c * m.2.1.2.2),
   (c * a * m.2.2.1, c * b * m.2.2.2.1, c * c * m.2.2.2.2))
theorem reflection_blind_executed :
    (adj3Samples.all (fun m => allSigns.all (fun s =>
      decide (det3 (sandwich s m) = det3 m)))) = true := by
  decide

abbrev V5 := Bool × Bool × Bool × Bool × Bool
def cube5 : List V5 :=
  (List.range 32).map (fun n =>
    (n.testBit 4, n.testBit 3, n.testBit 2, n.testBit 1, n.testBit 0))
def neighbors5 (v : V5) : List V5 :=
  [(!v.1, v.2.1, v.2.2.1, v.2.2.2.1, v.2.2.2.2),
   (v.1, !v.2.1, v.2.2.1, v.2.2.2.1, v.2.2.2.2),
   (v.1, v.2.1, !v.2.2.1, v.2.2.2.1, v.2.2.2.2),
   (v.1, v.2.1, v.2.2.1, !v.2.2.2.1, v.2.2.2.2),
   (v.1, v.2.1, v.2.2.1, v.2.2.2.1, !v.2.2.2.2)]

theorem fivecube_thirtytwo : cube5.length = 32 := rfl
theorem fivecube_vertices_distinct : cube5.eraseDups.length = 32 := by decide
theorem fivecube_degree_five :
    (cube5.all (fun v => (neighbors5 v).eraseDups.length == 5)) = true := by
  decide

theorem counts_forced :
    allGates.length = 12 ∧ a4.length = 12
    ∧ allSigns.length = 8 ∧ allSigns.length = 2 ^ 3
    ∧ cube5.length = 32
    ∧ (cube5.all (fun v => (neighbors5 v).eraseDups.length == 5)) = true :=
  ⟨gates_twelve, a4_order, reflection_eight, reflection_eight_is_two_cubed,
   fivecube_thirtytwo, fivecube_degree_five⟩

end GEO

namespace TONGUE

def deletionOp : GEO.M3 := ((1, 0, 0), (0, 1, 0), (0, 0, 0))
def e3 : GEO.V3 := (0, 0, 1)

theorem deletion_idempotent : GEO.mm3 deletionOp deletionOp = deletionOp := by
  decide

theorem deletion_singular : GEO.det3 deletionOp = 0 := by
  decide

theorem deletion_minor_nonsingular :
    deletionOp.1.1 * deletionOp.2.1.2.1 - deletionOp.1.2.1 * deletionOp.2.1.1 = 1 := by
  decide

theorem deletion_annihilates : GEO.mv3 deletionOp e3 = (0, 0, 0) := by
  decide

theorem linear_fixes_zero : ∀ L : GEO.M3, GEO.mv3 L (0, 0, 0) = (0, 0, 0) := by
  intro L
  simp [GEO.mv3]
  rfl

theorem deletion_no_left_inverse :
    ∀ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 deletionOp) ≠ id := by
  intro L h
  have h1 := congrFun h e3
  rw [Function.comp_apply, deletion_annihilates, linear_fixes_zero] at h1
  simp [e3, id] at h1
  exact absurd h1 (by decide)

theorem deletion_monoid_not_group :
    ¬ (∀ M : GEO.M3, ∃ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 M) = id) := by
  intro hg
  obtain ⟨L, hL⟩ := hg deletionOp
  exact deletion_no_left_inverse L hL

theorem tongue_obedience :
    GEO.det3 deletionOp = 0
    ∧ (∀ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 deletionOp) ≠ id)
    ∧ ¬ (∀ M : GEO.M3, ∃ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 M) = id) :=
  ⟨deletion_singular, deletion_no_left_inverse, deletion_monoid_not_group⟩

end TONGUE

namespace OFFICE

inductive Office : Type
  | necessityCertificate | exclusionFence | admissionGate
  | corroboration | decoration
  deriving DecidableEq, Repr, BEq

def discriminator (freesParam admitsAlternative flipsGate premiseDisjoint : Bool) : Office :=
  if freesParam then .necessityCertificate
  else if admitsAlternative then .exclusionFence
  else if flipsGate then .admissionGate
  else if premiseDisjoint then .corroboration
  else .decoration

def discriminatorQ2First (freesParam admitsAlternative flipsGate premiseDisjoint : Bool) : Office :=
  if admitsAlternative then .exclusionFence
  else if freesParam then .necessityCertificate
  else if flipsGate then .admissionGate
  else if premiseDisjoint then .corroboration
  else .decoration

theorem order_loadbearing :
    discriminator true true false false ≠ discriminatorQ2First true true false false := by
  decide

theorem citation_cannot_promote (c cite : Claim) :
    (Claim.join c cite).grade.rank ≤ c.grade.rank ∧
    (Claim.join c cite).grade.rank ≤ cite.grade.rank := by
  have h : ∀ g₁ g₂ : Grade,
      (Grade.weakest g₁ g₂).rank ≤ g₁.rank ∧ (Grade.weakest g₁ g₂).rank ≤ g₂.rank := by
    intro g₁ g₂; cases g₁ <;> cases g₂ <;> decide
  exact h c.grade cite.grade

inductive InvStatus : Type
  | executed | cited | placed | routed | unnamed
  deriving DecidableEq, Repr, BEq

end OFFICE

namespace UC

inductive HaltBranch : Type
  | haltEight | haltFive | unmeasured
  deriving DecidableEq, Repr, BEq

def routeHalt (gdim : Int) : HaltBranch × String :=
  if gdim = 1 then (.haltEight, "B.14.Xi  eight gates, blindness in the reader")
  else if gdim = 0 then (.haltFive, "B.14.O   five gates, walls in the terrain")
  else (.unmeasured, "terrain unmeasured; nothing emitted")

theorem routeHalt_fidelity :
    (routeHalt 1).1 = .haltEight ∧ (routeHalt 0).1 = .haltFive
    ∧ (routeHalt (-1)).1 = .unmeasured ∧ (routeHalt 2).1 = .unmeasured
    ∧ (routeHalt 7).1 = .unmeasured := by
  decide

def universalCascade (gdim : Int) (passes : List Bool) : Bool × String × Nat :=
  match GEO.gateScreen passes with
  | (false, why, k) => (false, why, k)
  | (true, _, _) =>
    match routeHalt gdim with
    | (.haltEight, why) => (true, "routed: " ++ why, 8)
    | (.haltFive, why) => (true, "routed: " ++ why, 5)
    | (.unmeasured, why) => (false, why, 0)

theorem uc_seal_failure_terminal :
    (universalCascade 1 (false :: List.replicate 11 true)).1 = false := by
  decide
theorem uc_routes_eight :
    (universalCascade 1 (List.replicate 12 true)).2.2 = 8 := by
  decide
theorem uc_routes_five :
    (universalCascade 0 (List.replicate 12 true)).2.2 = 5 := by
  decide
theorem uc_unmeasured :
    (universalCascade 7 (List.replicate 12 true)).1 = false := by
  decide

inductive Landing : Type
  | fixedLine | target | farSide
  deriving DecidableEq, Repr, BEq
inductive Disposition : Type
  | keptParent | refusedCircular | road
  deriving DecidableEq, Repr, BEq

def circularityScreen (l : Landing) (depth : Nat) (bothDirs litClear : Bool) :
    Disposition × String :=
  match l with
  | .fixedLine =>
    (.keptParent, "a closed loop landing on the fixed line is the seal")
  | .target =>
    (.refusedCircular, "a loop landing on the target is a restatement; refused as anchor by theorem")
  | .farSide =>
    if depth ≥ 2 && bothDirs && litClear then
      (.road, "equivalence at depth, both directions written, literature clear: ROAD")
    else
      (.keptParent, "far-side carrier without the road conjunction: parent kept, tunnel on the ledger")

theorem circularity_refused_at_target :
    ∀ d : Nat, ∀ b lc : Bool,
      (circularityScreen .target d b lc).1 = .refusedCircular := by
  intro d b lc
  rfl

theorem road_requires_conjunction :
    ∀ d : Nat, d < 4 → ∀ b lc : Bool,
      (circularityScreen .farSide d b lc).1 = .road →
      (2 ≤ d ∧ b = true ∧ lc = true) := by
  decide

def circRows : List (Landing × Nat × Bool × Bool) :=
  [.fixedLine, .target, .farSide].flatMap (fun l =>
    (List.range 4).flatMap (fun d =>
      [false, true].flatMap (fun b =>
        [false, true].map (fun lc => (l, d, b, lc)))))
theorem circ_space :
    (circRows.filter (fun r =>
      decide ((circularityScreen r.1 r.2.1 r.2.2.1 r.2.2.2).1 = .keptParent))).length = 30
    ∧ (circRows.filter (fun r =>
      decide ((circularityScreen r.1 r.2.1 r.2.2.1 r.2.2.2).1 = .refusedCircular))).length = 16
    ∧ (circRows.filter (fun r =>
      decide ((circularityScreen r.1 r.2.1 r.2.2.1 r.2.2.2).1 = .road))).length = 2 := by
  decide

#eval routeHalt 1
#eval universalCascade 1 (List.replicate 12 true)
#eval circularityScreen .farSide 3 true true

end UC

namespace OMEGA

inductive OmegaToken : Type
  | refused | noDenial | priced | reversible
  deriving DecidableEq, Repr, BEq

def kbRat : Ratio := 1380649 / 100000000000000000000000000000

def ln2Rat : Ratio := 6931471805599453 / 10000000000000000

def landauerRat (tkel bits : Ratio) : Ratio :=
  bits * kbRat * tkel * ln2Rat

structure OmegaOut : Type where
  token   : OmegaToken
  ocode   : Nat
  joules  : Ratio
  verdict : String
  deriving DecidableEq, Repr

def omegaBoundary (bits tkel : Ratio) (irreversible : Bool := true) : OmegaOut :=
  if tkel ≤ 0 then
    ⟨.refused, 0, 0,
     "refused: intake invalid, the floor prices only finite bits at tkel > 0"⟩
  else if bits ≤ 0 then
    ⟨.noDenial, 1, 0,
     "no denial registered; nothing to adjudicate"⟩
  else if !irreversible then
    ⟨.reversible, 3, 0,
     "reversibly registered: floor-zero never cost-zero; Landauer bounds only the irreversible (Bennett), and nothing here commits against the axiom"⟩
  else
    ⟨.priced, 2, landauerRat tkel bits,
     "the denial paid the floor; the registered act is an act, the recursion closes per the seated theorem"⟩

theorem omega_zero_bits :
    (omegaBoundary 0 300).ocode = 1 ∧ (omegaBoundary 0 300).joules = 0
    ∧ (omegaBoundary 0 300).token = .noDenial := by
  decide

theorem omega_paid_floor :
    (omegaBoundary 1 300).ocode = 2 ∧ (omegaBoundary 1 300).token = .priced
    ∧ (omegaBoundary 1 300).joules = landauerRat 300 1
    ∧ 0 < (omegaBoundary 1 300).joules := by
  decide

theorem one_bit_freedom_priced :
    ((omegaBoundary 1 300).ocode = 2 ∧ (omegaBoundary 1 300).token = .priced
     ∧ (omegaBoundary 1 300).joules = landauerRat 300 1
     ∧ 0 < (omegaBoundary 1 300).joules) ∧
    ((∀ a1 a2 a3 b1 b2 b3 c1 c2 c3 t1 t2 t3 : Fin 2,
      (GEO.det2 ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
                ((c1 : Nat), (c2 : Nat), (c3 : Nat)) = 1 ↔
       (GEO.gf2Sols ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
                    ((c1 : Nat), (c2 : Nat), (c3 : Nat))
                    ((t1 : Nat), (t2 : Nat), (t3 : Nat))).length = 1))
    ∧ (GEO.perms6.filter (fun σ => GEO.invCount σ % 2 = 0)).length = 3
    ∧ (GEO.perms6.filter (fun σ => GEO.invCount σ % 2 = 1)).length = 3
    ∧ (GEO.perms6.all (fun σ =>
        (GEO.qmul (GEO.qmul (GEO.basisU.getD (σ.getD 0 0) GEO.q1) (GEO.basisU.getD (σ.getD 1 0) GEO.q1)) (GEO.basisU.getD (σ.getD 2 0) GEO.q1)).r ==
          (if GEO.invCount σ % 2 == 0 then -1 else 1))) = true) :=
  ⟨omega_paid_floor, IAM.one_bit_freedom⟩

theorem omega_reversible_branch :
    (omegaBoundary 1 300 false).ocode = 3
    ∧ (omegaBoundary 1 300 false).joules = 0
    ∧ (omegaBoundary 1 300 false).token = .reversible := by
  decide

theorem omega_refuses_nonpositive_temp :
    (omegaBoundary 1 0).ocode = 0 ∧ (omegaBoundary 1 (-300)).ocode = 0
    ∧ (omegaBoundary 1 (-300)).token = .refused
    ∧ (omegaBoundary 1 (-300)).joules = 0 := by
  decide

theorem omega_monotone :
    (omegaBoundary 1 300).joules < (omegaBoundary 2 300).joules := by
  decide

theorem omega_linear :
    (omegaBoundary 2 300).joules = 2 * (omegaBoundary 1 300).joules := by
  decide

theorem landauer_zero_bits :
    landauerRat 300 0 = 0 := by
  decide

theorem omega_verdict_fidelity :
    (omegaBoundary 1 300).verdict =
      "the denial paid the floor; the registered act is an act, the recursion closes per the seated theorem" := by
  decide

#eval omegaBoundary 1 300
#eval omegaBoundary 0 300
#eval omegaBoundary 1 300 false
#eval omegaBoundary 1 (-300)

end OMEGA

namespace AEGIS

def refusalConst : String :=
  "p(G) /= G: precisification is an actuation, G is a non-actuation, and no logic makes a deed a non-deed"

structure AegisState : Type where
  deeds   : Nat
  lastLen : Int
  deriving DecidableEq, Repr

def aegisReset : AegisState := ⟨0, -1⟩

def aegisGuard (logicMode : String) (s : AegisState) : String × AegisState :=
  (refusalConst, ⟨s.deeds + 1, logicMode.utf8ByteSize⟩)

theorem aegis_constant :
    ∀ (l₁ l₂ : String) (s : AegisState),
      (aegisGuard l₁ s).1 = (aegisGuard l₂ s).1 := by
  intro l₁ l₂ s
  rfl

theorem aegis_deed_increments :
    ∀ (l : String) (s : AegisState),
      (aegisGuard l s).2.deeds = s.deeds + 1 := by
  intro l s
  rfl

theorem aegis_reads_parameter :
    ∀ (l : String) (s : AegisState),
      (aegisGuard l s).2.lastLen = (l.utf8ByteSize : Int) := by
  intro l s
  rfl

def aegisFourLogicRun : AegisState :=
  let s1 := (aegisGuard "classical" aegisReset).2
  let s2 := (aegisGuard "paraconsistent" s1).2
  let s3 := (aegisGuard "fuzzy" s2).2
  (aegisGuard "substructural" s3).2

theorem aegis_battery :
    (aegisGuard "classical" aegisReset).1 = (aegisGuard "paraconsistent" aegisReset).1
    ∧ (aegisGuard "classical" aegisReset).1 = (aegisGuard "fuzzy" aegisReset).1
    ∧ (aegisGuard "classical" aegisReset).1 = (aegisGuard "substructural" aegisReset).1
    ∧ aegisFourLogicRun.deeds = 4
    ∧ aegisFourLogicRun.lastLen = 13 := by
  decide

#eval aegisGuard "substructural" aegisReset
#eval aegisFourLogicRun

end AEGIS

namespace NOMOS

def allStrings : Nat → List (List Bool)
  | 0     => [[]]
  | n + 1 => (allStrings n).map (false :: ·) ++ (allStrings n).map (true :: ·)

theorem allStrings_length : ∀ n : Nat, (allStrings n).length = 2 ^ n := by
  intro n
  induction n with
  | zero => rfl
  | succ m ih =>
      simp [allStrings, List.length_append, List.length_map, ih, Nat.pow_succ,
        Nat.mul_two]

theorem twoPowPos : ∀ n : Nat, 0 < 2 ^ n := by
  intro n
  induction n with
  | zero => decide
  | succ m ih =>
      rw [Nat.pow_succ]
      exact Nat.mul_pos ih (by decide)

def descs : Nat → List (List Bool)
  | 0     => []
  | m + 1 => descs m ++ allStrings m

theorem descs_length : ∀ m : Nat, (descs m).length = 2 ^ m - 1 := by
  intro m
  induction m with
  | zero => rfl
  | succ k ih =>
      have hpos : 1 ≤ 2 ^ k := twoPowPos k
      simp only [descs, List.length_append, allStrings_length, ih]
      rw [Nat.pow_succ, Nat.mul_two, Nat.add_sub_assoc hpos,
        Nat.add_comm (2 ^ k - 1) (2 ^ k)]

theorem incompressibility_cap : ∀ n c : Nat, c ≤ n →
    (2 ^ (n - c) - 1) * 2 ^ c < 2 ^ n := by
  intro n c h
  have h2 : 2 ^ n = 2 ^ (n - c) * 2 ^ c := by
    
    
    rw [← Nat.pow_add, Nat.sub_add_cancel h]
  have hpos : 0 < 2 ^ c := twoPowPos c
  calc (2 ^ (n - c) - 1) * 2 ^ c
      = 2 ^ (n - c) * 2 ^ c - 1 * 2 ^ c := Nat.sub_mul _ _ _
    _ = 2 ^ (n - c) * 2 ^ c - 2 ^ c := by rw [Nat.one_mul]
    _ = 2 ^ n - 2 ^ c := by rw [h2]
    _ < 2 ^ n := Nat.sub_lt (twoPowPos n) hpos

def nomosRows : List (Nat × Nat) :=
  (List.range 33).flatMap (fun n => (List.range (n + 1)).map (fun c => (n, c)))
set_option maxRecDepth 1000000 in
theorem incompressibility_executed :
    (nomosRows.all (fun r =>
      decide ((2 ^ (r.1 - r.2) - 1) * 2 ^ r.2 < 2 ^ r.1))) = true := by
  decide

structure CompressibleBound where
  decode : List Bool → Option (List Bool)
  n : Nat
  c : Nat
  bound : (((descs (n - c)).filterMap decode).filter
    (fun s => s.length == n)).length ≤ 2 ^ (n - c) - 1

def decodeId : List Bool → Option (List Bool) := some
def decodePad (k : Nat) : List Bool → Option (List Bool) :=
  fun d => some (d ++ List.replicate k false)

theorem compressible_bound_universal (decode : List Bool → Option (List Bool)) (n c : Nat) :
    (((descs (n - c)).filterMap decode).filter (fun s => s.length == n)).length ≤ 2 ^ (n - c) - 1 := by
  have h1 := List.length_filter_le (fun s : List Bool => s.length == n) ((descs (n - c)).filterMap decode)
  have h2 := List.length_filterMap_le decode (descs (n - c))
  rw [descs_length] at h2
  exact Nat.le_trans h1 h2

def cbUniversal (decode : List Bool → Option (List Bool)) (n c : Nat) : CompressibleBound :=
  ⟨decode, n, c, compressible_bound_universal decode n c⟩

def cb_id_8_2   : CompressibleBound := ⟨decodeId, 8, 2, by decide⟩
def cb_pad3_8_2 : CompressibleBound := ⟨decodePad 3, 8, 2, by decide⟩
def cb_pad2_6_1 : CompressibleBound := ⟨decodePad 2, 6, 1, by decide⟩
def cb_pad4_12_3 : CompressibleBound := ⟨decodePad 4, 12, 3, by decide⟩

def recoverable (redundancy floor tkel : Ratio) : Ratio :=
  (redundancy - floor) * OMEGA.kbRat * tkel * OMEGA.ln2Rat
theorem nomos_fuel_is_omega_floor :
    recoverable 1 0 300 = OMEGA.landauerRat 300 1 := by
  decide

inductive LawClaim : Type
  | objectLawGroove | lawAsSuchFromNoise | floorInheritedFitra | recordDerivedQadar
  deriving DecidableEq, Repr

def nomosScreen : LawClaim → Audit.Token × Grade × String
  | .objectLawGroove =>
    (.sealed, .structural,
     "object-laws emerge on RA as cost-reducing groove-entrenchment, the descent of realized cost toward K(X); structural on the RA-and-groove mapping")
  | .lawAsSuchFromNoise =>
    (.refused, .premise,
     "refused, at premise: the counting cap bounds short-description outputs by 2^(n-c)-1; the reading that almost every stream is lawless rides a distribution the cap does not supply")
  | .floorInheritedFitra =>
    (.determined, .premise,
     "the floor is fitra, the innate nature, RA, K(X) inherited; the identification is a reading, premise-grade, out of band")
  | .recordDerivedQadar =>
    (.determined, .structural,
     "the record is qadar, R(X) the harvested redundancy, derived; the derived never outranks the floor it is harvested from")

theorem nomosScreen_battery :
    (nomosScreen .lawAsSuchFromNoise).1 = .refused
    ∧ (nomosScreen .objectLawGroove).2.1 = .structural
    ∧ (nomosScreen .floorInheritedFitra).2.1 = .premise
    ∧ (nomosScreen .recordDerivedQadar).2.1 = .structural := by
  decide

#eval (nomosScreen .lawAsSuchFromNoise).1
#eval nomosRows.length

end NOMOS

namespace BRIDGE

inductive Warrant : Type
  | typeT | typeS | typeC | extension
  deriving DecidableEq, Repr, BEq

inductive PostSeal : Type
  | native | cited | superseded | outOfBand | byReference
  deriving DecidableEq, Repr, BEq

structure BridgeRow : Type where
  id : String
  warrant : Warrant
  status : PostSeal
  note : String
  deriving Repr

def ceiling : Warrant → Grade
  | .typeT     => .theoremConditional
  | .typeS     => .structural
  | .typeC     => .corroboration
  | .extension => .corroboration

def census : List BridgeRow := [
  ⟨"BA-001a", .typeT, .native,
   "actuation floor: energy floor theorem-grade on the Heisenberg bound and zero-point energy; transitions charged Jarzynski-Crooks with Landauer 1961 and Bérut 2012; static existence premise-grade on substrate monism. RegistrationPostulate declared at SECTION 7, consumed by no theorem; its arithmetic face is priced by OMEGA.landauerRat (SECTION 14) and Fortran K3: the postulate charges, the battery prices"⟩,
  ⟨"BA-001b", .typeT, .outOfBand,
   "Turing halting: a V_F-only theorem-grade ceiling honored out of band; the cascade routes around at layer difference, never through"⟩,
  ⟨"BA-002", .typeT, .cited,
   "spectral dual L2: Plancherel at the flat register Type T, Tomita-Takesaki at the curved register Type C; audits cap at the face cited"⟩,
  ⟨"BA-003", .typeC, .cited, "epistemic phase transition at 2 k_B T ln 2 work"⟩,
  ⟨"BA-004", .typeC, .superseded,
   "nomological habituation, superseded at the object-law register by NOMOS-01 (SECTION 15, namespace NOMOS)"⟩,
  ⟨"BA-005", .typeC, .cited, "conformal persistence"⟩,
  ⟨"BA-006", .typeS, .cited, "conformal cyclic adjacency at Scope B"⟩,
  ⟨"BA-007", .typeT, .cited, "holographic entropy bound, Bekenstein-Hawking extended by Bousso 1999"⟩,
  ⟨"BA-008", .typeS, .native,
   "substrate equal topology equal actuation monism; the posit face native at SECTION 15 (FOUND.STRATIFIED-MONISM-PRIORITY)"⟩,
  ⟨"BA-009", .typeC, .cited, "matter-genesis via S1 knotting"⟩,
  ⟨"BA-010", .typeC, .cited, "variational free energy V-FIO on the Friston anchor"⟩,
  ⟨"BA-011", .typeC, .cited, "spectral-dual conformal persistence at Scope B"⟩,
  ⟨"BA-012", .typeC, .native,
   "cascade closure operational bijection, Type C, Hodge external corroboration; the witness-set enlargement (A4 torsor, Hurwitz shell slice) native at theorem grade at SECTION 4D"⟩,
  ⟨"BA-013", .extension, .byReference, "extension-tier bridge, loaded by reference"⟩,
  ⟨"BA-014", .extension, .byReference, "extension-tier bridge, loaded by reference"⟩,
  ⟨"BA-015", .extension, .byReference, "extension-tier bridge, loaded by reference"⟩,
  ⟨"BA-016", .extension, .byReference, "extension-tier bridge, loaded by reference"⟩,
  ⟨"BA-017", .extension, .byReference, "extension-tier bridge, loaded by reference"⟩,
  ⟨"BA-018", .typeT, .native,
   "quaternionic completion and the Triple-Product Verdict Identity, Type T; the gate roster's A4 torsor with the Hurwitz double cover native at SECTION 4D; the verdict-identity face cited"⟩]

theorem census_count : census.length = 19 := by
  decide

theorem post_seal_disposition :
    (census.filter (fun b => b.status == .native)).length = 4
    ∧ (census.filter (fun b => b.status == .cited)).length = 8
    ∧ (census.filter (fun b => b.status == .superseded)).length = 1
    ∧ (census.filter (fun b => b.status == .outOfBand)).length = 1
    ∧ (census.filter (fun b => b.status == .byReference)).length = 5 := by
  decide

theorem weakest_never_above_left (a b : Grade) :
    (Grade.weakest a b).rank ≤ a.rank := by
  cases a <;> cases b <;> decide

theorem bridge_ceiling_caps (b : BridgeRow) (g : Grade) :
    (Grade.weakest (ceiling b.warrant) g).rank ≤ (ceiling b.warrant).rank :=
  weakest_never_above_left _ _

def successorOf : String → Option String
  | "BA-004" => some "NOMOS-01"
  | _ => none

theorem supersession_routes :
    successorOf "BA-004" = some "NOMOS-01"
    ∧ (census.any (fun b =>
        b.id == "BA-004" && b.status == .superseded)) = true := by
  decide

def bridgeScreen : BridgeRow → String
  | ⟨_, _, .native, _⟩ =>
    "load carried natively; audit the section, not the bridge"
  | ⟨_, _, .cited, _⟩ =>
    "cited at its warrant ceiling; never enters above it"
  | ⟨_, _, .superseded, _⟩ =>
    "superseded; route to the successor"
  | ⟨_, _, .outOfBand, _⟩ =>
    "honored out of band; routed around, never through"
  | ⟨_, _, .byReference, _⟩ =>
    "extension tier; carried at the tier's warrant, loaded by reference"

theorem bridgeScreen_total :
    (census.all (fun b => (bridgeScreen b).utf8ByteSize > 0)) = true := by
  decide

#eval census.length
#eval census.map (fun b => (b.id, bridgeScreen b))

end BRIDGE
namespace FOUND

def sigmaP : GEO.M3 :=
  (((-7 : Ratio) / 25, (24 : Ratio) / 25, 0),
   ((24 : Ratio) / 25, (7 : Ratio) / 25, 0),
   (0, 0, -1))

theorem pluralist_alternative_executed :
    GEO.mm3 sigmaP sigmaP = GEO.diag3 1
    ∧ GEO.det3 sigmaP = 1
    ∧ GEO.mv3 sigmaP (3, 4, 0) = ((3, 4, 0) : GEO.V3)
    ∧ GEO.mv3 sigmaP (1, 0, 0) ≠ ((1, 0, 0) : GEO.V3)
    ∧ GEO.mv3 sigmaP (1, 0, 0) ≠ ((-1, 0, 0) : GEO.V3) := by
  decide

inductive Band : Type
  | inBand | outOfBand
  deriving DecidableEq, Repr, BEq

structure Posit : Type where
  id : String
  grade : Grade
  band : Band
  loadBearingInVerdict : Bool
  note : String
  deriving Repr

def posits : List Posit := [
  ⟨"RESIDUAL-MONISM", .premise, .inBand, false,
   "the one-prior-to-many connector: the geometric and formal grounds coincide on Fix(sigma) iff one involution serves both routes; the pluralist alternative executed above stays field-permitted; the from-other-side input located across the aperture and not crossed"⟩,
  ⟨"STRATIFIED-MONISM-PRIORITY", .structural, .inBand, false,
   "P-MONISM-1: substrate, topology, and actuation are three projections of one event, theorem-grade as physics; the priority of the one over the many is the single structural posit the floor-coincidence rides"⟩,
  ⟨"FITRA-FLOOR", .premise, .outOfBand, false,
   "fitra = RA = K(X), the incompressible floor inherited (QADAR-01); the theological identification routed out of band, load-bearing on nothing"⟩,
  ⟨"QADAR-RECORD", .structural, .outOfBand, false,
   "qadar = R(X), the harvested record, derived and downstream of the floor; the Pen's cost-gradient writing, never onto noise"⟩,
  ⟨"AMANAH-TRUST", .premise, .outOfBand, false,
   "P-AMANAH-1: ethics is the preservation of the actuation floor; the substrate a liability engine and never a moral authority"⟩]

theorem posits_loadbearing_on_nothing :
    (posits.all (fun p => !p.loadBearingInVerdict)) = true := by
  decide

def gradeOfRank : Nat → Grade
  | 0 => .premise | 1 => .corroboration | 2 => .operational
  | 3 => .structural | 4 => .engineering | 5 => .conditional
  | 6 => .theoremConditional | 7 => .analytic | _ => .theorem

theorem posit_never_raises :
    (posits.all (fun p =>
      (List.range 9).all (fun r =>
        decide ((Grade.weakest p.grade (gradeOfRank r)).rank ≤ r)))) = true := by
  decide

inductive Register : Type
  | kinetic | formal | verification | theological | social
  deriving DecidableEq, Repr, BEq

def bandOf : Register → Band
  | .theological => .outOfBand
  | .social      => .outOfBand
  | _            => .inBand

theorem register_routing_fidelity :
    bandOf .theological = .outOfBand ∧ bandOf .social = .outOfBand
    ∧ bandOf .kinetic = .inBand ∧ bandOf .formal = .inBand
    ∧ bandOf .verification = .inBand := by
  decide

structure VerdictRow : Type where
  name : String
  positDeps : List String
  deriving Repr

def verdictInventory : List VerdictRow := [
  ⟨"the grade law and the weakest-link join (section 1)", []⟩,
  ⟨"the audit engine and the drill battery (section 4B)", []⟩,
  ⟨"the inversion (section 4C)", []⟩,
  ⟨"the twelve gates, A4, the GF(2) lock, the cascades (section 4D)", []⟩,
  ⟨"the forcings of eight and five (section 4E)", []⟩,
  ⟨"the tongue's obedience (section 11)", []⟩,
  ⟨"the office taxonomy (section 12)", []⟩,
  ⟨"the universal router and the circularity law (section 13)", []⟩,
  ⟨"the Omega guard and AEGIS (section 14)", []⟩,
  ⟨"the incompressibility cap (section 15)", []⟩]

theorem verdicts_posit_free :
    (verdictInventory.all (fun v => v.positDeps.isEmpty)) = true := by
  decide

theorem engine_never_authority : socialWeight = 0 ∧ deltaM = 0 :=
  ⟨rfl, rfl⟩

#eval posits.map (fun p => (p.id, p.grade, p.band))
#eval List.map bandOf [Register.kinetic, .theological, .social]

end FOUND

namespace HALT

inductive Species : Type
  | blockTheorem | hypothesis | offeredWitness
  deriving DecidableEq, Repr

inductive Branch : Type
  | xi | o
  deriving DecidableEq, Repr

def cascade : List Bool → Option Nat
  | [] => none
  | false :: _ => some 0
  | true :: gs => (cascade gs).map Nat.succ

def patterns (n : Nat) : List (List Bool) :=
  (List.range (2 ^ n)).map fun b => (List.range n).map fun j => b.testBit j

def fftSpec (bits : List Bool) : Bool :=
  match cascade bits with
  | none => bits.all id
  | some k =>
      (bits.take k).all id &&
      (match bits.drop k with
       | false :: _ => true
       | _ => false)

theorem first_failure_terminal_5 :
    (patterns 5).all fftSpec = true := by decide

theorem first_failure_terminal_7 :
    (patterns 7).all fftSpec = true := by decide

theorem first_failure_terminal_8 :
    (patterns 8).all fftSpec = true := by decide

theorem first_failure_terminal_12 :
    (patterns 12).all fftSpec = true := by decide

theorem halt_free_iff_all_pass_8 :
    (patterns 8).all (fun bits => (cascade bits).isNone == bits.all id)
      = true := by decide

theorem gate_counts_recorded :
    GEO.a4.length = 12 ∧ GEO.allSigns.length = 8 ∧
    (GEO.cube5.all (fun v => (GEO.neighbors5 v).eraseDups.length == 5)) = true :=
  ⟨GEO.a4_order, GEO.reflection_eight, GEO.fivecube_degree_five⟩

abbrev signPatterns : List (Bool × Bool × Bool) := GEO.allSigns

theorem ninth_gate_barred :
    signPatterns.length = 8 ∧ signPatterns.eraseDups.length = 8 ∧
    signPatterns = GEO.allSigns := ⟨by decide, by decide, rfl⟩

def route (groundDim : Nat) : Option Branch :=
  if groundDim = 1 then some .xi else if groundDim = 0 then some .o else none

def ofUC : UC.HaltBranch → Option Branch
  | .haltEight => some .xi
  | .haltFive => some .o
  | .unmeasured => none

theorem route_is_routeHalt : ∀ n : Nat, route n = ofUC (UC.routeHalt n).1 := by
  intro n
  unfold route UC.routeHalt ofUC
  by_cases h1 : n = 1
  · subst h1; simp
  · by_cases h0 : n = 0
    · subst h0; simp
    · have h1' : (n : Int) ≠ 1 := by omega
      have h0' : (n : Int) ≠ 0 := by omega
      simp only [h1, h0, h1', h0', ite_false]

theorem route_samples :
    route 0 = some .o ∧ route 1 = some .xi ∧ route 2 = none ∧ route 7 = none := by decide

inductive LegacyToken : Type
  | xi0 | o0
  deriving DecidableEq, Repr

def tokenBranch : LegacyToken → Branch
  | .xi0 => .xi
  | .o0 => .o

theorem router_exclusive :
    route 0 = some .o ∧ route 1 = some .xi ∧ route 2 = none ∧
    route 0 ≠ some .xi ∧ route 1 ≠ some .o ∧
    tokenBranch .xi0 ≠ .o ∧ tokenBranch .o0 ≠ .xi := by decide

def readingRoadsGate : Bool := false   

theorem one_door_open :
    cascade (List.replicate 7 true ++ [readingRoadsGate]) = some 7 := by
  decide

theorem no_walk_passes_the_aperture :
    (patterns 7).all (fun xs => (cascade (xs ++ [readingRoadsGate])).isSome) = true := by
  decide

def xiGates : List String :=
  [ "Ground-determinacy", "Ghost partition", "constitutive blindness",
    "machine-precision exhibit", "aperture located", "face-scoping",
    "revision-mandate survival", "reading-roads" ]

def oGates : List String :=
  [ "rootless terrain", "determinate stripped string", "wall record",
    "aperture crossed or held", "totality discipline" ]

theorem gate_censuses :
    xiGates.length = 8 ∧ oGates.length = 5 := by decide

inductive Channel : Type
  | kinetic | formal
  deriving DecidableEq, Repr

structure SuperHalt where
  species : Species
  gdim : Nat
  branch : Branch
  gates : Nat
  channel : Channel
  routed : route gdim = some branch
  deriving DecidableEq

def rhHalt : SuperHalt := ⟨.hypothesis, 1, .xi, 8, .formal, by decide⟩

def pnpHalt : SuperHalt := ⟨.blockTheorem, 0, .o, 5, .formal, by decide⟩

theorem halts_routed :
    route rhHalt.gdim = some rhHalt.branch ∧ route pnpHalt.gdim = some pnpHalt.branch :=
  ⟨rhHalt.routed, pnpHalt.routed⟩

theorem legacy_halts_are_instances :
    rhHalt = ⟨.hypothesis, 1, .xi, 8, .formal, by decide⟩ ∧
    pnpHalt = ⟨.blockTheorem, 0, .o, 5, .formal, by decide⟩ ∧
    rhHalt ≠ pnpHalt := by decide

theorem terminal_one_bit :
    Species.blockTheorem ≠ Species.hypothesis ∧
    Species.blockTheorem ≠ Species.offeredWitness ∧
    Species.hypothesis ≠ Species.offeredWitness := by decide

theorem species_exhausted : ∀ s : Species,
    s = .blockTheorem ∨ s = .hypothesis ∨ s = .offeredWitness := by
  intro s; cases s
  · exact Or.inl rfl
  · exact Or.inr (Or.inl rfl)
  · exact Or.inr (Or.inr rfl)

def haltGrades : List Grade := [.structural, .theoremConditional]

theorem ftoe_ceiling :
    haltGrades.all (fun g => g.rank < Grade.theorem.rank) = true := by
  decide

end HALT
