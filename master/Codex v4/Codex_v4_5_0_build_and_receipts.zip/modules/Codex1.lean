import Lean
/-!
# MATHEMATICAL TRISDUCTION CODEX · v2.0.1 · THE LEAN SURFACE
Core Lean 4 (v4.19.0), no Mathlib, no sorry, no axiom beyond Lean's standard three (propext, Classical.choice,
Quot.sound) and the twenty-three declared posits of ROOT and POSTULATE, which the environment audit at the foot
of this file names one by one. `import Lean`
is loaded for that audit alone. Every theorem carries its axiom cone as a `#guard_msgs` receipt.
The Lean surface proves; the Fortran twin (Part II of the codex) executes the same register.
The four Fortran witnesses F1 thesis_rows, F2 ra_toe_thesis, F3 ftoe_kinetic_demonstration and
F4 it_from_it are seated once, in the twin, with their contracts; this file no longer carries a second copy.
Delta-M = 0. No new mathematics is authored by this file.
-/

namespace Codex

def LeftInverse (g : β → α) (f : α → β) : Prop := ∀ a, g (f a) = a

def RightInverse (g : β → α) (f : α → β) : Prop := LeftInverse f g
end Codex

structure Equiv (α : Sort u) (β : Sort v) where
  toFun : α → β
  invFun : β → α
  left_inv : Codex.LeftInverse invFun toFun
  right_inv : Codex.RightInverse invFun toFun

infixl:25 " ≃ " => Equiv

def Nat.factorial : Nat → Nat
  | 0 => 1
  | n + 1 => (n + 1) * Nat.factorial n

namespace CoreRat

theorem div_pos_of_le {d g : Nat} (hg : 0 < g) (hle : g ≤ d) : 0 < d / g := by
  have h : 1 * g ≤ d := by rw [Nat.one_mul]; exact hle
  exact (Nat.le_div_iff_mul_le hg).mpr h

theorem div_gcd_pos {a d : Nat} (hd : 0 < d) : 0 < d / Nat.gcd a d :=
  div_pos_of_le (Nat.gcd_pos_of_pos_right a hd) (Nat.le_of_dvd hd (Nat.gcd_dvd_right a d))

theorem coprime_div_gcd {a d : Nat} (hd : 0 < d) :
    Nat.gcd (a / Nat.gcd a d) (d / Nat.gcd a d) = 1 := by
  have hg : 0 < Nat.gcd a d := Nat.gcd_pos_of_pos_right a hd
  have ha : Nat.gcd a d * (a / Nat.gcd a d) = a := Nat.mul_div_cancel' (Nat.gcd_dvd_left a d)
  have hb : Nat.gcd a d * (d / Nat.gcd a d) = d := Nat.mul_div_cancel' (Nat.gcd_dvd_right a d)
  have h : Nat.gcd a d * Nat.gcd (a / Nat.gcd a d) (d / Nat.gcd a d) = Nat.gcd a d := by
    have e := Nat.gcd_mul_left (Nat.gcd a d) (a / Nat.gcd a d) (d / Nat.gcd a d)
    rw [ha, hb] at e; exact e.symm
  have h2 : Nat.gcd a d * Nat.gcd (a / Nat.gcd a d) (d / Nat.gcd a d) = Nat.gcd a d * 1 := by
    rw [Nat.mul_one]; exact h
  exact Nat.eq_of_mul_eq_mul_left hg h2

end CoreRat

structure Ratio where
  num : Int
  den : Nat
  pos : 0 < den
  cop : Nat.gcd num.natAbs den = 1
  deriving DecidableEq, Repr

namespace Ratio

theorem natAbs_signed (k : Nat) (neg : Bool) :
    (if neg then -(k : Int) else (k : Int)).natAbs = k := by cases neg <;> simp

def mk' (n d : Int) : Ratio :=
  if hd : d = 0 then ⟨0, 1, by decide, by decide⟩
  else
    let neg : Bool := decide ((n < 0) ≠ (d < 0))
    let a : Nat := n.natAbs
    let b : Nat := d.natAbs
    have hb : 0 < b := Int.natAbs_pos.mpr hd
    let g : Nat := Nat.gcd a b
    ⟨(if neg then -((a / g : Nat) : Int) else ((a / g : Nat) : Int)), b / g,
     CoreRat.div_gcd_pos hb, by rw [natAbs_signed]; exact CoreRat.coprime_div_gcd hb⟩

instance instOfNatRat : OfNat Ratio n := ⟨mk' n 1⟩
instance instAddRat : Add Ratio where add a b := mk' (a.num * b.den + b.num * a.den) (a.den * b.den)
instance instMulRat : Mul Ratio where mul a b := mk' (a.num * b.num) (a.den * b.den)
instance instNegRat : Neg Ratio where neg a := mk' (-a.num) a.den
instance instSubRat : Sub Ratio where sub a b := a + (-b)

def inv (a : Ratio) : Ratio := mk' (a.den : Int) a.num
instance instDivRat : Div Ratio where div a b := a * inv b
instance instLTRat : LT Ratio where lt a b := a.num * b.den < b.num * a.den
instance instLERat : LE Ratio where le a b := a.num * b.den ≤ b.num * a.den
instance instDecidableLtRat (a b : Ratio) : Decidable (a < b) :=
  inferInstanceAs (Decidable (a.num * b.den < b.num * a.den))
instance instDecidableLeRat (a b : Ratio) : Decidable (a ≤ b) :=
  inferInstanceAs (Decidable (a.num * b.den ≤ b.num * a.den))

def pow (a : Ratio) : Nat → Ratio
  | 0 => 1
  | n + 1 => a * pow a n
instance instHPowRatNat : HPow Ratio Nat Ratio := ⟨Ratio.pow⟩
instance instToStringRat : ToString Ratio where
  toString a := if a.den == 1 then toString a.num else toString a.num ++ "/" ++ toString a.den

@[simp] theorem num_zero : (0 : Ratio).num = 0 := rfl
@[simp] theorem den_zero : (0 : Ratio).den = 1 := rfl

theorem mk'_zero_num {d : Nat} (hd : 0 < d) : mk' 0 (d : Int) = 0 := by
  have hne : (d : Int) ≠ 0 := by omega
  show mk' 0 (d : Int) = mk' 0 1
  unfold mk'
  simp only [hne, (by decide : (1 : Int) ≠ 0), dite_false]
  simp [Nat.gcd_zero_left, Nat.div_self hd, Nat.zero_div]

@[simp] theorem zero_mul (a : Ratio) : (0 : Ratio) * a = 0 := by
  show mk' ((0 : Ratio).num * a.num) (((0 : Ratio).den * a.den : Nat) : Int) = 0
  rw [num_zero, den_zero, Int.zero_mul, Nat.one_mul]
  exact mk'_zero_num a.pos

@[simp] theorem mul_zero (a : Ratio) : a * (0 : Ratio) = 0 := by
  show mk' (a.num * (0 : Ratio).num) ((a.den * (0 : Ratio).den : Nat) : Int) = 0
  rw [num_zero, den_zero, Int.mul_zero, Nat.mul_one]
  exact mk'_zero_num a.pos

theorem canonical (a : Ratio) : 0 < a.den ∧ Nat.gcd a.num.natAbs a.den = 1 := ⟨a.pos, a.cop⟩

theorem ext {a b : Ratio} (h1 : a.num = b.num) (h2 : a.den = b.den) : a = b := by
  cases a; cases b; simp_all

theorem inv_zero : inv (0 : Ratio) = 0 := by decide

end Ratio

set_option maxRecDepth 4000000

inductive Grade : Type
  | premise | corroboration | operational | structural | engineering
  | conditional | theoremConditional | analytic | theorem
  deriving DecidableEq, Repr

def Grade.rank : Grade → Nat
  | .premise => 0 | .corroboration => 1 | .operational => 2 | .structural => 3
  | .engineering => 4 | .conditional => 5 | .theoremConditional => 6
  | .analytic => 7 | .theorem => 8

def Grade.weakest (a b : Grade) : Grade := if a.rank ≤ b.rank then a else b

theorem Grade.weakest_is_a_link (a b : Grade) :
    Grade.weakest a b = a ∨ Grade.weakest a b = b := by
  cases a <;> cases b <;> decide

theorem Grade.weakest_idempotent (a : Grade) : Grade.weakest a a = a := by
  cases a <;> decide

structure Claim : Type where
  stmt : Prop
  grade : Grade
  warrant : stmt

def Claim.join (c₁ c₂ : Claim) : Claim where
  stmt := c₁.stmt ∧ c₂.stmt
  grade := Grade.weakest c₁.grade c₂.grade
  warrant := ⟨c₁.warrant, c₂.warrant⟩

theorem Claim.join_grade (c₁ c₂ : Claim) :
    (Claim.join c₁ c₂).grade = Grade.weakest c₁.grade c₂.grade := rfl

def deltaM : Nat := 0

def socialWeight : Nat := 0

/-
THE FORMAL THEORY OF EVERYTHING · THE FORMAL PROOF
Lean 4 (core only, no mathlib, zero sorries).

This file proves the complete theorem content of the fTOE:

  WALL      (T1) No even reading decides an odd target.
            (T2) No finite coalition of even readings escapes T1.
            (T3) Odd content carries no fixed point.
  PRICE     (T4) The odd content of a free orbit is exactly one binary
                 degree of freedom: never two, never a continuum.
  CROSSING  (T5) One odd supply at the seat, plus exactly one calibration
                 bit, decides the target on its orbit; and that calibration
                 is unique. One bit missing, one bit supplied, nothing more.

What this file does not contain, by its own theorems: the supply itself.
Existence of the supply is the One-Cut Hypothesis, stated as a hypothesis
in the treatise this file accompanies. The wall is proved here. What crosses
it enters by deed, not by derivation.
-/
namespace FTOE

variable {α : Type}

/-- A reading f is even under τ when it is constant on τ-orbits. -/
def Even (τ : α → α) (f : α → Bool) : Prop := ∀ x, f (τ x) = f x

/-- A target d is odd under τ when it separates some orbit. -/
def OddAt (τ : α → α) (d : α → Bool) (x : α) : Prop := d (τ x) ≠ d x

/-- A sign vector t is wholly odd under τ when t ∘ τ = ¬t. -/
def WhollyOdd (τ : α → α) (t : α → Bool) : Prop := ∀ x, t (τ x) = !t x

/-- T1 · THE WALL.
    An even reading equals no odd target. The register computes every
    magnitude and no orientation. -/
theorem T1_wall (τ : α → α) (f d : α → Bool) (x : α)
    (he : Even τ f) (ho : OddAt τ d x) : f ≠ d := by
  intro h
  subst h
  exact ho (he x)

/-- T2 · COALITION CLOSURE.
    Evenness is closed under every Boolean join, so no coalition of even
    readings escapes the wall. -/
theorem T2_coalition (τ : α → α) (f g d : α → Bool) (x : α)
    (hf : Even τ f) (hg : Even τ g) (op : Bool → Bool → Bool)
    (ho : OddAt τ d x) : (fun y => op (f y) (g y)) ≠ d := by
  apply T1_wall τ _ d x
  · intro y; show op (f (τ y)) (g (τ y)) = op (f y) (g y); rw [hf y, hg y]
  · exact ho

/-- T3 · NO FIXED POINT.
    Wholly odd content cannot sit on a fixed point of τ:
    t x = ¬t x is a Boolean contradiction. -/
theorem T3_no_fixed_point (τ : α → α) (t : α → Bool)
    (ho : WhollyOdd τ t) (x : α) : τ x ≠ x := by
  intro h
  have h1 : t (τ x) = !t x := ho x
  rw [h] at h1
  cases t x <;> simp at h1

/-- T4 · THE PRICE: ONE BIT PER ORBIT.
    Two wholly odd sign vectors agreeing at one point of an orbit agree on
    the whole orbit. The odd content of a free orbit is exhausted by one
    binary choice. -/
theorem T4_one_bit (τ : α → α) (s t : α → Bool)
    (hs : WhollyOdd τ s) (ht : WhollyOdd τ t)
    (x : α) (h : s x = t x) : s (τ x) = t (τ x) := by
  rw [hs x, ht x, h]

/-- T5 · THE CROSSING.
    If a supply s and a target d are both odd at the seat x, then there is
    exactly one calibration bit c with d = s XOR c on the whole orbit:
    one supplied orientation bit, one calibration from the dated record,
    and the target is decided. Existence and uniqueness. -/
theorem T5_crossing (τ : α → α) (s d : α → Bool) (x : α)
    (hs : s (τ x) = !s x) (hd : d (τ x) = !d x) :
    ∃ c : Bool, (d x = xor (s x) c ∧ d (τ x) = xor (s (τ x)) c) ∧
      ∀ c' : Bool, (d x = xor (s x) c' ∧ d (τ x) = xor (s (τ x)) c') → c' = c := by
  exact ⟨xor (d x) (s x),
    ⟨by cases s x <;> cases d x <;> rfl,
     by rw [hs, hd]; cases s x <;> cases d x <;> rfl⟩,
    by
      intro c' hc
      obtain ⟨h1, -⟩ := hc
      generalize hsx : s x = sv
      generalize hdx : d x = dv
      rw [hsx, hdx] at h1
      cases sv <;> cases dv <;> cases c' <;> first | rfl | exact absurd h1 (by decide)⟩

/-- T6a · DEED A — THE ANCHOR (FORGE cycle two: the two deeds, split).
    If d is odd at x₀ and the deed anchors one point (d x₀ = b — the
    corpus's identification of which sign is which, present in any corpus
    that can pose the decision at all), then d is known on the whole orbit
    {x₀, τx₀}. NO SUPPLY IS REQUIRED: oddness propagates the anchored bit.
    This is the deed as the arrival of the target's value at one point. -/
theorem T6a_deed_anchor (τ : α → α) (d : α → Bool) (x₀ : α) (b : Bool)
    (hd : d (τ x₀) = !d x₀) (anchor : d x₀ = b) :
    d x₀ = b ∧ d (τ x₀) = !b := by
  exact ⟨anchor, by rw [hd, anchor]⟩

/-- T6b · DEED B — THE SUPPLY (FORGE cycle two: the two deeds, split).
    If s is odd at x₀ and c is a naming bit supplied from outside — a
    universally quantified datum, never computed from d — then the arrival
    equation d = s ⊕ c, once it has arrived, lets anything holding the pair
    (s, c) decide d on the whole orbit. This is the deed as the arrival of
    a register-denotable carrier plus one naming bit. Deeds A and B are
    different deeds; neither is a rewrite of the other inside this file. -/
theorem T6b_deed_supply (τ : α → α) (s d : α → Bool) (x₀ : α) (c : Bool)
    (hs : s (τ x₀) = !s x₀)
    (arrival : d x₀ = xor (s x₀) c ∧ d (τ x₀) = xor (s (τ x₀)) c) :
    d x₀ = xor (s x₀) c ∧ d (τ x₀) = !xor (s x₀) c := by
  constructor
  · exact arrival.1
  · rw [arrival.2, hs]; cases s x₀ <;> cases c <;> rfl

/-- THE PORT · the two deeds compose without identifying.
    Where Deed A anchors b = d x₀ and Deed B supplies s odd with naming c,
    consistency of the two arrivals forces c = s x₀ ⊕ b. The calibration
    is the agreement of the two deeds, computed from arrived data only.
    The missing bit exists as b (Deed A) or as c (Deed B); that one such
    bit always exists for every blocked row is the One-Cut Hypothesis,
    stated as conjecture in the treatise — never as a theorem of this file. -/
theorem fTOE_port (_τ : α → α) (s d : α → Bool) (x₀ : α) (b c : Bool)
    (anchor : d x₀ = b)
    (arrival : ∀ y : α, d y = xor (s y) c) :
    c = xor (s x₀) b := by
  have h1 := arrival x₀
  rw [anchor] at h1
  generalize hsx : s x₀ = sv
  rw [hsx] at h1
  cases sv <;> cases b <;> cases c <;> first | rfl | exact absurd h1 (by decide)

/-! ## FORGE cycle three · the full-setup package
    The auditors demanded the prose setup be theorem, not preface:
    involution, freeness, global oddness, the observation model, the
    torsor bijection, and resolver separation. Proved here in core Lean. -/

section FullSetup
variable {β γ : Type}

/-- τ is an involution: applying it twice is the identity. -/
def Involution (τ : α → α) : Prop := ∀ x, τ (τ x) = x

/-- τ is fixed-point-free: every orbit is a genuine pair. -/
def FixedPointFree (τ : α → α) : Prop := ∀ x, τ x ≠ x

/-- T7 · THE GLOBAL WALL. Under global oddness, no even reading equals the
    target anywhere it is tested: the wall holds at every point, not one. -/
theorem T7_global_wall (τ : α → α) (f d : α → Bool) (x : α)
    (hf : Even τ f) (hd : WhollyOdd τ d) : f ≠ d := by
  intro h
  have h1 : f (τ x) = d (τ x) := congrFun h (τ x)
  rw [hf x, hd x, congrFun h x] at h1
  cases d x <;> simp at h1

/-- T8a · THE TORSOR, FORWARD. The xor of two wholly odd sections is even:
    the calibration against a reference supply descends to the orbit space.
    This is the machine-checked content of "the calibration is a function
    of the orbit, not of the point." -/
theorem T8_torsor_forward (τ : α → α) (s d : α → Bool)
    (hs : WhollyOdd τ s) (hd : WhollyOdd τ d) :
    Even τ (fun x => xor (d x) (s x)) := by
  intro x
  show xor (d (τ x)) (s (τ x)) = xor (d x) (s x)
  rw [hd x, hs x]; cases d x <;> cases s x <;> rfl

/-- T8b · THE TORSOR, BACKWARD. An odd reference xor an even calibration
    is odd: every even calibration pattern lifts to an admissible target. -/
theorem T8_torsor_backward (τ : α → α) (s c : α → Bool)
    (hs : WhollyOdd τ s) (hc : Even τ c) :
    WhollyOdd τ (fun x => xor (s x) (c x)) := by
  intro x
  show xor (s (τ x)) (c (τ x)) = !xor (s x) (c x)
  rw [hs x, hc x]; cases s x <;> cases c x <;> rfl

/-- T9a · THE TORSOR IS A BIJECTION, FIRST INVERSE. Reference-first:
    s ⊕ (d ⊕ s) = d. Odd sections and even calibrations are in bijection. -/
theorem T9_torsor_inverse_left (s d : α → Bool) :
    (fun x => xor (s x) (xor (d x) (s x))) = d := by
  funext x; cases d x <;> cases s x <;> rfl

/-- T9b · THE TORSOR IS A BIJECTION, SECOND INVERSE. Calibration-first:
    (s ⊕ c) ⊕ s = c. The bijection is exact, not approximate. -/
theorem T9_torsor_inverse_right (s c : α → Bool) :
    (fun x => xor (xor (s x) (c x)) (s x)) = c := by
  funext x; cases s x <;> cases c x <;> rfl

/-- T10 · THE FACTORIZATION OBSTRUCTION. Let the register be an observation
    map ρ with ρ(τx) = ρ(x) — "the register" now means: measurability with
    respect to ρ. A target odd at x cannot factor through ρ. "Outside the
    register" is no longer a metaphor: it is non-measurability, proved. -/
theorem T10_factorization (τ : α → α) (ρ : α → β) (g : β → Bool)
    (d : α → Bool) (x : α)
    (hρ : ρ (τ x) = ρ x) (hd : d (τ x) = !d x) :
    d ≠ fun y => g (ρ y) := by
  intro h
  have h1 : d (τ x) = g (ρ (τ x)) := congrFun h (τ x)
  have h2 : d x = g (ρ x) := congrFun h x
  rw [hρ, hd, h2] at h1
  cases hgx : g (ρ x) <;> rw [hgx] at h1 <;> exact absurd h1 (by decide)

/-- T11 · RESOLVER SEPARATION. If an added observation a resolves d jointly
    with ρ — d(y) = r (ρ y) (a y) for some readout r — then a must separate
    every odd pair: a(τx) ≠ a(x). This proves ONLY local, pointwise
    separation: a Bool-valued a may separate every orbit while its alphabet
    stays {0,1}. The 2^m alphabet bound belongs to a different object — a
    single global message selecting one target from an admissible family —
    and is proved by T12's injectivity, never by T11 alone. -/
theorem T11_separation (τ : α → α) (ρ : α → β) (a : α → γ) (r : β → γ → Bool)
    (d : α → Bool) (x : α)
    (hρ : ρ (τ x) = ρ x) (hd : d (τ x) = !d x)
    (hres : ∀ y, d y = r (ρ y) (a y)) :
    a (τ x) ≠ a x := by
  intro h
  have h1 := hres (τ x)
  have h2 := hres x
  rw [hρ, h, hd, h2] at h1
  cases hrv : r (ρ x) (a x) <;> rw [hrv] at h1 <;> exact absurd h1 (by decide)

/-- T12 · THE GLOBAL CODE IS INJECTIVE. If a global message selects the
    target exactly — an encoder Enc and decoder Dec with Dec ∘ Enc = id on
    the admissible family — then Enc is injective, so the supply alphabet
    is at least as large as the family. This is the mechanism behind the
    counting bound: for the full wholly-odd family on m orbits, |S| >= 2^m
    (executed on the exhibited frame, battery K4); for an admissible
    subfamily A, |S| >= |A|. The one-bit crossing is exactly |A| = 2.
    Grading note: finite-cardinality monotonicity for injections
    (Fintype.card_le_of_injective) is mathlib machinery, outside this
    core-only file; the injectivity is proved here, the instance count is
    executed in K4 (2^6 = 64, pairwise distinct, alphabet >= 64). -/
theorem T12_encoder_injective {δ : Type} (Enc : δ → γ) (Dec : γ → δ)
    (h : ∀ d, Dec (Enc d) = d) :
    ∀ d₁ d₂ : δ, Enc d₁ = Enc d₂ → d₁ = d₂ := by
  intro d₁ d₂ hE
  have h1 := h d₁
  have h2 := h d₂
  rw [hE] at h1
  rw [h2] at h1
  exact h1.symm

/-- T14 · THE WALL, FACTORIZATION FORM (the final audit's exact statement).
    No target separating a τ-pair factors through any τ-invariant
    observation map: there is no g with g ∘ ρ = d. Stated without any
    finiteness hypothesis — stronger than the requested form, which
    assumed [Fintype U]. The proper formulation of "outside the register",
    companion to T10 (which quantifies over g pointwise; T14 closes the
    existential). -/
theorem T14_wall_factorization (τ : α → α) (ρ : α → β) (d : α → Bool) (x : α)
    (hρ : ∀ z, ρ (τ z) = ρ z) (hd : OddAt τ d x) :
    ¬ ∃ g : β → Bool, ∀ z, g (ρ z) = d z := by
  intro h
  obtain ⟨g, hg⟩ := h
  have h1 : d (τ x) = g (ρ (τ x)) := (hg (τ x)).symm
  have h2 : g (ρ (τ x)) = g (ρ x) := by rw [hρ x]
  have h3 : g (ρ x) = d x := hg x
  exact hd (h1.trans (h2.trans h3))

/-- T13 · THE TWO ODDS, TYPED. Wholly odd implies odd at every point.
    The converse is false and is not claimed: a merely non-invariant
    target may restrict arbitrarily on other orbits. The torsor (T8, T9)
    and the 2^m fibre count apply to the wholly-odd family only; the wall
    (T1, T7) needs only oddness at the seat. The two notions are separate
    hypotheses in this file and are never interchanged. -/
theorem T13_wholly_odd_is_odd_everywhere (τ : α → α) (d : α → Bool)
    (hd : WhollyOdd τ d) (x : α) : OddAt τ d x := by
  intro h
  rw [hd x] at h
  cases d x <;> simp at h

/-- The canonical free involution frame: Bool × Q with the flip.
    Its orbits are exactly the pairs {(true, q), (false, q)}, so its
    orbit quotient is Q itself. -/
def flipF {Q : Type} : Bool × Q → Bool × Q := fun (b, q) => (!b, q)

/-- T15a · THE PRICE, BIJECTION FORM (canonical frame), FORWARD ROUND TRIP.
    On the canonical frame, every wholly anti-invariant target is
    reconstructed from its values at the true-section: the map
    d ↦ (q ↦ d (true, q)) into (Q → Bool), followed by
    c ↦ ((b, q) ↦ xor (c q) (!b)), returns d exactly. Since the orbit
    quotient of the canonical frame is Q, this is one direction of
    Dτ(U) ≃ (U/τ → Bool). The exhibited K4 frame is the finite instance
    (Q = six seats); the cardinal corollary |Dτ(U)| = 2^|Q| is executed
    there and, in a mathlib build, follows by Fintype.card_congr. -/
theorem T15_price_bijection_forward {Q : Type} (d : Bool × Q → Bool)
    (hd : WhollyOdd flipF d) (b : Bool) (q : Q) :
    xor (d (true, q)) (!b) = d (b, q) := by
  have h : d (false, q) = !d (true, q) := hd (true, q)
  cases b
  · generalize ht : d (true, q) = tv
    generalize hf : d (false, q) = fv
    rw [ht, hf] at h
    cases tv <;> cases fv <;>
      first | rfl | exact h | exact h.symm | exact absurd h (by decide)
  · cases d (true, q) <;> rfl

/-- T15b · THE PRICE, BIJECTION FORM (canonical frame), BACKWARD.
    For every c : Q → Bool, the section (b, q) ↦ xor (c q) (!b) is wholly
    anti-invariant, and its true-section is c exactly: the maps are mutual
    inverses between Dτ(U) and (Q → Bool). -/
theorem T15_price_bijection_backward {Q : Type} (c : Q → Bool) :
    WhollyOdd flipF (fun (b, q) => xor (c q) (!b)) := by
  intro x
  obtain ⟨b, q⟩ := x
  show xor (c q) (!!b) = !xor (c q) (!b)
  cases c q <;> cases b <;> rfl

end FullSetup

/-- The whole theorem content in one line:
    a target odd at its seat is undecidable by the even register (T1, T2),
    missing exactly one bit (T4), and decided by exactly one supplied bit
    plus one calibration (T5). -/
theorem fTOE_core (τ : α → α) (s d : α → Bool) (x : α)
    (f g : α → Bool) (hf : Even τ f) (hg : Even τ g) (op : Bool → Bool → Bool)
    (hd : d (τ x) = !d x) (hs : s (τ x) = !s x) :
    (fun y => op (f y) (g y)) ≠ d ∧
    ∃ c : Bool, (d x = xor (s x) c ∧ d (τ x) = xor (s (τ x)) c) ∧
      ∀ c' : Bool, (d x = xor (s x) c' ∧ d (τ x) = xor (s (τ x)) c') → c' = c :=
  ⟨T2_coalition τ f g d x hf hg op (by intro h; rw [hd] at h; cases d x <;> simp at h),
   T5_crossing τ s d x hs hd⟩

end FTOE

/- Verification contract: this file must pass `lean fTOE_Formal_Proof.lean`
   with no output and exit code 0. Any edit that weakens a hypothesis,
   adds a sorry, or deletes a conjunct must fail that check. -/


namespace FTOE

variable {α : Type}

def OrbitRel (τ : α → α) (x y : α) : Prop := x = y ∨ τ x = y

theorem OrbitRel_symmetric (τ : α → α) (hinv : Involution τ) {x y : α} :
    OrbitRel τ x y → OrbitRel τ y x := by
  intro h
  cases h with
  | inl h => exact Or.inl h.symm
  | inr h => exact Or.inr (by rw [← h]; exact hinv x)

def Dtau (τ : α → α) : Type := { d : α → Bool // WhollyOdd τ d }

def calib (d0 d : α → Bool) : α → Bool := fun x => xor (d x) (d0 x)

theorem calib_even (τ : α → α) (d0 d : α → Bool)
    (h0 : WhollyOdd τ d0) (hd : WhollyOdd τ d) : Even τ (calib d0 d) :=
  T8_torsor_forward τ d0 d h0 hd

def descend (τ : α → α) (e : α → Bool) (he : Even τ e) :
    Quot (OrbitRel τ) → Bool :=
  Quot.lift e (by
    intro a b hab
    cases hab with
    | inl h => rw [h]
    | inr h => rw [← h]; exact (he a).symm)

def priceForward (τ : α → α) (d0 : Dtau τ) (d : Dtau τ) :
    Quot (OrbitRel τ) → Bool :=
  descend τ (calib d0.1 d.1) (calib_even τ d0.1 d.1 d0.2 d.2)

def priceBackward (τ : α → α) (hinv : Involution τ) (d0 : Dtau τ)
    (e : Quot (OrbitRel τ) → Bool) : Dtau τ :=
  ⟨fun x => xor (d0.1 x) (e (Quot.mk (OrbitRel τ) x)), by
    intro x
    show xor (d0.1 (τ x)) (e (Quot.mk (OrbitRel τ) (τ x)))
       = !xor (d0.1 x) (e (Quot.mk (OrbitRel τ) x))
    have hq : Quot.mk (OrbitRel τ) (τ x) = Quot.mk (OrbitRel τ) x :=
      Quot.sound (Or.inr (hinv x))
    rw [hq, d0.2 x]
    cases d0.1 x <;> cases e (Quot.mk (OrbitRel τ) x) <;> rfl⟩

theorem T16_left_inverse (τ : α → α) (hinv : Involution τ) (d0 : Dtau τ) :
    Codex.LeftInverse (priceBackward τ hinv d0) (priceForward τ d0) := by
  intro d
  apply Subtype.ext
  funext x
  show xor (d0.1 x) (xor (d.1 x) (d0.1 x)) = d.1 x
  cases d.1 x <;> cases d0.1 x <;> rfl

theorem T16_right_inverse (τ : α → α) (hinv : Involution τ) (d0 : Dtau τ) :
    Codex.RightInverse (priceBackward τ hinv d0) (priceForward τ d0) := by
  intro e
  funext q
  induction q using Quot.ind with
  | _ x =>
    show xor (xor (d0.1 x) (e (Quot.mk (OrbitRel τ) x))) (d0.1 x)
       = e (Quot.mk (OrbitRel τ) x)
    generalize e (Quot.mk (OrbitRel τ) x) = b
    generalize d0.1 x = a
    cases a <;> cases b <;> rfl

theorem T16_price_bijection (τ : α → α) (hinv : Involution τ) (d0 : Dtau τ) :
    Nonempty (Dtau τ ≃ (Quot (OrbitRel τ) → Bool)) :=
  ⟨{ toFun := priceForward τ d0
     invFun := priceBackward τ hinv d0
     left_inv := T16_left_inverse τ hinv d0
     right_inv := T16_right_inverse τ hinv d0 }⟩

def canonD0 : Dtau (flipF (Q := Bool)) :=
  ⟨fun (b, _) => b, by intro x; obtain ⟨b, q⟩ := x; rfl⟩

theorem flipF_involution : Involution (flipF (Q := Bool)) := by
  intro x; obtain ⟨b, q⟩ := x; cases b <;> rfl

theorem T16_canonical :
    Nonempty (Dtau (flipF (Q := Bool)) ≃
      (Quot (OrbitRel (flipF (Q := Bool))) → Bool)) :=
  T16_price_bijection (flipF (Q := Bool)) flipF_involution canonD0

theorem T17_odd_everywhere_iff_wholly_odd (τ : α → α) (d : α → Bool) :
    (∀ x, d (τ x) ≠ d x) ↔ (∀ x, d (τ x) = !d x) := by
  constructor
  · intro h x
    have hx := h x
    cases hd : d x <;> cases ht : d (τ x) <;> simp_all
  · intro h x
    have hx := h x
    cases hd : d x <;> cases ht : d (τ x) <;> simp_all

end FTOE

namespace K4

def val : Nat → Nat
  | 0 => 11 | 1 => 851 | 2 => 13 | 3 => 1273 | 4 => 17 | 5 => 437
  | 6 => 19 | 7 => 2119 | 8 => 23 | 9 => 1703 | 10 => 29 | 11 => 869
  | _ => 0

def tau : Nat → Nat := fun i =>
  if i < 12 then (if i % 2 = 0 then i + 1 else i - 1) else i

def target : Nat → Bool := fun i => i % 2 == 0

def rho : Nat → Nat := fun i =>
  (val i % 2) * 1000 + (val i % 3) * 100 + (val i % 5) * 10 + (val i % 7)

theorem tau_involution : ∀ i, i < 12 → tau (tau i) = i := by decide

theorem tau_fixed_point_free : ∀ i, i < 12 → tau i ≠ i := by decide

theorem target_wholly_odd : ∀ i, i < 12 → target (tau i) = !target i := by decide

theorem register_even : ∀ i, i < 12 → rho (tau i) = rho i := by decide

theorem val_lifts_mod_210 : ∀ i, i < 12 → i % 2 = 1 →
    val i > val (tau i) ∧ (val i - val (tau i)) % 210 = 0 := by decide

theorem wall (g : Nat → Bool) : target ≠ fun y => g (rho y) :=
  FTOE.T10_factorization tau rho g target 0
    (register_even 0 (by decide)) (target_wholly_odd 0 (by decide))

theorem pair_distinct : target ≠ fun i => !target i := by
  intro h
  exact absurd (congrFun h 0) (by decide)

theorem price_one_bit : 2^1 = 2 := rfl

theorem price_full_fibre : (2 : Nat)^6 = 64 := by decide

def wallClaim : Claim where
  stmt := ∀ g : Nat → Bool, target ≠ fun y => g (rho y)
  grade := .theorem
  warrant := wall

end K4

namespace Audit

inductive Token : Type
  | sealed | broken | opn | refused | determined | dotmark
  | gok | golok | void | aGivenRA | iAm | interior
  deriving DecidableEq, Repr, BEq

inductive Compartment : Type
  | closureRowed | unpopulated | worldRowed | none
  deriving DecidableEq, Repr, BEq

inductive Ans : Type
  | yes | no | unknown
  deriving DecidableEq, Repr, BEq

def Ans.toBool : Ans → Bool
  | .yes => true
  | _ => false

structure ClaimInput where
  hasContent  : Ans
  facesScoped : Ans
  canonical   : Ans
  forwardMode : Ans
  populated   : Ans
  worldlyRow  : Ans
  drillsOk    : Ans
  frameClosed : Ans
  slots       : Option (List (List Int))
  deriving Repr

def ClaimInput.anyUnknown (i : ClaimInput) : Bool :=
  [i.hasContent, i.facesScoped, i.canonical, i.forwardMode, i.populated,
   i.worldlyRow, i.drillsOk, i.frameClosed].any (· == Ans.unknown)
    || i.slots.isNone

def sealL : Option (List (List Int)) → Token × String
  | none => (.opn, "S-L0: vocabulary slots not supplied; under-determined")
  | some slots =>
    let nz := slots.map (fun s => s.filter (· != 0))
    if slots.flatten.any (fun x => decide (x < 0)) then
      (.broken, "negative literal id; not vocabulary")
    else
      let nfull := (nz.filter (fun s => !s.isEmpty)).length
      if nfull != 3 then
        (.broken, s!"deletion test returns {nfull} slots, not three")
      else if nz.any (fun s => s.length != s.eraseDups.length) then
        (.broken, "repeated literal within slot")
      else
        let flat := nz.flatten
        if flat.length != flat.eraseDups.length then
          (.broken, "LIT collision across slots")
        else
          (.sealed, "three slots, vocabulary pairwise disjoint")

structure DrillInput where
  d1 : Ans
  d2 : Ans
  d3Filed : Ans
  d3Shaped : Ans
  d4 : Ans
  d5 : Ans
  d6 : Ans
  deriving Repr

def DrillInput.anyUnknown (d : DrillInput) : Bool :=
  [d.d1, d.d2, d.d3Filed, d.d3Shaped, d.d4, d.d5, d.d6].any (· == Ans.unknown)

def drillScreen (d : DrillInput) : Token × Grade × String :=
  if d.anyUnknown then
    (.opn, .premise, "drill screen under-determined: a drill was not run")
  else if !(d.d1.toBool && d.d2.toBool) then
    (.broken, .premise, "D1/D2 fail: Seal L break, terminal whatever the determinant reads")
  else if !d.d3Filed.toBool then
    (.broken, .premise, "D3 fail: provenance unfiled; Number-shaped content in the Tongue seat")
  else if !d.d4.toBool then
    (.broken, .premise, "D4 fail: a magnitude carried on the Tongue; sign only, veto never substitution")
  else if !d.d5.toBool then
    (.broken, .premise, "D5 fail: register undeclared; re-index rather than refute")
  else if !d.d6.toBool then
    (.broken, .premise, "D6 fail: the Tongue reproduced the blindness it was appointed to repair")
  else if d.d3Shaped.toBool then
    (.sealed, .structural, "drills pass; provenance filed and SHAPED, so the assignment caps at structural")
  else
    (.sealed, .theorem, "drills pass; provenance filed and unshaped, no tier discount")

def refusalGates (i : ClaimInput) : Option (Compartment × Token × String) :=
  if !i.hasContent.toBool then
    some (.none, .refused, "F-0: every term decoration; contentless, refused, not compartmented")
  else if !i.facesScoped.toBool then
    some (.none, .refused, "R-1: faces not enumerated; a composite carries one compartment per face")
  else if !i.canonical.toBool then
    some (.none, .refused, "R-2: not canonicalised; the compartment attaches to the stripped string")
  else none

def compartmentGates (i : ClaimInput) : Compartment × Token × String :=
  if !i.populated.toBool then
    (.unpopulated, .opn, "S-1: an axis is empty; two planes meet in a line; no lock forms")
  else if i.forwardMode.toBool then
    (.worldRowed, .determined, "R-3: a dated axis must be sourced, never measured; world-rowed unconditionally")
  else if i.worldlyRow.toBool then
    (.worldRowed, .determined, "S-2: a row furnished by the world; the lock is total given those rows")
  else if !i.drillsOk.toBool then
    (.worldRowed, .opn, "S-3: term closure unscreened; typed by its remaining rows")
  else if !i.frameClosed.toBool then
    (.worldRowed, .opn, "S-4: existential import or transport; the leak names the compartment")
  else
    (.closureRowed, .sealed, "rows are the closure; the two determinations are one; conditional on the root posit at the act")

def auditClaim (i : ClaimInput) : Compartment × Token × String :=
  if i.anyUnknown then
    (.none, .opn, "under-determined reading: a gate or the slots were not supplied; first failure terminal, nothing sealed")
  else
    match refusalGates i with
    | some r => r
    | none =>
      match sealL i.slots with
      | (.broken, msg) => (.none, .broken, s!"Seal L break, terminal: {msg}")
      | _ => compartmentGates i

def compartmentGrade : Compartment → Grade → String
  | .closureRowed, cap =>
      s!"row-indefeasible, defeasible against fault, cap {repr cap}"
  | .unpopulated, _ => "no determination to defeat; an axis is owed"
  | .worldRowed, _ =>
      "revisable entirely in the rows; direction bought with the arrow"
  | .none, _ => "no compartment"

theorem unknown_routes_open (i : ClaimInput) (h : i.anyUnknown = true) :
    (auditClaim i).2.1 = Token.opn := by
  simp [auditClaim, h]

theorem contentless_refused (i : ClaimInput)
    (hk : i.anyUnknown = false) (hc : i.hasContent = Ans.no) :
    (auditClaim i).2.1 = Token.refused := by
  unfold auditClaim refusalGates
  rw [hk]
  simp [hc, Ans.toBool]

def det3 (m : Fin 3 → Fin 3 → Ratio) : Ratio :=
  m 0 0 * (m 1 1 * m 2 2 - m 1 2 * m 2 1)
    - m 0 1 * (m 1 0 * m 2 2 - m 1 2 * m 2 0)
    + m 0 2 * (m 1 0 * m 2 1 - m 1 1 * m 2 0)

theorem det3_two_id : det3 (fun a b => if a == b then (2 : Ratio) else 0) = 8 := by
  decide

end Audit

#eval Audit.auditClaim {
  hasContent := .no, facesScoped := .yes, canonical := .yes,
  forwardMode := .no, populated := .yes, worldlyRow := .no,
  drillsOk := .yes, frameClosed := .yes, slots := some [[1], [2], [3]] }

#eval Audit.auditClaim {
  hasContent := .yes, facesScoped := .yes, canonical := .yes,
  forwardMode := .no, populated := .yes, worldlyRow := .no,
  drillsOk := .yes, frameClosed := .yes, slots := some [[1, 2], [3], [4]] }

#eval Audit.auditClaim {
  hasContent := .yes, facesScoped := .yes, canonical := .unknown,
  forwardMode := .no, populated := .yes, worldlyRow := .no,
  drillsOk := .yes, frameClosed := .yes, slots := some [[1], [2], [3]] }

#eval Audit.auditClaim {
  hasContent := .yes, facesScoped := .yes, canonical := .yes,
  forwardMode := .no, populated := .yes, worldlyRow := .no,
  drillsOk := .yes, frameClosed := .yes, slots := some [[1, 2], [3], [2]] }

#eval Audit.det3 (fun a b => if a == b then (2 : Ratio) else (0 : Ratio))

namespace INVERSION

def ItFromBit {α β : Type} (ρ : α → β) (d : α → Bool) : Prop :=
  ∃ g : β → Bool, d = fun y => g (ρ y)

theorem it_from_bit_refuted {α β : Type} (τ : α → α) (ρ : α → β)
    (d : α → Bool) (x : α)
    (hρ : ρ (τ x) = ρ x) (hd : d (τ x) = !d x) :
    ¬ ItFromBit ρ d := by
  intro h
  obtain ⟨g, hg⟩ := h
  exact FTOE.T10_factorization τ ρ g d x hρ hd hg

structure ItFromIt {α β : Type} (τ : α → α) (ρ : α → β) (d : α → Bool)
    (x : α) : Prop where
  
  record_collapses : ρ (τ x) = ρ x
  
  pair_genuine : τ x ≠ x
  
  target_separates : d (τ x) = !d x
  
  no_return : ¬ ItFromBit ρ d

theorem it_from_it {α β : Type} (τ : α → α) (ρ : α → β) (d : α → Bool)
    (x : α) (hρ : ρ (τ x) = ρ x) (hpair : τ x ≠ x) (hd : d (τ x) = !d x) :
    ItFromIt τ ρ d x :=
  ⟨hρ, hpair, hd, it_from_bit_refuted τ ρ d x hρ hd⟩

end INVERSION

namespace K4

theorem it_from_it_canonical :
    INVERSION.ItFromIt tau rho target 0 :=
  INVERSION.it_from_it tau rho target 0
    (register_even 0 (by decide)) (by decide) (target_wholly_odd 0 (by decide))

theorem it_from_bit_refuted_canonical :
    ¬ INVERSION.ItFromBit rho target :=
  it_from_it_canonical.no_return

def inversionClaim : Claim where
  stmt := INVERSION.ItFromIt tau rho target 0
  grade := .theorem
  warrant := it_from_it_canonical

end K4
