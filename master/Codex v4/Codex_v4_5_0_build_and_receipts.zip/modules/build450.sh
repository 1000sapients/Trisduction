#!/bin/sh
# Clean sequential build of the nine modules of the v4.5.0 Lean surface; each .olean feeds the next.
cd /tmp/kit450/modules
export PATH=/tmp/lean-4.19.0-linux/bin:$PATH LEAN_PATH=/tmp/kit450/modules
: > fullbuild_clean.txt
for m in Codex1 Codex2 Codex3 Codex4 Codex5 Codex6 Codex7 Codex8 Codex9; do
  s=$(date +%s); lean -o "$m.olean" "$m.lean" > "$m.log" 2>&1; e=$?
  echo "$m exit $e seconds $(( $(date +%s) - s )) log-bytes $(wc -c < "$m.log")" >> fullbuild_clean.txt
  [ $e -eq 0 ] || break
done
echo DONE >> fullbuild_clean.txt
