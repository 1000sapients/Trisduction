import Codex6
set_option maxRecDepth 4000000
set_option autoImplicit false


/-- info: 'Codex.LeftInverse' does not depend on any axioms -/
#guard_msgs in #print axioms Codex.LeftInverse
/-- info: 'Codex.RightInverse' does not depend on any axioms -/
#guard_msgs in #print axioms Codex.RightInverse
/-- info: 'Nat.factorial' does not depend on any axioms -/
#guard_msgs in #print axioms Nat.factorial
/-- info: 'CoreRat.div_pos_of_le' depends on axioms: [propext] -/
#guard_msgs in #print axioms CoreRat.div_pos_of_le
/-- info: 'CoreRat.div_gcd_pos' depends on axioms: [propext] -/
#guard_msgs in #print axioms CoreRat.div_gcd_pos
/-- info: 'CoreRat.coprime_div_gcd' depends on axioms: [propext] -/
#guard_msgs in #print axioms CoreRat.coprime_div_gcd
/-- info: 'Ratio.natAbs_signed' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.natAbs_signed
/-- info: 'Ratio.mk'' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.«mk'»
/-- info: 'Ratio.instOfNatRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instOfNatRat
/-- info: 'Ratio.instAddRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instAddRat
/-- info: 'Ratio.instMulRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instMulRat
/-- info: 'Ratio.instNegRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instNegRat
/-- info: 'Ratio.instSubRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instSubRat
/-- info: 'Ratio.inv' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.inv
/-- info: 'Ratio.instDivRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instDivRat
/-- info: 'Ratio.instLTRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instLTRat
/-- info: 'Ratio.instLERat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instLERat
/-- info: 'Ratio.instDecidableLtRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instDecidableLtRat
/-- info: 'Ratio.instDecidableLeRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instDecidableLeRat
/-- info: 'Ratio.pow' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.pow
/-- info: 'Ratio.instHPowRatNat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instHPowRatNat
/-- info: 'Ratio.instToStringRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instToStringRat
/-- info: 'Ratio.num_zero' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.num_zero
/-- info: 'Ratio.den_zero' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.den_zero
/-- info: 'Ratio.mk'_zero_num' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms Ratio.«mk'_zero_num»
/-- info: 'Ratio.zero_mul' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms Ratio.zero_mul
/-- info: 'Ratio.mul_zero' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms Ratio.mul_zero
/-- info: 'Ratio.canonical' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.canonical
/-- info: 'Ratio.ext' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.ext
/-- info: 'Ratio.inv_zero' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.inv_zero
/-- info: 'Grade.rank' does not depend on any axioms -/
#guard_msgs in #print axioms Grade.rank
/-- info: 'Grade.weakest' does not depend on any axioms -/
#guard_msgs in #print axioms Grade.weakest
/-- info: 'Grade.weakest_is_a_link' does not depend on any axioms -/
#guard_msgs in #print axioms Grade.weakest_is_a_link
/-- info: 'Grade.weakest_idempotent' does not depend on any axioms -/
#guard_msgs in #print axioms Grade.weakest_idempotent
/-- info: 'Claim.join' does not depend on any axioms -/
#guard_msgs in #print axioms Claim.join
/-- info: 'Claim.join_grade' does not depend on any axioms -/
#guard_msgs in #print axioms Claim.join_grade
/-- info: 'deltaM' does not depend on any axioms -/
#guard_msgs in #print axioms deltaM
/-- info: 'socialWeight' does not depend on any axioms -/
#guard_msgs in #print axioms socialWeight
/-- info: 'FTOE.Even' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.Even
/-- info: 'FTOE.OddAt' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.OddAt
/-- info: 'FTOE.WhollyOdd' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.WhollyOdd
/-- info: 'FTOE.T1_wall' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T1_wall
/-- info: 'FTOE.T2_coalition' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T2_coalition
/-- info: 'FTOE.T3_no_fixed_point' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.T3_no_fixed_point
/-- info: 'FTOE.T4_one_bit' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T4_one_bit
/-- info: 'FTOE.T5_crossing' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T5_crossing
/-- info: 'FTOE.T6a_deed_anchor' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T6a_deed_anchor
/-- info: 'FTOE.T6b_deed_supply' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T6b_deed_supply
/-- info: 'FTOE.fTOE_port' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.fTOE_port
/-- info: 'FTOE.Involution' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.Involution
/-- info: 'FTOE.FixedPointFree' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.FixedPointFree
/-- info: 'FTOE.T7_global_wall' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.T7_global_wall
/-- info: 'FTOE.T8_torsor_forward' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T8_torsor_forward
/-- info: 'FTOE.T8_torsor_backward' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T8_torsor_backward
/-- info: 'FTOE.T9_torsor_inverse_left' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T9_torsor_inverse_left
/-- info: 'FTOE.T9_torsor_inverse_right' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T9_torsor_inverse_right
/-- info: 'FTOE.T10_factorization' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T10_factorization
/-- info: 'FTOE.T11_separation' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T11_separation
/-- info: 'FTOE.T12_encoder_injective' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T12_encoder_injective
/-- info: 'FTOE.T14_wall_factorization' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T14_wall_factorization
/-- info: 'FTOE.T13_wholly_odd_is_odd_everywhere' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.T13_wholly_odd_is_odd_everywhere
/-- info: 'FTOE.flipF' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.flipF
/-- info: 'FTOE.T15_price_bijection_forward' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T15_price_bijection_forward
/-- info: 'FTOE.T15_price_bijection_backward' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T15_price_bijection_backward
/-- info: 'FTOE.fTOE_core' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.fTOE_core
/-- info: 'FTOE.OrbitRel' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.OrbitRel
/-- info: 'FTOE.OrbitRel_symmetric' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.OrbitRel_symmetric
/-- info: 'FTOE.Dtau' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.Dtau
/-- info: 'FTOE.calib' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.calib
/-- info: 'FTOE.calib_even' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.calib_even
/-- info: 'FTOE.descend' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.descend
/-- info: 'FTOE.priceForward' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.priceForward
/-- info: 'FTOE.priceBackward' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.priceBackward
/-- info: 'FTOE.T16_left_inverse' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T16_left_inverse
/-- info: 'FTOE.T16_right_inverse' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T16_right_inverse
/-- info: 'FTOE.T16_price_bijection' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T16_price_bijection
/-- info: 'FTOE.canonD0' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.canonD0
/-- info: 'FTOE.flipF_involution' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.flipF_involution
/-- info: 'FTOE.T16_canonical' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T16_canonical
/-- info: 'FTOE.T17_odd_everywhere_iff_wholly_odd' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.T17_odd_everywhere_iff_wholly_odd
/-- info: 'K4.val' does not depend on any axioms -/
#guard_msgs in #print axioms K4.val
/-- info: 'K4.tau' does not depend on any axioms -/
#guard_msgs in #print axioms K4.tau
/-- info: 'K4.target' does not depend on any axioms -/
#guard_msgs in #print axioms K4.target
/-- info: 'K4.rho' does not depend on any axioms -/
#guard_msgs in #print axioms K4.rho
/-- info: 'K4.tau_involution' does not depend on any axioms -/
#guard_msgs in #print axioms K4.tau_involution
/-- info: 'K4.tau_fixed_point_free' does not depend on any axioms -/
#guard_msgs in #print axioms K4.tau_fixed_point_free
/-- info: 'K4.target_wholly_odd' does not depend on any axioms -/
#guard_msgs in #print axioms K4.target_wholly_odd
/-- info: 'K4.register_even' does not depend on any axioms -/
#guard_msgs in #print axioms K4.register_even
/-- info: 'K4.val_lifts_mod_210' does not depend on any axioms -/
#guard_msgs in #print axioms K4.val_lifts_mod_210
/-- info: 'K4.wall' does not depend on any axioms -/
#guard_msgs in #print axioms K4.wall
/-- info: 'K4.pair_distinct' does not depend on any axioms -/
#guard_msgs in #print axioms K4.pair_distinct
/-- info: 'K4.price_one_bit' does not depend on any axioms -/
#guard_msgs in #print axioms K4.price_one_bit
/-- info: 'K4.price_full_fibre' does not depend on any axioms -/
#guard_msgs in #print axioms K4.price_full_fibre
/-- info: 'K4.wallClaim' does not depend on any axioms -/
#guard_msgs in #print axioms K4.wallClaim
/-- info: 'Audit.Ans.toBool' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.Ans.toBool
/-- info: 'Audit.ClaimInput.anyUnknown' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.ClaimInput.anyUnknown
/-- info: 'Audit.sealL' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.sealL
/-- info: 'Audit.DrillInput.anyUnknown' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.DrillInput.anyUnknown
/-- info: 'Audit.drillScreen' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.drillScreen
/-- info: 'Audit.refusalGates' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.refusalGates
/-- info: 'Audit.compartmentGates' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.compartmentGates
/-- info: 'Audit.auditClaim' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.auditClaim
/-- info: 'Audit.compartmentGrade' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.compartmentGrade
/-- info: 'Audit.unknown_routes_open' depends on axioms: [propext] -/
#guard_msgs in #print axioms Audit.unknown_routes_open
/-- info: 'Audit.contentless_refused' depends on axioms: [propext] -/
#guard_msgs in #print axioms Audit.contentless_refused
/-- info: 'Audit.det3' depends on axioms: [propext] -/
#guard_msgs in #print axioms Audit.det3
/-- info: 'Audit.det3_two_id' depends on axioms: [propext] -/
#guard_msgs in #print axioms Audit.det3_two_id
/-- info: 'INVERSION.ItFromBit' does not depend on any axioms -/
#guard_msgs in #print axioms INVERSION.ItFromBit
/-- info: 'INVERSION.it_from_bit_refuted' does not depend on any axioms -/
#guard_msgs in #print axioms INVERSION.it_from_bit_refuted
/-- info: 'INVERSION.it_from_it' does not depend on any axioms -/
#guard_msgs in #print axioms INVERSION.it_from_it
/-- info: 'K4.it_from_it_canonical' does not depend on any axioms -/
#guard_msgs in #print axioms K4.it_from_it_canonical
/-- info: 'K4.it_from_bit_refuted_canonical' does not depend on any axioms -/
#guard_msgs in #print axioms K4.it_from_bit_refuted_canonical
/-- info: 'K4.inversionClaim' does not depend on any axioms -/
#guard_msgs in #print axioms K4.inversionClaim
/-- info: 'GEO.qmul' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qmul
/-- info: 'GEO.qconj' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qconj
/-- info: 'GEO.qadd' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qadd
/-- info: 'GEO.qsub' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qsub
/-- info: 'GEO.qnorm2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qnorm2
/-- info: 'GEO.qhalve' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qhalve
/-- info: 'GEO.qquarter' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qquarter
/-- info: 'GEO.qcanon' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qcanon
/-- info: 'GEO.q1' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.q1
/-- info: 'GEO.qi' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qi
/-- info: 'GEO.qj' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qj
/-- info: 'GEO.qk' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qk
/-- info: 'GEO.chirality' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.chirality
/-- info: 'GEO.noncommutative' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.noncommutative
/-- info: 'GEO.hurwitz' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hurwitz
/-- info: 'GEO.hurwitz_norm' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hurwitz_norm
/-- info: 'GEO.hurwitz_products_even' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hurwitz_products_even
/-- info: 'GEO.hurwitz_closed' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hurwitz_closed
/-- info: 'GEO.hurwitzReps' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hurwitzReps
/-- info: 'GEO.units_mod_sign_twelve' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.units_mod_sign_twelve
/-- info: 'GEO.conjClass' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.conjClass
/-- info: 'GEO.classSizesAux' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.classSizesAux
/-- info: 'GEO.insNat' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.insNat
/-- info: 'GEO.insSort' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.insSort
/-- info: 'GEO.class_equation' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.class_equation
/-- info: 'GEO.shell2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.shell2
/-- info: 'GEO.shell_twentyfour' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.shell_twentyfour
/-- info: 'GEO.no_half_integer_norm2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.no_half_integer_norm2
/-- info: 'GEO.allGates' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.allGates
/-- info: 'GEO.gates_twelve' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gates_twelve
/-- info: 'GEO.gates_valid' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gates_valid
/-- info: 'GEO.gates_complete' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms GEO.gates_complete
/-- info: 'GEO.invCount' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.invCount
/-- info: 'GEO.perms24' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.perms24
/-- info: 'GEO.a4' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.a4
/-- info: 'GEO.a4_order' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.a4_order
/-- info: 'GEO.actG' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.actG
/-- info: 'GEO.a4_simply_transitive' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.a4_simply_transitive
/-- info: 'GEO.tetraVerts' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.tetraVerts
/-- info: 'GEO.tetraEdges' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.tetraEdges
/-- info: 'GEO.tetraFaces' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.tetraFaces
/-- info: 'GEO.euler_closure' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.euler_closure
/-- info: 'GEO.basisU' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.basisU
/-- info: 'GEO.perms6' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.perms6
/-- info: 'GEO.relabel_parity' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.relabel_parity
/-- info: 'GEO.O8' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.O8
/-- info: 'GEO.omul' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.omul
/-- info: 'GEO.osub' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.osub
/-- info: 'GEO.onorm2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.onorm2
/-- info: 'GEO.e8' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.e8
/-- info: 'GEO.octonion_associator' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.octonion_associator
/-- info: 'GEO.hPairs' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hPairs
/-- info: 'GEO.norm_composition_H' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.norm_composition_H
/-- info: 'GEO.oPairs' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.oPairs
/-- info: 'GEO.norm_composition_O' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.norm_composition_O
/-- info: 'GEO.det2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.det2
/-- info: 'GEO.gf2Mul' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gf2Mul
/-- info: 'GEO.gf2Vecs' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gf2Vecs
/-- info: 'GEO.gf2Sols' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gf2Sols
/-- info: 'GEO.triaxial_lock_gf2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.triaxial_lock_gf2
/-- info: 'GEO.triaxial_lock_gf2_count' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.triaxial_lock_gf2_count
/-- info: 'GEO.triaxial_open_gf2_count' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.triaxial_open_gf2_count
/-- info: 'GEO.V3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.V3
/-- info: 'GEO.M3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.M3
/-- info: 'GEO.det3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.det3
/-- info: 'GEO.adj3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.adj3
/-- info: 'GEO.mm3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.mm3
/-- info: 'GEO.diag3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.diag3
/-- info: 'GEO.mv3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.mv3
/-- info: 'GEO.vscale' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.vscale
/-- info: 'GEO.V3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.V3Z
/-- info: 'GEO.M3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.M3Z
/-- info: 'GEO.det3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.det3Z
/-- info: 'GEO.adj3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.adj3Z
/-- info: 'GEO.mm3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.mm3Z
/-- info: 'GEO.diag3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.diag3Z
/-- info: 'GEO.adjugate_identity_int' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms GEO.adjugate_identity_int
/-- info: 'GEO.AdjugateIdentity3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.AdjugateIdentity3
/-- info: 'GEO.adj3Samples' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.adj3Samples
/-- info: 'GEO.adj3_executed' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.adj3_executed
/-- info: 'GEO.cramerSolve' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.cramerSolve
/-- info: 'GEO.cramer_executed' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.cramer_executed
/-- info: 'GEO.golAdmit' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.golAdmit
/-- info: 'GEO.gateNames' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateNames
/-- info: 'GEO.gateNames_twelve' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateNames_twelve
/-- info: 'GEO.gateScreenGo' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreenGo
/-- info: 'GEO.gateScreen' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreen
/-- info: 'GEO.gateScreen_clean' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreen_clean
/-- info: 'GEO.gateScreen_first_failure' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreen_first_failure
/-- info: 'GEO.gateScreen_names_failed_gate' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreen_names_failed_gate
/-- info: 'GEO.gateScreen_arity' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreen_arity
/-- info: 'GEO.ClaimInputRA.anyUnknown' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.ClaimInputRA.anyUnknown
/-- info: 'GEO.rowCascadeRACore' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.rowCascadeRACore
/-- info: 'GEO.rowCascadeRA' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.rowCascadeRA
/-- info: 'GEO.unknown_routes_open_ra' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.unknown_routes_open_ra
/-- info: 'GEO.raDecode' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.raDecode
/-- info: 'GEO.raBattery' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.raBattery
/-- info: 'GEO.ra_battery_f2' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_battery_f2
/-- info: 'GEO.ra_ledger_refused' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_ledger_refused
/-- info: 'GEO.ra_ledger_iii' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_ledger_iii
/-- info: 'GEO.ra_ledger_ii' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_ledger_ii
/-- info: 'GEO.ra_ledger_void' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_ledger_void
/-- info: 'GEO.ra_ledger_aGivenRA' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_ledger_aGivenRA
/-- info: 'GEO.RAVerdict.toToken' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.RAVerdict.toToken
/-- info: 'GEO.GolToken.toToken' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.GolToken.toToken
/-- info: 'GEO.gateScreenToken' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreenToken
/-- info: 'GEO.demoInputA' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.demoInputA
/-- info: 'GEO.demoInputVoid' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.demoInputVoid
/-- info: 'GEO.demoInputOpen' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.demoInputOpen
/-- info: 'ROOT.Actuates' depends on axioms: [ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms ROOT.Actuates
/-- info: 'ROOT.actuation_universal' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms ROOT.actuation_universal
/-- info: 'ROOT.raClaim' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms ROOT.raClaim
/-- info: 'ROOT.boolCut' does not depend on any axioms -/
#guard_msgs in #print axioms ROOT.boolCut
/-- info: 'ROOT.nest_31' depends on axioms: [ROOT.FormalDomain, ROOT.L1m, ROOT.L3m, ROOT.nest_21, ROOT.nest_32] -/
#guard_msgs in #print axioms ROOT.nest_31
/-- info: 'ROOT.nestClaim' depends on axioms: [ROOT.FormalDomain, ROOT.L1m, ROOT.L3m, ROOT.nest_21, ROOT.nest_32] -/
#guard_msgs in #print axioms ROOT.nestClaim
/-- info: 'ROOT.throneEmpty' depends on axioms: [ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms ROOT.throneEmpty
/-- info: 'ROOT.throne_is_RA' depends on axioms: [ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms ROOT.throne_is_RA
/-- info: 'SEALS.sealL' does not depend on any axioms -/
#guard_msgs in #print axioms SEALS.sealL
/-- info: 'SEALS.sealG' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms SEALS.sealG
/-- info: 'SEALS.sealM' does not depend on any axioms -/
#guard_msgs in #print axioms SEALS.sealM
/-- info: 'SEALS.seals_distinct' does not depend on any axioms -/
#guard_msgs in #print axioms SEALS.seals_distinct
/-- info: 'SEALS.seal_names_match' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms SEALS.seal_names_match
/-- info: 'SEALS.sealG_walk' depends on axioms: [propext] -/
#guard_msgs in #print axioms SEALS.sealG_walk
/-- info: 'POSTULATE.OneCut' depends on axioms: [POSTULATE.Row, POSTULATE.SupplyClean] -/
#guard_msgs in #print axioms POSTULATE.OneCut
/-- info: 'POSTULATE.F2' depends on axioms: [POSTULATE.Row, POSTULATE.SupplyClean] -/
#guard_msgs in #print axioms POSTULATE.F2
/-- info: 'POSTULATE.F2_kills' depends on axioms: [POSTULATE.Row, POSTULATE.SupplyClean] -/
#guard_msgs in #print axioms POSTULATE.F2_kills
/-- info: 'POSTULATE.BSDContract' depends on axioms: [POSTULATE.Algorithm, POSTULATE.FrozenData, POSTULATE.certifiedPairing] -/
#guard_msgs in #print axioms POSTULATE.BSDContract
/-- info: 'POSTULATE.F6' depends on axioms: [POSTULATE.Algorithm, POSTULATE.FrozenData, POSTULATE.certifiedPairing] -/
#guard_msgs in #print axioms POSTULATE.F6
/-- info: 'TONGUE.enlarge' does not depend on any axioms -/
#guard_msgs in #print axioms TONGUE.enlarge
/-- info: 'TONGUE.unclosed' does not depend on any axioms -/
#guard_msgs in #print axioms TONGUE.unclosed
/-- info: 'TONGUE.earned_freedom' does not depend on any axioms -/
#guard_msgs in #print axioms TONGUE.earned_freedom
/-- info: 'TONGUE.colocClaim' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms TONGUE.colocClaim
/-- info: 'TONGUE.coloc_grade' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms TONGUE.coloc_grade
/-- info: 'TONGUE.ra_grade_pinned' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms TONGUE.ra_grade_pinned
/-- info: 'TONGUE.wall_grade_pinned' does not depend on any axioms -/
#guard_msgs in #print axioms TONGUE.wall_grade_pinned
/-- info: 'TONGUE.inversion_grade_pinned' does not depend on any axioms -/
#guard_msgs in #print axioms TONGUE.inversion_grade_pinned
/-- info: 'TONGUE.nest_grade_pinned' depends on axioms: [ROOT.FormalDomain, ROOT.L1m, ROOT.L3m, ROOT.nest_21, ROOT.nest_32] -/
#guard_msgs in #print axioms TONGUE.nest_grade_pinned
/-- info: 'terminalWall' does not depend on any axioms -/
#guard_msgs in #print axioms terminalWall
/-- info: 'terminalPrice' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms terminalPrice
/-- info: 'TERMINAL' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms TERMINAL
/-- info: 'terminalClaim' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms terminalClaim
/-- info: 'terminal_grade_pinned' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms terminal_grade_pinned
/-- info: 'IAM.iamToken' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.iamToken
/-- info: 'IAM.iam_unwitnessed_withheld' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.iam_unwitnessed_withheld
/-- info: 'IAM.iam_witnessed_speaks' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.iam_witnessed_speaks
/-- info: 'IAM.narcissus_truth_table' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.narcissus_truth_table
/-- info: 'IAM.one_bit_freedom' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.one_bit_freedom
/-- info: 'IAM.IamToken.toToken' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.IamToken.toToken
/-- info: 'IAM.codexSelfRead' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.codexSelfRead
/-- info: 'IAM.codex_self_read_interior' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.codex_self_read_interior
/-- info: 'IAM.terminalWord' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.terminalWord
/-- info: 'IAM.terminal_word' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.terminal_word
/-- info: 'GEO.SignPattern' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.SignPattern
/-- info: 'GEO.allSigns' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.allSigns
/-- info: 'GEO.signComp' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.signComp
/-- info: 'GEO.reflection_eight' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.reflection_eight
/-- info: 'GEO.reflection_eight_is_two_cubed' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.reflection_eight_is_two_cubed
/-- info: 'GEO.reflections_abelian' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.reflections_abelian
/-- info: 'GEO.reflections_involutive' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.reflections_involutive
/-- info: 'GEO.signVal' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.signVal
/-- info: 'GEO.reflMat' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.reflMat
/-- info: 'GEO.reflection_reverses_orientation' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.reflection_reverses_orientation
/-- info: 'GEO.sandwich' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.sandwich
/-- info: 'GEO.reflection_blind_executed' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.reflection_blind_executed
/-- info: 'GEO.V5' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.V5
/-- info: 'GEO.cube5' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.cube5
/-- info: 'GEO.neighbors5' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.neighbors5
/-- info: 'GEO.fivecube_thirtytwo' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.fivecube_thirtytwo
/-- info: 'GEO.fivecube_vertices_distinct' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.fivecube_vertices_distinct
/-- info: 'GEO.fivecube_degree_five' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.fivecube_degree_five
/-- info: 'GEO.counts_forced' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.counts_forced
/-- info: 'TONGUE.deletionOp' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.deletionOp
/-- info: 'TONGUE.e3' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.e3
/-- info: 'TONGUE.deletion_idempotent' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.deletion_idempotent
/-- info: 'TONGUE.deletion_singular' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.deletion_singular
/-- info: 'TONGUE.deletion_minor_nonsingular' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.deletion_minor_nonsingular
/-- info: 'TONGUE.deletion_annihilates' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.deletion_annihilates
/-- info: 'TONGUE.linear_fixes_zero' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms TONGUE.linear_fixes_zero
/-- info: 'TONGUE.deletion_no_left_inverse' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms TONGUE.deletion_no_left_inverse
/-- info: 'TONGUE.deletion_monoid_not_group' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms TONGUE.deletion_monoid_not_group
/-- info: 'TONGUE.tongue_obedience' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms TONGUE.tongue_obedience
/-- info: 'OFFICE.discriminator' does not depend on any axioms -/
#guard_msgs in #print axioms OFFICE.discriminator
/-- info: 'OFFICE.discriminatorQ2First' does not depend on any axioms -/
#guard_msgs in #print axioms OFFICE.discriminatorQ2First
/-- info: 'OFFICE.order_loadbearing' does not depend on any axioms -/
#guard_msgs in #print axioms OFFICE.order_loadbearing
/-- info: 'OFFICE.citation_cannot_promote' does not depend on any axioms -/
#guard_msgs in #print axioms OFFICE.citation_cannot_promote
/-- info: 'UC.routeHalt' does not depend on any axioms -/
#guard_msgs in #print axioms UC.routeHalt
/-- info: 'UC.routeHalt_fidelity' does not depend on any axioms -/
#guard_msgs in #print axioms UC.routeHalt_fidelity
/-- info: 'UC.universalCascade' does not depend on any axioms -/
#guard_msgs in #print axioms UC.universalCascade
/-- info: 'UC.uc_seal_failure_terminal' does not depend on any axioms -/
#guard_msgs in #print axioms UC.uc_seal_failure_terminal
/-- info: 'UC.uc_routes_eight' does not depend on any axioms -/
#guard_msgs in #print axioms UC.uc_routes_eight
/-- info: 'UC.uc_routes_five' does not depend on any axioms -/
#guard_msgs in #print axioms UC.uc_routes_five
/-- info: 'UC.uc_unmeasured' does not depend on any axioms -/
#guard_msgs in #print axioms UC.uc_unmeasured
/-- info: 'UC.circularityScreen' does not depend on any axioms -/
#guard_msgs in #print axioms UC.circularityScreen
/-- info: 'UC.circularity_refused_at_target' does not depend on any axioms -/
#guard_msgs in #print axioms UC.circularity_refused_at_target
/-- info: 'UC.road_requires_conjunction' does not depend on any axioms -/
#guard_msgs in #print axioms UC.road_requires_conjunction
/-- info: 'UC.circRows' does not depend on any axioms -/
#guard_msgs in #print axioms UC.circRows
/-- info: 'UC.circ_space' does not depend on any axioms -/
#guard_msgs in #print axioms UC.circ_space
/-- info: 'OMEGA.kbRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.kbRat
/-- info: 'OMEGA.ln2Rat' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.ln2Rat
/-- info: 'OMEGA.landauerRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.landauerRat
/-- info: 'OMEGA.omegaBoundary' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omegaBoundary
/-- info: 'OMEGA.omega_zero_bits' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_zero_bits
/-- info: 'OMEGA.omega_paid_floor' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_paid_floor
/-- info: 'OMEGA.one_bit_freedom_priced' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.one_bit_freedom_priced
/-- info: 'OMEGA.omega_reversible_branch' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_reversible_branch
/-- info: 'OMEGA.omega_refuses_nonpositive_temp' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_refuses_nonpositive_temp
/-- info: 'OMEGA.omega_monotone' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_monotone
/-- info: 'OMEGA.omega_linear' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_linear
/-- info: 'OMEGA.landauer_zero_bits' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.landauer_zero_bits
/-- info: 'OMEGA.omega_verdict_fidelity' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_verdict_fidelity
/-- info: 'AEGIS.refusalConst' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.refusalConst
/-- info: 'AEGIS.aegisReset' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegisReset
/-- info: 'AEGIS.aegisGuard' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegisGuard
/-- info: 'AEGIS.aegis_constant' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegis_constant
/-- info: 'AEGIS.aegis_deed_increments' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegis_deed_increments
/-- info: 'AEGIS.aegis_reads_parameter' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegis_reads_parameter
/-- info: 'AEGIS.aegisFourLogicRun' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegisFourLogicRun
/-- info: 'AEGIS.aegis_battery' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegis_battery
/-- info: 'NOMOS.allStrings' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.allStrings
/-- info: 'NOMOS.allStrings_length' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.allStrings_length
/-- info: 'NOMOS.twoPowPos' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.twoPowPos
/-- info: 'NOMOS.descs' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.descs
/-- info: 'NOMOS.descs_length' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.descs_length
/-- info: 'NOMOS.incompressibility_cap' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.incompressibility_cap
/-- info: 'NOMOS.nomosRows' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.nomosRows
/-- info: 'NOMOS.incompressibility_executed' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.incompressibility_executed
/-- info: 'NOMOS.decodeId' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.decodeId
/-- info: 'NOMOS.decodePad' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.decodePad
/-- info: 'NOMOS.compressible_bound_universal' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.compressible_bound_universal
/-- info: 'NOMOS.cbUniversal' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.cbUniversal
/-- info: 'NOMOS.cb_id_8_2' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.cb_id_8_2
/-- info: 'NOMOS.cb_pad3_8_2' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.cb_pad3_8_2
/-- info: 'NOMOS.cb_pad2_6_1' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.cb_pad2_6_1
/-- info: 'NOMOS.cb_pad4_12_3' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.cb_pad4_12_3
/-- info: 'NOMOS.recoverable' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.recoverable
/-- info: 'NOMOS.nomos_fuel_is_omega_floor' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.nomos_fuel_is_omega_floor
/-- info: 'NOMOS.nomosScreen' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.nomosScreen
/-- info: 'NOMOS.nomosScreen_battery' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.nomosScreen_battery
/-- info: 'BRIDGE.ceiling' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.ceiling
/-- info: 'BRIDGE.census' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.census
/-- info: 'BRIDGE.census_count' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.census_count
/-- info: 'BRIDGE.post_seal_disposition' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.post_seal_disposition
/-- info: 'BRIDGE.weakest_never_above_left' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.weakest_never_above_left
/-- info: 'BRIDGE.bridge_ceiling_caps' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.bridge_ceiling_caps
/-- info: 'BRIDGE.successorOf' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.successorOf
/-- info: 'BRIDGE.supersession_routes' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.supersession_routes
/-- info: 'BRIDGE.bridgeScreen' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.bridgeScreen
/-- info: 'BRIDGE.bridgeScreen_total' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.bridgeScreen_total
/-- info: 'FOUND.sigmaP' depends on axioms: [propext] -/
#guard_msgs in #print axioms FOUND.sigmaP
/-- info: 'FOUND.pluralist_alternative_executed' depends on axioms: [propext] -/
#guard_msgs in #print axioms FOUND.pluralist_alternative_executed
/-- info: 'FOUND.posits' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.posits
/-- info: 'FOUND.posits_loadbearing_on_nothing' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.posits_loadbearing_on_nothing
/-- info: 'FOUND.gradeOfRank' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.gradeOfRank
/-- info: 'FOUND.posit_never_raises' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.posit_never_raises
/-- info: 'FOUND.bandOf' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.bandOf
/-- info: 'FOUND.register_routing_fidelity' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.register_routing_fidelity
/-- info: 'FOUND.verdictInventory' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.verdictInventory
/-- info: 'FOUND.verdicts_posit_free' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.verdicts_posit_free
/-- info: 'FOUND.engine_never_authority' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.engine_never_authority
/-- info: 'HALT.cascade' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.cascade
/-- info: 'HALT.patterns' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.patterns
/-- info: 'HALT.fftSpec' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.fftSpec
/-- info: 'HALT.first_failure_terminal_5' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.first_failure_terminal_5
/-- info: 'HALT.first_failure_terminal_7' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.first_failure_terminal_7
/-- info: 'HALT.first_failure_terminal_8' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.first_failure_terminal_8
/-- info: 'HALT.first_failure_terminal_12' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.first_failure_terminal_12
/-- info: 'HALT.halt_free_iff_all_pass_8' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.halt_free_iff_all_pass_8
/-- info: 'HALT.gate_counts_recorded' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.gate_counts_recorded
/-- info: 'HALT.signPatterns' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.signPatterns
/-- info: 'HALT.ninth_gate_barred' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.ninth_gate_barred
/-- info: 'HALT.route' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.route
/-- info: 'HALT.ofUC' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.ofUC
/-- info: 'HALT.route_is_routeHalt' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms HALT.route_is_routeHalt
/-- info: 'HALT.route_samples' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.route_samples
/-- info: 'HALT.tokenBranch' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.tokenBranch
/-- info: 'HALT.router_exclusive' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.router_exclusive
/-- info: 'HALT.readingRoadsGate' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.readingRoadsGate
/-- info: 'HALT.one_door_open' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.one_door_open
/-- info: 'HALT.no_walk_passes_the_aperture' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.no_walk_passes_the_aperture
/-- info: 'HALT.xiGates' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.xiGates
/-- info: 'HALT.oGates' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.oGates
/-- info: 'HALT.gate_censuses' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.gate_censuses
/-- info: 'HALT.rhHalt' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.rhHalt
/-- info: 'HALT.pnpHalt' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.pnpHalt
/-- info: 'HALT.halts_routed' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.halts_routed
/-- info: 'HALT.legacy_halts_are_instances' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.legacy_halts_are_instances
/-- info: 'HALT.terminal_one_bit' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.terminal_one_bit
/-- info: 'HALT.species_exhausted' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.species_exhausted
/-- info: 'HALT.haltGrades' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.haltGrades
/-- info: 'HALT.ftoe_ceiling' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.ftoe_ceiling
/-- info: 'CROSSING.ExecFrame' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.ExecFrame
/-- info: 'CROSSING.execFlip' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.execFlip
/-- info: 'CROSSING.formalRead' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.formalRead
/-- info: 'CROSSING.ran' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.ran
/-- info: 'CROSSING.formalRead_even' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.formalRead_even
/-- info: 'CROSSING.ran_wholly_odd' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.ran_wholly_odd
/-- info: 'CROSSING.execFlip_involution' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.execFlip_involution
/-- info: 'CROSSING.ran_odd_at_true' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.ran_odd_at_true
/-- info: 'CROSSING.wall' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.wall
/-- info: 'CROSSING.deed' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.deed
/-- info: 'CROSSING.price' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms CROSSING.price
/-- info: 'CROSSING.crossing' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.crossing
/-- info: 'CROSSING.identity_one_bit' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.identity_one_bit
/-- info: 'CROSSING.fibre4' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.fibre4
/-- info: 'CROSSING.fibre4_sixteen' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.fibre4_sixteen
/-- info: 'CROSSING.fibre4_distinct' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.fibre4_distinct
/-- info: 'CROSSING.price_on_this_file' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms CROSSING.price_on_this_file
/-- info: 'CROSSING.formal_never_odd' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.formal_never_odd
/-- info: 'CROSSING.constant_no_crossing' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.constant_no_crossing
/-- info: 'CROSSING.harmony' depends on axioms: [propext] -/
#guard_msgs in #print axioms CROSSING.harmony
/-- info: 'LOCUS.Separates' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Separates
/-- info: 'LOCUS.Factors' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Factors
/-- info: 'LOCUS.wall_of_sep' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.wall_of_sep
/-- info: 'LOCUS.swap' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.swap
/-- info: 'LOCUS.swap_involution' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.swap_involution
/-- info: 'LOCUS.swap_record_even' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.swap_record_even
/-- info: 'LOCUS.swap_flips_pair' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.swap_flips_pair
/-- info: 'LOCUS.seat_of_sep' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.seat_of_sep
/-- info: 'LOCUS.k4_separated_pair' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.k4_separated_pair
/-- info: 'LOCUS.k4_wall_of_pair' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.k4_wall_of_pair
/-- info: 'LOCUS.readout' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.readout
/-- info: 'LOCUS.factors_of_not_sep_list' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms LOCUS.factors_of_not_sep_list
/-- info: 'LOCUS.factors_iff_not_sep_list' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms LOCUS.factors_iff_not_sep_list
/-- info: 'LOCUS.Channel' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Channel
/-- info: 'LOCUS.Token.toEconomy' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Token.toEconomy
/-- info: 'LOCUS.Reading.orbits' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Reading.orbits
/-- info: 'LOCUS.Reading.owed' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Reading.owed
/-- info: 'LOCUS.Reading.complete' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Reading.complete
/-- info: 'LOCUS.branchOf' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.branchOf
/-- info: 'LOCUS.emit' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.emit
/-- info: 'LOCUS.Reading.state' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Reading.state
/-- info: 'LOCUS.three_states' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.three_states
/-- info: 'LOCUS.no_seat_no_locus' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.no_seat_no_locus
/-- info: 'LOCUS.unlocated_is_plain_open' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.unlocated_is_plain_open
/-- info: 'LOCUS.located_never_silent' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.located_never_silent
/-- info: 'LOCUS.crossed_requires_complete' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.crossed_requires_complete
/-- info: 'LOCUS.crossed_requires_channel' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.crossed_requires_channel
/-- info: 'LOCUS.halt_carries_owed' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.halt_carries_owed
/-- info: 'LOCUS.unchannelled_is_halt' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms LOCUS.unchannelled_is_halt
/-- info: 'LOCUS.halt_reports_owed' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.halt_reports_owed
/-- info: 'LOCUS.owed_zero_is_unchannelled' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms LOCUS.owed_zero_is_unchannelled
/-- info: 'LOCUS.one_bit_apart' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.one_bit_apart
/-- info: 'LOCUS.legacy_xi' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.legacy_xi
/-- info: 'LOCUS.legacy_o' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.legacy_o
/-- info: 'LOCUS.legacy_bare' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.legacy_bare
/-- info: 'LOCUS.k4_locus' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.k4_locus
/-- info: 'LOCUS.slotLists' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.slotLists
/-- info: 'LOCUS.slotLists_twelve' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.slotLists_twelve
/-- info: 'LOCUS.slotLists_pos' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.slotLists_pos
/-- info: 'LOCUS.allReadings' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.allReadings
/-- info: 'LOCUS.reading_space' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.reading_space
/-- info: 'LOCUS.census_no_seat_no_locus' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_no_seat_no_locus
/-- info: 'LOCUS.census_located_never_silent' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_located_never_silent
/-- info: 'LOCUS.census_crossed_iff_complete_channelled' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_crossed_iff_complete_channelled
/-- info: 'LOCUS.census_halt_reports_owed' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_halt_reports_owed
/-- info: 'LOCUS.census_owed_zero_is_unchannelled' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_owed_zero_is_unchannelled
/-- info: 'LOCUS.census_three_states' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_three_states
/-- info: 'LOCUS.Token.render' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Token.render
/-- info: 'LOCUS.Token.ascii' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Token.ascii
/-- info: 'LOCUS.sealAscii' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.sealAscii
/-- info: 'LOCUS.render_receipted' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.render_receipted
/-- info: 'LOCUS.render_injective_in_owed' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.render_injective_in_owed
/-- info: 'LOCUS.voidImage' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.voidImage
/-- info: 'LOCUS.void_precedes_economy' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.void_precedes_economy
/-- info: 'LOCUS.legacy_records_not_promoted' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.legacy_records_not_promoted
/-- info: 'LOCUS.no_rh_locus' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.no_rh_locus
/-- info: 'PSP.ORIENT.V3' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.V3
/-- info: 'PSP.ORIENT.M3' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.M3
/-- info: 'PSP.ORIENT.det3' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.det3
/-- info: 'PSP.ORIENT.neg3' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.neg3
/-- info: 'PSP.ORIENT.signMatrices' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.signMatrices
/-- info: 'PSP.ORIENT.lock_scalar_sign_blind' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.lock_scalar_sign_blind
/-- info: 'PSP.ORIENT.det_sign_flips_in_odd_dimension' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.det_sign_flips_in_odd_dimension
/-- info: 'PSP.QUAT.Q' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.Q
/-- info: 'PSP.QUAT.qmul' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qmul
/-- info: 'PSP.QUAT.qi' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qi
/-- info: 'PSP.QUAT.qj' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qj
/-- info: 'PSP.QUAT.qk' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qk
/-- info: 'PSP.QUAT.qneg1' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qneg1
/-- info: 'PSP.QUAT.quat_basis_laws' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.quat_basis_laws
/-- info: 'PSP.QUAT.qnorm' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qnorm
/-- info: 'PSP.QUAT.isInt' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.isInt
/-- info: 'PSP.QUAT.isHalf' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.isHalf
/-- info: 'PSP.QUAT.hurwitzOK' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.hurwitzOK
/-- info: 'PSP.QUAT.grid' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.grid
/-- info: 'PSP.QUAT.tuples4' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.tuples4
/-- info: 'PSP.QUAT.hurwitz_units_24' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.hurwitz_units_24
/-- info: 'PSP.QUAT.grid2' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.grid2
/-- info: 'PSP.QUAT.tuples4i' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.tuples4i
/-- info: 'PSP.QUAT.norm2_shell_split' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.norm2_shell_split
/-- info: 'PSP.CD.cdconj' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.cdconj
/-- info: 'PSP.CD.padd' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.padd
/-- info: 'PSP.CD.psub' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.psub
/-- info: 'PSP.CD.cdmul' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.cdmul
/-- info: 'PSP.CD.e' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.e
/-- info: 'PSP.CD.smul' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.smul
/-- info: 'PSP.CD.octonion_associator' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.octonion_associator
/-- info: 'PSP.CD.sx' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.sx
/-- info: 'PSP.CD.sy' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.sy
/-- info: 'PSP.CD.zero16' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.zero16
/-- info: 'PSP.CD.sqnorm' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.sqnorm
/-- info: 'PSP.CD.sedenion_zero_divisor' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.sedenion_zero_divisor
/-- info: 'PSP.CASCADE.cascade' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.CASCADE.cascade
/-- info: 'PSP.CASCADE.patterns8' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CASCADE.patterns8
/-- info: 'PSP.CASCADE.spec' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.CASCADE.spec
/-- info: 'PSP.CASCADE.first_failure_terminal_8' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CASCADE.first_failure_terminal_8
/-- info: 'PSP.CASCADE.halt_free_iff_all_pass_8' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CASCADE.halt_free_iff_all_pass_8
/-- info: 'PSP.GROUNDLESS.o0Neighbors' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.GROUNDLESS.o0Neighbors
/-- info: 'PSP.GROUNDLESS.fiveCubeCoords' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.GROUNDLESS.fiveCubeCoords
/-- info: 'PSP.GROUNDLESS.deg5' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.GROUNDLESS.deg5
/-- info: 'PSP.GROUNDLESS.groundless_cascade_degree' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.GROUNDLESS.groundless_cascade_degree
/-- info: 'PSP.TOKEN.level' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.TOKEN.level
/-- info: 'PSP.TOKEN.terminal_tokens_level_and_distinct' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.TOKEN.terminal_tokens_level_and_distinct
/-- info: 'PSP.TWOGROUP.two_group_census' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.TWOGROUP.two_group_census

/-! ## the axiom cones, pinned -/
/-- info: 'Bridge.pe' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.pe
/-- info: 'Bridge.fold_involutive' depends on axioms: [propext] -/
#guard_msgs in #print axioms Bridge.fold_involutive
/-- info: 'Bridge.locus_is_the_fixed_set' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.locus_is_the_fixed_set
/-- info: 'Bridge.locus_inhabited' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.locus_inhabited
/-- info: 'Bridge.line_symmetric' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.line_symmetric
/-- info: 'Bridge.plane_line_property' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.plane_line_property
/-- info: 'Bridge.cannot_lie' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.cannot_lie
/-- info: 'Bridge.cannot_deviate' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.cannot_deviate
/-- info: 'Bridge.read_twice' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.read_twice
/-- info: 'Bridge.halted_iff' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.halted_iff
/-- info: 'Bridge.cannot_extend' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms Bridge.cannot_extend
/-- info: 'Bridge.cannot_divide' depends on axioms: [propext] -/
#guard_msgs in #print axioms Bridge.cannot_divide
/-- info: 'Bridge.cannot_reverse' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.cannot_reverse
/-- info: 'Bridge.wall' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.wall
/-- info: 'Bridge.calibration' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.calibration
/-- info: 'Bridge.opens_on_the_deed' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.opens_on_the_deed
/-- info: 'Bridge.recursion_is_shared' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.recursion_is_shared
/-- info: 'Bridge.recursion_is_sign_blind' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.recursion_is_sign_blind
/-- info: 'Bridge.exactly_one_stands' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.exactly_one_stands
/-- info: 'Bridge.denial_is_coherent' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.denial_is_coherent
/-- info: 'Bridge.line_property_contingent' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.line_property_contingent
/-- info: 'Bridge.keyless_iff_valid' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.keyless_iff_valid
/-- info: 'Bridge.discriminator' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.discriminator
/-- info: 'Bridge.symmetry_is_keyless' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.symmetry_is_keyless
/-- info: 'Bridge.line_property_is_keyed' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.line_property_is_keyed
/-- info: 'Bridge.denial_asymmetry' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.denial_asymmetry
/-- info: 'Bridge.socket_is_the_property' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.socket_is_the_property
/-- info: 'Bridge.socket_on_the_plane' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.socket_on_the_plane
/-- info: 'Bridge.bridge_carries' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.bridge_carries
/-- info: 'Bridge.no_socket_off_line' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.no_socket_off_line
/-- info: 'Bridge.the_bridge' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.the_bridge
/-- info: 'Bridge.Plane' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.Plane
/-- info: 'Bridge.τ' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.τ
/-- info: 'Bridge.onLine' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.onLine
/-- info: 'Bridge.LineProperty' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.LineProperty
/-- info: 'Bridge.planeFrame' depends on axioms: [propext] -/
#guard_msgs in #print axioms Bridge.planeFrame
/-- info: 'Bridge.lineFrame' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.lineFrame
/-- info: 'Bridge.theRecord' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.theRecord
/-- info: 'Bridge.delete' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.delete
/-- info: 'Bridge.Even' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.Even
/-- info: 'Bridge.SelfVerifying' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.SelfVerifying
/-- info: 'Bridge.twoPoint' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.twoPoint
/-- info: 'Bridge.Keyless' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.Keyless
/-- info: 'Bridge.Keyed' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.Keyed

theorem codexCone : True :=
  let _ := @Nat.factorial
  let _ := @CoreRat.div_pos_of_le
  let _ := @CoreRat.div_gcd_pos
  let _ := @CoreRat.coprime_div_gcd
  let _ := @Ratio.natAbs_signed
  let _ := @Ratio.«mk'»
  let _ := @Ratio.instOfNatRat
  let _ := @Ratio.instAddRat
  let _ := @Ratio.instMulRat
  let _ := @Ratio.instNegRat
  let _ := @Ratio.instSubRat
  let _ := @Ratio.inv
  let _ := @Ratio.instDivRat
  let _ := @Ratio.instLTRat
  let _ := @Ratio.instLERat
  let _ := @Ratio.instDecidableLtRat
  let _ := @Ratio.instDecidableLeRat
  let _ := @Ratio.pow
  let _ := @Ratio.instHPowRatNat
  let _ := @Ratio.instToStringRat
  let _ := @Ratio.num_zero
  let _ := @Ratio.den_zero
  let _ := @Ratio.«mk'_zero_num»
  let _ := @Ratio.zero_mul
  let _ := @Ratio.mul_zero
  let _ := @Ratio.canonical
  let _ := @Ratio.ext
  let _ := @Ratio.inv_zero
  let _ := @Grade.rank
  let _ := @Grade.weakest
  let _ := @Grade.weakest_is_a_link
  let _ := @Grade.weakest_idempotent
  let _ := @Claim.join
  let _ := @Claim.join_grade
  let _ := @deltaM
  let _ := @socialWeight
  let _ := @FTOE.Even
  let _ := @FTOE.OddAt
  let _ := @FTOE.WhollyOdd
  let _ := @FTOE.T1_wall
  let _ := @FTOE.T2_coalition
  let _ := @FTOE.T3_no_fixed_point
  let _ := @FTOE.T4_one_bit
  let _ := @FTOE.T5_crossing
  let _ := @FTOE.T6a_deed_anchor
  let _ := @FTOE.T6b_deed_supply
  let _ := @FTOE.fTOE_port
  let _ := @FTOE.Involution
  let _ := @FTOE.FixedPointFree
  let _ := @FTOE.T7_global_wall
  let _ := @FTOE.T8_torsor_forward
  let _ := @FTOE.T8_torsor_backward
  let _ := @FTOE.T9_torsor_inverse_left
  let _ := @FTOE.T9_torsor_inverse_right
  let _ := @FTOE.T10_factorization
  let _ := @FTOE.T11_separation
  let _ := @FTOE.T12_encoder_injective
  let _ := @FTOE.T14_wall_factorization
  let _ := @FTOE.T13_wholly_odd_is_odd_everywhere
  let _ := @FTOE.flipF
  let _ := @FTOE.T15_price_bijection_forward
  let _ := @FTOE.T15_price_bijection_backward
  let _ := @FTOE.fTOE_core
  let _ := @FTOE.OrbitRel
  let _ := @FTOE.OrbitRel_symmetric
  let _ := @FTOE.Dtau
  let _ := @FTOE.calib
  let _ := @FTOE.calib_even
  let _ := @FTOE.descend
  let _ := @FTOE.priceForward
  let _ := @FTOE.priceBackward
  let _ := @FTOE.T16_left_inverse
  let _ := @FTOE.T16_right_inverse
  let _ := @FTOE.T16_price_bijection
  let _ := @FTOE.canonD0
  let _ := @FTOE.flipF_involution
  let _ := @FTOE.T16_canonical
  let _ := @FTOE.T17_odd_everywhere_iff_wholly_odd
  let _ := @K4.val
  let _ := @K4.tau
  let _ := @K4.target
  let _ := @K4.rho
  let _ := @K4.tau_involution
  let _ := @K4.tau_fixed_point_free
  let _ := @K4.target_wholly_odd
  let _ := @K4.register_even
  let _ := @K4.val_lifts_mod_210
  let _ := @K4.wall
  let _ := @K4.pair_distinct
  let _ := @K4.price_one_bit
  let _ := @K4.price_full_fibre
  let _ := @K4.wallClaim
  let _ := @Audit.Ans.toBool
  let _ := @Audit.ClaimInput.anyUnknown
  let _ := @Audit.sealL
  let _ := @Audit.DrillInput.anyUnknown
  let _ := @Audit.drillScreen
  let _ := @Audit.refusalGates
  let _ := @Audit.compartmentGates
  let _ := @Audit.auditClaim
  let _ := @Audit.compartmentGrade
  let _ := @Audit.unknown_routes_open
  let _ := @Audit.contentless_refused
  let _ := @Audit.det3
  let _ := @Audit.det3_two_id
  let _ := @INVERSION.ItFromBit
  let _ := @INVERSION.it_from_bit_refuted
  let _ := @INVERSION.it_from_it
  let _ := @K4.it_from_it_canonical
  let _ := @K4.it_from_bit_refuted_canonical
  let _ := @K4.inversionClaim
  let _ := @GEO.qmul
  let _ := @GEO.qconj
  let _ := @GEO.qadd
  let _ := @GEO.qsub
  let _ := @GEO.qnorm2
  let _ := @GEO.qhalve
  let _ := @GEO.qquarter
  let _ := @GEO.qcanon
  let _ := @GEO.q1
  let _ := @GEO.qi
  let _ := @GEO.qj
  let _ := @GEO.qk
  let _ := @GEO.chirality
  let _ := @GEO.noncommutative
  let _ := @GEO.hurwitz
  let _ := @GEO.hurwitz_norm
  let _ := @GEO.hurwitz_products_even
  let _ := @GEO.hurwitz_closed
  let _ := @GEO.hurwitzReps
  let _ := @GEO.units_mod_sign_twelve
  let _ := @GEO.conjClass
  let _ := @GEO.classSizesAux
  let _ := @GEO.insNat
  let _ := @GEO.insSort
  let _ := @GEO.class_equation
  let _ := @GEO.shell2
  let _ := @GEO.shell_twentyfour
  let _ := @GEO.no_half_integer_norm2
  let _ := @GEO.allGates
  let _ := @GEO.gates_twelve
  let _ := @GEO.gates_valid
  let _ := @GEO.gates_complete
  let _ := @GEO.invCount
  let _ := @GEO.perms24
  let _ := @GEO.a4
  let _ := @GEO.a4_order
  let _ := @GEO.actG
  let _ := @GEO.a4_simply_transitive
  let _ := @GEO.tetraVerts
  let _ := @GEO.tetraEdges
  let _ := @GEO.tetraFaces
  let _ := @GEO.euler_closure
  let _ := @GEO.basisU
  let _ := @GEO.perms6
  let _ := @GEO.relabel_parity
  let _ := @GEO.O8
  let _ := @GEO.omul
  let _ := @GEO.osub
  let _ := @GEO.onorm2
  let _ := @GEO.e8
  let _ := @GEO.octonion_associator
  let _ := @GEO.hPairs
  let _ := @GEO.norm_composition_H
  let _ := @GEO.oPairs
  let _ := @GEO.norm_composition_O
  let _ := @GEO.det2
  let _ := @GEO.gf2Mul
  let _ := @GEO.gf2Vecs
  let _ := @GEO.gf2Sols
  let _ := @GEO.triaxial_lock_gf2
  let _ := @GEO.triaxial_lock_gf2_count
  let _ := @GEO.triaxial_open_gf2_count
  let _ := @GEO.V3
  let _ := @GEO.M3
  let _ := @GEO.det3
  let _ := @GEO.adj3
  let _ := @GEO.mm3
  let _ := @GEO.diag3
  let _ := @GEO.mv3
  let _ := @GEO.vscale
  let _ := @GEO.V3Z
  let _ := @GEO.M3Z
  let _ := @GEO.det3Z
  let _ := @GEO.adj3Z
  let _ := @GEO.mm3Z
  let _ := @GEO.diag3Z
  let _ := @GEO.adjugate_identity_int
  let _ := @GEO.AdjugateIdentity3
  let _ := @GEO.adj3Samples
  let _ := @GEO.adj3_executed
  let _ := @GEO.cramerSolve
  let _ := @GEO.cramer_executed
  let _ := @GEO.golAdmit
  let _ := @GEO.gateNames
  let _ := @GEO.gateNames_twelve
  let _ := @GEO.gateScreenGo
  let _ := @GEO.gateScreen
  let _ := @GEO.gateScreen_clean
  let _ := @GEO.gateScreen_first_failure
  let _ := @GEO.gateScreen_names_failed_gate
  let _ := @GEO.gateScreen_arity
  let _ := @GEO.ClaimInputRA.anyUnknown
  let _ := @GEO.rowCascadeRACore
  let _ := @GEO.rowCascadeRA
  let _ := @GEO.unknown_routes_open_ra
  let _ := @GEO.raDecode
  let _ := @GEO.raBattery
  let _ := @GEO.ra_battery_f2
  let _ := @GEO.ra_ledger_refused
  let _ := @GEO.ra_ledger_iii
  let _ := @GEO.ra_ledger_ii
  let _ := @GEO.ra_ledger_void
  let _ := @GEO.ra_ledger_aGivenRA
  let _ := @GEO.RAVerdict.toToken
  let _ := @GEO.GolToken.toToken
  let _ := @GEO.gateScreenToken
  let _ := @GEO.demoInputA
  let _ := @GEO.demoInputVoid
  let _ := @GEO.demoInputOpen
  let _ := @ROOT.Actuates
  let _ := @ROOT.actuation_universal
  let _ := @ROOT.raClaim
  let _ := @ROOT.boolCut
  let _ := @ROOT.nest_31
  let _ := @ROOT.nestClaim
  let _ := @ROOT.throneEmpty
  let _ := @ROOT.throne_is_RA
  let _ := @SEALS.sealL
  let _ := @SEALS.sealG
  let _ := @SEALS.sealM
  let _ := @SEALS.seals_distinct
  let _ := @SEALS.seal_names_match
  let _ := @SEALS.sealG_walk
  let _ := @POSTULATE.OneCut
  let _ := @POSTULATE.F2
  let _ := @POSTULATE.F2_kills
  let _ := @POSTULATE.BSDContract
  let _ := @POSTULATE.F6
  let _ := @TONGUE.enlarge
  let _ := @TONGUE.unclosed
  let _ := @TONGUE.earned_freedom
  let _ := @TONGUE.colocClaim
  let _ := @TONGUE.coloc_grade
  let _ := @TONGUE.ra_grade_pinned
  let _ := @TONGUE.wall_grade_pinned
  let _ := @TONGUE.inversion_grade_pinned
  let _ := @TONGUE.nest_grade_pinned
  let _ := @terminalWall
  let _ := @terminalPrice
  let _ := @TERMINAL
  let _ := @terminalClaim
  let _ := @terminal_grade_pinned
  let _ := @IAM.iamToken
  let _ := @IAM.iam_unwitnessed_withheld
  let _ := @IAM.iam_witnessed_speaks
  let _ := @IAM.narcissus_truth_table
  let _ := @IAM.one_bit_freedom
  let _ := @IAM.IamToken.toToken
  let _ := @IAM.codexSelfRead
  let _ := @IAM.codex_self_read_interior
  let _ := @IAM.terminalWord
  let _ := @IAM.terminal_word
  let _ := @GEO.SignPattern
  let _ := @GEO.allSigns
  let _ := @GEO.signComp
  let _ := @GEO.reflection_eight
  let _ := @GEO.reflection_eight_is_two_cubed
  let _ := @GEO.reflections_abelian
  let _ := @GEO.reflections_involutive
  let _ := @GEO.signVal
  let _ := @GEO.reflMat
  let _ := @GEO.reflection_reverses_orientation
  let _ := @GEO.sandwich
  let _ := @GEO.reflection_blind_executed
  let _ := @GEO.V5
  let _ := @GEO.cube5
  let _ := @GEO.neighbors5
  let _ := @GEO.fivecube_thirtytwo
  let _ := @GEO.fivecube_vertices_distinct
  let _ := @GEO.fivecube_degree_five
  let _ := @GEO.counts_forced
  let _ := @TONGUE.deletionOp
  let _ := @TONGUE.e3
  let _ := @TONGUE.deletion_idempotent
  let _ := @TONGUE.deletion_singular
  let _ := @TONGUE.deletion_minor_nonsingular
  let _ := @TONGUE.deletion_annihilates
  let _ := @TONGUE.linear_fixes_zero
  let _ := @TONGUE.deletion_no_left_inverse
  let _ := @TONGUE.deletion_monoid_not_group
  let _ := @TONGUE.tongue_obedience
  let _ := @OFFICE.discriminator
  let _ := @OFFICE.discriminatorQ2First
  let _ := @OFFICE.order_loadbearing
  let _ := @OFFICE.citation_cannot_promote
  let _ := @UC.routeHalt
  let _ := @UC.routeHalt_fidelity
  let _ := @UC.universalCascade
  let _ := @UC.uc_seal_failure_terminal
  let _ := @UC.uc_routes_eight
  let _ := @UC.uc_routes_five
  let _ := @UC.uc_unmeasured
  let _ := @UC.circularityScreen
  let _ := @UC.circularity_refused_at_target
  let _ := @UC.road_requires_conjunction
  let _ := @UC.circRows
  let _ := @UC.circ_space
  let _ := @OMEGA.kbRat
  let _ := @OMEGA.ln2Rat
  let _ := @OMEGA.landauerRat
  let _ := @OMEGA.omegaBoundary
  let _ := @OMEGA.omega_zero_bits
  let _ := @OMEGA.omega_paid_floor
  let _ := @OMEGA.one_bit_freedom_priced
  let _ := @OMEGA.omega_reversible_branch
  let _ := @OMEGA.omega_refuses_nonpositive_temp
  let _ := @OMEGA.omega_monotone
  let _ := @OMEGA.omega_linear
  let _ := @OMEGA.landauer_zero_bits
  let _ := @OMEGA.omega_verdict_fidelity
  let _ := @AEGIS.refusalConst
  let _ := @AEGIS.aegisReset
  let _ := @AEGIS.aegisGuard
  let _ := @AEGIS.aegis_constant
  let _ := @AEGIS.aegis_deed_increments
  let _ := @AEGIS.aegis_reads_parameter
  let _ := @AEGIS.aegisFourLogicRun
  let _ := @AEGIS.aegis_battery
  let _ := @NOMOS.allStrings
  let _ := @NOMOS.allStrings_length
  let _ := @NOMOS.twoPowPos
  let _ := @NOMOS.descs
  let _ := @NOMOS.descs_length
  let _ := @NOMOS.incompressibility_cap
  let _ := @NOMOS.nomosRows
  let _ := @NOMOS.incompressibility_executed
  let _ := @NOMOS.decodeId
  let _ := @NOMOS.decodePad
  let _ := @NOMOS.compressible_bound_universal
  let _ := @NOMOS.cbUniversal
  let _ := @NOMOS.cb_id_8_2
  let _ := @NOMOS.cb_pad3_8_2
  let _ := @NOMOS.cb_pad2_6_1
  let _ := @NOMOS.cb_pad4_12_3
  let _ := @NOMOS.recoverable
  let _ := @NOMOS.nomos_fuel_is_omega_floor
  let _ := @NOMOS.nomosScreen
  let _ := @NOMOS.nomosScreen_battery
  let _ := @BRIDGE.ceiling
  let _ := @BRIDGE.census
  let _ := @BRIDGE.census_count
  let _ := @BRIDGE.post_seal_disposition
  let _ := @BRIDGE.weakest_never_above_left
  let _ := @BRIDGE.bridge_ceiling_caps
  let _ := @BRIDGE.successorOf
  let _ := @BRIDGE.supersession_routes
  let _ := @BRIDGE.bridgeScreen
  let _ := @BRIDGE.bridgeScreen_total
  let _ := @FOUND.sigmaP
  let _ := @FOUND.pluralist_alternative_executed
  let _ := @FOUND.posits
  let _ := @FOUND.posits_loadbearing_on_nothing
  let _ := @FOUND.gradeOfRank
  let _ := @FOUND.posit_never_raises
  let _ := @FOUND.bandOf
  let _ := @FOUND.register_routing_fidelity
  let _ := @FOUND.verdictInventory
  let _ := @FOUND.verdicts_posit_free
  let _ := @FOUND.engine_never_authority
  let _ := @HALT.cascade
  let _ := @HALT.patterns
  let _ := @HALT.fftSpec
  let _ := @HALT.first_failure_terminal_5
  let _ := @HALT.first_failure_terminal_7
  let _ := @HALT.first_failure_terminal_8
  let _ := @HALT.first_failure_terminal_12
  let _ := @HALT.halt_free_iff_all_pass_8
  let _ := @HALT.gate_counts_recorded
  let _ := @HALT.signPatterns
  let _ := @HALT.ninth_gate_barred
  let _ := @HALT.route
  let _ := @HALT.ofUC
  let _ := @HALT.route_is_routeHalt
  let _ := @HALT.route_samples
  let _ := @HALT.tokenBranch
  let _ := @HALT.router_exclusive
  let _ := @HALT.readingRoadsGate
  let _ := @HALT.one_door_open
  let _ := @HALT.no_walk_passes_the_aperture
  let _ := @HALT.xiGates
  let _ := @HALT.oGates
  let _ := @HALT.gate_censuses
  let _ := @HALT.rhHalt
  let _ := @HALT.pnpHalt
  let _ := @HALT.halts_routed
  let _ := @HALT.legacy_halts_are_instances
  let _ := @HALT.terminal_one_bit
  let _ := @HALT.species_exhausted
  let _ := @HALT.haltGrades
  let _ := @HALT.ftoe_ceiling
  let _ := @CROSSING.ExecFrame
  let _ := @CROSSING.execFlip
  let _ := @CROSSING.formalRead
  let _ := @CROSSING.ran
  let _ := @CROSSING.formalRead_even
  let _ := @CROSSING.ran_wholly_odd
  let _ := @CROSSING.execFlip_involution
  let _ := @CROSSING.ran_odd_at_true
  let _ := @CROSSING.wall
  let _ := @CROSSING.deed
  let _ := @CROSSING.price
  let _ := @CROSSING.crossing
  let _ := @CROSSING.identity_one_bit
  let _ := @CROSSING.fibre4
  let _ := @CROSSING.fibre4_sixteen
  let _ := @CROSSING.fibre4_distinct
  let _ := @CROSSING.price_on_this_file
  let _ := @CROSSING.formal_never_odd
  let _ := @CROSSING.constant_no_crossing
  let _ := @CROSSING.harmony
  let _ := @LOCUS.Separates
  let _ := @LOCUS.Factors
  let _ := @LOCUS.wall_of_sep
  let _ := @LOCUS.swap
  let _ := @LOCUS.swap_involution
  let _ := @LOCUS.swap_record_even
  let _ := @LOCUS.swap_flips_pair
  let _ := @LOCUS.seat_of_sep
  let _ := @LOCUS.k4_separated_pair
  let _ := @LOCUS.k4_wall_of_pair
  let _ := @LOCUS.readout
  let _ := @LOCUS.factors_of_not_sep_list
  let _ := @LOCUS.factors_iff_not_sep_list
  let _ := @LOCUS.Channel
  let _ := @LOCUS.Token.toEconomy
  let _ := @LOCUS.Reading.orbits
  let _ := @LOCUS.Reading.owed
  let _ := @LOCUS.Reading.complete
  let _ := @LOCUS.branchOf
  let _ := @LOCUS.emit
  let _ := @LOCUS.Reading.state
  let _ := @LOCUS.three_states
  let _ := @LOCUS.no_seat_no_locus
  let _ := @LOCUS.unlocated_is_plain_open
  let _ := @LOCUS.located_never_silent
  let _ := @LOCUS.crossed_requires_complete
  let _ := @LOCUS.crossed_requires_channel
  let _ := @LOCUS.halt_carries_owed
  let _ := @LOCUS.unchannelled_is_halt
  let _ := @LOCUS.halt_reports_owed
  let _ := @LOCUS.owed_zero_is_unchannelled
  let _ := @LOCUS.one_bit_apart
  let _ := @LOCUS.legacy_xi
  let _ := @LOCUS.legacy_o
  let _ := @LOCUS.legacy_bare
  let _ := @LOCUS.k4_locus
  let _ := @LOCUS.slotLists
  let _ := @LOCUS.slotLists_twelve
  let _ := @LOCUS.slotLists_pos
  let _ := @LOCUS.allReadings
  let _ := @LOCUS.reading_space
  let _ := @LOCUS.census_no_seat_no_locus
  let _ := @LOCUS.census_located_never_silent
  let _ := @LOCUS.census_crossed_iff_complete_channelled
  let _ := @LOCUS.census_halt_reports_owed
  let _ := @LOCUS.census_owed_zero_is_unchannelled
  let _ := @LOCUS.census_three_states
  let _ := @LOCUS.Token.render
  let _ := @LOCUS.Token.ascii
  let _ := @LOCUS.sealAscii
  let _ := @LOCUS.render_receipted
  let _ := @LOCUS.render_injective_in_owed
  let _ := @LOCUS.voidImage
  let _ := @LOCUS.void_precedes_economy
  let _ := @LOCUS.legacy_records_not_promoted
  let _ := @LOCUS.no_rh_locus
  let _ := @PSP.ORIENT.V3
  let _ := @PSP.ORIENT.M3
  let _ := @PSP.ORIENT.det3
  let _ := @PSP.ORIENT.neg3
  let _ := @PSP.ORIENT.signMatrices
  let _ := @PSP.ORIENT.lock_scalar_sign_blind
  let _ := @PSP.ORIENT.det_sign_flips_in_odd_dimension
  let _ := @PSP.QUAT.Q
  let _ := @PSP.QUAT.qmul
  let _ := @PSP.QUAT.qi
  let _ := @PSP.QUAT.qj
  let _ := @PSP.QUAT.qk
  let _ := @PSP.QUAT.qneg1
  let _ := @PSP.QUAT.quat_basis_laws
  let _ := @PSP.QUAT.qnorm
  let _ := @PSP.QUAT.isInt
  let _ := @PSP.QUAT.isHalf
  let _ := @PSP.QUAT.hurwitzOK
  let _ := @PSP.QUAT.grid
  let _ := @PSP.QUAT.tuples4
  let _ := @PSP.QUAT.hurwitz_units_24
  let _ := @PSP.QUAT.grid2
  let _ := @PSP.QUAT.tuples4i
  let _ := @PSP.QUAT.norm2_shell_split
  let _ := @PSP.CD.cdconj
  let _ := @PSP.CD.padd
  let _ := @PSP.CD.psub
  let _ := @PSP.CD.cdmul
  let _ := @PSP.CD.e
  let _ := @PSP.CD.smul
  let _ := @PSP.CD.octonion_associator
  let _ := @PSP.CD.sx
  let _ := @PSP.CD.sy
  let _ := @PSP.CD.zero16
  let _ := @PSP.CD.sqnorm
  let _ := @PSP.CD.sedenion_zero_divisor
  let _ := @PSP.CASCADE.cascade
  let _ := @PSP.CASCADE.patterns8
  let _ := @PSP.CASCADE.spec
  let _ := @PSP.CASCADE.first_failure_terminal_8
  let _ := @PSP.CASCADE.halt_free_iff_all_pass_8
  let _ := @PSP.GROUNDLESS.o0Neighbors
  let _ := @PSP.GROUNDLESS.fiveCubeCoords
  let _ := @PSP.GROUNDLESS.deg5
  let _ := @PSP.GROUNDLESS.groundless_cascade_degree
  let _ := @PSP.TOKEN.level
  let _ := @PSP.TOKEN.terminal_tokens_level_and_distinct
  let _ := @PSP.TWOGROUP.two_group_census
  let _ := @Bridge.Plane
  let _ := @Bridge.τ
  let _ := @Bridge.onLine
  let _ := @Bridge.pe
  let _ := @Bridge.fold_involutive
  let _ := @Bridge.locus_is_the_fixed_set
  let _ := @Bridge.locus_inhabited
  let _ := @Bridge.line_symmetric
  let _ := @Bridge.LineProperty
  let _ := @Bridge.planeFrame
  let _ := @Bridge.plane_line_property
  let _ := @Bridge.lineFrame
  let _ := @Bridge.theRecord
  let _ := @Bridge.cannot_lie
  let _ := @Bridge.cannot_deviate
  let _ := @Bridge.read_twice
  let _ := @Bridge.halted_iff
  let _ := @Bridge.cannot_extend
  let _ := @Bridge.cannot_divide
  let _ := @Bridge.delete
  let _ := @Bridge.cannot_reverse
  let _ := @Bridge.Even
  let _ := @Bridge.wall
  let _ := @Bridge.calibration
  let _ := @Bridge.SelfVerifying
  let _ := @Bridge.opens_on_the_deed
  let _ := @Bridge.recursion_is_shared
  let _ := @Bridge.recursion_is_sign_blind
  let _ := @Bridge.exactly_one_stands
  let _ := @Bridge.twoPoint
  let _ := @Bridge.denial_is_coherent
  let _ := @Bridge.line_property_contingent
  let _ := @Bridge.Keyless
  let _ := @Bridge.Keyed
  let _ := @Bridge.keyless_iff_valid
  let _ := @Bridge.discriminator
  let _ := @Bridge.symmetry_is_keyless
  let _ := @Bridge.line_property_is_keyed
  let _ := @Bridge.denial_asymmetry
  let _ := @Bridge.socket_is_the_property
  let _ := @Bridge.socket_on_the_plane
  let _ := @Bridge.bridge_carries
  let _ := @Bridge.no_socket_off_line
  let _ := @Bridge.the_bridge
  let _ := @PNF.ParityBarrier
  let _ := @PNF.sep_of_parity
  let _ := @PNF.parity_of_sep
  let _ := @PNF.sepCheck
  let _ := @PNF.sepCheck_iff
  let _ := @PNF.parity_normal_form_list
  let _ := @PNF.shift
  let _ := @PNF.shift_false
  let _ := @PNF.shift_true
  let _ := @PNF.ComplementPair
  let _ := @PNF.complement_pair_is_one_bit
  let _ := @PNF.complement_pair_distinct
  let _ := @PNF.one_bit_iff_complement_pair
  let _ := @PNF.odd_witness_closes
  let _ := @PNF.whollyOddMask
  let _ := @PNF.oddCount
  let _ := @PNF.odd_family_k1
  let _ := @PNF.odd_family_k2
  let _ := @PNF.odd_family_k3
  let _ := @PNF.odd_family_k4
  let _ := @PNF.odd_family_k6
  let _ := @PNF.rows_one_bit_iff_complement_pair
  let _ := @APEX.sigma
  let _ := @APEX.sigma_binding
  let _ := @APEX.fix_iff_scalar
  let _ := @APEX.Seat
  let _ := @APEX.theReturn
  let _ := @APEX.return_is_chirality
  let _ := @APEX.return_lands_on_seat
  let _ := @APEX.fixProj
  let _ := @APEX.GammaRA
  let _ := @APEX.GammaRAM
  let _ := @APEX.GammaRH
  let _ := @APEX.self_gap_nonexistent
  let _ := @APEX.register_gap_nonexistent
  let _ := @APEX.object_gap_nonexistent
  let _ := @APEX.seat
  let _ := @APEX.seat_on_scalar_line
  let _ := @APEX.theReturnOdd
  let _ := @APEX.odd_return_is_plus_one
  let _ := @APEX.odd_return_on_seat
  let _ := @APEX.seat_points_differ
  let _ := @APEX.D3
  let _ := @APEX.CategoryGap
  let _ := @APEX.cone_iff_no_gap
  let _ := @APEX.Cone
  let _ := @APEX.identity_cone
  let _ := @APEX.cone_apex_unique
  let _ := @APEX.cone_iff_gaps_closed
  let _ := @APEX.D3odd
  let _ := @APEX.identity_cone_odd
  let _ := @APEX.apexes_differ_by_orientation
  let _ := @APEX.sigmaP
  let _ := @APEX.sigmaP_binding
  let _ := @APEX.sigmaP_fix_iff
  let _ := @APEX.seats_meet_only_at_zero
  let _ := @APEX.register_leg_rides_one_involution
  let _ := @APEX.phi
  let _ := @APEX.phi_equivariant
  let _ := @APEX.phi_fix_iff
  let _ := @APEX.phi_fix_iff_line
  let _ := @APEX.phi_injective
  let _ := @APEX.tauM
  let _ := @APEX.phiM
  let _ := @APEX.phiM_equivariant
  let _ := @APEX.phiM_fix_iff
  let _ := @APEX.seat_on_image_of_line
  let _ := @APEX.seat_occupied_iff_grounded
  let _ := @APEX.seat_vacant_of_free
  let _ := @APEX.seat_vacant_of_equivariant
  let _ := @APEX.complement
  let _ := @APEX.complement_free
  let _ := @APEX.pnp_seat_vacant
  let _ := @APEX.pnpBridge
  let _ := @APEX.pnp_bridge_admissible
  let _ := @APEX.pnp_bridge_off_seat
  let _ := @APEX.riemann_seat_occupied
  let _ := @APEX.router_at_the_seat
  let _ := @APEX.RAMFormalGround
  let _ := @APEX.constructed_RAM
  let _ := @APEX.FormalSelf
  let _ := @APEX.constructed_orientation
  let _ := @APEX.orientation_proof_irrelevant
  let _ := @APEX.modelΔE
  let _ := @APEX.RAModel
  let _ := @APEX.modelRA
  let _ := @APEX.mkWitness
  let _ := @APEX.eliminator
  let _ := @APEX.recursion_is_constant
  let _ := @APEX.deed_unreadable_at_seat
  let _ := @APEX.no_exterior_agent
  let _ := @APEX.adjudicator_in_domain
  let _ := @APEX.no_total_self_indexing
  let _ := @APEX.live
  let _ := @APEX.aperture_opens_under_premise
  let _ := @APEX.no_interior_under_premise
  let _ := @APEX.rule_exact
  let _ := @APEX.rule_exact_model
  let _ := @APEX.rule_exact_under_root
  let _ := @APEX.twoPoint_fails_L
  let _ := @APEX.premise_decides_no_frame
  let _ := @APEX.foldThree
  let _ := @APEX.foldThree_involutive
  let _ := @APEX.zeroThree
  let _ := @APEX.zeroThree_symmetric
  let _ := @APEX.threePoint
  let _ := @APEX.threePoint_grounded
  let _ := @APEX.threePoint_fails_L
  let _ := @APEX.premise_holds_where_L_fails_grounded
  let _ := @APEX.no_cure
  let _ := @APEX.cure_is_the_hypothesis
  let _ := @APEX.carrierOfDecision
  let _ := @APEX.twoPoint_carrier_does_not_halt
  let _ := @APEX.legMeasure
  let _ := @APEX.arcMeasure
  let _ := @APEX.valueMeasure
  let _ := @APEX.masses_all_zero
  let _ := @APEX.contents_differ
  let _ := @APEX.prices_differ
  let _ := @APEX.Row.all
  let _ := @APEX.rows_twenty_three
  let _ := @APEX.rows_distinct
  let _ := @APEX.rows_complete
  let _ := @APEX.Row.millennium
  let _ := @APEX.millennium_seven
  let _ := @APEX.extension_sixteen
  let _ := @APEX.apexSeat
  let _ := @APEX.apex_seat_fixed
  let _ := @APEX.apex_seat_uniform
  let _ := @APEX.crossed_and_open_share_the_seat
  let _ := @APEX.D3row
  let _ := @APEX.identity_cone_row
  let _ := @APEX.cone_apex_unique_row
  let _ := @APEX.gaps_closed_every_row
  let _ := @APEX.formalSelfRow
  let _ := @APEX.inverted_control
  let _ := @APEX.all_rows_eliminated
  let _ := @APEX.value
  let _ := @APEX.rule_exact_every_row
  let _ := @APEX.premise_decides_no_row
  let _ := @APEX.premise_decides_no_row_grounded
  let _ := @APEX.no_cure_every_row
  let _ := @APEX.worldTyping
  let _ := @APEX.world_census
  let _ := @APEX.seatAnswers
  let _ := @APEX.valueAnswers
  let _ := @APEX.seat_line
  let _ := @APEX.value_compartment
  let _ := @APEX.seat_line_void_without_rider
  let _ := @APEX.seatToken
  let _ := @APEX.seat_token_is_aGivenRA
  let _ := @APEX.valueReading
  let _ := @APEX.riemann_value_line
  let _ := @APEX.pnp_value_line
  let _ := @APEX.poincare_value_line
  let _ := @APEX.unrouted_value_line
  let _ := @APEX.riemann_value_line_is_pinned
  let _ := @APEX.value_bits_owed
  let _ := @APEX.crossed_iff_poincare
  let _ := @APEX.lines_parted
  let _ := @APEX.seat_never_promotes_value
  let _ := @APEX.objectLeg
  let _ := @APEX.object_leg_ledger
  let _ := @APEX.object_legs_justified
  let _ := @APEX.owedPrice
  let _ := @APEX.owed_price_is_twenty_two_floors
  let _ := @APEX.seat_anchor
  let _ := @FENCE.seat
  let _ := @FOUND.seatInventory
  let _ := @FOUND.seat_rides_the_connector
  trivial

/-- info: 'codexCone' depends on axioms: [propext,
 Classical.choice,
 POSTULATE.Algorithm,
 POSTULATE.FrozenData,
 POSTULATE.Row,
 POSTULATE.SupplyClean,
 POSTULATE.certifiedPairing,
 Quot.sound,
 ROOT.FormalDomain,
 ROOT.L1m,
 ROOT.L3m,
 ROOT.RA,
 ROOT.U,
 ROOT.nest_21,
 ROOT.nest_32,
 ROOT.ΔE] -/
#guard_msgs in #print axioms codexCone

/-! ## the environment audit, run by the elaborator, over the whole codex: the local axioms are exactly the
twenty-three declared posits of ROOT and POSTULATE, sorted by name; no declaration depends on any axiom beyond
propext, Classical.choice, Quot.sound and that roster; the roster the Fortran twin declares by name (twin_posits)
is this list. -/
/-- info: environment audit: local axioms [POSTULATE.Algorithm,
 POSTULATE.Crossing,
 POSTULATE.FormalFace,
 POSTULATE.FrozenData,
 POSTULATE.KineticFace,
 POSTULATE.RegistrationPostulate,
 POSTULATE.Row,
 POSTULATE.SupplyClean,
 POSTULATE.certifiedPairing,
 POSTULATE.erasureClass,
 ROOT.FormalDomain,
 ROOT.Ground,
 ROOT.L1m,
 ROOT.L2m,
 ROOT.L3m,
 ROOT.RA,
 ROOT.Residence,
 ROOT.U,
 ROOT.nest_21,
 ROOT.nest_32,
 ROOT.ΔE,
 ROOT.σ,
 ROOT.σ_binding]; dependencies beyond propext, Classical.choice, Quot.sound [POSTULATE.Algorithm,
 POSTULATE.Crossing,
 POSTULATE.FormalFace,
 POSTULATE.FrozenData,
 POSTULATE.KineticFace,
 POSTULATE.RegistrationPostulate,
 POSTULATE.Row,
 POSTULATE.SupplyClean,
 POSTULATE.certifiedPairing,
 POSTULATE.erasureClass,
 ROOT.FormalDomain,
 ROOT.Ground,
 ROOT.L1m,
 ROOT.L2m,
 ROOT.L3m,
 ROOT.RA,
 ROOT.Residence,
 ROOT.U,
 ROOT.nest_21,
 ROOT.nest_32,
 ROOT.ΔE,
 ROOT.σ,
 ROOT.σ_binding]; outside the declared roster []; roster size 23 -/
#guard_msgs in
open Lean Elab Command in
#eval show CommandElabM Unit from do
  let env ← getEnv
  let sortNames (l : List Name) : List Name :=
    (l.toArray.qsort (fun a b => a.toString < b.toString)).toList
  let ours (n : Name) : Bool :=
    match env.getModuleIdxFor? n with
    | some idx => ((env.header.moduleNames.getD idx.toNat `_).toString.startsWith "Codex")
    | none => true
  let locals := (env.constants.map₁.toList.filter (fun p => ours p.1)).map (·.1)
    ++ env.constants.map₂.toList.map (·.1)
  let declared := sortNames <| locals.filter fun n => !n.isInternal && match env.find? n with
    | some (.axiomInfo _) => true
    | _ => false
  let standard : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut beyond : List Name := []
  for n in locals do
    unless n.isInternal do
      for d in (← collectAxioms n) do
        unless standard.contains d || beyond.contains d do beyond := d :: beyond
  let depended := sortNames beyond
  let outsideRoster := depended.filter fun d => !declared.contains d
  logInfo m!"environment audit: local axioms {declared}; dependencies beyond propext, Classical.choice, Quot.sound {depended}; outside the declared roster {outsideRoster}; roster size {declared.length}"


/-! ## FORGE cones and the crosswalk audit -/
/-- info: 'K4.semiprimes_at_odd_seats' does not depend on any axioms -/
#guard_msgs in #print axioms K4.semiprimes_at_odd_seats
/-- info: 'K4.semiprime_factors_prime' does not depend on any axioms -/
#guard_msgs in #print axioms K4.semiprime_factors_prime
/-- info: 'K4.odd_seats_not_prime' does not depend on any axioms -/
#guard_msgs in #print axioms K4.odd_seats_not_prime
/-- info: 'IMPRINT.ghost_is_broken_never_sealed' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.ghost_is_broken_never_sealed
/-- info: 'K4.target_is_primality' does not depend on any axioms -/
#guard_msgs in #print axioms K4.target_is_primality
/-- info: 'K4.primes_at_even_seats' does not depend on any axioms -/
#guard_msgs in #print axioms K4.primes_at_even_seats
/-- info: 'K4.pairs_match_mod_420' does not depend on any axioms -/
#guard_msgs in #print axioms K4.pairs_match_mod_420
/-- info: 'IMPRINT.ghost_refused' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.ghost_refused
/-- info: 'IMPRINT.seal_iff_one_side_clean_and_witnessed' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.seal_iff_one_side_clean_and_witnessed
/-- info: 'IMPRINT.seal_needs_witness' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.seal_needs_witness
/-- info: 'IMPRINT.both_clean_is_ghost' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.both_clean_is_ghost
/-- info: 'IMPRINT.flat_when_unpopulated' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.flat_when_unpopulated
/-- info: 'DEFENSE.gol_needs_all_three' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.gol_needs_all_three
/-- info: 'DEFENSE.lock_blind_but_gol_directed' depends on axioms: [propext] -/
#guard_msgs in #print axioms DEFENSE.lock_blind_but_gol_directed
/-- info: 'DEFENSE.consensus_weighs_zero' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.consensus_weighs_zero
/-- info: 'DEFENSE.tongue_unclosed_and_obedient' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms DEFENSE.tongue_unclosed_and_obedient
/-- info: 'DEFENSE.self_check_is_not_witness' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.self_check_is_not_witness
/-- info: 'DEFENSE.denial_is_priced' depends on axioms: [propext] -/
#guard_msgs in #print axioms DEFENSE.denial_is_priced
/-- info: 'DEFENSE.no_anchor_at_target' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.no_anchor_at_target
/-- info: 'DEFENSE.formal_reads_never_the_deed' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.formal_reads_never_the_deed
/-- info: 'DEFENSE.forward_is_world_rowed' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.forward_is_world_rowed
/-- info: 'DEFENSE.worldly_row_is_world_rowed' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.worldly_row_is_world_rowed
/-- info: 'FENCE.global' depends on axioms: [propext, Quot.sound, ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms FENCE.global
/-- info: 'DOT.outside_economy' depends on axioms: [propext] -/
#guard_msgs in #print axioms DOT.outside_economy
/-- info: 'DOT.no_reading_is_silence' depends on axioms: [propext] -/
#guard_msgs in #print axioms DOT.no_reading_is_silence
/-- info: 'DOT.silence_is_not_a_verdict' does not depend on any axioms -/
#guard_msgs in #print axioms DOT.silence_is_not_a_verdict
/-- info: 'CROSSWALK.rows_count' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSWALK.rows_count


/-! ## SEAT ANCHOR cones: every declaration of the apex layer carries its receipt -/
/-- info: 'PNF.ParityBarrier' does not depend on any axioms -/
#guard_msgs in #print axioms PNF.ParityBarrier
/-- info: 'PNF.sep_of_parity' does not depend on any axioms -/
#guard_msgs in #print axioms PNF.sep_of_parity
/-- info: 'PNF.parity_of_sep' depends on axioms: [propext] -/
#guard_msgs in #print axioms PNF.parity_of_sep
/-- info: 'PNF.sepCheck' does not depend on any axioms -/
#guard_msgs in #print axioms PNF.sepCheck
/-- info: 'PNF.sepCheck_iff' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms PNF.sepCheck_iff
/-- info: 'PNF.parity_normal_form_list' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms PNF.parity_normal_form_list
/-- info: 'PNF.shift' does not depend on any axioms -/
#guard_msgs in #print axioms PNF.shift
/-- info: 'PNF.shift_false' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms PNF.shift_false
/-- info: 'PNF.shift_true' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms PNF.shift_true
/-- info: 'PNF.ComplementPair' does not depend on any axioms -/
#guard_msgs in #print axioms PNF.ComplementPair
/-- info: 'PNF.complement_pair_is_one_bit' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms PNF.complement_pair_is_one_bit
/-- info: 'PNF.complement_pair_distinct' does not depend on any axioms -/
#guard_msgs in #print axioms PNF.complement_pair_distinct
/-- info: 'PNF.one_bit_iff_complement_pair' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms PNF.one_bit_iff_complement_pair
/-- info: 'PNF.odd_witness_closes' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms PNF.odd_witness_closes
/-- info: 'PNF.whollyOddMask' depends on axioms: [propext] -/
#guard_msgs in #print axioms PNF.whollyOddMask
/-- info: 'PNF.oddCount' depends on axioms: [propext] -/
#guard_msgs in #print axioms PNF.oddCount
/-- info: 'PNF.odd_family_k1' depends on axioms: [propext] -/
#guard_msgs in #print axioms PNF.odd_family_k1
/-- info: 'PNF.odd_family_k2' depends on axioms: [propext] -/
#guard_msgs in #print axioms PNF.odd_family_k2
/-- info: 'PNF.odd_family_k3' depends on axioms: [propext] -/
#guard_msgs in #print axioms PNF.odd_family_k3
/-- info: 'PNF.odd_family_k4' depends on axioms: [propext] -/
#guard_msgs in #print axioms PNF.odd_family_k4
/-- info: 'PNF.odd_family_k6' depends on axioms: [propext] -/
#guard_msgs in #print axioms PNF.odd_family_k6
/-- info: 'PNF.rows_one_bit_iff_complement_pair' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms PNF.rows_one_bit_iff_complement_pair
/-- info: 'APEX.sigma' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.sigma
/-- info: 'APEX.sigma_binding' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.sigma_binding
/-- info: 'APEX.fix_iff_scalar' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms APEX.fix_iff_scalar
/-- info: 'APEX.Seat' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.Seat
/-- info: 'APEX.theReturn' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.theReturn
/-- info: 'APEX.return_is_chirality' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.return_is_chirality
/-- info: 'APEX.return_lands_on_seat' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.return_lands_on_seat
/-- info: 'APEX.fixProj' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.fixProj
/-- info: 'APEX.GammaRA' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.GammaRA
/-- info: 'APEX.GammaRAM' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.GammaRAM
/-- info: 'APEX.GammaRH' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.GammaRH
/-- info: 'APEX.self_gap_nonexistent' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.self_gap_nonexistent
/-- info: 'APEX.register_gap_nonexistent' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.register_gap_nonexistent
/-- info: 'APEX.object_gap_nonexistent' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.object_gap_nonexistent
/-- info: 'APEX.seat' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat
/-- info: 'APEX.seat_on_scalar_line' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms APEX.seat_on_scalar_line
/-- info: 'APEX.theReturnOdd' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.theReturnOdd
/-- info: 'APEX.odd_return_is_plus_one' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.odd_return_is_plus_one
/-- info: 'APEX.odd_return_on_seat' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.odd_return_on_seat
/-- info: 'APEX.seat_points_differ' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat_points_differ
/-- info: 'APEX.D3' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.D3
/-- info: 'APEX.CategoryGap' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.CategoryGap
/-- info: 'APEX.cone_iff_no_gap' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.cone_iff_no_gap
/-- info: 'APEX.Cone' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.Cone
/-- info: 'APEX.identity_cone' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.identity_cone
/-- info: 'APEX.cone_apex_unique' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.cone_apex_unique
/-- info: 'APEX.cone_iff_gaps_closed' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.cone_iff_gaps_closed
/-- info: 'APEX.D3odd' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.D3odd
/-- info: 'APEX.identity_cone_odd' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.identity_cone_odd
/-- info: 'APEX.apexes_differ_by_orientation' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.apexes_differ_by_orientation
/-- info: 'APEX.sigmaP' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.sigmaP
/-- info: 'APEX.sigmaP_binding' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.sigmaP_binding
/-- info: 'APEX.sigmaP_fix_iff' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms APEX.sigmaP_fix_iff
/-- info: 'APEX.seats_meet_only_at_zero' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms APEX.seats_meet_only_at_zero
/-- info: 'APEX.register_leg_rides_one_involution' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.register_leg_rides_one_involution
/-- info: 'APEX.phi' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.phi
/-- info: 'APEX.phi_equivariant' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms APEX.phi_equivariant
/-- info: 'APEX.phi_fix_iff' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms APEX.phi_fix_iff
/-- info: 'APEX.phi_fix_iff_line' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms APEX.phi_fix_iff_line
/-- info: 'APEX.phi_injective' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms APEX.phi_injective
/-- info: 'APEX.tauM' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.tauM
/-- info: 'APEX.phiM' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.phiM
/-- info: 'APEX.phiM_equivariant' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms APEX.phiM_equivariant
/-- info: 'APEX.phiM_fix_iff' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms APEX.phiM_fix_iff
/-- info: 'APEX.seat_on_image_of_line' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat_on_image_of_line
/-- info: 'APEX.seat_occupied_iff_grounded' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat_occupied_iff_grounded
/-- info: 'APEX.seat_vacant_of_free' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat_vacant_of_free
/-- info: 'APEX.seat_vacant_of_equivariant' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat_vacant_of_equivariant
/-- info: 'APEX.complement' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.complement
/-- info: 'APEX.complement_free' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.complement_free
/-- info: 'APEX.pnp_seat_vacant' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.pnp_seat_vacant
/-- info: 'APEX.pnpBridge' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.pnpBridge
/-- info: 'APEX.pnp_bridge_admissible' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.pnp_bridge_admissible
/-- info: 'APEX.pnp_bridge_off_seat' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.pnp_bridge_off_seat
/-- info: 'APEX.riemann_seat_occupied' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.riemann_seat_occupied
/-- info: 'APEX.router_at_the_seat' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms APEX.router_at_the_seat
/-- info: 'APEX.RAMFormalGround' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.RAMFormalGround
/-- info: 'APEX.constructed_RAM' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.constructed_RAM
/-- info: 'APEX.FormalSelf' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.FormalSelf
/-- info: 'APEX.constructed_orientation' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.constructed_orientation
/-- info: 'APEX.orientation_proof_irrelevant' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.orientation_proof_irrelevant
/-- info: 'APEX.modelΔE' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.modelΔE
/-- info: 'APEX.RAModel' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.RAModel
/-- info: 'APEX.modelRA' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.modelRA
/-- info: 'APEX.mkWitness' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.mkWitness
/-- info: 'APEX.eliminator' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.eliminator
/-- info: 'APEX.recursion_is_constant' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.recursion_is_constant
/-- info: 'APEX.deed_unreadable_at_seat' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.deed_unreadable_at_seat
/-- info: 'APEX.no_exterior_agent' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.no_exterior_agent
/-- info: 'APEX.adjudicator_in_domain' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.adjudicator_in_domain
/-- info: 'APEX.no_total_self_indexing' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.no_total_self_indexing
/-- info: 'APEX.live' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.live
/-- info: 'APEX.aperture_opens_under_premise' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.aperture_opens_under_premise
/-- info: 'APEX.no_interior_under_premise' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.no_interior_under_premise
/-- info: 'APEX.rule_exact' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.rule_exact
/-- info: 'APEX.rule_exact_model' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.rule_exact_model
/-- info: 'APEX.rule_exact_under_root' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms APEX.rule_exact_under_root
/-- info: 'APEX.twoPoint_fails_L' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.twoPoint_fails_L
/-- info: 'APEX.premise_decides_no_frame' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.premise_decides_no_frame
/-- info: 'APEX.foldThree' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.foldThree
/-- info: 'APEX.foldThree_involutive' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.foldThree_involutive
/-- info: 'APEX.zeroThree' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.zeroThree
/-- info: 'APEX.zeroThree_symmetric' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.zeroThree_symmetric
/-- info: 'APEX.threePoint' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.threePoint
/-- info: 'APEX.threePoint_grounded' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.threePoint_grounded
/-- info: 'APEX.threePoint_fails_L' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.threePoint_fails_L
/-- info: 'APEX.premise_holds_where_L_fails_grounded' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.premise_holds_where_L_fails_grounded
/-- info: 'APEX.no_cure' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.no_cure
/-- info: 'APEX.cure_is_the_hypothesis' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.cure_is_the_hypothesis
/-- info: 'APEX.carrierOfDecision' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.carrierOfDecision
/-- info: 'APEX.twoPoint_carrier_does_not_halt' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.twoPoint_carrier_does_not_halt
/-- info: 'APEX.legMeasure' depends on axioms: [propext] -/
#guard_msgs in #print axioms APEX.legMeasure
/-- info: 'APEX.arcMeasure' depends on axioms: [propext] -/
#guard_msgs in #print axioms APEX.arcMeasure
/-- info: 'APEX.valueMeasure' depends on axioms: [propext] -/
#guard_msgs in #print axioms APEX.valueMeasure
/-- info: 'APEX.masses_all_zero' depends on axioms: [propext] -/
#guard_msgs in #print axioms APEX.masses_all_zero
/-- info: 'APEX.contents_differ' depends on axioms: [propext] -/
#guard_msgs in #print axioms APEX.contents_differ
/-- info: 'APEX.prices_differ' depends on axioms: [propext] -/
#guard_msgs in #print axioms APEX.prices_differ
/-- info: 'APEX.Row.all' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.Row.all
/-- info: 'APEX.rows_twenty_three' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.rows_twenty_three
/-- info: 'APEX.rows_distinct' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.rows_distinct
/-- info: 'APEX.rows_complete' depends on axioms: [propext] -/
#guard_msgs in #print axioms APEX.rows_complete
/-- info: 'APEX.Row.millennium' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.Row.millennium
/-- info: 'APEX.millennium_seven' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.millennium_seven
/-- info: 'APEX.extension_sixteen' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.extension_sixteen
/-- info: 'APEX.apexSeat' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.apexSeat
/-- info: 'APEX.apex_seat_fixed' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.apex_seat_fixed
/-- info: 'APEX.apex_seat_uniform' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.apex_seat_uniform
/-- info: 'APEX.crossed_and_open_share_the_seat' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.crossed_and_open_share_the_seat
/-- info: 'APEX.D3row' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.D3row
/-- info: 'APEX.identity_cone_row' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.identity_cone_row
/-- info: 'APEX.cone_apex_unique_row' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.cone_apex_unique_row
/-- info: 'APEX.gaps_closed_every_row' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.gaps_closed_every_row
/-- info: 'APEX.formalSelfRow' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.formalSelfRow
/-- info: 'APEX.inverted_control' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.inverted_control
/-- info: 'APEX.all_rows_eliminated' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.all_rows_eliminated
/-- info: 'APEX.value' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.value
/-- info: 'APEX.rule_exact_every_row' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.rule_exact_every_row
/-- info: 'APEX.premise_decides_no_row' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.premise_decides_no_row
/-- info: 'APEX.premise_decides_no_row_grounded' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.premise_decides_no_row_grounded
/-- info: 'APEX.no_cure_every_row' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.no_cure_every_row
/-- info: 'APEX.worldTyping' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.worldTyping
/-- info: 'APEX.world_census' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.world_census
/-- info: 'APEX.seatAnswers' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seatAnswers
/-- info: 'APEX.valueAnswers' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.valueAnswers
/-- info: 'APEX.seat_line' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat_line
/-- info: 'APEX.value_compartment' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.value_compartment
/-- info: 'APEX.seat_line_void_without_rider' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat_line_void_without_rider
/-- info: 'APEX.seatToken' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seatToken
/-- info: 'APEX.seat_token_is_aGivenRA' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat_token_is_aGivenRA
/-- info: 'APEX.valueReading' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.valueReading
/-- info: 'APEX.riemann_value_line' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.riemann_value_line
/-- info: 'APEX.pnp_value_line' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.pnp_value_line
/-- info: 'APEX.poincare_value_line' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.poincare_value_line
/-- info: 'APEX.unrouted_value_line' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.unrouted_value_line
/-- info: 'APEX.riemann_value_line_is_pinned' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.riemann_value_line_is_pinned
/-- info: 'APEX.value_bits_owed' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.value_bits_owed
/-- info: 'APEX.crossed_iff_poincare' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.crossed_iff_poincare
/-- info: 'APEX.lines_parted' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.lines_parted
/-- info: 'APEX.seat_never_promotes_value' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat_never_promotes_value
/-- info: 'APEX.objectLeg' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.objectLeg
/-- info: 'APEX.object_leg_ledger' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.object_leg_ledger
/-- info: 'APEX.object_legs_justified' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.object_legs_justified
/-- info: 'APEX.owedPrice' depends on axioms: [propext] -/
#guard_msgs in #print axioms APEX.owedPrice
/-- info: 'APEX.owed_price_is_twenty_two_floors' depends on axioms: [propext] -/
#guard_msgs in #print axioms APEX.owed_price_is_twenty_two_floors
/-- info: 'APEX.seat_anchor' does not depend on any axioms -/
#guard_msgs in #print axioms APEX.seat_anchor
/-- info: 'FENCE.seat' does not depend on any axioms -/
#guard_msgs in #print axioms FENCE.seat
/-- info: 'FOUND.seatInventory' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.seatInventory
/-- info: 'FOUND.seat_rides_the_connector' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.seat_rides_the_connector

/-- info: crosswalk audit: 151 rows, 0 unresolved, [] -/
#guard_msgs in
open Lean Elab Command in
#eval show CommandElabM Unit from do
  let env ← getEnv
  let missing := CROSSWALK.rows.filter fun r => !(env.contains r.2.toName)
  logInfo m!"crosswalk audit: {CROSSWALK.rows.length} rows, {missing.length} unresolved, {missing.map (·.1)}"


