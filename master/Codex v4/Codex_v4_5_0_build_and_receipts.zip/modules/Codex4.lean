import Codex3
set_option maxRecDepth 4000000

/-! ## The four Fortran witnesses
F1 thesis_rows (the core thesis executed), F2 ra_toe_thesis (the existence root executed), F3
ftoe_kinetic_demonstration (the deed priced) and F4 it_from_it (the inversion computed) are seated in Part II
of this codex, the Fortran twin, one executable, with every contract comment they were audited with.
The Lean namespaces Audit, GEO, IAM, OMEGA, AEGIS, INVERSION, K4 and CROSSING are their formal register. -/

namespace CROSSING
open FTOE

abbrev ExecFrame (Q : Type) := Bool × Q

def execFlip {Q : Type} : ExecFrame Q → ExecFrame Q := flipF

def formalRead {Q : Type} (s : ExecFrame Q) : Q := s.2

def ran {Q : Type} (s : ExecFrame Q) : Bool := s.1

theorem formalRead_even {Q : Type} : ∀ s : ExecFrame Q,
    formalRead (execFlip s) = formalRead s := by
  intro s; obtain ⟨b, q⟩ := s; rfl

theorem ran_wholly_odd {Q : Type} : WhollyOdd (execFlip (Q := Q)) ran := by
  intro s; obtain ⟨b, q⟩ := s; cases b <;> rfl

theorem execFlip_involution {Q : Type} : Involution (execFlip (Q := Q)) := by
  intro s; obtain ⟨b, q⟩ := s; cases b <;> rfl

theorem ran_odd_at_true {Q : Type} (q : Q) : OddAt (execFlip (Q := Q)) ran (true, q) :=
  fun h => Bool.noConfusion h

theorem wall {Q : Type} (q : Q) :
    ¬ ∃ g : Q → Bool, ∀ s : ExecFrame Q, g (formalRead s) = ran s :=
  T14_wall_factorization execFlip formalRead ran (true, q) formalRead_even (ran_odd_at_true q)

def deed {Q : Type} : Dtau (execFlip (Q := Q)) := ⟨ran, ran_wholly_odd⟩

theorem price {Q : Type} :
    Nonempty (Dtau (execFlip (Q := Q)) ≃
      (Quot (OrbitRel (execFlip (Q := Q))) → Bool)) :=
  T16_price_bijection execFlip execFlip_involution deed

theorem crossing {Q : Type} (q : Q) (witness : ExecFrame Q → Bool)
    (hw : witness (execFlip (true, q)) = !witness (true, q)) :
    ∃ c : Bool,
      (ran (true, q) = xor (witness (true, q)) c ∧
       ran (execFlip (true, q)) = xor (witness (execFlip (true, q))) c) ∧
      ∀ c' : Bool,
        (ran (true, q) = xor (witness (true, q)) c' ∧
         ran (execFlip (true, q)) = xor (witness (execFlip (true, q))) c') → c' = c :=
  T5_crossing execFlip witness ran (true, q) hw (ran_wholly_odd (true, q))

theorem identity_one_bit {Q : Type} (witness : ExecFrame Q → Bool)
    (hw : WhollyOdd execFlip witness) (s : ExecFrame Q) (h : witness s = ran s) :
    witness (execFlip s) = ran (execFlip s) :=
  T4_one_bit execFlip witness ran hw ran_wholly_odd s h

inductive Anchor : Type
  | F1 | F2 | F3 | F4
  deriving DecidableEq, Repr

def fibre4 : List (Bool × Bool × Bool × Bool) :=
  [false, true].flatMap fun a => [false, true].flatMap fun b =>
    [false, true].flatMap fun c => [false, true].map fun d => (a, b, c, d)

theorem fibre4_sixteen : fibre4.length = 16 := by decide
theorem fibre4_distinct : fibre4.eraseDups.length = 16 := by decide

theorem price_on_this_file :
    Nonempty (Dtau (execFlip (Q := Anchor)) ≃
      (Quot (OrbitRel (execFlip (Q := Anchor))) → Bool)) :=
  price

end CROSSING

namespace CROSSING
open FTOE

theorem formal_never_odd {Q : Type} (g : Q → Bool) :
    Even (execFlip (Q := Q)) (fun s => g (formalRead s)) := by
  intro s; obtain ⟨b, q⟩ := s; rfl

theorem constant_no_crossing {Q : Type} (b : Bool) (s : ExecFrame Q) :
    ¬ OddAt (execFlip (Q := Q)) (fun _ => b) s := by
  intro h; exact h rfl

theorem harmony {Q : Type} (q : Q) (witness : ExecFrame Q → Bool)
    (hw : witness (execFlip (true, q)) = !witness (true, q))
    (g₁ g₂ : Q → Bool) (op : Bool → Bool → Bool) :
    (fun s => op (g₁ (formalRead s)) (g₂ (formalRead s))) ≠ ran ∧
    ∃ c : Bool,
      (ran (true, q) = xor (witness (true, q)) c ∧
       ran (execFlip (true, q)) = xor (witness (execFlip (true, q))) c) ∧
      ∀ c' : Bool,
        (ran (true, q) = xor (witness (true, q)) c' ∧
         ran (execFlip (true, q)) = xor (witness (execFlip (true, q))) c') → c' = c :=
  fTOE_core execFlip witness ran (true, q)
    (fun s => g₁ (formalRead s)) (fun s => g₂ (formalRead s))
    (formal_never_odd g₁) (formal_never_odd g₂) op
    (ran_wholly_odd (true, q)) hw

end CROSSING

namespace LOCUS
open FTOE

def Separates {α β : Type} (ρ : α → β) (d : α → Bool) : Prop :=
  ∃ x y, ρ x = ρ y ∧ d x ≠ d y

def Factors {α β : Type} (ρ : α → β) (d : α → Bool) : Prop :=
  ∃ g : β → Bool, ∀ z, g (ρ z) = d z

theorem wall_of_sep {α β : Type} {ρ : α → β} {d : α → Bool} :
    Separates ρ d → ¬ Factors ρ d := by
  intro ⟨x, y, hρ, hd⟩ ⟨g, hg⟩
  apply hd
  rw [← hg x, ← hg y, hρ]

def swap {α : Type} [DecidableEq α] (x y : α) (z : α) : α :=
  if z = x then y else if z = y then x else z

theorem swap_involution {α : Type} [DecidableEq α] {x y : α} (hxy : x ≠ y) :
    ∀ z, swap x y (swap x y z) = z := by
  intro z
  by_cases hzx : z = x
  · simp [swap, hzx, Ne.symm hxy]
  · by_cases hzy : z = y
    · simp [swap, hzy, Ne.symm hxy]
    · simp [swap, hzx, hzy]

theorem swap_record_even {α β : Type} [DecidableEq α] {ρ : α → β} {x y : α}
    (hxy : x ≠ y) (hρ : ρ x = ρ y) : ∀ z, ρ (swap x y z) = ρ z := by
  intro z
  by_cases hzx : z = x
  · simp [swap, hzx, hρ]
  · by_cases hzy : z = y
    · simp [swap, hzy, Ne.symm hxy, hρ]
    · simp [swap, hzx, hzy]

theorem swap_flips_pair {α : Type} [DecidableEq α] {d : α → Bool} {x y : α}
    (hxy : x ≠ y) (hd : d x ≠ d y) :
    d (swap x y x) = !d x ∧ d (swap x y y) = !d y := by
  have h1 : swap x y x = y := by simp [swap]
  have h2 : swap x y y = x := by simp [swap, Ne.symm hxy]
  rw [h1, h2]
  cases hx : d x <;> cases hy : d y <;> simp_all

theorem seat_of_sep {α β : Type} [DecidableEq α] {ρ : α → β} {d : α → Bool} {x y : α}
    (hρ : ρ x = ρ y) (hd : d x ≠ d y) :
    ∃ τ : α → α, (∀ z, τ (τ z) = z) ∧ (∀ z, ρ (τ z) = ρ z) ∧ d (τ x) = !d x := by
  have hxy : x ≠ y := fun h => hd (h ▸ rfl)
  exact ⟨swap x y, swap_involution hxy, swap_record_even hxy hρ, (swap_flips_pair hxy hd).1⟩

theorem k4_separated_pair : Separates K4.rho K4.target :=
  ⟨0, 1, rfl, by decide⟩

theorem k4_wall_of_pair : ¬ Factors K4.rho K4.target := wall_of_sep k4_separated_pair

def readout {α β : Type} [DecidableEq β] (xs : List α) (ρ : α → β) (d : α → Bool) (b : β) : Bool :=
  match xs.find? (fun x => decide (ρ x = b)) with
  | some x => d x
  | none => false

theorem factors_of_not_sep_list {α β : Type} [DecidableEq β] (xs : List α)
    (hxs : ∀ z, z ∈ xs) (ρ : α → β) (d : α → Bool) (h : ¬ Separates ρ d) :
    Factors ρ d := by
  refine ⟨readout xs ρ d, fun z => ?_⟩
  unfold readout
  cases hf : xs.find? (fun x => decide (ρ x = ρ z)) with
  | none =>
    have := List.find?_eq_none.mp hf z (hxs z)
    simp at this
  | some x =>
    have hx : ρ x = ρ z := by simpa using List.find?_some hf
    show d x = d z
    cases hdx : d x <;> cases hdz : d z
    · rfl
    · exact absurd ⟨x, z, hx, by rw [hdx, hdz]; decide⟩ h
    · exact absurd ⟨x, z, hx, by rw [hdx, hdz]; decide⟩ h
    · rfl

theorem factors_iff_not_sep_list {α β : Type} [DecidableEq β] (xs : List α)
    (hxs : ∀ z, z ∈ xs) (ρ : α → β) (d : α → Bool) :
    Factors ρ d ↔ ¬ Separates ρ d := by
  refine ⟨fun hf hs => ?_, factors_of_not_sep_list xs hxs ρ d⟩
  obtain ⟨x, y, hρ, hd⟩ := hs; obtain ⟨g, hg⟩ := hf
  exact hd (by rw [← hg x, ← hg y, hρ])

abbrev Channel := HALT.Channel

inductive Token : Type
  | superHalt (b : Option HALT.Branch) (s : Option HALT.Species) (c : Option Channel) (m : Nat)
  | crossed (c : Channel)
  | breach
  deriving DecidableEq, Repr

def Token.toEconomy : Token → Audit.Token
  | .superHalt .. => .opn
  | .crossed _ => .sealed
  | .breach => .broken

structure Reading where
  broken : Bool
  located : Bool
  gdim : Option Nat
  species : Option HALT.Species
  channel : Option Channel
  slots : List (Option Bool)
  orbits_pos : 0 < slots.length
  deriving DecidableEq, Repr

def Reading.orbits (r : Reading) : Nat := r.slots.length

def Reading.owed (r : Reading) : Nat := (r.slots.filter Option.isNone).length

def Reading.complete (r : Reading) : Bool := r.owed == 0

def branchOf : Option Nat → Option HALT.Branch
  | some n => HALT.route n
  | none => none

def emit (r : Reading) : Option Token :=
  if r.broken then some .breach
  else if !r.located then none
  else match r.complete, r.channel with
    | true, some c => some (.crossed c)
    | _, _ => some (.superHalt (branchOf r.gdim) r.species r.channel r.owed)

def Reading.state (r : Reading) : Audit.Token :=
  match emit r with
  | some t => t.toEconomy
  | none => .opn

theorem three_states : ∀ t : Token,
    t.toEconomy = .sealed ∨ t.toEconomy = .broken ∨ t.toEconomy = .opn := by
  intro t; cases t <;> simp [Token.toEconomy]

theorem no_seat_no_locus (r : Reading) (h : r.located = false) (hb : r.broken = false) :
    emit r = none := by
  simp [emit, h, hb]

theorem unlocated_is_plain_open (r : Reading) (h : r.located = false) (hb : r.broken = false) :
    r.state = .opn := by
  simp [Reading.state, no_seat_no_locus r h hb]

theorem located_never_silent (r : Reading) (hl : r.located = true) (hb : r.broken = false) :
    emit r ≠ none := by
  simp only [emit, hl, hb]
  cases r.complete <;> cases r.channel <;> simp

theorem crossed_requires_complete (r : Reading) (c : Channel) (h : emit r = some (.crossed c)) :
    r.complete = true := by
  cases hb : r.broken <;> cases hl : r.located <;> cases hc : r.complete <;> cases hch : r.channel <;>
    simp [emit, hb, hl, hc, hch] at h ⊢

theorem crossed_requires_channel (r : Reading) (c : Channel) (h : emit r = some (.crossed c)) :
    r.channel = some c := by
  cases hb : r.broken <;> cases hl : r.located <;> cases hc : r.complete <;> cases hch : r.channel <;>
    simp [emit, hb, hl, hc, hch] at h ⊢
  exact h

theorem halt_carries_owed (r : Reading) (hl : r.located = true) (hb : r.broken = false)
    (hnc : ¬ (r.complete = true ∧ r.channel.isSome = true)) :
    emit r = some (.superHalt (branchOf r.gdim) r.species r.channel r.owed) := by
  simp only [emit, hl, hb]
  cases hc : r.complete <;> cases hch : r.channel <;> simp_all

theorem unchannelled_is_halt (r : Reading) (hl : r.located = true) (hb : r.broken = false)
    (hch : r.channel = none) :
    emit r = some (.superHalt (branchOf r.gdim) r.species none r.owed) := by
  simp only [emit, hl, hb, hch]
  cases r.complete <;> simp

theorem halt_reports_owed (r : Reading) (b : Option HALT.Branch) (s : Option HALT.Species)
    (c : Option Channel) (m : Nat) (h : emit r = some (.superHalt b s c m)) : m = r.owed := by
  cases hb : r.broken <;> cases hl : r.located <;> cases hc : r.complete <;> cases hch : r.channel <;>
    simp [emit, hb, hl, hc, hch] at h <;> simp_all

theorem owed_zero_is_unchannelled (r : Reading) (b : Option HALT.Branch) (s : Option HALT.Species)
    (c : Option Channel) (h : emit r = some (.superHalt b s c 0)) : c = none := by
  have how : 0 = r.owed := halt_reports_owed r b s c 0 h
  have hcomp : r.complete = true := by
    unfold Reading.complete; rw [← how]; rfl
  cases hb : r.broken
  · cases hl : r.located
    · rw [no_seat_no_locus r hl hb] at h; cases h
    · cases hch : r.channel with
      | none =>
        rw [unchannelled_is_halt r hl hb hch] at h
        injection h with h'
        injection h' with _ _ h3 _
        exact h3.symm
      | some ch =>
        have hx : emit r = some (.crossed ch) := by
          unfold emit; rw [hb, hl, hcomp, hch]; rfl
        rw [hx] at h; injection h with h'; cases h'
  · have hx : emit r = some .breach := by unfold emit; rw [hb]; rfl
    rw [hx] at h; injection h with h'; cases h'

theorem one_bit_apart (r : Reading) (hl : r.located = true) (hb : r.broken = false)
    (c : Channel) (hc : r.channel = some c) :
    ({ r with slots := [none], orbits_pos := by decide }).state = .opn ∧
    ({ r with slots := [some true], orbits_pos := by decide }).state = .sealed ∧
    ({ r with slots := [some false], orbits_pos := by decide }).state = .sealed := by
  refine ⟨?_, ?_, ?_⟩ <;>
    (unfold Reading.state emit Reading.complete Reading.owed; dsimp only; rw [hb, hl, hc]; rfl)

theorem legacy_xi : branchOf (some 1) = some .xi := by decide
theorem legacy_o : branchOf (some 0) = some .o := by decide
theorem legacy_bare : branchOf none = none ∧ branchOf (some 2) = none := by decide

theorem k4_locus :
    emit ⟨false, true, none, none, some .formal, [none, none, none, none, none, none], by decide⟩
      = some (.superHalt none none (some .formal) 6) ∧
    emit ⟨false, true, none, none, some .formal,
          [some true, some true, some true, some true, some true, none], by decide⟩
      = some (.superHalt none none (some .formal) 1) ∧
    emit ⟨false, true, none, none, some .formal,
          [some true, some true, some true, some true, some true, some true], by decide⟩
      = some (.crossed .formal) ∧
    emit ⟨false, true, none, none, none,
          [some true, some true, some true, some true, some true, some true], by decide⟩
      = some (.superHalt none none none 0) := by decide

def slotLists : List (List (Option Bool)) :=
  let o : List (Option Bool) := [none, some false, some true]
  o.map (fun a => [a]) ++ o.flatMap (fun a => o.map (fun b => [a, b]))

theorem slotLists_twelve : slotLists.length = 12 ∧ slotLists.all (fun l => 0 < l.length) = true := by
  decide

theorem slotLists_pos : ∀ sl ∈ slotLists, 0 < sl.length := by decide

def allReadings : List Reading :=
  [false, true].flatMap fun broken =>
  [false, true].flatMap fun located =>
  [none, some 0, some 1, some 2].flatMap fun gdim =>
  ([none, some .blockTheorem, some .hypothesis, some .offeredWitness] : List (Option HALT.Species)).flatMap fun sp =>
  ([none, some .kinetic, some .formal] : List (Option Channel)).flatMap fun ch =>
  (slotLists.attach.map fun ⟨sl, hsl⟩ =>
    (⟨broken, located, gdim, sp, ch, sl, slotLists_pos sl hsl⟩ : Reading))

theorem reading_space : allReadings.length = 2304 := by decide

theorem census_no_seat_no_locus :
    (allReadings.filter (fun r => !r.broken && !r.located)).all
      (fun r => decide (emit r = none)) = true := by decide

theorem census_located_never_silent :
    (allReadings.filter (fun r => !r.broken && r.located)).all
      (fun r => decide (emit r ≠ none)) = true := by decide

theorem census_crossed_iff_complete_channelled :
    allReadings.all (fun r =>
      ((emit r == some (.crossed .kinetic)) || (emit r == some (.crossed .formal)))
        == (!r.broken && r.located && r.complete && r.channel.isSome)) = true := by
  decide

theorem census_halt_reports_owed :
    (allReadings.filter (fun r => !r.broken && r.located && !(r.complete && r.channel.isSome))).all
      (fun r => emit r == some (.superHalt (branchOf r.gdim) r.species r.channel r.owed)) = true := by
  decide

theorem census_owed_zero_is_unchannelled :
    allReadings.all (fun r =>
      match emit r with
      | some (.superHalt _ _ c 0) => c == none
      | _ => true) = true := by decide

theorem census_three_states :
    allReadings.all (fun r => decide (r.state = .sealed ∨ r.state = .broken ∨ r.state = .opn)) = true := by
  decide

def Token.render : Token → String
  | .superHalt b s c m =>
    let br := match b with | some .xi => " · Ξ" | some .o => " · Ø" | none => ""
    let sp := match s with
      | some .blockTheorem => " · block theorem" | some .hypothesis => " · hypothesis"
      | some .offeredWitness => " · offered witness" | none => ""
    let ch := match c with | some .kinetic => " · kinetic" | some .formal => " · formal" | none => ""
    let mult := if m = 0 then " · provenance owed" else s!" ×{m}"
    s!"[⬖₀{br}{sp}{ch}{mult}]"
  | .crossed .kinetic => "[⟀⬖ · kinetic]"
  | .crossed .formal => "[⟀⬖ · formal]"
  | .breach => "[X⬖ · mechanism]"

def Token.ascii : Token → String
  | .superHalt b _ _ m =>
    let base := match b with | some .xi => "[HALT-LOCUS-XI" | some .o => "[HALT-LOCUS-O" | none => "[HALT-LOCUS"
    if m = 0 then s!"{base} PROV-OWED]" else s!"{base} x{m}]"
  | .crossed _ => "[SEAL-LOCUS]"
  | .breach => "[X-LOCUS]"

def sealAscii : String := "[SEAL]"

theorem render_receipted :
    (Token.superHalt none none none 1).render = "[⬖₀ ×1]" ∧
    (Token.superHalt (some .xi) none none 1).render = "[⬖₀ · Ξ ×1]" ∧
    (Token.superHalt (some .o) none none 1).render = "[⬖₀ · Ø ×1]" ∧
    (Token.superHalt (some .xi) (some .hypothesis) (some .formal) 1).render
      = "[⬖₀ · Ξ · hypothesis · formal ×1]" ∧
    (Token.superHalt none none (some .formal) 6).render = "[⬖₀ · formal ×6]" ∧
    (Token.superHalt none none none 0).render = "[⬖₀ · provenance owed]" ∧
    (Token.superHalt none none (some .formal) 1).render = "[⬖₀ · formal ×1]" ∧
    (Token.superHalt (some .xi) none none 3).render = "[⬖₀ · Ξ ×3]" ∧
    (Token.crossed .kinetic).render = "[⟀⬖ · kinetic]" ∧
    (Token.crossed .formal).render = "[⟀⬖ · formal]" ∧
    Token.breach.render = "[X⬖ · mechanism]" ∧
    (Token.superHalt (some .xi) none none 1).ascii = "[HALT-LOCUS-XI x1]" ∧
    (Token.superHalt (some .xi) none none 3).ascii = "[HALT-LOCUS-XI x3]" ∧
    (Token.superHalt (some .o) none none 2).ascii = "[HALT-LOCUS-O x2]" ∧
    (Token.superHalt none none none 6).ascii = "[HALT-LOCUS x6]" ∧
    (Token.superHalt none none none 1).ascii = "[HALT-LOCUS x1]" ∧
    (Token.superHalt none none none 0).ascii = "[HALT-LOCUS PROV-OWED]" ∧
    (Token.crossed .formal).ascii = "[SEAL-LOCUS]" ∧
    Token.breach.ascii = "[X-LOCUS]" ∧
    sealAscii = "[SEAL]" := by decide

theorem render_injective_in_owed :
    ((List.range 13).all fun m => (List.range 13).all fun n =>
      (decide ((Token.superHalt none none none m).ascii = (Token.superHalt none none none n).ascii) == decide (m = n)) &&
      (decide ((Token.superHalt (some .xi) none none m).ascii = (Token.superHalt (some .xi) none none n).ascii) == decide (m = n)) &&
      (decide ((Token.superHalt none none (some .formal) m).render = (Token.superHalt none none (some .formal) n).render) == decide (m = n))) = true := by
  decide

#eval (Token.superHalt (some .xi) (some .hypothesis) (some .formal) 1).render
#eval (Token.superHalt none none (some .formal) 6).render
#eval (Token.crossed .kinetic).render
#eval Token.breach.render

def voidImage : Audit.Token := .opn
theorem void_precedes_economy : voidImage = .opn ∧ Audit.Token.void ≠ Audit.Token.refused := by decide

theorem legacy_records_not_promoted :
    HALT.rhHalt.species = .hypothesis ∧ HALT.pnpHalt.species = .blockTheorem ∧
    HALT.rhHalt.channel = .formal ∧ HALT.pnpHalt.channel = .formal := by decide

theorem no_rh_locus :
    emit ⟨false, true, some 1, some .hypothesis, some .formal, [none], by decide⟩
      = some (.superHalt (some .xi) (some .hypothesis) (some .formal) 1) := by decide

end LOCUS

namespace PSP.ORIENT

abbrev V3 := Ratio × Ratio × Ratio
abbrev M3 := V3 × V3 × V3

def det3 (m : M3) : Ratio :=
  m.1.1 * (m.2.1.2.1 * m.2.2.2.2 - m.2.1.2.2 * m.2.2.2.1)
  - m.1.2.1 * (m.2.1.1 * m.2.2.2.2 - m.2.1.2.2 * m.2.2.1)
  + m.1.2.2 * (m.2.1.1 * m.2.2.2.1 - m.2.1.2.1 * m.2.2.1)

def neg3 (m : M3) : M3 :=
  ((-m.1.1, -m.1.2.1, -m.1.2.2),
   (-m.2.1.1, -m.2.1.2.1, -m.2.1.2.2),
   (-m.2.2.1, -m.2.2.2.1, -m.2.2.2.2))

def signMatrices : List M3 :=
  [ (( 1,0,0),(0, 1,0),(0,0, 1)), ((-1,0,0),(0, 1,0),(0,0, 1)),
    (( 1,0,0),(0,-1,0),(0,0, 1)), (( 1,0,0),(0, 1,0),(0,0,-1)),
    ((-1,0,0),(0,-1,0),(0,0, 1)), ((-1,0,0),(0, 1,0),(0,0,-1)),
    (( 1,0,0),(0,-1,0),(0,0,-1)), ((-1,0,0),(0,-1,0),(0,0,-1)) ]

theorem lock_scalar_sign_blind :
    signMatrices.all (fun m =>
      det3 m * det3 m == det3 (neg3 m) * det3 (neg3 m)) = true := by decide

theorem det_sign_flips_in_odd_dimension :
    signMatrices.all (fun m => det3 (neg3 m) == -det3 m) = true := by decide

end PSP.ORIENT

namespace PSP.QUAT

abbrev Q := Ratio × Ratio × Ratio × Ratio   

def qmul (p q : Q) : Q :=
  (p.1*q.1 - p.2.1*q.2.1 - p.2.2.1*q.2.2.1 - p.2.2.2*q.2.2.2,
   p.1*q.2.1 + p.2.1*q.1 + p.2.2.1*q.2.2.2 - p.2.2.2*q.2.2.1,
   p.1*q.2.2.1 - p.2.1*q.2.2.2 + p.2.2.1*q.1 + p.2.2.2*q.2.1,
   p.1*q.2.2.2 + p.2.1*q.2.2.1 - p.2.2.1*q.2.1 + p.2.2.2*q.1)

def qi : Q := (0,1,0,0)
def qj : Q := (0,0,1,0)
def qk : Q := (0,0,0,1)
def qneg1 : Q := (-1,0,0,0)

theorem quat_basis_laws :
    qmul qi qi = qneg1 ∧ qmul qj qj = qneg1 ∧ qmul qk qk = qneg1 ∧
    qmul (qmul qi qj) qk = qneg1 := by decide

end PSP.QUAT

namespace PSP.QUAT

def qnorm (p : Q) : Ratio := p.1^2 + p.2.1^2 + p.2.2.1^2 + p.2.2.2^2
def isInt (r : Ratio) : Bool := r.den == 1
def isHalf (r : Ratio) : Bool := r.den == 2
def hurwitzOK (p : Q) : Bool :=
  (isInt p.1 && isInt p.2.1 && isInt p.2.2.1 && isInt p.2.2.2) ||
  (isHalf p.1 && isHalf p.2.1 && isHalf p.2.2.1 && isHalf p.2.2.2)

def grid : List Ratio := [-1, -1/2, 0, 1/2, 1]
def tuples4 : List Q :=
  grid.flatMap fun a => grid.flatMap fun b =>
    grid.flatMap fun c => grid.map fun d => (a,b,c,d)

theorem hurwitz_units_24 :
    (tuples4.filter fun p => hurwitzOK p && qnorm p == 1).length = 24 := by decide

end PSP.QUAT

namespace PSP.QUAT

def grid2 : List Ratio := [-2, -1, 0, 1, 2]
def tuples4i : List Q :=
  grid2.flatMap fun a => grid2.flatMap fun b =>
    grid2.flatMap fun c => grid2.map fun d => (a,b,c,d)

theorem norm2_shell_split :
    (tuples4i.filter fun p => qnorm p == 2).length = 24 ∧
    (tuples4i.filter fun p => qnorm p == 2 && p.1 == 0).length = 12 ∧
    (tuples4i.filter fun p => qnorm p == 2 && p.1 != 0).length = 12 := by decide

end PSP.QUAT

namespace PSP.CD

def cdconj : List Ratio → List Ratio
  | [] => []
  | [a] => [a]
  | a :: rest => a :: rest.map (fun x => -x)

def padd : List Ratio → List Ratio → List Ratio := List.zipWith (· + ·)
def psub : List Ratio → List Ratio → List Ratio := List.zipWith (· - ·)

def cdmul : Nat → List Ratio → List Ratio → List Ratio
  | 0, _, _ => []
  | _+1, [a], [b] => [a * b]
  | fuel+1, a, b =>
      let n := a.length / 2
      let a1 := a.take n; let a2 := a.drop n
      let b1 := b.take n; let b2 := b.drop n
      psub (cdmul fuel a1 b1) (cdmul fuel (cdconj b2) a2) ++
      padd (cdmul fuel b2 a1) (cdmul fuel a2 (cdconj b1))

def e (n i : Nat) : List Ratio := List.replicate i 0 ++ [1] ++ List.replicate (n - i - 1) 0
def smul (s : Ratio) (v : List Ratio) : List Ratio := v.map (fun x => s * x)

theorem octonion_associator :
    psub (cdmul 4 (cdmul 4 (e 8 1) (e 8 2)) (e 8 4))
         (cdmul 4 (e 8 1) (cdmul 4 (e 8 2) (e 8 4)))
    = smul 2 (e 8 7) := by decide

end PSP.CD

namespace PSP.CD

def sx : List Ratio := padd (e 16 1) (e 16 10)

def sy : List Ratio := padd (e 16 5) (e 16 14)
def zero16 : List Ratio := List.replicate 16 0
def sqnorm (v : List Ratio) : Ratio := (v.map fun x => x^2).sum

theorem sedenion_zero_divisor :
    cdmul 5 sx sy = zero16 ∧ sx ≠ zero16 ∧ sy ≠ zero16
    ∧ sqnorm sx = 2 ∧ sqnorm sy = 2 := by decide

end PSP.CD

namespace PSP.CASCADE

def cascade : List Bool → Option Nat
  | [] => none
  | false :: _ => some 0
  | true :: gs => (cascade gs).map Nat.succ

def patterns8 : List (List Bool) :=
  (List.range 256).map fun b => (List.range 8).map fun j => b.testBit j

def spec (bits : List Bool) : Bool :=
  match cascade bits with
  | none => bits.all id
  | some k => (bits.take k).all id && (bits[k]? == some false)

theorem first_failure_terminal_8 :
    patterns8.all spec = true := by decide

theorem halt_free_iff_all_pass_8 :
    patterns8.all (fun bits => (cascade bits).isNone == bits.all id) = true := by decide

end PSP.CASCADE

namespace PSP.GROUNDLESS

def o0Neighbors : List String :=
  ["sigma-token", "dissolve-openness", "ordinary-openness",
   "resolved-states", "broken-or-ghost"]

def fiveCubeCoords : List String :=
  ["Ground-dimension", "determinacy", "blockage", "aperture", "totality"]

def deg5 (v : Nat) : Nat :=
  ((List.range 5).map fun j => v ^^^ (1 <<< j)).eraseDups.length

theorem groundless_cascade_degree :
    o0Neighbors.length = 5 ∧ fiveCubeCoords.length = 5 ∧
    o0Neighbors.length ≠ 7 ∧ o0Neighbors.length ≠ 8 ∧
    (List.range 32).all (fun v => deg5 v == 5) = true := by decide

end PSP.GROUNDLESS

namespace PSP.TOKEN

inductive TerminalToken | xi0 | o0 deriving DecidableEq

def level : TerminalToken → Nat := fun _ => 3

theorem terminal_tokens_level_and_distinct :
    level TerminalToken.xi0 = level TerminalToken.o0 ∧
    TerminalToken.xi0 ≠ TerminalToken.o0 := ⟨rfl, by decide⟩

end PSP.TOKEN

namespace PSP.TWOGROUP

theorem two_group_census :
    Nat.factorial 4 / 2 = 12 ∧ 2^3 = 8 := by decide

end PSP.TWOGROUP
