module twin_apex
  ! THE SEAT ANCHOR, EXECUTED. The finite content of the Lean layer APEX and PNF, re-executed by enumeration:
  ! the seat, the Return, the cone, the embedding, the occupancy law over every involution on six points, the
  ! complementation vacancy, the rival involution, the premise and the cure, the twenty-three rows with their two
  ! lines, and the Parity Normal Form with the Width Law. Every assert reads a computed quantity; every battery
  ! prints what it enumerated. Delta-M = 0.
  use twin_kinds
  use twin_battery
  use twin_omega, only: landauer_scaled
  use twin_locus, only: emit, render, to_economy, T_SUPERHALT, T_CROSSED, B_XI, B_O, B_NONE, C_FORMAL, &
       E_SEALED, E_OPN
  implicit none
  private
  public :: run_apex
  integer, parameter :: R = 6, W = 8
  ! the codex token vocabulary, as Audit.Token orders it
  integer, parameter :: TK_SEALED = 1, TK_OPN = 3, TK_VOID = 9, TK_AGIVENRA = 10
  ! the RA row cascade verdicts, as GEO.RAVerdict orders them
  integer, parameter :: RV_REFUSED = 1, RV_III = 2, RV_II = 3, RV_VOID = 4, RV_AGIVENRA = 5
contains

  pure function qmul(a, b) result(c)
    integer, intent(in) :: a(4), b(4)
    integer :: c(4)
    c(1) = a(1)*b(1) - a(2)*b(2) - a(3)*b(3) - a(4)*b(4)
    c(2) = a(1)*b(2) + a(2)*b(1) + a(3)*b(4) - a(4)*b(3)
    c(3) = a(1)*b(3) - a(2)*b(4) + a(3)*b(1) + a(4)*b(2)
    c(4) = a(1)*b(4) + a(2)*b(3) - a(3)*b(2) + a(4)*b(1)
  end function qmul

  pure function sig(a) result(c)
    integer, intent(in) :: a(4)
    integer :: c(4)
    c = [a(1), -a(2), -a(3), -a(4)]
  end function sig

  pure function sigp(a) result(c)
    integer, intent(in) :: a(4)
    integer :: c(4)
    c = [a(2), a(1), -a(3), -a(4)]
  end function sigp

  ! phi_m(h, t) = <t, h - m, 0, 0>, the embedding of the stage at resolution m
  pure function phim(m, h, t) result(c)
    integer, intent(in) :: m, h, t
    integer :: c(4)
    c = [t, h - m, 0, 0]
  end function phim

  pure function proj(a) result(c)
    integer, intent(in) :: a(4)
    integer :: c(4)
    c = [a(1), 0, 0, 0]
  end function proj

  ! GEO.rowCascadeRACore, mirrored
  pure integer function cascade_ra(nonvac, velive, fwd, pop, worldly, tclosed, tworldly, fclosed, annot)
    logical, intent(in) :: nonvac, velive, fwd, pop, worldly, tclosed, tworldly, fclosed, annot
    if (.not. nonvac) then
       cascade_ra = RV_REFUSED
    else if (velive .or. fwd) then
       cascade_ra = RV_III
    else if (.not. pop) then
       cascade_ra = RV_II
    else if (worldly) then
       cascade_ra = RV_III
    else if (.not. tclosed) then
       if (tworldly) then
          cascade_ra = RV_III
       else
          cascade_ra = RV_II
       end if
    else if (.not. fclosed) then
       cascade_ra = RV_III
    else if (.not. annot) then
       cascade_ra = RV_VOID
    else
       cascade_ra = RV_AGIVENRA
    end if
  end function cascade_ra

  ! GEO.RAVerdict.toToken, mirrored: refused, determined, determined, void, aGivenRA
  pure integer function rv_token(v)
    integer, intent(in) :: v
    select case (v)
    case (RV_REFUSED);  rv_token = 4
    case (RV_III);      rv_token = 5
    case (RV_II);       rv_token = 5
    case (RV_VOID);     rv_token = TK_VOID
    case default;       rv_token = TK_AGIVENRA
    end select
  end function rv_token

  subroutine run_apex()
    call section('SECTION 20 · THE SEAT ANCHOR: the seat, the cone, the occupancy law, the two lines of every row')
    call a1_seat()
    call a2_return()
    call a3_cone()
    call a4_embedding()
    call a5_occupancy()
    call a6_complement()
    call a7_rival()
    call a8_premise_cure()
    call a9_rows()
    call a10_pnf()
  end subroutine run_apex

  subroutine a1_seat()
    integer :: r0, i0, j0, k0, nfix, bad, q(4)
    nfix = 0; bad = 0
    do r0 = -R, R; do i0 = -R, R; do j0 = -R, R; do k0 = -R, R
       q = [r0, i0, j0, k0]
       if (any(sig(sig(q)) /= q)) bad = bad + 1
       if ((all(sig(q) == q)) .neqv. (i0 == 0 .and. j0 == 0 .and. k0 == 0)) bad = bad + 1
       if (all(sig(q) == q)) nfix = nfix + 1
    end do; end do; end do; end do
    write(*,'(A,I0,A,I0)') '   A1 ball points ', (2*R+1)**4, ', fixed by sigma ', nfix
    call assert(bad == 0, 'A1 sigma binding and fixed iff scalar on every point of the ball')
    call assert(nfix == 2*R+1, 'A1 the seat in the ball is the scalar line: 13 points')
  end subroutine a1_seat

  subroutine a2_return()
    integer :: e(4,3), p(3,6), s, k, q(4), ret(4), odd(4)
    logical :: even
    e = 0; e(2,1) = 1; e(3,2) = 1; e(4,3) = 1
    p = reshape([1,2,3, 2,3,1, 3,1,2, 2,1,3, 1,3,2, 3,2,1], [3,6])
    s = 0
    do k = 1, 6
       q = qmul(qmul(e(:,p(1,k)), e(:,p(2,k))), e(:,p(3,k)))
       even = (k <= 3)
       if (even .and. all(q == [-1,0,0,0])) s = s + 1
       if ((.not. even) .and. all(q == [1,0,0,0])) s = s + 1
    end do
    ret = qmul(qmul(e(:,1), e(:,2)), e(:,3))
    odd = qmul(qmul(e(:,3), e(:,2)), e(:,1))
    call assert(s == 6, 'A2 six orderings: the three even land at -1, the three odd at +1')
    call assert(all(ret == [-1,0,0,0]) .and. all(sig(ret) == ret), 'A2 the Return is -1 and lies on the seat')
    call assert(all(odd == [1,0,0,0]) .and. all(sig(odd) == odd) .and. any(odd /= ret), &
         'A2 the reversed triad is +1, on the seat, and differs')
  end subroutine a2_return

  subroutine a3_cone()
    integer :: e(4,3), gra(4), gram(4), grh(4), odd(4), a(4), r0, i0, j0, k0, n1, n2
    e = 0; e(2,1) = 1; e(3,2) = 1; e(4,3) = 1
    gra = qmul(qmul(e(:,1), e(:,2)), e(:,3)); gram = proj(gra); grh = [-1,0,0,0]
    odd = qmul(qmul(e(:,3), e(:,2)), e(:,1))
    call assert(all(sig(gra) == gra) .and. all(gra == gram) .and. all(gram == grh), &
         'A3 the three gaps are identities: gap vector (0,0,0)')
    n1 = 0; n2 = 0
    do r0 = -R, R; do i0 = -R, R; do j0 = -R, R; do k0 = -R, R
       a = [r0, i0, j0, k0]
       if (all(a == gra) .and. all(a == gram) .and. all(a == grh)) n1 = n1 + 1
       if (all(a == odd) .and. all(a == proj(odd)) .and. all(a == [1,0,0,0])) n2 = n2 + 1
    end do; end do; end do; end do
    write(*,'(A,I0,A,I0)') '   A3 apexes over the ordered diagram ', n1, ', over the reversed ', n2
    call assert(n1 == 1 .and. n2 == 1, 'A3 exactly one apex per orientation over the ball')
  end subroutine a3_cone

  subroutine a4_embedding()
    integer :: m, h, t, h2, t2, nline, nhit, bad, p(4)
    bad = 0
    do m = -3, 3
       nline = 0; nhit = 0
       do h = -W, W; do t = -W, W
          p = phim(m, h, t)
          if (any(sig(p) /= phim(m, 2*m - h, t))) bad = bad + 1
          if ((all(sig(p) == p)) .neqv. (2*m - h == h)) bad = bad + 1
          if (2*m - h == h) nline = nline + 1
          do h2 = -W, W; do t2 = -W, W
             if (all(phim(m, h2, t2) == p)) then
                nhit = nhit + 1
                if (h2 /= h .or. t2 /= t) bad = bad + 1
             end if
          end do; end do
       end do; end do
       if (nline /= 2*W + 1 .or. nhit /= (2*W + 1)**2) bad = bad + 1
    end do
    write(*,'(A,I0,A)') '   A4 seven resolutions, ', (2*W+1)**2, ' stage points each: equivariance, image clause, injectivity'
    call assert(bad == 0, 'A4 phi_m equivariant, fixed iff on the line, injective, 17 line points, at m = -3..3')
    p = qmul(qmul([0,1,0,0], [0,0,1,0]), [0,0,0,1])
    call assert(all(phim(1, 1, -1) == proj(p)), 'A4 phi(1,-1) is the named seat point, the Return projected')
  end subroutine a4_embedding

  ! THE OCCUPANCY LAW over every involution on 1 to 6 points and every map into a nine-point window of the carrier,
  ! (r, i) in {-1,0,1}^2 with j = k = 0; a window point is on the seat iff i = 0.
  subroutine a5_occupancy()
    integer :: n, tcode, c, pw, p, d, f, ninv, ntot, nadm, bad, fpf, neq, badeq, digit(6), tau(6), expect, m
    logical :: isinv, grounded, occ, img, eqv, inj
    integer :: eqcount(3)
    ntot = 0; bad = 0; badeq = 0; eqcount = 0
    do n = 1, 6
       ninv = 0
       do tcode = 0, n**n - 1
          do p = 1, n
             tau(p) = mod(tcode / n**(p-1), n) + 1
          end do
          isinv = .true.
          do p = 1, n
             if (tau(tau(p)) /= p) isinv = .false.
          end do
          if (.not. isinv) cycle
          ninv = ninv + 1
          f = count([(tau(p) == p, p = 1, n)])
          grounded = (f > 0)
          nadm = 0; neq = 0
          pw = 9**n
          do c = 0, pw - 1
             do p = 1, n
                digit(p) = mod(c / 9**(p-1), 9)
             end do
             img = .true.; occ = .false.
             do p = 1, n
                ! window point (r, i) = (digit/3 - 1, mod(digit,3) - 1); on the seat iff i = 0
                if ((mod(digit(p), 3) == 1) .neqv. (tau(p) == p)) img = .false.
                if (mod(digit(p), 3) == 1) occ = .true.
             end do
             if (img) then
                nadm = nadm + 1
                if (occ .neqv. grounded) bad = bad + 1
             end if
             if (.not. grounded) then
                eqv = .true.; inj = .true.
                do p = 1, n
                   d = 3*(digit(p)/3) + (2 - mod(digit(p), 3))     ! sigma on the window
                   if (d /= digit(tau(p))) eqv = .false.
                   do m = p + 1, n
                      if (digit(m) == digit(p)) inj = .false.
                   end do
                end do
                if (eqv .and. inj) then
                   neq = neq + 1
                   if (occ) badeq = badeq + 1
                end if
             end if
          end do
          expect = 3**f * 6**(n - f)
          if (nadm /= expect .or. nadm == 0) bad = bad + 1
          if (.not. grounded) then
             fpf = n / 2
             eqcount(fpf) = neq
          end if
       end do
       ntot = ntot + ninv
    end do
    write(*,'(A,I0,A)') '   A5 involutions on 1..6 points: ', ntot, '; admissible maps counted as 3^f 6^(n-f) on each'
    write(*,'(A,3I4)') '   A5 equivariant injective bridges of the fixed-point-free involutions on 2, 4, 6 points: ', eqcount
    call assert(ntot == 119, 'A5 one hundred nineteen involutions enumerated')
    call assert(bad == 0, 'A5 occupancy law: under every image-clause bridge, occupied iff grounded')
    call assert(badeq == 0 .and. all(eqcount == [6, 24, 48]), &
         'A5 vacancy by equivariance and injectivity alone: 6, 24, 48 bridges, none on the seat')
  end subroutine a5_occupancy

  subroutine a6_complement()
    integer :: m, f, full, bad, b, pb(4), pc(4)
    bad = 0
    do m = 1, 3
       full = 2**m - 1
       do f = 0, full
          if (ieor(f, full) == f) bad = bad + 1
       end do
    end do
    call assert(bad == 0, 'A6 complementation fixes no Boolean function on domains of 1, 2, 3 points')
    bad = 0
    do b = 0, 1
       pb = [0, merge(1, -1, b == 1), 0, 0]
       pc = [0, merge(1, -1, b == 0), 0, 0]
       if (any(sig(pb) /= pc)) bad = bad + 1
       if (all(sig(pb) == pb)) bad = bad + 1
    end do
    call assert(bad == 0, 'A6 the complexity bridge exists, is equivariant, and lands off the seat')
  end subroutine a6_complement

  subroutine a7_rival()
    integer :: r0, i0, j0, k0, nfixp, nboth, bad, q(4)
    nfixp = 0; nboth = 0; bad = 0
    do r0 = -R, R; do i0 = -R, R; do j0 = -R, R; do k0 = -R, R
       q = [r0, i0, j0, k0]
       if (any(sigp(sigp(q)) /= q)) bad = bad + 1
       if (all(sigp(q) == q)) nfixp = nfixp + 1
       if (all(sigp(q) == q) .and. all(sig(q) == q)) nboth = nboth + 1
    end do; end do; end do; end do
    write(*,'(A,I0,A,I0)') '   A7 rival involution: fixed line of 13 expected, found ', nfixp, '; meeting points ', nboth
    call assert(bad == 0 .and. nfixp == 2*R+1, 'A7 sigmaP is binding and fixes the line r = i')
    call assert(nboth == 1, 'A7 the two seats meet only at the origin')
    call assert(any(sigp([-1,0,0,0]) /= [-1,0,0,0]), 'A7 the rival moves the kinetic seat point: the leg rides one involution')
  end subroutine a7_rival

  subroutine a8_premise_cure()
    integer :: tau(3,4), t, z, s, nfr, nl, nfail, ngr, bad, frames(2,6), nf2, cls, ncured, k
    logical :: sym, lprop, grnd, prem, allimp, alll
    tau = reshape([1,2,3, 2,1,3, 3,2,1, 1,3,2], [3,4])
    prem = .true.
    nfr = 0; nl = 0; nfail = 0; ngr = 0; bad = 0
    do t = 1, 4
       do z = 0, 7
          sym = .true.; lprop = .true.; grnd = .false.
          do s = 1, 3
             if (btest(z, s-1) .and. .not. btest(z, tau(s,t)-1)) sym = .false.
             if (btest(z, s-1) .and. tau(s,t) /= s) lprop = .false.
             if (tau(s,t) == s) grnd = .true.
          end do
          if (.not. sym) cycle
          nfr = nfr + 1
          if (((.not. prem) .or. lprop) .neqv. lprop) bad = bad + 1
          if (lprop) then
             nl = nl + 1
          else
             nfail = nfail + 1
             if (grnd) ngr = ngr + 1
          end if
       end do
    end do
    write(*,'(A,I0,A,I0,A,I0,A,I0)') '   A8 three-point frames with symmetric zeros ', nfr, ': L holds ', nl, &
         ', fails ', nfail, ', grounded counter-models ', ngr
    call assert(bad == 0 .and. nfr == 20 .and. nl == 14 .and. nfail == 6, &
         'A8 the rule is exact on every frame; twenty frames, fourteen on the line, six off')
    call assert(ngr == nfail, 'A8 every counter-model is grounded: the bound needs no seatless frame')
    ! two-point frames with symmetric zeros: identity with any zero set, the swap with none or both
    nf2 = 0
    do t = 0, 1
       do z = 0, 3
          if (t == 1 .and. .not. (z == 0 .or. z == 3)) cycle
          nf2 = nf2 + 1
          frames(1, nf2) = t; frames(2, nf2) = z
       end do
    end do
    ncured = 0
    do cls = 0, 2**nf2 - 1
       allimp = .true.; alll = .true.
       do k = 1, nf2
          if (.not. btest(cls, k-1)) cycle
          lprop = .not. (frames(1,k) == 1 .and. frames(2,k) /= 0)
          if (.not. ((.not. prem) .or. lprop)) allimp = .false.
          if (.not. lprop) alll = .false.
       end do
       if (allimp .neqv. alll) bad = bad + 1
       if (allimp) ncured = ncured + 1
    end do
    write(*,'(A,I0,A,I0)') '   A8 two-point frame classes ', 2**nf2, ': cured ', ncured
    call assert(bad == 0 .and. nf2 == 6 .and. ncured == 32, &
         'A8 the cure theorem: a class is cured iff L already holds on it, 32 of 64')
  end subroutine a8_premise_cure

  subroutine a9_rows()
    character(len=26) :: nm(23)
    integer :: typing(23), gd(23), nsup(23), leg(23), census(8), k, tok, br, chn, mult, owed, ncross, bad
    integer :: nleg(3), led(5), n, v, seat_rv, value_rv, void_rv, seattok, valtok
    character(len=40) :: rr
    integer(i16) :: p22, p1
    nm = [character(len=26) :: 'P versus NP', 'Riemann Hypothesis', 'Navier-Stokes', 'Yang-Mills', 'Hodge', 'BSD', &
         'Poincare', 'Goldbach', 'Twin primes', 'Legendre', 'abc', 'Jacobian', 'Mersenne primes', &
         'Odd perfect numbers', 'Smooth 4D Poincare', 'Collatz', 'Hadwiger', 'Sunflower', 'Erdos-Straus', 'Beal', &
         'Invariant subspace', 'Hilbert 16 second part', 'Lindelof / Montgomery PCC']
    typing = [1,1,2,2,2,3,4, 1,1,1,1,1, 5,5,5, 6, 7,7,7,7, 8,8,8]
    gd = -1; gd(1) = 0; gd(2) = 1
    nsup = 0; nsup(7) = 1
    leg = 3; leg(2) = 1; leg(1) = 2
    census = 0
    do k = 1, 23
       census(typing(k)) = census(typing(k)) + 1
    end do
    call assert(all(census == [7,3,1,1,3,1,4,3]), 'A9 the world census 7, 3, 1, 1, 3, 1, 4, 3')
    ! the RA cascade, its 512-input ledger against the kernel's GEO.ra_ledger theorems
    led = 0
    do n = 0, 511
       v = cascade_ra(btest(n,8), btest(n,7), btest(n,6), btest(n,5), btest(n,4), btest(n,3), btest(n,2), &
            btest(n,1), btest(n,0))
       led(v) = led(v) + 1
    end do
    call assert(all(led == [256, 216, 36, 2, 2]), 'A9 the RA cascade ledger: 256 refused, 216 III, 36 II, 2 void, 2 A|RA')
    seat_rv  = cascade_ra(.true., .false., .false., .true., .false., .true., .false., .true., .true.)
    value_rv = cascade_ra(.true., .false., .false., .true., .true., .true., .false., .true., .true.)
    void_rv  = cascade_ra(.true., .false., .false., .true., .false., .true., .false., .true., .false.)
    call assert(seat_rv == RV_AGIVENRA .and. value_rv == RV_III .and. void_rv == RV_VOID, &
         'A9 the seat line is compartment I, the value line III, and the seat line without its rider is void')
    seattok = rv_token(seat_rv)
    owed = 0; ncross = 0; bad = 0; nleg = 0
    do k = 1, 23
       call emit(.false., .true., gd(k), C_FORMAL, nsup(k), 1, tok, br, chn, mult)
       rr = render(tok, br, mult)
       owed = owed + mult
       if (tok == T_CROSSED) ncross = ncross + 1
       if (tok == T_CROSSED .neqv. k == 7) bad = bad + 1
       select case (k)
       case (1); if (trim(rr) /= '[HALT-LOCUS-O x1]') bad = bad + 1
       case (2); if (trim(rr) /= '[HALT-LOCUS-XI x1]') bad = bad + 1
       case (7); if (trim(rr) /= '[SEAL-LOCUS]') bad = bad + 1
       case default; if (trim(rr) /= '[HALT-LOCUS x1]') bad = bad + 1
       end select
       if (to_economy(tok) == E_SEALED) then
          valtok = TK_SEALED
       else if (to_economy(tok) == E_OPN) then
          valtok = TK_OPN
       else
          valtok = 0
       end if
       if (seattok == valtok) bad = bad + 1
       nleg(leg(k)) = nleg(leg(k)) + 1
       if (k <= 2 .or. k == 7) write(*,'(A,A26,A,A,A)') '   A9 ', nm(k), '  seat [A|RA]  value ', trim(rr), ''
    end do
    call assert(bad == 0, 'A9 every value line rendered as the kernel emits it, and parted from the seat line on every row')
    call assert(owed == 22 .and. ncross == 1, 'A9 twenty-two bits owed, one crossing, the Poincare row')
    call assert(all(nleg == [1, 1, 21]), 'A9 object legs: one bridged on the stage, one vacant by theorem, twenty-one owed')
    p1 = landauer_scaled(300, 1); p22 = landauer_scaled(300, owed)
    write(*,'(A,I0,A)') '   A9 price of the owed bits at 300 K: ', p22, ' x 10^-45 J'
    call assert(p22 == 22_i16 * p1 .and. p22 > 0_i16, 'A9 the owed bits are priced at twenty-two exact floors')
  end subroutine a9_rows

  subroutine a10_pnf()
    integer :: k, msk, i, cnt, cnts(6), m, nf, full, a, d, e, e2, npair, bad, ok_l, ok_r
    integer :: npt, nb, rcode, dcode, ntau, tcode, p, g, nbar, pairs, x, y
    integer :: rho(4), dd(4), tau(4)
    logical :: wo, lhs, rhs, fac, pb, sep, isinv, heven, flip, found
    ! the unconstrained odd family on k orbits is 2^k wide
    do k = 1, 6
       cnt = 0
       do msk = 0, 2**(2*k) - 1
          wo = .true.
          do i = 0, k - 1
             if (btest(msk, 2*i) .eqv. btest(msk, 2*i+1)) wo = .false.
          end do
          if (wo) cnt = cnt + 1
       end do
       cnts(k) = cnt
    end do
    write(*,'(A,6I4)') '   A10 wholly odd targets on k = 1..6 orbits: ', cnts
    call assert(all(cnts == [2, 4, 8, 16, 32, 64]), 'A10 the odd family on k orbits is 2^k: six bits at the census frame')
    ! the Width Law on every family of Boolean functions over two and three points
    bad = 0
    do m = 2, 3
       nf = 2**m; full = nf - 1; npair = 0
       do a = 1, 2**nf - 1
          do d = 0, nf - 1
             if (.not. btest(a, d)) cycle
             ok_l = 1
             do e = 0, nf - 1
                if (.not. btest(a, e)) cycle
                if (.not. btest(a, ieor(e, full))) ok_l = 0
                do e2 = 0, nf - 1
                   if (.not. btest(a, e2)) cycle
                   if (e2 /= e .and. e2 /= ieor(e, full)) ok_l = 0
                end do
             end do
             ok_r = 0
             if (a == ior(ishft(1, d), ishft(1, ieor(d, full)))) ok_r = 1
             lhs = (ok_l == 1); rhs = (ok_r == 1)
             if (lhs .neqv. rhs) bad = bad + 1
             if (rhs) npair = npair + 1
          end do
       end do
       if (npair /= nf) bad = bad + 1
    end do
    call assert(bad == 0, 'A10 the Width Law: one bit wide iff the admissible family is a complement pair, every family')
    ! the barrier criterion and the parity normal form on three and four points
    bad = 0; nbar = 0; pairs = 0
    do npt = 3, 4
       nb = npt - 1
       do rcode = 0, nb**npt - 1
          do p = 1, npt
             rho(p) = mod(rcode / nb**(p-1), nb)
          end do
          do dcode = 0, 2**npt - 1
             pairs = pairs + 1
             do p = 1, npt
                dd(p) = merge(1, 0, btest(dcode, p-1))
             end do
             fac = .false.
             do g = 0, 2**nb - 1
                found = .true.
                do p = 1, npt
                   if (merge(1, 0, btest(g, rho(p))) /= dd(p)) found = .false.
                end do
                if (found) fac = .true.
             end do
             sep = .false.
             do x = 1, npt
                do y = 1, npt
                   if (rho(x) == rho(y) .and. dd(x) /= dd(y)) sep = .true.
                end do
             end do
             pb = .false.; ntau = 0
             do tcode = 0, npt**npt - 1
                do p = 1, npt
                   tau(p) = mod(tcode / npt**(p-1), npt) + 1
                end do
                isinv = .true.; heven = .true.; flip = .false.
                do p = 1, npt
                   if (tau(tau(p)) /= p) isinv = .false.
                   if (rho(tau(p)) /= rho(p)) heven = .false.
                   if (dd(tau(p)) /= dd(p)) flip = .true.
                end do
                if (isinv) ntau = ntau + 1
                if (isinv .and. heven .and. flip) pb = .true.
             end do
             if (npt == 3 .and. ntau /= 4) bad = bad + 1
             if (npt == 4 .and. ntau /= 10) bad = bad + 1
             if (((.not. fac) .neqv. pb) .or. (pb .neqv. sep)) bad = bad + 1
             if (pb) nbar = nbar + 1
          end do
       end do
    end do
    write(*,'(A,I0,A,I0)') '   A10 record-target pairs on three and four points ', pairs, ', barriers ', nbar
    call assert(bad == 0 .and. nbar > 0, &
         'A10 the parity normal form: unreadable iff a record-even involution flips the target iff a pair separates')
  end subroutine a10_pnf

end module twin_apex
