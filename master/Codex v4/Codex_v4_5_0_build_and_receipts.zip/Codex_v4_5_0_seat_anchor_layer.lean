/-!
# THE SEAT ANCHOR · the apex layer of the rows, carried in the Code Block
core Lean 4 v4.19.0 · no Mathlib · no sorry · no axiom declared.
Every row carries two objects parted by theorem: its seat, the row read as the fixed locus of a binding involution, and
its value, the row's proposition. This layer proves the seat line on every row, the occupancy law that reads the router
bit at the seat, the vacancy of the complexity seat, the one-involution rider on the register leg, the rule and its
bound, the cure theorem, and the parting of the two lines, reusing GEO, Bridge, CROSSING, LOCUS, HALT, OMEGA and FOUND.
The Parity Normal Form enters in its list edition, choice-free. ΔM = 0: every step is classical and elementary.
-/

/-! ## PNF · the Parity Normal Form and the Width Law, list edition -/
namespace PNF
open LOCUS

/-- A parity barrier: an involution that fixes the record and flips the target somewhere. -/
def ParityBarrier {α β : Type} (ρ : α → β) (d : α → Bool) : Prop :=
  ∃ τ : α → α, (∀ z, τ (τ z) = z) ∧ (∀ z, ρ (τ z) = ρ z) ∧ ∃ x, d (τ x) ≠ d x

/-- Every parity barrier separates a pair. -/
theorem sep_of_parity {α β : Type} {ρ : α → β} {d : α → Bool} :
    ParityBarrier ρ d → Separates ρ d := by
  intro ⟨τ, _, hρ, x, hx⟩
  exact ⟨τ x, x, hρ x, hx⟩

/-- Every separated pair is a parity barrier: the swap of the pair, resident at `LOCUS.seat_of_sep`. -/
theorem parity_of_sep {α β : Type} [DecidableEq α] {ρ : α → β} {d : α → Bool} :
    Separates ρ d → ParityBarrier ρ d := by
  intro ⟨x, y, hρ, hd⟩
  obtain ⟨τ, hinv, heven, hflip⟩ := seat_of_sep hρ hd
  refine ⟨τ, hinv, heven, x, ?_⟩
  rw [hflip]
  cases d x <;> decide

/-- Separation, checked on a complete enumeration of the carrier. -/
def sepCheck {α β : Type} [DecidableEq β] (xs : List α) (ρ : α → β) (d : α → Bool) : Bool :=
  xs.any fun x => xs.any fun y => decide (ρ x = ρ y) && (d x != d y)

theorem sepCheck_iff {α β : Type} [DecidableEq β] (xs : List α) (hxs : ∀ z, z ∈ xs)
    (ρ : α → β) (d : α → Bool) : sepCheck xs ρ d = true ↔ Separates ρ d := by
  unfold sepCheck Separates
  constructor
  · intro h
    obtain ⟨x, -, hx⟩ := List.any_eq_true.mp h
    obtain ⟨y, -, hy⟩ := List.any_eq_true.mp hx
    simp only [Bool.and_eq_true, decide_eq_true_eq, bne_iff_ne, ne_eq] at hy
    exact ⟨x, y, hy.1, hy.2⟩
  · intro ⟨x, y, hρ, hd⟩
    apply List.any_eq_true.mpr
    refine ⟨x, hxs x, ?_⟩
    apply List.any_eq_true.mpr
    refine ⟨y, hxs y, ?_⟩
    simp only [Bool.and_eq_true, decide_eq_true_eq, bne_iff_ne, ne_eq]
    exact ⟨hρ, hd⟩

/-- THE PARITY NORMAL FORM, list edition: on an enumerated carrier, a target is unreadable from a record iff an
    involution fixes the record and flips the target. No choice is used. -/
theorem parity_normal_form_list {α β : Type} [DecidableEq α] [DecidableEq β]
    (xs : List α) (hxs : ∀ z, z ∈ xs) (ρ : α → β) (d : α → Bool) :
    ¬ Factors ρ d ↔ ParityBarrier ρ d := by
  constructor
  · intro h
    apply parity_of_sep
    cases hc : sepCheck xs ρ d with
    | true => exact (sepCheck_iff xs hxs ρ d).mp hc
    | false =>
      exfalso
      apply h
      apply factors_of_not_sep_list xs hxs ρ d
      intro hs
      have hs' := (sepCheck_iff xs hxs ρ d).mpr hs
      rw [hc] at hs'
      exact Bool.noConfusion hs'
  · intro hp hf
    exact wall_of_sep (sep_of_parity hp) hf

def shift {α : Type} (d : α → Bool) (c : Bool) : α → Bool := fun x => xor (d x) c

theorem shift_false {α : Type} (d : α → Bool) : shift d false = d := by
  funext x; simp [shift]

theorem shift_true {α : Type} (d : α → Bool) : shift d true = fun x => !d x := by
  funext x; simp [shift]

/-- The complement pair of d. -/
def ComplementPair {α : Type} (d e : α → Bool) : Prop := e = d ∨ e = fun x => !d x

/-- On a nonempty domain the complement pair is exactly the image of one bit, the bit unique. -/
theorem complement_pair_is_one_bit {α : Type} (d : α → Bool) (x₀ : α) :
    (∀ e, ComplementPair d e ↔ ∃ c, e = shift d c) ∧
    (∀ c₁ c₂, shift d c₁ = shift d c₂ → c₁ = c₂) := by
  refine ⟨fun e => ⟨?_, ?_⟩, ?_⟩
  · intro h; cases h with
    | inl h => exact ⟨false, by rw [h, shift_false]⟩
    | inr h => exact ⟨true, by rw [h, shift_true]⟩
  · intro ⟨c, hc⟩; cases c
    · exact Or.inl (by rw [hc, shift_false])
    · exact Or.inr (by rw [hc, shift_true])
  · intro c₁ c₂ h
    have := congrFun h x₀
    simp only [shift] at this
    cases hd : d x₀ <;> cases c₁ <;> cases c₂ <;> simp_all

/-- The two members of the pair differ: the width is one bit and not zero. -/
theorem complement_pair_distinct {α : Type} (d : α → Bool) (x₀ : α) : d ≠ fun x => !d x := by
  intro h
  have h1 : d x₀ = !d x₀ := congrFun h x₀
  generalize d x₀ = b at h1
  cases b <;> cases h1

/-- THE WIDTH LAW: a nonempty family closed under complement, any two members equal or complementary, is exactly the
    complement pair of any member, and conversely. -/
theorem one_bit_iff_complement_pair {α : Type} (A : (α → Bool) → Prop) (d : α → Bool) (hd : A d) :
    ((∀ e, A e → A (fun x => !e x)) ∧ (∀ e e', A e → A e' → e' = e ∨ e' = fun x => !e x)) ↔
    (∀ e, A e ↔ ComplementPair d e) := by
  constructor
  · intro ⟨hclosed, hpair⟩ e
    constructor
    · intro he; exact hpair d e hd he
    · intro h; cases h with
      | inl h => rw [h]; exact hd
      | inr h => rw [h]; exact hclosed d hd
  · intro h
    refine ⟨fun e he => ?_, fun e e' he he' => ?_⟩
    · have := (h e).1 he
      apply (h _).2
      cases this with
      | inl h1 => exact Or.inr (by rw [h1])
      | inr h1 => left; rw [h1]; funext x; simp
    · have h1 := (h e).1 he; have h2 := (h e').1 he'
      cases h1 with
      | inl h1 => cases h2 with
        | inl h2 => left; rw [h1, h2]
        | inr h2 => right; rw [h1, h2]
      | inr h1 => cases h2 with
        | inl h2 => right; rw [h1, h2]; funext x; simp
        | inr h2 => left; rw [h1, h2]

/-- An odd witness fixes the calibration uniquely: one supplied bit closes a one-bit barrier. -/
theorem odd_witness_closes {α : Type} (d s : α → Bool) (x₀ : α) (c c' : Bool)
    (hc : s = shift d c) (hc' : s = shift d c') : c = c' :=
  (complement_pair_is_one_bit d x₀).2 c c' (hc.symm.trans hc')

def whollyOddMask (k m : Nat) : Bool :=
  (List.range k).all (fun i => m.testBit (2 * i) != m.testBit (2 * i + 1))

def oddCount (k : Nat) : Nat := ((List.range (2 ^ (2 * k))).filter (whollyOddMask k)).length

theorem odd_family_k1 : oddCount 1 = 2 := by decide
theorem odd_family_k2 : oddCount 2 = 4 := by decide
theorem odd_family_k3 : oddCount 3 = 8 := by decide
theorem odd_family_k4 : oddCount 4 = 16 := by decide
/-- The census parity frame: six pairs, 2^6 = 64 wholly odd targets, six bits unconstrained. -/
theorem odd_family_k6 : oddCount 6 = 64 := by decide

/-- The rows' claim at its grade: every row one bit wide iff every row's admissible family is a complement pair. -/
theorem rows_one_bit_iff_complement_pair {R α : Type} (A : R → (α → Bool) → Prop)
    (d : R → α → Bool) (hd : ∀ r, A r (d r)) :
    (∀ r, (∀ e, A r e → A r (fun x => !e x)) ∧ (∀ e e', A r e → A r e' → e' = e ∨ e' = fun x => !e x)) ↔
    (∀ r e, A r e ↔ ComplementPair (d r) e) := by
  constructor
  · intro h r; exact (one_bit_iff_complement_pair (A r) (d r) (hd r)).1 (h r)
  · intro h r; exact (one_bit_iff_complement_pair (A r) (d r) (hd r)).2 (h r)

end PNF

/-! ## APEX · the seat, the cone, the occupancy law, and the two lines of every row -/
namespace APEX
open GEO

/-! ### 1 · the seat -/

/-- The seat's binding involution: conjugation on the integer quaternions. -/
abbrev sigma : Q4 → Q4 := qconj

theorem sigma_binding (q : Q4) : sigma (sigma q) = q := by
  cases q with
  | mk r i j k =>
    change Q4.mk r (-(-i)) (-(-j)) (-(-k)) = Q4.mk r i j k
    rw [Int.neg_neg, Int.neg_neg, Int.neg_neg]

/-- Fix(σ) is the scalar line, for every quaternion. -/
theorem fix_iff_scalar (q : Q4) : sigma q = q ↔ (q.i = 0 ∧ q.j = 0 ∧ q.k = 0) := by
  cases q with
  | mk r i j k =>
    change (Q4.mk r (-i) (-j) (-k) = Q4.mk r i j k) ↔ (i = 0 ∧ j = 0 ∧ k = 0)
    constructor
    · intro h
      injection h with _ hi hj hk
      exact ⟨by omega, by omega, by omega⟩
    · intro h
      obtain ⟨hi, hj, hk⟩ := h
      subst hi
      subst hj
      subst hk
      rfl

/-- The seat: the fixed locus of the binding involution, constructed on the carrier. It is not `ROOT.Ground`,
    the posited type; it is a model of the posited shape. -/
def Seat : Type := { q : Q4 // sigma q = q }

/-- The Return: the parse triad through its own cascade, `GEO.chirality`. -/
def theReturn : Q4 := qmul (qmul qi qj) qk
theorem return_is_chirality : theReturn = ⟨-1, 0, 0, 0⟩ := GEO.chirality
theorem return_lands_on_seat : sigma theReturn = theReturn := rfl

def fixProj (q : Q4) : Q4 := ⟨q.r, 0, 0, 0⟩
/-- The axiom's seat point, the formal seat point, and the named seat point: three definitions. -/
def GammaRA : Q4 := theReturn
def GammaRAM : Q4 := fixProj theReturn
def GammaRH : Q4 := ⟨-1, 0, 0, 0⟩

/-- C0, C1, C2: the three category gaps are definitional identities. -/
theorem self_gap_nonexistent : sigma GammaRA = GammaRA := rfl
theorem register_gap_nonexistent : GammaRA = GammaRAM := rfl
theorem object_gap_nonexistent : GammaRAM = GammaRH := rfl

def seat : Seat := ⟨GammaRH, rfl⟩

theorem seat_on_scalar_line : GammaRH.i = 0 ∧ GammaRH.j = 0 ∧ GammaRH.k = 0 :=
  (fix_iff_scalar GammaRH).mp seat.2

/-- The reversed triad returns +1, also on the seat: the sign of the seat point is the orientation of the triad. -/
def theReturnOdd : Q4 := qmul (qmul qk qj) qi
theorem odd_return_is_plus_one : theReturnOdd = ⟨1, 0, 0, 0⟩ := rfl
theorem odd_return_on_seat : sigma theReturnOdd = theReturnOdd := rfl
theorem seat_points_differ : theReturnOdd ≠ theReturn := by decide

/-! ### 2 · the cone, and the category gap as a defined object -/

inductive Register3 where
  | ra
  | ram
  | rh
  deriving DecidableEq, Repr

def D3 : Register3 → Q4
  | .ra => GammaRA
  | .ram => GammaRAM
  | .rh => GammaRH

/-- A category gap: the absence of an identity leg from an apex to one register's reading of the seat. -/
def CategoryGap (D : Register3 → Q4) (a : Q4) (r : Register3) : Prop := a ≠ D r

/-- A cone over a register diagram in the groupoid of identities. -/
structure ConeOver (D : Register3 → Q4) (apex : Q4) : Prop where
  leg : ∀ r, apex = D r

/-- A cone is exactly an apex with no category gap. -/
theorem cone_iff_no_gap (D : Register3 → Q4) (a : Q4) : ConeOver D a ↔ ∀ r, ¬ CategoryGap D a r :=
  ⟨fun c r h => h (c.leg r), fun h => ⟨fun r => Decidable.byContradiction (h r)⟩⟩

abbrev Cone : Q4 → Prop := ConeOver D3

/-- THE IDENTITY CONE: every leg `rfl`. -/
theorem identity_cone : Cone GammaRH := ⟨fun r => by cases r <;> rfl⟩

theorem cone_apex_unique (a b : Q4) (ha : Cone a) (hb : Cone b) : a = b :=
  (ha.leg .rh).trans (hb.leg .rh).symm

theorem cone_iff_gaps_closed : (∃ a, Cone a) ↔ (GammaRA = GammaRAM ∧ GammaRAM = GammaRH) := by
  constructor
  · intro ⟨a, ha⟩
    exact ⟨(ha.leg .ra).symm.trans (ha.leg .ram), (ha.leg .ram).symm.trans (ha.leg .rh)⟩
  · intro ⟨h1, h2⟩
    exact ⟨GammaRH, ⟨fun r => by
      cases r
      · exact (h1.trans h2).symm
      · exact h2.symm
      · rfl⟩⟩

def D3odd : Register3 → Q4
  | .ra => theReturnOdd
  | .ram => fixProj theReturnOdd
  | .rh => ⟨1, 0, 0, 0⟩

theorem identity_cone_odd : ConeOver D3odd ⟨1, 0, 0, 0⟩ := ⟨fun r => by cases r <;> rfl⟩

/-- Uniqueness is per orientation: the two apexes differ. -/
theorem apexes_differ_by_orientation :
    ConeOver D3 GammaRH ∧ ConeOver D3odd ⟨1, 0, 0, 0⟩ ∧ GammaRH ≠ ⟨1, 0, 0, 0⟩ :=
  ⟨identity_cone, identity_cone_odd, by decide⟩

/-! ### 3 · the register leg rides one involution (RESIDUAL-MONISM, executed on the carrier) -/

/-- A second binding involution on the carrier, fixing the line r = i. -/
def sigmaP (q : Q4) : Q4 := ⟨q.i, q.r, -q.j, -q.k⟩

theorem sigmaP_binding (q : Q4) : sigmaP (sigmaP q) = q := by
  cases q with
  | mk r i j k =>
    change Q4.mk r i (-(-j)) (-(-k)) = Q4.mk r i j k
    rw [Int.neg_neg, Int.neg_neg]

theorem sigmaP_fix_iff (q : Q4) : sigmaP q = q ↔ (q.r = q.i ∧ q.j = 0 ∧ q.k = 0) := by
  cases q with
  | mk r i j k =>
    change (Q4.mk i r (-j) (-k) = Q4.mk r i j k) ↔ (r = i ∧ j = 0 ∧ k = 0)
    constructor
    · intro h
      injection h with h1 _ h3 h4
      exact ⟨by omega, by omega, by omega⟩
    · intro h
      obtain ⟨h1, h3, h4⟩ := h
      subst h1
      subst h3
      subst h4
      rfl

/-- The two seats meet only at the origin. -/
theorem seats_meet_only_at_zero (r i j k : Int) :
    (sigma ⟨r, i, j, k⟩ = ⟨r, i, j, k⟩ ∧ sigmaP ⟨r, i, j, k⟩ = ⟨r, i, j, k⟩) ↔
      (r = 0 ∧ i = 0 ∧ j = 0 ∧ k = 0) := by
  rw [fix_iff_scalar, sigmaP_fix_iff]
  show (i = 0 ∧ j = 0 ∧ k = 0) ∧ (r = i ∧ j = 0 ∧ k = 0) ↔ (r = 0 ∧ i = 0 ∧ j = 0 ∧ k = 0)
  constructor
  · intro ⟨⟨hi, hj, hk⟩, hr, _, _⟩
    exact ⟨by omega, hi, hj, hk⟩
  · intro ⟨hr, hi, hj, hk⟩
    exact ⟨⟨hi, hj, hk⟩, by omega, hj, hk⟩

/-- THE REGISTER LEG RIDES ONE INVOLUTION: the kinetic seat point is fixed by σ and moved by the rival σP, so the leg
    Γ_RA = Γ_RAM closes by `rfl` only under the one-involution connector the codex holds as RESIDUAL-MONISM. -/
theorem register_leg_rides_one_involution :
    sigma GammaRA = GammaRA ∧ sigmaP GammaRA ≠ GammaRA ∧ sigmaP GammaRH ≠ GammaRH :=
  ⟨rfl, by decide, by decide⟩

/-! ### 4 · the embedding of the Riemann stage -/

/-- φ(h, t) = ⟨t, h − 1, 0, 0⟩ on the Bridge's plane, against the Bridge's fold. -/
def phi (p : Bridge.Plane) : Q4 := ⟨p.2, p.1 - 1, 0, 0⟩

theorem phi_equivariant (p : Bridge.Plane) : sigma (phi p) = phi (Bridge.τ p) := by
  obtain ⟨h, t⟩ := p
  change Q4.mk t (-(h - 1)) 0 0 = Q4.mk t ((2 - h) - 1) 0 0
  have e : -(h - 1) = (2 - h) - 1 := by omega
  rw [e]

theorem phi_fix_iff (p : Bridge.Plane) : sigma (phi p) = phi p ↔ Bridge.τ p = p := by
  obtain ⟨h, t⟩ := p
  change (Q4.mk t (-(h - 1)) 0 0 = Q4.mk t (h - 1) 0 0) ↔ ((2 - h, t) = (h, t))
  constructor
  · intro e
    injection e with _ e2 _ _
    have : h = 1 := by omega
    subst this
    rfl
  · intro e
    have e1 : 2 - h = h := congrArg Prod.fst e
    have : h = 1 := by omega
    subst this
    rfl

/-- φ carries the Bridge's line onto the seat: the image clause, read through `Bridge.locus_is_the_fixed_set`. -/
theorem phi_fix_iff_line (p : Bridge.Plane) : sigma (phi p) = phi p ↔ Bridge.onLine p :=
  (phi_fix_iff p).trans (Bridge.locus_is_the_fixed_set p)

theorem phi_injective (p q : Bridge.Plane) (e : phi p = phi q) : p = q := by
  obtain ⟨h, t⟩ := p
  obtain ⟨h', t'⟩ := q
  injection e with e1 e2 _ _
  have : h = h' := by omega
  subst this
  subst e1
  rfl

def tauM (m : Int) (p : Bridge.Plane) : Bridge.Plane := (2 * m - p.1, p.2)
def phiM (m : Int) (p : Bridge.Plane) : Q4 := ⟨p.2, p.1 - m, 0, 0⟩

theorem phiM_equivariant (m : Int) (p : Bridge.Plane) : sigma (phiM m p) = phiM m (tauM m p) := by
  obtain ⟨h, t⟩ := p
  change Q4.mk t (-(h - m)) 0 0 = Q4.mk t ((2 * m - h) - m) 0 0
  have e : -(h - m) = (2 * m - h) - m := by omega
  rw [e]

theorem phiM_fix_iff (m : Int) (p : Bridge.Plane) : sigma (phiM m p) = phiM m p ↔ tauM m p = p := by
  obtain ⟨h, t⟩ := p
  change (Q4.mk t (-(h - m)) 0 0 = Q4.mk t (h - m) 0 0) ↔ ((2 * m - h, t) = (h, t))
  constructor
  · intro e
    injection e with _ e2 _ _
    have : h = m := by omega
    subst this
    show (2 * h - h, t) = (h, t)
    have e3 : 2 * h - h = h := by omega
    rw [e3]
  · intro e
    have e1 : 2 * m - h = h := congrArg Prod.fst e
    have : h = m := by omega
    subst this
    show Q4.mk t (-(h - h)) 0 0 = Q4.mk t (h - h) 0 0
    have e3 : h - h = 0 := by omega
    rw [e3]
    rfl

theorem seat_on_image_of_line : phi (1, -1) = GammaRH := rfl

/-! ### 5 · THE OCCUPANCY LAW: the router bit is read on each row's native involution, through the occupancy of the seat; the seat point never supplies a Ground dimension -/

/-- THE OCCUPANCY LAW. Under a bridge whose image clause carries fixedness exactly, the seat is occupied iff the row's
    native involution has a fixed point. -/
theorem seat_occupied_iff_grounded {S : Type} (τ : S → S) (φ : S → Q4)
    (himg : ∀ p, sigma (φ p) = φ p ↔ τ p = p) :
    (∃ p, sigma (φ p) = φ p) ↔ (∃ p, τ p = p) :=
  ⟨fun ⟨p, h⟩ => ⟨p, (himg p).mp h⟩, fun ⟨p, h⟩ => ⟨p, (himg p).mpr h⟩⟩

/-- A fixed-point-free native involution leaves the seat vacant under every admissible bridge. -/
theorem seat_vacant_of_free {S : Type} (τ : S → S) (φ : S → Q4)
    (hfree : ∀ p, τ p ≠ p) (himg : ∀ p, sigma (φ p) = φ p ↔ τ p = p) :
    ∀ p, sigma (φ p) ≠ φ p :=
  fun p h => hfree p ((himg p).mp h)

/-- The same vacancy from equivariance and injectivity alone, no image clause assumed. -/
theorem seat_vacant_of_equivariant {S : Type} (τ : S → S) (φ : S → Q4)
    (hfree : ∀ p, τ p ≠ p) (heq : ∀ p, sigma (φ p) = φ (τ p))
    (hinj : ∀ p q, φ p = φ q → p = q) :
    ∀ p, sigma (φ p) ≠ φ p :=
  fun p h => hfree p (hinj _ _ ((heq p).symm.trans h))

/-- The complexity row's native involution as its shape face types it: complementation. -/
def complement {α : Type} (f : α → Bool) : α → Bool := fun x => !f x

/-- Complementation is fixed-point-free on any nonempty domain: the Width Law's distinctness, read as an involution. -/
theorem complement_free {α : Type} (x₀ : α) (f : α → Bool) : complement f ≠ f :=
  fun h => PNF.complement_pair_distinct f x₀ h.symm

/-- THE VACANCY OF THE COMPLEXITY SEAT: no admissible bridge places the row on Fix(σ). -/
theorem pnp_seat_vacant {α : Type} (x₀ : α) (φ : (α → Bool) → Q4)
    (himg : ∀ f, sigma (φ f) = φ f ↔ complement f = f) :
    ∀ f, sigma (φ f) ≠ φ f :=
  seat_vacant_of_free complement φ (complement_free x₀) himg

/-- An admissible bridge for the complexity row exists, on the one-point domain, and it lands off the seat. -/
def pnpBridge (b : Bool) : Q4 := ⟨0, if b then 1 else -1, 0, 0⟩

theorem pnp_bridge_admissible :
    (∀ b : Bool, sigma (pnpBridge b) = pnpBridge (!b)) ∧
    (∀ b : Bool, sigma (pnpBridge b) = pnpBridge b ↔ (!b) = b) := by
  constructor <;> intro b <;> cases b <;> decide

theorem pnp_bridge_off_seat : ∀ b : Bool, sigma (pnpBridge b) ≠ pnpBridge b := by
  intro b; cases b <;> decide

/-- The critical-line stage occupies the seat. -/
theorem riemann_seat_occupied : ∃ p : Bridge.Plane, sigma (phi p) = phi p := ⟨(1, -1), rfl⟩

/-- THE ROUTER BIT, READ ON EACH ROW'S NATIVE INVOLUTION THROUGH THE OCCUPANCY OF THE SEAT: the Ξ branch where the
    stage's involution has a fixed point and the stage reaches the seat, the Ø branch where the row's involution is
    fixed-point-free and no admissible bridge can reach it. The uniform seat point never supplies a Ground dimension. -/
theorem router_at_the_seat :
    ((∃ p : Bridge.Plane, sigma (phi p) = phi p) ↔ (∃ p : Bridge.Plane, Bridge.τ p = p)) ∧
    (∃ p : Bridge.Plane, sigma (phi p) = phi p) ∧ HALT.route HALT.rhHalt.gdim = some .xi ∧
    (∀ b : Bool, sigma (pnpBridge b) ≠ pnpBridge b) ∧ HALT.route HALT.pnpHalt.gdim = some .o :=
  ⟨seat_occupied_iff_grounded Bridge.τ phi phi_fix_iff, riemann_seat_occupied, rfl,
   pnp_bridge_off_seat, rfl⟩

/-! ### 6 · the witness, the eliminator, and the deed the kernel cannot read -/

def RAMFormalGround : Prop := Nonempty Seat
theorem constructed_RAM : RAMFormalGround := ⟨seat⟩

/-- The formal self: every point of the seat is fixed. It names the seat and says nothing about any row's value. -/
def FormalSelf : Prop := ∀ g : Seat, sigma g.1 = g.1

/-- Bridge-born orientation, carried in Prop: registered as supplied, never readable as data. -/
structure OrientationBit : Prop where
  direction : True
  closure : True

theorem constructed_orientation : OrientationBit := ⟨trivial, trivial⟩
theorem orientation_proof_irrelevant (a b : OrientationBit) : a = b := rfl

inductive ModelPoint where
  | source
  deriving DecidableEq, Repr

def modelΔE : ModelPoint → Int := fun _ => 1

/-- RA at a constructed one-point domain: a model of the root, never its universal extension `ROOT.RA`. -/
def RAModel : Prop := ∀ x : ModelPoint, 0 < modelΔE x

theorem modelRA : RAModel := by
  intro x
  cases x
  decide

structure Witness : Prop where
  actuates : RAModel
  orientation : OrientationBit
  bridge : RAMFormalGround
  trisRecursion : OrientationBit → RAMFormalGround → FormalSelf

/-- The constructed witness: the only supplied witness. -/
theorem mkWitness : Witness :=
  ⟨modelRA, constructed_orientation, constructed_RAM, fun _ _ g => g.2⟩

/-- THE ELIMINATOR: RA → RA → RAM → the formal self, Bridge capacity then recursion, from the witness alone. -/
theorem eliminator : FormalSelf := mkWitness.trisRecursion mkWitness.orientation mkWitness.bridge

/-- The recursion field is constant: masslessness stated as a term, occupancy and not derivation. -/
theorem recursion_is_constant (o o' : OrientationBit) (g g' : RAMFormalGround) :
    mkWitness.trisRecursion o g = mkWitness.trisRecursion o' g' := rfl

/-- The wall at the seat: no readout of the seat equals the deed bit, `CROSSING.wall` at the seat. -/
theorem deed_unreadable_at_seat :
    ¬ ∃ f : Seat → Bool, ∀ s : CROSSING.ExecFrame Seat, f (CROSSING.formalRead s) = CROSSING.ran s :=
  CROSSING.wall seat

/-! ### 7 · RAF at the formal register: no exterior agent, no total self-indexing, the aperture -/

structure Domain (S : Type) where
  mem : S → Prop
  registers : S → S → Prop
  registers_symm : ∀ a b, registers a b → registers b a
  closure : ∀ s d, mem d → registers s d → mem s

theorem no_exterior_agent {S : Type} (D : Domain S) (s : S) (hs : ¬ D.mem s) :
    ∀ d, D.mem d → ¬ D.registers s d :=
  fun d hd hr => hs (D.closure s d hd hr)

theorem adjudicator_in_domain {S : Type} (D : Domain S) (r d : S) (hd : D.mem d)
    (hr : D.registers r d) : D.mem r :=
  D.closure r d hd hr

theorem no_total_self_indexing {S : Type} (f : S → S → Bool) :
    ¬ ∀ g : S → Bool, ∃ x, f x = g := by
  intro h
  obtain ⟨x, hx⟩ := h (fun y => !f y y)
  have h1 : f x x = !f x x := congrFun hx x
  generalize f x x = b at h1
  cases b <;> cases h1

/-- The live face on the codex's own tokens: witnessed and assent seal, witnessed and denial refuse, unwitnessed open. -/
def live (witnessed assent : Bool) : Audit.Token :=
  if witnessed then (if assent then .sealed else .refused) else .opn

theorem aperture_opens_under_premise {U : Type} (dE : U → Int) (h : ∀ x, 0 < dE x) (x : U) :
    decide (0 < dE x) = true :=
  decide_eq_true (h x)

/-- Under the premise no present reader's row is interior: sealed or refused by the bit alone. -/
theorem no_interior_under_premise {U : Type} (dE : U → Int) (h : ∀ x, 0 < dE x) (x : U) (b : Bool) :
    live (decide (0 < dE x)) b ≠ .opn := by
  rw [aperture_opens_under_premise dE h x]
  cases b <;> decide

/-! ### 8 · the rule, its bound, the grounded counter-model, and the cure -/

/-- THE RULE, EXACT: for any inhabited premise, (P → L X) ↔ L X. -/
theorem rule_exact (P : Prop) (hp : P) (X : Bridge.Frame) :
    (P → Bridge.LineProperty X) ↔ Bridge.LineProperty X :=
  ⟨fun h => h hp, fun t _ => t⟩

theorem rule_exact_model (X : Bridge.Frame) : (RAModel → Bridge.LineProperty X) ↔ Bridge.LineProperty X :=
  rule_exact _ modelRA X

/-- The same rule against the posit itself: its dependency set names ROOT.RA, ROOT.U, ROOT.ΔE, and nothing else. -/
theorem rule_exact_under_root (X : Bridge.Frame) :
    (ROOT.throneEmpty → Bridge.LineProperty X) ↔ Bridge.LineProperty X :=
  rule_exact _ ROOT.RA X

/-- The two-point frame of the Bridge fails the line property, proved here without choice; the resident statement is
    `Bridge.line_property_contingent`. -/
theorem twoPoint_fails_L : ¬ Bridge.LineProperty Bridge.twoPoint := by
  intro h
  have h1 := h true trivial
  cases h1

/-- No inhabited premise decides the line property on every frame: the two-point frame carries it and fails L. -/
theorem premise_decides_no_frame (P : Prop) (hp : P) : ¬ ∀ X : Bridge.Frame, P → Bridge.LineProperty X :=
  fun h => twoPoint_fails_L (h Bridge.twoPoint hp)

inductive Three where
  | a
  | b
  | c
  deriving DecidableEq, Repr

def foldThree : Three → Three
  | .a => .b
  | .b => .a
  | .c => .c

theorem foldThree_involutive : ∀ s, foldThree (foldThree s) = s := by
  intro s; cases s <;> rfl

def zeroThree (x : Three) : Prop := x = .a ∨ x = .b

theorem zeroThree_symmetric : ∀ s, zeroThree s → zeroThree (foldThree s) := by
  intro s hs
  cases s with
  | a => exact Or.inr rfl
  | b => exact Or.inl rfl
  | c => cases hs with
    | inl h => cases h
    | inr h => cases h

/-- The grounded counter-model: a seat and a moved zero. -/
def threePoint : Bridge.Frame := ⟨Three, foldThree, zeroThree, foldThree_involutive, zeroThree_symmetric⟩

theorem threePoint_grounded : ∃ s : Three, foldThree s = s := ⟨Three.c, rfl⟩

theorem threePoint_fails_L : ¬ Bridge.LineProperty threePoint := by
  intro h
  have h1 : foldThree Three.a = Three.a := h Three.a (Or.inl rfl)
  cases h1

theorem premise_holds_where_L_fails_grounded (P : Prop) (hp : P) :
    P ∧ (∃ s : Three, foldThree s = s) ∧ ¬ Bridge.LineProperty threePoint :=
  ⟨hp, threePoint_grounded, threePoint_fails_L⟩

/-- THE CURE THEOREM: for every class of frames, a true premise decides L on the class exactly where L already holds. -/
theorem no_cure (P : Prop) (hp : P) (C : Bridge.Frame → Prop) :
    (∀ X, C X → P → Bridge.LineProperty X) ↔ (∀ X, C X → Bridge.LineProperty X) :=
  ⟨fun h X hc => h X hc hp, fun h X hc _ => h X hc⟩

theorem cure_is_the_hypothesis (P : Prop) (hp : P) :
    (∀ X : Bridge.Frame, Bridge.LineProperty X → P → Bridge.LineProperty X) ∧
    ¬ (∀ X : Bridge.Frame, True → P → Bridge.LineProperty X) :=
  ⟨fun _ h _ => h, fun h => premise_decides_no_frame P hp (fun X => h X trivial)⟩

/-- The halting carrier inhabited by decision, the clause proved from the decision and never assumed. -/
def carrierOfDecision (X : Bridge.Frame) (d : Decidable (Bridge.LineProperty X)) : Bridge.Carrier X :=
  match d with
  | isTrue h => ⟨.bot, ⟨fun _ => h, fun _ => rfl⟩, Bridge.theRecord⟩
  | isFalse h => ⟨.tt, ⟨fun e => absurd e (by decide), fun hl => absurd hl h⟩, Bridge.theRecord⟩

theorem twoPoint_carrier_does_not_halt :
    (carrierOfDecision Bridge.twoPoint (isFalse twoPoint_fails_L)).terminal = .tt := rfl

/-! ### 9 · the three measures: content, mass, price -/

inductive Content where
  | trivial_
  | proved
  | supplied
  deriving DecidableEq, Repr

structure Measure where
  content : Content
  mass : Nat
  price : Ratio
  deriving DecidableEq

def legMeasure : Measure := ⟨.trivial_, deltaM, 0⟩
def arcMeasure : Measure := ⟨.proved, deltaM, 0⟩
/-- The value's price is the exact Landauer floor of the codex, `OMEGA.landauerRat` at 300 K. -/
def valueMeasure : Measure := ⟨.supplied, deltaM, OMEGA.landauerRat 300 1⟩

theorem masses_all_zero : legMeasure.mass = 0 ∧ arcMeasure.mass = 0 ∧ valueMeasure.mass = 0 :=
  ⟨rfl, rfl, rfl⟩

theorem contents_differ :
    legMeasure.content ≠ valueMeasure.content ∧ arcMeasure.content ≠ valueMeasure.content ∧
    legMeasure.content ≠ arcMeasure.content := by
  refine ⟨?_, ?_, ?_⟩ <;> decide

theorem prices_differ : legMeasure.price = 0 ∧ 0 < valueMeasure.price := by
  constructor
  · rfl
  · decide

/-! ### 10 · the twenty-three rows -/

inductive Row : Type where
  | pVsNP | riemann | navierStokes | yangMills | hodge | bsd | poincare
  | goldbach | twinPrimes | legendre | abc | jacobian
  | mersenne | oddPerfect | smoothPoincare4 | collatz
  | hadwiger | sunflower | erdosStraus | beal
  | invariantSubspace | hilbert16 | lindelofPCC
  deriving DecidableEq, Repr

def Row.all : List Row :=
  [.pVsNP, .riemann, .navierStokes, .yangMills, .hodge, .bsd, .poincare,
   .goldbach, .twinPrimes, .legendre, .abc, .jacobian,
   .mersenne, .oddPerfect, .smoothPoincare4, .collatz,
   .hadwiger, .sunflower, .erdosStraus, .beal,
   .invariantSubspace, .hilbert16, .lindelofPCC]

theorem rows_twenty_three : Row.all.length = 23 := by decide
theorem rows_distinct : Row.all.eraseDups.length = 23 := by decide
theorem rows_complete : ∀ r : Row, r ∈ Row.all := by intro r; cases r <;> decide

def Row.millennium : Row → Bool
  | .pVsNP | .riemann | .navierStokes | .yangMills | .hodge | .bsd | .poincare => true
  | _ => false

theorem millennium_seven : (Row.all.filter Row.millennium).length = 7 := by decide
theorem extension_sixteen : (Row.all.filter (fun r => !r.millennium)).length = 16 := by decide

/-- Every row's seat point is the one seat point Γ_RH: an assignment of the grounding reading, computed from no
    row's object. -/
def apexSeat : Row → Q4 := fun _ => GammaRH

theorem apex_seat_fixed : ∀ r : Row, sigma (apexSeat r) = apexSeat r := by
  intro r; cases r <;> rfl

theorem apex_seat_uniform : ∀ r s : Row, apexSeat r = apexSeat s := by
  intro r s; cases r <;> cases s <;> rfl

theorem crossed_and_open_share_the_seat : apexSeat .poincare = apexSeat .riemann := rfl

def D3row (r : Row) : Register3 → Q4
  | .ra => GammaRA
  | .ram => GammaRAM
  | .rh => apexSeat r

theorem identity_cone_row (r : Row) : ConeOver (D3row r) GammaRH :=
  ⟨fun k => by cases k <;> cases r <;> rfl⟩

theorem cone_apex_unique_row {r : Row} (a b : Q4) (ha : ConeOver (D3row r) a) (hb : ConeOver (D3row r) b) :
    a = b :=
  (ha.leg .rh).trans (hb.leg .rh).symm

theorem gaps_closed_every_row :
    Row.all.all (fun r => decide (GammaRH = GammaRA ∧ GammaRH = GammaRAM ∧ GammaRH = apexSeat r)) = true := by
  decide

/-- The formal self of a row: one proposition on every row. -/
def formalSelfRow (_ : Row) : Prop := FormalSelf

/-- THE INVERTED CONTROL: the witness on the crossed row is the witness on every open row, and decides none. -/
theorem inverted_control : ∀ r s : Row, formalSelfRow r ↔ formalSelfRow s := fun _ _ => Iff.rfl

theorem all_rows_eliminated : ∀ r : Row, formalSelfRow r := fun _ => eliminator

/-- A row's value: the line property of a frame assigned to it, the assignment a parameter. -/
def value (F : Row → Bridge.Frame) (r : Row) : Prop := Bridge.LineProperty (F r)

theorem rule_exact_every_row (P : Prop) (hp : P) (F : Row → Bridge.Frame) (r : Row) :
    (P → value F r) ↔ value F r :=
  rule_exact P hp (F r)

theorem premise_decides_no_row (P : Prop) (hp : P) : ¬ ∀ (F : Row → Bridge.Frame) (r : Row), P → value F r :=
  fun h => twoPoint_fails_L (h (fun _ => Bridge.twoPoint) .riemann hp)

theorem premise_decides_no_row_grounded (P : Prop) (hp : P) :
    ¬ ∀ (F : Row → Bridge.Frame) (r : Row), P → value F r :=
  fun h => threePoint_fails_L (h (fun _ => threePoint) .poincare hp)

theorem no_cure_every_row (P : Prop) (hp : P) (_r : Row) (C : Bridge.Frame → Prop) :
    (∀ X, C X → P → Bridge.LineProperty X) ↔ (∀ X, C X → Bridge.LineProperty X) :=
  no_cure P hp C

/-! ### 11 · the world typing of the census, carried as data -/

inductive WorldTyping : Type where
  | exactStructural | wallRowF4 | beachheadOrderTwo | crossedControl
  | pureUnbridged | diagonalPortF3 | oneBitFromClosure | wallRowBridgeGate
  deriving DecidableEq, Repr

def worldTyping : Row → WorldTyping
  | .pVsNP | .riemann | .goldbach | .twinPrimes | .legendre | .abc | .jacobian => .exactStructural
  | .navierStokes | .yangMills | .hodge => .wallRowF4
  | .bsd => .beachheadOrderTwo
  | .poincare => .crossedControl
  | .mersenne | .oddPerfect | .smoothPoincare4 => .pureUnbridged
  | .collatz => .diagonalPortF3
  | .hadwiger | .sunflower | .erdosStraus | .beal => .oneBitFromClosure
  | .invariantSubspace | .hilbert16 | .lindelofPCC => .wallRowBridgeGate

theorem world_census :
    (Row.all.filter (fun r => decide (worldTyping r = .exactStructural))).length = 7 ∧
    (Row.all.filter (fun r => decide (worldTyping r = .wallRowF4))).length = 3 ∧
    (Row.all.filter (fun r => decide (worldTyping r = .beachheadOrderTwo))).length = 1 ∧
    (Row.all.filter (fun r => decide (worldTyping r = .crossedControl))).length = 1 ∧
    (Row.all.filter (fun r => decide (worldTyping r = .pureUnbridged))).length = 3 ∧
    (Row.all.filter (fun r => decide (worldTyping r = .diagonalPortF3))).length = 1 ∧
    (Row.all.filter (fun r => decide (worldTyping r = .oneBitFromClosure))).length = 4 ∧
    (Row.all.filter (fun r => decide (worldTyping r = .wallRowBridgeGate))).length = 3 := by
  decide

/-! ### 12 · the two lines of every row: the seat line by the row cascade, the value line by the locus emitter -/

/-- The seat's answers to the row cascade: contentful, no live V_E, not forward, populated, no worldly row, terms
    closed, frame closed under the one-involution connector, the RA rider present. -/
def seatAnswers : GEO.ClaimInputRA :=
  { nonvacuous := .yes, veLive := .no, forward := .no, populated := .yes, worldlyRow := .no,
    termsClosed := .yes, termWorldly := .no, frameClosed := .yes, annotate := .yes }

/-- The value's answers: the same, save that the deciding row is furnished by the world. -/
def valueAnswers : GEO.ClaimInputRA := { seatAnswers with worldlyRow := .yes }

/-- THE SEAT LINE: compartment I, closure-rowed, the RA rider present, emitted by the codex's own cascade. -/
theorem seat_line : (GEO.rowCascadeRA seatAnswers).1 = .aGivenRA := by decide
/-- The value line's compartment: III, world-rowed. -/
theorem value_compartment : (GEO.rowCascadeRA valueAnswers).1 = .iii := by decide
/-- Without the RA rider the seat line is void: the rider is load-bearing. -/
theorem seat_line_void_without_rider : (GEO.rowCascadeRA { seatAnswers with annotate := .no }).1 = .void := by
  decide

def seatToken : Audit.Token := (GEO.rowCascadeRA seatAnswers).1.toToken
theorem seat_token_is_aGivenRA : seatToken = .aGivenRA := by decide

/-- The value reading of each row for the locus emitter: the router bit where the register of record measured it,
    the formal channel, one owed slot on an open row and one filled slot on the crossed control. No species is
    invented: only the two rows the kernel already types carry one. -/
def valueReading : Row → LOCUS.Reading
  | .riemann => ⟨false, true, some 1, some .hypothesis, some .formal, [none], by decide⟩
  | .pVsNP => ⟨false, true, some 0, some .blockTheorem, some .formal, [none], by decide⟩
  | .poincare => ⟨false, true, none, none, some .formal, [some true], by decide⟩
  | _ => ⟨false, true, none, none, some .formal, [none], by decide⟩

theorem riemann_value_line :
    LOCUS.emit (valueReading .riemann) = some (.superHalt (some .xi) (some .hypothesis) (some .formal) 1) := by
  decide

theorem pnp_value_line :
    LOCUS.emit (valueReading .pVsNP) = some (.superHalt (some .o) (some .blockTheorem) (some .formal) 1) := by
  decide

theorem poincare_value_line : LOCUS.emit (valueReading .poincare) = some (.crossed .formal) := by
  decide

theorem unrouted_value_line :
    LOCUS.emit (valueReading .hodge) = some (.superHalt none none (some .formal) 1) := by
  decide

/-- The Riemann value line is the one `FENCE.global` already pins. -/
theorem riemann_value_line_is_pinned :
    LOCUS.emit (valueReading .riemann) =
      LOCUS.emit ⟨false, true, some 1, some .hypothesis, some .formal, [none], by decide⟩ := rfl

theorem value_bits_owed : (Row.all.map (fun r => (valueReading r).owed)).foldl (· + ·) 0 = 22 := by decide

theorem crossed_iff_poincare : ∀ r : Row, (valueReading r).state = .sealed ↔ r = .poincare := by
  intro r; cases r <;> decide

/-- THE PARTING: on no row does the seat line coincide with the value line. -/
theorem lines_parted : ∀ r : Row, seatToken ≠ (valueReading r).state := by
  intro r; cases r <;> decide

/-- THE NO-PROMOTION THEOREM: the seat line holds on every row; the value line is crossed on exactly one. -/
theorem seat_never_promotes_value :
    (∀ _r : Row, FormalSelf ∧ seatToken = .aGivenRA) ∧
    (∀ r : Row, (valueReading r).state = .sealed ↔ r = .poincare) :=
  ⟨fun _ => ⟨eliminator, seat_token_is_aGivenRA⟩, crossed_iff_poincare⟩

/-! ### 13 · the object leg of every row, and its justification -/

inductive ObjectLeg where
  | bridgedStage
  | vacantByTheorem
  | owed
  deriving DecidableEq, Repr

def objectLeg : Row → ObjectLeg
  | .riemann => .bridgedStage
  | .pVsNP => .vacantByTheorem
  | _ => .owed

theorem object_leg_ledger :
    (Row.all.filter (fun r => decide (objectLeg r = .bridgedStage))).length = 1 ∧
    (Row.all.filter (fun r => decide (objectLeg r = .vacantByTheorem))).length = 1 ∧
    (Row.all.filter (fun r => decide (objectLeg r = .owed))).length = 21 := by
  decide

/-- Each nontrivial leg is backed by its theorem: the stage reaches the seat; the complexity row never can. -/
theorem object_legs_justified :
    (objectLeg .riemann = .bridgedStage ∧ ∃ p : Bridge.Plane, sigma (phi p) = phi p) ∧
    (objectLeg .pVsNP = .vacantByTheorem ∧
      ∀ {α : Type} (_x₀ : α) (φ : (α → Bool) → Q4),
        (∀ f, sigma (φ f) = φ f ↔ complement f = f) → ∀ f, sigma (φ f) ≠ φ f) :=
  ⟨⟨rfl, riemann_seat_occupied⟩, ⟨rfl, fun x₀ φ h => pnp_seat_vacant x₀ φ h⟩⟩

/-- The price of the owed value bits, exact: twenty-two Landauer floors at 300 K. -/
def owedPrice : Ratio := OMEGA.landauerRat 300 22

theorem owed_price_is_twenty_two_floors : owedPrice = 22 * OMEGA.landauerRat 300 1 := by decide

/-! ### 14 · the anchor, whole -/

/-- THE SEAT ANCHOR. The cone and the one seat on every row; the occupancy law; the stage on the seat and the complexity
    row off it; the register leg riding one involution; the seat line uniform and the value lines parted from it; the
    crossing on one row; twenty-two bits owed; no true premise deciding any frame. -/
theorem seat_anchor :
    (∀ r : Row, ConeOver (D3row r) GammaRH ∧ apexSeat r = GammaRH) ∧
    (∀ {S : Type} (τ : S → S) (φ : S → Q4), (∀ p, sigma (φ p) = φ p ↔ τ p = p) →
        ((∃ p, sigma (φ p) = φ p) ↔ (∃ p, τ p = p))) ∧
    (∃ p : Bridge.Plane, sigma (phi p) = phi p) ∧
    (∀ b : Bool, sigma (pnpBridge b) ≠ pnpBridge b) ∧
    (sigma GammaRA = GammaRA ∧ sigmaP GammaRA ≠ GammaRA) ∧
    (seatToken = .aGivenRA ∧ ∀ r : Row, seatToken ≠ (valueReading r).state) ∧
    (∀ r : Row, (valueReading r).state = .sealed ↔ r = .poincare) ∧
    ((Row.all.map (fun r => (valueReading r).owed)).foldl (· + ·) 0 = 22) ∧
    (∀ P : Prop, P → ¬ ∀ X : Bridge.Frame, P → Bridge.LineProperty X) :=
  ⟨fun r => ⟨identity_cone_row r, rfl⟩, fun τ φ h => seat_occupied_iff_grounded τ φ h,
   riemann_seat_occupied, pnp_bridge_off_seat,
   ⟨register_leg_rides_one_involution.1, register_leg_rides_one_involution.2.1⟩,
   ⟨seat_token_is_aGivenRA, lines_parted⟩, crossed_iff_poincare, value_bits_owed,
   fun P hp => premise_decides_no_frame P hp⟩

end APEX

/-! ## FENCE.seat · the one fence of the seat line, beside FENCE.global -/
namespace FENCE

theorem seat :
    (∀ r : APEX.Row, APEX.seatToken ≠ (APEX.valueReading r).state) ∧
    (∀ r : APEX.Row, (APEX.valueReading r).state = .sealed ↔ r = .poincare) ∧
    LOCUS.emit (APEX.valueReading .pVsNP) = some (.superHalt (some .o) (some .blockTheorem) (some .formal) 1) ∧
    LOCUS.emit (APEX.valueReading .riemann) = some (.superHalt (some .xi) (some .hypothesis) (some .formal) 1) ∧
    (APEX.Row.all.map (fun r => (APEX.valueReading r).owed)).foldl (· + ·) 0 = 22 ∧
    (∀ P : Prop, P → ¬ ∀ X : Bridge.Frame, P → Bridge.LineProperty X) ∧
    (∀ P : Prop, P → ∀ C : Bridge.Frame → Prop,
      (∀ X, C X → P → Bridge.LineProperty X) ↔ (∀ X, C X → Bridge.LineProperty X)) :=
  ⟨APEX.lines_parted, APEX.crossed_iff_poincare, APEX.pnp_value_line, APEX.riemann_value_line,
   APEX.value_bits_owed, fun P hp => APEX.premise_decides_no_frame P hp, fun P hp C => APEX.no_cure P hp C⟩

end FENCE

/-! ## FOUND.seatInventory · the connector's one dependency, recorded apart from the value verdicts -/
namespace FOUND

def seatInventory : List VerdictRow := [
  ⟨"the seat line on every row, its register leg read as RA to RAM (APEX, the Seat Anchor)", ["RESIDUAL-MONISM"]⟩]

theorem seat_rides_the_connector :
    (seatInventory.all (fun v => v.positDeps == ["RESIDUAL-MONISM"])) = true ∧
    (verdictInventory.all (fun v => v.positDeps.isEmpty)) = true := by
  decide

end FOUND
