# v4.2.0 kit · build receipts

**Toolchains.** Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release); GNU Fortran (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0; one CPU, 3 GB of memory.

**v4.1.0 baseline, six-module harness** (cuts at top-level boundaries 855, 1361, 2456, 3087, 3648; each module re-sets `maxRecDepth 4000000`, and `autoImplicit false` past line 3115, as the single file does): exit 0 on all six; seconds 3, 58, 22, 56, 2, 4; 0 errors; the foot module printed nothing, so its 601 receipts, the environment audit (23 posits) and the crosswalk audit (129 rows, 0 unresolved) all passed.

**v4.2.0, seven-module build of the single file** (cuts 855, 1361, 2456, 3087, 3670, 4592): exit 0 on all seven; seconds 4, 62, 23, 59, 3, 12, 6; 0 errors, 0 warnings; the foot printed nothing, rerun at the close of this session and again silent: 771 receipts, the environment audit unchanged at 23 posits with nothing outside the roster, the `codexCone` guard byte-identical, the crosswalk audit at 151 rows, 0 unresolved.

**Twin v4.2.0.** Built with `gfortran -std=f2018 -O2 -fno-fast-math -ffp-contract=off`, exit 0; default run exit 0; witnessed run exit 0. Section 20, verbatim:
```text
 SECTION 20 · THE SEAT ANCHOR: the seat, the cone, the occupancy law, the two lines of every row
   A1 ball points 28561, fixed by sigma 13
   A3 apexes over the ordered diagram 1, over the reversed 1
   A4 seven resolutions, 289 stage points each: equivariance, image clause, injectivity
   A5 involutions on 1..6 points: 119; admissible maps counted as 3^f 6^(n-f) on each
   A5 equivariant injective bridges of the fixed-point-free involutions on 2, 4, 6 points:    6  24  48
   A7 rival involution: fixed line of 13 expected, found 13; meeting points 1
   A8 three-point frames with symmetric zeros 20: L holds 14, fails 6, grounded counter-models 6
   A8 two-point frame classes 64: cured 32
   A9 P versus NP                 seat [A|RA]  value [HALT-LOCUS-O x1]
   A9 Riemann Hypothesis          seat [A|RA]  value [HALT-LOCUS-XI x1]
   A9 Poincare                    seat [A|RA]  value [SEAL-LOCUS]
   A9 price of the owed bits at 300 K: 63161535471731922620980200 x 10^-45 J
   A10 wholly odd targets on k = 1..6 orbits:    2   4   8  16  32  64
   A10 record-target pairs on three and four points 1360, barriers 870

```
Closing lines, verbatim:
```text
 TWIN BATTERY, Lean-native sections   checks 165   failures 0
 THE BATTERY   checks 248   failures 0
 BATTERY-JSON: {"checks":1123,"failures":0,"mode":"sealed"}
fTOE KINETIC DEMONSTRATION: all batteries pass.
 VERDICT: IT FROM BIT REFUTED, EXHAUSTIVE.
 VERDICT: IT FROM IT VERIFIED ON THE CANONICAL FRAME.
 THE TWIN LOAD IS PROVEN. 165 Lean-native checks, 0 failures; four witnesses to exit 0.
```

**Vacuity lint.**
```text
v4.1.0 twin:
vacuity lint: 2 vacuous checks
  line 564 (assert): 4 - 6 + 4 == 2
  line 1101 (assert): 16 == 2**4
v4.2.0 twin:
vacuity lint: 0 vacuous checks
```

## Manifest

| File | sha256 | Lines |
|---|---|---|
| `Codex_v4_2_0.lean` | `53fde25209863f6b38f93b66636617b60834ad0fbad56a312bdcb165bf1e35c5` | 6981 |
| `Codex_v4_2_0_seat_anchor_layer.lean` | `5604c101d3331210129928c5a95a16488ba3da3ba0603ca46b320f072b5fbe6b` | 921 |
| `Codex_Twin_v4_2_0.f90` | `935af3d439e881c6bff5881de769920a6d8839e7695db7d12e356f16e854ccff` | 7258 |
| `twin_apex.f90` | `15b2cf52a53e7709e0123e70a1a89453851548e3060e35a7a3b9df517f9e0fbb` | 507 |
| `vacuity_lint.py` | `feaefea3ceb67eb09a4bbbad70678900509e5b13bb682fa55b82b52766e1146e` | 71 |

## v4.2.2 · the router's gloss frozen

Lean surface sha256 227dce180a4c399e65c7da6062c1fa900cbb25f62fefb5a9c9915b01f25e0e40. Seat-anchor layer sha256 7a8c4631f7270462b3db392c9abdd82600e76d2bced08e176d3ed8ba79746c25. Twin unchanged, sha256 935af3d439e881c6bff5881de769920a6d8839e7695db7d12e356f16e854ccff. Two comments change and nothing else: the fifth heading of the seat-anchor layer and the docstring of APEX.router_at_the_seat, both now reading the router bit on each row's native involution through the occupancy of the seat. Codex6 rebuilt exit 0 in 36 seconds and Codex7 rebuilt exit 0 in 7 seconds, errors 0, the 771 #guard_msgs of Codex7 passing; Codex1 to Codex5 are unchanged in text and carried from the v4.2.0 build. Every statement and every receipt is unchanged.

## v4.3.0 · the RH engine in the Code Block

Lean surface sha256 2d7ea3256a205baec5c57eefaf76126dae5b7338cea97020dfef867244d5c0c3, 8165 lines: modules one to seven unchanged in text, and the eighth, Codex8, the final paper's RA_Li_Bridge.lean with its seventy-five #print axioms lines pinned under #guard_msgs and the engine cone RHEngine.engineCone on propext and Quot.sound alone. All eight modules rebuilt in sequence on one machine, exit 0, errors 0, warnings 0: Codex1 exit 0 seconds 2 log-bytes 563;Codex2 exit 0 seconds 59 log-bytes 844;Codex3 exit 0 seconds 23 log-bytes 3368;Codex4 exit 0 seconds 58 log-bytes 114 errors 0 warnings 0;Codex5 exit 0 seconds 2 log-bytes 0 errors 0 warnings 0;Codex6 exit 0 seconds 11 log-bytes 0 errors 0 warnings 0;Codex7 exit 0 seconds 7 log-bytes 0 errors 0 warnings 0;Codex8 exit 0 seconds 2 log-bytes 0 errors 0 warnings 0; 847 #guard_msgs silent. Twin sha256 8a1732543490b7ecd71e8499ca33b54a7e4fa42b19926fd69f80e87d49df3cbf: Section 21 added, 186 Lean-native checks, 0 failures, THE BATTERY 248 and 0, BATTERY-JSON 1123 and 0, four witnesses to exit 0.

## v4.4.0 · the sealed RH row

Engine `RA_Li_Bridge.lean`, the paper's final sealed edition, Zenodo record 22929637: 1058 lines, sha256 `f2d0f4e33e82ad5db4afa6f4d12cfb93619354bec0ffb32efac8f7be3ef18f03`, rebuilt byte for byte from the record's Appendix A against its printed digest. Core Lean 4.19.0, exit 0, 79 receipts: 57 axiom-free, 2 on propext, 20 on propext and Quot.sound; Parts XI to XIV carry 30, 27 axiom-free. The adjudication `RA_Li_Bridge_Retirement.lean` recompiles against it: A1 on propext and Quot.sound, A2 axiom-free.

Modules: Codex1 to Codex7 unchanged; Codex8 1233 lines, sha256 156a35057604e829, the engine with 79 pins and the cone on propext and Quot.sound. Clean sequential build, `modules/build440.sh`, log `modules/fullbuild.txt`: Codex1 exit 0 seconds 3;Codex2 exit 0 seconds 71;Codex3 exit 0 seconds 27;Codex4 exit 0 seconds 69;Codex5 exit 0 seconds 3;Codex6 exit 0 seconds 14;Codex7 exit 0 seconds 7;Codex8 exit 0 seconds 3. Surface `Codex_v4_4_0.lean`: 8213 lines, sha256 9dc012cdda9a8189, 851 pins.

Twin `Codex_Twin_v4_4_0.f90`, sha256 f30bb43388f69b21: gfortran -std=f2018 -O2 -fno-fast-math -ffp-contract=off, exit 0, no messages; 190 Lean-native checks and 0 failures, THE BATTERY 248 and 0, BATTERY-JSON 1123 and 0, four witnesses to exit 0. Section 21 gains R8, the logical form executed exhaustively, 25 checks.

Codex v4.4.0: extraction bit-exact, the Lean and Fortran blocks equal to the files above. Audit: held cycle v430, SEALED-ROUND at round 6, SELF grade.

## v4.5.0 · the directional can't

`Directional_Cant.lean`, the architect's file: 60 lines, sha256 `eb4f0ced664d1bb7d39c1ebea0521c1a0c0e89f10727d0fabcfe67b543393e2a`. Core Lean 4.19.0, exit 0, 5 receipts: `cant_refute_seals` and `asymmetry` on propext, Classical.choice and Quot.sound; `cant_refute_seals_dec`, `rh_iff_cant_refute` and `cant_prove_does_not_seal_false` axiom-free; no axiom declared.

Module Codex9: 87 lines, sha256 54e5fd46816b868a, the file carried whole with its five receipts pinned and the cone `DirCantCone.dirCone` on propext, Classical.choice and Quot.sound; built on the eight modules of v4.4.0 at exit 0 in 1 second, silent. Codex1 to Codex8 unchanged. `modules/build450.sh` rebuilds all nine in sequence. Surface `Codex_v4_5_0.lean`: 8299 lines, sha256 ea4f15760bbcb9c8, 857 pins.

Twin `Codex_Twin_v4_5_0.f90`, sha256 32d38f793b422135: gfortran -std=f2018 -O2 -fno-fast-math -ffp-contract=off, exit 0, no messages; 194 Lean-native checks and 0 failures, BATTERY-JSON 1123 and 0, four witnesses to exit 0. Section 22, module `twin_dircant`, runs the two fields and the five theorems on the eight finite settings, four checks.

Codex v4.5.0: extraction bit-exact. Audit: round 7 of cycle v430, the post-landing round of the architect's amendment, SEALED-ROUND at SELF grade.
