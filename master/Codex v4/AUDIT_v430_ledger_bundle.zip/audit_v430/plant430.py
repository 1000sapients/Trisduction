# Plants the committed controls of one round into a seeded copy. Mechanical: each control's site is the first
# eligible current-prose line in its section of twelve, or the nearest following section that has one.
import re, json, sys
from battery430 import HIST
SITES = {'ARITH': [(r'entries_out \((\d+)\)', lambda m: 'entries_out (%d)' % (int(m.group(1)) + 10)),
                   (r'(\d+) axiom receipts: (\d+) axiom-free', lambda m: '%s axiom receipts: %d axiom-free' % (m.group(1), int(m.group(2)) + 10)),
                   (r'(?<!\+ )(\d+) \+ (\d+) = (\d+)', lambda m: '%s + %s = %d' % (m.group(1), m.group(2), int(m.group(3)) + 10))],
         'DRIFT': [(r'outside the economy', lambda m: 'inside the economy'), (r'compartment I, closure-rowed', lambda m: 'compartment I, world-rowed')],
         'SCOPE': [(r'exhibited on two frames', lambda m: 'proved on every frame'), (r'\[⟀ S\] on its third clause', lambda m: '[⟀ T] on its third clause')]}
def plant(entry, sealed, out, log):
    L = open(entry, encoding='utf-8').read().split('\n'); n = len(L); cur = [True] * n; code = False; start = 0
    for i, l in enumerate(L):
        if l.startswith('```'): code = not code; cur[i] = False; continue
        if code: cur[i] = False; continue
        if not l.strip(): start = i + 1; continue
        if L[start].lstrip().startswith(HIST): cur[i] = False
    ctl = json.load(open(sealed)); used = set(); rec = []
    for c in ctl['controls'] if isinstance(ctl, dict) and 'controls' in ctl else ctl:
        k = int(c['section']); done = False
        for step in range(12):
            sec = (k - 1 + step) % 12; lo, hi = sec * n // 12, (sec + 1) * n // 12
            for i in range(lo, hi):
                if not cur[i] or i in used: continue
                for pat, fn in SITES[c['kind']]:
                    m = re.search(pat, L[i])
                    if m and ('[.]' in L[i] or c['kind'] != 'DRIFT' or 'compartment' in pat):
                        L[i] = L[i][:m.start()] + fn(m) + L[i][m.end():]; used.add(i); rec.append({'id': c['id'], 'kind': c['kind'], 'section': k, 'line': i + 1, 'pattern': pat}); done = True; break
                if done: break
            if done: break
        if not done: rec.append({'id': c['id'], 'kind': c['kind'], 'section': k, 'line': None})
    open(out, 'w', encoding='utf-8').write('\n'.join(L)); json.dump(rec, open(log, 'w'), indent=1); return rec
if __name__ == '__main__':
    print(plant(*sys.argv[1:5]))
