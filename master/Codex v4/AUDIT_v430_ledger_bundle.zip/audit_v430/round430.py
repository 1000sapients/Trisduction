# One round of cycle v430 up to the close: commit, plant, prosecute the seeded copy, leak-scan, arbitrate with
# leak-safe matching on both sides, reveal. The close is left to the ledger after findings are filed.
import json, subprocess, sys, battery430 as b, plant430
N, regs, cand = int(sys.argv[1]), sys.argv[2].split(','), sys.argv[3]
manual = json.load(open(sys.argv[4])) if len(sys.argv) > 4 and not sys.argv[4].startswith('--') else {'rows': [], 'text': ''}
sh = lambda *a: subprocess.run(list(a), capture_output=True, text=True).stdout
if '--resume' in sys.argv: P = json.load(open('audit_v430/plants_r%d.json' % N)); print('resumed on the committed round-%d controls and seeded copy' % N)
else:
    print([l for l in sh('python3', 'seed_controls.py', 'commit', '--round', str(N), '--cycle', 'v430', '--grade', 'SELF').split('\n') if 'COMMITTED' in l][0])
    P = plant430.plant(cand, 'audit_v430/controls_r%d.sealed.json' % N, 'seeded_r%d.md' % N, 'audit_v430/plants_r%d.json' % N)
S = open('seeded_r%d.md' % N, encoding='utf-8').read(); K = open(cand, encoding='utf-8').read()
HS = b.run(S, regs); HK = b.run(K, regs); json.dump({'seeded': HS, 'candidate': HK}, open('hits_r%d.json' % N, 'w'), indent=1)
rows = [(h['register'], h['claim'], h['mechanism'], h['severity'], h['falsifier']) for h in HS] + [tuple(r) for r in manual['rows']]
tbl = '\n'.join('| P-%d | %s | %s | %s | %s | %s |' % ((k,) + tuple(x.replace('|', '/')[:300] for x in (r[0], r[1], r[2], r[3], r[4]))) for k, r in enumerate(rows, 1))
txt = ('# Prosecution, round %d · registers %s · read against the seeded copy\n\n' % (N, ', '.join(regs)) + manual['text'] + '\n\n| id | register | target | mechanism | severity | minimal falsifier |\n|---|---|---|---|---|---|\n' + tbl + '\n')
open('prosecution_r%d.md' % N, 'w', encoding='utf-8').write(b.neutral(txt))
print(sh('python3', 'audit_ledger.py', 'leakscan', '--file', 'prosecution_r%d.md' % N).strip().split('\n')[-1][:70])
SL = S.split('\n'); only = [h for h in HS if h not in HK]; caught = []
for c in P:
    line = b.neutral(SL[c['line'] - 1]) if c['line'] else ''
    m = [k for k, h in enumerate(HS, 1) if h in only and h['mechanism'].split(': ', 1)[-1][:40] in line]
    print('control %s %s line %s -> %s' % (c['id'], c['kind'], c['line'], 'CAUGHT by P-%d' % m[0] if m else 'MISSED'))
    if m: caught.append(c['id'])
print('battery hits: seeded %d, unseeded candidate %d; manual rows %d' % (len(HS), len(HK), len(manual['rows'])))
for k, h in enumerate(HS, 1): print('  P-%d %s %s | %s' % (k, h['register'], h['severity'], h['mechanism'][:120]))
for k, r in enumerate(manual['rows'], len(HS) + 1): print('  P-%d %s %s | %s' % (k, r[0], r[3], r[2][:120]))
print([l for l in sh('python3', 'seed_controls.py', 'reveal', '--round', str(N), '--cycle', 'v430', '--caught', ','.join(caught)).split('\n') if l.strip()][:5])
open('caught_r%d.txt' % N, 'w').write('%d' % len(caught))
