import re, hashlib, os, shutil, sys
sys.path.insert(0, '/tmp/audit430'); from v450_texts import *; import v440_texts as V4
F4 = '/mnt/user-data/outputs/v4_4_0_forge'; ST = '/tmp/stage450'; K = '/tmp/kit450'
sha = lambda s: hashlib.sha256(s.encode('utf-8')).hexdigest()
def rep(s, o, n, k=1, tag=''):
    c = s.count(o); assert c >= 1 and (k is None or c == k), (tag, c, o[:70]); return s.replace(o, n)
LEAN = open(K + '/Codex_v4_5_0.lean', encoding='utf-8').read(); FORT = open(K + '/Codex_Twin_v4_5_0.f90', encoding='utf-8').read()
L4 = open('/tmp/kit440/Codex_v4_4_0.lean', encoding='utf-8').read(); F4T = open('/tmp/kit440/Codex_Twin_v4_4_0.f90', encoding='utf-8').read()
DC = open('/tmp/dircant/Directional_Cant.lean', encoding='utf-8').read(); C9 = open(K + '/modules/Codex9.lean', encoding='utf-8').read()
def card(s):
    i = s.index('*TERMINAL FOR THE RECORD.*'); s = s[:i] + DIRCANT + '\n\n' + s[i:]
    for o, n, t in [(KEYCL_OLD, KEYCL_NEW, 'key clause'), (TERM_A_OLD, TERM_A_NEW, 'term a'), (TERM_B_OLD, TERM_B_NEW, 'term b'), (GR_A_OLD, GR_A_NEW, 'grade a'), (GR_B_OLD, GR_B_NEW, 'grade b'), (REFS_OLD, REFS_NEW % sha(DC), 'refs')]:
        s = rep(s, o, n, 1, t)
    return s
def seat(s):
    s = rep(s, '`Codex.lean`, sha256 `%s…`, 8,213 lines' % sha(L4)[:16], '`Codex.lean`, sha256 `%s…`, 8,299 lines' % sha(LEAN)[:16], 1, 'seat surface')
    s = rep(s, "`Codex_Twin.f90`, sha256 `%s…`, Sections 20 and 21, the seat anchor's batteries A1 to A10 and the RH engine's twenty-five checks, 190 Lean-native checks, 0 failures." % sha(F4T)[:16],
            "`Codex_Twin.f90`, sha256 `%s…`, Sections 20 to 22, the seat anchor's batteries A1 to A10, the RH engine's twenty-five checks and the directional can't's four, 194 Lean-native checks, 0 failures." % sha(FORT)[:16], 1, 'seat twin')
    return s.replace('The Code Block of TRISDUCTION_Master_Codex_v4_4_0.md', 'The Code Block of TRISDUCTION_Master_Codex_v4_5_0.md')
k = open(F4 + '/master/Codex v4/TRISDUCTION_Master_Codex_v4_4_0.md', encoding='utf-8').read()
k = seat(card(k)); k = rep(k, D63_OLD, D63_NEW, 1, 'd63')
k = rep(k, sha(L4), sha(LEAN), 1, 'C.1 surface'); k = rep(k, sha(F4T), sha(FORT), 1, 'C.1 twin')
k = rep(k, 'Codex8 `156a35057604e829`.', 'Codex8 `156a35057604e829`, Codex9 `%s`.' % sha(C9)[:16], 1, 'C.1 modules')
k = rep(k, 'The file is the concatenation of eight modules', 'The file is the concatenation of nine modules', 1, 'C.1 nine')
k = rep(k, 'The single file and the eight modules carry the same text', 'The single file and the nine modules carry the same text', 1, 'C.1 same text')
k = rep(k, 'all eight rebuilt at v4.4.0 in sequence on one machine', 'all eight rebuilt at v4.4.0 in sequence on one machine; Codex9 exit 0 seconds 1, built on them at v4.5.0', 1, 'C.1 timing')
k = rep(k, 'checks 190   failures 0', 'checks 194   failures 0', 1, 'C.1 count'); k = rep(k, 'THE TWIN LOAD IS PROVEN. 190 Lean-native checks', 'THE TWIN LOAD IS PROVEN. 194 Lean-native checks', 1, 'closing')
a = 'and 22 + 1 = 23 value bits. No value token moved and no tier moved. ΔM = 0.'; k = rep(k, a, a + '\n\n' + P450 % sha(LEAN)[:16], 1, 'p450')
k = rep(k, V4.RECEIPT_440, V4.RECEIPT_440 + RECEIPT_450, 1, 'receipt')
k = rep(k, 'version: v4.4.0', 'version: v4.5.0'); k = rep(k, 'Master Codex, v4.4.0', 'Master Codex, v4.5.0'); k = rep(k, 'TRISDUCTION_Master_Codex_v4_4_0.md', 'TRISDUCTION_Master_Codex_v4_5_0.md', None)
L0 = re.search(r'^```lean$\n(.*?)^```$', k, re.M | re.S).group(1); F0 = re.search(r'^```fortran$\n(.*?)^```$', k, re.M | re.S).group(1); assert L0 == L4 and F0 == F4T
k = k.replace('```lean\n' + L0 + '```', '```lean\n' + LEAN + '```', 1).replace('```fortran\n' + F0 + '```', '```fortran\n' + FORT + '```', 1)
assert re.search(r'^```lean$\n(.*?)^```$', k, re.M | re.S).group(1) == LEAN and re.search(r'^```fortran$\n(.*?)^```$', k, re.M | re.S).group(1) == FORT
open('/tmp/audit430/TRISDUCTION_Master_Codex_v4_5_0.md', 'w', encoding='utf-8').write(k)
print('codex v4.5.0: %d bytes sha %s | files named v4_5_0: %d' % (len(k.encode()), sha(k)[:16], k.count('TRISDUCTION_Master_Codex_v4_5_0.md')))
for d in ('protocols/RH One Bit', 'master', 'psp'): os.makedirs(ST + '/' + d, exist_ok=True)
for f in os.listdir(F4 + '/protocols/RH One Bit'): shutil.copy(F4 + '/protocols/RH One Bit/' + f, ST + '/protocols/RH One Bit/' + f)
open(ST + '/protocols/RH One Bit/Directional_Cant.lean', 'w', encoding='utf-8').write(DC)
m = open(F4 + '/master/TRISDUCTION_Master_Codex_Unabridged_v3_43_0.md', encoding='utf-8').read(); m = seat(card(m))
if D63_OLD in m: m = m.replace(D63_OLD, D63_NEW)
m = rep(m, V4.MOTHER_MINOR_343, V4.MOTHER_MINOR_343 + '\n\n' + MOTHER_MINOR_344, 1, 'mother minor')
open(ST + '/master/TRISDUCTION_Master_Codex_Unabridged_v3_44_0.md', 'w', encoding='utf-8').write(m)
p = card(open(F4 + '/psp/APEX-PSP-RH-ONE-GAP-01.md', encoding='utf-8').read())
p = rep(p, 'Unabridged_v3_43_0.md` and carried at II.5 of `master/Codex v4/TRISDUCTION_Master_Codex_v4_4_0.md`', 'Unabridged_v3_44_0.md` and carried at II.5 of `master/Codex v4/TRISDUCTION_Master_Codex_v4_5_0.md`', 1, 'psp seat')
i = p.index('## Engine\n\n') + len('## Engine\n\n'); j = p.index('\n', i); p = p[:j] + ' The architect\'s `Directional_Cant.lean`, sha256 `%s`, 60 lines, stands beside them in the same folder and in the Code Block as its ninth module.' % sha(DC) + p[j:]
open(ST + '/psp/APEX-PSP-RH-ONE-GAP-01.md', 'w', encoding='utf-8').write(p)
s = seat(open(F4 + '/psp/APEX-PSP-SEAT-ANCHOR-01.md', encoding='utf-8').read())
s = rep(s, sha(L4), sha(LEAN), None, 'sa surface'); s = rep(s, sha(F4T), sha(FORT), None, 'sa twin')
s = rep(s, 'master/Codex v4/TRISDUCTION_Master_Codex_v4_4_0.md', 'master/Codex v4/TRISDUCTION_Master_Codex_v4_5_0.md', None, 'sa file'); s = rep(s, 'Unabridged_v3_43_0.md', 'Unabridged_v3_44_0.md', None, 'sa mother')
open(ST + '/psp/APEX-PSP-SEAT-ANCHOR-01.md', 'w', encoding='utf-8').write(s)
shutil.copy(F4 + '/psp/APEX-PSP-PARITY-NORMAL-FORM-01.md', ST + '/psp/APEX-PSP-PARITY-NORMAL-FORM-01.md')
print('staged: Mother v3.44.0 %d bytes, psp one-gap %d, seat-anchor %d, protocols %s' % (len(m.encode()), len(p.encode()), len(s.encode()), sorted(os.listdir(ST + '/protocols/RH One Bit'))))
