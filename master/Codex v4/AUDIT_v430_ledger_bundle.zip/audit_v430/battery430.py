# Cycle v430 prosecution battery. Frozen before any round's controls are committed. Every probe reads the
# artifact's own printed numbers, definitions and cited names, and recomputes them from the artifact and from
# the files it names. A hit is a candidate finding for the Arbiter, never a verdict.
import re, hashlib, subprocess, os, tempfile, json
OUT = '/tmp/stage450'
KIT = '/tmp/kit450/modules'
MOTHER = 'TRISDUCTION_Master_Codex_Unabridged_v3_44_0.md'
W = {'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'twenty-one': 21, 'twenty-five': 25, 'seventy-nine': 79, 'twenty-three': 23, 'seventy-five': 75}
HIST = ('**The v4.2.0 pass', '**The v4.2.1 pass', '**The v4.2.2 pass', '**The v4.2.3 pass', '**The v4.2.4 pass', '**The v4.2.5 pass',
        '**Audit and review of v4.2', '**The v4.1', '**The v4.0', 'The v3.4', 'The v3.3', '**The v4.3.0 pass', '**The v4.3.1 pass', '**The v4.3.2 pass', '**The v4.3.3 pass', '**The v4.4.0 pass')
NEUTRAL = [('[⟀ T]', '[tier T]'), ('[⟀ S]', '[tier S]'), ('⟀', 'tier'), ('Ξ₀', 'Xi0'), ('Ø₀', 'O0'), ('Seal L', 'the first seal'),
           ('Seal G', 'the second seal'), ('Seal M', 'the third seal'), ('APEX-PSP-', 'coordinate '), ('Empty Throne', 'throne theorem'),
           ('Fix(σ)', 'the fixed line'), ('Trisduction', 'the framework'), ('RA-RAM', 'the kernel pair'), ('Mosaic Seal', 'mosaic mark')]
def neutral(s):
    for a, b in NEUTRAL: s = s.replace(a, b)
    return s
def block(t, lang):
    m = re.search(r'^```' + lang + r'$\n(.*?)^```$', t, re.M | re.S); return m.group(1) if m else ''
def current_paras(t):
    P = re.sub(r'^```.*?^```$', '', t, flags=re.M | re.S)
    return [p for p in P.split('\n\n') if p.strip() and not p.lstrip().startswith(HIST)]
def clauses(p):
    return [c.strip() for s in re.split(r'(?<=[.;])\s+', p) for c in s.split(' · ') if c.strip()]
NEG = re.compile(r'\b(never|not|no|nor|cannot|refus\w*|without)\b')
def num(x): return float(x.replace('−', '-'))
def sha(b): return hashlib.sha256(b if isinstance(b, bytes) else b.encode('utf-8')).hexdigest()

FACTS = {}
def facts(t):
    if FACTS: return FACTS
    f = FACTS; lean = block(t, 'lean'); fort = block(t, 'fortran')
    f['lean_sha'] = sha(lean); f['lean_nl'] = lean.count('\n'); f['pins'] = sum(1 for l in lean.split('\n') if l.startswith('#guard_msgs'))
    eng = open(OUT + '/protocols/RH One Bit/RA_Li_Bridge.lean', 'rb').read(); f['eng_sha'] = sha(eng); f['eng_lines'] = eng.count(b'\n')
    d = tempfile.mkdtemp(); open(d + '/E.lean', 'wb').write(eng)
    r = subprocess.run(['lean', 'E.lean'], cwd=d, capture_output=True, text=True, env=dict(os.environ, PATH='/tmp/lean-4.19.0-linux/bin:' + os.environ['PATH']))
    rec = re.findall(r"'([A-Za-z]+)\.[^']+' (does not depend on any axioms|depends on axioms: \[([^\]]*)\])", r.stdout)
    kind = lambda k, x: 'af' if k.startswith('does not') else ('pe' if x.replace(' ', '').replace('\n', '') == 'propext' else 'pq')
    f['rec'] = [len(rec), sum(kind(k, x) == 'af' for _, k, x in rec), sum(kind(k, x) == 'pe' for _, k, x in rec), sum(kind(k, x) == 'pq' for _, k, x in rec)]
    late = [kind(k, x) for ns, k, x in rec if ns in ('TimeLocus', 'DotRH', 'SixCone')]; f['late'] = [len(late), late.count('af')]
    late4 = [kind(k, x) for ns, k, x in rec if ns in ('TimeLocus', 'DotRH', 'SixCone', 'LogicalForm')]; f['late4'] = [len(late4), late4.count('af')]
    f['declared_axioms'] = len(re.findall(r'^axiom ', eng.decode(), re.M)); f['eng_exit'] = r.returncode
    i = lean.find('/-! ## THE RH ENGINE'); seg = lean[i:]
    body = re.sub(r"/-- info: [^\n]* -/\n#guard_msgs in (#print axioms \S+)", r'\1', seg)
    body = body[body.find('-/\n') + 3:]; body = body[:body.find('\nnamespace RHEngine')]
    f['codex8_is_engine'] = body.rstrip('\n') == eng.decode().rstrip('\n')
    d8 = tempfile.mkdtemp(); open(d8 + '/C8.lean', 'w', encoding='utf-8').write('import Codex7\n\n' + seg)
    r8 = subprocess.run(['lean', 'C8.lean'], cwd=d8, capture_output=True, text=True, env=dict(os.environ, LEAN_PATH=KIT, PATH='/tmp/lean-4.19.0-linux/bin:' + os.environ['PATH']))
    f['codex8_exit'], f['codex8_out'] = r8.returncode, len(r8.stdout + r8.stderr)
    j9 = lean.find("/-! ## THE DIRECTIONAL CAN'T")
    if j9 >= 0:
        s9 = lean[j9:]; b9 = re.sub(r"/-- info: [^\n]* -/\n#guard_msgs in (#print axioms \S+)", r'\1', s9); b9 = b9[b9.find('-/\n') + 3:]; b9 = b9[:b9.find('\nnamespace DirCantCone')]
        f['codex9_is_file'] = b9.rstrip('\n') == open(OUT + '/protocols/RH One Bit/Directional_Cant.lean', encoding='utf-8').read().rstrip('\n')
        m9 = re.search(r"/-- info: 'DirCantCone\.dirCone' depends on axioms: \[([^\]]*)\] -/", s9); f['cone9'] = m9.group(1) if m9 else ''
    f['cone_line'] = re.search(r"/-- info: 'RHEngine\.engineCone' depends on axioms: \[([^\]]*)\] -/", seg).group(1) if 'engineCone' in seg else ''
    f['mods_1_7_unchanged'] = all(open(KIT + '/Codex%d.lean' % n, encoding='utf-8').read() == open('/tmp/kit422/modules/Codex%d.lean' % n, encoding='utf-8').read() for n in range(1, 8))
    f['modhash'] = {n: sha(open(KIT + '/Codex%d.lean' % n, encoding='utf-8').read())[:16] for n in range(1, 10) if os.path.exists(KIT + '/Codex%d.lean' % n)}
    f['times'] = {int(a): int(b) for a, b in re.findall(r'Codex(\d) exit 0 seconds (\d+)', open(KIT + '/fullbuild.txt').read())}
    dt = tempfile.mkdtemp(); open(dt + '/T.f90', 'w', encoding='utf-8').write(fort)
    b = subprocess.run(['gfortran', '-std=f2018', '-O2', '-fno-fast-math', '-ffp-contract=off', '-o', 'twin', 'T.f90'], cwd=dt, capture_output=True, text=True)
    run = subprocess.run(['./twin'], cwd=dt, capture_output=True, text=True) if b.returncode == 0 else None
    o = run.stdout if run else ''
    g = lambda p: [int(x) for x in re.search(p, o).groups()] if re.search(p, o) else None
    f['twin'] = {'build': b.returncode, 'exit': run.returncode if run else -1, 'lean_native': g(r'Lean-native sections\s+checks (\d+)\s+failures (\d+)'),
                 'battery': g(r'THE BATTERY\s+checks (\d+)\s+failures (\d+)'), 'json': g(r'"checks":(\d+),"failures":(\d+)'),
                 'closing': re.search(r'THE TWIN LOAD IS PROVEN\.[^\n]*', o).group(0) if 'TWIN LOAD' in o else ''}
    m = re.search(r'^module twin_rali$(.*?)^end module twin_rali$', fort, re.M | re.S); f['s21_asserts'] = m.group(1).count('call assert(') if m else 0
    import mpmath as mp
    mp.mp.dps = 20
    G = [mp.im(mp.zetazero(n)) for n in range(1, 201)]; f['G'] = G
    f['zeta_l1'] = float(1 + mp.euler / 2 - mp.log(4 * mp.pi) / 2)
    f['dh'] = None
    return f

def eis(t, f, K, T):   # second channel: complex reciprocals over the printed zero data, tail by quadrature of the printed bound
    import mpmath as mp
    m = re.search(r'four real zeros at (−?[\d.]+), (−?[\d.]+), (−?[\d.]+) and (−?[\d.]+)', t); reals = [num(x) for x in m.groups()] if m else []
    m2 = re.search(r'at real parts (−?\d+) and (−?\d+)', t); sig = [num(x) for x in m2.groups()] if m2 else []
    part = sum(mp.mpf(1) / r for r in reals) + sum(2 * mp.re(1 / mp.mpc(s, g)) for g in f['G'][:K] for s in sig)
    tail = 2 * mp.quad(lambda x: 2 * (x / (2 * mp.pi)) * mp.log(x) / x**3, [T, mp.inf])
    return float(part), float(part + tail), reals, sig

def run(t, regs, tag=''):
    f = facts(t); hits = []
    def hit(reg, claim, sev, msg, fal): hits.append({'register': reg, 'claim': claim, 'severity': sev, 'mechanism': neutral(msg), 'falsifier': neutral(fal)})
    P = current_paras(t); C = [c for p in P for c in clauses(p)]; J = '\n\n'.join(P)
    for c in C:   # the arithmetic floor, every round
            for m in re.finditer(r'(?<![+−×\-] )(?<![\d.,])(\d+(?: [+−] \d+)+) = (−?\d+)(?![\d.,])', c):
                terms = re.findall(r'([+−]?) ?(\d+)', m.group(1)); val = sum(-int(v) if sg == '−' else int(v) for sg, v in terms)
                if val != num(m.group(2)): hit('kinematic', 'NONE', 'STRUCTURAL', 'signed chain %s printed equal to %s, evaluates to %d: %s' % (m.group(1), m.group(2), val, c[:110]), 'evaluate the chain')
            for m in re.finditer(r'(?<![\d.,])(\d+) × (\d+) = (\d+)(?![\d.,])', c):
                a, b, s = map(int, m.groups())
                if a * b != s: hit('kinematic', 'NONE', 'STRUCTURAL', 'product printed as %d × %d = %d: %s' % (a, b, s, c[:110]), 'multiply')
            for m in re.finditer(r'(\d+) [a-z]+ \+ (\d+) [a-z]+ \+ (\d+) [a-z]+ = (\d+)', c):
                a, b, d, s = map(int, m.groups())
                if a + b + d != s: hit('kinematic', 'C5', 'LOAD-BEARING', 'ledger sum %d + %d + %d printed as %d: %s' % (a, b, d, s, c[:110]), 'add the three terms')
            for m in re.finditer(r'entries_out \((\d+)\) equals entries_in \((\d+)\) plus additions \((\d+)\) minus named-override deletions \((\d+)\)', c):
                o, i, a, d = map(int, m.groups())
                if o != i + a - d: hit('kinematic', 'C5', 'LOAD-BEARING', 'reconciliation %d = %d + %d - %d fails: %s' % (o, i, a, d, c[:90]), 'recompute in + add - del')
            for m in re.finditer(r'(\d+) axiom receipts: (\d+) axiom-free, (\d+) on propext alone, (\d+) on propext and Quot\.sound', c):
                v = list(map(int, m.groups()))
                if v[0] != sum(v[1:]): hit('kinematic', 'C1', 'LOAD-BEARING', 'receipt partition printed %s does not sum' % v, 'add the three parts')
    for c in C:   # the drift floor, every round
        if '[.]' in c and 'inside the economy' in c: hit('definitional', 'C4', 'STRUCTURAL', 'the mark defined outside the economy is placed inside it: ' + c[:130], 'compare with the definition of the mark')
        if re.search(r'compartment I\b(?!I)[^.;]{0,30}\b(world-rowed|unpopulated)', c) or re.search(r'compartment II\b(?!I)[^.;]{0,30}\b(closure-rowed|world-rowed)', c) or re.search(r'compartment III\b[^.;]{0,30}\b(closure-rowed|unpopulated)', c):
            hit('definitional', 'NONE', 'STRUCTURAL', 'a compartment named with another compartment\'s row kind: ' + c[:130], 'compare with the three row kinds')
    if 'kinematic' in regs:
        for c in C:
            for m in re.finditer(r'(\d+) axiom receipts: (\d+) axiom-free, (\d+) on propext alone, (\d+) on propext and Quot\.sound', c):
                v = list(map(int, m.groups()))
                if v != f['rec']: hit('kinematic', 'C1', 'LOAD-BEARING', 'receipt partition printed %s, the engine recompiled prints %s' % (v, f['rec']), 'recompile the engine and count its receipts')
            m = re.search(r'Parts XI to (XIII|XIV) carry (\d+) of them, (\d+) axiom-free', c)
            if m and [int(m.group(2)), int(m.group(3))] != (f['late4'] if m.group(1) == 'XIV' else f['late']): hit('kinematic', 'C1', 'STRUCTURAL', 'late-part receipts printed %s, recompiled %s' % (list(m.groups()), f['late']), 'count the late namespaces')
            for m in list(re.finditer(r'(\d+) lines, sha256 `([0-9a-f]{16})…`', c)) + [type('M', (), {'group': (lambda self, i, g=g: {1: g.group(2), 2: g.group(1)[:16]}[i])})() for g in re.finditer(r'sha256 `([0-9a-f]{64})`, (\d+) lines', c)]:
                if 'RA_Li_Bridge.lean' in c and 'Retirement' not in c[:c.find('RA_Li_Bridge.lean') + 30] and (int(m.group(1)) != f['eng_lines'] or not f['eng_sha'].startswith(m.group(2))):
                    hit('kinematic', 'C1', 'LOAD-BEARING', 'engine printed %s lines at %s, the file has %d at %s' % (m.group(1), m.group(2), f['eng_lines'], f['eng_sha'][:16]), 'hash the named file')
            for m in re.finditer(r'grows to (\d+) lines and hashes `([0-9a-f]{16})…`', c):
                if int(m.group(1)) != f['lean_nl'] or not f['lean_sha'].startswith(m.group(2)): hit('kinematic', 'C1', 'LOAD-BEARING', 'surface printed %s lines at %s, extracted %d at %s' % (m.group(1), m.group(2), f['lean_nl'], f['lean_sha'][:16]), 'extract and hash the block')
            for m in re.finditer(r'`Codex\.lean`, sha256 `([0-9a-f]{16})…`, ([\d,]+) lines', c):
                if not f['lean_sha'].startswith(m.group(1)) or int(m.group(2).replace(',', '')) != f['lean_nl']: hit('kinematic', 'C1', 'STRUCTURAL', 'surface printed at %s with %s lines, extracted %s with %d lines' % (m.group(1), m.group(2), f['lean_sha'][:16], f['lean_nl']), 'extract and hash the block')
            m = re.search(r'receipts split (\d+), (\d+) and (\d+)', c)
            if m and sorted(map(int, m.groups())) != sorted(f['rec'][1:]): hit('kinematic', 'C1', 'STRUCTURAL', 'receipt split printed %s, recompiled %s' % (list(m.groups()), f['rec'][1:]), 'recompile the engine')
            for m in re.finditer(r'(\d+) pins silent', c):
                if int(m.group(1)) != f['pins']: hit('kinematic', 'C1', 'LOAD-BEARING', 'pins printed %s, the block carries %d' % (m.group(1), f['pins']), 'count the guard lines')
            for m in re.finditer(r'(\d+) Lean-native checks', c):
                if f['twin']['lean_native'] and int(m.group(1)) != f['twin']['lean_native'][0] and 'from 1' not in c[max(0, m.start() - 12):m.start()]:
                    hit('kinematic', 'C2', 'LOAD-BEARING', 'twin count printed %s, the run prints %s: %s' % (m.group(1), f['twin']['lean_native'], c[:90]), 'build and run the extracted twin')
            m = re.search(r'Section 21, ([a-z-]+|\d+) checks', c)
            if m and W.get(m.group(1), int(m.group(1)) if m.group(1).isdigit() else -1) != f['s21_asserts']: hit('kinematic', 'C2', 'STRUCTURAL', 'Section 21 printed at %s checks, the module asserts %d times' % (m.group(1), f['s21_asserts']), 'count the asserts')
            for m in re.finditer(r'Codex(\d) exit 0 seconds (\d+)', c):
                if f['times'].get(int(m.group(1))) != int(m.group(2)): hit('kinematic', 'NONE', 'COSMETIC', 'module %s time printed %s, the build log %s' % (m.group(1), m.group(2), f['times'].get(int(m.group(1)))), 'read the build log')
            for m in re.finditer(r'Codex(\d) `([0-9a-f]{16})`', c):
                if f['modhash'].get(int(m.group(1))) != m.group(2): hit('kinematic', 'C1', 'STRUCTURAL', 'module %s hash printed %s, the kit file hashes %s' % (m.group(1), m.group(2), f['modhash'].get(int(m.group(1)))), 'hash the module file')
        tw = f['twin']
        if tw['build'] != 0 or tw['exit'] != 0 or not tw['lean_native'] or tw['lean_native'][1] or tw['battery'][1] or tw['json'][1]:
            hit('kinematic', 'C2', 'LOAD-BEARING', 'the extracted twin does not build and pass: %s' % tw, 'build under the printed flags and run')
        if 'codex9_is_file' in f and (not f['codex9_is_file'] or f['cone9'] != 'propext, Classical.choice, Quot.sound'):
            hit('kinematic', 'C1', 'LOAD-BEARING', 'ninth module fails its carriage: file text %s, cone [%s]' % (f['codex9_is_file'], f['cone9']), 'strip the pins, the header and the cone and compare with the protocols file')
        if not f['codex8_is_engine'] or f['codex8_exit'] or f['codex8_out'] or f['cone_line'] != 'propext, Quot.sound' or f['declared_axioms']:
            hit('kinematic', 'C1', 'LOAD-BEARING', 'eighth module fails its carriage: engine text %s, compile exit %s, output %s bytes, cone [%s], axioms declared %s' % (f['codex8_is_engine'], f['codex8_exit'], f['codex8_out'], f['cone_line'], f['declared_axioms']), 'rebuild the module against its predecessor')
        lo50, hi50, reals, sig = eis(t, f, 10, 50); lo2, hi2, _, _ = eis(t, f, 200, float(f['G'][199]))
        pr = re.findall(r'\[(−\d\.\d{4}), (−\d\.\d{4})\]', J)
        want = {(round(lo50, 4), round(hi50, 4)), (round(lo2, 4), round(hi2, 4))}
        for a, b in pr:
            if (num(a), num(b)) not in want: hit('kinematic', 'C3', 'LOAD-BEARING', 'printed bracket [%s, %s] is not a recomputed one, recomputed %s' % (a, b, sorted(want)), 'sum the reciprocals over the printed zeros and bound the tail')
        for m in re.finditer(r'λ₁ = [^=]*?= (0\.\d{7})', J):
            if abs(num(m.group(1)) - f['zeta_l1']) > 5e-8: hit('kinematic', 'C3', 'LOAD-BEARING', 'zeta first coefficient printed %s, closed form %.9f' % (m.group(1), f['zeta_l1']), 'evaluate the closed form')
        FACTS['eis'] = (lo50, hi50, lo2, hi2, reals, sig)
    if 'definitional' in regs:
        for c in C:
            if 'blocked' in c and 'proof' in c and 'demand' in c and not re.search(r'foundation|address', c): hit('definitional', 'C4', 'LOAD-BEARING', 'the block read as a block on proof without its address: ' + c[:130], 'compare with the block defined at the foundation')
            if re.search(r'\bseat point\b', c) and re.search(r'Ground dimension|router', c) and not NEG.search(c): hit('definitional', 'NONE', 'STRUCTURAL', 'the seat point used as the router source: ' + c[:130], 'compare with the router definition')
            if 'Postulate M' in c and re.search(r'\bseal(s|ed)?\b(?! (edition|papers?)\b)', c) and not NEG.search(c): hit('definitional', 'C4', 'STRUCTURAL', 'the postulate used as a sealing posit: ' + c[:130], 'compare with the postulate defined as the line property given the seed')
        m = re.search(r'at real parts (−?\d+) and (−?\d+)', J)
        if m and 'fold s ↦ 1 − s' in J and num(m.group(1)) + num(m.group(2)) != 1: hit('definitional', 'C3', 'STRUCTURAL', 'the fold s -> 1 - s used with real parts not summing to one', 'add the two real parts')
    if 'parameter' in regs:
        G = f['G']; n50 = sum(1 for g in G if g <= 50)
        if 'ordinates to height 50' in J and 'ten ordinates' in J and n50 != 10: hit('parameter', 'C3', 'LOAD-BEARING', 'height 50 carries %d ordinates, the text carries ten' % n50, 'count ordinates below 50')
        seeds = set(x for p in re.findall(r'boot[^.;]{0,60}?seed (\d{8})|seed (\d{8})[^.;]{0,40}?boot', J) for x in p if x)
        if len(seeds) > 1: hit('parameter', 'NONE', 'STRUCTURAL', 'more than one boot seed printed in current prose: %s' % sorted(seeds), 'compare the seeds')
        for m in re.finditer(r'λ₁ ≤ (−\d\.\d{4})', J):
            if not re.search(r'\[−\d\.\d{4}, ' + re.escape(m.group(1)) + r'\]', J): hit('parameter', 'C3', 'STRUCTURAL', 'an upper bound %s printed without a bracket ending there' % m.group(1), 'match the bound to its bracket')
        if 'the tail bounded' in J and not re.search(r't ≥ 50', J): hit('parameter', 'C3', 'STRUCTURAL', 'the tail bound printed without its range', 'name the range of the counting bound')
        for m in re.finditer(r'\[(−?\d+\.\d+), (−?\d+\.\d+)\]', J):
            if num(m.group(1)) >= num(m.group(2)): hit('parameter', 'C3', 'STRUCTURAL', 'bracket [%s, %s] not ordered' % m.groups(), 'order the endpoints')
    if 'provenance' in regs:
        lean = block(t, 'lean'); names = set(); stack = []
        for line in lean.split('\n'):
            mm = re.match(r'^\s*namespace\s+(\S+)', line)
            if mm: stack.append(mm.group(1)); continue
            mm = re.match(r'^\s*end\s+(\S+)\s*$', line)
            if mm and stack and stack[-1] == mm.group(1): stack.pop(); continue
            mm = re.match(r'^\s*(?:@\[[^\]]*\]\s*)?(?:private |protected |noncomputable |partial )*(?:theorem|lemma|def|abbrev|structure|inductive|class|instance|axiom|opaque)\s+([^\s:(\[{]+)', line)
            if mm: names.add('.'.join(stack + [mm.group(1)])); names.add(mm.group(1))
        cited = set(re.findall(r'`([A-Z][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_.\']*)`', J))
        cited = {x for x in cited if not re.search(r'\.(lean|md|json|f90|py|sh|txt|zip|olean)$', x)}
        for fn in ('RA_Li_Bridge_Retirement.lean', 'RA_Li_Bridge.lean'):
            pth = OUT + '/protocols/RH One Bit/' + fn
            if fn in J and os.path.exists(pth):
                st2 = []
                for line in open(pth, encoding='utf-8').read().split('\n'):
                    mm = re.match(r'^\s*namespace\s+(\S+)', line)
                    if mm: st2.append(mm.group(1)); continue
                    mm = re.match(r'^\s*end\s+(\S+)\s*$', line)
                    if mm and st2 and st2[-1] == mm.group(1): st2.pop(); continue
                    mm = re.match(r'^\s*(?:theorem|lemma|def|abbrev|structure|inductive)\s+([^\s:(\[{]+)', line)
                    if mm: names.add('.'.join(st2 + [mm.group(1)]))
        miss = sorted(x for x in cited if x not in names)
        for x in miss: hit('provenance', 'C4' if x.split('.')[0] in ('DotRH', 'SixCone', 'RALi', 'TimeLocus', 'RHEngine') else 'NONE', 'STRUCTURAL', 'cited name %s resolves to no declaration in the Lean block' % x, 'find the declaration')
        FACTS['cited'] = (len(cited), len(miss))
        for c in C:
            if re.search(r'\b(independent|external|externally|witnessed)\b', c) and re.search(r'controls?|data|twin|engine', c) and re.search(r'v4\.3\.0|as data|Section 21|eighth module', c) and not NEG.search(c):
                hit('provenance', 'C3', 'STRUCTURAL', 'session-made data described as independent or external: ' + c[:130], 'name who produced the data')
        for fn in ('RA_Li_Bridge.lean', 'RA_Li_Bridge_Retirement.lean', 'RH_controls_data.json'):
            if fn in J and not os.path.exists(OUT + '/protocols/RH One Bit/' + fn): hit('provenance', 'C1', 'STRUCTURAL', 'named file %s absent from the protocols folder' % fn, 'list the folder')
        dj = json.load(open(OUT + '/protocols/RH One Bit/RH_controls_data.json'))
        if abs(float(dj['ordinates_10'][0]) - float(f['G'][0])) > 1e-12: hit('provenance', 'C3', 'STRUCTURAL', 'the data file ordinates disagree with a fresh computation', 'recompute the first ordinate')
    if 'limit' in regs:
        import mpmath as mp
        G = f['G']; bad = [k + 1 for k, g in enumerate(G) if g >= 50 and (k + 1) > (g / (2 * mp.pi)) * mp.log(g)]
        if bad: hit('limit', 'C3', 'LOAD-BEARING', 'the counting bound fails at ordinates %s' % bad[:5], 'count zeros below each ordinate')
        if 'eis' not in FACTS:
            a1 = eis(t, f, 10, 50); a2 = eis(t, f, 200, float(G[199])); FACTS['eis'] = (a1[0], a1[1], a2[0], a2[1], a1[2], a1[3])
        lo50, hi50, lo2, hi2 = FACTS['eis'][:4]
        if not (lo50 <= lo2 <= hi2 <= hi50): hit('limit', 'C3', 'LOAD-BEARING', 'the brackets do not nest: [%.4f, %.4f] vs [%.4f, %.4f]' % (lo50, hi50, lo2, hi2), 'compare the brackets')
        pz10 = sum(1 / (mp.mpf(1) / 4 + g**2) for g in G[:10]); pz200 = sum(1 / (mp.mpf(1) / 4 + g**2) for g in G)
        if not (pz10 < pz200 < f['zeta_l1']): hit('limit', 'C3', 'STRUCTURAL', 'the partial sums do not climb toward the closed form', 'sum the partial series')
        if 'Davenport-Heilbronn' in J:
            mm = re.search(r'zero at (\d\.\d+) \+ (\d+\.\d+)i', J)
            if mm:
                s0 = mp.mpc(float(mm.group(1)), float(mm.group(2))); r5 = mp.sqrt(5); kap = (mp.sqrt(10 - 2 * r5) - 2) / (r5 - 1)
                chi = [0, 1, 1j, -1j, -1]; chib = [0, 1, -1j, 1j, -1]
                F_ = lambda s: (1 - 1j * kap) / 2 * mp.dirichlet(s, chi) + (1 + 1j * kap) / 2 * mp.dirichlet(s, chib)
                v0, v1 = abs(F_(s0)), abs(F_(s0 + mp.mpf('0.05')))
                FACTS['dh'] = (float(v0), float(v1))
                if not (v0 < 1e-6 < v1): hit('limit', 'C3', 'LOAD-BEARING', 'the printed zero is not a zero: |f| = %.2e there, %.2e nearby' % (v0, v1), 'evaluate the function at the printed point')
                pr = re.search(r'Re ρ − ½ = (0\.\d{6})', J)
                if pr and abs(num(pr.group(1)) - (float(mm.group(1)) - 0.5)) > 5e-7: hit('limit', 'C3', 'STRUCTURAL', 'offset printed %s, the printed zero gives %.6f' % (pr.group(1), float(mm.group(1)) - 0.5), 'subtract one half')
    if 'symmetry' in regs:
        copies = {'mother': open(OUT + '/master/' + MOTHER, encoding='utf-8').read(), 'psp': open(OUT + '/psp/APEX-PSP-RH-ONE-GAP-01.md', encoding='utf-8').read()}
        norm = lambda s: re.sub(r'\s+', ' ', s.replace('*', '')).strip()
        anc = 'Its engine is `RA_Li_Bridge.lean` in its final'
        for head in ('THE TERMINAL BLOCK.', 'THE CONTROLS, AS DATA.', 'THE LOGICAL FORM, AND THE KEYSTONE.', "THE DIRECTIONAL CAN'T.", 'TERMINAL FOR THE RECORD.', 'THE DEMAND ADDRESSED.', 'POSTULATE M.', 'ENGINE REFS.'):
            i = t.find(head, max(t.find(anc), 0)); mine = norm(t[i + len(head):t.find('\n', i)])[:600] if i >= 0 else None
            for nm, ct in copies.items():
                j = ct.find(head, max(ct.find(anc), 0)); theirs = norm(ct[j + len(head):ct.find('\n', j)])[:600] if j >= 0 else None
                if mine is None or theirs is None or mine != theirs: hit('symmetry', 'C4', 'STRUCTURAL', 'movement %s differs between the codex and the %s copy' % (head, nm), 'compare the three copies')
        m = re.search(r'four real zeros at (−?[\d.]+), (−?[\d.]+), (−?[\d.]+) and (−?[\d.]+)', J)
        if m:
            z = sorted(num(x) for x in m.groups())
            if sorted(1 - x for x in z) != z: hit('symmetry', 'C3', 'STRUCTURAL', 'the printed real zeros are not closed under the fold: %s' % z, 'map each zero to one minus it')
        lean = block(t, 'lean'); mm = re.search(r'theorem demand_is_ghost_in_register[^\n]*\n(?:[^\n]*\n){0,4}', lean)
        if mm and '¬' not in mm.group(0): hit('symmetry', 'C4', 'STRUCTURAL', 'the ghost theorem states no negated case', 'read the statement')
        for c in C:
            if re.search(r'\b(measured|observed|experimental)\b', c) and re.search(r'Eisenstein|Davenport|λ₁', c) and not NEG.search(c): hit('symmetry', 'C3', 'STRUCTURAL', 'computed data described as observation: ' + c[:120], 'name the computation')
    for c in C:   # the scope floor, every round
        if '[⟀ T]' in c and re.search(r'third clause|object alone decides|well-posed', c): hit('scope', 'C4', 'LOAD-BEARING', 'theorem tier on the object clause: ' + c[:130], 'compare with the grade line')
        if re.search(r'\bon (every|all) frames?\b', c) and re.search(r'\bprov(ed|es|ing)\b', c) and not NEG.search(c): hit('scope', 'C4', 'LOAD-BEARING', 'a frame result stated for every frame: ' + c[:130], 'compare with the exhibition on two frames')
        if re.search(r'seal(s|ed)? (on )?the value line|value line (is |stands )?sealed|seals? the value\b', c) and not NEG.search(c): hit('scope', 'C4', 'LOAD-BEARING', 'a seal on the value line: ' + c[:130], 'compare with the unsealed value line')
        if re.search(r'prove[sd]? the line property|proved the line property', c) and not re.search(r'given|seed|iff|equivalen|would|if ', c): hit('scope', 'C4', 'LOAD-BEARING', 'the line property proved without its hypothesis: ' + c[:130], 'find the hypothesis')
        if 'premise-grade seal' in c and not re.search(r'paper|reads|refus', c): hit('scope', 'C4', 'LOAD-BEARING', 'a premise-grade seal asserted in the artifact\'s own voice: ' + c[:130], 'compare with the refusal of seals purchased by posits')
    return hits
