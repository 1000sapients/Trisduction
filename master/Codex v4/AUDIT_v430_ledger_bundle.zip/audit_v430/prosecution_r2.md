# Prosecution, round 2 · registers kinematic, definitional · read against the seeded copy

Battery d69db50f869b60ff, frozen before the controls were committed, run with its every-round floor. Declared targets, the additions of round 1: the repaired terminal-block movement, the new pass line, the new receipts sentence. Headline numbers recomputed from the named files as in round 1, unchanged: the twin 186 and 0, the engine receipts 75 split 53, 2, 20, the eighth module unwound to the engine, the four bracket endpoints. The three phrase specs of the prior cycle re-run against the candidate: every banned phrasing absent, every required one present.

| id | register | target | mechanism | severity | minimal falsifier |
|---|---|---|---|---|---|
| P-1 | kinematic | C5 | reconciliation 286 = 276 + 0 - 0 fails: Reconciliation: entries_out (286) equals entries_in (276) plus additions (0) minus named-o | LOAD-BEARING | recompute in + add - del |
| P-2 | definitional | C4 | the mark defined outside the economy is placed inside it: One mark of chosen silence, [.], stands inside the economy entirely and is never counted. | STRUCTURAL | compare with the definition of the mark |
| P-3 | scope | C4 | a frame result stated for every frame: [tier S] on its third clause, that the object alone decides, proved on every frame | LOAD-BEARING | compare with the exhibition on two frames |

Rival readings built and tested. "Every reading the foundation supplies", read as an unbounded class: the text discriminates, the same sentence enumerates the class as six legs of one cone and the grade line names the cone over five readings and a sixth leg, so the class is defined where the earlier resource clause was not. The new pass line, read as moving a tier: it records a scope narrowed and no tier moved, and the ledger row agrees. The new receipts sentence, read against the code: both code blocks extract identical to the entry. No further finding.
