import re, hashlib, os, shutil, sys
sys.path.insert(0, '/tmp/forge'); import v430_texts as T; from v440_texts import *
OUT = '/mnt/user-data/outputs/v4_3_0_forge'; ST = '/tmp/stage440'
sha = lambda s: hashlib.sha256(s.encode('utf-8')).hexdigest()
def rep(s, o, n, k=None, tag=''):
    c = s.count(o); assert c >= 1 and (k is None or c == k), (tag, c, o[:70]); return s.replace(o, n)
LEAN = open('/tmp/kit440/Codex_v4_4_0.lean', encoding='utf-8').read(); FORT = open('/tmp/kit440/Codex_Twin_v4_4_0.f90', encoding='utf-8').read()
C8 = open('/tmp/kit440/modules/Codex8.lean', encoding='utf-8').read(); ENG = open('/tmp/final1058/RA_Li_Bridge.lean', encoding='utf-8').read()
TIMES = open('/tmp/kit440/modules/fullbuild.txt').read()
def card(s, first):
    if not first:
        s = rep(s, 'is blocked by theorem, and the block reaches every resource the foundation supplies. Every reading', 'is blocked by theorem. Every reading', 1, 'F-1')
        s = rep(s, 'a negative λ₁, the hypothesis `RALi.no_uniform_bridge` takes, executed.', 'a negative λ₁, a witness of the hypothesis `RALi.no_uniform_bridge` takes, a coefficient not nonnegative on some member of the family, executed.', 1, 'F-2')
    s = rep(s, 'in its final edition, Parts I to XIII, 1018 lines, sha256 `1c56b2a688ce8579…`', 'in its final sealed edition, Parts I to XIV, 1058 lines, sha256 `f2d0f4e33e82ad5d…`', 1, 'status')
    s = rep(s, '(final edition, 23 September 2026)', '(final sealed edition, Zenodo record 22929637, 23 September 2026)', None, 'paper')
    s = rep(s, '`RA_Li_Bridge.lean`, the final edition, sha256 `1c56b2a688ce85798d14c8fac979bada34dc14b9d2a0c77c83a0e5e1c913ae29`, 1018 lines, 75 axiom receipts: 53 axiom-free,', '`RA_Li_Bridge.lean`, the final sealed edition, sha256 `f2d0f4e33e82ad5db4afa6f4d12cfb93619354bec0ffb32efac8f7be3ef18f03`, 1058 lines, 79 axiom receipts: 57 axiom-free,', 1, 'refs')
    s = rep(s, 'Parts XI to XIII carry 26 of them, 23 axiom-free', 'Parts XI to XIV carry 30 of them, 27 axiom-free', 1, 'late')
    s = rep(s, 'its twin is Section 21 of the Fortran twin, twenty-one checks.', 'its twin is Section 21 of the Fortran twin, twenty-five checks.', 1, 'twin')
    s, n1 = re.subn(r'every further reformulation lands on (it|the same apex)', 'every proposition proved equivalent to the hypothesis lands on the same apex', s)
    s, n2 = re.subn(r'no true premise weaker than the apex closes it|positing it purchases nothing', 'conditioning on a true premise adds nothing', s)
    s = rep(s, GRADE_OLD_A, GRADE_NEW_A, 1, 'grade A'); s = rep(s, GRADE_OLD_B, GRADE_NEW_B, 1, 'grade B')
    s = rep(s, T.KEY_430, T.KEY_430 + KEY_440_ADD, 1, 'key')
    i = s.index('*THE CONTROLS, AS DATA.*'); j = s.index('\n', i)
    s = s[:j] + '\n\n' + LOGICAL_440 + '\n\n' + TERMINAL_440 + s[j:]
    return s, n1, n2
k = open('TRISDUCTION_Master_Codex_v4_3_3.md', encoding='utf-8').read()
k, a, b = card(k, True); print('codex scoped readings replaced: 46 x%d, 47 x%d' % (a, b))
d63 = T.LI_D63.replace('every further reformulation lands on the same apex', 'every proposition proved equivalent to the hypothesis lands on the same apex').replace('no true premise weaker than the apex closes it', 'conditioning on a true premise adds nothing')
k = rep(k, d63, d63 + D63_ADD, 1, 'd63')
k = rep(k, "the RH engine's twenty-one checks, 186 Lean-native checks, 0 failures.", "the RH engine's twenty-five checks, 190 Lean-native checks, 0 failures.", 1, 'seat twin')
F0 = re.search(r'^```fortran$\n(.*?)^```$', k, re.M | re.S).group(1); L0 = re.search(r'^```lean$\n(.*?)^```$', k, re.M | re.S).group(1)
k = rep(k, '`Codex.lean`, sha256 `2d7ea3256a205bae…`, 8,165 lines', '`Codex.lean`, sha256 `%s…`, 8,213 lines' % sha(LEAN)[:16], 1, 'F-3 seat surface')
k = rep(k, sha(L0), sha(LEAN), 1, 'C.1 surface'); k = rep(k, sha(F0), sha(FORT), 1, 'C.1 twin'); k = rep(k, sha(F0)[:16] + '…', sha(FORT)[:16] + '…', 1, 'seat twin sha')
k = rep(k, 'Codex8 `9f83ea7e88869cdc`', 'Codex8 `%s`' % sha(C8)[:16], 1, 'C.1 module')
k = rep(k, 'checks 186   failures 0', 'checks 190   failures 0', 1, 'C.1 twin count')
tm = '; '.join(re.findall(r'(Codex\d exit 0 seconds \d+)', TIMES))
k, nt = re.subn(r'Codex1 exit 0 seconds \d+; Codex2 exit 0 seconds \d+; Codex3 exit 0 seconds \d+; Codex4 exit 0 seconds \d+; Codex5 exit 0 seconds \d+; Codex6 exit 0 seconds \d+; Codex7 exit 0 seconds \d+; Codex8 exit 0 seconds \d+, all eight rebuilt at v4\.3\.0', tm + ', all eight rebuilt at v4.4.0', k); assert nt == 1, nt
k = rep(k, T.IV3_FINAL_PAPER, IV3_SEALED, 1, 'iv3')
a = 'the count now matches the hash. No value token moved and no tier moved. ΔM = 0.'
k = rep(k, a, a + '\n\n' + P440, 1, 'p440')
r = ' Edition v4.3.3 corrects one printed line count of the seat card beside an unchanged Code Block.'
k = rep(k, r, r + RECEIPT_440, 1, 'receipt')
k = rep(k, 'version: v4.3.3', 'version: v4.4.0', 1); k = rep(k, 'Master Codex, v4.3.3', 'Master Codex, v4.4.0', 1); k = rep(k, 'TRISDUCTION_Master_Codex_v4_3_3.md', 'TRISDUCTION_Master_Codex_v4_4_0.md', 3)
k = rep(k, 'THE TWIN LOAD IS PROVEN. 186 Lean-native checks, 0 failures; four witnesses to exit 0.', 'THE TWIN LOAD IS PROVEN. 190 Lean-native checks, 0 failures; four witnesses to exit 0.', 1, 'closing line')
k = k.replace('```lean\n' + L0 + '```', '```lean\n' + LEAN + '```', 1).replace('```fortran\n' + F0 + '```', '```fortran\n' + FORT + '```', 1)
assert re.search(r'^```lean$\n(.*?)^```$', k, re.M | re.S).group(1) == LEAN and re.search(r'^```fortran$\n(.*?)^```$', k, re.M | re.S).group(1) == FORT
open('TRISDUCTION_Master_Codex_v4_4_0.md', 'w', encoding='utf-8').write(k)
print('codex v4.4.0: %d bytes sha %s | Lean block = surface %s | Fortran block = twin %s' % (len(k.encode()), sha(k)[:16], sha(LEAN)[:16], sha(FORT)[:16]))
for d in ('protocols/RH One Bit', 'master', 'psp'): os.makedirs(ST + '/' + d, exist_ok=True)
open(ST + '/protocols/RH One Bit/RA_Li_Bridge.lean', 'w', encoding='utf-8').write(ENG)
for f in ('RA_Li_Bridge_Retirement.lean', 'RH_controls_data.json'): shutil.copy(OUT + '/protocols/RH One Bit/' + f, ST + '/protocols/RH One Bit/' + f)
m = open(OUT + '/master/TRISDUCTION_Master_Codex_Unabridged_v3_42_0.md', encoding='utf-8').read(); m, a, b = card(m, False)
m = rep(m, T.MOTHER_MINOR_342, T.MOTHER_MINOR_342 + '\n\n' + MOTHER_MINOR_343, 1, 'mother minor')
open(ST + '/master/TRISDUCTION_Master_Codex_Unabridged_v3_43_0.md', 'w', encoding='utf-8').write(m); print('Mother candidate: scoped 46 x%d, 47 x%d, %d bytes' % (a, b, len(m.encode())))
p = open(OUT + '/psp/APEX-PSP-RH-ONE-GAP-01.md', encoding='utf-8').read(); p, a, b = card(p, False)
open(ST + '/psp/APEX-PSP-RH-ONE-GAP-01.md', 'w', encoding='utf-8').write(p); print('psp candidate: scoped 46 x%d, 47 x%d, %d bytes' % (a, b, len(p.encode())))
