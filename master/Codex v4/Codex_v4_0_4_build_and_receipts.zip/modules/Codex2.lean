import Codex1
set_option maxRecDepth 4000000
namespace FOUND

def sigmaP : GEO.M3 :=
  (((-7 : Ratio) / 25, (24 : Ratio) / 25, 0),
   ((24 : Ratio) / 25, (7 : Ratio) / 25, 0),
   (0, 0, -1))

theorem pluralist_alternative_executed :
    GEO.mm3 sigmaP sigmaP = GEO.diag3 1
    ∧ GEO.det3 sigmaP = 1
    ∧ GEO.mv3 sigmaP (3, 4, 0) = ((3, 4, 0) : GEO.V3)
    ∧ GEO.mv3 sigmaP (1, 0, 0) ≠ ((1, 0, 0) : GEO.V3)
    ∧ GEO.mv3 sigmaP (1, 0, 0) ≠ ((-1, 0, 0) : GEO.V3) := by
  decide

inductive Band : Type
  | inBand | outOfBand
  deriving DecidableEq, Repr, BEq

structure Posit : Type where
  id : String
  grade : Grade
  band : Band
  loadBearingInVerdict : Bool
  note : String
  deriving Repr

def posits : List Posit := [
  ⟨"RESIDUAL-MONISM", .premise, .inBand, false,
   "the one-prior-to-many connector: the geometric and formal grounds coincide on Fix(sigma) iff one involution serves both routes; the pluralist alternative executed above stays field-permitted; the from-other-side input located across the aperture and not crossed"⟩,
  ⟨"STRATIFIED-MONISM-PRIORITY", .structural, .inBand, false,
   "P-MONISM-1: substrate, topology, and actuation are three projections of one event, theorem-grade as physics; the priority of the one over the many is the single structural posit the floor-coincidence rides"⟩,
  ⟨"FITRA-FLOOR", .premise, .outOfBand, false,
   "fitra = RA = K(X), the incompressible floor inherited (QADAR-01); the theological identification routed out of band, load-bearing on nothing"⟩,
  ⟨"QADAR-RECORD", .structural, .outOfBand, false,
   "qadar = R(X), the harvested record, derived and downstream of the floor; the Pen's cost-gradient writing, never onto noise"⟩,
  ⟨"AMANAH-TRUST", .premise, .outOfBand, false,
   "P-AMANAH-1: ethics is the preservation of the actuation floor; the substrate a liability engine and never a moral authority"⟩]

theorem posits_loadbearing_on_nothing :
    (posits.all (fun p => !p.loadBearingInVerdict)) = true := by
  decide

def gradeOfRank : Nat → Grade
  | 0 => .premise | 1 => .corroboration | 2 => .operational
  | 3 => .structural | 4 => .engineering | 5 => .conditional
  | 6 => .theoremConditional | 7 => .analytic | _ => .theorem

theorem posit_never_raises :
    (posits.all (fun p =>
      (List.range 9).all (fun r =>
        decide ((Grade.weakest p.grade (gradeOfRank r)).rank ≤ r)))) = true := by
  decide

inductive Register : Type
  | kinetic | formal | verification | theological | social
  deriving DecidableEq, Repr, BEq

def bandOf : Register → Band
  | .theological => .outOfBand
  | .social      => .outOfBand
  | _            => .inBand

theorem register_routing_fidelity :
    bandOf .theological = .outOfBand ∧ bandOf .social = .outOfBand
    ∧ bandOf .kinetic = .inBand ∧ bandOf .formal = .inBand
    ∧ bandOf .verification = .inBand := by
  decide

structure VerdictRow : Type where
  name : String
  positDeps : List String
  deriving Repr

def verdictInventory : List VerdictRow := [
  ⟨"the grade law and the weakest-link join (section 1)", []⟩,
  ⟨"the audit engine and the drill battery (section 4B)", []⟩,
  ⟨"the inversion (section 4C)", []⟩,
  ⟨"the twelve gates, A4, the GF(2) lock, the cascades (section 4D)", []⟩,
  ⟨"the forcings of eight and five (section 4E)", []⟩,
  ⟨"the tongue's obedience (section 11)", []⟩,
  ⟨"the office taxonomy (section 12)", []⟩,
  ⟨"the universal router and the circularity law (section 13)", []⟩,
  ⟨"the Omega guard and AEGIS (section 14)", []⟩,
  ⟨"the incompressibility cap (section 15)", []⟩]

theorem verdicts_posit_free :
    (verdictInventory.all (fun v => v.positDeps.isEmpty)) = true := by
  decide

theorem engine_never_authority : socialWeight = 0 ∧ deltaM = 0 :=
  ⟨rfl, rfl⟩

#eval posits.map (fun p => (p.id, p.grade, p.band))
#eval List.map bandOf [Register.kinetic, .theological, .social]

end FOUND

namespace HALT

inductive Species : Type
  | blockTheorem | hypothesis | offeredWitness
  deriving DecidableEq, Repr

inductive Branch : Type
  | xi | o
  deriving DecidableEq, Repr

def cascade : List Bool → Option Nat
  | [] => none
  | false :: _ => some 0
  | true :: gs => (cascade gs).map Nat.succ

def patterns (n : Nat) : List (List Bool) :=
  (List.range (2 ^ n)).map fun b => (List.range n).map fun j => b.testBit j

def fftSpec (bits : List Bool) : Bool :=
  match cascade bits with
  | none => bits.all id
  | some k =>
      (bits.take k).all id &&
      (match bits.drop k with
       | false :: _ => true
       | _ => false)

theorem first_failure_terminal_5 :
    (patterns 5).all fftSpec = true := by decide

theorem first_failure_terminal_7 :
    (patterns 7).all fftSpec = true := by decide

theorem first_failure_terminal_8 :
    (patterns 8).all fftSpec = true := by decide

theorem first_failure_terminal_12 :
    (patterns 12).all fftSpec = true := by decide

theorem halt_free_iff_all_pass_8 :
    (patterns 8).all (fun bits => (cascade bits).isNone == bits.all id)
      = true := by decide

theorem gate_counts_recorded :
    GEO.a4.length = 12 ∧ GEO.allSigns.length = 8 ∧
    (GEO.cube5.all (fun v => (GEO.neighbors5 v).eraseDups.length == 5)) = true :=
  ⟨GEO.a4_order, GEO.reflection_eight, GEO.fivecube_degree_five⟩

abbrev signPatterns : List (Bool × Bool × Bool) := GEO.allSigns

theorem ninth_gate_barred :
    signPatterns.length = 8 ∧ signPatterns.eraseDups.length = 8 ∧
    signPatterns = GEO.allSigns := ⟨by decide, by decide, rfl⟩

def route (groundDim : Nat) : Option Branch :=
  if groundDim = 1 then some .xi else if groundDim = 0 then some .o else none

def ofUC : UC.HaltBranch → Option Branch
  | .haltEight => some .xi
  | .haltFive => some .o
  | .unmeasured => none

theorem route_is_routeHalt : ∀ n : Nat, route n = ofUC (UC.routeHalt n).1 := by
  intro n
  unfold route UC.routeHalt ofUC
  by_cases h1 : n = 1
  · subst h1; simp
  · by_cases h0 : n = 0
    · subst h0; simp
    · have h1' : (n : Int) ≠ 1 := by omega
      have h0' : (n : Int) ≠ 0 := by omega
      simp only [h1, h0, h1', h0', ite_false]

theorem route_samples :
    route 0 = some .o ∧ route 1 = some .xi ∧ route 2 = none ∧ route 7 = none := by decide

inductive LegacyToken : Type
  | xi0 | o0
  deriving DecidableEq, Repr

def tokenBranch : LegacyToken → Branch
  | .xi0 => .xi
  | .o0 => .o

theorem router_exclusive :
    route 0 = some .o ∧ route 1 = some .xi ∧ route 2 = none ∧
    route 0 ≠ some .xi ∧ route 1 ≠ some .o ∧
    tokenBranch .xi0 ≠ .o ∧ tokenBranch .o0 ≠ .xi := by decide

def readingRoadsGate : Bool := false   

theorem one_door_open :
    cascade (List.replicate 7 true ++ [readingRoadsGate]) = some 7 := by
  decide

theorem no_walk_passes_the_aperture :
    (patterns 7).all (fun xs => (cascade (xs ++ [readingRoadsGate])).isSome) = true := by
  decide

def xiGates : List String :=
  [ "Ground-determinacy", "Ghost partition", "constitutive blindness",
    "machine-precision exhibit", "aperture located", "face-scoping",
    "revision-mandate survival", "reading-roads" ]

def oGates : List String :=
  [ "rootless terrain", "determinate stripped string", "wall record",
    "aperture crossed or held", "totality discipline" ]

theorem gate_censuses :
    xiGates.length = 8 ∧ oGates.length = 5 := by decide

inductive Channel : Type
  | kinetic | formal
  deriving DecidableEq, Repr

structure SuperHalt where
  species : Species
  gdim : Nat
  branch : Branch
  gates : Nat
  channel : Channel
  routed : route gdim = some branch
  deriving DecidableEq

def rhHalt : SuperHalt := ⟨.hypothesis, 1, .xi, 8, .formal, by decide⟩

def pnpHalt : SuperHalt := ⟨.blockTheorem, 0, .o, 5, .formal, by decide⟩

theorem halts_routed :
    route rhHalt.gdim = some rhHalt.branch ∧ route pnpHalt.gdim = some pnpHalt.branch :=
  ⟨rhHalt.routed, pnpHalt.routed⟩

theorem legacy_halts_are_instances :
    rhHalt = ⟨.hypothesis, 1, .xi, 8, .formal, by decide⟩ ∧
    pnpHalt = ⟨.blockTheorem, 0, .o, 5, .formal, by decide⟩ ∧
    rhHalt ≠ pnpHalt := by decide

theorem terminal_one_bit :
    Species.blockTheorem ≠ Species.hypothesis ∧
    Species.blockTheorem ≠ Species.offeredWitness ∧
    Species.hypothesis ≠ Species.offeredWitness := by decide

theorem species_exhausted : ∀ s : Species,
    s = .blockTheorem ∨ s = .hypothesis ∨ s = .offeredWitness := by
  intro s; cases s
  · exact Or.inl rfl
  · exact Or.inr (Or.inl rfl)
  · exact Or.inr (Or.inr rfl)

def haltGrades : List Grade := [.structural, .theoremConditional]

theorem ftoe_ceiling :
    haltGrades.all (fun g => g.rank < Grade.theorem.rank) = true := by
  decide

end HALT

/-! ## The four Fortran witnesses
F1 thesis_rows (the core thesis executed), F2 ra_toe_thesis (the existence root executed), F3
ftoe_kinetic_demonstration (the deed priced) and F4 it_from_it (the inversion computed) are seated in Part II
of this codex, the Fortran twin, one executable, with every contract comment they were audited with.
The Lean namespaces Audit, GEO, IAM, OMEGA, AEGIS, INVERSION, K4 and CROSSING are their formal register. -/

namespace CROSSING
open FTOE

abbrev ExecFrame (Q : Type) := Bool × Q

def execFlip {Q : Type} : ExecFrame Q → ExecFrame Q := flipF

def formalRead {Q : Type} (s : ExecFrame Q) : Q := s.2

def ran {Q : Type} (s : ExecFrame Q) : Bool := s.1

theorem formalRead_even {Q : Type} : ∀ s : ExecFrame Q,
    formalRead (execFlip s) = formalRead s := by
  intro s; obtain ⟨b, q⟩ := s; rfl

theorem ran_wholly_odd {Q : Type} : WhollyOdd (execFlip (Q := Q)) ran := by
  intro s; obtain ⟨b, q⟩ := s; cases b <;> rfl

theorem execFlip_involution {Q : Type} : Involution (execFlip (Q := Q)) := by
  intro s; obtain ⟨b, q⟩ := s; cases b <;> rfl

theorem ran_odd_at_true {Q : Type} (q : Q) : OddAt (execFlip (Q := Q)) ran (true, q) :=
  fun h => Bool.noConfusion h

theorem wall {Q : Type} (q : Q) :
    ¬ ∃ g : Q → Bool, ∀ s : ExecFrame Q, g (formalRead s) = ran s :=
  T14_wall_factorization execFlip formalRead ran (true, q) formalRead_even (ran_odd_at_true q)

def deed {Q : Type} : Dtau (execFlip (Q := Q)) := ⟨ran, ran_wholly_odd⟩

theorem price {Q : Type} :
    Nonempty (Dtau (execFlip (Q := Q)) ≃
      (Quot (OrbitRel (execFlip (Q := Q))) → Bool)) :=
  T16_price_bijection execFlip execFlip_involution deed

theorem crossing {Q : Type} (q : Q) (witness : ExecFrame Q → Bool)
    (hw : witness (execFlip (true, q)) = !witness (true, q)) :
    ∃ c : Bool,
      (ran (true, q) = xor (witness (true, q)) c ∧
       ran (execFlip (true, q)) = xor (witness (execFlip (true, q))) c) ∧
      ∀ c' : Bool,
        (ran (true, q) = xor (witness (true, q)) c' ∧
         ran (execFlip (true, q)) = xor (witness (execFlip (true, q))) c') → c' = c :=
  T5_crossing execFlip witness ran (true, q) hw (ran_wholly_odd (true, q))

theorem identity_one_bit {Q : Type} (witness : ExecFrame Q → Bool)
    (hw : WhollyOdd execFlip witness) (s : ExecFrame Q) (h : witness s = ran s) :
    witness (execFlip s) = ran (execFlip s) :=
  T4_one_bit execFlip witness ran hw ran_wholly_odd s h

inductive Anchor : Type
  | F1 | F2 | F3 | F4
  deriving DecidableEq, Repr

def fibre4 : List (Bool × Bool × Bool × Bool) :=
  [false, true].flatMap fun a => [false, true].flatMap fun b =>
    [false, true].flatMap fun c => [false, true].map fun d => (a, b, c, d)

theorem fibre4_sixteen : fibre4.length = 16 := by decide
theorem fibre4_distinct : fibre4.eraseDups.length = 16 := by decide

theorem price_on_this_file :
    Nonempty (Dtau (execFlip (Q := Anchor)) ≃
      (Quot (OrbitRel (execFlip (Q := Anchor))) → Bool)) :=
  price

end CROSSING

namespace CROSSING
open FTOE

theorem formal_never_odd {Q : Type} (g : Q → Bool) :
    Even (execFlip (Q := Q)) (fun s => g (formalRead s)) := by
  intro s; obtain ⟨b, q⟩ := s; rfl

theorem constant_no_crossing {Q : Type} (b : Bool) (s : ExecFrame Q) :
    ¬ OddAt (execFlip (Q := Q)) (fun _ => b) s := by
  intro h; exact h rfl

theorem harmony {Q : Type} (q : Q) (witness : ExecFrame Q → Bool)
    (hw : witness (execFlip (true, q)) = !witness (true, q))
    (g₁ g₂ : Q → Bool) (op : Bool → Bool → Bool) :
    (fun s => op (g₁ (formalRead s)) (g₂ (formalRead s))) ≠ ran ∧
    ∃ c : Bool,
      (ran (true, q) = xor (witness (true, q)) c ∧
       ran (execFlip (true, q)) = xor (witness (execFlip (true, q))) c) ∧
      ∀ c' : Bool,
        (ran (true, q) = xor (witness (true, q)) c' ∧
         ran (execFlip (true, q)) = xor (witness (execFlip (true, q))) c') → c' = c :=
  fTOE_core execFlip witness ran (true, q)
    (fun s => g₁ (formalRead s)) (fun s => g₂ (formalRead s))
    (formal_never_odd g₁) (formal_never_odd g₂) op
    (ran_wholly_odd (true, q)) hw

end CROSSING
