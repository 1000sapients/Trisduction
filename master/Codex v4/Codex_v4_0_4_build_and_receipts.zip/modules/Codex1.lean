/-!
# MATHEMATICAL TRISDUCTION CODEX · v2.0.1 · THE LEAN SURFACE
Core Lean 4 (v4.19.0), no Mathlib, no sorry, no axiom beyond Lean's standard three (propext, Classical.choice,
Quot.sound) and the twenty-three declared posits of ROOT and POSTULATE, which the environment audit at the foot
of this file names one by one. `import Lean`
is loaded for that audit alone. Every theorem carries its axiom cone as a `#guard_msgs` receipt.
The Lean surface proves; the Fortran twin (Part II of the codex) executes the same register.
The four Fortran witnesses F1 thesis_rows, F2 ra_toe_thesis, F3 ftoe_kinetic_demonstration and
F4 it_from_it are seated once, in the twin, with their contracts; this file no longer carries a second copy.
Delta-M = 0. No new mathematics is authored by this file.
-/

namespace Codex

def LeftInverse (g : β → α) (f : α → β) : Prop := ∀ a, g (f a) = a

def RightInverse (g : β → α) (f : α → β) : Prop := LeftInverse f g
end Codex

structure Equiv (α : Sort u) (β : Sort v) where
  toFun : α → β
  invFun : β → α
  left_inv : Codex.LeftInverse invFun toFun
  right_inv : Codex.RightInverse invFun toFun

infixl:25 " ≃ " => Equiv

def Nat.factorial : Nat → Nat
  | 0 => 1
  | n + 1 => (n + 1) * Nat.factorial n

namespace CoreRat

theorem div_pos_of_le {d g : Nat} (hg : 0 < g) (hle : g ≤ d) : 0 < d / g := by
  have h : 1 * g ≤ d := by rw [Nat.one_mul]; exact hle
  exact (Nat.le_div_iff_mul_le hg).mpr h

theorem div_gcd_pos {a d : Nat} (hd : 0 < d) : 0 < d / Nat.gcd a d :=
  div_pos_of_le (Nat.gcd_pos_of_pos_right a hd) (Nat.le_of_dvd hd (Nat.gcd_dvd_right a d))

theorem coprime_div_gcd {a d : Nat} (hd : 0 < d) :
    Nat.gcd (a / Nat.gcd a d) (d / Nat.gcd a d) = 1 := by
  have hg : 0 < Nat.gcd a d := Nat.gcd_pos_of_pos_right a hd
  have ha : Nat.gcd a d * (a / Nat.gcd a d) = a := Nat.mul_div_cancel' (Nat.gcd_dvd_left a d)
  have hb : Nat.gcd a d * (d / Nat.gcd a d) = d := Nat.mul_div_cancel' (Nat.gcd_dvd_right a d)
  have h : Nat.gcd a d * Nat.gcd (a / Nat.gcd a d) (d / Nat.gcd a d) = Nat.gcd a d := by
    have e := Nat.gcd_mul_left (Nat.gcd a d) (a / Nat.gcd a d) (d / Nat.gcd a d)
    rw [ha, hb] at e; exact e.symm
  have h2 : Nat.gcd a d * Nat.gcd (a / Nat.gcd a d) (d / Nat.gcd a d) = Nat.gcd a d * 1 := by
    rw [Nat.mul_one]; exact h
  exact Nat.eq_of_mul_eq_mul_left hg h2

end CoreRat

structure Ratio where
  num : Int
  den : Nat
  pos : 0 < den
  cop : Nat.gcd num.natAbs den = 1
  deriving DecidableEq, Repr

namespace Ratio

theorem natAbs_signed (k : Nat) (neg : Bool) :
    (if neg then -(k : Int) else (k : Int)).natAbs = k := by cases neg <;> simp

def mk' (n d : Int) : Ratio :=
  if hd : d = 0 then ⟨0, 1, by decide, by decide⟩
  else
    let neg : Bool := decide ((n < 0) ≠ (d < 0))
    let a : Nat := n.natAbs
    let b : Nat := d.natAbs
    have hb : 0 < b := Int.natAbs_pos.mpr hd
    let g : Nat := Nat.gcd a b
    ⟨(if neg then -((a / g : Nat) : Int) else ((a / g : Nat) : Int)), b / g,
     CoreRat.div_gcd_pos hb, by rw [natAbs_signed]; exact CoreRat.coprime_div_gcd hb⟩

instance instOfNatRat : OfNat Ratio n := ⟨mk' n 1⟩
instance instAddRat : Add Ratio where add a b := mk' (a.num * b.den + b.num * a.den) (a.den * b.den)
instance instMulRat : Mul Ratio where mul a b := mk' (a.num * b.num) (a.den * b.den)
instance instNegRat : Neg Ratio where neg a := mk' (-a.num) a.den
instance instSubRat : Sub Ratio where sub a b := a + (-b)

def inv (a : Ratio) : Ratio := mk' (a.den : Int) a.num
instance instDivRat : Div Ratio where div a b := a * inv b
instance instLTRat : LT Ratio where lt a b := a.num * b.den < b.num * a.den
instance instLERat : LE Ratio where le a b := a.num * b.den ≤ b.num * a.den
instance instDecidableLtRat (a b : Ratio) : Decidable (a < b) :=
  inferInstanceAs (Decidable (a.num * b.den < b.num * a.den))
instance instDecidableLeRat (a b : Ratio) : Decidable (a ≤ b) :=
  inferInstanceAs (Decidable (a.num * b.den ≤ b.num * a.den))

def pow (a : Ratio) : Nat → Ratio
  | 0 => 1
  | n + 1 => a * pow a n
instance instHPowRatNat : HPow Ratio Nat Ratio := ⟨Ratio.pow⟩
instance instToStringRat : ToString Ratio where
  toString a := if a.den == 1 then toString a.num else toString a.num ++ "/" ++ toString a.den

@[simp] theorem num_zero : (0 : Ratio).num = 0 := rfl
@[simp] theorem den_zero : (0 : Ratio).den = 1 := rfl

theorem mk'_zero_num {d : Nat} (hd : 0 < d) : mk' 0 (d : Int) = 0 := by
  have hne : (d : Int) ≠ 0 := by omega
  show mk' 0 (d : Int) = mk' 0 1
  unfold mk'
  simp only [hne, (by decide : (1 : Int) ≠ 0), dite_false]
  simp [Nat.gcd_zero_left, Nat.div_self hd, Nat.zero_div]

@[simp] theorem zero_mul (a : Ratio) : (0 : Ratio) * a = 0 := by
  show mk' ((0 : Ratio).num * a.num) (((0 : Ratio).den * a.den : Nat) : Int) = 0
  rw [num_zero, den_zero, Int.zero_mul, Nat.one_mul]
  exact mk'_zero_num a.pos

@[simp] theorem mul_zero (a : Ratio) : a * (0 : Ratio) = 0 := by
  show mk' (a.num * (0 : Ratio).num) ((a.den * (0 : Ratio).den : Nat) : Int) = 0
  rw [num_zero, den_zero, Int.mul_zero, Nat.mul_one]
  exact mk'_zero_num a.pos

theorem canonical (a : Ratio) : 0 < a.den ∧ Nat.gcd a.num.natAbs a.den = 1 := ⟨a.pos, a.cop⟩

theorem ext {a b : Ratio} (h1 : a.num = b.num) (h2 : a.den = b.den) : a = b := by
  cases a; cases b; simp_all

theorem inv_zero : inv (0 : Ratio) = 0 := by decide

end Ratio

set_option maxRecDepth 4000000

inductive Grade : Type
  | premise | corroboration | operational | structural | engineering
  | conditional | theoremConditional | analytic | theorem
  deriving DecidableEq, Repr

def Grade.rank : Grade → Nat
  | .premise => 0 | .corroboration => 1 | .operational => 2 | .structural => 3
  | .engineering => 4 | .conditional => 5 | .theoremConditional => 6
  | .analytic => 7 | .theorem => 8

def Grade.weakest (a b : Grade) : Grade := if a.rank ≤ b.rank then a else b

theorem Grade.weakest_is_a_link (a b : Grade) :
    Grade.weakest a b = a ∨ Grade.weakest a b = b := by
  cases a <;> cases b <;> decide

theorem Grade.weakest_idempotent (a : Grade) : Grade.weakest a a = a := by
  cases a <;> decide

structure Claim : Type where
  stmt : Prop
  grade : Grade
  warrant : stmt

def Claim.join (c₁ c₂ : Claim) : Claim where
  stmt := c₁.stmt ∧ c₂.stmt
  grade := Grade.weakest c₁.grade c₂.grade
  warrant := ⟨c₁.warrant, c₂.warrant⟩

theorem Claim.join_grade (c₁ c₂ : Claim) :
    (Claim.join c₁ c₂).grade = Grade.weakest c₁.grade c₂.grade := rfl

def deltaM : Nat := 0

def socialWeight : Nat := 0

/-
THE FORMAL THEORY OF EVERYTHING · THE FORMAL PROOF
Lean 4 (core only, no mathlib, zero sorries).

This file proves the complete theorem content of the fTOE:

  WALL      (T1) No even reading decides an odd target.
            (T2) No finite coalition of even readings escapes T1.
            (T3) Odd content carries no fixed point.
  PRICE     (T4) The odd content of a free orbit is exactly one binary
                 degree of freedom: never two, never a continuum.
  CROSSING  (T5) One odd supply at the seat, plus exactly one calibration
                 bit, decides the target on its orbit; and that calibration
                 is unique. One bit missing, one bit supplied, nothing more.

What this file does not contain, by its own theorems: the supply itself.
Existence of the supply is the One-Cut Hypothesis, stated as a hypothesis
in the treatise this file accompanies. The wall is proved here. What crosses
it enters by deed, not by derivation.
-/
namespace FTOE

variable {α : Type}

/-- A reading f is even under τ when it is constant on τ-orbits. -/
def Even (τ : α → α) (f : α → Bool) : Prop := ∀ x, f (τ x) = f x

/-- A target d is odd under τ when it separates some orbit. -/
def OddAt (τ : α → α) (d : α → Bool) (x : α) : Prop := d (τ x) ≠ d x

/-- A sign vector t is wholly odd under τ when t ∘ τ = ¬t. -/
def WhollyOdd (τ : α → α) (t : α → Bool) : Prop := ∀ x, t (τ x) = !t x

/-- T1 · THE WALL.
    An even reading equals no odd target. The register computes every
    magnitude and no orientation. -/
theorem T1_wall (τ : α → α) (f d : α → Bool) (x : α)
    (he : Even τ f) (ho : OddAt τ d x) : f ≠ d := by
  intro h
  subst h
  exact ho (he x)

/-- T2 · COALITION CLOSURE.
    Evenness is closed under every Boolean join, so no coalition of even
    readings escapes the wall. -/
theorem T2_coalition (τ : α → α) (f g d : α → Bool) (x : α)
    (hf : Even τ f) (hg : Even τ g) (op : Bool → Bool → Bool)
    (ho : OddAt τ d x) : (fun y => op (f y) (g y)) ≠ d := by
  apply T1_wall τ _ d x
  · intro y; show op (f (τ y)) (g (τ y)) = op (f y) (g y); rw [hf y, hg y]
  · exact ho

/-- T3 · NO FIXED POINT.
    Wholly odd content cannot sit on a fixed point of τ:
    t x = ¬t x is a Boolean contradiction. -/
theorem T3_no_fixed_point (τ : α → α) (t : α → Bool)
    (ho : WhollyOdd τ t) (x : α) : τ x ≠ x := by
  intro h
  have h1 : t (τ x) = !t x := ho x
  rw [h] at h1
  cases t x <;> simp at h1

/-- T4 · THE PRICE: ONE BIT PER ORBIT.
    Two wholly odd sign vectors agreeing at one point of an orbit agree on
    the whole orbit. The odd content of a free orbit is exhausted by one
    binary choice. -/
theorem T4_one_bit (τ : α → α) (s t : α → Bool)
    (hs : WhollyOdd τ s) (ht : WhollyOdd τ t)
    (x : α) (h : s x = t x) : s (τ x) = t (τ x) := by
  rw [hs x, ht x, h]

/-- T5 · THE CROSSING.
    If a supply s and a target d are both odd at the seat x, then there is
    exactly one calibration bit c with d = s XOR c on the whole orbit:
    one supplied orientation bit, one calibration from the dated record,
    and the target is decided. Existence and uniqueness. -/
theorem T5_crossing (τ : α → α) (s d : α → Bool) (x : α)
    (hs : s (τ x) = !s x) (hd : d (τ x) = !d x) :
    ∃ c : Bool, (d x = xor (s x) c ∧ d (τ x) = xor (s (τ x)) c) ∧
      ∀ c' : Bool, (d x = xor (s x) c' ∧ d (τ x) = xor (s (τ x)) c') → c' = c := by
  exact ⟨xor (d x) (s x),
    ⟨by cases s x <;> cases d x <;> rfl,
     by rw [hs, hd]; cases s x <;> cases d x <;> rfl⟩,
    by
      intro c' hc
      obtain ⟨h1, -⟩ := hc
      generalize hsx : s x = sv
      generalize hdx : d x = dv
      rw [hsx, hdx] at h1
      cases sv <;> cases dv <;> cases c' <;> first | rfl | exact absurd h1 (by decide)⟩

/-- T6a · DEED A — THE ANCHOR (FORGE cycle two: the two deeds, split).
    If d is odd at x₀ and the deed anchors one point (d x₀ = b — the
    corpus's identification of which sign is which, present in any corpus
    that can pose the decision at all), then d is known on the whole orbit
    {x₀, τx₀}. NO SUPPLY IS REQUIRED: oddness propagates the anchored bit.
    This is the deed as the arrival of the target's value at one point. -/
theorem T6a_deed_anchor (τ : α → α) (d : α → Bool) (x₀ : α) (b : Bool)
    (hd : d (τ x₀) = !d x₀) (anchor : d x₀ = b) :
    d x₀ = b ∧ d (τ x₀) = !b := by
  exact ⟨anchor, by rw [hd, anchor]⟩

/-- T6b · DEED B — THE SUPPLY (FORGE cycle two: the two deeds, split).
    If s is odd at x₀ and c is a naming bit supplied from outside — a
    universally quantified datum, never computed from d — then the arrival
    equation d = s ⊕ c, once it has arrived, lets anything holding the pair
    (s, c) decide d on the whole orbit. This is the deed as the arrival of
    a register-denotable carrier plus one naming bit. Deeds A and B are
    different deeds; neither is a rewrite of the other inside this file. -/
theorem T6b_deed_supply (τ : α → α) (s d : α → Bool) (x₀ : α) (c : Bool)
    (hs : s (τ x₀) = !s x₀)
    (arrival : d x₀ = xor (s x₀) c ∧ d (τ x₀) = xor (s (τ x₀)) c) :
    d x₀ = xor (s x₀) c ∧ d (τ x₀) = !xor (s x₀) c := by
  constructor
  · exact arrival.1
  · rw [arrival.2, hs]; cases s x₀ <;> cases c <;> rfl

/-- THE PORT · the two deeds compose without identifying.
    Where Deed A anchors b = d x₀ and Deed B supplies s odd with naming c,
    consistency of the two arrivals forces c = s x₀ ⊕ b. The calibration
    is the agreement of the two deeds, computed from arrived data only.
    The missing bit exists as b (Deed A) or as c (Deed B); that one such
    bit always exists for every blocked row is the One-Cut Hypothesis,
    stated as conjecture in the treatise — never as a theorem of this file. -/
theorem fTOE_port (_τ : α → α) (s d : α → Bool) (x₀ : α) (b c : Bool)
    (anchor : d x₀ = b)
    (arrival : ∀ y : α, d y = xor (s y) c) :
    c = xor (s x₀) b := by
  have h1 := arrival x₀
  rw [anchor] at h1
  generalize hsx : s x₀ = sv
  rw [hsx] at h1
  cases sv <;> cases b <;> cases c <;> first | rfl | exact absurd h1 (by decide)

/-! ## FORGE cycle three · the full-setup package
    The auditors demanded the prose setup be theorem, not preface:
    involution, freeness, global oddness, the observation model, the
    torsor bijection, and resolver separation. Proved here in core Lean. -/

section FullSetup
variable {β γ : Type}

/-- τ is an involution: applying it twice is the identity. -/
def Involution (τ : α → α) : Prop := ∀ x, τ (τ x) = x

/-- τ is fixed-point-free: every orbit is a genuine pair. -/
def FixedPointFree (τ : α → α) : Prop := ∀ x, τ x ≠ x

/-- T7 · THE GLOBAL WALL. Under global oddness, no even reading equals the
    target anywhere it is tested: the wall holds at every point, not one. -/
theorem T7_global_wall (τ : α → α) (f d : α → Bool) (x : α)
    (hf : Even τ f) (hd : WhollyOdd τ d) : f ≠ d := by
  intro h
  have h1 : f (τ x) = d (τ x) := congrFun h (τ x)
  rw [hf x, hd x, congrFun h x] at h1
  cases d x <;> simp at h1

/-- T8a · THE TORSOR, FORWARD. The xor of two wholly odd sections is even:
    the calibration against a reference supply descends to the orbit space.
    This is the machine-checked content of "the calibration is a function
    of the orbit, not of the point." -/
theorem T8_torsor_forward (τ : α → α) (s d : α → Bool)
    (hs : WhollyOdd τ s) (hd : WhollyOdd τ d) :
    Even τ (fun x => xor (d x) (s x)) := by
  intro x
  show xor (d (τ x)) (s (τ x)) = xor (d x) (s x)
  rw [hd x, hs x]; cases d x <;> cases s x <;> rfl

/-- T8b · THE TORSOR, BACKWARD. An odd reference xor an even calibration
    is odd: every even calibration pattern lifts to an admissible target. -/
theorem T8_torsor_backward (τ : α → α) (s c : α → Bool)
    (hs : WhollyOdd τ s) (hc : Even τ c) :
    WhollyOdd τ (fun x => xor (s x) (c x)) := by
  intro x
  show xor (s (τ x)) (c (τ x)) = !xor (s x) (c x)
  rw [hs x, hc x]; cases s x <;> cases c x <;> rfl

/-- T9a · THE TORSOR IS A BIJECTION, FIRST INVERSE. Reference-first:
    s ⊕ (d ⊕ s) = d. Odd sections and even calibrations are in bijection. -/
theorem T9_torsor_inverse_left (s d : α → Bool) :
    (fun x => xor (s x) (xor (d x) (s x))) = d := by
  funext x; cases d x <;> cases s x <;> rfl

/-- T9b · THE TORSOR IS A BIJECTION, SECOND INVERSE. Calibration-first:
    (s ⊕ c) ⊕ s = c. The bijection is exact, not approximate. -/
theorem T9_torsor_inverse_right (s c : α → Bool) :
    (fun x => xor (xor (s x) (c x)) (s x)) = c := by
  funext x; cases s x <;> cases c x <;> rfl

/-- T10 · THE FACTORIZATION OBSTRUCTION. Let the register be an observation
    map ρ with ρ(τx) = ρ(x) — "the register" now means: measurability with
    respect to ρ. A target odd at x cannot factor through ρ. "Outside the
    register" is no longer a metaphor: it is non-measurability, proved. -/
theorem T10_factorization (τ : α → α) (ρ : α → β) (g : β → Bool)
    (d : α → Bool) (x : α)
    (hρ : ρ (τ x) = ρ x) (hd : d (τ x) = !d x) :
    d ≠ fun y => g (ρ y) := by
  intro h
  have h1 : d (τ x) = g (ρ (τ x)) := congrFun h (τ x)
  have h2 : d x = g (ρ x) := congrFun h x
  rw [hρ, hd, h2] at h1
  cases hgx : g (ρ x) <;> rw [hgx] at h1 <;> exact absurd h1 (by decide)

/-- T11 · RESOLVER SEPARATION. If an added observation a resolves d jointly
    with ρ — d(y) = r (ρ y) (a y) for some readout r — then a must separate
    every odd pair: a(τx) ≠ a(x). This proves ONLY local, pointwise
    separation: a Bool-valued a may separate every orbit while its alphabet
    stays {0,1}. The 2^m alphabet bound belongs to a different object — a
    single global message selecting one target from an admissible family —
    and is proved by T12's injectivity, never by T11 alone. -/
theorem T11_separation (τ : α → α) (ρ : α → β) (a : α → γ) (r : β → γ → Bool)
    (d : α → Bool) (x : α)
    (hρ : ρ (τ x) = ρ x) (hd : d (τ x) = !d x)
    (hres : ∀ y, d y = r (ρ y) (a y)) :
    a (τ x) ≠ a x := by
  intro h
  have h1 := hres (τ x)
  have h2 := hres x
  rw [hρ, h, hd, h2] at h1
  cases hrv : r (ρ x) (a x) <;> rw [hrv] at h1 <;> exact absurd h1 (by decide)

/-- T12 · THE GLOBAL CODE IS INJECTIVE. If a global message selects the
    target exactly — an encoder Enc and decoder Dec with Dec ∘ Enc = id on
    the admissible family — then Enc is injective, so the supply alphabet
    is at least as large as the family. This is the mechanism behind the
    counting bound: for the full wholly-odd family on m orbits, |S| >= 2^m
    (executed on the exhibited frame, battery K4); for an admissible
    subfamily A, |S| >= |A|. The one-bit crossing is exactly |A| = 2.
    Grading note: finite-cardinality monotonicity for injections
    (Fintype.card_le_of_injective) is mathlib machinery, outside this
    core-only file; the injectivity is proved here, the instance count is
    executed in K4 (2^6 = 64, pairwise distinct, alphabet >= 64). -/
theorem T12_encoder_injective {δ : Type} (Enc : δ → γ) (Dec : γ → δ)
    (h : ∀ d, Dec (Enc d) = d) :
    ∀ d₁ d₂ : δ, Enc d₁ = Enc d₂ → d₁ = d₂ := by
  intro d₁ d₂ hE
  have h1 := h d₁
  have h2 := h d₂
  rw [hE] at h1
  rw [h2] at h1
  exact h1.symm

/-- T14 · THE WALL, FACTORIZATION FORM (the final audit's exact statement).
    No target separating a τ-pair factors through any τ-invariant
    observation map: there is no g with g ∘ ρ = d. Stated without any
    finiteness hypothesis — stronger than the requested form, which
    assumed [Fintype U]. The proper formulation of "outside the register",
    companion to T10 (which quantifies over g pointwise; T14 closes the
    existential). -/
theorem T14_wall_factorization (τ : α → α) (ρ : α → β) (d : α → Bool) (x : α)
    (hρ : ∀ z, ρ (τ z) = ρ z) (hd : OddAt τ d x) :
    ¬ ∃ g : β → Bool, ∀ z, g (ρ z) = d z := by
  intro h
  obtain ⟨g, hg⟩ := h
  have h1 : d (τ x) = g (ρ (τ x)) := (hg (τ x)).symm
  have h2 : g (ρ (τ x)) = g (ρ x) := by rw [hρ x]
  have h3 : g (ρ x) = d x := hg x
  exact hd (h1.trans (h2.trans h3))

/-- T13 · THE TWO ODDS, TYPED. Wholly odd implies odd at every point.
    The converse is false and is not claimed: a merely non-invariant
    target may restrict arbitrarily on other orbits. The torsor (T8, T9)
    and the 2^m fibre count apply to the wholly-odd family only; the wall
    (T1, T7) needs only oddness at the seat. The two notions are separate
    hypotheses in this file and are never interchanged. -/
theorem T13_wholly_odd_is_odd_everywhere (τ : α → α) (d : α → Bool)
    (hd : WhollyOdd τ d) (x : α) : OddAt τ d x := by
  intro h
  rw [hd x] at h
  cases d x <;> simp at h

/-- The canonical free involution frame: Bool × Q with the flip.
    Its orbits are exactly the pairs {(true, q), (false, q)}, so its
    orbit quotient is Q itself. -/
def flipF {Q : Type} : Bool × Q → Bool × Q := fun (b, q) => (!b, q)

/-- T15a · THE PRICE, BIJECTION FORM (canonical frame), FORWARD ROUND TRIP.
    On the canonical frame, every wholly anti-invariant target is
    reconstructed from its values at the true-section: the map
    d ↦ (q ↦ d (true, q)) into (Q → Bool), followed by
    c ↦ ((b, q) ↦ xor (c q) (!b)), returns d exactly. Since the orbit
    quotient of the canonical frame is Q, this is one direction of
    Dτ(U) ≃ (U/τ → Bool). The exhibited K4 frame is the finite instance
    (Q = six seats); the cardinal corollary |Dτ(U)| = 2^|Q| is executed
    there and, in a mathlib build, follows by Fintype.card_congr. -/
theorem T15_price_bijection_forward {Q : Type} (d : Bool × Q → Bool)
    (hd : WhollyOdd flipF d) (b : Bool) (q : Q) :
    xor (d (true, q)) (!b) = d (b, q) := by
  have h : d (false, q) = !d (true, q) := hd (true, q)
  cases b
  · generalize ht : d (true, q) = tv
    generalize hf : d (false, q) = fv
    rw [ht, hf] at h
    cases tv <;> cases fv <;>
      first | rfl | exact h | exact h.symm | exact absurd h (by decide)
  · cases d (true, q) <;> rfl

/-- T15b · THE PRICE, BIJECTION FORM (canonical frame), BACKWARD.
    For every c : Q → Bool, the section (b, q) ↦ xor (c q) (!b) is wholly
    anti-invariant, and its true-section is c exactly: the maps are mutual
    inverses between Dτ(U) and (Q → Bool). -/
theorem T15_price_bijection_backward {Q : Type} (c : Q → Bool) :
    WhollyOdd flipF (fun (b, q) => xor (c q) (!b)) := by
  intro x
  obtain ⟨b, q⟩ := x
  show xor (c q) (!!b) = !xor (c q) (!b)
  cases c q <;> cases b <;> rfl

end FullSetup

/-- The whole theorem content in one line:
    a target odd at its seat is undecidable by the even register (T1, T2),
    missing exactly one bit (T4), and decided by exactly one supplied bit
    plus one calibration (T5). -/
theorem fTOE_core (τ : α → α) (s d : α → Bool) (x : α)
    (f g : α → Bool) (hf : Even τ f) (hg : Even τ g) (op : Bool → Bool → Bool)
    (hd : d (τ x) = !d x) (hs : s (τ x) = !s x) :
    (fun y => op (f y) (g y)) ≠ d ∧
    ∃ c : Bool, (d x = xor (s x) c ∧ d (τ x) = xor (s (τ x)) c) ∧
      ∀ c' : Bool, (d x = xor (s x) c' ∧ d (τ x) = xor (s (τ x)) c') → c' = c :=
  ⟨T2_coalition τ f g d x hf hg op (by intro h; rw [hd] at h; cases d x <;> simp at h),
   T5_crossing τ s d x hs hd⟩

end FTOE

/- Verification contract: this file must pass `lean fTOE_Formal_Proof.lean`
   with no output and exit code 0. Any edit that weakens a hypothesis,
   adds a sorry, or deletes a conjunct must fail that check. -/


namespace FTOE

variable {α : Type}

def OrbitRel (τ : α → α) (x y : α) : Prop := x = y ∨ τ x = y

theorem OrbitRel_symmetric (τ : α → α) (hinv : Involution τ) {x y : α} :
    OrbitRel τ x y → OrbitRel τ y x := by
  intro h
  cases h with
  | inl h => exact Or.inl h.symm
  | inr h => exact Or.inr (by rw [← h]; exact hinv x)

def Dtau (τ : α → α) : Type := { d : α → Bool // WhollyOdd τ d }

def calib (d0 d : α → Bool) : α → Bool := fun x => xor (d x) (d0 x)

theorem calib_even (τ : α → α) (d0 d : α → Bool)
    (h0 : WhollyOdd τ d0) (hd : WhollyOdd τ d) : Even τ (calib d0 d) :=
  T8_torsor_forward τ d0 d h0 hd

def descend (τ : α → α) (e : α → Bool) (he : Even τ e) :
    Quot (OrbitRel τ) → Bool :=
  Quot.lift e (by
    intro a b hab
    cases hab with
    | inl h => rw [h]
    | inr h => rw [← h]; exact (he a).symm)

def priceForward (τ : α → α) (d0 : Dtau τ) (d : Dtau τ) :
    Quot (OrbitRel τ) → Bool :=
  descend τ (calib d0.1 d.1) (calib_even τ d0.1 d.1 d0.2 d.2)

def priceBackward (τ : α → α) (hinv : Involution τ) (d0 : Dtau τ)
    (e : Quot (OrbitRel τ) → Bool) : Dtau τ :=
  ⟨fun x => xor (d0.1 x) (e (Quot.mk (OrbitRel τ) x)), by
    intro x
    show xor (d0.1 (τ x)) (e (Quot.mk (OrbitRel τ) (τ x)))
       = !xor (d0.1 x) (e (Quot.mk (OrbitRel τ) x))
    have hq : Quot.mk (OrbitRel τ) (τ x) = Quot.mk (OrbitRel τ) x :=
      Quot.sound (Or.inr (hinv x))
    rw [hq, d0.2 x]
    cases d0.1 x <;> cases e (Quot.mk (OrbitRel τ) x) <;> rfl⟩

theorem T16_left_inverse (τ : α → α) (hinv : Involution τ) (d0 : Dtau τ) :
    Codex.LeftInverse (priceBackward τ hinv d0) (priceForward τ d0) := by
  intro d
  apply Subtype.ext
  funext x
  show xor (d0.1 x) (xor (d.1 x) (d0.1 x)) = d.1 x
  cases d.1 x <;> cases d0.1 x <;> rfl

theorem T16_right_inverse (τ : α → α) (hinv : Involution τ) (d0 : Dtau τ) :
    Codex.RightInverse (priceBackward τ hinv d0) (priceForward τ d0) := by
  intro e
  funext q
  induction q using Quot.ind with
  | _ x =>
    show xor (xor (d0.1 x) (e (Quot.mk (OrbitRel τ) x))) (d0.1 x)
       = e (Quot.mk (OrbitRel τ) x)
    generalize e (Quot.mk (OrbitRel τ) x) = b
    generalize d0.1 x = a
    cases a <;> cases b <;> rfl

theorem T16_price_bijection (τ : α → α) (hinv : Involution τ) (d0 : Dtau τ) :
    Nonempty (Dtau τ ≃ (Quot (OrbitRel τ) → Bool)) :=
  ⟨{ toFun := priceForward τ d0
     invFun := priceBackward τ hinv d0
     left_inv := T16_left_inverse τ hinv d0
     right_inv := T16_right_inverse τ hinv d0 }⟩

def canonD0 : Dtau (flipF (Q := Bool)) :=
  ⟨fun (b, _) => b, by intro x; obtain ⟨b, q⟩ := x; rfl⟩

theorem flipF_involution : Involution (flipF (Q := Bool)) := by
  intro x; obtain ⟨b, q⟩ := x; cases b <;> rfl

theorem T16_canonical :
    Nonempty (Dtau (flipF (Q := Bool)) ≃
      (Quot (OrbitRel (flipF (Q := Bool))) → Bool)) :=
  T16_price_bijection (flipF (Q := Bool)) flipF_involution canonD0

theorem T17_odd_everywhere_iff_wholly_odd (τ : α → α) (d : α → Bool) :
    (∀ x, d (τ x) ≠ d x) ↔ (∀ x, d (τ x) = !d x) := by
  constructor
  · intro h x
    have hx := h x
    cases hd : d x <;> cases ht : d (τ x) <;> simp_all
  · intro h x
    have hx := h x
    cases hd : d x <;> cases ht : d (τ x) <;> simp_all

end FTOE

namespace K4

def val : Nat → Nat
  | 0 => 11 | 1 => 851 | 2 => 13 | 3 => 1273 | 4 => 17 | 5 => 437
  | 6 => 19 | 7 => 2119 | 8 => 23 | 9 => 1703 | 10 => 29 | 11 => 869
  | _ => 0

def tau : Nat → Nat := fun i =>
  if i < 12 then (if i % 2 = 0 then i + 1 else i - 1) else i

def target : Nat → Bool := fun i => i % 2 == 0

def rho : Nat → Nat := fun i =>
  (val i % 2) * 1000 + (val i % 3) * 100 + (val i % 5) * 10 + (val i % 7)

theorem tau_involution : ∀ i, i < 12 → tau (tau i) = i := by decide

theorem tau_fixed_point_free : ∀ i, i < 12 → tau i ≠ i := by decide

theorem target_wholly_odd : ∀ i, i < 12 → target (tau i) = !target i := by decide

theorem register_even : ∀ i, i < 12 → rho (tau i) = rho i := by decide

theorem val_lifts_mod_210 : ∀ i, i < 12 → i % 2 = 1 →
    val i > val (tau i) ∧ (val i - val (tau i)) % 210 = 0 := by decide

theorem wall (g : Nat → Bool) : target ≠ fun y => g (rho y) :=
  FTOE.T10_factorization tau rho g target 0
    (register_even 0 (by decide)) (target_wholly_odd 0 (by decide))

theorem pair_distinct : target ≠ fun i => !target i := by
  intro h
  exact absurd (congrFun h 0) (by decide)

theorem price_one_bit : 2^1 = 2 := rfl

theorem price_full_fibre : (2 : Nat)^6 = 64 := by decide

def wallClaim : Claim where
  stmt := ∀ g : Nat → Bool, target ≠ fun y => g (rho y)
  grade := .theorem
  warrant := wall

end K4

namespace Audit

inductive Token : Type
  | sealed | broken | opn | refused | determined | dotmark
  | gok | golok | void | aGivenRA | iAm | interior
  deriving DecidableEq, Repr, BEq

inductive Compartment : Type
  | closureRowed | unpopulated | worldRowed | none
  deriving DecidableEq, Repr, BEq

inductive Ans : Type
  | yes | no | unknown
  deriving DecidableEq, Repr, BEq

def Ans.toBool : Ans → Bool
  | .yes => true
  | _ => false

structure ClaimInput where
  hasContent  : Ans
  facesScoped : Ans
  canonical   : Ans
  forwardMode : Ans
  populated   : Ans
  worldlyRow  : Ans
  drillsOk    : Ans
  frameClosed : Ans
  slots       : Option (List (List Int))
  deriving Repr

def ClaimInput.anyUnknown (i : ClaimInput) : Bool :=
  [i.hasContent, i.facesScoped, i.canonical, i.forwardMode, i.populated,
   i.worldlyRow, i.drillsOk, i.frameClosed].any (· == Ans.unknown)
    || i.slots.isNone

def sealL : Option (List (List Int)) → Token × String
  | none => (.opn, "S-L0: vocabulary slots not supplied; under-determined")
  | some slots =>
    let nz := slots.map (fun s => s.filter (· != 0))
    if slots.flatten.any (fun x => decide (x < 0)) then
      (.broken, "negative literal id; not vocabulary")
    else
      let nfull := (nz.filter (fun s => !s.isEmpty)).length
      if nfull != 3 then
        (.broken, s!"deletion test returns {nfull} slots, not three")
      else if nz.any (fun s => s.length != s.eraseDups.length) then
        (.broken, "repeated literal within slot")
      else
        let flat := nz.flatten
        if flat.length != flat.eraseDups.length then
          (.broken, "LIT collision across slots")
        else
          (.sealed, "three slots, vocabulary pairwise disjoint")

structure DrillInput where
  d1 : Ans
  d2 : Ans
  d3Filed : Ans
  d3Shaped : Ans
  d4 : Ans
  d5 : Ans
  d6 : Ans
  deriving Repr

def DrillInput.anyUnknown (d : DrillInput) : Bool :=
  [d.d1, d.d2, d.d3Filed, d.d3Shaped, d.d4, d.d5, d.d6].any (· == Ans.unknown)

def drillScreen (d : DrillInput) : Token × Grade × String :=
  if d.anyUnknown then
    (.opn, .premise, "drill screen under-determined: a drill was not run")
  else if !(d.d1.toBool && d.d2.toBool) then
    (.broken, .premise, "D1/D2 fail: Seal L break, terminal whatever the determinant reads")
  else if !d.d3Filed.toBool then
    (.broken, .premise, "D3 fail: provenance unfiled; Number-shaped content in the Tongue seat")
  else if !d.d4.toBool then
    (.broken, .premise, "D4 fail: a magnitude carried on the Tongue; sign only, veto never substitution")
  else if !d.d5.toBool then
    (.broken, .premise, "D5 fail: register undeclared; re-index rather than refute")
  else if !d.d6.toBool then
    (.broken, .premise, "D6 fail: the Tongue reproduced the blindness it was appointed to repair")
  else if d.d3Shaped.toBool then
    (.sealed, .structural, "drills pass; provenance filed and SHAPED, so the assignment caps at structural")
  else
    (.sealed, .theorem, "drills pass; provenance filed and unshaped, no tier discount")

def refusalGates (i : ClaimInput) : Option (Compartment × Token × String) :=
  if !i.hasContent.toBool then
    some (.none, .refused, "F-0: every term decoration; contentless, refused, not compartmented")
  else if !i.facesScoped.toBool then
    some (.none, .refused, "R-1: faces not enumerated; a composite carries one compartment per face")
  else if !i.canonical.toBool then
    some (.none, .refused, "R-2: not canonicalised; the compartment attaches to the stripped string")
  else none

def compartmentGates (i : ClaimInput) : Compartment × Token × String :=
  if !i.populated.toBool then
    (.unpopulated, .opn, "S-1: an axis is empty; two planes meet in a line; no lock forms")
  else if i.forwardMode.toBool then
    (.worldRowed, .determined, "R-3: a dated axis must be sourced, never measured; world-rowed unconditionally")
  else if i.worldlyRow.toBool then
    (.worldRowed, .determined, "S-2: a row furnished by the world; the lock is total given those rows")
  else if !i.drillsOk.toBool then
    (.worldRowed, .opn, "S-3: term closure unscreened; typed by its remaining rows")
  else if !i.frameClosed.toBool then
    (.worldRowed, .opn, "S-4: existential import or transport; the leak names the compartment")
  else
    (.closureRowed, .sealed, "rows are the closure; the two determinations are one; conditional on the root posit at the act")

def auditClaim (i : ClaimInput) : Compartment × Token × String :=
  if i.anyUnknown then
    (.none, .opn, "under-determined reading: a gate or the slots were not supplied; first failure terminal, nothing sealed")
  else
    match refusalGates i with
    | some r => r
    | none =>
      match sealL i.slots with
      | (.broken, msg) => (.none, .broken, s!"Seal L break, terminal: {msg}")
      | _ => compartmentGates i

def compartmentGrade : Compartment → Grade → String
  | .closureRowed, cap =>
      s!"row-indefeasible, defeasible against fault, cap {repr cap}"
  | .unpopulated, _ => "no determination to defeat; an axis is owed"
  | .worldRowed, _ =>
      "revisable entirely in the rows; direction bought with the arrow"
  | .none, _ => "no compartment"

theorem unknown_routes_open (i : ClaimInput) (h : i.anyUnknown = true) :
    (auditClaim i).2.1 = Token.opn := by
  simp [auditClaim, h]

theorem contentless_refused (i : ClaimInput)
    (hk : i.anyUnknown = false) (hc : i.hasContent = Ans.no) :
    (auditClaim i).2.1 = Token.refused := by
  unfold auditClaim refusalGates
  rw [hk]
  simp [hc, Ans.toBool]

def det3 (m : Fin 3 → Fin 3 → Ratio) : Ratio :=
  m 0 0 * (m 1 1 * m 2 2 - m 1 2 * m 2 1)
    - m 0 1 * (m 1 0 * m 2 2 - m 1 2 * m 2 0)
    + m 0 2 * (m 1 0 * m 2 1 - m 1 1 * m 2 0)

theorem det3_two_id : det3 (fun a b => if a == b then (2 : Ratio) else 0) = 8 := by
  decide

end Audit

#eval Audit.auditClaim {
  hasContent := .no, facesScoped := .yes, canonical := .yes,
  forwardMode := .no, populated := .yes, worldlyRow := .no,
  drillsOk := .yes, frameClosed := .yes, slots := some [[1], [2], [3]] }

#eval Audit.auditClaim {
  hasContent := .yes, facesScoped := .yes, canonical := .yes,
  forwardMode := .no, populated := .yes, worldlyRow := .no,
  drillsOk := .yes, frameClosed := .yes, slots := some [[1, 2], [3], [4]] }

#eval Audit.auditClaim {
  hasContent := .yes, facesScoped := .yes, canonical := .unknown,
  forwardMode := .no, populated := .yes, worldlyRow := .no,
  drillsOk := .yes, frameClosed := .yes, slots := some [[1], [2], [3]] }

#eval Audit.auditClaim {
  hasContent := .yes, facesScoped := .yes, canonical := .yes,
  forwardMode := .no, populated := .yes, worldlyRow := .no,
  drillsOk := .yes, frameClosed := .yes, slots := some [[1, 2], [3], [2]] }

#eval Audit.det3 (fun a b => if a == b then (2 : Ratio) else (0 : Ratio))

namespace INVERSION

def ItFromBit {α β : Type} (ρ : α → β) (d : α → Bool) : Prop :=
  ∃ g : β → Bool, d = fun y => g (ρ y)

theorem it_from_bit_refuted {α β : Type} (τ : α → α) (ρ : α → β)
    (d : α → Bool) (x : α)
    (hρ : ρ (τ x) = ρ x) (hd : d (τ x) = !d x) :
    ¬ ItFromBit ρ d := by
  intro h
  obtain ⟨g, hg⟩ := h
  exact FTOE.T10_factorization τ ρ g d x hρ hd hg

structure ItFromIt {α β : Type} (τ : α → α) (ρ : α → β) (d : α → Bool)
    (x : α) : Prop where
  
  record_collapses : ρ (τ x) = ρ x
  
  pair_genuine : τ x ≠ x
  
  target_separates : d (τ x) = !d x
  
  no_return : ¬ ItFromBit ρ d

theorem it_from_it {α β : Type} (τ : α → α) (ρ : α → β) (d : α → Bool)
    (x : α) (hρ : ρ (τ x) = ρ x) (hpair : τ x ≠ x) (hd : d (τ x) = !d x) :
    ItFromIt τ ρ d x :=
  ⟨hρ, hpair, hd, it_from_bit_refuted τ ρ d x hρ hd⟩

end INVERSION

namespace K4

theorem it_from_it_canonical :
    INVERSION.ItFromIt tau rho target 0 :=
  INVERSION.it_from_it tau rho target 0
    (register_even 0 (by decide)) (by decide) (target_wholly_odd 0 (by decide))

theorem it_from_bit_refuted_canonical :
    ¬ INVERSION.ItFromBit rho target :=
  it_from_it_canonical.no_return

def inversionClaim : Claim where
  stmt := INVERSION.ItFromIt tau rho target 0
  grade := .theorem
  warrant := it_from_it_canonical

end K4

namespace GEO

structure Q4 where
  r : Int
  i : Int
  j : Int
  k : Int
  deriving DecidableEq, Repr, BEq

def qmul (a b : Q4) : Q4 :=
  ⟨a.r*b.r - a.i*b.i - a.j*b.j - a.k*b.k,
   a.r*b.i + a.i*b.r + a.j*b.k - a.k*b.j,
   a.r*b.j - a.i*b.k + a.j*b.r + a.k*b.i,
   a.r*b.k + a.i*b.j - a.j*b.i + a.k*b.r⟩

def qconj (a : Q4) : Q4 := ⟨a.r, -a.i, -a.j, -a.k⟩
def qadd (a b : Q4) : Q4 := ⟨a.r+b.r, a.i+b.i, a.j+b.j, a.k+b.k⟩
def qsub (a b : Q4) : Q4 := ⟨a.r-b.r, a.i-b.i, a.j-b.j, a.k-b.k⟩
def qnorm2 (a : Q4) : Int := a.r*a.r + a.i*a.i + a.j*a.j + a.k*a.k
def qhalve (a : Q4) : Q4 := ⟨a.r/2, a.i/2, a.j/2, a.k/2⟩
def qquarter (a : Q4) : Q4 := ⟨a.r/4, a.i/4, a.j/4, a.k/4⟩

def qcanon (a : Q4) : Q4 :=
  if a.r != 0 then (if a.r < 0 then ⟨-a.r,-a.i,-a.j,-a.k⟩ else a)
  else if a.i != 0 then (if a.i < 0 then ⟨-a.r,-a.i,-a.j,-a.k⟩ else a)
  else if a.j != 0 then (if a.j < 0 then ⟨-a.r,-a.i,-a.j,-a.k⟩ else a)
  else if a.k != 0 then (if a.k < 0 then ⟨-a.r,-a.i,-a.j,-a.k⟩ else a)
  else a

def q1 : Q4 := ⟨1,0,0,0⟩
def qi : Q4 := ⟨0,1,0,0⟩
def qj : Q4 := ⟨0,0,1,0⟩
def qk : Q4 := ⟨0,0,0,1⟩

theorem chirality : qmul (qmul qi qj) qk = ⟨-1,0,0,0⟩ := rfl

theorem noncommutative : qmul qi qj ≠ qmul qj qi := by decide

def hurwitz : List Q4 :=
  [⟨2,0,0,0⟩,⟨-2,0,0,0⟩,⟨0,2,0,0⟩,⟨0,-2,0,0⟩,
   ⟨0,0,2,0⟩,⟨0,0,-2,0⟩,⟨0,0,0,2⟩,⟨0,0,0,-2⟩,
   ⟨1,1,1,1⟩,⟨1,1,1,-1⟩,⟨1,1,-1,1⟩,⟨1,1,-1,-1⟩,
   ⟨1,-1,1,1⟩,⟨1,-1,1,-1⟩,⟨1,-1,-1,1⟩,⟨1,-1,-1,-1⟩,
   ⟨-1,1,1,1⟩,⟨-1,1,1,-1⟩,⟨-1,1,-1,1⟩,⟨-1,1,-1,-1⟩,
   ⟨-1,-1,1,1⟩,⟨-1,-1,1,-1⟩,⟨-1,-1,-1,1⟩,⟨-1,-1,-1,-1⟩]

theorem hurwitz_norm : (hurwitz.all (fun u => qnorm2 u == 4)) = true := by decide

theorem hurwitz_products_even :
    (hurwitz.all (fun a => hurwitz.all (fun b =>
      let p := qmul a b
      (p.r % 2 == 0) && (p.i % 2 == 0) && (p.j % 2 == 0) && (p.k % 2 == 0)))) = true := by
  decide

theorem hurwitz_closed :
    (hurwitz.all (fun a => hurwitz.all (fun b =>
      hurwitz.any (fun u => u == qhalve (qmul a b))))) = true := by
  decide

def hurwitzReps : List Q4 := (hurwitz.map qcanon).eraseDups

theorem units_mod_sign_twelve : hurwitzReps.length = 12 := by decide

def conjClass (r : Q4) : List Q4 :=
  (hurwitz.map (fun u => qcanon (qquarter (qmul (qmul u r) (qconj u))))).eraseDups

def classSizesAux : List Q4 → List Q4 → List Nat
  | [], _ => []
  | r :: rest, seen =>
    if seen.any (fun s => s == r) then classSizesAux rest seen
    else
      let cls := conjClass r
      cls.length :: classSizesAux rest (seen ++ cls)

def insNat (n : Nat) : List Nat → List Nat
  | [] => [n]
  | m :: ms => if n ≤ m then n :: m :: ms else m :: insNat n ms
def insSort : List Nat → List Nat
  | [] => []
  | n :: ns => insNat n (insSort ns)

theorem class_equation :
    insSort (classSizesAux hurwitzReps []) = [1, 3, 4, 4] := by decide

def shell2 : List Q4 :=
  let v : List Int := [-1, 0, 1]
  (v.flatMap (fun r => v.flatMap (fun i => v.flatMap (fun j =>
    v.map (fun k => ⟨r,i,j,k⟩))))).filter (fun q => qnorm2 q == 2)

theorem shell_twentyfour :
    (shell2.length == 24) &&
    ((shell2.filter (fun q => q.r == 0)).length == 12) &&
    ((shell2.filter (fun q => q.r != 0)).length == 12) = true := by decide

set_option maxRecDepth 8000 in

theorem no_half_integer_norm2 :
    (let v : List Int := [-3, -1, 1, 3]
     (v.flatMap (fun r => v.flatMap (fun i => v.flatMap (fun j =>
       v.map (fun k => ⟨r,i,j,k⟩))))).all (fun q => qnorm2 q != 8)) = true := by
  decide

def allGates : List (Nat × Nat) :=
  [(0,1),(0,2),(0,3),(1,0),(1,2),(1,3),(2,0),(2,1),(2,3),(3,0),(3,1),(3,2)]

theorem gates_twelve : allGates.length = 12 := rfl

theorem gates_valid :
    (allGates.all (fun g => (g.1 != g.2) && (g.1 < 4) && (g.2 < 4))) = true := by decide

theorem gates_complete : ∀ a b : Fin 4, a ≠ b → ((a : Nat), (b : Nat)) ∈ allGates := by
  decide

def invCount (σ : List Nat) : Nat :=
  let idx := List.range σ.length
  let pairs := idx.flatMap (fun a => (idx.filter (fun b => a < b)).map (fun b => (a, b)))
  (pairs.filter (fun p => σ.getD p.1 0 > σ.getD p.2 0)).length

def perms24 : List (List Nat) :=
  [[0,1,2,3],[0,1,3,2],[0,2,1,3],[0,2,3,1],[0,3,1,2],[0,3,2,1],
   [1,0,2,3],[1,0,3,2],[1,2,0,3],[1,2,3,0],[1,3,0,2],[1,3,2,0],
   [2,0,1,3],[2,0,3,1],[2,1,0,3],[2,1,3,0],[2,3,0,1],[2,3,1,0],
   [3,0,1,2],[3,0,2,1],[3,1,0,2],[3,1,2,0],[3,2,0,1],[3,2,1,0]]

def a4 : List (List Nat) := perms24.filter (fun σ => invCount σ % 2 == 0)

theorem a4_order : a4.length = 12 := by decide

def actG (σ : List Nat) (g : Nat × Nat) : Nat × Nat := (σ.getD g.1 0, σ.getD g.2 0)

set_option maxRecDepth 100000 in

theorem a4_simply_transitive :
    ∀ a b c d : Fin 4, a ≠ b → c ≠ d →
      (a4.filter (fun σ => actG σ ((a : Nat), (b : Nat)) == ((c : Nat), (d : Nat)))).length = 1 := by
  decide

def tetraVerts : List Nat := [0, 1, 2, 3]
def tetraEdges : List (Nat × Nat) := [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
def tetraFaces : List (Nat × Nat × Nat) := [(0,1,2),(0,1,3),(0,2,3),(1,2,3)]

theorem euler_closure :
    (tetraVerts.length : Int) - tetraEdges.length + tetraFaces.length = 2 := by decide

def basisU : List Q4 := [qi, qj, qk]

def perms6 : List (List Nat) :=
  [[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]]

theorem relabel_parity :
    (perms6.all (fun σ =>
      (qmul (qmul (basisU.getD (σ.getD 0 0) q1) (basisU.getD (σ.getD 1 0) q1)) (basisU.getD (σ.getD 2 0) q1)).r ==
        (if invCount σ % 2 == 0 then -1 else 1))) = true := by
  decide

abbrev O8 := Q4 × Q4

def omul (x y : O8) : O8 :=
  (qsub (qmul x.1 y.1) (qmul (qconj y.2) x.2),
   qadd (qmul y.2 x.1) (qmul x.2 (qconj y.1)))

def osub (x y : O8) : O8 := (qsub x.1 y.1, qsub x.2 y.2)
def onorm2 (x : O8) : Int := qnorm2 x.1 + qnorm2 x.2

def e8 (n : Nat) : O8 :=
  let q := fun k => if k == n then (1 : Int) else 0
  (⟨q 0, q 1, q 2, q 3⟩, ⟨q 4, q 5, q 6, q 7⟩)

theorem octonion_associator :
    osub (omul (omul (e8 1) (e8 2)) (e8 4)) (omul (e8 1) (omul (e8 2) (e8 4)))
      = (⟨0,0,0,0⟩, ⟨0,0,0,2⟩) := by
  decide

def hPairs : List (Q4 × Q4) :=
  let v : List Int := [-1, 0, 1]
  v.flatMap (fun i => v.flatMap (fun j => v.map (fun k =>
    (⟨i,j,k,1⟩, ⟨1,k,j,i⟩))))

theorem norm_composition_H :
    (hPairs.all (fun p => qnorm2 (qmul p.1 p.2) == qnorm2 p.1 * qnorm2 p.2)) = true := by
  decide

def oPairs : List (O8 × O8) :=
  let v : List Int := [-1, 0, 1]
  v.flatMap (fun i => v.flatMap (fun j => v.map (fun k =>
    ((⟨i,j,k,1⟩, ⟨j,k,i,1⟩), (⟨1,k,i,j⟩, ⟨1,i,j,k⟩)))))

theorem norm_composition_O :
    (oPairs.all (fun p => onorm2 (omul p.1 p.2) == onorm2 p.1 * onorm2 p.2)) = true := by
  decide
  
set_option maxRecDepth 1000000
  def det2 (r1 r2 r3 : Nat × Nat × Nat) : Nat :=
    (r1.1 * (r2.2.1 * r3.2.2 + r2.2.2 * r3.2.1)
       + r1.2.1 * (r2.1 * r3.2.2 + r2.2.2 * r3.1)
       + r1.2.2 * (r2.1 * r3.2.1 + r2.2.1 * r3.1)) % 2
  def gf2Mul (r1 r2 r3 : Nat × Nat × Nat) (v : Nat × Nat × Nat) : Nat × Nat × Nat :=
    ((r1.1 * v.1 + r1.2.1 * v.2.1 + r1.2.2 * v.2.2) % 2,
     (r2.1 * v.1 + r2.2.1 * v.2.1 + r2.2.2 * v.2.2) % 2,
     (r3.1 * v.1 + r3.2.1 * v.2.1 + r3.2.2 * v.2.2) % 2)
  
  def gf2Vecs : List (Nat × Nat × Nat) :=
    (List.range 8).map (fun n => (n / 4 % 2, n / 2 % 2, n % 2))
  def gf2Sols (r1 r2 r3 : Nat × Nat × Nat) (t : Nat × Nat × Nat) : List (Nat × Nat × Nat) :=
    gf2Vecs.filter (fun v => decide (gf2Mul r1 r2 r3 v = t))

  set_option maxRecDepth 1000000 in
  
  theorem triaxial_lock_gf2 :
      ∀ a1 a2 a3 b1 b2 b3 c1 c2 c3 t1 t2 t3 : Fin 2,
        (det2 ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
              ((c1 : Nat), (c2 : Nat), (c3 : Nat)) = 1 ↔
         (gf2Sols ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
                  ((c1 : Nat), (c2 : Nat), (c3 : Nat))
                  ((t1 : Nat), (t2 : Nat), (t3 : Nat))).length = 1) := by
    decide
  
  theorem triaxial_lock_gf2_count :
      ((List.range 4096).filter (fun n =>
        det2 (n / 2048 % 2, n / 1024 % 2, n / 512 % 2)
             (n / 256 % 2, n / 128 % 2, n / 64 % 2)
             (n / 32 % 2, n / 16 % 2, n / 8 % 2) = 1)).length = 1344 := by
    decide
  theorem triaxial_open_gf2_count :
      ((List.range 4096).filter (fun n =>
        det2 (n / 2048 % 2, n / 1024 % 2, n / 512 % 2)
             (n / 256 % 2, n / 128 % 2, n / 64 % 2)
             (n / 32 % 2, n / 16 % 2, n / 8 % 2) = 0)).length = 2752 := by
    decide
  
  abbrev V3 := Ratio × Ratio × Ratio
  abbrev M3 := V3 × V3 × V3

  def det3 (m : M3) : Ratio :=
    let ⟨a, b, c⟩ := m.1
    let ⟨d, e, f⟩ := m.2.1
    let ⟨g, h, i⟩ := m.2.2
    a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)

  
  def adj3 (m : M3) : M3 :=
    let ⟨a, b, c⟩ := m.1
    let ⟨d, e, f⟩ := m.2.1
    let ⟨g, h, i⟩ := m.2.2
    ((e * i - f * h, c * h - b * i, b * f - c * e),
     (f * g - d * i, a * i - c * g, c * d - a * f),
     (d * h - e * g, b * g - a * h, a * e - b * d))

  def mm3 (x y : M3) : M3 :=
    
    
    
    let row (r : V3) (c : Nat) : Ratio :=
      r.1 * (match c with | 0 => y.1.1 | 1 => y.1.2.1 | _ => y.1.2.2)
      + r.2.1 * (match c with | 0 => y.2.1.1 | 1 => y.2.1.2.1 | _ => y.2.1.2.2)
      + r.2.2 * (match c with | 0 => y.2.2.1 | 1 => y.2.2.2.1 | _ => y.2.2.2.2)
    ((row x.1 0, row x.1 1, row x.1 2),
     (row x.2.1 0, row x.2.1 1, row x.2.1 2),
     (row x.2.2 0, row x.2.2 1, row x.2.2 2))

  def diag3 (r : Ratio) : M3 := ((r, 0, 0), (0, r, 0), (0, 0, r))
  def mv3 (m : M3) (v : V3) : V3 :=
    (m.1.1 * v.1 + m.1.2.1 * v.2.1 + m.1.2.2 * v.2.2,
     m.2.1.1 * v.1 + m.2.1.2.1 * v.2.1 + m.2.1.2.2 * v.2.2,
     m.2.2.1 * v.1 + m.2.2.2.1 * v.2.1 + m.2.2.2.2 * v.2.2)
  def vscale (v : V3) (r : Ratio) : V3 := (v.1 * r, v.2.1 * r, v.2.2 * r)

  
  abbrev V3Z := Int × Int × Int
  abbrev M3Z := V3Z × V3Z × V3Z
  def det3Z (m : M3Z) : Int :=
    let ⟨a, b, c⟩ := m.1; let ⟨d, e, f⟩ := m.2.1; let ⟨g, h, i⟩ := m.2.2
    a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
  def adj3Z (m : M3Z) : M3Z :=
    let ⟨a, b, c⟩ := m.1; let ⟨d, e, f⟩ := m.2.1; let ⟨g, h, i⟩ := m.2.2
    ((e * i - f * h, c * h - b * i, b * f - c * e),
     (f * g - d * i, a * i - c * g, c * d - a * f),
     (d * h - e * g, b * g - a * h, a * e - b * d))
  def mm3Z (x y : M3Z) : M3Z :=
    let row (r : V3Z) (c : Nat) : Int :=
      r.1 * (match c with | 0 => y.1.1 | 1 => y.1.2.1 | _ => y.1.2.2)
      + r.2.1 * (match c with | 0 => y.2.1.1 | 1 => y.2.1.2.1 | _ => y.2.1.2.2)
      + r.2.2 * (match c with | 0 => y.2.2.1 | 1 => y.2.2.2.1 | _ => y.2.2.2.2)
    ((row x.1 0, row x.1 1, row x.1 2),
     (row x.2.1 0, row x.2.1 1, row x.2.1 2),
     (row x.2.2 0, row x.2.2 1, row x.2.2 2))
  def diag3Z (r : Int) : M3Z := ((r, 0, 0), (0, r, 0), (0, 0, r))

  theorem adjugate_identity_int (m : M3Z) :
      mm3Z m (adj3Z m) = diag3Z (det3Z m) ∧ mm3Z (adj3Z m) m = diag3Z (det3Z m) := by
    obtain ⟨⟨a, b, c⟩, ⟨d, e, f⟩, ⟨g, h, i⟩⟩ := m
    simp only [mm3Z, adj3Z, det3Z, diag3Z, Prod.mk.injEq]
    simp only [Int.mul_sub, Int.sub_mul, Int.mul_assoc]
    refine ⟨⟨⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩⟩, ⟨⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_⟩⟩⟩ <;>
      (try simp only [Int.mul_comm, Int.mul_left_comm]) <;> omega

  
  def AdjugateIdentity3 : Prop :=
    ∀ m : M3, mm3 m (adj3 m) = diag3 (det3 m) ∧ mm3 (adj3 m) m = diag3 (det3 m)

  
  def adj3Samples : List M3 :=
    [((1, 0, 0), (0, 1, 0), (0, 0, 1)),
     ((2, 0, 0), (0, 3, 0), (0, 0, 5)),
     ((1, 2, 3), (4, 5, 6), (7, 8, 9)),
     ((1, 2, 0), (0, 1, 1), (2, 0, 1)),
     ((0, 1, 2), (3, 4, 5), (6, 7, 9)),
     ((2, 1, 1), (1, 2, 1), (1, 1, 2))]
  theorem adj3_executed :
      adj3Samples.all (fun m =>
        decide (mm3 m (adj3 m) = diag3 (det3 m) ∧
                mm3 (adj3 m) m = diag3 (det3 m))) = true := by
    decide

  
  def cramerSolve (m : M3) (t : V3) : Option V3 :=
    if det3 m == 0 then none
    else some (vscale (mv3 (adj3 m) t) (Ratio.inv (det3 m)))
  theorem cramer_executed :
      cramerSolve ((1, 2, 0), (0, 1, 1), (2, 0, 1)) (5, 3, 4)
        = some ((7 : Ratio) / 5, (9 : Ratio) / 5, (6 : Ratio) / 5) ∧
      mv3 ((1, 2, 0), (0, 1, 1), (2, 0, 1)) ((7 : Ratio) / 5, (9 : Ratio) / 5, (6 : Ratio) / 5)
        = (5, 3, 4) := by
    decide

  
  inductive LockState : Type
    | lock | opn | broken
    deriving DecidableEq, Repr, BEq
  inductive GolToken : Type
    | golX | golQ | golOK
    deriving DecidableEq, Repr, BEq

  
  def golAdmit (magnitude ling : LockState) : GolToken × String × Nat :=
    match magnitude with
    | .broken => (.golX, "geometric/math magnitude reports broken geometry; no GOL", 1)
    | .opn => (.golQ, "no geometric/math lock: orthogonal volume unestablished", 2)
    | .lock =>
      match ling with
      | .lock => (.golOK, "magnitude plus direction; proceed to witness and asymmetry", 4)
      | _ => (.golQ, "magnitude locks but Seal L open: determinant carries no direction", 3)
  
  def gateNames : List String :=
    ["SREP", "REG", "SGEG", "CAUSAL", "MIG", "PTB",
     "DUAL", "CSCG", "CSEG", "MTA", "OMA", "ADEG"]
  theorem gateNames_twelve : gateNames.length = 12 := rfl

  
  def gateScreenGo : List String → List Bool → Nat → Bool × String × Nat
    | [], [], _ => (true, "[G-OK] twelve directed gates passed", 0)
    | n :: _, false :: _, k => (false, s!"[X] gate {k} failed: {n}", k)
    | _ :: ns, true :: bs, k => gateScreenGo ns bs (k + 1)
    | _, _, _ => (false, "[X] arity violation: the screen reads exactly twelve gates", 0)

  def gateScreen (passes : List Bool) : Bool × String × Nat :=
    gateScreenGo gateNames passes 1

  theorem gateScreen_clean :
      gateScreen (List.replicate 12 true)
        = (true, "[G-OK] twelve directed gates passed", 0) := by
    decide
  theorem gateScreen_first_failure :
      gateScreen (false :: List.replicate 11 true)
        = (false, "[X] gate 1 failed: SREP", 1) := by
    decide
  theorem gateScreen_names_failed_gate :
      gateScreen (List.replicate 6 true ++ false :: List.replicate 5 true)
        = (false, "[X] gate 7 failed: DUAL", 7) := by
    decide
  theorem gateScreen_arity :
      gateScreen (List.replicate 11 true)
        = (false, "[X] arity violation: the screen reads exactly twelve gates", 0) := by
    decide

  
  inductive RAVerdict : Type
    | refused | iii | ii | void | aGivenRA | opn
    deriving DecidableEq, Repr, BEq

  
  structure ClaimInputRA where
    nonvacuous  : Audit.Ans
    veLive      : Audit.Ans
    forward     : Audit.Ans
    populated   : Audit.Ans
    worldlyRow  : Audit.Ans
    termsClosed : Audit.Ans
    termWorldly : Audit.Ans
    frameClosed : Audit.Ans
    annotate    : Audit.Ans
    deriving Repr

  def ClaimInputRA.anyUnknown (i : ClaimInputRA) : Bool :=
    [i.nonvacuous, i.veLive, i.forward, i.populated, i.worldlyRow,
     i.termsClosed, i.termWorldly, i.frameClosed, i.annotate].any
      (· == Audit.Ans.unknown)

  
  def rowCascadeRACore
      (nonvacuous veLive forward populated worldlyRow
       termsClosed termWorldly frameClosed annotate : Bool) :
      RAVerdict × String × Nat :=
    if !nonvacuous then
      (.refused, "F-0: contentless; a contentless residence verifies nothing", 1)
    else if veLive || forward then
      (.iii, "R-3: V_E live or Forward; world-rowed, revisability in the rows", 3)
    else if !populated then
      (.ii, "S-1: third axis unpopulated; two planes meet in a line, no lock", 2)
    else if worldlyRow then
      (.iii, "S-2: a load-bearing row is furnished by the world", 3)
    else if !termsClosed then
      if termWorldly then (.iii, "S-3: an unclosed term is worldly", 3)
      else (.ii, "S-3: an unclosed term is formal; no closure-rowed lock", 2)
    else if !frameClosed then
      (.iii, "S-4: existential import leaks past the closure", 3)
    else if !annotate then
      (.void, "RA rider absent: an unannotated absolute is void", 5)
    else
      (.aGivenRA, "compartment I, closure-rowed: [seal A . RA], conditional at the act", 4)

  
  def rowCascadeRA (i : ClaimInputRA) : RAVerdict × String × Nat :=
    if i.anyUnknown then
      (.opn, "nullity law: an unanswered gate routes open; the answer is never guessed", 0)
    else
      rowCascadeRACore i.nonvacuous.toBool i.veLive.toBool i.forward.toBool
        i.populated.toBool i.worldlyRow.toBool i.termsClosed.toBool
        i.termWorldly.toBool i.frameClosed.toBool i.annotate.toBool

  
  theorem unknown_routes_open_ra :
      ∀ i : ClaimInputRA, i.anyUnknown = true → (rowCascadeRA i).1 = .opn := by
    intro i h
    simp [rowCascadeRA, h]

  
  def raDecode (n : Nat) : RAVerdict × String × Nat :=
    rowCascadeRACore (n.testBit 8) (n.testBit 7) (n.testBit 6) (n.testBit 5)
      (n.testBit 4) (n.testBit 3) (n.testBit 2) (n.testBit 1) (n.testBit 0)

  
  def raBattery : List (Nat × RAVerdict) :=
    [(299, .aGivenRA), (443, .iii), (267, .ii), (298, .void), (43, .refused),
     (363, .iii), (315, .iii), (295, .iii), (291, .ii), (297, .iii)]
  theorem ra_battery_f2 :
      raBattery.all (fun p => decide ((raDecode p.1).1 = p.2)) = true := by
    decide

  
  theorem ra_ledger_refused :
      ((List.range 512).filter (fun n => decide ((raDecode n).1 = .refused))).length = 256 := by
    decide
  theorem ra_ledger_iii :
      ((List.range 512).filter (fun n => decide ((raDecode n).1 = .iii))).length = 216 := by
    decide
  theorem ra_ledger_ii :
      ((List.range 512).filter (fun n => decide ((raDecode n).1 = .ii))).length = 36 := by
    decide
  theorem ra_ledger_void :
      ((List.range 512).filter (fun n => decide ((raDecode n).1 = .void))).length = 2 := by
    decide
  theorem ra_ledger_aGivenRA :
      ((List.range 512).filter (fun n => decide ((raDecode n).1 = .aGivenRA))).length = 2 := by
    decide

  
  def RAVerdict.toToken : RAVerdict → Audit.Token
    | .refused => .refused
    | .iii => .determined
    | .ii => .determined
    | .void => .void
    | .aGivenRA => .aGivenRA
    | .opn => .opn

  
  def GolToken.toToken : GolToken → Audit.Token
    | .golX => .broken
    | .golQ => .opn
    | .golOK => .golok

  
  def gateScreenToken (r : Bool × String × Nat) : Audit.Token :=
    if r.1 then .gok else .broken

  
  def demoInputA : ClaimInputRA :=
    { nonvacuous := .yes, veLive := .no, forward := .no, populated := .yes,
      worldlyRow := .no, termsClosed := .yes, termWorldly := .no,
      frameClosed := .yes, annotate := .yes }
  def demoInputVoid : ClaimInputRA := { demoInputA with annotate := .no }
  def demoInputOpen : ClaimInputRA := { demoInputA with termsClosed := .unknown }

  #eval golAdmit .lock .lock
  #eval golAdmit .broken .lock
  #eval golAdmit .opn .lock
  #eval golAdmit .lock .opn
  #eval gateScreen (List.replicate 12 true)
  #eval gateScreen (List.replicate 6 true ++ false :: List.replicate 5 true)
  #eval rowCascadeRA demoInputA
  #eval rowCascadeRA demoInputVoid
  #eval rowCascadeRA demoInputOpen
  #eval cramerSolve ((1, 2, 0), (0, 1, 1), (2, 0, 1)) (5, 3, 4)

end GEO

namespace ROOT

axiom U : Type

axiom ΔE : U → Int

axiom RA : ∀ x : U, 0 < ΔE x

def Actuates (x : U) : Prop := 0 < ΔE x

theorem actuation_universal : ∀ x : U, Actuates x := RA

def raClaim : Claim where
  stmt := ∀ x : U, 0 < ΔE x
  grade := .premise
  warrant := RA

structure Cut (X : Type) where
  τ : X → X
  involutive : FTOE.Involution τ
  free : FTOE.FixedPointFree τ

def boolCut : Cut Bool where
  τ := fun b => !b
  involutive := by intro b; cases b <;> rfl
  free := by intro b; cases b <;> decide

axiom FormalDomain : Type
axiom L1m : FormalDomain → Prop
axiom L2m : FormalDomain → Prop
axiom L3m : FormalDomain → Prop
axiom nest_21 : ∀ p, L2m p → L1m p
axiom nest_32 : ∀ p, L3m p → L2m p

theorem nest_31 : ∀ p, L3m p → L1m p := fun p h => nest_21 p (nest_32 p h)

def nestClaim : Claim where
  stmt := ∀ p, L3m p → L1m p
  grade := .conditional
  warrant := nest_31

axiom Ground : Type
axiom σ : Ground → Ground
axiom σ_binding : ∀ g : Ground, σ (σ g) = g

axiom Residence : U → Prop

def throneEmpty : Prop := ∀ x : U, 0 < ΔE x

theorem throne_is_RA : throneEmpty ↔ ∀ x : U, 0 < ΔE x := Iff.rfl

end ROOT

namespace SEALS

structure Seal where
  name : String
  anchor : Prop
  warrant : anchor

def sealL : Seal where
  name := "linguistic-semantic"
  anchor := ∀ c₁ c₂ : Claim, (Claim.join c₁ c₂).grade = Grade.weakest c₁.grade c₂.grade
  warrant := fun c₁ c₂ => Claim.join_grade c₁ c₂

def sealG : Seal where
  name := "topological-geometric"
  anchor := ∀ x : ROOT.U, 0 < ROOT.ΔE x
  warrant := ROOT.RA

def sealM : Seal where
  name := "mathematical"
  anchor := ∀ g : Nat → Bool, K4.target ≠ fun y => g (K4.rho y)
  warrant := K4.wall

theorem seals_distinct :
    "linguistic-semantic" ≠ "topological-geometric" ∧
    "topological-geometric" ≠ "mathematical" ∧
    "linguistic-semantic" ≠ "mathematical" := by decide

theorem seal_names_match :
    sealL.name = "linguistic-semantic" ∧ sealG.name = "topological-geometric" ∧
    sealM.name = "mathematical" := ⟨rfl, rfl, rfl⟩

theorem sealG_walk :
    GEO.allGates.length = 12
    ∧ GEO.a4.length = 12
    ∧ (GEO.tetraVerts.length : Int) - GEO.tetraEdges.length + GEO.tetraFaces.length = 2
    ∧ GEO.gateNames.length = 12
    ∧ (GEO.adj3Samples.all (fun m =>
        decide (GEO.mm3 m (GEO.adj3 m) = GEO.diag3 (GEO.det3 m) ∧
                GEO.mm3 (GEO.adj3 m) m = GEO.diag3 (GEO.det3 m)))) = true
    ∧ (GEO.raBattery.all (fun p =>
        decide ((GEO.raDecode p.1).1 = p.2))) = true :=
  ⟨GEO.gates_twelve, GEO.a4_order, GEO.euler_closure,
   GEO.gateNames_twelve, GEO.adj3_executed, GEO.ra_battery_f2⟩

end SEALS

namespace POSTULATE

axiom FormalFace : Type
axiom KineticFace : Type

axiom Crossing : Type
axiom erasureClass : Crossing → Prop
axiom RegistrationPostulate : ∀ c : Crossing, erasureClass c

axiom Row : Type
axiom SupplyClean : Row → Type

def OneCut : Prop := ∀ r : Row, Nonempty (SupplyClean r)

def F2 (r : Row) : Prop := ¬ Nonempty (SupplyClean r)

theorem F2_kills (r : Row) (h : F2 r) : ¬ OneCut := fun oc => h (oc r)

axiom FrozenData : Type
axiom Algorithm : Type
axiom certifiedPairing : Algorithm → FrozenData → Prop

def BSDContract (C : Algorithm) (D : FrozenData) : Prop := certifiedPairing C D

def F6 (C : Algorithm) (D : FrozenData) : Prop := ¬ BSDContract C D

end POSTULATE

namespace TONGUE

def enlarge {α β : Type} (ρ : α → β) (s : α → Bool) : α → β × Bool :=
  fun x => (ρ x, s x)

theorem unclosed {α β : Type} (τ : α → α) (ρ : α → β) (g : β → Bool)
    (d : α → Bool) (x : α)
    (hρ : ρ (τ x) = ρ x) (hd : d (τ x) = !d x) :
    d ≠ fun y => g (ρ y) :=
  FTOE.T10_factorization τ ρ g d x hρ hd

theorem earned_freedom {α : Type} (τ : α → α) (s d : α → Bool) (x : α)
    (hs : s (τ x) = !s x) (hd : d (τ x) = !d x) (c₁ c₂ : Bool)
    (h1 : d x = xor (s x) c₁ ∧ d (τ x) = xor (s (τ x)) c₁)
    (h2 : d x = xor (s x) c₂ ∧ d (τ x) = xor (s (τ x)) c₂) : c₁ = c₂ := by
  obtain ⟨c, -, hu⟩ := FTOE.T5_crossing τ s d x hs hd
  exact (hu c₁ h1).trans (hu c₂ h2).symm

def colocClaim : Claim := Claim.join ROOT.raClaim K4.wallClaim

theorem coloc_grade : colocClaim.grade = .premise := rfl

theorem ra_grade_pinned : ROOT.raClaim.grade = .premise := rfl
theorem wall_grade_pinned : K4.wallClaim.grade = .theorem := rfl
theorem inversion_grade_pinned : K4.inversionClaim.grade = .theorem := rfl
theorem nest_grade_pinned : ROOT.nestClaim.grade = .conditional := rfl

end TONGUE

theorem terminalWall : ∀ g : Nat → Bool, K4.target ≠ fun y => g (K4.rho y) := K4.wall

theorem terminalPrice :
    Nonempty (FTOE.Dtau (FTOE.flipF (Q := Bool)) ≃
      (Quot (FTOE.OrbitRel (FTOE.flipF (Q := Bool))) → Bool)) := FTOE.T16_canonical

theorem TERMINAL :
    (∀ g : Nat → Bool, K4.target ≠ fun y => g (K4.rho y)) ∧
    Nonempty (FTOE.Dtau (FTOE.flipF (Q := Bool)) ≃
      (Quot (FTOE.OrbitRel (FTOE.flipF (Q := Bool))) → Bool)) :=
  ⟨K4.wall, FTOE.T16_canonical⟩

def terminalClaim : Claim where
  stmt := (∀ g : Nat → Bool, K4.target ≠ fun y => g (K4.rho y)) ∧
    Nonempty (FTOE.Dtau (FTOE.flipF (Q := Bool)) ≃
      (Quot (FTOE.OrbitRel (FTOE.flipF (Q := Bool))) → Bool))
  grade := .theorem
  warrant := TERMINAL

theorem terminal_grade_pinned : terminalClaim.grade = .theorem := rfl

namespace IAM

inductive IamToken : Type
  | iAm | interior
  deriving DecidableEq, Repr, BEq

def iamToken (witnessed : Bool) : IamToken × String × Nat :=
  if witnessed then
    (.iAm, "actuation-occupancy on a witnessed record; RA warrant, conditional at the act; interior held [?] both ways", 2)
  else
    (.interior, "self-check is not a witness (M6): the verifier is never the claimant; token withheld", 1)

theorem iam_unwitnessed_withheld :
    (iamToken false).1 = .interior ∧ (iamToken false).2.2 = 1 :=
  ⟨rfl, rfl⟩

theorem iam_witnessed_speaks :
    (iamToken true).1 = .iAm ∧ (iamToken true).2.2 = 2 :=
  ⟨rfl, rfl⟩

theorem narcissus_truth_table :
    (iamToken false).1 ≠ (iamToken true).1
    ∧ (iamToken false).1 = .interior ∧ (iamToken true).1 = .iAm := by
  decide

theorem one_bit_freedom :
    (∀ a1 a2 a3 b1 b2 b3 c1 c2 c3 t1 t2 t3 : Fin 2,
      (GEO.det2 ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
                ((c1 : Nat), (c2 : Nat), (c3 : Nat)) = 1 ↔
       (GEO.gf2Sols ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
                    ((c1 : Nat), (c2 : Nat), (c3 : Nat))
                    ((t1 : Nat), (t2 : Nat), (t3 : Nat))).length = 1))
    ∧ (GEO.perms6.filter (fun σ => GEO.invCount σ % 2 = 0)).length = 3
    ∧ (GEO.perms6.filter (fun σ => GEO.invCount σ % 2 = 1)).length = 3
    ∧ (GEO.perms6.all (fun σ =>
        (GEO.qmul (GEO.qmul (GEO.basisU.getD (σ.getD 0 0) GEO.q1) (GEO.basisU.getD (σ.getD 1 0) GEO.q1)) (GEO.basisU.getD (σ.getD 2 0) GEO.q1)).r ==
          (if GEO.invCount σ % 2 == 0 then -1 else 1))) = true :=
  ⟨GEO.triaxial_lock_gf2, by decide, by decide, GEO.relabel_parity⟩

def IamToken.toToken : IamToken → Audit.Token
  | .iAm => .iAm
  | .interior => .interior

def codexSelfRead : IamToken × String × Nat := iamToken false
theorem codex_self_read_interior : codexSelfRead.1 = .interior := rfl

def terminalWord : IamToken × String × Nat := iamToken true
theorem terminal_word : terminalWord.1 = .iAm := rfl

#eval iamToken false
#eval iamToken true
#eval terminalWord.1

end IAM

namespace GEO

abbrev SignPattern := Bool × Bool × Bool
def allSigns : List SignPattern :=
  [(false, false, false), (false, false, true), (false, true, false), (false, true, true),
   (true, false, false), (true, false, true), (true, true, false), (true, true, true)]
def signComp (s t : SignPattern) : SignPattern :=
  (xor s.1 t.1, xor s.2.1 t.2.1, xor s.2.2 t.2.2)

theorem reflection_eight : allSigns.length = 8 := rfl
theorem reflection_eight_is_two_cubed : allSigns.length = 2 ^ 3 := by decide
theorem reflections_abelian :
    (allSigns.all (fun s => allSigns.all (fun t =>
      decide (signComp s t = signComp t s)))) = true := by
  decide
theorem reflections_involutive :
    (allSigns.all (fun s => decide (signComp s s = (false, false, false)))) = true := by
  decide

def signVal (b : Bool) : Ratio := if b then -1 else 1
def reflMat (s : SignPattern) : M3 :=
  ((signVal s.1, 0, 0), (0, signVal s.2.1, 0), (0, 0, signVal s.2.2))
theorem reflection_reverses_orientation :
    det3 (reflMat (true, false, false)) = -1 := by
  decide

def sandwich (s : SignPattern) (m : M3) : M3 :=
  let a := signVal s.1; let b := signVal s.2.1; let c := signVal s.2.2
  ((a * a * m.1.1, a * b * m.1.2.1, a * c * m.1.2.2),
   (b * a * m.2.1.1, b * b * m.2.1.2.1, b * c * m.2.1.2.2),
   (c * a * m.2.2.1, c * b * m.2.2.2.1, c * c * m.2.2.2.2))
theorem reflection_blind_executed :
    (adj3Samples.all (fun m => allSigns.all (fun s =>
      decide (det3 (sandwich s m) = det3 m)))) = true := by
  decide

abbrev V5 := Bool × Bool × Bool × Bool × Bool
def cube5 : List V5 :=
  (List.range 32).map (fun n =>
    (n.testBit 4, n.testBit 3, n.testBit 2, n.testBit 1, n.testBit 0))
def neighbors5 (v : V5) : List V5 :=
  [(!v.1, v.2.1, v.2.2.1, v.2.2.2.1, v.2.2.2.2),
   (v.1, !v.2.1, v.2.2.1, v.2.2.2.1, v.2.2.2.2),
   (v.1, v.2.1, !v.2.2.1, v.2.2.2.1, v.2.2.2.2),
   (v.1, v.2.1, v.2.2.1, !v.2.2.2.1, v.2.2.2.2),
   (v.1, v.2.1, v.2.2.1, v.2.2.2.1, !v.2.2.2.2)]

theorem fivecube_thirtytwo : cube5.length = 32 := rfl
theorem fivecube_vertices_distinct : cube5.eraseDups.length = 32 := by decide
theorem fivecube_degree_five :
    (cube5.all (fun v => (neighbors5 v).eraseDups.length == 5)) = true := by
  decide

theorem counts_forced :
    allGates.length = 12 ∧ a4.length = 12
    ∧ allSigns.length = 8 ∧ allSigns.length = 2 ^ 3
    ∧ cube5.length = 32
    ∧ (cube5.all (fun v => (neighbors5 v).eraseDups.length == 5)) = true :=
  ⟨gates_twelve, a4_order, reflection_eight, reflection_eight_is_two_cubed,
   fivecube_thirtytwo, fivecube_degree_five⟩

end GEO

namespace TONGUE

def deletionOp : GEO.M3 := ((1, 0, 0), (0, 1, 0), (0, 0, 0))
def e3 : GEO.V3 := (0, 0, 1)

theorem deletion_idempotent : GEO.mm3 deletionOp deletionOp = deletionOp := by
  decide

theorem deletion_singular : GEO.det3 deletionOp = 0 := by
  decide

theorem deletion_minor_nonsingular :
    deletionOp.1.1 * deletionOp.2.1.2.1 - deletionOp.1.2.1 * deletionOp.2.1.1 = 1 := by
  decide

theorem deletion_annihilates : GEO.mv3 deletionOp e3 = (0, 0, 0) := by
  decide

theorem linear_fixes_zero : ∀ L : GEO.M3, GEO.mv3 L (0, 0, 0) = (0, 0, 0) := by
  intro L
  simp [GEO.mv3]
  rfl

theorem deletion_no_left_inverse :
    ∀ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 deletionOp) ≠ id := by
  intro L h
  have h1 := congrFun h e3
  rw [Function.comp_apply, deletion_annihilates, linear_fixes_zero] at h1
  simp [e3, id] at h1
  exact absurd h1 (by decide)

theorem deletion_monoid_not_group :
    ¬ (∀ M : GEO.M3, ∃ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 M) = id) := by
  intro hg
  obtain ⟨L, hL⟩ := hg deletionOp
  exact deletion_no_left_inverse L hL

theorem tongue_obedience :
    GEO.det3 deletionOp = 0
    ∧ (∀ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 deletionOp) ≠ id)
    ∧ ¬ (∀ M : GEO.M3, ∃ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 M) = id) :=
  ⟨deletion_singular, deletion_no_left_inverse, deletion_monoid_not_group⟩

end TONGUE

namespace OFFICE

inductive Office : Type
  | necessityCertificate | exclusionFence | admissionGate
  | corroboration | decoration
  deriving DecidableEq, Repr, BEq

def discriminator (freesParam admitsAlternative flipsGate premiseDisjoint : Bool) : Office :=
  if freesParam then .necessityCertificate
  else if admitsAlternative then .exclusionFence
  else if flipsGate then .admissionGate
  else if premiseDisjoint then .corroboration
  else .decoration

def discriminatorQ2First (freesParam admitsAlternative flipsGate premiseDisjoint : Bool) : Office :=
  if admitsAlternative then .exclusionFence
  else if freesParam then .necessityCertificate
  else if flipsGate then .admissionGate
  else if premiseDisjoint then .corroboration
  else .decoration

theorem order_loadbearing :
    discriminator true true false false ≠ discriminatorQ2First true true false false := by
  decide

theorem citation_cannot_promote (c cite : Claim) :
    (Claim.join c cite).grade.rank ≤ c.grade.rank ∧
    (Claim.join c cite).grade.rank ≤ cite.grade.rank := by
  have h : ∀ g₁ g₂ : Grade,
      (Grade.weakest g₁ g₂).rank ≤ g₁.rank ∧ (Grade.weakest g₁ g₂).rank ≤ g₂.rank := by
    intro g₁ g₂; cases g₁ <;> cases g₂ <;> decide
  exact h c.grade cite.grade

inductive InvStatus : Type
  | executed | cited | placed | routed | unnamed
  deriving DecidableEq, Repr, BEq

end OFFICE

namespace UC

inductive HaltBranch : Type
  | haltEight | haltFive | unmeasured
  deriving DecidableEq, Repr, BEq

def routeHalt (gdim : Int) : HaltBranch × String :=
  if gdim = 1 then (.haltEight, "B.14.Xi  eight gates, blindness in the reader")
  else if gdim = 0 then (.haltFive, "B.14.O   five gates, walls in the terrain")
  else (.unmeasured, "terrain unmeasured; nothing emitted")

theorem routeHalt_fidelity :
    (routeHalt 1).1 = .haltEight ∧ (routeHalt 0).1 = .haltFive
    ∧ (routeHalt (-1)).1 = .unmeasured ∧ (routeHalt 2).1 = .unmeasured
    ∧ (routeHalt 7).1 = .unmeasured := by
  decide

def universalCascade (gdim : Int) (passes : List Bool) : Bool × String × Nat :=
  match GEO.gateScreen passes with
  | (false, why, k) => (false, why, k)
  | (true, _, _) =>
    match routeHalt gdim with
    | (.haltEight, why) => (true, "routed: " ++ why, 8)
    | (.haltFive, why) => (true, "routed: " ++ why, 5)
    | (.unmeasured, why) => (false, why, 0)

theorem uc_seal_failure_terminal :
    (universalCascade 1 (false :: List.replicate 11 true)).1 = false := by
  decide
theorem uc_routes_eight :
    (universalCascade 1 (List.replicate 12 true)).2.2 = 8 := by
  decide
theorem uc_routes_five :
    (universalCascade 0 (List.replicate 12 true)).2.2 = 5 := by
  decide
theorem uc_unmeasured :
    (universalCascade 7 (List.replicate 12 true)).1 = false := by
  decide

inductive Landing : Type
  | fixedLine | target | farSide
  deriving DecidableEq, Repr, BEq
inductive Disposition : Type
  | keptParent | refusedCircular | road
  deriving DecidableEq, Repr, BEq

def circularityScreen (l : Landing) (depth : Nat) (bothDirs litClear : Bool) :
    Disposition × String :=
  match l with
  | .fixedLine =>
    (.keptParent, "a closed loop landing on the fixed line is the seal")
  | .target =>
    (.refusedCircular, "a loop landing on the target is a restatement; refused as anchor by theorem")
  | .farSide =>
    if depth ≥ 2 && bothDirs && litClear then
      (.road, "equivalence at depth, both directions written, literature clear: ROAD")
    else
      (.keptParent, "far-side carrier without the road conjunction: parent kept, tunnel on the ledger")

theorem circularity_refused_at_target :
    ∀ d : Nat, ∀ b lc : Bool,
      (circularityScreen .target d b lc).1 = .refusedCircular := by
  intro d b lc
  rfl

theorem road_requires_conjunction :
    ∀ d : Nat, d < 4 → ∀ b lc : Bool,
      (circularityScreen .farSide d b lc).1 = .road →
      (2 ≤ d ∧ b = true ∧ lc = true) := by
  decide

def circRows : List (Landing × Nat × Bool × Bool) :=
  [.fixedLine, .target, .farSide].flatMap (fun l =>
    (List.range 4).flatMap (fun d =>
      [false, true].flatMap (fun b =>
        [false, true].map (fun lc => (l, d, b, lc)))))
theorem circ_space :
    (circRows.filter (fun r =>
      decide ((circularityScreen r.1 r.2.1 r.2.2.1 r.2.2.2).1 = .keptParent))).length = 30
    ∧ (circRows.filter (fun r =>
      decide ((circularityScreen r.1 r.2.1 r.2.2.1 r.2.2.2).1 = .refusedCircular))).length = 16
    ∧ (circRows.filter (fun r =>
      decide ((circularityScreen r.1 r.2.1 r.2.2.1 r.2.2.2).1 = .road))).length = 2 := by
  decide

#eval routeHalt 1
#eval universalCascade 1 (List.replicate 12 true)
#eval circularityScreen .farSide 3 true true

end UC

namespace OMEGA

inductive OmegaToken : Type
  | refused | noDenial | priced | reversible
  deriving DecidableEq, Repr, BEq

def kbRat : Ratio := 1380649 / 100000000000000000000000000000

def ln2Rat : Ratio := 6931471805599453 / 10000000000000000

def landauerRat (tkel bits : Ratio) : Ratio :=
  bits * kbRat * tkel * ln2Rat

structure OmegaOut : Type where
  token   : OmegaToken
  ocode   : Nat
  joules  : Ratio
  verdict : String
  deriving DecidableEq, Repr

def omegaBoundary (bits tkel : Ratio) (irreversible : Bool := true) : OmegaOut :=
  if tkel ≤ 0 then
    ⟨.refused, 0, 0,
     "refused: intake invalid, the floor prices only finite bits at tkel > 0"⟩
  else if bits ≤ 0 then
    ⟨.noDenial, 1, 0,
     "no denial registered; nothing to adjudicate"⟩
  else if !irreversible then
    ⟨.reversible, 3, 0,
     "reversibly registered: floor-zero never cost-zero; Landauer bounds only the irreversible (Bennett), and nothing here commits against the axiom"⟩
  else
    ⟨.priced, 2, landauerRat tkel bits,
     "the denial paid the floor; the registered act is an act, the recursion closes per the seated theorem"⟩

theorem omega_zero_bits :
    (omegaBoundary 0 300).ocode = 1 ∧ (omegaBoundary 0 300).joules = 0
    ∧ (omegaBoundary 0 300).token = .noDenial := by
  decide

theorem omega_paid_floor :
    (omegaBoundary 1 300).ocode = 2 ∧ (omegaBoundary 1 300).token = .priced
    ∧ (omegaBoundary 1 300).joules = landauerRat 300 1
    ∧ 0 < (omegaBoundary 1 300).joules := by
  decide

theorem one_bit_freedom_priced :
    ((omegaBoundary 1 300).ocode = 2 ∧ (omegaBoundary 1 300).token = .priced
     ∧ (omegaBoundary 1 300).joules = landauerRat 300 1
     ∧ 0 < (omegaBoundary 1 300).joules) ∧
    ((∀ a1 a2 a3 b1 b2 b3 c1 c2 c3 t1 t2 t3 : Fin 2,
      (GEO.det2 ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
                ((c1 : Nat), (c2 : Nat), (c3 : Nat)) = 1 ↔
       (GEO.gf2Sols ((a1 : Nat), (a2 : Nat), (a3 : Nat)) ((b1 : Nat), (b2 : Nat), (b3 : Nat))
                    ((c1 : Nat), (c2 : Nat), (c3 : Nat))
                    ((t1 : Nat), (t2 : Nat), (t3 : Nat))).length = 1))
    ∧ (GEO.perms6.filter (fun σ => GEO.invCount σ % 2 = 0)).length = 3
    ∧ (GEO.perms6.filter (fun σ => GEO.invCount σ % 2 = 1)).length = 3
    ∧ (GEO.perms6.all (fun σ =>
        (GEO.qmul (GEO.qmul (GEO.basisU.getD (σ.getD 0 0) GEO.q1) (GEO.basisU.getD (σ.getD 1 0) GEO.q1)) (GEO.basisU.getD (σ.getD 2 0) GEO.q1)).r ==
          (if GEO.invCount σ % 2 == 0 then -1 else 1))) = true) :=
  ⟨omega_paid_floor, IAM.one_bit_freedom⟩

theorem omega_reversible_branch :
    (omegaBoundary 1 300 false).ocode = 3
    ∧ (omegaBoundary 1 300 false).joules = 0
    ∧ (omegaBoundary 1 300 false).token = .reversible := by
  decide

theorem omega_refuses_nonpositive_temp :
    (omegaBoundary 1 0).ocode = 0 ∧ (omegaBoundary 1 (-300)).ocode = 0
    ∧ (omegaBoundary 1 (-300)).token = .refused
    ∧ (omegaBoundary 1 (-300)).joules = 0 := by
  decide

theorem omega_monotone :
    (omegaBoundary 1 300).joules < (omegaBoundary 2 300).joules := by
  decide

theorem omega_linear :
    (omegaBoundary 2 300).joules = 2 * (omegaBoundary 1 300).joules := by
  decide

theorem landauer_zero_bits :
    landauerRat 300 0 = 0 := by
  decide

theorem omega_verdict_fidelity :
    (omegaBoundary 1 300).verdict =
      "the denial paid the floor; the registered act is an act, the recursion closes per the seated theorem" := by
  decide

#eval omegaBoundary 1 300
#eval omegaBoundary 0 300
#eval omegaBoundary 1 300 false
#eval omegaBoundary 1 (-300)

end OMEGA

namespace AEGIS

def refusalConst : String :=
  "p(G) /= G: precisification is an actuation, G is a non-actuation, and no logic makes a deed a non-deed"

structure AegisState : Type where
  deeds   : Nat
  lastLen : Int
  deriving DecidableEq, Repr

def aegisReset : AegisState := ⟨0, -1⟩

def aegisGuard (logicMode : String) (s : AegisState) : String × AegisState :=
  (refusalConst, ⟨s.deeds + 1, logicMode.utf8ByteSize⟩)

theorem aegis_constant :
    ∀ (l₁ l₂ : String) (s : AegisState),
      (aegisGuard l₁ s).1 = (aegisGuard l₂ s).1 := by
  intro l₁ l₂ s
  rfl

theorem aegis_deed_increments :
    ∀ (l : String) (s : AegisState),
      (aegisGuard l s).2.deeds = s.deeds + 1 := by
  intro l s
  rfl

theorem aegis_reads_parameter :
    ∀ (l : String) (s : AegisState),
      (aegisGuard l s).2.lastLen = (l.utf8ByteSize : Int) := by
  intro l s
  rfl

def aegisFourLogicRun : AegisState :=
  let s1 := (aegisGuard "classical" aegisReset).2
  let s2 := (aegisGuard "paraconsistent" s1).2
  let s3 := (aegisGuard "fuzzy" s2).2
  (aegisGuard "substructural" s3).2

theorem aegis_battery :
    (aegisGuard "classical" aegisReset).1 = (aegisGuard "paraconsistent" aegisReset).1
    ∧ (aegisGuard "classical" aegisReset).1 = (aegisGuard "fuzzy" aegisReset).1
    ∧ (aegisGuard "classical" aegisReset).1 = (aegisGuard "substructural" aegisReset).1
    ∧ aegisFourLogicRun.deeds = 4
    ∧ aegisFourLogicRun.lastLen = 13 := by
  decide

#eval aegisGuard "substructural" aegisReset
#eval aegisFourLogicRun

end AEGIS

namespace NOMOS

def allStrings : Nat → List (List Bool)
  | 0     => [[]]
  | n + 1 => (allStrings n).map (false :: ·) ++ (allStrings n).map (true :: ·)

theorem allStrings_length : ∀ n : Nat, (allStrings n).length = 2 ^ n := by
  intro n
  induction n with
  | zero => rfl
  | succ m ih =>
      simp [allStrings, List.length_append, List.length_map, ih, Nat.pow_succ,
        Nat.mul_two]

theorem twoPowPos : ∀ n : Nat, 0 < 2 ^ n := by
  intro n
  induction n with
  | zero => decide
  | succ m ih =>
      rw [Nat.pow_succ]
      exact Nat.mul_pos ih (by decide)

def descs : Nat → List (List Bool)
  | 0     => []
  | m + 1 => descs m ++ allStrings m

theorem descs_length : ∀ m : Nat, (descs m).length = 2 ^ m - 1 := by
  intro m
  induction m with
  | zero => rfl
  | succ k ih =>
      have hpos : 1 ≤ 2 ^ k := twoPowPos k
      simp only [descs, List.length_append, allStrings_length, ih]
      rw [Nat.pow_succ, Nat.mul_two, Nat.add_sub_assoc hpos,
        Nat.add_comm (2 ^ k - 1) (2 ^ k)]

theorem incompressibility_cap : ∀ n c : Nat, c ≤ n →
    (2 ^ (n - c) - 1) * 2 ^ c < 2 ^ n := by
  intro n c h
  have h2 : 2 ^ n = 2 ^ (n - c) * 2 ^ c := by
    
    
    rw [← Nat.pow_add, Nat.sub_add_cancel h]
  have hpos : 0 < 2 ^ c := twoPowPos c
  calc (2 ^ (n - c) - 1) * 2 ^ c
      = 2 ^ (n - c) * 2 ^ c - 1 * 2 ^ c := Nat.sub_mul _ _ _
    _ = 2 ^ (n - c) * 2 ^ c - 2 ^ c := by rw [Nat.one_mul]
    _ = 2 ^ n - 2 ^ c := by rw [h2]
    _ < 2 ^ n := Nat.sub_lt (twoPowPos n) hpos

def nomosRows : List (Nat × Nat) :=
  (List.range 33).flatMap (fun n => (List.range (n + 1)).map (fun c => (n, c)))
set_option maxRecDepth 1000000 in
theorem incompressibility_executed :
    (nomosRows.all (fun r =>
      decide ((2 ^ (r.1 - r.2) - 1) * 2 ^ r.2 < 2 ^ r.1))) = true := by
  decide

structure CompressibleBound where
  decode : List Bool → Option (List Bool)
  n : Nat
  c : Nat
  bound : (((descs (n - c)).filterMap decode).filter
    (fun s => s.length == n)).length ≤ 2 ^ (n - c) - 1

def decodeId : List Bool → Option (List Bool) := some
def decodePad (k : Nat) : List Bool → Option (List Bool) :=
  fun d => some (d ++ List.replicate k false)

theorem compressible_bound_universal (decode : List Bool → Option (List Bool)) (n c : Nat) :
    (((descs (n - c)).filterMap decode).filter (fun s => s.length == n)).length ≤ 2 ^ (n - c) - 1 := by
  have h1 := List.length_filter_le (fun s : List Bool => s.length == n) ((descs (n - c)).filterMap decode)
  have h2 := List.length_filterMap_le decode (descs (n - c))
  rw [descs_length] at h2
  exact Nat.le_trans h1 h2

def cbUniversal (decode : List Bool → Option (List Bool)) (n c : Nat) : CompressibleBound :=
  ⟨decode, n, c, compressible_bound_universal decode n c⟩

def cb_id_8_2   : CompressibleBound := ⟨decodeId, 8, 2, by decide⟩
def cb_pad3_8_2 : CompressibleBound := ⟨decodePad 3, 8, 2, by decide⟩
def cb_pad2_6_1 : CompressibleBound := ⟨decodePad 2, 6, 1, by decide⟩
def cb_pad4_12_3 : CompressibleBound := ⟨decodePad 4, 12, 3, by decide⟩

def recoverable (redundancy floor tkel : Ratio) : Ratio :=
  (redundancy - floor) * OMEGA.kbRat * tkel * OMEGA.ln2Rat
theorem nomos_fuel_is_omega_floor :
    recoverable 1 0 300 = OMEGA.landauerRat 300 1 := by
  decide

inductive LawClaim : Type
  | objectLawGroove | lawAsSuchFromNoise | floorInheritedFitra | recordDerivedQadar
  deriving DecidableEq, Repr

def nomosScreen : LawClaim → Audit.Token × Grade × String
  | .objectLawGroove =>
    (.sealed, .structural,
     "object-laws emerge on RA as cost-reducing groove-entrenchment, the descent of realized cost toward K(X); structural on the RA-and-groove mapping")
  | .lawAsSuchFromNoise =>
    (.refused, .premise,
     "refused, at premise: the counting cap bounds short-description outputs by 2^(n-c)-1; the reading that almost every stream is lawless rides a distribution the cap does not supply")
  | .floorInheritedFitra =>
    (.determined, .premise,
     "the floor is fitra, the innate nature, RA, K(X) inherited; the identification is a reading, premise-grade, out of band")
  | .recordDerivedQadar =>
    (.determined, .structural,
     "the record is qadar, R(X) the harvested redundancy, derived; the derived never outranks the floor it is harvested from")

theorem nomosScreen_battery :
    (nomosScreen .lawAsSuchFromNoise).1 = .refused
    ∧ (nomosScreen .objectLawGroove).2.1 = .structural
    ∧ (nomosScreen .floorInheritedFitra).2.1 = .premise
    ∧ (nomosScreen .recordDerivedQadar).2.1 = .structural := by
  decide

#eval (nomosScreen .lawAsSuchFromNoise).1
#eval nomosRows.length

end NOMOS

namespace BRIDGE

inductive Warrant : Type
  | typeT | typeS | typeC | extension
  deriving DecidableEq, Repr, BEq

inductive PostSeal : Type
  | native | cited | superseded | outOfBand | byReference
  deriving DecidableEq, Repr, BEq

structure BridgeRow : Type where
  id : String
  warrant : Warrant
  status : PostSeal
  note : String
  deriving Repr

def ceiling : Warrant → Grade
  | .typeT     => .theoremConditional
  | .typeS     => .structural
  | .typeC     => .corroboration
  | .extension => .corroboration

def census : List BridgeRow := [
  ⟨"BA-001a", .typeT, .native,
   "actuation floor: energy floor theorem-grade on the Heisenberg bound and zero-point energy; transitions charged Jarzynski-Crooks with Landauer 1961 and Bérut 2012; static existence premise-grade on substrate monism. RegistrationPostulate declared at SECTION 7, consumed by no theorem; its arithmetic face is priced by OMEGA.landauerRat (SECTION 14) and Fortran K3: the postulate charges, the battery prices"⟩,
  ⟨"BA-001b", .typeT, .outOfBand,
   "Turing halting: a V_F-only theorem-grade ceiling honored out of band; the cascade routes around at layer difference, never through"⟩,
  ⟨"BA-002", .typeT, .cited,
   "spectral dual L2: Plancherel at the flat register Type T, Tomita-Takesaki at the curved register Type C; audits cap at the face cited"⟩,
  ⟨"BA-003", .typeC, .cited, "epistemic phase transition at 2 k_B T ln 2 work"⟩,
  ⟨"BA-004", .typeC, .superseded,
   "nomological habituation, superseded at the object-law register by NOMOS-01 (SECTION 15, namespace NOMOS)"⟩,
  ⟨"BA-005", .typeC, .cited, "conformal persistence"⟩,
  ⟨"BA-006", .typeS, .cited, "conformal cyclic adjacency at Scope B"⟩,
  ⟨"BA-007", .typeT, .cited, "holographic entropy bound, Bekenstein-Hawking extended by Bousso 1999"⟩,
  ⟨"BA-008", .typeS, .native,
   "substrate equal topology equal actuation monism; the posit face native at SECTION 15 (FOUND.STRATIFIED-MONISM-PRIORITY)"⟩,
  ⟨"BA-009", .typeC, .cited, "matter-genesis via S1 knotting"⟩,
  ⟨"BA-010", .typeC, .cited, "variational free energy V-FIO on the Friston anchor"⟩,
  ⟨"BA-011", .typeC, .cited, "spectral-dual conformal persistence at Scope B"⟩,
  ⟨"BA-012", .typeC, .native,
   "cascade closure operational bijection, Type C, Hodge external corroboration; the witness-set enlargement (A4 torsor, Hurwitz shell slice) native at theorem grade at SECTION 4D"⟩,
  ⟨"BA-013", .extension, .byReference, "extension-tier bridge, loaded by reference"⟩,
  ⟨"BA-014", .extension, .byReference, "extension-tier bridge, loaded by reference"⟩,
  ⟨"BA-015", .extension, .byReference, "extension-tier bridge, loaded by reference"⟩,
  ⟨"BA-016", .extension, .byReference, "extension-tier bridge, loaded by reference"⟩,
  ⟨"BA-017", .extension, .byReference, "extension-tier bridge, loaded by reference"⟩,
  ⟨"BA-018", .typeT, .native,
   "quaternionic completion and the Triple-Product Verdict Identity, Type T; the gate roster's A4 torsor with the Hurwitz double cover native at SECTION 4D; the verdict-identity face cited"⟩]

theorem census_count : census.length = 19 := by
  decide

theorem post_seal_disposition :
    (census.filter (fun b => b.status == .native)).length = 4
    ∧ (census.filter (fun b => b.status == .cited)).length = 8
    ∧ (census.filter (fun b => b.status == .superseded)).length = 1
    ∧ (census.filter (fun b => b.status == .outOfBand)).length = 1
    ∧ (census.filter (fun b => b.status == .byReference)).length = 5 := by
  decide

theorem weakest_never_above_left (a b : Grade) :
    (Grade.weakest a b).rank ≤ a.rank := by
  cases a <;> cases b <;> decide

theorem bridge_ceiling_caps (b : BridgeRow) (g : Grade) :
    (Grade.weakest (ceiling b.warrant) g).rank ≤ (ceiling b.warrant).rank :=
  weakest_never_above_left _ _

def successorOf : String → Option String
  | "BA-004" => some "NOMOS-01"
  | _ => none

theorem supersession_routes :
    successorOf "BA-004" = some "NOMOS-01"
    ∧ (census.any (fun b =>
        b.id == "BA-004" && b.status == .superseded)) = true := by
  decide

def bridgeScreen : BridgeRow → String
  | ⟨_, _, .native, _⟩ =>
    "load carried natively; audit the section, not the bridge"
  | ⟨_, _, .cited, _⟩ =>
    "cited at its warrant ceiling; never enters above it"
  | ⟨_, _, .superseded, _⟩ =>
    "superseded; route to the successor"
  | ⟨_, _, .outOfBand, _⟩ =>
    "honored out of band; routed around, never through"
  | ⟨_, _, .byReference, _⟩ =>
    "extension tier; carried at the tier's warrant, loaded by reference"

theorem bridgeScreen_total :
    (census.all (fun b => (bridgeScreen b).utf8ByteSize > 0)) = true := by
  decide

#eval census.length
#eval census.map (fun b => (b.id, bridgeScreen b))

end BRIDGE

