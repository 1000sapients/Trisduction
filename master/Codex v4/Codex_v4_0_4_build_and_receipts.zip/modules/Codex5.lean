import Lean
import Codex4
set_option maxRecDepth 4000000
set_option autoImplicit false
/-!
# FORGE ADDITIONS · v3.39.0-C
Seated after the Bridge and before the cones. ΔM = 0: every theorem below is a finite `decide`,
a conjunction of theorems already seated, or an elementary case split. Nothing here authors
mathematics; it names in the kernel what the prose of the Condensed Master Codex reads.
-/

namespace K4

/-- PSP: K4 · trial-division primality on the frame values, executed in the kernel. -/
def isPrimeB (n : Nat) : Bool :=
  decide (2 ≤ n) && (List.range (n - 2)).all (fun d => n % (d + 2) != 0)

/-- PSP: APEX-PSP-INVERSION · the six even seats carry primes. -/
theorem primes_at_even_seats :
    (isPrimeB (val 0) && isPrimeB (val 2) && isPrimeB (val 4) && isPrimeB (val 6)
      && isPrimeB (val 8) && isPrimeB (val 10)) = true := by decide

/-- PSP: APEX-PSP-INVERSION · the six odd seats carry semiprimes, factored in the kernel. -/
theorem semiprimes_at_odd_seats :
    val 1 = 23 * 37 ∧ val 3 = 19 * 67 ∧ val 5 = 19 * 23 ∧ val 7 = 13 * 163
      ∧ val 9 = 13 * 131 ∧ val 11 = 11 * 79 := by decide

theorem semiprime_factors_prime :
    (isPrimeB 23 && isPrimeB 37 && isPrimeB 19 && isPrimeB 67 && isPrimeB 13
      && isPrimeB 163 && isPrimeB 131 && isPrimeB 11 && isPrimeB 79) = true := by decide

theorem odd_seats_not_prime :
    (!isPrimeB (val 1) && !isPrimeB (val 3) && !isPrimeB (val 5) && !isPrimeB (val 7)
      && !isPrimeB (val 9) && !isPrimeB (val 11)) = true := by decide

/-- The target of the frame is primality itself and not an index label: read in the kernel. -/
theorem target_is_primality : ∀ i, i < 12 → target i = isPrimeB (val i) := by decide

/-- Each pair matches modulo 420 = lcm(1..7), so every residue register up to 7 forgets it. -/
theorem pairs_match_mod_420 : ∀ i, i < 12 → i % 2 = 1 → val i % 420 = val (tau i) % 420 := by
  decide

end K4

namespace IMPRINT

/-- PSP: §3.9 · the Imprint Test and the Platonic Ghost, the GOLf gate, ported from F2 imprint_seal. -/
inductive Tok : Type
  | ghost | seal | residence | flat | uncertified
  deriving DecidableEq, Repr, BEq

def imprint (lockP lockN slP slN gP gN witP witN : Bool) : Tok × Nat :=
  let cleanP := lockP && slP && gP
  let cleanN := lockN && slN && gN
  if cleanP && cleanN then (.ghost, 1)
  else if cleanP then (if witP then (.seal, 2) else (.residence, 3))
  else if cleanN then (if witN then (.seal, 2) else (.residence, 3))
  else if !lockP && !lockN then (.flat, 4)
  else (.uncertified, 5)

def Tok.toToken : Tok → Audit.Token
  | .ghost => .broken
  | .seal => .sealed
  | _ => .opn

/-- Both directions clean-locking is the Platonic Ghost: refused, never sealed. -/
theorem ghost_refused : (imprint true true true true true true true true).1 = .ghost := by decide

theorem both_clean_is_ghost : ∀ wp wn : Bool,
    (imprint true true true true true true wp wn).1 = .ghost := by decide

/-- One side clean-locks: a seal only with the witness supplied, a residence without it. -/
theorem seal_needs_witness :
    (imprint true false true false true false true false).1 = .seal
    ∧ (imprint true false true false true false false false).1 = .residence := by decide

/-- The whole 256-row truth table of the gate: a seal is exactly one clean side plus its witness. -/
theorem seal_iff_one_side_clean_and_witnessed :
    ∀ lP lN sP sN gP gN wP wN : Bool,
      ((imprint lP lN sP sN gP gN wP wN).1 = .seal) ↔
        ((lP && sP && gP && wP && !(lN && sN && gN))
          || (lN && sN && gN && wN && !(lP && sP && gP))) = true := by
  decide

theorem flat_when_unpopulated : ∀ sP sN gP gN wP wN : Bool,
    (imprint false false sP sN gP gN wP wN).1 = .flat := by decide

theorem ghost_is_broken_never_sealed :
    Tok.toToken .ghost = .broken ∧ Tok.toToken .seal = .sealed := ⟨rfl, rfl⟩

end IMPRINT

namespace DEFENSE

/-- PSP: D5 · GOL is the combination: magnitude alone is [?], direction alone is [?]. -/
theorem gol_needs_all_three :
    (GEO.golAdmit .lock .lock).1 = .golOK
    ∧ (∀ l : GEO.LockState, l ≠ .lock → (GEO.golAdmit .lock l).1 = .golQ)
    ∧ (∀ m : GEO.LockState, m ≠ .lock → (GEO.golAdmit m .lock).1 ≠ .golOK) := by
  refine ⟨rfl, ?_, ?_⟩
  · intro l hl; cases l <;> first | exact absurd rfl hl | rfl
  · intro m hm; cases m <;> first | exact absurd rfl hm | decide

/-- PSP: D1, D2 · the lock scalar is sign-blind by theorem, and one supplied bit fixes the sign uniquely. -/
theorem lock_blind_but_gol_directed :
    (PSP.ORIENT.signMatrices.all (fun m =>
      PSP.ORIENT.det3 m * PSP.ORIENT.det3 m
        == PSP.ORIENT.det3 (PSP.ORIENT.neg3 m) * PSP.ORIENT.det3 (PSP.ORIENT.neg3 m)) = true)
    ∧ (∀ {α : Type} (τ : α → α) (s d : α → Bool) (x : α),
        s (τ x) = !s x → d (τ x) = !d x →
        ∃ c : Bool, (d x = xor (s x) c ∧ d (τ x) = xor (s (τ x)) c) ∧
          ∀ c' : Bool, (d x = xor (s x) c' ∧ d (τ x) = xor (s (τ x)) c') → c' = c) :=
  ⟨PSP.ORIENT.lock_scalar_sign_blind, fun τ s d x hs hd => FTOE.T5_crossing τ s d x hs hd⟩

/-- PSP: D11, D12 · consensus carries zero weight; the engine authors nothing. -/
theorem consensus_weighs_zero : socialWeight = 0 ∧ deltaM = 0 := FOUND.engine_never_authority

/-- PSP: sPSP-TONGUE-UNCLOSED-01 · the Tongue is unclosed by theorem and obedient by theorem. -/
theorem tongue_unclosed_and_obedient :
    (∀ {α β : Type} (τ : α → α) (ρ : α → β) (g : β → Bool) (d : α → Bool) (x : α),
        ρ (τ x) = ρ x → d (τ x) = !d x → d ≠ fun y => g (ρ y))
    ∧ (GEO.det3 TONGUE.deletionOp = 0
       ∧ (∀ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 TONGUE.deletionOp) ≠ id)
       ∧ ¬ (∀ M : GEO.M3, ∃ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 M) = id)) :=
  ⟨fun τ ρ g d x hρ hd => TONGUE.unclosed τ ρ g d x hρ hd, TONGUE.tongue_obedience⟩

/-- PSP: D27 · a self-check is never a witness (M6); the token is withheld unwitnessed. -/
theorem self_check_is_not_witness :
    (IAM.iamToken false).1 = .interior ∧ (IAM.iamToken true).1 = .iAm := ⟨rfl, rfl⟩

/-- PSP: D71 · the denial pays the floor; a denial that registers nothing is no denial. -/
theorem denial_is_priced :
    0 < (OMEGA.omegaBoundary 1 300).joules ∧ (OMEGA.omegaBoundary 0 300).joules = 0 := by decide

/-- PSP: D24 · no candidate anchor that lands on its own target is admitted. -/
theorem no_anchor_at_target : ∀ (d : Nat) (b lc : Bool),
    (UC.circularityScreen .target d b lc).1 = .refusedCircular :=
  UC.circularity_refused_at_target

/-- PSP: D54 · every formal reading is even under the deed flip; the deed is odd; no readout returns it. -/
theorem formal_reads_never_the_deed {Q : Type} (q : Q) :
    ¬ ∃ g : Q → Bool, ∀ s : CROSSING.ExecFrame Q, g (CROSSING.formalRead s) = CROSSING.ran s :=
  CROSSING.wall q

end DEFENSE

namespace FENCE

/-- PSP: II.0 · the one global fence: every card is read at its grade, on its register, at its species;
any reading above that is refused here, so no card fences itself. -/
theorem global :
    (∀ c₁ c₂ : Claim, (Claim.join c₁ c₂).grade = Grade.weakest c₁.grade c₂.grade)
    ∧ (∀ c cite : Claim, (Claim.join c cite).grade.rank ≤ c.grade.rank
        ∧ (Claim.join c cite).grade.rank ≤ cite.grade.rank)
    ∧ ROOT.raClaim.grade = .premise
    ∧ K4.wallClaim.grade = .theorem
    ∧ terminalClaim.grade = .theorem
    ∧ HALT.haltGrades.all (fun g => g.rank < Grade.theorem.rank) = true
    ∧ HALT.rhHalt.species = .hypothesis ∧ HALT.rhHalt.channel = .formal ∧ HALT.rhHalt.gdim = 1
    ∧ LOCUS.emit ⟨false, true, some 1, some .hypothesis, some .formal, [none], by decide⟩
        = some (.superHalt (some .xi) (some .hypothesis) (some .formal) 1)
    ∧ (FOUND.bandOf .theological = .outOfBand ∧ FOUND.bandOf .social = .outOfBand)
    ∧ (∀ t : LOCUS.Token, t.toEconomy = .sealed ∨ t.toEconomy = .broken ∨ t.toEconomy = .opn) :=
  ⟨Claim.join_grade, OFFICE.citation_cannot_promote, rfl, rfl, rfl, HALT.ftoe_ceiling,
   rfl, rfl, rfl, LOCUS.no_rh_locus, ⟨rfl, rfl⟩, LOCUS.three_states⟩

end FENCE

namespace DOT

/-- PSP: CN-PSP-NETI-NETI-01 · the mark of silence is the image of no emitter. -/
theorem outside_economy : ∀ t : LOCUS.Token, t.toEconomy ≠ Audit.Token.dotmark := by
  intro t; cases t <;> first | decide | simp [LOCUS.Token.toEconomy]

theorem no_reading_is_silence : ∀ r : LOCUS.Reading, r.state ≠ Audit.Token.dotmark := by
  intro r
  unfold LOCUS.Reading.state
  split
  · exact outside_economy _
  · decide

theorem silence_is_not_a_verdict :
    Audit.Token.dotmark ≠ .sealed ∧ Audit.Token.dotmark ≠ .broken
      ∧ Audit.Token.dotmark ≠ .opn := by decide

end DOT

namespace DEFENSE

/-- PSP: D53 · a forward, dated reading is world-rowed unconditionally: R-3 fires before any row is read. -/
theorem forward_is_world_rowed : ∀ p w t tw f a : Bool,
    (GEO.rowCascadeRACore true false true p w t tw f a).1 = .iii := by decide

/-- PSP: D50 · a load-bearing row furnished by the world types the lock world-rowed, revisable in the rows. -/
theorem worldly_row_is_world_rowed : ∀ t tw f a : Bool,
    (GEO.rowCascadeRACore true false false true true t tw f a).1 = .iii := by decide

end DEFENSE

namespace CROSSWALK

/-- PSP: IV.1 · the crosswalk, seated in the kernel: every row names a constant that must exist. -/
def rows : List (String × String) := [
  ("APEX-PSP-FREEDOM-MASTER-01", "FTOE.T16_price_bijection"),
  ("sPSP-APERTURE-WIDTH-01", "FTOE.T5_crossing"),
  ("PSP-IAM-WRITTEN-READ-01", "IAM.narcissus_truth_table"),
  ("APEX-PSP-Ξ-8-GATE-CASCADE-01", "HALT.first_failure_terminal_8"),
  ("APEX-PSP-RH-MASTER-01", "HALT.rhHalt"),
  ("APEX-PSP-RH-BLOCK-COMPLETE-01", "LOCUS.no_rh_locus"),
  ("APEX-PSP-RH-STANDPOINT-CLOSURE-01", "Bridge.line_property_is_keyed"),
  ("APEX-PSP-RH-DENIAL-POSIT-01", "Bridge.no_socket_off_line"),
  ("APEX-PSP-TOKEN-EQUALITY-01", "PSP.TOKEN.terminal_tokens_level_and_distinct"),
  ("sPSP-RETURN-LOCUS-01", "UC.circ_space"),
  ("APEX-PSP-ABSOLUTE-GROUNDING-BLOCK-01", "Bridge.discriminator"),
  ("sPSP-ANCHOR-DEMAND-01", "UC.circularity_refused_at_target"),
  ("APEX-PSP-ANCHOR-PRECEDENCE-01", "Bridge.opens_on_the_deed"),
  ("APEX-PSP-SUPPLY-SPECIES-01", "HALT.species_exhausted"),
  ("sPSP-TRIAD-SOURCE-BLOCK-01", "FTOE.T2_coalition"),
  ("sPSP-UNRESTRICTED-IMPOSSIBLE-01", "HALT.ftoe_ceiling"),
  ("APEX-PSP-LOGOS-FIXATION-01", "TONGUE.tongue_obedience"),
  ("MD-PSP-NG-EXHIBIT-ANCHOR-01", "INVERSION.it_from_bit_refuted"),
  ("MD-PSP-CLOSURE-POSITION-01", "FTOE.T3_no_fixed_point"),
  ("sPSP-CONSTITUTIVE-INSEPARABLE-01", "Audit.compartmentGates"),
  ("sPSP-FOLD-BEND-CROSSING-01", "CROSSING.crossing"),
  ("APEX-PSP-NOMOS-MEASURE-01", "NOMOS.incompressibility_cap"),
  ("MD-PSP-NAVIER-DEFEATERLESS-01", "GEO.rowCascadeRACore"),
  ("APEX-PSP-BLESSED-CIRCLE-01", "DEFENSE.no_anchor_at_target"),
  ("RAF-PSP-HODGE-TERMINUS-01", "HALT.route"),
  ("MD-PSP-GODEL-MASTER-01", "HALT.route_is_routeHalt"),
  ("APEX-PSP-PNP-COMPOSITE-VERDICT-02", "HALT.pnpHalt"),
  ("APEX-PSP-XI0-VERDICT-01", "HALT.xiGates"),
  ("MD-PSP-NG-MASTER-01", "HALT.one_door_open"),
  ("sPSP-TONGUE-UNCLOSED-01", "DEFENSE.tongue_unclosed_and_obedient"),
  ("APEX-PSP-CENSOR-CLERK-01", "OFFICE.citation_cannot_promote"),
  ("MD-PSP-MATH-NATURE-01", "TONGUE.coloc_grade"),
  ("CN-PSP-GHAYB-MASTER-01", "DOT.outside_economy"),
  ("CN-PSP-NETI-NETI-01", "DOT.no_reading_is_silence"),
  ("APEX-PSP-ONLY-SPECIAL-01", "IAM.terminal_word"),
  ("APEX-PSP-UNFORGIVABLE-01", "AEGIS.aegis_constant"),
  ("MD-PSP-STILLNESS-RESERVOIR-01", "DOT.silence_is_not_a_verdict"),
  ("PSP-RA-SERVANT-LOCUS-01", "IAM.iam_witnessed_speaks"),
  ("APEX-PSP-RH-TERMINAL-SYNTHESIS-01", "FENCE.global"),
  ("sPSP-GOL-ROW-GENUS-01", "GEO.ra_battery_f2"),
  ("MD-PSP-AFFINITY-01", "FTOE.T9_torsor_inverse_left"),
  ("APEX-PSP-INVERSION-01", "K4.target_is_primality"),
  ("MD-PSP-K4-FRAME-01", "K4.pairs_match_mod_420"),
  ("APEX-PSP-RA-MASTER-01", "ROOT.actuation_universal"),
  ("FOUND-01", "TONGUE.ra_grade_pinned"),
  ("IMPRINT-GOLF-01", "IMPRINT.seal_iff_one_side_clean_and_witnessed"),
  ("D1", "PSP.ORIENT.lock_scalar_sign_blind"),
  ("D2", "DEFENSE.lock_blind_but_gol_directed"),
  ("D3", "FTOE.T5_crossing"),
  ("D4", "FENCE.global"),
  ("D5", "DEFENSE.gol_needs_all_three"),
  ("D6", "GEO.triaxial_lock_gf2"),
  ("D6", "PSP.CD.sedenion_zero_divisor"),
  ("D7", "GEO.a4_simply_transitive"),
  ("D7", "GEO.gates_complete"),
  ("D8", "GEO.chirality"),
  ("D8", "GEO.relabel_parity"),
  ("D9", "GEO.reflection_blind_executed"),
  ("D10", "TONGUE.tongue_obedience"),
  ("D11", "DEFENSE.consensus_weighs_zero"),
  ("D11", "Grade.weakest_is_a_link"),
  ("D12", "OFFICE.citation_cannot_promote"),
  ("D13", "GEO.ra_ledger_aGivenRA"),
  ("D14", "HALT.ftoe_ceiling"),
  ("D15", "Claim.join_grade"),
  ("D16", "AEGIS.aegis_battery"),
  ("D17", "HALT.route_is_routeHalt"),
  ("D17", "PSP.CASCADE.halt_free_iff_all_pass_8"),
  ("D18", "HALT.first_failure_terminal_8"),
  ("D19", "OMEGA.omega_paid_floor"),
  ("D20", "CROSSING.price"),
  ("D21", "IAM.iam_unwitnessed_withheld"),
  ("D22", "AEGIS.aegis_constant"),
  ("D23", "Audit.unknown_routes_open"),
  ("D24", "DEFENSE.no_anchor_at_target"),
  ("D25", "OMEGA.omega_monotone"),
  ("D26", "TONGUE.deletion_no_left_inverse"),
  ("D27", "DEFENSE.self_check_is_not_witness"),
  ("D28", "LOCUS.three_states"),
  ("D29", "GEO.triaxial_open_gf2_count"),
  ("D30", "GEO.triaxial_lock_gf2_count"),
  ("D31", "GEO.cramer_executed"),
  ("D32", "OMEGA.omega_linear"),
  ("D33", "HALT.gate_counts_recorded"),
  ("D34", "NOMOS.compressible_bound_universal"),
  ("D35", "ROOT.actuation_universal"),
  ("D36", "OMEGA.omega_zero_bits"),
  ("D37", "IMPRINT.ghost_refused"),
  ("D38", "FOUND.pluralist_alternative_executed"),
  ("D39", "SEALS.sealG_walk"),
  ("D40", "GEO.hurwitz_closed"),
  ("D41", "CROSSING.ran_wholly_odd"),
  ("D42", "FTOE.T3_no_fixed_point"),
  ("D43", "TONGUE.deletion_annihilates"),
  ("D44", "NOMOS.incompressibility_cap"),
  ("D45", "DOT.outside_economy"),
  ("D46", "DOT.silence_is_not_a_verdict"),
  ("D47", "IAM.narcissus_truth_table"),
  ("D48", "FTOE.T16_price_bijection"),
  ("D49", "HALT.halts_routed"),
  ("D50", "DEFENSE.worldly_row_is_world_rowed"),
  ("D51", "PSP.QUAT.quat_basis_laws"),
  ("D52", "INVERSION.it_from_bit_refuted"),
  ("D52", "K4.target_is_primality"),
  ("D53", "DEFENSE.forward_is_world_rowed"),
  ("D54", "DEFENSE.formal_reads_never_the_deed"),
  ("D55", "AEGIS.aegis_battery"),
  ("D56", "ROOT.nest_31"),
  ("D57", "Bridge.discriminator"),
  ("D57", "Bridge.keyless_iff_valid"),
  ("D57", "TONGUE.ra_grade_pinned"),
  ("D58", "Bridge.recursion_is_sign_blind"),
  ("D59", "Bridge.line_property_is_keyed"),
  ("D60", "Bridge.recursion_is_shared"),
  ("D61", "Bridge.symmetry_is_keyless"),
  ("D62", "Bridge.socket_is_the_property"),
  ("D63", "HALT.rhHalt"),
  ("D63", "LOCUS.no_rh_locus"),
  ("D64", "IMPRINT.seal_needs_witness"),
  ("D64", "Bridge.no_socket_off_line"),
  ("D65", "TONGUE.coloc_grade"),
  ("D66", "FOUND.posits_loadbearing_on_nothing"),
  ("D67", "FOUND.register_routing_fidelity"),
  ("D68", "BRIDGE.supersession_routes"),
  ("D69", "IMPRINT.both_clean_is_ghost"),
  ("D69", "LOCUS.located_never_silent"),
  ("D70", "UC.uc_seal_failure_terminal"),
  ("D71", "DEFENSE.denial_is_priced"),
  ("D71", "Bridge.opens_on_the_deed")]

theorem rows_count : rows.length = 129 := by decide

end CROSSWALK


/-- info: 'Codex.LeftInverse' does not depend on any axioms -/
#guard_msgs in #print axioms Codex.LeftInverse
/-- info: 'Codex.RightInverse' does not depend on any axioms -/
#guard_msgs in #print axioms Codex.RightInverse
/-- info: 'Nat.factorial' does not depend on any axioms -/
#guard_msgs in #print axioms Nat.factorial
/-- info: 'CoreRat.div_pos_of_le' depends on axioms: [propext] -/
#guard_msgs in #print axioms CoreRat.div_pos_of_le
/-- info: 'CoreRat.div_gcd_pos' depends on axioms: [propext] -/
#guard_msgs in #print axioms CoreRat.div_gcd_pos
/-- info: 'CoreRat.coprime_div_gcd' depends on axioms: [propext] -/
#guard_msgs in #print axioms CoreRat.coprime_div_gcd
/-- info: 'Ratio.natAbs_signed' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.natAbs_signed
/-- info: 'Ratio.mk'' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.«mk'»
/-- info: 'Ratio.instOfNatRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instOfNatRat
/-- info: 'Ratio.instAddRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instAddRat
/-- info: 'Ratio.instMulRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instMulRat
/-- info: 'Ratio.instNegRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instNegRat
/-- info: 'Ratio.instSubRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instSubRat
/-- info: 'Ratio.inv' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.inv
/-- info: 'Ratio.instDivRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instDivRat
/-- info: 'Ratio.instLTRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instLTRat
/-- info: 'Ratio.instLERat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instLERat
/-- info: 'Ratio.instDecidableLtRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instDecidableLtRat
/-- info: 'Ratio.instDecidableLeRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instDecidableLeRat
/-- info: 'Ratio.pow' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.pow
/-- info: 'Ratio.instHPowRatNat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instHPowRatNat
/-- info: 'Ratio.instToStringRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.instToStringRat
/-- info: 'Ratio.num_zero' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.num_zero
/-- info: 'Ratio.den_zero' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.den_zero
/-- info: 'Ratio.mk'_zero_num' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms Ratio.«mk'_zero_num»
/-- info: 'Ratio.zero_mul' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms Ratio.zero_mul
/-- info: 'Ratio.mul_zero' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms Ratio.mul_zero
/-- info: 'Ratio.canonical' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.canonical
/-- info: 'Ratio.ext' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.ext
/-- info: 'Ratio.inv_zero' depends on axioms: [propext] -/
#guard_msgs in #print axioms Ratio.inv_zero
/-- info: 'Grade.rank' does not depend on any axioms -/
#guard_msgs in #print axioms Grade.rank
/-- info: 'Grade.weakest' does not depend on any axioms -/
#guard_msgs in #print axioms Grade.weakest
/-- info: 'Grade.weakest_is_a_link' does not depend on any axioms -/
#guard_msgs in #print axioms Grade.weakest_is_a_link
/-- info: 'Grade.weakest_idempotent' does not depend on any axioms -/
#guard_msgs in #print axioms Grade.weakest_idempotent
/-- info: 'Claim.join' does not depend on any axioms -/
#guard_msgs in #print axioms Claim.join
/-- info: 'Claim.join_grade' does not depend on any axioms -/
#guard_msgs in #print axioms Claim.join_grade
/-- info: 'deltaM' does not depend on any axioms -/
#guard_msgs in #print axioms deltaM
/-- info: 'socialWeight' does not depend on any axioms -/
#guard_msgs in #print axioms socialWeight
/-- info: 'FTOE.Even' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.Even
/-- info: 'FTOE.OddAt' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.OddAt
/-- info: 'FTOE.WhollyOdd' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.WhollyOdd
/-- info: 'FTOE.T1_wall' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T1_wall
/-- info: 'FTOE.T2_coalition' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T2_coalition
/-- info: 'FTOE.T3_no_fixed_point' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.T3_no_fixed_point
/-- info: 'FTOE.T4_one_bit' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T4_one_bit
/-- info: 'FTOE.T5_crossing' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T5_crossing
/-- info: 'FTOE.T6a_deed_anchor' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T6a_deed_anchor
/-- info: 'FTOE.T6b_deed_supply' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T6b_deed_supply
/-- info: 'FTOE.fTOE_port' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.fTOE_port
/-- info: 'FTOE.Involution' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.Involution
/-- info: 'FTOE.FixedPointFree' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.FixedPointFree
/-- info: 'FTOE.T7_global_wall' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.T7_global_wall
/-- info: 'FTOE.T8_torsor_forward' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T8_torsor_forward
/-- info: 'FTOE.T8_torsor_backward' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T8_torsor_backward
/-- info: 'FTOE.T9_torsor_inverse_left' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T9_torsor_inverse_left
/-- info: 'FTOE.T9_torsor_inverse_right' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T9_torsor_inverse_right
/-- info: 'FTOE.T10_factorization' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T10_factorization
/-- info: 'FTOE.T11_separation' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T11_separation
/-- info: 'FTOE.T12_encoder_injective' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T12_encoder_injective
/-- info: 'FTOE.T14_wall_factorization' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T14_wall_factorization
/-- info: 'FTOE.T13_wholly_odd_is_odd_everywhere' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.T13_wholly_odd_is_odd_everywhere
/-- info: 'FTOE.flipF' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.flipF
/-- info: 'FTOE.T15_price_bijection_forward' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T15_price_bijection_forward
/-- info: 'FTOE.T15_price_bijection_backward' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.T15_price_bijection_backward
/-- info: 'FTOE.fTOE_core' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.fTOE_core
/-- info: 'FTOE.OrbitRel' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.OrbitRel
/-- info: 'FTOE.OrbitRel_symmetric' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.OrbitRel_symmetric
/-- info: 'FTOE.Dtau' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.Dtau
/-- info: 'FTOE.calib' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.calib
/-- info: 'FTOE.calib_even' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.calib_even
/-- info: 'FTOE.descend' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.descend
/-- info: 'FTOE.priceForward' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.priceForward
/-- info: 'FTOE.priceBackward' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.priceBackward
/-- info: 'FTOE.T16_left_inverse' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T16_left_inverse
/-- info: 'FTOE.T16_right_inverse' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T16_right_inverse
/-- info: 'FTOE.T16_price_bijection' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T16_price_bijection
/-- info: 'FTOE.canonD0' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.canonD0
/-- info: 'FTOE.flipF_involution' does not depend on any axioms -/
#guard_msgs in #print axioms FTOE.flipF_involution
/-- info: 'FTOE.T16_canonical' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms FTOE.T16_canonical
/-- info: 'FTOE.T17_odd_everywhere_iff_wholly_odd' depends on axioms: [propext] -/
#guard_msgs in #print axioms FTOE.T17_odd_everywhere_iff_wholly_odd
/-- info: 'K4.val' does not depend on any axioms -/
#guard_msgs in #print axioms K4.val
/-- info: 'K4.tau' does not depend on any axioms -/
#guard_msgs in #print axioms K4.tau
/-- info: 'K4.target' does not depend on any axioms -/
#guard_msgs in #print axioms K4.target
/-- info: 'K4.rho' does not depend on any axioms -/
#guard_msgs in #print axioms K4.rho
/-- info: 'K4.tau_involution' does not depend on any axioms -/
#guard_msgs in #print axioms K4.tau_involution
/-- info: 'K4.tau_fixed_point_free' does not depend on any axioms -/
#guard_msgs in #print axioms K4.tau_fixed_point_free
/-- info: 'K4.target_wholly_odd' does not depend on any axioms -/
#guard_msgs in #print axioms K4.target_wholly_odd
/-- info: 'K4.register_even' does not depend on any axioms -/
#guard_msgs in #print axioms K4.register_even
/-- info: 'K4.val_lifts_mod_210' does not depend on any axioms -/
#guard_msgs in #print axioms K4.val_lifts_mod_210
/-- info: 'K4.wall' does not depend on any axioms -/
#guard_msgs in #print axioms K4.wall
/-- info: 'K4.pair_distinct' does not depend on any axioms -/
#guard_msgs in #print axioms K4.pair_distinct
/-- info: 'K4.price_one_bit' does not depend on any axioms -/
#guard_msgs in #print axioms K4.price_one_bit
/-- info: 'K4.price_full_fibre' does not depend on any axioms -/
#guard_msgs in #print axioms K4.price_full_fibre
/-- info: 'K4.wallClaim' does not depend on any axioms -/
#guard_msgs in #print axioms K4.wallClaim
/-- info: 'Audit.Ans.toBool' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.Ans.toBool
/-- info: 'Audit.ClaimInput.anyUnknown' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.ClaimInput.anyUnknown
/-- info: 'Audit.sealL' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.sealL
/-- info: 'Audit.DrillInput.anyUnknown' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.DrillInput.anyUnknown
/-- info: 'Audit.drillScreen' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.drillScreen
/-- info: 'Audit.refusalGates' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.refusalGates
/-- info: 'Audit.compartmentGates' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.compartmentGates
/-- info: 'Audit.auditClaim' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.auditClaim
/-- info: 'Audit.compartmentGrade' does not depend on any axioms -/
#guard_msgs in #print axioms Audit.compartmentGrade
/-- info: 'Audit.unknown_routes_open' depends on axioms: [propext] -/
#guard_msgs in #print axioms Audit.unknown_routes_open
/-- info: 'Audit.contentless_refused' depends on axioms: [propext] -/
#guard_msgs in #print axioms Audit.contentless_refused
/-- info: 'Audit.det3' depends on axioms: [propext] -/
#guard_msgs in #print axioms Audit.det3
/-- info: 'Audit.det3_two_id' depends on axioms: [propext] -/
#guard_msgs in #print axioms Audit.det3_two_id
/-- info: 'INVERSION.ItFromBit' does not depend on any axioms -/
#guard_msgs in #print axioms INVERSION.ItFromBit
/-- info: 'INVERSION.it_from_bit_refuted' does not depend on any axioms -/
#guard_msgs in #print axioms INVERSION.it_from_bit_refuted
/-- info: 'INVERSION.it_from_it' does not depend on any axioms -/
#guard_msgs in #print axioms INVERSION.it_from_it
/-- info: 'K4.it_from_it_canonical' does not depend on any axioms -/
#guard_msgs in #print axioms K4.it_from_it_canonical
/-- info: 'K4.it_from_bit_refuted_canonical' does not depend on any axioms -/
#guard_msgs in #print axioms K4.it_from_bit_refuted_canonical
/-- info: 'K4.inversionClaim' does not depend on any axioms -/
#guard_msgs in #print axioms K4.inversionClaim
/-- info: 'GEO.qmul' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qmul
/-- info: 'GEO.qconj' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qconj
/-- info: 'GEO.qadd' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qadd
/-- info: 'GEO.qsub' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qsub
/-- info: 'GEO.qnorm2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qnorm2
/-- info: 'GEO.qhalve' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qhalve
/-- info: 'GEO.qquarter' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qquarter
/-- info: 'GEO.qcanon' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qcanon
/-- info: 'GEO.q1' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.q1
/-- info: 'GEO.qi' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qi
/-- info: 'GEO.qj' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qj
/-- info: 'GEO.qk' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.qk
/-- info: 'GEO.chirality' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.chirality
/-- info: 'GEO.noncommutative' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.noncommutative
/-- info: 'GEO.hurwitz' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hurwitz
/-- info: 'GEO.hurwitz_norm' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hurwitz_norm
/-- info: 'GEO.hurwitz_products_even' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hurwitz_products_even
/-- info: 'GEO.hurwitz_closed' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hurwitz_closed
/-- info: 'GEO.hurwitzReps' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hurwitzReps
/-- info: 'GEO.units_mod_sign_twelve' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.units_mod_sign_twelve
/-- info: 'GEO.conjClass' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.conjClass
/-- info: 'GEO.classSizesAux' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.classSizesAux
/-- info: 'GEO.insNat' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.insNat
/-- info: 'GEO.insSort' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.insSort
/-- info: 'GEO.class_equation' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.class_equation
/-- info: 'GEO.shell2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.shell2
/-- info: 'GEO.shell_twentyfour' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.shell_twentyfour
/-- info: 'GEO.no_half_integer_norm2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.no_half_integer_norm2
/-- info: 'GEO.allGates' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.allGates
/-- info: 'GEO.gates_twelve' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gates_twelve
/-- info: 'GEO.gates_valid' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gates_valid
/-- info: 'GEO.gates_complete' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms GEO.gates_complete
/-- info: 'GEO.invCount' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.invCount
/-- info: 'GEO.perms24' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.perms24
/-- info: 'GEO.a4' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.a4
/-- info: 'GEO.a4_order' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.a4_order
/-- info: 'GEO.actG' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.actG
/-- info: 'GEO.a4_simply_transitive' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.a4_simply_transitive
/-- info: 'GEO.tetraVerts' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.tetraVerts
/-- info: 'GEO.tetraEdges' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.tetraEdges
/-- info: 'GEO.tetraFaces' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.tetraFaces
/-- info: 'GEO.euler_closure' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.euler_closure
/-- info: 'GEO.basisU' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.basisU
/-- info: 'GEO.perms6' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.perms6
/-- info: 'GEO.relabel_parity' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.relabel_parity
/-- info: 'GEO.O8' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.O8
/-- info: 'GEO.omul' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.omul
/-- info: 'GEO.osub' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.osub
/-- info: 'GEO.onorm2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.onorm2
/-- info: 'GEO.e8' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.e8
/-- info: 'GEO.octonion_associator' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.octonion_associator
/-- info: 'GEO.hPairs' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.hPairs
/-- info: 'GEO.norm_composition_H' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.norm_composition_H
/-- info: 'GEO.oPairs' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.oPairs
/-- info: 'GEO.norm_composition_O' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.norm_composition_O
/-- info: 'GEO.det2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.det2
/-- info: 'GEO.gf2Mul' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gf2Mul
/-- info: 'GEO.gf2Vecs' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gf2Vecs
/-- info: 'GEO.gf2Sols' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gf2Sols
/-- info: 'GEO.triaxial_lock_gf2' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.triaxial_lock_gf2
/-- info: 'GEO.triaxial_lock_gf2_count' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.triaxial_lock_gf2_count
/-- info: 'GEO.triaxial_open_gf2_count' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.triaxial_open_gf2_count
/-- info: 'GEO.V3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.V3
/-- info: 'GEO.M3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.M3
/-- info: 'GEO.det3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.det3
/-- info: 'GEO.adj3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.adj3
/-- info: 'GEO.mm3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.mm3
/-- info: 'GEO.diag3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.diag3
/-- info: 'GEO.mv3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.mv3
/-- info: 'GEO.vscale' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.vscale
/-- info: 'GEO.V3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.V3Z
/-- info: 'GEO.M3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.M3Z
/-- info: 'GEO.det3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.det3Z
/-- info: 'GEO.adj3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.adj3Z
/-- info: 'GEO.mm3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.mm3Z
/-- info: 'GEO.diag3Z' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.diag3Z
/-- info: 'GEO.adjugate_identity_int' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms GEO.adjugate_identity_int
/-- info: 'GEO.AdjugateIdentity3' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.AdjugateIdentity3
/-- info: 'GEO.adj3Samples' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.adj3Samples
/-- info: 'GEO.adj3_executed' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.adj3_executed
/-- info: 'GEO.cramerSolve' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.cramerSolve
/-- info: 'GEO.cramer_executed' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.cramer_executed
/-- info: 'GEO.golAdmit' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.golAdmit
/-- info: 'GEO.gateNames' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateNames
/-- info: 'GEO.gateNames_twelve' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateNames_twelve
/-- info: 'GEO.gateScreenGo' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreenGo
/-- info: 'GEO.gateScreen' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreen
/-- info: 'GEO.gateScreen_clean' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreen_clean
/-- info: 'GEO.gateScreen_first_failure' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreen_first_failure
/-- info: 'GEO.gateScreen_names_failed_gate' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreen_names_failed_gate
/-- info: 'GEO.gateScreen_arity' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreen_arity
/-- info: 'GEO.ClaimInputRA.anyUnknown' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.ClaimInputRA.anyUnknown
/-- info: 'GEO.rowCascadeRACore' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.rowCascadeRACore
/-- info: 'GEO.rowCascadeRA' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.rowCascadeRA
/-- info: 'GEO.unknown_routes_open_ra' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.unknown_routes_open_ra
/-- info: 'GEO.raDecode' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.raDecode
/-- info: 'GEO.raBattery' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.raBattery
/-- info: 'GEO.ra_battery_f2' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_battery_f2
/-- info: 'GEO.ra_ledger_refused' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_ledger_refused
/-- info: 'GEO.ra_ledger_iii' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_ledger_iii
/-- info: 'GEO.ra_ledger_ii' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_ledger_ii
/-- info: 'GEO.ra_ledger_void' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_ledger_void
/-- info: 'GEO.ra_ledger_aGivenRA' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.ra_ledger_aGivenRA
/-- info: 'GEO.RAVerdict.toToken' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.RAVerdict.toToken
/-- info: 'GEO.GolToken.toToken' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.GolToken.toToken
/-- info: 'GEO.gateScreenToken' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.gateScreenToken
/-- info: 'GEO.demoInputA' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.demoInputA
/-- info: 'GEO.demoInputVoid' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.demoInputVoid
/-- info: 'GEO.demoInputOpen' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.demoInputOpen
/-- info: 'ROOT.Actuates' depends on axioms: [ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms ROOT.Actuates
/-- info: 'ROOT.actuation_universal' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms ROOT.actuation_universal
/-- info: 'ROOT.raClaim' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms ROOT.raClaim
/-- info: 'ROOT.boolCut' does not depend on any axioms -/
#guard_msgs in #print axioms ROOT.boolCut
/-- info: 'ROOT.nest_31' depends on axioms: [ROOT.FormalDomain, ROOT.L1m, ROOT.L3m, ROOT.nest_21, ROOT.nest_32] -/
#guard_msgs in #print axioms ROOT.nest_31
/-- info: 'ROOT.nestClaim' depends on axioms: [ROOT.FormalDomain, ROOT.L1m, ROOT.L3m, ROOT.nest_21, ROOT.nest_32] -/
#guard_msgs in #print axioms ROOT.nestClaim
/-- info: 'ROOT.throneEmpty' depends on axioms: [ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms ROOT.throneEmpty
/-- info: 'ROOT.throne_is_RA' depends on axioms: [ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms ROOT.throne_is_RA
/-- info: 'SEALS.sealL' does not depend on any axioms -/
#guard_msgs in #print axioms SEALS.sealL
/-- info: 'SEALS.sealG' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms SEALS.sealG
/-- info: 'SEALS.sealM' does not depend on any axioms -/
#guard_msgs in #print axioms SEALS.sealM
/-- info: 'SEALS.seals_distinct' does not depend on any axioms -/
#guard_msgs in #print axioms SEALS.seals_distinct
/-- info: 'SEALS.seal_names_match' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms SEALS.seal_names_match
/-- info: 'SEALS.sealG_walk' depends on axioms: [propext] -/
#guard_msgs in #print axioms SEALS.sealG_walk
/-- info: 'POSTULATE.OneCut' depends on axioms: [POSTULATE.Row, POSTULATE.SupplyClean] -/
#guard_msgs in #print axioms POSTULATE.OneCut
/-- info: 'POSTULATE.F2' depends on axioms: [POSTULATE.Row, POSTULATE.SupplyClean] -/
#guard_msgs in #print axioms POSTULATE.F2
/-- info: 'POSTULATE.F2_kills' depends on axioms: [POSTULATE.Row, POSTULATE.SupplyClean] -/
#guard_msgs in #print axioms POSTULATE.F2_kills
/-- info: 'POSTULATE.BSDContract' depends on axioms: [POSTULATE.Algorithm, POSTULATE.FrozenData, POSTULATE.certifiedPairing] -/
#guard_msgs in #print axioms POSTULATE.BSDContract
/-- info: 'POSTULATE.F6' depends on axioms: [POSTULATE.Algorithm, POSTULATE.FrozenData, POSTULATE.certifiedPairing] -/
#guard_msgs in #print axioms POSTULATE.F6
/-- info: 'TONGUE.enlarge' does not depend on any axioms -/
#guard_msgs in #print axioms TONGUE.enlarge
/-- info: 'TONGUE.unclosed' does not depend on any axioms -/
#guard_msgs in #print axioms TONGUE.unclosed
/-- info: 'TONGUE.earned_freedom' does not depend on any axioms -/
#guard_msgs in #print axioms TONGUE.earned_freedom
/-- info: 'TONGUE.colocClaim' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms TONGUE.colocClaim
/-- info: 'TONGUE.coloc_grade' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms TONGUE.coloc_grade
/-- info: 'TONGUE.ra_grade_pinned' depends on axioms: [ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms TONGUE.ra_grade_pinned
/-- info: 'TONGUE.wall_grade_pinned' does not depend on any axioms -/
#guard_msgs in #print axioms TONGUE.wall_grade_pinned
/-- info: 'TONGUE.inversion_grade_pinned' does not depend on any axioms -/
#guard_msgs in #print axioms TONGUE.inversion_grade_pinned
/-- info: 'TONGUE.nest_grade_pinned' depends on axioms: [ROOT.FormalDomain, ROOT.L1m, ROOT.L3m, ROOT.nest_21, ROOT.nest_32] -/
#guard_msgs in #print axioms TONGUE.nest_grade_pinned
/-- info: 'terminalWall' does not depend on any axioms -/
#guard_msgs in #print axioms terminalWall
/-- info: 'terminalPrice' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms terminalPrice
/-- info: 'TERMINAL' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms TERMINAL
/-- info: 'terminalClaim' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms terminalClaim
/-- info: 'terminal_grade_pinned' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms terminal_grade_pinned
/-- info: 'IAM.iamToken' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.iamToken
/-- info: 'IAM.iam_unwitnessed_withheld' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.iam_unwitnessed_withheld
/-- info: 'IAM.iam_witnessed_speaks' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.iam_witnessed_speaks
/-- info: 'IAM.narcissus_truth_table' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.narcissus_truth_table
/-- info: 'IAM.one_bit_freedom' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.one_bit_freedom
/-- info: 'IAM.IamToken.toToken' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.IamToken.toToken
/-- info: 'IAM.codexSelfRead' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.codexSelfRead
/-- info: 'IAM.codex_self_read_interior' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.codex_self_read_interior
/-- info: 'IAM.terminalWord' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.terminalWord
/-- info: 'IAM.terminal_word' does not depend on any axioms -/
#guard_msgs in #print axioms IAM.terminal_word
/-- info: 'GEO.SignPattern' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.SignPattern
/-- info: 'GEO.allSigns' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.allSigns
/-- info: 'GEO.signComp' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.signComp
/-- info: 'GEO.reflection_eight' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.reflection_eight
/-- info: 'GEO.reflection_eight_is_two_cubed' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.reflection_eight_is_two_cubed
/-- info: 'GEO.reflections_abelian' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.reflections_abelian
/-- info: 'GEO.reflections_involutive' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.reflections_involutive
/-- info: 'GEO.signVal' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.signVal
/-- info: 'GEO.reflMat' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.reflMat
/-- info: 'GEO.reflection_reverses_orientation' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.reflection_reverses_orientation
/-- info: 'GEO.sandwich' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.sandwich
/-- info: 'GEO.reflection_blind_executed' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.reflection_blind_executed
/-- info: 'GEO.V5' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.V5
/-- info: 'GEO.cube5' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.cube5
/-- info: 'GEO.neighbors5' does not depend on any axioms -/
#guard_msgs in #print axioms GEO.neighbors5
/-- info: 'GEO.fivecube_thirtytwo' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.fivecube_thirtytwo
/-- info: 'GEO.fivecube_vertices_distinct' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.fivecube_vertices_distinct
/-- info: 'GEO.fivecube_degree_five' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.fivecube_degree_five
/-- info: 'GEO.counts_forced' depends on axioms: [propext] -/
#guard_msgs in #print axioms GEO.counts_forced
/-- info: 'TONGUE.deletionOp' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.deletionOp
/-- info: 'TONGUE.e3' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.e3
/-- info: 'TONGUE.deletion_idempotent' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.deletion_idempotent
/-- info: 'TONGUE.deletion_singular' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.deletion_singular
/-- info: 'TONGUE.deletion_minor_nonsingular' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.deletion_minor_nonsingular
/-- info: 'TONGUE.deletion_annihilates' depends on axioms: [propext] -/
#guard_msgs in #print axioms TONGUE.deletion_annihilates
/-- info: 'TONGUE.linear_fixes_zero' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms TONGUE.linear_fixes_zero
/-- info: 'TONGUE.deletion_no_left_inverse' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms TONGUE.deletion_no_left_inverse
/-- info: 'TONGUE.deletion_monoid_not_group' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms TONGUE.deletion_monoid_not_group
/-- info: 'TONGUE.tongue_obedience' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms TONGUE.tongue_obedience
/-- info: 'OFFICE.discriminator' does not depend on any axioms -/
#guard_msgs in #print axioms OFFICE.discriminator
/-- info: 'OFFICE.discriminatorQ2First' does not depend on any axioms -/
#guard_msgs in #print axioms OFFICE.discriminatorQ2First
/-- info: 'OFFICE.order_loadbearing' does not depend on any axioms -/
#guard_msgs in #print axioms OFFICE.order_loadbearing
/-- info: 'OFFICE.citation_cannot_promote' does not depend on any axioms -/
#guard_msgs in #print axioms OFFICE.citation_cannot_promote
/-- info: 'UC.routeHalt' does not depend on any axioms -/
#guard_msgs in #print axioms UC.routeHalt
/-- info: 'UC.routeHalt_fidelity' does not depend on any axioms -/
#guard_msgs in #print axioms UC.routeHalt_fidelity
/-- info: 'UC.universalCascade' does not depend on any axioms -/
#guard_msgs in #print axioms UC.universalCascade
/-- info: 'UC.uc_seal_failure_terminal' does not depend on any axioms -/
#guard_msgs in #print axioms UC.uc_seal_failure_terminal
/-- info: 'UC.uc_routes_eight' does not depend on any axioms -/
#guard_msgs in #print axioms UC.uc_routes_eight
/-- info: 'UC.uc_routes_five' does not depend on any axioms -/
#guard_msgs in #print axioms UC.uc_routes_five
/-- info: 'UC.uc_unmeasured' does not depend on any axioms -/
#guard_msgs in #print axioms UC.uc_unmeasured
/-- info: 'UC.circularityScreen' does not depend on any axioms -/
#guard_msgs in #print axioms UC.circularityScreen
/-- info: 'UC.circularity_refused_at_target' does not depend on any axioms -/
#guard_msgs in #print axioms UC.circularity_refused_at_target
/-- info: 'UC.road_requires_conjunction' does not depend on any axioms -/
#guard_msgs in #print axioms UC.road_requires_conjunction
/-- info: 'UC.circRows' does not depend on any axioms -/
#guard_msgs in #print axioms UC.circRows
/-- info: 'UC.circ_space' does not depend on any axioms -/
#guard_msgs in #print axioms UC.circ_space
/-- info: 'OMEGA.kbRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.kbRat
/-- info: 'OMEGA.ln2Rat' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.ln2Rat
/-- info: 'OMEGA.landauerRat' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.landauerRat
/-- info: 'OMEGA.omegaBoundary' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omegaBoundary
/-- info: 'OMEGA.omega_zero_bits' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_zero_bits
/-- info: 'OMEGA.omega_paid_floor' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_paid_floor
/-- info: 'OMEGA.one_bit_freedom_priced' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.one_bit_freedom_priced
/-- info: 'OMEGA.omega_reversible_branch' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_reversible_branch
/-- info: 'OMEGA.omega_refuses_nonpositive_temp' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_refuses_nonpositive_temp
/-- info: 'OMEGA.omega_monotone' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_monotone
/-- info: 'OMEGA.omega_linear' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_linear
/-- info: 'OMEGA.landauer_zero_bits' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.landauer_zero_bits
/-- info: 'OMEGA.omega_verdict_fidelity' depends on axioms: [propext] -/
#guard_msgs in #print axioms OMEGA.omega_verdict_fidelity
/-- info: 'AEGIS.refusalConst' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.refusalConst
/-- info: 'AEGIS.aegisReset' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegisReset
/-- info: 'AEGIS.aegisGuard' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegisGuard
/-- info: 'AEGIS.aegis_constant' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegis_constant
/-- info: 'AEGIS.aegis_deed_increments' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegis_deed_increments
/-- info: 'AEGIS.aegis_reads_parameter' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegis_reads_parameter
/-- info: 'AEGIS.aegisFourLogicRun' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegisFourLogicRun
/-- info: 'AEGIS.aegis_battery' does not depend on any axioms -/
#guard_msgs in #print axioms AEGIS.aegis_battery
/-- info: 'NOMOS.allStrings' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.allStrings
/-- info: 'NOMOS.allStrings_length' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.allStrings_length
/-- info: 'NOMOS.twoPowPos' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.twoPowPos
/-- info: 'NOMOS.descs' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.descs
/-- info: 'NOMOS.descs_length' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.descs_length
/-- info: 'NOMOS.incompressibility_cap' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.incompressibility_cap
/-- info: 'NOMOS.nomosRows' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.nomosRows
/-- info: 'NOMOS.incompressibility_executed' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.incompressibility_executed
/-- info: 'NOMOS.decodeId' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.decodeId
/-- info: 'NOMOS.decodePad' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.decodePad
/-- info: 'NOMOS.compressible_bound_universal' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.compressible_bound_universal
/-- info: 'NOMOS.cbUniversal' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.cbUniversal
/-- info: 'NOMOS.cb_id_8_2' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.cb_id_8_2
/-- info: 'NOMOS.cb_pad3_8_2' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.cb_pad3_8_2
/-- info: 'NOMOS.cb_pad2_6_1' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.cb_pad2_6_1
/-- info: 'NOMOS.cb_pad4_12_3' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.cb_pad4_12_3
/-- info: 'NOMOS.recoverable' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.recoverable
/-- info: 'NOMOS.nomos_fuel_is_omega_floor' depends on axioms: [propext] -/
#guard_msgs in #print axioms NOMOS.nomos_fuel_is_omega_floor
/-- info: 'NOMOS.nomosScreen' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.nomosScreen
/-- info: 'NOMOS.nomosScreen_battery' does not depend on any axioms -/
#guard_msgs in #print axioms NOMOS.nomosScreen_battery
/-- info: 'BRIDGE.ceiling' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.ceiling
/-- info: 'BRIDGE.census' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.census
/-- info: 'BRIDGE.census_count' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.census_count
/-- info: 'BRIDGE.post_seal_disposition' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.post_seal_disposition
/-- info: 'BRIDGE.weakest_never_above_left' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.weakest_never_above_left
/-- info: 'BRIDGE.bridge_ceiling_caps' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.bridge_ceiling_caps
/-- info: 'BRIDGE.successorOf' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.successorOf
/-- info: 'BRIDGE.supersession_routes' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.supersession_routes
/-- info: 'BRIDGE.bridgeScreen' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.bridgeScreen
/-- info: 'BRIDGE.bridgeScreen_total' does not depend on any axioms -/
#guard_msgs in #print axioms BRIDGE.bridgeScreen_total
/-- info: 'FOUND.sigmaP' depends on axioms: [propext] -/
#guard_msgs in #print axioms FOUND.sigmaP
/-- info: 'FOUND.pluralist_alternative_executed' depends on axioms: [propext] -/
#guard_msgs in #print axioms FOUND.pluralist_alternative_executed
/-- info: 'FOUND.posits' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.posits
/-- info: 'FOUND.posits_loadbearing_on_nothing' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.posits_loadbearing_on_nothing
/-- info: 'FOUND.gradeOfRank' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.gradeOfRank
/-- info: 'FOUND.posit_never_raises' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.posit_never_raises
/-- info: 'FOUND.bandOf' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.bandOf
/-- info: 'FOUND.register_routing_fidelity' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.register_routing_fidelity
/-- info: 'FOUND.verdictInventory' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.verdictInventory
/-- info: 'FOUND.verdicts_posit_free' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.verdicts_posit_free
/-- info: 'FOUND.engine_never_authority' does not depend on any axioms -/
#guard_msgs in #print axioms FOUND.engine_never_authority
/-- info: 'HALT.cascade' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.cascade
/-- info: 'HALT.patterns' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.patterns
/-- info: 'HALT.fftSpec' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.fftSpec
/-- info: 'HALT.first_failure_terminal_5' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.first_failure_terminal_5
/-- info: 'HALT.first_failure_terminal_7' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.first_failure_terminal_7
/-- info: 'HALT.first_failure_terminal_8' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.first_failure_terminal_8
/-- info: 'HALT.first_failure_terminal_12' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.first_failure_terminal_12
/-- info: 'HALT.halt_free_iff_all_pass_8' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.halt_free_iff_all_pass_8
/-- info: 'HALT.gate_counts_recorded' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.gate_counts_recorded
/-- info: 'HALT.signPatterns' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.signPatterns
/-- info: 'HALT.ninth_gate_barred' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.ninth_gate_barred
/-- info: 'HALT.route' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.route
/-- info: 'HALT.ofUC' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.ofUC
/-- info: 'HALT.route_is_routeHalt' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms HALT.route_is_routeHalt
/-- info: 'HALT.route_samples' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.route_samples
/-- info: 'HALT.tokenBranch' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.tokenBranch
/-- info: 'HALT.router_exclusive' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.router_exclusive
/-- info: 'HALT.readingRoadsGate' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.readingRoadsGate
/-- info: 'HALT.one_door_open' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.one_door_open
/-- info: 'HALT.no_walk_passes_the_aperture' depends on axioms: [propext] -/
#guard_msgs in #print axioms HALT.no_walk_passes_the_aperture
/-- info: 'HALT.xiGates' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.xiGates
/-- info: 'HALT.oGates' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.oGates
/-- info: 'HALT.gate_censuses' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.gate_censuses
/-- info: 'HALT.rhHalt' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.rhHalt
/-- info: 'HALT.pnpHalt' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.pnpHalt
/-- info: 'HALT.halts_routed' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.halts_routed
/-- info: 'HALT.legacy_halts_are_instances' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.legacy_halts_are_instances
/-- info: 'HALT.terminal_one_bit' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.terminal_one_bit
/-- info: 'HALT.species_exhausted' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.species_exhausted
/-- info: 'HALT.haltGrades' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.haltGrades
/-- info: 'HALT.ftoe_ceiling' does not depend on any axioms -/
#guard_msgs in #print axioms HALT.ftoe_ceiling
/-- info: 'CROSSING.ExecFrame' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.ExecFrame
/-- info: 'CROSSING.execFlip' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.execFlip
/-- info: 'CROSSING.formalRead' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.formalRead
/-- info: 'CROSSING.ran' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.ran
/-- info: 'CROSSING.formalRead_even' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.formalRead_even
/-- info: 'CROSSING.ran_wholly_odd' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.ran_wholly_odd
/-- info: 'CROSSING.execFlip_involution' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.execFlip_involution
/-- info: 'CROSSING.ran_odd_at_true' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.ran_odd_at_true
/-- info: 'CROSSING.wall' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.wall
/-- info: 'CROSSING.deed' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.deed
/-- info: 'CROSSING.price' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms CROSSING.price
/-- info: 'CROSSING.crossing' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.crossing
/-- info: 'CROSSING.identity_one_bit' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.identity_one_bit
/-- info: 'CROSSING.fibre4' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.fibre4
/-- info: 'CROSSING.fibre4_sixteen' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.fibre4_sixteen
/-- info: 'CROSSING.fibre4_distinct' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.fibre4_distinct
/-- info: 'CROSSING.price_on_this_file' depends on axioms: [Quot.sound] -/
#guard_msgs in #print axioms CROSSING.price_on_this_file
/-- info: 'CROSSING.formal_never_odd' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.formal_never_odd
/-- info: 'CROSSING.constant_no_crossing' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSING.constant_no_crossing
/-- info: 'CROSSING.harmony' depends on axioms: [propext] -/
#guard_msgs in #print axioms CROSSING.harmony
/-- info: 'LOCUS.Separates' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Separates
/-- info: 'LOCUS.Factors' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Factors
/-- info: 'LOCUS.wall_of_sep' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.wall_of_sep
/-- info: 'LOCUS.swap' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.swap
/-- info: 'LOCUS.swap_involution' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.swap_involution
/-- info: 'LOCUS.swap_record_even' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.swap_record_even
/-- info: 'LOCUS.swap_flips_pair' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.swap_flips_pair
/-- info: 'LOCUS.seat_of_sep' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.seat_of_sep
/-- info: 'LOCUS.k4_separated_pair' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.k4_separated_pair
/-- info: 'LOCUS.k4_wall_of_pair' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.k4_wall_of_pair
/-- info: 'LOCUS.readout' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.readout
/-- info: 'LOCUS.factors_of_not_sep_list' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms LOCUS.factors_of_not_sep_list
/-- info: 'LOCUS.factors_iff_not_sep_list' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms LOCUS.factors_iff_not_sep_list
/-- info: 'LOCUS.Channel' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Channel
/-- info: 'LOCUS.Token.toEconomy' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Token.toEconomy
/-- info: 'LOCUS.Reading.orbits' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Reading.orbits
/-- info: 'LOCUS.Reading.owed' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Reading.owed
/-- info: 'LOCUS.Reading.complete' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Reading.complete
/-- info: 'LOCUS.branchOf' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.branchOf
/-- info: 'LOCUS.emit' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.emit
/-- info: 'LOCUS.Reading.state' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Reading.state
/-- info: 'LOCUS.three_states' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.three_states
/-- info: 'LOCUS.no_seat_no_locus' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.no_seat_no_locus
/-- info: 'LOCUS.unlocated_is_plain_open' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.unlocated_is_plain_open
/-- info: 'LOCUS.located_never_silent' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.located_never_silent
/-- info: 'LOCUS.crossed_requires_complete' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.crossed_requires_complete
/-- info: 'LOCUS.crossed_requires_channel' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.crossed_requires_channel
/-- info: 'LOCUS.halt_carries_owed' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.halt_carries_owed
/-- info: 'LOCUS.unchannelled_is_halt' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms LOCUS.unchannelled_is_halt
/-- info: 'LOCUS.halt_reports_owed' depends on axioms: [propext] -/
#guard_msgs in #print axioms LOCUS.halt_reports_owed
/-- info: 'LOCUS.owed_zero_is_unchannelled' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms LOCUS.owed_zero_is_unchannelled
/-- info: 'LOCUS.one_bit_apart' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.one_bit_apart
/-- info: 'LOCUS.legacy_xi' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.legacy_xi
/-- info: 'LOCUS.legacy_o' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.legacy_o
/-- info: 'LOCUS.legacy_bare' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.legacy_bare
/-- info: 'LOCUS.k4_locus' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.k4_locus
/-- info: 'LOCUS.slotLists' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.slotLists
/-- info: 'LOCUS.slotLists_twelve' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.slotLists_twelve
/-- info: 'LOCUS.slotLists_pos' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.slotLists_pos
/-- info: 'LOCUS.allReadings' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.allReadings
/-- info: 'LOCUS.reading_space' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.reading_space
/-- info: 'LOCUS.census_no_seat_no_locus' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_no_seat_no_locus
/-- info: 'LOCUS.census_located_never_silent' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_located_never_silent
/-- info: 'LOCUS.census_crossed_iff_complete_channelled' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_crossed_iff_complete_channelled
/-- info: 'LOCUS.census_halt_reports_owed' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_halt_reports_owed
/-- info: 'LOCUS.census_owed_zero_is_unchannelled' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_owed_zero_is_unchannelled
/-- info: 'LOCUS.census_three_states' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.census_three_states
/-- info: 'LOCUS.Token.render' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Token.render
/-- info: 'LOCUS.Token.ascii' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.Token.ascii
/-- info: 'LOCUS.sealAscii' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.sealAscii
/-- info: 'LOCUS.render_receipted' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.render_receipted
/-- info: 'LOCUS.render_injective_in_owed' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.render_injective_in_owed
/-- info: 'LOCUS.voidImage' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.voidImage
/-- info: 'LOCUS.void_precedes_economy' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.void_precedes_economy
/-- info: 'LOCUS.legacy_records_not_promoted' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.legacy_records_not_promoted
/-- info: 'LOCUS.no_rh_locus' does not depend on any axioms -/
#guard_msgs in #print axioms LOCUS.no_rh_locus
/-- info: 'PSP.ORIENT.V3' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.V3
/-- info: 'PSP.ORIENT.M3' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.M3
/-- info: 'PSP.ORIENT.det3' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.det3
/-- info: 'PSP.ORIENT.neg3' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.neg3
/-- info: 'PSP.ORIENT.signMatrices' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.signMatrices
/-- info: 'PSP.ORIENT.lock_scalar_sign_blind' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.lock_scalar_sign_blind
/-- info: 'PSP.ORIENT.det_sign_flips_in_odd_dimension' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.ORIENT.det_sign_flips_in_odd_dimension
/-- info: 'PSP.QUAT.Q' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.Q
/-- info: 'PSP.QUAT.qmul' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qmul
/-- info: 'PSP.QUAT.qi' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qi
/-- info: 'PSP.QUAT.qj' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qj
/-- info: 'PSP.QUAT.qk' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qk
/-- info: 'PSP.QUAT.qneg1' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qneg1
/-- info: 'PSP.QUAT.quat_basis_laws' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.quat_basis_laws
/-- info: 'PSP.QUAT.qnorm' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.qnorm
/-- info: 'PSP.QUAT.isInt' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.isInt
/-- info: 'PSP.QUAT.isHalf' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.isHalf
/-- info: 'PSP.QUAT.hurwitzOK' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.hurwitzOK
/-- info: 'PSP.QUAT.grid' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.grid
/-- info: 'PSP.QUAT.tuples4' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.tuples4
/-- info: 'PSP.QUAT.hurwitz_units_24' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.hurwitz_units_24
/-- info: 'PSP.QUAT.grid2' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.grid2
/-- info: 'PSP.QUAT.tuples4i' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.tuples4i
/-- info: 'PSP.QUAT.norm2_shell_split' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.QUAT.norm2_shell_split
/-- info: 'PSP.CD.cdconj' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.cdconj
/-- info: 'PSP.CD.padd' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.padd
/-- info: 'PSP.CD.psub' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.psub
/-- info: 'PSP.CD.cdmul' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.cdmul
/-- info: 'PSP.CD.e' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.e
/-- info: 'PSP.CD.smul' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.smul
/-- info: 'PSP.CD.octonion_associator' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.octonion_associator
/-- info: 'PSP.CD.sx' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.sx
/-- info: 'PSP.CD.sy' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.sy
/-- info: 'PSP.CD.zero16' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.zero16
/-- info: 'PSP.CD.sqnorm' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.sqnorm
/-- info: 'PSP.CD.sedenion_zero_divisor' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CD.sedenion_zero_divisor
/-- info: 'PSP.CASCADE.cascade' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.CASCADE.cascade
/-- info: 'PSP.CASCADE.patterns8' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CASCADE.patterns8
/-- info: 'PSP.CASCADE.spec' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.CASCADE.spec
/-- info: 'PSP.CASCADE.first_failure_terminal_8' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CASCADE.first_failure_terminal_8
/-- info: 'PSP.CASCADE.halt_free_iff_all_pass_8' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.CASCADE.halt_free_iff_all_pass_8
/-- info: 'PSP.GROUNDLESS.o0Neighbors' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.GROUNDLESS.o0Neighbors
/-- info: 'PSP.GROUNDLESS.fiveCubeCoords' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.GROUNDLESS.fiveCubeCoords
/-- info: 'PSP.GROUNDLESS.deg5' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.GROUNDLESS.deg5
/-- info: 'PSP.GROUNDLESS.groundless_cascade_degree' depends on axioms: [propext] -/
#guard_msgs in #print axioms PSP.GROUNDLESS.groundless_cascade_degree
/-- info: 'PSP.TOKEN.level' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.TOKEN.level
/-- info: 'PSP.TOKEN.terminal_tokens_level_and_distinct' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.TOKEN.terminal_tokens_level_and_distinct
/-- info: 'PSP.TWOGROUP.two_group_census' does not depend on any axioms -/
#guard_msgs in #print axioms PSP.TWOGROUP.two_group_census

/-! ## the axiom cones, pinned -/
/-- info: 'Bridge.pe' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.pe
/-- info: 'Bridge.fold_involutive' depends on axioms: [propext] -/
#guard_msgs in #print axioms Bridge.fold_involutive
/-- info: 'Bridge.locus_is_the_fixed_set' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.locus_is_the_fixed_set
/-- info: 'Bridge.locus_inhabited' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.locus_inhabited
/-- info: 'Bridge.line_symmetric' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.line_symmetric
/-- info: 'Bridge.plane_line_property' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.plane_line_property
/-- info: 'Bridge.cannot_lie' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.cannot_lie
/-- info: 'Bridge.cannot_deviate' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.cannot_deviate
/-- info: 'Bridge.read_twice' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.read_twice
/-- info: 'Bridge.halted_iff' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.halted_iff
/-- info: 'Bridge.cannot_extend' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms Bridge.cannot_extend
/-- info: 'Bridge.cannot_divide' depends on axioms: [propext] -/
#guard_msgs in #print axioms Bridge.cannot_divide
/-- info: 'Bridge.cannot_reverse' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.cannot_reverse
/-- info: 'Bridge.wall' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.wall
/-- info: 'Bridge.calibration' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.calibration
/-- info: 'Bridge.opens_on_the_deed' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.opens_on_the_deed
/-- info: 'Bridge.recursion_is_shared' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.recursion_is_shared
/-- info: 'Bridge.recursion_is_sign_blind' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.recursion_is_sign_blind
/-- info: 'Bridge.exactly_one_stands' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.exactly_one_stands
/-- info: 'Bridge.denial_is_coherent' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.denial_is_coherent
/-- info: 'Bridge.line_property_contingent' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.line_property_contingent
/-- info: 'Bridge.keyless_iff_valid' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.keyless_iff_valid
/-- info: 'Bridge.discriminator' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.discriminator
/-- info: 'Bridge.symmetry_is_keyless' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.symmetry_is_keyless
/-- info: 'Bridge.line_property_is_keyed' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.line_property_is_keyed
/-- info: 'Bridge.denial_asymmetry' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.denial_asymmetry
/-- info: 'Bridge.socket_is_the_property' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.socket_is_the_property
/-- info: 'Bridge.socket_on_the_plane' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.socket_on_the_plane
/-- info: 'Bridge.bridge_carries' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.bridge_carries
/-- info: 'Bridge.no_socket_off_line' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.no_socket_off_line
/-- info: 'Bridge.the_bridge' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.the_bridge
/-- info: 'Bridge.Plane' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.Plane
/-- info: 'Bridge.τ' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.τ
/-- info: 'Bridge.onLine' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.onLine
/-- info: 'Bridge.LineProperty' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.LineProperty
/-- info: 'Bridge.planeFrame' depends on axioms: [propext] -/
#guard_msgs in #print axioms Bridge.planeFrame
/-- info: 'Bridge.lineFrame' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in #print axioms Bridge.lineFrame
/-- info: 'Bridge.theRecord' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.theRecord
/-- info: 'Bridge.delete' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.delete
/-- info: 'Bridge.Even' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.Even
/-- info: 'Bridge.SelfVerifying' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.SelfVerifying
/-- info: 'Bridge.twoPoint' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.twoPoint
/-- info: 'Bridge.Keyless' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.Keyless
/-- info: 'Bridge.Keyed' does not depend on any axioms -/
#guard_msgs in #print axioms Bridge.Keyed

theorem codexCone : True :=
  let _ := @Nat.factorial
  let _ := @CoreRat.div_pos_of_le
  let _ := @CoreRat.div_gcd_pos
  let _ := @CoreRat.coprime_div_gcd
  let _ := @Ratio.natAbs_signed
  let _ := @Ratio.«mk'»
  let _ := @Ratio.instOfNatRat
  let _ := @Ratio.instAddRat
  let _ := @Ratio.instMulRat
  let _ := @Ratio.instNegRat
  let _ := @Ratio.instSubRat
  let _ := @Ratio.inv
  let _ := @Ratio.instDivRat
  let _ := @Ratio.instLTRat
  let _ := @Ratio.instLERat
  let _ := @Ratio.instDecidableLtRat
  let _ := @Ratio.instDecidableLeRat
  let _ := @Ratio.pow
  let _ := @Ratio.instHPowRatNat
  let _ := @Ratio.instToStringRat
  let _ := @Ratio.num_zero
  let _ := @Ratio.den_zero
  let _ := @Ratio.«mk'_zero_num»
  let _ := @Ratio.zero_mul
  let _ := @Ratio.mul_zero
  let _ := @Ratio.canonical
  let _ := @Ratio.ext
  let _ := @Ratio.inv_zero
  let _ := @Grade.rank
  let _ := @Grade.weakest
  let _ := @Grade.weakest_is_a_link
  let _ := @Grade.weakest_idempotent
  let _ := @Claim.join
  let _ := @Claim.join_grade
  let _ := @deltaM
  let _ := @socialWeight
  let _ := @FTOE.Even
  let _ := @FTOE.OddAt
  let _ := @FTOE.WhollyOdd
  let _ := @FTOE.T1_wall
  let _ := @FTOE.T2_coalition
  let _ := @FTOE.T3_no_fixed_point
  let _ := @FTOE.T4_one_bit
  let _ := @FTOE.T5_crossing
  let _ := @FTOE.T6a_deed_anchor
  let _ := @FTOE.T6b_deed_supply
  let _ := @FTOE.fTOE_port
  let _ := @FTOE.Involution
  let _ := @FTOE.FixedPointFree
  let _ := @FTOE.T7_global_wall
  let _ := @FTOE.T8_torsor_forward
  let _ := @FTOE.T8_torsor_backward
  let _ := @FTOE.T9_torsor_inverse_left
  let _ := @FTOE.T9_torsor_inverse_right
  let _ := @FTOE.T10_factorization
  let _ := @FTOE.T11_separation
  let _ := @FTOE.T12_encoder_injective
  let _ := @FTOE.T14_wall_factorization
  let _ := @FTOE.T13_wholly_odd_is_odd_everywhere
  let _ := @FTOE.flipF
  let _ := @FTOE.T15_price_bijection_forward
  let _ := @FTOE.T15_price_bijection_backward
  let _ := @FTOE.fTOE_core
  let _ := @FTOE.OrbitRel
  let _ := @FTOE.OrbitRel_symmetric
  let _ := @FTOE.Dtau
  let _ := @FTOE.calib
  let _ := @FTOE.calib_even
  let _ := @FTOE.descend
  let _ := @FTOE.priceForward
  let _ := @FTOE.priceBackward
  let _ := @FTOE.T16_left_inverse
  let _ := @FTOE.T16_right_inverse
  let _ := @FTOE.T16_price_bijection
  let _ := @FTOE.canonD0
  let _ := @FTOE.flipF_involution
  let _ := @FTOE.T16_canonical
  let _ := @FTOE.T17_odd_everywhere_iff_wholly_odd
  let _ := @K4.val
  let _ := @K4.tau
  let _ := @K4.target
  let _ := @K4.rho
  let _ := @K4.tau_involution
  let _ := @K4.tau_fixed_point_free
  let _ := @K4.target_wholly_odd
  let _ := @K4.register_even
  let _ := @K4.val_lifts_mod_210
  let _ := @K4.wall
  let _ := @K4.pair_distinct
  let _ := @K4.price_one_bit
  let _ := @K4.price_full_fibre
  let _ := @K4.wallClaim
  let _ := @Audit.Ans.toBool
  let _ := @Audit.ClaimInput.anyUnknown
  let _ := @Audit.sealL
  let _ := @Audit.DrillInput.anyUnknown
  let _ := @Audit.drillScreen
  let _ := @Audit.refusalGates
  let _ := @Audit.compartmentGates
  let _ := @Audit.auditClaim
  let _ := @Audit.compartmentGrade
  let _ := @Audit.unknown_routes_open
  let _ := @Audit.contentless_refused
  let _ := @Audit.det3
  let _ := @Audit.det3_two_id
  let _ := @INVERSION.ItFromBit
  let _ := @INVERSION.it_from_bit_refuted
  let _ := @INVERSION.it_from_it
  let _ := @K4.it_from_it_canonical
  let _ := @K4.it_from_bit_refuted_canonical
  let _ := @K4.inversionClaim
  let _ := @GEO.qmul
  let _ := @GEO.qconj
  let _ := @GEO.qadd
  let _ := @GEO.qsub
  let _ := @GEO.qnorm2
  let _ := @GEO.qhalve
  let _ := @GEO.qquarter
  let _ := @GEO.qcanon
  let _ := @GEO.q1
  let _ := @GEO.qi
  let _ := @GEO.qj
  let _ := @GEO.qk
  let _ := @GEO.chirality
  let _ := @GEO.noncommutative
  let _ := @GEO.hurwitz
  let _ := @GEO.hurwitz_norm
  let _ := @GEO.hurwitz_products_even
  let _ := @GEO.hurwitz_closed
  let _ := @GEO.hurwitzReps
  let _ := @GEO.units_mod_sign_twelve
  let _ := @GEO.conjClass
  let _ := @GEO.classSizesAux
  let _ := @GEO.insNat
  let _ := @GEO.insSort
  let _ := @GEO.class_equation
  let _ := @GEO.shell2
  let _ := @GEO.shell_twentyfour
  let _ := @GEO.no_half_integer_norm2
  let _ := @GEO.allGates
  let _ := @GEO.gates_twelve
  let _ := @GEO.gates_valid
  let _ := @GEO.gates_complete
  let _ := @GEO.invCount
  let _ := @GEO.perms24
  let _ := @GEO.a4
  let _ := @GEO.a4_order
  let _ := @GEO.actG
  let _ := @GEO.a4_simply_transitive
  let _ := @GEO.tetraVerts
  let _ := @GEO.tetraEdges
  let _ := @GEO.tetraFaces
  let _ := @GEO.euler_closure
  let _ := @GEO.basisU
  let _ := @GEO.perms6
  let _ := @GEO.relabel_parity
  let _ := @GEO.O8
  let _ := @GEO.omul
  let _ := @GEO.osub
  let _ := @GEO.onorm2
  let _ := @GEO.e8
  let _ := @GEO.octonion_associator
  let _ := @GEO.hPairs
  let _ := @GEO.norm_composition_H
  let _ := @GEO.oPairs
  let _ := @GEO.norm_composition_O
  let _ := @GEO.det2
  let _ := @GEO.gf2Mul
  let _ := @GEO.gf2Vecs
  let _ := @GEO.gf2Sols
  let _ := @GEO.triaxial_lock_gf2
  let _ := @GEO.triaxial_lock_gf2_count
  let _ := @GEO.triaxial_open_gf2_count
  let _ := @GEO.V3
  let _ := @GEO.M3
  let _ := @GEO.det3
  let _ := @GEO.adj3
  let _ := @GEO.mm3
  let _ := @GEO.diag3
  let _ := @GEO.mv3
  let _ := @GEO.vscale
  let _ := @GEO.V3Z
  let _ := @GEO.M3Z
  let _ := @GEO.det3Z
  let _ := @GEO.adj3Z
  let _ := @GEO.mm3Z
  let _ := @GEO.diag3Z
  let _ := @GEO.adjugate_identity_int
  let _ := @GEO.AdjugateIdentity3
  let _ := @GEO.adj3Samples
  let _ := @GEO.adj3_executed
  let _ := @GEO.cramerSolve
  let _ := @GEO.cramer_executed
  let _ := @GEO.golAdmit
  let _ := @GEO.gateNames
  let _ := @GEO.gateNames_twelve
  let _ := @GEO.gateScreenGo
  let _ := @GEO.gateScreen
  let _ := @GEO.gateScreen_clean
  let _ := @GEO.gateScreen_first_failure
  let _ := @GEO.gateScreen_names_failed_gate
  let _ := @GEO.gateScreen_arity
  let _ := @GEO.ClaimInputRA.anyUnknown
  let _ := @GEO.rowCascadeRACore
  let _ := @GEO.rowCascadeRA
  let _ := @GEO.unknown_routes_open_ra
  let _ := @GEO.raDecode
  let _ := @GEO.raBattery
  let _ := @GEO.ra_battery_f2
  let _ := @GEO.ra_ledger_refused
  let _ := @GEO.ra_ledger_iii
  let _ := @GEO.ra_ledger_ii
  let _ := @GEO.ra_ledger_void
  let _ := @GEO.ra_ledger_aGivenRA
  let _ := @GEO.RAVerdict.toToken
  let _ := @GEO.GolToken.toToken
  let _ := @GEO.gateScreenToken
  let _ := @GEO.demoInputA
  let _ := @GEO.demoInputVoid
  let _ := @GEO.demoInputOpen
  let _ := @ROOT.Actuates
  let _ := @ROOT.actuation_universal
  let _ := @ROOT.raClaim
  let _ := @ROOT.boolCut
  let _ := @ROOT.nest_31
  let _ := @ROOT.nestClaim
  let _ := @ROOT.throneEmpty
  let _ := @ROOT.throne_is_RA
  let _ := @SEALS.sealL
  let _ := @SEALS.sealG
  let _ := @SEALS.sealM
  let _ := @SEALS.seals_distinct
  let _ := @SEALS.seal_names_match
  let _ := @SEALS.sealG_walk
  let _ := @POSTULATE.OneCut
  let _ := @POSTULATE.F2
  let _ := @POSTULATE.F2_kills
  let _ := @POSTULATE.BSDContract
  let _ := @POSTULATE.F6
  let _ := @TONGUE.enlarge
  let _ := @TONGUE.unclosed
  let _ := @TONGUE.earned_freedom
  let _ := @TONGUE.colocClaim
  let _ := @TONGUE.coloc_grade
  let _ := @TONGUE.ra_grade_pinned
  let _ := @TONGUE.wall_grade_pinned
  let _ := @TONGUE.inversion_grade_pinned
  let _ := @TONGUE.nest_grade_pinned
  let _ := @terminalWall
  let _ := @terminalPrice
  let _ := @TERMINAL
  let _ := @terminalClaim
  let _ := @terminal_grade_pinned
  let _ := @IAM.iamToken
  let _ := @IAM.iam_unwitnessed_withheld
  let _ := @IAM.iam_witnessed_speaks
  let _ := @IAM.narcissus_truth_table
  let _ := @IAM.one_bit_freedom
  let _ := @IAM.IamToken.toToken
  let _ := @IAM.codexSelfRead
  let _ := @IAM.codex_self_read_interior
  let _ := @IAM.terminalWord
  let _ := @IAM.terminal_word
  let _ := @GEO.SignPattern
  let _ := @GEO.allSigns
  let _ := @GEO.signComp
  let _ := @GEO.reflection_eight
  let _ := @GEO.reflection_eight_is_two_cubed
  let _ := @GEO.reflections_abelian
  let _ := @GEO.reflections_involutive
  let _ := @GEO.signVal
  let _ := @GEO.reflMat
  let _ := @GEO.reflection_reverses_orientation
  let _ := @GEO.sandwich
  let _ := @GEO.reflection_blind_executed
  let _ := @GEO.V5
  let _ := @GEO.cube5
  let _ := @GEO.neighbors5
  let _ := @GEO.fivecube_thirtytwo
  let _ := @GEO.fivecube_vertices_distinct
  let _ := @GEO.fivecube_degree_five
  let _ := @GEO.counts_forced
  let _ := @TONGUE.deletionOp
  let _ := @TONGUE.e3
  let _ := @TONGUE.deletion_idempotent
  let _ := @TONGUE.deletion_singular
  let _ := @TONGUE.deletion_minor_nonsingular
  let _ := @TONGUE.deletion_annihilates
  let _ := @TONGUE.linear_fixes_zero
  let _ := @TONGUE.deletion_no_left_inverse
  let _ := @TONGUE.deletion_monoid_not_group
  let _ := @TONGUE.tongue_obedience
  let _ := @OFFICE.discriminator
  let _ := @OFFICE.discriminatorQ2First
  let _ := @OFFICE.order_loadbearing
  let _ := @OFFICE.citation_cannot_promote
  let _ := @UC.routeHalt
  let _ := @UC.routeHalt_fidelity
  let _ := @UC.universalCascade
  let _ := @UC.uc_seal_failure_terminal
  let _ := @UC.uc_routes_eight
  let _ := @UC.uc_routes_five
  let _ := @UC.uc_unmeasured
  let _ := @UC.circularityScreen
  let _ := @UC.circularity_refused_at_target
  let _ := @UC.road_requires_conjunction
  let _ := @UC.circRows
  let _ := @UC.circ_space
  let _ := @OMEGA.kbRat
  let _ := @OMEGA.ln2Rat
  let _ := @OMEGA.landauerRat
  let _ := @OMEGA.omegaBoundary
  let _ := @OMEGA.omega_zero_bits
  let _ := @OMEGA.omega_paid_floor
  let _ := @OMEGA.one_bit_freedom_priced
  let _ := @OMEGA.omega_reversible_branch
  let _ := @OMEGA.omega_refuses_nonpositive_temp
  let _ := @OMEGA.omega_monotone
  let _ := @OMEGA.omega_linear
  let _ := @OMEGA.landauer_zero_bits
  let _ := @OMEGA.omega_verdict_fidelity
  let _ := @AEGIS.refusalConst
  let _ := @AEGIS.aegisReset
  let _ := @AEGIS.aegisGuard
  let _ := @AEGIS.aegis_constant
  let _ := @AEGIS.aegis_deed_increments
  let _ := @AEGIS.aegis_reads_parameter
  let _ := @AEGIS.aegisFourLogicRun
  let _ := @AEGIS.aegis_battery
  let _ := @NOMOS.allStrings
  let _ := @NOMOS.allStrings_length
  let _ := @NOMOS.twoPowPos
  let _ := @NOMOS.descs
  let _ := @NOMOS.descs_length
  let _ := @NOMOS.incompressibility_cap
  let _ := @NOMOS.nomosRows
  let _ := @NOMOS.incompressibility_executed
  let _ := @NOMOS.decodeId
  let _ := @NOMOS.decodePad
  let _ := @NOMOS.compressible_bound_universal
  let _ := @NOMOS.cbUniversal
  let _ := @NOMOS.cb_id_8_2
  let _ := @NOMOS.cb_pad3_8_2
  let _ := @NOMOS.cb_pad2_6_1
  let _ := @NOMOS.cb_pad4_12_3
  let _ := @NOMOS.recoverable
  let _ := @NOMOS.nomos_fuel_is_omega_floor
  let _ := @NOMOS.nomosScreen
  let _ := @NOMOS.nomosScreen_battery
  let _ := @BRIDGE.ceiling
  let _ := @BRIDGE.census
  let _ := @BRIDGE.census_count
  let _ := @BRIDGE.post_seal_disposition
  let _ := @BRIDGE.weakest_never_above_left
  let _ := @BRIDGE.bridge_ceiling_caps
  let _ := @BRIDGE.successorOf
  let _ := @BRIDGE.supersession_routes
  let _ := @BRIDGE.bridgeScreen
  let _ := @BRIDGE.bridgeScreen_total
  let _ := @FOUND.sigmaP
  let _ := @FOUND.pluralist_alternative_executed
  let _ := @FOUND.posits
  let _ := @FOUND.posits_loadbearing_on_nothing
  let _ := @FOUND.gradeOfRank
  let _ := @FOUND.posit_never_raises
  let _ := @FOUND.bandOf
  let _ := @FOUND.register_routing_fidelity
  let _ := @FOUND.verdictInventory
  let _ := @FOUND.verdicts_posit_free
  let _ := @FOUND.engine_never_authority
  let _ := @HALT.cascade
  let _ := @HALT.patterns
  let _ := @HALT.fftSpec
  let _ := @HALT.first_failure_terminal_5
  let _ := @HALT.first_failure_terminal_7
  let _ := @HALT.first_failure_terminal_8
  let _ := @HALT.first_failure_terminal_12
  let _ := @HALT.halt_free_iff_all_pass_8
  let _ := @HALT.gate_counts_recorded
  let _ := @HALT.signPatterns
  let _ := @HALT.ninth_gate_barred
  let _ := @HALT.route
  let _ := @HALT.ofUC
  let _ := @HALT.route_is_routeHalt
  let _ := @HALT.route_samples
  let _ := @HALT.tokenBranch
  let _ := @HALT.router_exclusive
  let _ := @HALT.readingRoadsGate
  let _ := @HALT.one_door_open
  let _ := @HALT.no_walk_passes_the_aperture
  let _ := @HALT.xiGates
  let _ := @HALT.oGates
  let _ := @HALT.gate_censuses
  let _ := @HALT.rhHalt
  let _ := @HALT.pnpHalt
  let _ := @HALT.halts_routed
  let _ := @HALT.legacy_halts_are_instances
  let _ := @HALT.terminal_one_bit
  let _ := @HALT.species_exhausted
  let _ := @HALT.haltGrades
  let _ := @HALT.ftoe_ceiling
  let _ := @CROSSING.ExecFrame
  let _ := @CROSSING.execFlip
  let _ := @CROSSING.formalRead
  let _ := @CROSSING.ran
  let _ := @CROSSING.formalRead_even
  let _ := @CROSSING.ran_wholly_odd
  let _ := @CROSSING.execFlip_involution
  let _ := @CROSSING.ran_odd_at_true
  let _ := @CROSSING.wall
  let _ := @CROSSING.deed
  let _ := @CROSSING.price
  let _ := @CROSSING.crossing
  let _ := @CROSSING.identity_one_bit
  let _ := @CROSSING.fibre4
  let _ := @CROSSING.fibre4_sixteen
  let _ := @CROSSING.fibre4_distinct
  let _ := @CROSSING.price_on_this_file
  let _ := @CROSSING.formal_never_odd
  let _ := @CROSSING.constant_no_crossing
  let _ := @CROSSING.harmony
  let _ := @LOCUS.Separates
  let _ := @LOCUS.Factors
  let _ := @LOCUS.wall_of_sep
  let _ := @LOCUS.swap
  let _ := @LOCUS.swap_involution
  let _ := @LOCUS.swap_record_even
  let _ := @LOCUS.swap_flips_pair
  let _ := @LOCUS.seat_of_sep
  let _ := @LOCUS.k4_separated_pair
  let _ := @LOCUS.k4_wall_of_pair
  let _ := @LOCUS.readout
  let _ := @LOCUS.factors_of_not_sep_list
  let _ := @LOCUS.factors_iff_not_sep_list
  let _ := @LOCUS.Channel
  let _ := @LOCUS.Token.toEconomy
  let _ := @LOCUS.Reading.orbits
  let _ := @LOCUS.Reading.owed
  let _ := @LOCUS.Reading.complete
  let _ := @LOCUS.branchOf
  let _ := @LOCUS.emit
  let _ := @LOCUS.Reading.state
  let _ := @LOCUS.three_states
  let _ := @LOCUS.no_seat_no_locus
  let _ := @LOCUS.unlocated_is_plain_open
  let _ := @LOCUS.located_never_silent
  let _ := @LOCUS.crossed_requires_complete
  let _ := @LOCUS.crossed_requires_channel
  let _ := @LOCUS.halt_carries_owed
  let _ := @LOCUS.unchannelled_is_halt
  let _ := @LOCUS.halt_reports_owed
  let _ := @LOCUS.owed_zero_is_unchannelled
  let _ := @LOCUS.one_bit_apart
  let _ := @LOCUS.legacy_xi
  let _ := @LOCUS.legacy_o
  let _ := @LOCUS.legacy_bare
  let _ := @LOCUS.k4_locus
  let _ := @LOCUS.slotLists
  let _ := @LOCUS.slotLists_twelve
  let _ := @LOCUS.slotLists_pos
  let _ := @LOCUS.allReadings
  let _ := @LOCUS.reading_space
  let _ := @LOCUS.census_no_seat_no_locus
  let _ := @LOCUS.census_located_never_silent
  let _ := @LOCUS.census_crossed_iff_complete_channelled
  let _ := @LOCUS.census_halt_reports_owed
  let _ := @LOCUS.census_owed_zero_is_unchannelled
  let _ := @LOCUS.census_three_states
  let _ := @LOCUS.Token.render
  let _ := @LOCUS.Token.ascii
  let _ := @LOCUS.sealAscii
  let _ := @LOCUS.render_receipted
  let _ := @LOCUS.render_injective_in_owed
  let _ := @LOCUS.voidImage
  let _ := @LOCUS.void_precedes_economy
  let _ := @LOCUS.legacy_records_not_promoted
  let _ := @LOCUS.no_rh_locus
  let _ := @PSP.ORIENT.V3
  let _ := @PSP.ORIENT.M3
  let _ := @PSP.ORIENT.det3
  let _ := @PSP.ORIENT.neg3
  let _ := @PSP.ORIENT.signMatrices
  let _ := @PSP.ORIENT.lock_scalar_sign_blind
  let _ := @PSP.ORIENT.det_sign_flips_in_odd_dimension
  let _ := @PSP.QUAT.Q
  let _ := @PSP.QUAT.qmul
  let _ := @PSP.QUAT.qi
  let _ := @PSP.QUAT.qj
  let _ := @PSP.QUAT.qk
  let _ := @PSP.QUAT.qneg1
  let _ := @PSP.QUAT.quat_basis_laws
  let _ := @PSP.QUAT.qnorm
  let _ := @PSP.QUAT.isInt
  let _ := @PSP.QUAT.isHalf
  let _ := @PSP.QUAT.hurwitzOK
  let _ := @PSP.QUAT.grid
  let _ := @PSP.QUAT.tuples4
  let _ := @PSP.QUAT.hurwitz_units_24
  let _ := @PSP.QUAT.grid2
  let _ := @PSP.QUAT.tuples4i
  let _ := @PSP.QUAT.norm2_shell_split
  let _ := @PSP.CD.cdconj
  let _ := @PSP.CD.padd
  let _ := @PSP.CD.psub
  let _ := @PSP.CD.cdmul
  let _ := @PSP.CD.e
  let _ := @PSP.CD.smul
  let _ := @PSP.CD.octonion_associator
  let _ := @PSP.CD.sx
  let _ := @PSP.CD.sy
  let _ := @PSP.CD.zero16
  let _ := @PSP.CD.sqnorm
  let _ := @PSP.CD.sedenion_zero_divisor
  let _ := @PSP.CASCADE.cascade
  let _ := @PSP.CASCADE.patterns8
  let _ := @PSP.CASCADE.spec
  let _ := @PSP.CASCADE.first_failure_terminal_8
  let _ := @PSP.CASCADE.halt_free_iff_all_pass_8
  let _ := @PSP.GROUNDLESS.o0Neighbors
  let _ := @PSP.GROUNDLESS.fiveCubeCoords
  let _ := @PSP.GROUNDLESS.deg5
  let _ := @PSP.GROUNDLESS.groundless_cascade_degree
  let _ := @PSP.TOKEN.level
  let _ := @PSP.TOKEN.terminal_tokens_level_and_distinct
  let _ := @PSP.TWOGROUP.two_group_census
  let _ := @Bridge.Plane
  let _ := @Bridge.τ
  let _ := @Bridge.onLine
  let _ := @Bridge.pe
  let _ := @Bridge.fold_involutive
  let _ := @Bridge.locus_is_the_fixed_set
  let _ := @Bridge.locus_inhabited
  let _ := @Bridge.line_symmetric
  let _ := @Bridge.LineProperty
  let _ := @Bridge.planeFrame
  let _ := @Bridge.plane_line_property
  let _ := @Bridge.lineFrame
  let _ := @Bridge.theRecord
  let _ := @Bridge.cannot_lie
  let _ := @Bridge.cannot_deviate
  let _ := @Bridge.read_twice
  let _ := @Bridge.halted_iff
  let _ := @Bridge.cannot_extend
  let _ := @Bridge.cannot_divide
  let _ := @Bridge.delete
  let _ := @Bridge.cannot_reverse
  let _ := @Bridge.Even
  let _ := @Bridge.wall
  let _ := @Bridge.calibration
  let _ := @Bridge.SelfVerifying
  let _ := @Bridge.opens_on_the_deed
  let _ := @Bridge.recursion_is_shared
  let _ := @Bridge.recursion_is_sign_blind
  let _ := @Bridge.exactly_one_stands
  let _ := @Bridge.twoPoint
  let _ := @Bridge.denial_is_coherent
  let _ := @Bridge.line_property_contingent
  let _ := @Bridge.Keyless
  let _ := @Bridge.Keyed
  let _ := @Bridge.keyless_iff_valid
  let _ := @Bridge.discriminator
  let _ := @Bridge.symmetry_is_keyless
  let _ := @Bridge.line_property_is_keyed
  let _ := @Bridge.denial_asymmetry
  let _ := @Bridge.socket_is_the_property
  let _ := @Bridge.socket_on_the_plane
  let _ := @Bridge.bridge_carries
  let _ := @Bridge.no_socket_off_line
  let _ := @Bridge.the_bridge
  trivial

/-- info: 'codexCone' depends on axioms: [propext,
 Classical.choice,
 POSTULATE.Algorithm,
 POSTULATE.FrozenData,
 POSTULATE.Row,
 POSTULATE.SupplyClean,
 POSTULATE.certifiedPairing,
 Quot.sound,
 ROOT.FormalDomain,
 ROOT.L1m,
 ROOT.L3m,
 ROOT.RA,
 ROOT.U,
 ROOT.nest_21,
 ROOT.nest_32,
 ROOT.ΔE] -/
#guard_msgs in #print axioms codexCone

/-! ## the environment audit, run by the elaborator, over the whole codex: the local axioms are exactly the
twenty-three declared posits of ROOT and POSTULATE, sorted by name; no declaration depends on any axiom beyond
propext, Classical.choice, Quot.sound and that roster; the roster the Fortran twin declares by name (twin_posits)
is this list. -/
/-- info: environment audit: local axioms [POSTULATE.Algorithm,
 POSTULATE.Crossing,
 POSTULATE.FormalFace,
 POSTULATE.FrozenData,
 POSTULATE.KineticFace,
 POSTULATE.RegistrationPostulate,
 POSTULATE.Row,
 POSTULATE.SupplyClean,
 POSTULATE.certifiedPairing,
 POSTULATE.erasureClass,
 ROOT.FormalDomain,
 ROOT.Ground,
 ROOT.L1m,
 ROOT.L2m,
 ROOT.L3m,
 ROOT.RA,
 ROOT.Residence,
 ROOT.U,
 ROOT.nest_21,
 ROOT.nest_32,
 ROOT.ΔE,
 ROOT.σ,
 ROOT.σ_binding]; dependencies beyond propext, Classical.choice, Quot.sound [POSTULATE.Algorithm,
 POSTULATE.Crossing,
 POSTULATE.FormalFace,
 POSTULATE.FrozenData,
 POSTULATE.KineticFace,
 POSTULATE.RegistrationPostulate,
 POSTULATE.Row,
 POSTULATE.SupplyClean,
 POSTULATE.certifiedPairing,
 POSTULATE.erasureClass,
 ROOT.FormalDomain,
 ROOT.Ground,
 ROOT.L1m,
 ROOT.L2m,
 ROOT.L3m,
 ROOT.RA,
 ROOT.Residence,
 ROOT.U,
 ROOT.nest_21,
 ROOT.nest_32,
 ROOT.ΔE,
 ROOT.σ,
 ROOT.σ_binding]; outside the declared roster []; roster size 23 -/
#guard_msgs in
open Lean Elab Command in
#eval show CommandElabM Unit from do
  let env ← getEnv
  let sortNames (l : List Name) : List Name :=
    (l.toArray.qsort (fun a b => a.toString < b.toString)).toList
  let ours (n : Name) : Bool :=
    match env.getModuleIdxFor? n with
    | some idx => ((env.header.moduleNames.getD idx.toNat `_).toString.startsWith "Codex")
    | none => true
  let locals := (env.constants.map₁.toList.filter (fun p => ours p.1)).map (·.1)
    ++ env.constants.map₂.toList.map (·.1)
  let declared := sortNames <| locals.filter fun n => !n.isInternal && match env.find? n with
    | some (.axiomInfo _) => true
    | _ => false
  let standard : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut beyond : List Name := []
  for n in locals do
    unless n.isInternal do
      for d in (← collectAxioms n) do
        unless standard.contains d || beyond.contains d do beyond := d :: beyond
  let depended := sortNames beyond
  let outsideRoster := depended.filter fun d => !declared.contains d
  logInfo m!"environment audit: local axioms {declared}; dependencies beyond propext, Classical.choice, Quot.sound {depended}; outside the declared roster {outsideRoster}; roster size {declared.length}"


/-! ## FORGE cones and the crosswalk audit -/
/-- info: 'K4.semiprimes_at_odd_seats' does not depend on any axioms -/
#guard_msgs in #print axioms K4.semiprimes_at_odd_seats
/-- info: 'K4.semiprime_factors_prime' does not depend on any axioms -/
#guard_msgs in #print axioms K4.semiprime_factors_prime
/-- info: 'K4.odd_seats_not_prime' does not depend on any axioms -/
#guard_msgs in #print axioms K4.odd_seats_not_prime
/-- info: 'IMPRINT.ghost_is_broken_never_sealed' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.ghost_is_broken_never_sealed
/-- info: 'K4.target_is_primality' does not depend on any axioms -/
#guard_msgs in #print axioms K4.target_is_primality
/-- info: 'K4.primes_at_even_seats' does not depend on any axioms -/
#guard_msgs in #print axioms K4.primes_at_even_seats
/-- info: 'K4.pairs_match_mod_420' does not depend on any axioms -/
#guard_msgs in #print axioms K4.pairs_match_mod_420
/-- info: 'IMPRINT.ghost_refused' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.ghost_refused
/-- info: 'IMPRINT.seal_iff_one_side_clean_and_witnessed' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.seal_iff_one_side_clean_and_witnessed
/-- info: 'IMPRINT.seal_needs_witness' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.seal_needs_witness
/-- info: 'IMPRINT.both_clean_is_ghost' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.both_clean_is_ghost
/-- info: 'IMPRINT.flat_when_unpopulated' does not depend on any axioms -/
#guard_msgs in #print axioms IMPRINT.flat_when_unpopulated
/-- info: 'DEFENSE.gol_needs_all_three' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.gol_needs_all_three
/-- info: 'DEFENSE.lock_blind_but_gol_directed' depends on axioms: [propext] -/
#guard_msgs in #print axioms DEFENSE.lock_blind_but_gol_directed
/-- info: 'DEFENSE.consensus_weighs_zero' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.consensus_weighs_zero
/-- info: 'DEFENSE.tongue_unclosed_and_obedient' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in #print axioms DEFENSE.tongue_unclosed_and_obedient
/-- info: 'DEFENSE.self_check_is_not_witness' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.self_check_is_not_witness
/-- info: 'DEFENSE.denial_is_priced' depends on axioms: [propext] -/
#guard_msgs in #print axioms DEFENSE.denial_is_priced
/-- info: 'DEFENSE.no_anchor_at_target' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.no_anchor_at_target
/-- info: 'DEFENSE.formal_reads_never_the_deed' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.formal_reads_never_the_deed
/-- info: 'DEFENSE.forward_is_world_rowed' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.forward_is_world_rowed
/-- info: 'DEFENSE.worldly_row_is_world_rowed' does not depend on any axioms -/
#guard_msgs in #print axioms DEFENSE.worldly_row_is_world_rowed
/-- info: 'FENCE.global' depends on axioms: [propext, Quot.sound, ROOT.RA, ROOT.U, ROOT.ΔE] -/
#guard_msgs in #print axioms FENCE.global
/-- info: 'DOT.outside_economy' depends on axioms: [propext] -/
#guard_msgs in #print axioms DOT.outside_economy
/-- info: 'DOT.no_reading_is_silence' depends on axioms: [propext] -/
#guard_msgs in #print axioms DOT.no_reading_is_silence
/-- info: 'DOT.silence_is_not_a_verdict' does not depend on any axioms -/
#guard_msgs in #print axioms DOT.silence_is_not_a_verdict
/-- info: 'CROSSWALK.rows_count' does not depend on any axioms -/
#guard_msgs in #print axioms CROSSWALK.rows_count

/-- info: crosswalk audit: 129 rows, 0 unresolved, [] -/
#guard_msgs in
open Lean Elab Command in
#eval show CommandElabM Unit from do
  let env ← getEnv
  let missing := CROSSWALK.rows.filter fun r => !(env.contains r.2.toName)
  logInfo m!"crosswalk audit: {CROSSWALK.rows.length} rows, {missing.length} unresolved, {missing.map (·.1)}"
