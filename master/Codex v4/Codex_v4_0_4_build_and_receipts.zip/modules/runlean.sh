#!/bin/bash
export PATH=/tmp/forge/lean4/lean-4.19.0-linux/bin:$PATH
export LEAN_PATH=/tmp/forge/build
cd /tmp/forge
for n in "$@"; do
  s=$(date +%s)
  lean Codex$n.lean -o build/Codex$n.olean > c$n.out 2>&1
  echo "exit $? seconds $(( $(date +%s) - s ))" >> c$n.out
done
