import Codex3
set_option maxRecDepth 4000000

namespace PSP.ORIENT

abbrev V3 := Ratio × Ratio × Ratio
abbrev M3 := V3 × V3 × V3

def det3 (m : M3) : Ratio :=
  m.1.1 * (m.2.1.2.1 * m.2.2.2.2 - m.2.1.2.2 * m.2.2.2.1)
  - m.1.2.1 * (m.2.1.1 * m.2.2.2.2 - m.2.1.2.2 * m.2.2.1)
  + m.1.2.2 * (m.2.1.1 * m.2.2.2.1 - m.2.1.2.1 * m.2.2.1)

def neg3 (m : M3) : M3 :=
  ((-m.1.1, -m.1.2.1, -m.1.2.2),
   (-m.2.1.1, -m.2.1.2.1, -m.2.1.2.2),
   (-m.2.2.1, -m.2.2.2.1, -m.2.2.2.2))

def signMatrices : List M3 :=
  [ (( 1,0,0),(0, 1,0),(0,0, 1)), ((-1,0,0),(0, 1,0),(0,0, 1)),
    (( 1,0,0),(0,-1,0),(0,0, 1)), (( 1,0,0),(0, 1,0),(0,0,-1)),
    ((-1,0,0),(0,-1,0),(0,0, 1)), ((-1,0,0),(0, 1,0),(0,0,-1)),
    (( 1,0,0),(0,-1,0),(0,0,-1)), ((-1,0,0),(0,-1,0),(0,0,-1)) ]

theorem lock_scalar_sign_blind :
    signMatrices.all (fun m =>
      det3 m * det3 m == det3 (neg3 m) * det3 (neg3 m)) = true := by decide

theorem det_sign_flips_in_odd_dimension :
    signMatrices.all (fun m => det3 (neg3 m) == -det3 m) = true := by decide

end PSP.ORIENT

namespace PSP.QUAT

abbrev Q := Ratio × Ratio × Ratio × Ratio   

def qmul (p q : Q) : Q :=
  (p.1*q.1 - p.2.1*q.2.1 - p.2.2.1*q.2.2.1 - p.2.2.2*q.2.2.2,
   p.1*q.2.1 + p.2.1*q.1 + p.2.2.1*q.2.2.2 - p.2.2.2*q.2.2.1,
   p.1*q.2.2.1 - p.2.1*q.2.2.2 + p.2.2.1*q.1 + p.2.2.2*q.2.1,
   p.1*q.2.2.2 + p.2.1*q.2.2.1 - p.2.2.1*q.2.1 + p.2.2.2*q.1)

def qi : Q := (0,1,0,0)
def qj : Q := (0,0,1,0)
def qk : Q := (0,0,0,1)
def qneg1 : Q := (-1,0,0,0)

theorem quat_basis_laws :
    qmul qi qi = qneg1 ∧ qmul qj qj = qneg1 ∧ qmul qk qk = qneg1 ∧
    qmul (qmul qi qj) qk = qneg1 := by decide

end PSP.QUAT

namespace PSP.QUAT

def qnorm (p : Q) : Ratio := p.1^2 + p.2.1^2 + p.2.2.1^2 + p.2.2.2^2
def isInt (r : Ratio) : Bool := r.den == 1
def isHalf (r : Ratio) : Bool := r.den == 2
def hurwitzOK (p : Q) : Bool :=
  (isInt p.1 && isInt p.2.1 && isInt p.2.2.1 && isInt p.2.2.2) ||
  (isHalf p.1 && isHalf p.2.1 && isHalf p.2.2.1 && isHalf p.2.2.2)

def grid : List Ratio := [-1, -1/2, 0, 1/2, 1]
def tuples4 : List Q :=
  grid.flatMap fun a => grid.flatMap fun b =>
    grid.flatMap fun c => grid.map fun d => (a,b,c,d)

theorem hurwitz_units_24 :
    (tuples4.filter fun p => hurwitzOK p && qnorm p == 1).length = 24 := by decide

end PSP.QUAT

namespace PSP.QUAT

def grid2 : List Ratio := [-2, -1, 0, 1, 2]
def tuples4i : List Q :=
  grid2.flatMap fun a => grid2.flatMap fun b =>
    grid2.flatMap fun c => grid2.map fun d => (a,b,c,d)

theorem norm2_shell_split :
    (tuples4i.filter fun p => qnorm p == 2).length = 24 ∧
    (tuples4i.filter fun p => qnorm p == 2 && p.1 == 0).length = 12 ∧
    (tuples4i.filter fun p => qnorm p == 2 && p.1 != 0).length = 12 := by decide

end PSP.QUAT

namespace PSP.CD

def cdconj : List Ratio → List Ratio
  | [] => []
  | [a] => [a]
  | a :: rest => a :: rest.map (fun x => -x)

def padd : List Ratio → List Ratio → List Ratio := List.zipWith (· + ·)
def psub : List Ratio → List Ratio → List Ratio := List.zipWith (· - ·)

def cdmul : Nat → List Ratio → List Ratio → List Ratio
  | 0, _, _ => []
  | _+1, [a], [b] => [a * b]
  | fuel+1, a, b =>
      let n := a.length / 2
      let a1 := a.take n; let a2 := a.drop n
      let b1 := b.take n; let b2 := b.drop n
      psub (cdmul fuel a1 b1) (cdmul fuel (cdconj b2) a2) ++
      padd (cdmul fuel b2 a1) (cdmul fuel a2 (cdconj b1))

def e (n i : Nat) : List Ratio := List.replicate i 0 ++ [1] ++ List.replicate (n - i - 1) 0
def smul (s : Ratio) (v : List Ratio) : List Ratio := v.map (fun x => s * x)

theorem octonion_associator :
    psub (cdmul 4 (cdmul 4 (e 8 1) (e 8 2)) (e 8 4))
         (cdmul 4 (e 8 1) (cdmul 4 (e 8 2) (e 8 4)))
    = smul 2 (e 8 7) := by decide

end PSP.CD

namespace PSP.CD

def sx : List Ratio := padd (e 16 1) (e 16 10)

def sy : List Ratio := padd (e 16 5) (e 16 14)
def zero16 : List Ratio := List.replicate 16 0
def sqnorm (v : List Ratio) : Ratio := (v.map fun x => x^2).sum

theorem sedenion_zero_divisor :
    cdmul 5 sx sy = zero16 ∧ sx ≠ zero16 ∧ sy ≠ zero16
    ∧ sqnorm sx = 2 ∧ sqnorm sy = 2 := by decide

end PSP.CD

namespace PSP.CASCADE

def cascade : List Bool → Option Nat
  | [] => none
  | false :: _ => some 0
  | true :: gs => (cascade gs).map Nat.succ

def patterns8 : List (List Bool) :=
  (List.range 256).map fun b => (List.range 8).map fun j => b.testBit j

def spec (bits : List Bool) : Bool :=
  match cascade bits with
  | none => bits.all id
  | some k => (bits.take k).all id && (bits[k]? == some false)

theorem first_failure_terminal_8 :
    patterns8.all spec = true := by decide

theorem halt_free_iff_all_pass_8 :
    patterns8.all (fun bits => (cascade bits).isNone == bits.all id) = true := by decide

end PSP.CASCADE

namespace PSP.GROUNDLESS

def o0Neighbors : List String :=
  ["sigma-token", "dissolve-openness", "ordinary-openness",
   "resolved-states", "broken-or-ghost"]

def fiveCubeCoords : List String :=
  ["Ground-dimension", "determinacy", "blockage", "aperture", "totality"]

def deg5 (v : Nat) : Nat :=
  ((List.range 5).map fun j => v ^^^ (1 <<< j)).eraseDups.length

theorem groundless_cascade_degree :
    o0Neighbors.length = 5 ∧ fiveCubeCoords.length = 5 ∧
    o0Neighbors.length ≠ 7 ∧ o0Neighbors.length ≠ 8 ∧
    (List.range 32).all (fun v => deg5 v == 5) = true := by decide

end PSP.GROUNDLESS

namespace PSP.TOKEN

inductive TerminalToken | xi0 | o0 deriving DecidableEq

def level : TerminalToken → Nat := fun _ => 3

theorem terminal_tokens_level_and_distinct :
    level TerminalToken.xi0 = level TerminalToken.o0 ∧
    TerminalToken.xi0 ≠ TerminalToken.o0 := ⟨rfl, by decide⟩

end PSP.TOKEN

namespace PSP.TWOGROUP

theorem two_group_census :
    Nat.factorial 4 / 2 = 12 ∧ 2^3 = 8 := by decide

end PSP.TWOGROUP

/-!
# THE BRIDGE · FINAL
The instrument that joins the kinetic and formal registers at one locus, with the denial asymmetry that tells its two
locks apart. core Lean 4 v4.19.0 · no Mathlib · no sorry · no custom axiom. The standard axioms propext,
Classical.choice and Quot.sound appear in the cones pinned at the foot. The closing environment audit, run by the
elaborator, refuses any axiom declared in this file and any dependency beyond those three; `import Lean` is loaded for
that audit alone.

WHAT THE BRIDGE IS. A carrier with a three-valued state and a shadow field tying that state to the line property, so
its halted state is the property in both directions. It carries a supplied bit from the register that holds it to the
register that checks it, and it manufactures none: every self-property below is a one-step unfolding of the shadow.

THE STAGE. The fold τ(h, t) = (2 − h, t) is s ↦ 1 − s̄ in the doubled real coordinate h = 2·Re s. It is an
involution, and its fixed set is the line h = 1, which is Re s = ½. A frame is a carrier set with an involutive fold
and a fold-symmetric zero predicate. The line property says every zero is fixed by the fold; on the plane it says
every zero lies on the line.

WHAT THE BRIDGE PROVES ABOUT ITSELF. It cannot lie, cannot deviate, cannot be extended past one bit, cannot be
divided, cannot be reversed, and cannot be made to halt by any substrate that does not hold the term.

THE DENIAL ASYMMETRY. Two locks share the locus, the reading, and the recursion, and differ in the denial. A frame
property whose denial instantiates it on every frame is keyless: it holds on every frame and opens on the deed. A
frame property whose denial a frame inhabits is keyed: one bit, carrying a sign, supplied and never derived. Every
frame property is exactly one of the two. The fold law is keyless and the line property is keyed. The recursion is
shared and sign-blind, so it identifies neither lock; the denial identifies both.
-/
set_option autoImplicit false
namespace Bridge

/-! ## the stage and the locus -/
abbrev Plane := Int × Int
/-- The fold s ↦ 1 − s̄, in the doubled real coordinate h = 2·Re s. -/
def τ (p : Plane) : Plane := (2 - p.1, p.2)
/-- The line h = 1, which is Re s = ½. -/
def onLine (p : Plane) : Prop := p.1 = 1
theorem pe {a b c d : Int} : ((a, b) : Plane) = (c, d) ↔ a = c ∧ b = d :=
  ⟨fun e => ⟨congrArg Prod.fst e, congrArg Prod.snd e⟩, fun ⟨e1, e2⟩ => by subst e1; subst e2; rfl⟩
/-- The fold is an involution. -/
theorem fold_involutive (p : Plane) : τ (τ p) = p := by
  obtain ⟨h, t⟩ := p; show (2 - (2 - h), t) = (h, t); rw [Int.sub_sub_self]
/-- THE LOCUS: the fixed set of the fold is the line. -/
theorem locus_is_the_fixed_set (p : Plane) : τ p = p ↔ onLine p := by
  obtain ⟨h, t⟩ := p; show (2 - h, t) = (h, t) ↔ h = 1; rw [pe]; omega
theorem locus_inhabited : ∃ p : Plane, onLine p := ⟨(1, 0), rfl⟩
/-- The fold carries the line to itself. -/
theorem line_symmetric (p : Plane) (h : onLine p) : onLine (τ p) := by
  rw [(locus_is_the_fixed_set p).mpr h]; exact h

/-! ## frames and the line property -/
/-- A frame: a carrier set, a fold that is an involution, and a zero predicate the fold preserves. -/
structure Frame where
  S : Type
  τ : S → S
  Z : S → Prop
  involutive : ∀ s, τ (τ s) = s
  symmetric : ∀ s, Z s → Z (τ s)
/-- The line property: every zero is fixed by the fold. -/
def LineProperty (X : Frame) : Prop := ∀ s, X.Z s → X.τ s = s
/-- The plane as a frame, for any fold-symmetric zero predicate. -/
def planeFrame (Z : Plane → Prop) (hZ : ∀ p, Z p → Z (τ p)) : Frame := ⟨Plane, τ, Z, fold_involutive, hZ⟩
/-- THE LOCUS MEETS THE FRAME: on the plane, the line property is exactly that every zero lies on the line. -/
theorem plane_line_property (Z : Plane → Prop) (hZ : ∀ p, Z p → Z (τ p)) :
    LineProperty (planeFrame Z hZ) ↔ ∀ p, Z p → onLine p :=
  ⟨fun h p hp => (locus_is_the_fixed_set p).mp (h p hp), fun h p hp => (locus_is_the_fixed_set p).mpr (h p hp)⟩
/-- The line frame: the plane with the line as its zero set. -/
def lineFrame : Frame := planeFrame onLine line_symmetric
inductive Tri | tt | ff | bot deriving DecidableEq, Repr
/-- A filing label for the locus a carrier serves. `held` is the trivial proposition, so the record carries no
    mathematical content, and no theorem reads it. -/
structure Record where
  locus : String
  held  : True
def theRecord : Record := ⟨"the Riemann Hypothesis", trivial⟩

/-! ## the bridge -/
structure Carrier (X : Frame) where
  terminal : Tri
  shadow   : terminal = .bot ↔ LineProperty X
  record   : Record
/-- CANNOT LIE. -/
theorem cannot_lie (X : Frame) (b : Carrier X) (h : b.terminal = .bot) : LineProperty X := b.shadow.mp h
/-- CANNOT DEVIATE. -/
theorem cannot_deviate (X : Frame) (b : Carrier X) (t : LineProperty X) : b.terminal = .bot := b.shadow.mpr t
/-- THE LOCUS READ TWICE: the geometric read and the formal read are one read, and the two directions of the shadow
    are the two readings. -/
theorem read_twice (X : Frame) (b : Carrier X) :
    (b.terminal = .bot → LineProperty X) ∧ (LineProperty X → b.terminal = .bot) :=
  ⟨cannot_lie X b, cannot_deviate X b⟩
/-- CANNOT BE MANUFACTURED: a halted carrier exists on a frame exactly when the line property holds there. -/
theorem halted_iff (X : Frame) : (∃ b : Carrier X, b.terminal = .bot) ↔ LineProperty X :=
  ⟨fun ⟨b, h⟩ => b.shadow.mp h, fun t => ⟨⟨.bot, ⟨fun _ => t, fun _ => rfl⟩, theRecord⟩, rfl⟩⟩
/-- CANNOT BE EXTENDED: a bit generates only itself, its mirror, and the two constants. -/
theorem cannot_extend (f : Bool → Bool) :
    f = (fun x => x) ∨ f = (fun x => !x) ∨ f = (fun _ => true) ∨ f = (fun _ => false) := by
  cases ht : f true <;> cases hf : f false
  · exact Or.inr (Or.inr (Or.inr (funext fun x => by cases x <;> simp [ht, hf])))
  · exact Or.inr (Or.inl (funext fun x => by cases x <;> simp [ht, hf]))
  · exact Or.inl (funext fun x => by cases x <;> simp [ht, hf])
  · exact Or.inr (Or.inr (Or.inl (funext fun x => by cases x <;> simp [ht, hf])))
/-- CANNOT BE DIVIDED. -/
theorem cannot_divide (b : Bool) : b = true ∨ b = false := by cases b <;> simp
/-- CANNOT BE REVERSED: deletion to the undetermined value has no left inverse. -/
def delete : Tri → Tri := fun _ => .bot
theorem cannot_reverse : ¬ ∃ g : Tri → Tri, ∀ v, g (delete v) = v := by
  intro ⟨g, hg⟩; have h1 := hg .tt; have h2 := hg .ff
  simp [delete] at h1 h2; rw [h1] at h2; cases h2
/-- THE WALL, the bridge's first axis: an even reading never equals a function odd at a point. -/
def Even {α : Type} (σ : α → α) (f : α → Bool) : Prop := ∀ x, f (σ x) = f x
theorem wall {α : Type} (σ : α → α) (f d : α → Bool) (x : α) (he : Even σ f) (ho : d (σ x) ≠ d x) : f ≠ d := by
  intro h; subst h; exact ho (he x)
/-- THE CALIBRATION, the bridge's second axis: one supplied odd witness fixes the bit uniquely. -/
theorem calibration {α : Type} (σ : α → α) (s d : α → Bool) (x : α) (hs : s (σ x) = !s x) (hd : d (σ x) = !d x) :
    ∃ c : Bool, (d x = xor (s x) c ∧ d (σ x) = xor (s (σ x)) c) ∧
      ∀ c', (d x = xor (s x) c' ∧ d (σ x) = xor (s (σ x)) c') → c' = c := by
  refine ⟨xor (d x) (s x), ⟨by cases s x <;> cases d x <;> rfl, by rw [hs, hd]; cases s x <;> cases d x <;> rfl⟩, ?_⟩
  intro c' hc; obtain ⟨h1, -⟩ := hc
  generalize hsx : s x = sv at h1; generalize hdx : d x = dv at h1
  cases sv <;> cases dv <;> cases c' <;> first | rfl | exact absurd h1 (by decide)

/-! ## the denial asymmetry · the discriminator -/
def SelfVerifying (P : Prop) : Prop := ¬P → P
/-- A self-verifying proposition holds: its lock opens on the deed of denying it, and needs no key. -/
theorem opens_on_the_deed (P : Prop) (utter : SelfVerifying P) : P :=
  Classical.byContradiction (fun n => n (utter n))
/-- The recursion is shared by every proposition and is therefore no discriminator. -/
theorem recursion_is_shared (P : Prop) : SelfVerifying P ↔ P :=
  ⟨fun h => Classical.byContradiction (fun n => n (h n)), fun p _ => p⟩
/-- And it is sign-blind: it holds for the negation under the mirror condition. -/
theorem recursion_is_sign_blind (P : Prop) : (SelfVerifying P ↔ P) ∧ (SelfVerifying (¬P) ↔ ¬P) :=
  ⟨recursion_is_shared P, recursion_is_shared (¬P)⟩
/-- Exactly one of a proposition and its negation carries the closed loop. -/
theorem exactly_one_stands (P : Prop) :
    (SelfVerifying P ∨ SelfVerifying (¬P)) ∧ ¬ (SelfVerifying P ∧ SelfVerifying (¬P)) :=
  ⟨Classical.byCases (fun p : P => Or.inl (fun _ => p)) (fun n => Or.inr (fun _ => n)),
   fun ⟨a, b⟩ => (recursion_is_shared (¬P)).mp b ((recursion_is_shared P).mp a)⟩
/-- The two-point frame: an off-line pair under the fold. The fold is involutive and fixed-point-free, the zero set
    is fold-symmetric, and the line property fails: the denial of the line property as a coherent structure. -/
def twoPoint : Frame := ⟨Bool, (fun b => !b), fun _ => True, fun b => by cases b <;> rfl, fun _ _ => trivial⟩
theorem denial_is_coherent :
    (∀ b : Bool, twoPoint.τ (twoPoint.τ b) = b) ∧ (∀ b : Bool, twoPoint.Z b → twoPoint.Z (twoPoint.τ b)) ∧
    (∀ b : Bool, twoPoint.τ b ≠ b) ∧ ¬ LineProperty twoPoint :=
  ⟨twoPoint.involutive, twoPoint.symmetric, fun b => by cases b <;> (intro h; cases h),
   fun h => by have := h true trivial; cases this⟩
/-- THE PROPERTY IS CONTINGENT: it holds on the line frame and fails on the two-point frame, so its value on a frame
    is fixed by the frame's zeros and never by the fold. -/
theorem line_property_contingent : LineProperty lineFrame ∧ ¬ LineProperty twoPoint :=
  ⟨(plane_line_property onLine line_symmetric).mpr (fun _ h => h), denial_is_coherent.2.2.2⟩
/-- A frame property is keyless when its denial instantiates it on every frame. -/
def Keyless (Q : Frame → Prop) : Prop := ∀ X, SelfVerifying (Q X)
/-- A frame property is keyed when a frame inhabits its denial. -/
def Keyed (Q : Frame → Prop) : Prop := ∃ X, ¬ Q X
/-- A keyless lock is a property that holds on every frame: the deed of denying it hands it over. -/
theorem keyless_iff_valid (Q : Frame → Prop) : Keyless Q ↔ ∀ X, Q X :=
  ⟨fun h X => opens_on_the_deed (Q X) (h X), fun h X _ => h X⟩
/-- THE DISCRIMINATOR, a decision on the denial: every frame property is keyless or keyed, and never both. The
    property is bound in both halves; the pointwise recursion, shared and sign-blind, plays no part in the sort. -/
theorem discriminator (Q : Frame → Prop) : (Keyless Q ∨ Keyed Q) ∧ ¬ (Keyless Q ∧ Keyed Q) :=
  ⟨Classical.byCases (fun h : ∀ X, Q X => Or.inl ((keyless_iff_valid Q).mpr h))
     (fun h => Or.inr (Classical.byContradiction fun hn =>
        h fun X => Classical.byContradiction fun hq => hn (Exists.intro X hq))),
   fun h => Exists.elim h.2 fun X hX => hX ((keyless_iff_valid Q).mp h.1 X)⟩
/-- The fold law is keyless: every frame carries it by its own law. -/
theorem symmetry_is_keyless : Keyless (fun X => ∀ s, X.τ (X.τ s) = s) := fun X _ => X.involutive
/-- The line property is keyed: the two-point frame inhabits its denial. -/
theorem line_property_is_keyed : Keyed LineProperty ∧ ¬ Keyless LineProperty :=
  ⟨Exists.intro twoPoint denial_is_coherent.2.2.2,
   fun h => denial_is_coherent.2.2.2 ((keyless_iff_valid LineProperty).mp h twoPoint)⟩
/-- THE ASYMMETRY. A self-verifying proposition needs no key: its denial hands it over. The line property has a key:
    its denial is a structure that obeys both frame laws and on which every theorem of this file holds, so no deed of
    reading supplies the sign, and no carrier halts on every frame. -/
theorem denial_asymmetry :
    (∀ P : Prop, SelfVerifying P → P) ∧
    (∀ P : Prop, (SelfVerifying P ↔ P) ∧ (SelfVerifying (¬P) ↔ ¬P)) ∧
    ((∀ b : Bool, twoPoint.τ (twoPoint.τ b) = b) ∧ (∀ b : Bool, twoPoint.Z b → twoPoint.Z (twoPoint.τ b)) ∧
      (∀ b : Bool, twoPoint.τ b ≠ b) ∧ ¬ LineProperty twoPoint) ∧
    (¬ ∀ X : Frame, ∃ b : Carrier X, b.terminal = .bot) ∧
    (¬ ∀ X : Frame, LineProperty X) :=
  ⟨opens_on_the_deed, recursion_is_sign_blind, denial_is_coherent,
   fun h => denial_is_coherent.2.2.2 ((halted_iff twoPoint).mp (h twoPoint)),
   fun h => denial_is_coherent.2.2.2 (h twoPoint)⟩

/-! ## the socket, and what the bridge carries -/
class Supplied (X : Frame) where
  term : LineProperty X
theorem socket_is_the_property (X : Frame) : Nonempty (Supplied X) ↔ LineProperty X :=
  ⟨fun ⟨i⟩ => i.term, fun t => ⟨⟨t⟩⟩⟩
/-- THE SOCKET ON THE PLANE: an instance is exactly the statement that every zero lies on the line. -/
theorem socket_on_the_plane (Z : Plane → Prop) (hZ : ∀ p, Z p → Z (τ p)) :
    Nonempty (Supplied (planeFrame Z hZ)) ↔ ∀ p, Z p → onLine p :=
  (socket_is_the_property (planeFrame Z hZ)).trans (plane_line_property Z hZ)
theorem bridge_carries (X : Frame) [i : Supplied X] : LineProperty X ∧ ∃ b : Carrier X, b.terminal = .bot :=
  ⟨i.term, (halted_iff X).mpr i.term⟩
theorem no_socket_off_line : ¬ Nonempty (Supplied twoPoint) :=
  fun h => denial_is_coherent.2.2.2 ((socket_is_the_property twoPoint).mp h)

/-! ## the bridge, whole -/
theorem the_bridge :
    (∀ p : Plane, τ (τ p) = p) ∧ (∀ p : Plane, τ p = p ↔ onLine p) ∧ (∃ p : Plane, onLine p) ∧
    (∀ (Z : Plane → Prop) (hZ : ∀ p, Z p → Z (τ p)), LineProperty (planeFrame Z hZ) ↔ ∀ p, Z p → onLine p) ∧
    (∀ (X : Frame) (b : Carrier X), (b.terminal = .bot → LineProperty X) ∧ (LineProperty X → b.terminal = .bot)) ∧
    (∀ X : Frame, (∃ b : Carrier X, b.terminal = .bot) ↔ LineProperty X) ∧
    (∀ f : Bool → Bool, f = (fun x => x) ∨ f = (fun x => !x) ∨ f = (fun _ => true) ∨ f = (fun _ => false)) ∧
    (∀ b : Bool, b = true ∨ b = false) ∧
    (¬ ∃ g : Tri → Tri, ∀ v, g (delete v) = v) ∧
    (∀ {α : Type} (σ : α → α) (f d : α → Bool) (x : α), Even σ f → d (σ x) ≠ d x → f ≠ d) ∧
    (∀ {α : Type} (σ : α → α) (s d : α → Bool) (x : α), s (σ x) = !s x → d (σ x) = !d x →
      ∃ c : Bool, (d x = xor (s x) c ∧ d (σ x) = xor (s (σ x)) c) ∧
        ∀ c', (d x = xor (s x) c' ∧ d (σ x) = xor (s (σ x)) c') → c' = c) ∧
    (∀ X : Frame, Nonempty (Supplied X) ↔ LineProperty X) ∧
    (∀ (Z : Plane → Prop) (hZ : ∀ p, Z p → Z (τ p)), Nonempty (Supplied (planeFrame Z hZ)) ↔ ∀ p, Z p → onLine p) ∧
    (∀ (X : Frame) [Supplied X], LineProperty X ∧ ∃ b : Carrier X, b.terminal = .bot) ∧
    (¬ Nonempty (Supplied twoPoint)) ∧
    (LineProperty lineFrame ∧ ¬ LineProperty twoPoint) ∧
    (∀ P : Prop, (SelfVerifying P ∨ SelfVerifying (¬P)) ∧ ¬ (SelfVerifying P ∧ SelfVerifying (¬P))) ∧
    (∀ Q : Frame → Prop, (Keyless Q ∨ Keyed Q) ∧ ¬ (Keyless Q ∧ Keyed Q)) ∧
    Keyless (fun X => ∀ s, X.τ (X.τ s) = s) ∧
    (Keyed LineProperty ∧ ¬ Keyless LineProperty) ∧
    ((∀ P : Prop, SelfVerifying P → P) ∧
     (∀ P : Prop, (SelfVerifying P ↔ P) ∧ (SelfVerifying (¬P) ↔ ¬P)) ∧
     ((∀ b : Bool, twoPoint.τ (twoPoint.τ b) = b) ∧ (∀ b : Bool, twoPoint.Z b → twoPoint.Z (twoPoint.τ b)) ∧
       (∀ b : Bool, twoPoint.τ b ≠ b) ∧ ¬ LineProperty twoPoint) ∧
     (¬ ∀ X : Frame, ∃ b : Carrier X, b.terminal = .bot) ∧ (¬ ∀ X : Frame, LineProperty X)) :=
  ⟨fold_involutive, locus_is_the_fixed_set, locus_inhabited, plane_line_property, read_twice, halted_iff,
   cannot_extend, cannot_divide, cannot_reverse, fun σ f d x he ho => wall σ f d x he ho,
   fun σ s d x hs hd => calibration σ s d x hs hd, socket_is_the_property, socket_on_the_plane, @bridge_carries,
   no_socket_off_line, line_property_contingent, exactly_one_stands, discriminator, symmetry_is_keyless,
   line_property_is_keyed, denial_asymmetry⟩
end Bridge
