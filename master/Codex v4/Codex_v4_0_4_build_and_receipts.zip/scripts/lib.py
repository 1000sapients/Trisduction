import re, hashlib, json, os

M = open('/tmp/M.md', encoding='utf-8').read().split('\n')
C = open('/tmp/C.md', encoding='utf-8').read().split('\n')

def lines(a, b):
    """1-based inclusive line range of the Master."""
    return M[a-1:b]

def text(a, b):
    return '\n'.join(lines(a, b))

# ---------- chapter ranges in Master v3.39.0 (1-based, inclusive start, exclusive end line of next heading)
def find_heading(prefix, start=1):
    for i in range(start-1, len(M)):
        if M[i].startswith(prefix):
            return i+1
    raise KeyError(prefix)

def chapter(prefix, start=1, stop_prefixes=('## ', '# ')):
    a = find_heading(prefix, start)
    b = a
    for i in range(a, len(M)):
        if any(M[i].startswith(p) for p in stop_prefixes):
            b = i
            break
    else:
        b = len(M)
    return a, b  # M[a-1:b-1] is the chapter incl. heading

def chapter_text(prefix, start=1):
    a, b = chapter(prefix, start)
    return '\n'.join(M[a-1:b-1]).rstrip() + '\n'

# ---------- substitution map (L4)
SUBS = [
    (re.compile(r'MathDuction'), 'the Math Seal'),
    (re.compile(r'mathduction'), 'the math seal'),
]
def substitute(s):
    for rx, rep in SUBS:
        s = rx.sub(rep, s)
    # article repair: "the the Math Seal" / "The the Math Seal"
    s = s.replace('the the Math Seal', 'the Math Seal').replace('The the Math Seal', 'The Math Seal')
    s = s.replace('a the Math Seal', 'a Math Seal')
    return s

def sha(s):
    return hashlib.sha256(s.encode('utf-8')).hexdigest()[:16]

# ---------- hedge lexicon (L2)
HEDGE = re.compile(r"\b(may|might|perhaps|arguably|seems?|appears? to|likely|we believe|to some extent|in some sense|tentative(ly)?|preliminar(y|ily)|not necessarily|honest perimeter|our limitation|a limitation|weaknesses?)\b", re.I)

def hedge_hits(s):
    return [(m.group(0), s[max(0,m.start()-60):m.end()+60].replace('\n',' ')) for m in HEDGE.finditer(s)]

# ---------- Lean excerpts
LEAN_FILES = ['/tmp/forge/Codex1.lean', '/tmp/forge/Codex2.lean', '/tmp/forge/Codex3.lean',
              '/tmp/forge/Codex4.lean', '/tmp/forge/forge_additions.lean']
_lean_cache = None
def lean_index():
    global _lean_cache
    if _lean_cache is not None:
        return _lean_cache
    idx = {}
    for fn in LEAN_FILES:
        L = open(fn, encoding='utf-8').read().split('\n')
        ns = []
        for i, l in enumerate(L):
            m = re.match(r'^\s*namespace\s+([\w.«»\']+)', l)
            if m:
                ns.append(m.group(1)); continue
            m = re.match(r'^\s*end\s+([\w.«»\']+)\s*$', l)
            if m and ns and ns[-1] == m.group(1):
                ns.pop(); continue
            m = re.match(r'^(\s*)(theorem|def|abbrev|structure|inductive)\s+([\w«»\'.]+)', l)
            if m:
                name = m.group(3)
                full = '.'.join(ns + [name]) if ns else name
                indent = len(m.group(1))
                # extent: until blank line followed by a decl/command at indent <= this, or namespace end
                j = i + 1
                while j < len(L):
                    lj = L[j]
                    if re.match(r'^\s*(theorem|def|abbrev|structure|inductive|instance|end |namespace|#eval|#guard_msgs|/--|/-!|set_option|section|@\[)', lj) and (len(lj) - len(lj.lstrip())) <= indent:
                        break
                    j += 1
                body = L[i:j]
                while body and not body[-1].strip():
                    body.pop()
                # docstring above
                doc = []
                k = i - 1
                if k >= 0 and L[k].rstrip().endswith('-/'):
                    while k >= 0:
                        doc.insert(0, L[k])
                        if L[k].lstrip().startswith('/--'):
                            break
                        k -= 1
                idx.setdefault(full, (fn, doc + body))
        # nothing
    _lean_cache = idx
    return idx

def lean_excerpt(full, maxlines=16):
    idx = lean_index()
    if full not in idx:
        raise KeyError(full)
    fn, body = idx[full]
    # dedent
    ind = min((len(l) - len(l.lstrip())) for l in body if l.strip())
    body = [l[ind:] if len(l) >= ind else l for l in body]
    if len(body) > maxlines:
        body = body[:maxlines] + ['  -- (proof continues; full text in the Code Block)']
    return '\n'.join(body)

def lean_exists(full):
    return full in lean_index()
