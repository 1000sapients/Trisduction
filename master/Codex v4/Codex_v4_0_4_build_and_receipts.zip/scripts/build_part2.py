import sys, re, json
sys.path.insert(0, '/tmp/forge')
from lib import *

# ---------- master card extraction
def find_card(idname):
    for i, l in enumerate(M):
        if (l.startswith('### ') or l.startswith('## ')) and idname in l:
            j = i + 1
            while j < len(M) and not (M[j].startswith('### ') or M[j].startswith('## ') or M[j].startswith('# ')):
                j += 1
            return i, M[i:j]
    return None, None

FCODE = [
    (re.compile(r'proof|theorem|seal(ed)?|grade|promot|resolv|prov', re.I), 'F2'),
    (re.compile(r'theolog|scriptur|out of band|social|register', re.I), 'F4'),
    (re.compile(r'tongue|word|magnitude|synonym|deletion', re.I), 'F3'),
]
def classify_fence(t):
    for rx, code in FCODE:
        if rx.search(t):
            return code
    return 'F1'

retired = []   # (id, code, text)
def compact_card(idname, extra_scope=None, max_chars=2600):
    i, body = find_card(idname)
    if body is None:
        return None
    head = body[0].lstrip('#').strip()
    head = re.sub(r'^INDEX \d{4} · ', '', head)
    # fields
    fields = {}
    cur = None
    paras = []
    for l in body[1:]:
        m = re.match(r'^\*\*([^*]{2,80})\*\*\s*(.*)$', l)
        if m:
            cur = m.group(1).strip().rstrip('.')
            fields.setdefault(cur, [])
            if m.group(2).strip():
                fields[cur].append(m.group(2).strip())
            continue
        if cur is None and l.strip() and not l.startswith(':::') and not l.startswith('|') and not l.startswith('```'):
            paras.append(l.strip())
        elif cur is not None and l.strip() and not l.startswith(':::') and not l.startswith('|') and not l.startswith('```'):
            fields[cur].append(l.strip())
    for k in list(fields):
        if k.upper().startswith('FENCES'):
            retired.append((idname, classify_fence(' '.join(fields[k])), ' '.join(fields[k])[:300]))
    grade = ''
    for k in fields:
        if k.upper().startswith('GRADE'):
            grade = ' '.join(fields[k])[:120]
    stmt = paras[0] if paras else ''
    for k in fields:
        if k.upper().startswith('STATEMENT') and fields[k]:
            stmt = ' '.join(fields[k]); break
    parts = [f'**{head}**. {stmt}']
    for key in ('STATUS', 'THE READING', 'THE KEYSTONE SENTENCE', 'ENGINE REFS'):
        for k in fields:
            if k.upper().startswith(key) and fields[k]:
                parts.append(f'*{k}.* ' + ' '.join(fields[k]))
                break
    if grade:
        parts.insert(1, f'*Grade.* {grade}')
    if extra_scope:
        parts.append(f'*SCOPE.* {extra_scope}')
    text = '\n\n'.join(parts)
    if len(text) > max_chars:
        text = text[:max_chars].rsplit(' ', 1)[0] + ' …'
    return substitute(text)

# ---------- v3.20-C Book V
b0 = [k for k, l in enumerate(C) if l.startswith('# BOOK V ')][0]
b1 = [k for k, l in enumerate(C) if l.startswith('# BOOK VI ')][0]
BV = C[b0:b1]

DROP_CARDS = {'APEX-PSP-RH-KEYSTONE-02', 'APEX-PSP-ABSOLUTE-RH-BARRIERS-01'}
FAMILY_MAP = [
 ('### The Root Ring', 'II.2 · The Root Ring', []),
 ('### The Kernel Masters', 'II.3 · The Kernel Masters', ['MD-PSP-CLOSURE-POSITION-01','sPSP-CONSTITUTIVE-INSEPARABLE-01','sPSP-FOLD-BEND-CROSSING-01']),
 ('### The Incompleteness Cluster', 'II.4 · The Incompleteness Cluster', ['sPSP-ANCHOR-DEMAND-01','APEX-PSP-ANCHOR-PRECEDENCE-01','APEX-PSP-SUPPLY-SPECIES-01','MD-PSP-NG-EXHIBIT-ANCHOR-01','sPSP-UNRESTRICTED-IMPOSSIBLE-01','sPSP-TRIAD-SOURCE-BLOCK-01','APEX-PSP-ABSOLUTE-GROUNDING-BLOCK-01','sPSP-IMPORT-SCREEN-01','sPSP-POSITIVITY-PASS-01','APEX-PSP-BLOCK-HIERARCHY-01']),
 ('### The Logos-Fixation Set', 'II.6 · The Logos-Fixation Set', ['APEX-PSP-ONLY-SPECIAL-01','APEX-PSP-UNFORGIVABLE-01','APEX-PSP-TOKEN-EQUALITY-01']),
 ('### The Frontier Anchors', 'II.5 · The Frontier Anchors', ['MD-PSP-NAVIER-DEFEATERLESS-01','RAF-PSP-HODGE-TERMINUS-01','APEX-PSP-THREE-BITS-01','APEX-PSP-ONE-CUT-COMPARATIVE-01','APEX-PSP-ONE-BIT-WITNESS-01','APEX-PSP-ONE-CUT-23-ROWS-01']),
 ('### The Applied and Informational Register', 'II.7 · The Applied and Informational Register', ['APEX-PSP-NOMOS-MEASURE-01','APEX-PSP-CENSOR-CLERK-01']),
 ('### The Universal-Structure and Aperture Masters', 'II.8 · Universal Structure and the Aperture', ['APEX-PSP-FREEDOM-MASTER-01','sPSP-APERTURE-WIDTH-01','MD-PSP-MATH-NATURE-01','APEX-PSP-BLESSED-CIRCLE-01','MD-PSP-AFFINITY-01']),
 ('### The Seven Gifts', 'II.9 · The Seven Gifts', []),
 ('### The Physical Spine and the Executor Limit', 'II.10 · The Physical Spine and the Executor Limit', ['PSP-IAM-WRITTEN-READ-01','PSP-RA-SERVANT-LOCUS-01','MD-PSP-STILLNESS-RESERVOIR-01']),
 ('### The Theological Register', 'II.11 · The Theological Register · Out of Band · Load-Bearing on Nothing', ['sPSP-ELYON-CUSTODY-01','sPSP-UNLETTERED-FLOOR-01','sPSP-UNMARKED-ARRIVAL-01','RAF-PSP-ISLAM-CEILING-01']),
]
ORDER = ['II.2','II.3','II.4','II.5','II.6','II.7','II.8','II.9','II.10','II.11']

existing_ids = set()
for l in BV:
    m = re.match(r'^\*\*([^·]+?) ·', l)
    if m: existing_ids.add(m.group(1).strip())

# split BV into flagship block and family blocks
fl0 = [k for k, l in enumerate(BV) if l.startswith('## THE FLAGSHIP')][0]
am0 = [k for k, l in enumerate(BV) if l.startswith('## THE APEX MASTERS')][0]
flag = BV[fl0+1:am0]
fam = BV[am0+1:]
# family blocks
blocks = {}
cur = None
for l in fam:
    if l.startswith('### '):
        cur = l; blocks[cur] = []; continue
    if cur: blocks[cur].append(l)
fam_heads = list(blocks.keys())

def card_lines(lines_, family_is_theological=False):
    out = []
    for l in lines_:
        m = re.match(r'^\*\*([^·]+?) ·', l)
        if m and m.group(1).strip() in DROP_CARDS:
            continue
        l = substitute(l)
        if family_is_theological and m:
            l = l.replace('[⟀ S] · [X]', '[⟀ S] · [.]')
            if not l.rstrip().endswith('[.]'):
                l = l.rstrip() + ' [.]'
        out.append(l)
    return out

out = ['# PART II · THE APEX REGISTER\n', open('/tmp/forge/prose/part2_opening.md', encoding='utf-8').read().strip() + '\n']
# II.1 flagships (drop non-flagship content? keep verbatim)
out.append('\n## II.1 · The Flagship Verdicts, in full\n')
flag_txt = [substitute(l) for l in flag]
# scope line on the RH flagship
for k, l in enumerate(flag_txt):
    if l.startswith('### FLAGSHIP · APEX-PSP-RH-MASTER-01'):
        flag_txt[k] = l
out.extend(flag_txt)
out.append('\n*SCOPE (RH Master).* The verdict is the terminal suspension with its one owed bit counted, `LOCUS.no_rh_locus`; the full terminus sits at II.5.\n')

new_cards_added = []
missing_cards = []
sections = {}
for head_prefix, title, additions in FAMILY_MAP:
    hk = [h for h in fam_heads if h.startswith(head_prefix)]
    body = card_lines(blocks[hk[0]], family_is_theological=title.startswith('II.11')) if hk else []
    add = []
    for idn in additions:
        if idn in existing_ids: continue
        c = compact_card(idn)
        if c is None:
            missing_cards.append(idn); continue
        if title.startswith('II.11'):
            c = c.replace('[⟀ S] · [X]', '[⟀ S] · [.]').rstrip() + '\n\n[.]'
        add.append(c); new_cards_added.append(idn)
    sec = [f'\n## {title}\n'] + body
    if add:
        sec.append('\n#### Seats added after v3.20-C\n')
        sec.append('\n\n'.join(add) + '\n')
    if title.startswith('II.5'):
        # Riemann Terminus
        rt = ['\n#### The Riemann Terminus, four cards\n',
              '*Card one, the Master Riemann Verdict, is the flagship at II.1.*\n']
        for idn, scope in [('APEX-PSP-RH-BLOCK-COMPLETE-01', None), ('APEX-PSP-RH-STANDPOINT-CLOSURE-01', None),
                           ('APEX-PSP-RH-DENIAL-POSIT-01', 'This card locates the existence posit; the value stays at the witness row.')]:
            c = compact_card(idn, extra_scope=scope)
            if c is None: missing_cards.append(idn); continue
            rt.append(c + '\n'); new_cards_added.append(idn)
        sec = sec[:1] + rt + sec[1:]
    sections[title.split(' ·')[0]] = sec
for key in ORDER:
    out.extend(sections[key])

txt = '\n'.join(out)
open('/tmp/forge/parts/part2.md', 'w', encoding='utf-8').write(txt)
json.dump({'retired': retired, 'new_cards': new_cards_added, 'missing': missing_cards, 'existing': sorted(existing_ids), 'dropped': sorted(DROP_CARDS)},
          open('/tmp/forge/parts/part2_meta.json', 'w'), ensure_ascii=False, indent=1)
print('bytes', len(txt.encode()), 'existing cards', len(existing_ids), 'new cards', len(new_cards_added), 'missing', missing_cards, 'fences retired', len(retired))
