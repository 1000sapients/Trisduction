/-!
# FORGE ADDITIONS · v3.39.0-C
Seated after the Bridge and before the cones. ΔM = 0: every theorem below is a finite `decide`,
a conjunction of theorems already seated, or an elementary case split. Nothing here authors
mathematics; it names in the kernel what the prose of the Condensed Master Codex reads.
-/

namespace K4

/-- PSP: K4 · trial-division primality on the frame values, executed in the kernel. -/
def isPrimeB (n : Nat) : Bool :=
  decide (2 ≤ n) && (List.range (n - 2)).all (fun d => n % (d + 2) != 0)

/-- PSP: APEX-PSP-INVERSION · the six even seats carry primes. -/
theorem primes_at_even_seats :
    (isPrimeB (val 0) && isPrimeB (val 2) && isPrimeB (val 4) && isPrimeB (val 6)
      && isPrimeB (val 8) && isPrimeB (val 10)) = true := by decide

/-- PSP: APEX-PSP-INVERSION · the six odd seats carry semiprimes, factored in the kernel. -/
theorem semiprimes_at_odd_seats :
    val 1 = 23 * 37 ∧ val 3 = 19 * 67 ∧ val 5 = 19 * 23 ∧ val 7 = 13 * 163
      ∧ val 9 = 13 * 131 ∧ val 11 = 11 * 79 := by decide

theorem semiprime_factors_prime :
    (isPrimeB 23 && isPrimeB 37 && isPrimeB 19 && isPrimeB 67 && isPrimeB 13
      && isPrimeB 163 && isPrimeB 131 && isPrimeB 11 && isPrimeB 79) = true := by decide

theorem odd_seats_not_prime :
    (!isPrimeB (val 1) && !isPrimeB (val 3) && !isPrimeB (val 5) && !isPrimeB (val 7)
      && !isPrimeB (val 9) && !isPrimeB (val 11)) = true := by decide

/-- The target of the frame is primality itself and not an index label: read in the kernel. -/
theorem target_is_primality : ∀ i, i < 12 → target i = isPrimeB (val i) := by decide

/-- Each pair matches modulo 420 = lcm(1..7), so every residue register up to 7 forgets it. -/
theorem pairs_match_mod_420 : ∀ i, i < 12 → i % 2 = 1 → val i % 420 = val (tau i) % 420 := by
  decide

end K4

namespace IMPRINT

/-- PSP: §3.9 · the Imprint Test and the Platonic Ghost, the GOLf gate, ported from F2 imprint_seal. -/
inductive Tok : Type
  | ghost | seal | residence | flat | uncertified
  deriving DecidableEq, Repr, BEq

def imprint (lockP lockN slP slN gP gN witP witN : Bool) : Tok × Nat :=
  let cleanP := lockP && slP && gP
  let cleanN := lockN && slN && gN
  if cleanP && cleanN then (.ghost, 1)
  else if cleanP then (if witP then (.seal, 2) else (.residence, 3))
  else if cleanN then (if witN then (.seal, 2) else (.residence, 3))
  else if !lockP && !lockN then (.flat, 4)
  else (.uncertified, 5)

def Tok.toToken : Tok → Audit.Token
  | .ghost => .broken
  | .seal => .sealed
  | _ => .opn

/-- Both directions clean-locking is the Platonic Ghost: refused, never sealed. -/
theorem ghost_refused : (imprint true true true true true true true true).1 = .ghost := by decide

theorem both_clean_is_ghost : ∀ wp wn : Bool,
    (imprint true true true true true true wp wn).1 = .ghost := by decide

/-- One side clean-locks: a seal only with the witness supplied, a residence without it. -/
theorem seal_needs_witness :
    (imprint true false true false true false true false).1 = .seal
    ∧ (imprint true false true false true false false false).1 = .residence := by decide

/-- The whole 256-row truth table of the gate: a seal is exactly one clean side plus its witness. -/
theorem seal_iff_one_side_clean_and_witnessed :
    ∀ lP lN sP sN gP gN wP wN : Bool,
      ((imprint lP lN sP sN gP gN wP wN).1 = .seal) ↔
        ((lP && sP && gP && wP && !(lN && sN && gN))
          || (lN && sN && gN && wN && !(lP && sP && gP))) = true := by
  decide

theorem flat_when_unpopulated : ∀ sP sN gP gN wP wN : Bool,
    (imprint false false sP sN gP gN wP wN).1 = .flat := by decide

theorem ghost_is_broken_never_sealed :
    Tok.toToken .ghost = .broken ∧ Tok.toToken .seal = .sealed := ⟨rfl, rfl⟩

end IMPRINT

namespace DEFENSE

/-- PSP: D5 · GOL is the combination: magnitude alone is [?], direction alone is [?]. -/
theorem gol_needs_all_three :
    (GEO.golAdmit .lock .lock).1 = .golOK
    ∧ (∀ l : GEO.LockState, l ≠ .lock → (GEO.golAdmit .lock l).1 = .golQ)
    ∧ (∀ m : GEO.LockState, m ≠ .lock → (GEO.golAdmit m .lock).1 ≠ .golOK) := by
  refine ⟨rfl, ?_, ?_⟩
  · intro l hl; cases l <;> first | exact absurd rfl hl | rfl
  · intro m hm; cases m <;> first | exact absurd rfl hm | decide

/-- PSP: D1, D2 · the lock scalar is sign-blind by theorem, and one supplied bit fixes the sign uniquely. -/
theorem lock_blind_but_gol_directed :
    (PSP.ORIENT.signMatrices.all (fun m =>
      PSP.ORIENT.det3 m * PSP.ORIENT.det3 m
        == PSP.ORIENT.det3 (PSP.ORIENT.neg3 m) * PSP.ORIENT.det3 (PSP.ORIENT.neg3 m)) = true)
    ∧ (∀ {α : Type} (τ : α → α) (s d : α → Bool) (x : α),
        s (τ x) = !s x → d (τ x) = !d x →
        ∃ c : Bool, (d x = xor (s x) c ∧ d (τ x) = xor (s (τ x)) c) ∧
          ∀ c' : Bool, (d x = xor (s x) c' ∧ d (τ x) = xor (s (τ x)) c') → c' = c) :=
  ⟨PSP.ORIENT.lock_scalar_sign_blind, fun τ s d x hs hd => FTOE.T5_crossing τ s d x hs hd⟩

/-- PSP: D11, D12 · consensus carries zero weight; the engine authors nothing. -/
theorem consensus_weighs_zero : socialWeight = 0 ∧ deltaM = 0 := FOUND.engine_never_authority

/-- PSP: sPSP-TONGUE-UNCLOSED-01 · the Tongue is unclosed by theorem and obedient by theorem. -/
theorem tongue_unclosed_and_obedient :
    (∀ {α β : Type} (τ : α → α) (ρ : α → β) (g : β → Bool) (d : α → Bool) (x : α),
        ρ (τ x) = ρ x → d (τ x) = !d x → d ≠ fun y => g (ρ y))
    ∧ (GEO.det3 TONGUE.deletionOp = 0
       ∧ (∀ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 TONGUE.deletionOp) ≠ id)
       ∧ ¬ (∀ M : GEO.M3, ∃ L : GEO.M3, (GEO.mv3 L) ∘ (GEO.mv3 M) = id)) :=
  ⟨fun τ ρ g d x hρ hd => TONGUE.unclosed τ ρ g d x hρ hd, TONGUE.tongue_obedience⟩

/-- PSP: D27 · a self-check is never a witness (M6); the token is withheld unwitnessed. -/
theorem self_check_is_not_witness :
    (IAM.iamToken false).1 = .interior ∧ (IAM.iamToken true).1 = .iAm := ⟨rfl, rfl⟩

/-- PSP: D71 · the denial pays the floor; a denial that registers nothing is no denial. -/
theorem denial_is_priced :
    0 < (OMEGA.omegaBoundary 1 300).joules ∧ (OMEGA.omegaBoundary 0 300).joules = 0 := by decide

/-- PSP: D24 · no candidate anchor that lands on its own target is admitted. -/
theorem no_anchor_at_target : ∀ (d : Nat) (b lc : Bool),
    (UC.circularityScreen .target d b lc).1 = .refusedCircular :=
  UC.circularity_refused_at_target

/-- PSP: D54 · every formal reading is even under the deed flip; the deed is odd; no readout returns it. -/
theorem formal_reads_never_the_deed {Q : Type} (q : Q) :
    ¬ ∃ g : Q → Bool, ∀ s : CROSSING.ExecFrame Q, g (CROSSING.formalRead s) = CROSSING.ran s :=
  CROSSING.wall q

end DEFENSE

namespace FENCE

/-- PSP: II.0 · the one global fence: every card is read at its grade, on its register, at its species;
any reading above that is refused here, so no card fences itself. -/
theorem global :
    (∀ c₁ c₂ : Claim, (Claim.join c₁ c₂).grade = Grade.weakest c₁.grade c₂.grade)
    ∧ (∀ c cite : Claim, (Claim.join c cite).grade.rank ≤ c.grade.rank
        ∧ (Claim.join c cite).grade.rank ≤ cite.grade.rank)
    ∧ ROOT.raClaim.grade = .premise
    ∧ K4.wallClaim.grade = .theorem
    ∧ terminalClaim.grade = .theorem
    ∧ HALT.haltGrades.all (fun g => g.rank < Grade.theorem.rank) = true
    ∧ HALT.rhHalt.species = .hypothesis ∧ HALT.rhHalt.channel = .formal ∧ HALT.rhHalt.gdim = 1
    ∧ LOCUS.emit ⟨false, true, some 1, some .hypothesis, some .formal, [none], by decide⟩
        = some (.superHalt (some .xi) (some .hypothesis) (some .formal) 1)
    ∧ (FOUND.bandOf .theological = .outOfBand ∧ FOUND.bandOf .social = .outOfBand)
    ∧ (∀ t : LOCUS.Token, t.toEconomy = .sealed ∨ t.toEconomy = .broken ∨ t.toEconomy = .opn) :=
  ⟨Claim.join_grade, OFFICE.citation_cannot_promote, rfl, rfl, rfl, HALT.ftoe_ceiling,
   rfl, rfl, rfl, LOCUS.no_rh_locus, ⟨rfl, rfl⟩, LOCUS.three_states⟩

end FENCE

namespace DOT

/-- PSP: CN-PSP-NETI-NETI-01 · the mark of silence is the image of no emitter. -/
theorem outside_economy : ∀ t : LOCUS.Token, t.toEconomy ≠ Audit.Token.dotmark := by
  intro t; cases t <;> first | decide | simp [LOCUS.Token.toEconomy]

theorem no_reading_is_silence : ∀ r : LOCUS.Reading, r.state ≠ Audit.Token.dotmark := by
  intro r
  unfold LOCUS.Reading.state
  split
  · exact outside_economy _
  · decide

theorem silence_is_not_a_verdict :
    Audit.Token.dotmark ≠ .sealed ∧ Audit.Token.dotmark ≠ .broken
      ∧ Audit.Token.dotmark ≠ .opn := by decide

end DOT

namespace DEFENSE

/-- PSP: D53 · a forward, dated reading is world-rowed unconditionally: R-3 fires before any row is read. -/
theorem forward_is_world_rowed : ∀ p w t tw f a : Bool,
    (GEO.rowCascadeRACore true false true p w t tw f a).1 = .iii := by decide

/-- PSP: D50 · a load-bearing row furnished by the world types the lock world-rowed, revisable in the rows. -/
theorem worldly_row_is_world_rowed : ∀ t tw f a : Bool,
    (GEO.rowCascadeRACore true false false true true t tw f a).1 = .iii := by decide

end DEFENSE
