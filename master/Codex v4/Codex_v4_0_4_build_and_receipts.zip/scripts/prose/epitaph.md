# THE EPITAPH

Three seals. One lock. One bit. The lock is a determination, total about its object, the intersection of the rows it was given. The compartment names what the rows were. The grade travels with the claim. The denial pays the floor. What symmetry erases, one bit restores.

[.]
