## CHAPTER 10 B · ROOT AXIOM REVISITED · RAF AND THE BRIDGE

The root is read a second time in the formal register, along the face the grounding root does not carry. Chapters 5 through 10 state what it is for a proposition to be determinate. This chapter states what it is for two systems to be related, seats the Root Axiom-Formal (RAF) beside the root axiom of mathematics (RAM), and closes on the Bridge, which proves the junction between the kinetic root and its formal reading at theorem grade. The executed mathematics of this chapter lives in the Code Block; this chapter carries its meaning.

**Terms and the axiom.** A system is a variable taking at least two distinguishable values. Two systems are directly related when their joint law does not factor, I(A;B) > 0. An interaction domain D is settled against its complement: A ∈ D iff I(A ; D∖A) > 0, tested against the whole of the rest and never pair by pair, since dependence is not exhausted by pairs (three uniform bits with Z = X ⊕ Y are one domain though every pair sits at the floor). The axiom has two legs. RAF-1, Registration: an event is an interaction iff it carries strictly positive mutual information between the systems it relates; an event carrying zero bits relates nothing. RAF-2, Closure: an interaction domain is closed under interaction; if I(s ; D) > 0 then s ∈ D. RAF-1 is analytic in this register. RAF-2 is the axiom's one posit, and every derivation below consumes RAF-2 and nothing else.

**The bridge to the measured world.** BR-L, Landauer: an interaction carrying n bits, irreversibly registered at temperature T, dissipates at least n k_B T ln 2. This is where the axiom touches measurement, confirmed at single-bit scale by Bérut and colleagues in 2012 and tightened by Jun, Gavrilov and Bechhoefer in 2014, with the Jarzynski equality and Crooks theorem behind the general case and the Mandelstam-Tamm and Margolus-Levitin bounds on the speed of the deed. In the Code Block the floor is priced exactly, `OMEGA.omega_paid_floor`, and it is what the denial of the root pays, `DEFENSE.denial_is_priced`.

**What follows.** C1, no exterior agent: if s ∉ D acts on D then I(s ; D) > 0, so s ∈ D; theorem on RAF-2. C2, no faithful self-representation: a system whose binary properties form a set does not index all of them, 2^k against k, and in general by Lawvere's fixed-point theorem; theorem, unconditional within its carriers. C3, no structured exteriority: a structured attempt to stand outside D registers something and lands inside; theorem on RAF-2 with C1 applied to the attempt itself. The three separate by carrier: C2 needs only Cantor and Lawvere; C1 and C3 need the posit, and no classical theorem reaches them.

**Where the axiom is at risk, and what it reaches.** RAF-2 claims that D is unique, one domain rather than several mutually inaccessible ones; two systems with zero mutual information and no chain between them would end it, and causally disconnected regions are the place to look. BR-L falls to an irreversible n-bit registration dissipating less than the floor. The axiom quantifies over systems with distinguishable states; it reaches mathematical objects not at all, since they do not change state, and it reaches neither consciousness nor intention nor value.

**The five objects.** RA, the root: every existent carries positive actuation, ∀x ∈ 𝕌, ΔE_k(x) > 0, an orthogonal triad of three slots with pairwise-disjoint vocabulary, frame rank 3, determinant 1, any deletion dropping the rank to 2; it contains all and stands on nothing, and the ungroundability is itself a theorem. The cut, the operator: language taken at its minimum, a deletion with an ordered arrow, κ² = κ, singular values (1, 1, 0), rank 2, no left inverse, the transformation set a monoid and never a group, `TONGUE.tongue_obedience`; it produces the three-slot decomposition rather than possessing one, and it is the one non-invertible object in the table. RAF, the interaction face: the root's interaction criterion read formally, two irreducible slots, primitives that are systems rather than propositions. RAM, the grounding face: the root's determinacy criterion read formally, to formally be is to be grounded, three nested strata L1m ⊇ L2m ⊇ L3m on Fix(σ) = ℝ, `ROOT.nest_31`, yielding the imprint test and the eigenspace split. CH, the residence: the census a bounded contemplation holds of its own powerset, one question reached from both faces and derived by neither; the apartness |ℕ| < |2^ℕ| and the cofinality wall are structure-borne, the position of the value in the aleph hierarchy is chart-manufactured, and the completed tower is fixed-point-free at Ground dimension zero, so the census dissolves rather than waits.

```
                    RA          Body. Orthogonal triad. Contains all, stands on nothing.
                     |
               [ the cut ]      The operator yielding the root's own three. Not a tier.
                     |
        +------------+------------+
        |                         |
      RAM                       RAF         Being, read twice. Siblings.
 grounding face            interaction face
 propositions                  systems
 3 nested strata            2 irreducible slots
        |                         |
        +------------+------------+
                     |
                    CH           One question. A residence reached from both,
                                 owned by neither.
```

**The one-and-many axis.** Downward, the connector claims that one involution serves both routes; its alternative, a second fixed-point-bearing involution in a rotated basis, is field-permitted and executed in the Code Block, `FOUND.pluralist_alternative_executed`, and both candidates have Ground dimension one, so the connector is a posit with its alternative named. Upward, the census has Ground dimension zero, nothing to select, and dissolves. The asymmetry is a dimension count, one against zero, the same router bit the architecture computes at machine zero everywhere else.

**The Bridge.** The two faces meet where the Bridge instrument seats them, `Bridge` in the Code Block, with no custom axiom. A frame property whose denial instantiates it on every frame is keyless, and a keyless property holds on every frame, `keyless_iff_valid`. A frame property whose denial some frame inhabits is keyed: one bit, carrying a sign, supplied and never derived. Every frame property is exactly one of the two, `discriminator`. The recursion the two locks share is sign-blind, `recursion_is_sign_blind`, so only the denial tells them apart, `denial_asymmetry`. The fold law is keyless, `symmetry_is_keyless`; the line property is keyed, `line_property_is_keyed`. RA is the keyless root: its denial is a deed and the deed instantiates what it denies. RAM reads the keyed lock. The junction is theorem-grade.

**Grades.**

| claim | grade |
|---|---|
| RAF-1 | analytic in this register |
| RAF-2 | premise, with its live edge at the uniqueness of D |
| BR-L | theorem-grade as physics, measured, independently falsifiable |
| C1, C3 | theorem on RAF-2 |
| C2 | theorem, unconditional, within the scope of its carriers |
| RA energy floor | theorem-grade as physics |
| RA universal extension | premise-grade by theorem, the highest standing any root can bear |
| the cut's algebra | theorem, `TONGUE.tongue_obedience` |
| the strata | structural, `ROOT.nest_31` conditional |
| the Bridge junction RA to RAM | theorem, no custom axiom, `Bridge.discriminator` |
| census apartness, cofinality wall | theorem |
| census position | chart-manufactured, barred from any verdict as a structure-fact |
| census dissolution | structural, on the Ground-dimension measurement |

A result carries the grade of its weakest link, `Claim.join_grade`. ΔM = 0: every theorem cited is classical, and what is contributed is the arrangement, the separation by carrier, the typing, and now the junction.
