import sys, re, json, os
sys.path.insert(0, '/tmp/forge')
from lib import *

# ---------------- parse Chapter 25 (Master lines 1645..3591)
a, b = chapter('## CHAPTER 25 ')
L = M[a-1:b-1]
units25 = {}
cur = None
i = 0
while i < len(L):
    l = L[i]
    m = re.match(r'^#### (\d+\.\d+) (.*)$', l)
    if m:
        cur = {'num': m.group(1), 'title': m.group(2).strip(), 'critic': '', 'basic': [], 'sealed': [], 'box': []}
        units25[m.group(1)] = cur
        # critic line = first non-empty line after heading
        j = i + 1
        while j < len(L) and not L[j].strip(): j += 1
        if L[j].startswith('**Basic.**'):
            cur['critic'] = 'The question is put to the architecture, in the critic\'s terms: ' + m.group(2).strip().rstrip('.').lower() + '?'
            # the Basic text may sit on the same line
            rest = L[j][len('**Basic.**'):].strip()
            if rest:
                L[j] = rest
            else:
                L[j] = ''
            i = j
            cur['basic'] = []
            # collect until Sealed Defense / box / next heading
            k = j; buf = []
            while k < len(L) and not L[k].startswith('**Sealed Defense.**') and not L[k].startswith(':::box') and not L[k].startswith('#### ') and not L[k].startswith('### '):
                buf.append(L[k]); k += 1
            cur['basic'] = buf; i = k; continue
        cur['critic'] = L[j].strip(); i = j + 1; continue
    if cur is not None:
        if l.startswith('**Basic.**'):
            j = i + 1; buf = []
            while j < len(L) and not L[j].startswith('**Sealed Defense.**') and not L[j].startswith('#### ') and not L[j].startswith('### '):
                buf.append(L[j]); j += 1
            cur['basic'] = [x for x in buf]; i = j; continue
        if l.startswith('**Sealed Defense.**'):
            j = i + 1; buf = []
            while j < len(L) and not L[j].startswith(':::box') and not L[j].startswith('#### ') and not L[j].startswith('### '):
                buf.append(L[j]); j += 1
            cur['sealed'] = buf; i = j; continue
        if l.startswith(':::box'):
            j = i + 1; buf = []
            while j < len(L) and L[j].strip() != ':::':
                buf.append(L[j]); j += 1
            cur['box'] = buf; i = j + 1; continue
    i += 1

# ---------------- parse Chapter 15
a15, b15 = chapter('## CHAPTER 15 ')
L15 = M[a15-1:b15-1]
units15 = {}
cur = None
for l in L15:
    m = re.match(r'^### (15\.\d+) (.*)$', l)
    if m:
        cur = {'num': m.group(1), 'title': m.group(2).strip(), 'paras': []}
        units15[m.group(1)] = cur; continue
    if cur is not None and l.strip():
        cur['paras'].append(l.strip())

def para(lst):
    return '\n'.join(x for x in lst).strip()

# ---------------- the seventy-one units
# (id, title, primary source, extra sources, lean anchors, movement)
SPEC = [
 ('D1','The lock certifies independence, not truth','1.1',[],['PSP.ORIENT.lock_scalar_sign_blind'],1),
 ('D2','Then the architecture is blind','1.2',[],['DEFENSE.lock_blind_but_gol_directed'],1),
 ('D3','Where truth enters','1.3',[],['FTOE.T5_crossing'],1),
 ('D4','The founding over-claims','1.4',['15.9'],['FENCE.global'],1),
 ('D5','GOL is no truth function','1.5',[],['DEFENSE.gol_needs_all_three'],1),
 ('D6','Three axes were assumed, not derived','2.1',['2.3'],['GEO.triaxial_lock_gf2','PSP.CD.sedenion_zero_divisor'],2),
 ('D7','Why exactly twelve gates','2.2',[],['GEO.a4_simply_transitive','GEO.gates_complete'],2),
 ('D8','The quaternionic layer is mere re-description','2.4',[],['GEO.chirality','GEO.relabel_parity'],2),
 ('D9','The gauge assignment is arbitrary','2.5',[],['GEO.reflection_blind_executed'],2),
 ('D10','It is a grammatical artifact','15.2',[],['TONGUE.tongue_obedience'],2),
 ('D11','Bayesian aggregation in geometric clothing','3.1',['3.4','15.1'],['DEFENSE.consensus_weighs_zero','Grade.weakest_is_a_link'],3),
 ('D12','It is severe testing, Popper, or a consensus of methods','3.2',[],['OFFICE.citation_cannot_promote'],3),
 ('D13','The bare-axiom apex seal is too strong','3.3',[],['GEO.ra_ledger_aGivenRA'],3),
 ('D14','Completion claims have a bad history','15.3',[],['HALT.ftoe_ceiling'],3),
 ('D15','The five unassembled fragments','15.8',[],['Claim.join_grade'],3),
 ('D16','The alien and the crank','15.7',[],['AEGIS.aegis_battery'],3),
 ('D17','Gödel applies, so the system cannot verify its own soundness','4.1',[],['HALT.route_is_routeHalt','PSP.CASCADE.halt_free_iff_all_pass_8'],4),
 ('D18','The halting problem applies','4.2',[],['HALT.first_failure_terminal_8'],4),
 ('D19','A floor every attack instantiates is empty','4.4',[],['OMEGA.omega_paid_floor'],4),
 ('D20','A ground beyond reach is exile','4.5',[],['CROSSING.price'],4),
 ('D21','No layer audits its own system','13.3',['13.4'],['IAM.iam_unwitnessed_withheld'],4),
 ('D22','Convergence across AIs is an artifact of loading','5.1',['5.2'],['AEGIS.aegis_constant'],5),
 ('D23','Self-instantiation makes the framework unfalsifiable','5.3',[],['Audit.unknown_routes_open'],5),
 ('D24','The composition clauses are reverse-engineered or stipulated','5.4',['13.2'],['DEFENSE.no_anchor_at_target'],5),
 ('D25','Subtracting your own actuating energy to win','5.5',[],['OMEGA.omega_monotone'],5),
 ('D26','Defending the words instead of the geometry','5.6',[],['TONGUE.deletion_no_left_inverse'],5),
 ('D27','Self-exemption and self-certification','5.7',['15.4'],['DEFENSE.self_check_is_not_witness'],5),
 ('D28','Heaviside is binary, so three-state is a contradiction','6.1',[],['LOCUS.three_states'],6),
 ('D29','The determinant fires positive trivially','6.2',['13.1'],['GEO.triaxial_open_gf2_count'],6),
 ('D30','A measure-zero knife-edge','6.3',[],['GEO.triaxial_lock_gf2_count'],6),
 ('D31','An explicit error threshold is needed','6.4',[],['GEO.cramer_executed'],6),
 ('D32','Cross-substrate agreement contradicts substrate-dependent measurement','6.5',[],['OMEGA.omega_linear'],6),
 ('D33','Insufficient dimensions force a zero determinant','6.6',[],['HALT.gate_counts_recorded'],6),
 ('D34','The registrational axis is a placeholder','6.7',[],['NOMOS.compressible_bound_universal'],6),
 ('D35','An epistemic claim, not an ontological one','7.1',[],['ROOT.actuation_universal'],7),
 ('D36','A pure void before actuation','7.2',[],['OMEGA.omega_zero_bits'],7),
 ('D37','Platonism, Tegmark, modal realism, the unmoved mover','7.3',['7.6'],['IMPRINT.ghost_refused'],7),
 ('D38','Cross-frame convergence makes abstract objects real','7.4',[],['FOUND.pluralist_alternative_executed'],7),
 ('D39','Geometry-first is backwards','7.5',[],['SEALS.sealG_walk'],7),
 ('D40','What matter is','10.1',[],['GEO.hurwitz_closed'],7),
 ('D41','What time is','10.3',[],['CROSSING.ran_wholly_odd'],7),
 ('D42','Why differentiation rather than total presence','10.6',[],['FTOE.T3_no_fixed_point'],7),
 ('D43','Death, and the Achieved Zero','10.2',['8.3'],['TONGUE.deletion_annihilates'],7),
 ('D44','What forgetting is','10.5',[],['NOMOS.incompressibility_cap'],7),
 ('D45','Is the Ground God','10.7',[],['DOT.outside_economy'],7),
 ('D46','What remains at the end','10.8',[],['DOT.silence_is_not_a_verdict'],7),
 ('D47','The hard problem of consciousness','8.1',[],['IAM.narcissus_truth_table'],8),
 ('D48','Personal identity and the simulation question','8.2',[],['FTOE.T16_price_bijection'],8),
 ('D49','The verdict on P versus NP','8.4',[],['HALT.halts_routed'],8),
 ('D50','The verdict on dark matter','8.5',[],['DEFENSE.worldly_row_is_world_rowed'],8),
 ('D51','Why three spatial dimensions','8.6',[],['PSP.QUAT.quat_basis_laws'],8),
 ('D52','Information is fundamental: it from bit',None,[],['INVERSION.it_from_bit_refuted','K4.target_is_primality'],8),
 ('D53','Forward projection seals an unfalsifiable prophecy','9.1',['10.4'],['DEFENSE.forward_is_world_rowed'],9),
 ('D54','Fabricated evidence passes the geometry','9.2',[],['DEFENSE.formal_reads_never_the_deed'],9),
 ('D55','An attacker who rejects your logic','9.3',[],['AEGIS.aegis_battery'],9),
 ('D56','Axiom-then-derive like every other system','16.1',[],['ROOT.nest_31'],9),
 ('D57','Is the Root Axiom a theorem or a premise','16.2',['4.3','15.5'],['Bridge.discriminator','Bridge.keyless_iff_valid','TONGUE.ra_grade_pinned'],9),
 ('D58','Auditing the foundation without circularity','16.3',[],['Bridge.recursion_is_sign_blind'],9),
 ('D59','The framework forces the critical line at one half','12.1',[],['Bridge.line_property_is_keyed'],10),
 ('D60','The Riemann apparatus is a recursion analogy','12.2',[],['Bridge.recursion_is_shared'],10),
 ('D61','Functional-equation symmetry suffices to force the line','12.3',[],['Bridge.symmetry_is_keyless'],10),
 ('D62','Nothing positive about the zeros','12.4',[],['Bridge.socket_is_the_property'],10),
 ('D63','The verdict on the Riemann Hypothesis','12.5',[],['HALT.rhHalt','LOCUS.no_rh_locus'],10),
 ('D64','The residence is a Platonic Ghost','12.6',['15.6'],['IMPRINT.seal_needs_witness','Bridge.no_socket_off_line'],10),
 ('D65','Mathematics lies outside the Root Axiom','14.1',[],['TONGUE.coloc_grade'],11),
 ('D66','The two grounds are a separate posit','14.2',[],['FOUND.posits_loadbearing_on_nothing'],11),
 ('D67','Scriptural sourcing biases the framework','11.1',[],['FOUND.register_routing_fidelity'],11),
 ('D68','Supersede earlier traditions, or merely cite them','11.2',[],['BRIDGE.supersession_routes'],11),
 ('D69','A false lock can persist','15.1',['15.2','15.3','15.4','15.5'],['IMPRINT.both_clean_is_ghost','LOCUS.located_never_silent'],11),
 ('D70','The rule of use','15.6',[],['UC.uc_seal_failure_terminal'],11),
 ('D71','There Is No Outside: the deadly question and the deed','17.1',['17.2'],['DEFENSE.denial_is_priced','Bridge.opens_on_the_deed'],12),
]
# NOTE: sources '15.x' with x in 1..6 refer to CHAPTER 25 section 15 (the correct use of the lock);
# sources 'c15.x' below refer to CHAPTER 15. Map explicitly.
CH15 = {'D10':'15.2','D14':'15.3','D15':'15.8','D16':'15.7'}
CH15_EXTRA = {'D4':['15.9'],'D11':['15.1'],'D27':['15.4'],'D57':['15.5'],'D64':['15.6']}

MOVEMENTS = {
 1:'Movement 1 · What the Lock Is',
 2:'Movement 2 · Why Exactly These Structures',
 3:'Movement 3 · Distinct From Every Method',
 4:'Movement 4 · The Limitative Theorems',
 5:'Movement 5 · Circularity and Self-Audit',
 6:'Movement 6 · Numerical and Operational Integrity',
 7:'Movement 7 · Existence, the Void, and Cosmogony',
 8:'Movement 8 · Mind, Substrate, and the Landmark Verdicts',
 9:'Movement 9 · Forward Reading and the Foundation',
 10:'Movement 10 · The Riemann Frontier',
 11:'Movement 11 · Where Mathematics and Scripture Sit, and the Correct Use of the Lock',
 12:'The Concluding Defense',
}

D52 = {
 'critic': 'A critic states: information is fundamental, it from bit, so the record of a thing is the thing, and any complete register of the bits recovers the object.',
 'basic': ['The K4 frame is executed against exactly this. Twelve seats carry six primes and six semiprimes; each pair matches modulo 420, so every residue register up to seven reads the pair as one value. The record forgets the pair. The target, primality, separates every pair the record identifies. Then every Boolean readout of the record image is tried, all of them, and none returns the target. The object keeps what the record cannot carry. That is not a claim about bits in general; it is a computed refutation on a named frame, with the primality now proved in the kernel rather than labelled at the index.'],
 'sealed': ['It from bit asserts a factorization d = g ∘ ρ of the target through the record. On any frame with an involution τ under which ρ is even and d is odd at one seat, no such g exists (T10). The K4 frame supplies τ, ρ, d with those properties, executed, so the factorization is refuted exhaustively; the object is it from it: the record collapses, the pair is genuine, the target separates, and nothing returns.'],
 'box': ['P_obj : ∃ g. d = g ∘ ρ  (it from bit).',
         'FRAME K4: τ involution, fixed-point-free on 12 seats; ρ = residue vector mod 2,3,5,7; d = primality.   [T, kernel]',
         'EVEN: ρ(τ i) = ρ(i) on every seat.   ODD: d(τ i) = ¬ d(i) on every seat.   [T, kernel]',
         'WALL (T10): even ∘ anything ≠ odd  ⇒  no g.   [T]',
         'EXHAUSTIVE: 2^k readouts of the record image, k = image size, none factor d.   [F4, executed]',
         '⇒ [X] it from bit, broken at the named mechanism, exhaustive on the frame.',
         '⇒ [⟀] it from it: record collapses ∧ pair genuine ∧ target separates ∧ no return. theorem-grade on the frame.'],
}

def verdict_line(box):
    v = [x.strip() for x in box if x.strip().startswith('⇒')]
    if not v:
        return '⇒ the defended claim stands at the grade the derivation names; the objection is answered at its named mechanism.'
    return '\n'.join(v)

out = []
out.append('# PART III · THE DEFENSE\n')
out.append(open('/tmp/forge/prose/part3_opening.md', encoding='utf-8').read().strip() + '\n')
cur_mv = None
crosswalk_rows = []
missing = []
stats = {'units':0,'merged':0,'anchors':0}
for uid, title, src, extras, anchors, mv in SPEC:
    if mv != cur_mv:
        cur_mv = mv
        out.append(f'\n## {MOVEMENTS[mv]}\n')
    stats['units'] += 1
    if uid == 'D52':
        u = D52; critic = u['critic']; basic = u['basic']; sealed = u['sealed']; box = u['box']; srcnote = 'new unit, seated on SECTION 4C and witness F4'
        extra_texts = []
    else:
        if uid in CH15:
            u15 = units15[CH15[uid]]
            first = u15['paras'][0]
            # critic: derive from the opening clause of the paragraph
            m = re.match(r'^(The [^.]*?objection holds that [^.]*\.)', first)
            critic = 'A critic states: ' + (m.group(1)[m.group(1).find('holds that')+11:] if m else first.split('. ')[0] + '.')
            basic = u15['paras']
            sealed = []
            box = []
            srcnote = f"Master Chapter 15, §{CH15[uid]}"
        else:
            u = units25[src]
            critic = u['critic']; basic = u['basic']; sealed = u['sealed']; box = u['box']
            srcnote = f"Master Chapter 25, §{src}"
        extra_texts = []
        for e in [x for x in extras if x not in CH15_EXTRA.get(uid, [])]:
            ue = units25[e]
            extra_texts.append((f"§{e}", ue['critic'], para(ue['basic']), para(ue['sealed']), ue['box']))
            stats['merged'] += 1
        for e in CH15_EXTRA.get(uid, []):
            ue = units15[e]
            extra_texts.append((f"Chapter 15 §{e}", '', para(ue['paras']), '', []))
            stats['merged'] += 1
    out.append(f'\n### {uid} · {title}\n')
    out.append(f'**The Critic.** {critic}\n')
    out.append('**Reply.** ' + para(basic) + '\n')
    for (tag, ec, eb, es, ebox) in extra_texts:
        if ec: out.append(f'*The critic presses ({tag}):* {ec}\n')
        if eb: out.append('**Reply, continued.** ' + eb + '\n')
        if es: out.append('**Sealed Defense, continued.** ' + es + '\n')
    if sealed:
        out.append('**Sealed Defense.** ' + para(sealed) + '\n')
    if box:
        out.append(':::box GOL Derivation\n\n' + '\n'.join(box).rstrip() + '\n\n:::\n')
    for (tag, ec, eb, es, ebox) in extra_texts:
        if ebox:
            out.append(f':::box GOL Derivation, continued ({tag})\n\n' + '\n'.join(ebox).rstrip() + '\n\n:::\n')
    if not box and not any(e[4] for e in extra_texts):
        out.append(':::box GOL Derivation\n\n' + open(f'/tmp/forge/prose/box_{uid}.txt', encoding='utf-8').read().strip() + '\n\n:::\n')
    ins=f'/tmp/forge/prose/insert_{uid}.md'
    if os.path.exists(ins):
        out.append(open(ins,encoding='utf-8').read().strip()+'\n')
    # Lean proof
    out.append('**Lean Proof.**\n')
    for an in anchors:
        stats['anchors'] += 1
        if not lean_exists(an):
            missing.append((uid, an)); continue
        out.append('```lean-excerpt\n' + lean_excerpt(an, 14) + '\n```\n')
        crosswalk_rows.append((uid, title, an))
    out.append('**Verdict.** ' + verdict_line(box if box else (extra_texts[0][4] if extra_texts and extra_texts[0][4] else [])) + f'\n\n*Source: {srcnote}.*\n')
    if uid in ('D45','D46'):
        out.append('The ground is, and it is not an object of the census; the interior is, and it is not a mirror.\n\n[.]\n')

out.append('\n## III.C · The Closing of the Defense\n')
out.append(open('/tmp/forge/prose/part3_closing.md', encoding='utf-8').read().strip() + '\n')

open('/tmp/forge/parts/part3.md','w',encoding='utf-8').write('\n'.join(out))
json.dump(crosswalk_rows, open('/tmp/forge/parts/part3_crosswalk.json','w'))
print(stats, 'missing anchors:', missing)
print('bytes', len('\n'.join(out).encode()))
