import sys, re, json, os, hashlib, subprocess
sys.path.insert(0, '/tmp/forge')
from lib import *

P = '/tmp/forge/prose/'
def prose(n): return open(P + n, encoding='utf-8').read().strip() + '\n'

ledger = {'chapters': [], 'subs': [], 'hedge': {}, 'chapter_map': []}
MATH_SUBS = [
 ('λ(P) = λ(¬P)', 'λ(P) = −λ(¬P)', 'sign of the bracket under full negation: λ is odd, det(R) even (audit A-2)'),
 ('no rotation-invariant functional recovers the sign', 'no reflection-invariant functional recovers the sign, every reflection-blind functional of the triad factoring through the Gram matrix by the first fundamental theorem for O(3), the bracket λ being the one rotation invariant outside that ring and λ² = det(R) its square inside it', 'scope of the blindness: it belongs to the square, to O(3), not to rotations; the ordering by recoverability (audits A-1, round 2 A)'),
 ('two reproducible linguistic procedures, and on nothing else.', 'two reproducible linguistic procedures, and on nothing else. The self-demonstration of §1.4, in which a denial of the three lines instantiates them, is a cross-register corroboration, kinetic and registrational, and is counted among no anchor of this seal.', 'Seal L anchor base kept to the two procedures; the self-demonstration typed as corroboration (round 2, Seal L)'),
 ('The cost reading, the strictly positive cost of a transition that occurs, is theorem-grade conditional on a process occurring: the Jarzynski 1997 and Crooks 1999 nonequilibrium work relations bound the work of any process and are strictly more general than Landauer, with Landauer 1961 and Bérut 2012 the irreversible-erasure subclass, and the quantum speed limit of Mandelstam and Tamm and of Margolus and Levitin bounds the rate of any transition.',
  'The cost reading, the strictly positive cost of a transition that occurs, is theorem-grade conditional on a process occurring, and the chain is exact: a transition between distinguishable states completed in finite time τ has energy spread ΔE ≥ πħ/(2τ) > 0 by the Mandelstam-Tamm bound and mean energy above the ground ⟨E⟩ ≥ πħ/(2τ) > 0 by Margolus and Levitin, so a transition with no energy is a transition that never completes, the Frozen Substrate executed in F2; an irreversible registration pays at least k_B T ln 2 by Landauer 1961, measured by Bérut 2012; and the Jarzynski 1997 and Crooks 1999 nonequilibrium work relations bound the work of any process, erasure being the irreversible subclass. The cost is strictly positive for every completed transition because completion in finite time is itself the bound.',
  'the positive-cost theorem written as its exact chain: finite completion time forces ΔE > 0 by the speed limits (round 2, transition cost)'),
 ('The count is fixed at three and fixed twice on roads that share no premise,', 'The count is fixed at three, forced once at Seal M by the division algebras and corroborated once at Seal L by the deletion test, on roads that share no premise,', 'the residual forced-twice phrase at §1.9 brought under the D6/D10 tier (round 3, R4-03)'),
 ("Three seals on pairwise-disjoint anchors converge on one architecture. The convergence is certified, not assumed, by the architecture's own removal discipline. The independence of the seals is the seal of the seals [T].", "Three seals on pairwise-disjoint anchors converge on one architecture. The disjointness of the anchors is certified, not assumed, by the architecture's own removal discipline on the dependency record [T]; the convergence of the three on one architecture is corroboration, weighed as corroboration and never as a second forcing; the independence of the seals is the seal of the seals.", 'the Independence Law box retyped: disjointness [T], convergence corroboration (round 3, R4-02)'),
 ('Section 1.1 forces the count operationally, and Seal M forces it a second time at theorem grade from premises that mention no language at all', 'Section 1.1 carries the count operationally, and Seal M forces it once at theorem grade from the division algebras, premises that mention no language at all, the linguistic count standing as premise-disjoint corroboration', 'the residual second forcing at §1.6 brought under the D6/D10 tier (round 5, R6-02)'),
 ('So the object whose cardinality is forced twice is language,', 'So the object whose cardinality is forced once and corroborated once is language,', 'the residual forced-twice phrase at the head of §1.9 (round 5, R6-03)'),
 ('lose the premise-disjointness that double-seals the count.', 'lose the premise-disjointness by which the theorem forces the count and the deletion test corroborates it.', 'the residual double-seals phrase at the foot of §1.9 (round 5, R6-03)'),
 ('a count forced twice across disjoint anchors is not an accident of language', 'a count forced once and corroborated once across disjoint anchors is not an accident of language', 'the residual forced-twice phrase in D10 (round 5, R6-03)'),
 ('No fourth aspect of a bounded directed volume remains to be fixed,', 'No fourth aspect of the verdict object declared here, a bounded directed volume with its sign, its closure and its magnitude, remains to be fixed,', 'the three-aspect count scoped to the declared verdict object (round 2 B)'),
 ('twelve from five algebraic derivations', 'twelve from five derivations across three premise-disjoint objects, the ordered pairs, the Hurwitz units, and the sphere packing', 'derivation independence stated at the premise level (audit A-5)'),
 ('confirmed from five disjoint derivations', 'confirmed from five derivations across three premise-disjoint objects', 'derivation independence stated at the premise level (audit A-5)'),
]
def math_fix(t):
    for a, b, why in MATH_SUBS:
        if a in t:
            t = t.replace(a, b)
            ledger['subs'].append(('math correction', a, b + ' · ' + why))
    return t

# ---------------- PART I
def carry(prefix, retitle=None, start=1):
    t = chapter_text(prefix, start)
    h0 = sha(t)
    t2 = math_fix(substitute(t))
    if retitle:
        first, rest = t2.split('\n', 1)
        t2 = retitle + '\n' + rest
    ledger['chapters'].append((prefix.strip(), h0, sha(t2), len(t2.encode())))
    return t2

part1 = ['# PART I · THE THEORY\n']
# Book I
a, b = chapter('# BOOK I ', 1, stop_prefixes=('## ',))
part1.append(substitute('\n'.join(M[a-1:b-1])).rstrip().replace('# BOOK', '## BOOK', 1) + '\n')
for pre in ['## CHAPTER 0 ', '## CHAPTER 1 ', '## CHAPTER 2 ']:
    part1.append(carry(pre))
part1.append(carry('## CHAPTER 3 ', retitle='## CHAPTER 3 · THE MATH SEAL · SEAL M'))
part1.append(carry('## CHAPTER 4 '))
# Book II
a, b = chapter('# BOOK II ', 1, stop_prefixes=('## ',))
book2 = substitute('\n'.join(M[a-1:b-1])).rstrip().replace('# BOOK', '## BOOK', 1)
book2 = book2.replace('the three modes with the forward mode carried in full', 'the arrow of reading, the three readings of one instrument with the forward reading and its GOLf gate')
ledger['subs'].append(('Book II opening', 'the three modes with the forward mode carried in full', 'the arrow of reading, the three readings of one instrument with the forward reading and its GOLf gate'))
part1.append(book2 + '\n')
c5 = carry('## CHAPTER 5 ')
h, rest = c5.split('\n', 1)
part1.append(h + '\n\n*Naming in this edition.* The Math Seal is Seal M working on RAM, read along the arrow of Chapter 8; the Master\'s word for this register, MathDuction, is replaced by the Math Seal throughout, and nothing else in the register changes.\n' + rest)
for pre in ['## CHAPTER 6 ', '## CHAPTER 7 ']:
    part1.append(carry(pre))
part1.append(prose('ch8_arrow.md'))
ledger['chapter_map'].append(('CHAPTER 8 · THE THREE MODES', 'replaced by CHAPTER 8 · THE ARROW OF READING (new, 3 KB); GOLf and the Ghost test kept'))
part1.append(carry('## CHAPTER 9 '))
part1.append(carry('## CHAPTER 10 ·'))
part1.append(prose('ch10b.md'))
ledger['chapter_map'].append(('CHAPTER 10 B · ROOT AXIOM REVISITED (26 KB)', 'condensed to 8 KB; the Bridge junction added'))
part1.append(prose('part_three.md'))
ledger['chapter_map'].append(('PART THREE · THE FORMAL THEORY OF EVERYTHING (10 KB)', 'condensed to 4 KB; theorems named, executed mathematics in the Code Block'))
# Book III
a, b = chapter('# BOOK III ', 1, stop_prefixes=('## ',))
part1.append(substitute('\n'.join(M[a-1:b-1])).rstrip().replace('# BOOK', '## BOOK', 1) + '\n')
part1.append(carry('## CHAPTER 11 '))
part1.append(prose('ch11_bridge.md'))
ledger['chapter_map'].append(('CHAPTER 11', 'carried whole; three Bridge paragraphs added at its close'))
# Book IV
a, b = chapter('# BOOK IV ', 1, stop_prefixes=('## ',))
part1.append(substitute('\n'.join(M[a-1:b-1])).rstrip().replace('# BOOK', '## BOOK', 1) + '\n')
for pre in ['## CHAPTER 12 ', '## CHAPTER 13 ·', '## CHAPTER 13B ', '## CHAPTER 14 ']:
    part1.append(carry(pre))
part1.append(carry('## CHAPTER 26 '))
ledger['chapter_map'] += [('CHAPTER 15 · THE DEFENSE', 'moved into Part III'),
                          ('CHAPTER 16, 16B', 'absorbed into III.C, the Closing of the Defense'),
                          ('BOOK V · CHAPTERS 17 to 24, 25', 'Chapter 25 rebuilt as Part III; 17 and 18 replaced by C.0 and IV.1; 19 replaced by the Code Block; 20 to 24 pointed to the register of record; 23 absorbed into III.C'),
                          ('CHAPTER 26', 'carried whole, closing Part I'),
                          ('BOOK VI and the post-closing seat stream', 'triaged into Part II and the Census of IV.2'),
                          ('BOOK VII · THE SYSTEM ROLE', 'replaced by C.0 · Operating the Codex; the full role lives in the register of record'),
                          ('APPENDIX FINAL', 'absorbed into III.C')]
part1_txt = '\n'.join(part1)

# ---------------- PART II, III (already built)
part2_txt = math_fix(open('/tmp/forge/parts/part2.md', encoding='utf-8').read())
part3_txt = math_fix(open('/tmp/forge/parts/part3.md', encoding='utf-8').read())
meta2 = json.load(open('/tmp/forge/parts/part2_meta.json', encoding='utf-8'))

# ---------------- CODE BLOCK files
def body_without_header(fn, drop):
    L = open(fn, encoding='utf-8').read().split('\n')
    while L and any(L[0].startswith(d) for d in drop):
        L.pop(0)
    return '\n'.join(L).rstrip() + '\n'
lean_mono = 'import Lean\n' + open('/tmp/forge/Codex1.lean', encoding='utf-8').read().rstrip() + '\n' \
    + body_without_header('/tmp/forge/Codex2.lean', ['import', 'set_option maxRecDepth']) \
    + body_without_header('/tmp/forge/Codex3.lean', ['import', 'set_option maxRecDepth']) \
    + body_without_header('/tmp/forge/Codex4.lean', ['import', 'set_option maxRecDepth']) \
    + body_without_header('/tmp/forge/Codex5.lean', ['import', 'set_option maxRecDepth', 'set_option autoImplicit'])
open('/tmp/forge/out/Codex.lean', 'w', encoding='utf-8').write(lean_mono)
fort = open('/tmp/forge/Codex_Twin_v401.f90', encoding='utf-8').read()
open('/tmp/forge/out/Codex_Twin.f90', 'w', encoding='utf-8').write(fort)
sha_lean = hashlib.sha256(lean_mono.encode()).hexdigest()
sha_fort = hashlib.sha256(fort.encode()).hexdigest()
mod_shas = {n: hashlib.sha256(open(f'/tmp/forge/Codex{n}.lean','rb').read()).hexdigest()[:16] for n in range(1,6)}

# ---------------- PART IV
# crosswalk rows from Lean
rows = re.findall(r'\("([^"]+)", "([^"]+)"\)', open('/tmp/forge/Codex5.lean', encoding='utf-8').read().split('namespace CROSSWALK')[1].split('end CROSSWALK')[0])
FORT = [('K4.', 'F4 it_from_it, exhaustive readout census'), ('IMPRINT.', 'F2 imprint_seal, PART F and class 5'), ('OMEGA.', 'F2 omega_boundary, class 6 and PART H'),
        ('AEGIS.', 'F2 aegis_guard, four logics'), ('GEO.golAdmit', 'F2 gol_admit'), ('DEFENSE.gol', 'F2 gol_admit'), ('HALT.', 'F1 route_halt, ground_dim'),
        ('LOCUS.', 'twin locus emitter, 60 located readings'), ('Audit.', 'F1 seal_L, drill_screen, row_cascade'), ('GEO.rowCascade', 'F2 row_cascade'),
        ('DEFENSE.forward', 'F2 row_cascade, R-3'), ('DEFENSE.worldly', 'F2 row_cascade, S-2'), ('GEO.det', 'F1 det3, jacobi3'), ('GEO.adj', 'F1 det3 battery'),
        ('GEO.hurwitz', 'F2 PART C, Hurwitz closure 576/576'), ('GEO.a4', 'F2 PART C, A4 orbit and stabilizer'), ('GEO.triaxial', 'F1 intersection_dim'),
        ('FTOE.', 'F3 K1 to K4'), ('CROSSING.', 'F3 K2 the one-bit wall'), ('INVERSION.', 'F4 it_from_it'), ('IAM.', 'F2 PART H iam_token'),
        ('DEFENSE.self_check', 'F2 PART H iam_token'), ('DEFENSE.denial', 'F2 omega_boundary'), ('TONGUE.', 'F2 PART E, the cut and the deletion monoid'),
        ('DEFENSE.tongue', 'F2 PART E, the deletion monoid'), ('PSP.ORIENT', 'F1 orientation exhibit, F3 K1'), ('DEFENSE.lock_blind', 'F3 K1 and K2'),
        ('PSP.QUAT', 'F2 PART C, norm-two shell 24 = 12 + 12'), ('PSP.CD', 'F2 PART C, associator and sedenion wall'), ('DEFENSE.consensus', 'twin battery, mosaic dM = 0'),
        ('OFFICE.', 'twin battery, grade law'), ('Claim.', 'twin battery, grade law'), ('Grade.', 'twin battery, grade law'), ('UC.', 'F1 route_halt'),
        ('NOMOS.', 'twin battery, incompressibility rows'), ('FOUND.', 'twin battery, register routing'), ('ROOT.', 'F2 PART A and PART F'),
        ('SEALS.', 'F1 seal_L; F2 PART C'), ('BRIDGE.', 'twin battery, bridge census'), ('PSP.TOKEN', 'twin battery, token classes'), ('PSP.CASCADE', 'F1 first-failure cascade')]
def fort_label(t):
    for k, v in FORT:
        if t.startswith(k): return v
    return 'kernel only'
# grade tokens per identifier from the Master heading (or the card title in Part II)
def grade_tokens(idn):
    if idn in ('APEX-PSP-INVERSION-01', 'MD-PSP-K4-FRAME-01'):
        return 'kernel-checked'
    for l in part2_txt.split('\n'):
        if l.startswith('**') and idn in l:
            toks = re.findall(r'\[[^\]]+\]', l)
            if toks: return ' '.join(toks)
    for l in M:
        if (l.startswith('### ') or l.startswith('## ')) and idn in l:
            return ' '.join(re.findall(r'\[[^\]]+\]', l)) or '(grade in card)'
    m = re.search(r'\*\*' + re.escape(idn) + r' · [^*]*?(\[[^*]*)\*\*', part2_txt)
    if m: return m.group(1)
    return 'kernel-checked'
iv1 = ['## IV.1 · The Crosswalk\n', 'Every row names a constant that the crosswalk audit in the Code Block resolved in the compiled environment: 129 rows, 0 unresolved. The first block ties coordinates of the register to their kernel objects; the second ties each defense unit to the proof it quotes.\n',
       '| Coordinate or unit | Lean object | Fortran check | Grade |', '|---|---|---|---|']
for pid, t in rows:
    g = grade_tokens(pid) if not pid.startswith('D') or not pid[1:].isdigit() else 'the verdict line of the unit'
    iv1.append(f'| {pid} | `{t}` | {fort_label(t)} | {g} |')
iv1_txt = '\n'.join(iv1) + '\n'

# census
ids_master = sorted(set(json.load(open('/tmp/forge/out/ids.json'))))
in_part2 = {i for i in ids_master if re.search(r'(?<![A-Z0-9-])' + re.escape(i) + r'(?![A-Z0-9-])', part2_txt)}
card_headers = re.findall(r'^\*\*([^*]+?)\*\*', part2_txt, re.M) + re.findall(r'^### FLAGSHIP · (.+)$', part2_txt, re.M)
n_cards = len([h for h in card_headers if re.search(r'(?:APEX-PSP|MD-PSP|sPSP|PSP|RAF-PSP|CN-PSP)-', h)])
in_cross = {p for p, t in rows}
S = {}
for i in ['APEX-PSP-RH-KEYSTONE-02', 'APEX-PSP-ABSOLUTE-RH-BARRIERS-01', 'APEX-PSP-RH-KEYSTONE-01', 'APEX-PSP-RH-01', 'APEX-PSP-RH-DUAL-REGISTER-01', 'APEX-PSP-RH-DUAL-REGISTER-02', 'APEX-PSP-RH-GROUND-03', 'MD-PSP-RH-LADDER-BAR-01', 'sPSP-RH-BARRIER-01', 'APEX-PSP-RH-GROUNDING-BLOCKS-01', 'APEX-PSP-RH-TERMINAL-SYNTHESIS-01']:
    S[i] = 'S4 · merged into the Riemann Terminus, II.5'
S['sPSP-TONGUE-OBEDIENCE-01'] = 'S1 · folded into sPSP-TONGUE-UNCLOSED-01 at 0676 (v3.20.0 pass)'
def title_of(idn):
    for l in M:
        if (l.startswith('### ') or l.startswith('## ')) and idn in l:
            t = l.lstrip('#').strip()
            t = re.sub(r'^INDEX \d{4} · ', '', t)
            parts = t.split(' · ')
            return parts[1][:70] if len(parts) > 1 else ''
    return ''
iv2 = ['\n## IV.2 · The Census\n',
       f'The Mother names {len(ids_master)} coordinate identifiers in its text (the same set the Coordinate Key of IV.5 labels) and 42 explicit index numbers, 0706 to 0724 among them. The numbered roll 0001 to 0724 lives in the register of record and is not reproduced here; every identifier the Mother names appears below with its disposition in this edition.\n',
       '| Identifier | Title | Disposition |', '|---|---|---|']
counts = {'full card': 0, 'code stub': 0, 'ledger row': 0, 'removed': 0}
for idn in ids_master:
    if idn in S:
        d = S[idn]; counts['removed'] += 1
    elif idn in in_part2:
        d = 'full card, Part II'; counts['full card'] += 1
    elif idn in in_cross:
        d = 'code stub, IV.1 (a frame coordinate named in the kernel crosswalk)' if idn in ('APEX-PSP-INVERSION-01', 'MD-PSP-K4-FRAME-01') else 'code stub, IV.1'; counts['code stub'] += 1
    else:
        d = 'ledger row, register of record'; counts['ledger row'] += 1
    iv2.append(f'| {idn} | {title_of(idn)} | {d} |')
iv2_txt = '\n'.join(iv2) + '\n'

# hedge scan
def scan(name, txt):
    h = hedge_hits(txt)
    ledger['hedge'][name] = len(h)
    return h
new_prose_txt = '\n'.join(open(P + f, encoding='utf-8').read() for f in os.listdir(P))
hits_new = scan('new prose', new_prose_txt)
hits_p1 = scan('Part I (carried)', part1_txt); hits_p2 = scan('Part II', part2_txt); hits_p3 = scan('Part III', part3_txt)

fence_x_p2 = len(re.findall(r'\*\*FENCES', part2_txt))
retired = meta2['retired']
iv3 = ['\n## IV.3 · The Scribal Ledger\n',
       '**Substitution map (L4).** MathDuction → the Math Seal, everywhere, with the defining sentence at Chapter 5: the Math Seal is Seal M working on RAM. The chapter numbers of the Geometric Mother Codex (the Unabridged Master, v3.39.0) are kept, so every cross-reference inside a carried chapter still resolves; the map below records what each of its chapters became.\n',
       '| Master | This edition |', '|---|---|'] + [f'| {a} | {b} |' for a, b in ledger['chapter_map']]
iv3.append('\n**Carried chapters, hashed (sha256, first sixteen hex).** The first hash is the Master text as carried; the second is the same text after the substitution map.\n')
iv3 += ['| Chapter | Master sha | carried sha | bytes |', '|---|---|---|---|'] + [f'| {c} | {h0} | {h1} | {n} |' for c, h0, h1, n in ledger['chapters']]
iv3.append('\n**Retired fences (L7).** Every FENCES block of a card carried from the Master is retired; the block is replaced by the global fence of II.0 and `FENCE.global`. Codes: F1 kernel-carried, F2 grade-carried, F3 obedience-carried, F4 register-carried.\n')
iv3 += ['| Card | Code | The fence, opening words |', '|---|---|---|'] + [f'| {i} | {c} | {t[:110].replace("|","/")} … |' for i, c, t in retired]
iv3.append('\n**Scope survivors (F5).** Two: the RH Master flagship and the Denial Posit, each one positive line.\n')
iv3.append('\n**The [.] seats (L9).** Chapter 26, the cards of II.11, and units D45 and D46 of Part III.\n')
iv3.append('\n**Hedge scan (L2).** Counts of lexicon hits by part; new prose is held at zero. Hits in carried text are listed with their context so each can be read at its grade.\n')
iv3 += ['| Part | hits |', '|---|---|'] + [f'| {k} | {v} |' for k, v in ledger['hedge'].items()]
def classify_hedge(w, ctx):
    wl = w.lower(); c = ctx.lower()
    if wl in ('may','might') and ('critic' in c or 'objection' in c or 'p_obj' in c or 'alien' in c or 'attacker' in c or 'fabrication' in c):
        return "the critic's voice or the barred act, stated to be refused"
    if wl in ('may','might'):
        return 'permissive modal, what an instrument is licensed or barred to do; not a softening'
    if 'perimeter' in wl:
        return "the Master's own term for a boundary named by theorem; carried as a term"
    if 'limitation' in wl:
        return 'negated in place: not a limitation concealed but one legislated'
    if wl == 'likely':
        return 'descriptive of a reader, not of a claim'
    return 'read at its grade'
if hits_p1 or hits_p2 or hits_p3:
    iv3.append('\nCarried text is kept verbatim so its hashes hold; each hit is classified here and none softens a claim.\n')
    iv3.append('| Where | Word | Reading | Context |')
    iv3.append('|---|---|---|---|')
    for nm, hh in [('Part I', hits_p1), ('Part II', hits_p2), ('Part III', hits_p3)]:
        for w, ctx in hh[:400]:
            iv3.append(f'| {nm} | {w} | {classify_hedge(w, ctx)} | {ctx.replace("|","/")} |')
iv3.append('\n**Declared substitutions outside the hashed chapters.**\n')
iv3 += ['| Where | Master text | This edition |', '|---|---|---|'] + [f'| {a} | {b} | {c} |' for a, b, c in ledger['subs']]
iv3_txt = '\n'.join(iv3) + '\n'
iv4_txt = open(P + 'iv4_audit.md', encoding='utf-8').read().strip() + '\n'
# IV.5 the coordinate key (short labels), held in the Markdown master only
sys.path.insert(0, '/tmp/forge')
from labels import build_map, KEY
labels = build_map(json.load(open('/tmp/forge/out/ids.json')))
json.dump(labels, open('/tmp/forge/out/labels.json', 'w'), indent=1)
iv5 = ['\n## IV.5 · The Coordinate Key\n',
       'The short nomenclature of the condensed editions, one label per coordinate. A label is a rendering aid and carries no warrant; the native identifier is the register\'s. The rule: drop the family prefix, drop MASTER, VERDICT, LAW, PROTOCOL and UNION, keep the stem to twelve characters (abbreviating the second word to three letters where needed), and carry the seat number without its leading zero. Labels seated by the prior condensed edition are kept as given; the rest are derived by the rule and marked.\n',
       '| Label | Native identifier | Title |', '|---|---|---|']
for idn in sorted(labels, key=lambda x: labels[x]):
    iv5.append(f'| `{labels[idn]}` | {idn} | {title_of(idn)}{"" if idn in KEY else " · derived"} |')
iv5.append('\n**The hash preimage.** The sorted identifier list, exactly the text hashed in the closing (sha256 of the UTF-8 text of `json.dumps(sorted(ids))`, default separators):\n')
iv5.append('```json\n' + json.dumps(sorted(labels)) + '\n```\n')
iv5_txt = '\n'.join(iv5) + '\n'
part4_txt = '# PART IV · THE CROSSWALK AND THE CENSUS\n\n' + iv1_txt + iv2_txt + iv3_txt + '\n' + iv5_txt

# ---------------- receipts from the runs
def outfile(n):
    return open(f'/tmp/forge/c{n}.out', encoding='utf-8').read()
lean_receipts = {n: outfile(n).strip().split('\n')[-1] for n in range(1, 6)}
guards = sum(len(re.findall(r'^#guard_msgs', open(f'/tmp/forge/Codex{n}.lean', encoding='utf-8').read(), re.M)) for n in range(1, 6))
env_audit = [l for l in outfile(5).split('\n') if l.startswith('crosswalk audit')]
errors = sum(outfile(n).count('error') for n in range(1, 6))
twin = open('/tmp/forge/twin_v401.out', encoding='utf-8').read()
twin_lines = [l for l in twin.split('\n') if re.search(r'checks \d|checks":|batteries pass|VERDICT:|THE TWIN LOAD', l)]

# ---------------- Code Block text
code = ['# THE CODE BLOCK\n', prose('c0_operating.md'),
        '## C.1 · The Lean surface\n',
        f'One file, `Codex.lean`, sha256 `{sha_lean}`. Core Lean 4 v4.19.0, no Mathlib, no sorry, no custom axiom beyond the twenty-three declared posits. The file is the concatenation of five modules that compile in sequence under `lean -o` on a machine with four gigabytes of memory; the modules carry the same text with one `import` line each at the head, and their hashes are {", ".join(f"Codex{n} `{h}`" for n, h in mod_shas.items())}. The environment audit at the foot selects the constants of these modules by module name, so it reports the same twenty-three posits in the modular build as in the single file.\n',
        '```lean\n' + lean_mono.rstrip() + '\n```\n',
        '## C.2 · The Fortran twin\n',
        f'One file, `Codex_Twin.f90`, sha256 `{sha_fort}`: the twin battery of 135 checks and the four witnesses F1 thesis_rows, F2 ra_toe_thesis, F3 ftoe_kinetic_demonstration, F4 it_from_it. Four repairs on the twin are seated in this edition and named in its header: the left-inverse test computed through the deletion map, the omega guard aligned to the Lean surface at bits ≤ 0, the summary asserts reading the battery state, and the six-seat K4 section named a miniature of the canonical frame that F4 executes.\n',
        '```fortran\n' + fort.rstrip() + '\n```\n',
        prose('c3_contract.md')]
code_txt = '\n'.join(code)

# ---------------- references and closing
refs = ['# REFERENCES\n']
a, b = chapter('# THE INTERNAL REFERENCE AND PUBLICATION RECORD', 1, stop_prefixes=('# ',))
rtxt = substitute('\n'.join(M[a-1:b-1])).rstrip() + '\n'
rtxt = re.sub(r'## The Recent Posts, Organized by Codex Region.*?(?=\n## )', '', rtxt, flags=re.S)
refs.append(rtxt)
c0 = [k for k, l in enumerate(C) if l.startswith('# References and Sources')][0]
refs.append('\n' + '\n'.join(x for x in C[c0+1:] if x.strip() != 'End of manuscript.').rstrip() + '\n')
refs_txt = '\n'.join(refs)

closing = ['# THE CLOSING STATEMENT\n', prose('closing.md'),
           '## Build receipts, from the run that sealed this document\n',
           f'- Lean 4.19.0, modular build, five modules, exit codes and seconds: ' + '; '.join(f'Codex{n} {lean_receipts[n]}' for n in range(1,6)) + f'. Errors: {errors}. `#guard_msgs` receipts: {guards}, every FORGE-addition theorem carrying its cone receipt. The environment audit (twenty-three declared posits, nothing outside the roster) and the crosswalk audit (129 rows, 0 unresolved) are both `#guard_msgs`-guarded, so both ran silent, which is the pass.',
           f'- gfortran 13.3.0, `-std=f2018 -O2 -fno-fast-math -ffp-contract=off`, exit 0: ' + ' · '.join(x.strip() for x in twin_lines[:8]),
           f'- Verbatim integrity: {len(ledger["chapters"])} carried chapters hashed in IV.3, each with its Master hash and its carried hash after the declared substitution.',
           f'- Census: {len(ids_master)} identifiers named by the Master, all listed in IV.2: {counts["full card"]} full cards, {counts["code stub"]} code stubs, {counts["ledger row"]} ledger rows, {counts["removed"]} removed under S1 to S4.',
           f'- Cards, counted by rule (a card is a bold header or flagship head carrying a coordinate identifier): {n_cards} in Part II, of which {len(meta2["new_cards"])} were extracted from the Mother in this edition with their grade lines byte for byte; every kernel-pinned grade in the text equals its pin (`FENCE.global`).',
           f'- Crosswalk closure: 129 rows, 0 unresolved, audited in the kernel.',
           f'- One census, one hash: the sorted identifier list of IV.2 and IV.5 has sha256 `{hashlib.sha256(json.dumps(ids_master).encode()).hexdigest()}`; the preimage is the UTF-8 text of the JSON array json.dumps(sorted(ids)) with default separators, the identifiers being exactly those listed in IV.5, so any reader can recompute it; a copy of this edition that prints other totals is another edition. Sealing run 2026-09-23, edition v4.0.4, post external rounds 1 to 4.',
           f'- Hedge scan: new prose {ledger["hedge"]["new prose"]}; carried text {ledger["hedge"]["Part I (carried)"] + ledger["hedge"]["Part II"] + ledger["hedge"]["Part III"]} lexicon hits, each classified in IV.3 as a permissive modal, the critic\'s voice, or a named boundary term; the carried text is verbatim and none of the hits softens a claim.',
           f'- Fences: FENCES blocks in Part II {fence_x_p2}; retired {len(retired)} with codes; scope survivors 2; verdict [X] tokens in Part II {part2_txt.count("[X]")}; [.] seats as listed.',
           '\nA build that halts anywhere has not passed. This one reached its final line.\n', prose('epitaph.md')]
closing_txt = '\n'.join(closing)

# ---------------- front matter and assembly
front = open(P + 'front.md', encoding='utf-8').read()
doc = front + '\n' + prose('prologue.md') + '\n' + prose('intro.md') + '\n' + part1_txt + '\n' + part2_txt + '\n' + part3_txt + '\n' + part4_txt + '\n' + code_txt + '\n' + refs_txt + '\n' + closing_txt
open('/tmp/forge/out/TRISDUCTION_Master_Codex_v4_0_4.md', 'w', encoding='utf-8').write(doc)
print('doc bytes', len(doc.encode()))
print('parts', {k: len(v.encode()) for k, v in [('intro', prose('intro.md')), ('I', part1_txt), ('II', part2_txt), ('III', part3_txt), ('IV', part4_txt), ('code', code_txt), ('refs', refs_txt), ('closing', closing_txt)]})
print('hedge', ledger['hedge'])
print('census', counts, 'ids', len(ids_master))
print('lean receipts', lean_receipts, 'errors', errors, 'guards', guards)
json.dump({'hits_new': hits_new, 'hits_p1': hits_p1[:50], 'hits_p3': hits_p3[:50]}, open('/tmp/forge/out/hedge_report.json', 'w'), ensure_ascii=False, indent=1)
