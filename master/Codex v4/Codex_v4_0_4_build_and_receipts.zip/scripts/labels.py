import re, json

KEY = {}
for l in open('/tmp/CL.md', encoding='utf-8').read().split('\n'):
    m = re.match(r'^\| `(P-[A-Z0-9-]+)` \| .*? \| ([A-Za-z0-9-]+) \|\s*$', l)
    if m:
        KEY[m.group(2)] = m.group(1)

PREFIX = re.compile(r'^(APEX-PSP-|MD-PSP-|sPSP-|RAF-PSP-|CN-PSP-|GM-PSP-|SM-PSP-|PSP-)')
FILLER = {'MASTER', 'VERDICT', 'LAW', 'PROTOCOL', 'UNION', 'COMPARATIVE', 'BARRIERS', 'BLOCKS', 'REGISTER', 'THE', 'OF', 'AND'}
ABBR = {'GROUNDLESS': 'GRNDLESS', 'EXECUTION': 'EXEC', 'PHYSICAL': 'PHYS', 'UNPROVABILITY': 'UNPROV', 'OUROBOROS': 'OUROB',
        'SUSPENSION': 'SUSP', 'TERMINALITY': 'TERMINAL', 'EMBODIED': 'EMBOD', 'MINDSET': 'MIND', 'PARALLEL': 'PAR',
        'APERTURE': 'APE', 'HALT': 'HAL', 'WITNESS': 'WIT', 'LIFEBOAT': 'LIF', 'COMPOSITE': 'COMP', 'TRIUNE': 'TRI',
        'PROCLAMATION': 'PRO', 'MIRROR': 'MIR', 'LEDGER': 'LED', 'ADMISSION': 'ADMIT', 'CONSTITUTIVE': 'CONSTIT',
        'INSEPARABLE': 'INSEP', 'STANDPOINT': 'STANDPT', 'PRECEDENCE': 'PRECED', 'UNRESTRICTED': 'UNRESTR',
        'IMPOSSIBLE': 'IMPOSS', 'DEFEATERLESS': 'DEFEATLESS', 'TERMINUS': 'TERM', 'SYNTHESIS': 'SYNTH', 'FIXATION': 'FIX',
        'GROUNDING': 'GROUND', 'ABSOLUTE': 'ABSOLUTE', 'POSITIVITY': 'POSITIV', 'RESERVOIR': 'RESERV', 'STILLNESS': 'STILL',
        'UNLETTERED': 'UNLETTER', 'UNMARKED': 'UNMARKED', 'HIERARCHY': 'HIERARCH', 'COMPLETE': 'COMPL', 'CLOSURE': 'CLOS',
        'EXHIBIT': 'EXHIB', 'ANCHOR': 'ANCHOR', 'CENSOR': 'CENSOR', 'CIRCLE': 'CIRCLE', 'CROSSING': 'CROSS',
        'INSEPARABILITY': 'INSEP', 'DISCRIMINATOR': 'DISCRIM', 'POSITION': 'POS', 'ARRIVAL': 'ARRIV', 'CUSTODY': 'CUSTODY',
        'MEASURE': 'MEAS', 'ALIGNMENT': 'ALIGN', 'SERVANT': 'SERV', 'WRITTEN': 'WRIT', 'DENIAL': 'DENIAL', 'POSIT': 'POSIT',
        'EQUALITY': 'EQ', 'RETURN': 'RETURN', 'LOCUS': 'LOCUS', 'FLOOR': 'FLOOR', 'SUPPLY': 'SUPPLY', 'SPECIES': 'SPEC',
        'NATURE': 'NATURE', 'CEILING': 'CEIL', 'BLESSED': 'BLESSED', 'UNFORGIVABLE': 'UNFORGIV', 'SPECIAL': 'SPECIAL',
        'AFFINITY': 'AFFINITY', 'IMPORT': 'IMPORT', 'SCREEN': 'SCREEN', 'DEMAND': 'DEMAND', 'TRIAD': 'TRIAD', 'SOURCE': 'SRC',
        'BLOCK': 'BLOCK', 'THREE': 'THREE', 'BITS': 'BITS', 'ROWS': 'ROWS', 'WIDTH': 'WIDTH', 'FREEDOM': 'FREEDOM',
        'GRADE': 'GRADE', 'GENUS': 'GENUS', 'NOMOS': 'NOMOS', 'NAVIER': 'NAVIER', 'HODGE': 'HODGE', 'ISLAM': 'ISLAM',
        'ELYON': 'ELYON', 'TONGUE': 'TONGUE', 'UNCLOSED': 'UNCLOSED', 'OBEDIENCE': 'OBED', 'FOLD': 'FOLD', 'BEND': 'BEND',
        'LOGOS': 'LOGOS', 'ONLY': 'ONLY', 'TOKEN': 'TOKEN', 'ONE': 'ONE', 'CUT': 'CUT', 'BIT': 'BIT', 'KEYSTONE': 'KEYSTONE',
        'DUAL': 'DUAL', 'GROUND': 'GROUND', 'LADDER': 'LADDER', 'BAR': 'BAR', 'BARRIER': 'BARRIER', 'CLERK': 'CLERK',
        'INVERSION': 'INVERSION', 'FRAME': 'FRAME', 'MATH': 'MATH', 'ROW': 'ROW', 'GOL': 'GOL', 'RH': 'RH', 'NG': 'NG',
        'RA': 'RA', 'RAM': 'RAM', 'CH': 'CH', 'IAM': 'IAM', 'READ': 'READ', 'IMPRINT': 'IMPRINT', 'GOLF': 'GOLF'}

HARD = {'MASTER', 'VERDICT', 'LAW', 'PROTOCOL', 'UNION', 'THE', 'OF', 'AND'}
SOFT = ['COMPARATIVE', 'BARRIERS', 'BLOCKS', 'REGISTER', 'COMPLETE', 'SYNTHESIS', 'CASCADE', 'CLOSURE']

def derive(native):
    if native in KEY:
        return KEY[native]
    m = re.match(r'^(.*?)-(\d{2})$', native)
    stem, num = (m.group(1), str(int(m.group(2)))) if m else (native, '1')
    stem = PREFIX.sub('', stem).replace('Ξ', 'XI')
    words = [w for w in stem.split('-') if w and w not in HARD] or stem.split('-')[:1]
    def fit(ws):
        s = '-'.join(ws)
        return s if 0 < len(s) <= 12 else None
    cand = fit(words)
    if not cand:
        cand = fit([ABBR.get(w, w) for w in words])
    if not cand:
        ws = [w for w in words if w not in SOFT] or words
        cand = fit(ws) or fit([ABBR.get(w, w) for w in ws])
        words = ws
    if not cand:
        aw = [ABBR.get(w, w) for w in words]
        cand = fit(aw[:3]) or fit(aw[:2]) or fit([aw[0][:8], aw[1][:3]] if len(aw) > 1 else [aw[0][:12]]) or aw[0][:12]
    return f'P-{cand}-{num}'

def build_map(ids):
    mp, used = {}, {}
    for i in sorted(ids):
        if i in KEY:
            mp[i] = KEY[i]; used[KEY[i]] = i
    for i in sorted(ids):
        if i in mp: continue
        lab = derive(i); base = lab; k = 2
        while lab in used:
            lab = re.sub(r'-(\d+)$', lambda m: '-' + m.group(1) + chr(64 + k), base); k += 1
        used[lab] = i; mp[i] = lab
    return mp

if __name__ == '__main__':
    ids = json.load(open('/tmp/forge/out/ids.json'))
    mp = build_map(ids)
    json.dump(mp, open('/tmp/forge/out/labels.json', 'w'), indent=1)
    for i in sorted(ids):
        print(f'{mp[i]:22} <= {i}' + ('' if i in KEY else '   [derived]'))
