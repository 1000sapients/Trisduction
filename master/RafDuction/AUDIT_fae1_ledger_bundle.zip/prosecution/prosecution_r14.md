# Default Audit · round 14 · registers kinematic and definitional · re-run of the voided round-13 pass
Object: the seeded copy of the relation-claim engine deck v1.0.11, a self-contained universe. Mandatory targets carried from round 12: the census tolerance clause and the limit sentence, the fallback reason texts and the output law's sentences on them, the fault-injection battery and its sentence, the round-twelve record stanza.

Recomputed and agreeing: the floor at 4503.6 times the unit roundoff, a spread at the floor resolved to one part in 4504; the fault-injection battery true; the fallback reason naming three causes it does not tell apart; the round-twelve stanza's figures.

P1 · definitional · target: the output law's trace sentence and the output-battery sentence · STRUCTURAL
Mechanism: 2 sentences say a raising reading's trace keeps "the checks it passed". Executed on a registration reading whose claim is a list: the engine raises AttributeError inside the fourth typing check, after the trace recorded that check as reached. The trace reads ['L0', 'L1', 'L2', 'L3', 'L4', 'L0']: the fourth typing check is in it and was never passed. The trace keeps every check reached, the raising one included.
Minimal falsifier: run a registration reading with claim ["x"] and compare its trace with the sentences.

P2 · count slip found in passing · target: the pipeline section
Mechanism: "parses and types the claim, L0 through L5". The same section then says the fifth and sixth typing checks run after routing, so the fifth is counted twice.
Minimal falsifier: list the labels the section assigns before and after routing.

P3 · drift found in passing · target: the grounding section
Mechanism: "its energy floor, here meaning the lowest grade in the vocabulary". The energy floor is a physical lower bound on kinetic energy; the lowest grade is a rank in the warrant vocabulary. One phrase names two unrelated objects.
Minimal falsifier: compare with the grade vocabulary's own lowest entries.

P4 · scope found in passing · target: the typing stage's first check
Mechanism: "every variable whatever counting as a system". The document defines a system as a variable taking at least two distinguishable values, and routes a determinate proposition, entropy zero, away as relating nothing.
Minimal falsifier: enter a constant variable and read the router's verdict.

Targets examined without finding: the census tolerance clause, the limit sentence, the fallback reason texts, the fault-injection battery, the round-twelve record stanza.
