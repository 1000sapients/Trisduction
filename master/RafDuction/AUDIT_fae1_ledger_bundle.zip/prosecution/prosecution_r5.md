# Default Audit · round 5 · registers kinematic and definitional
Object: the seeded copy of the relation-claim engine deck v1.0.4, a self-contained universe. Mandatory targets from round 4: trace recording and the sampled-path order, the world uniqueness aperture emission and its scoping text, the typing-only instrument's availability and its Part 5 sentence, the output batteries and their Part 4 sentence, the floor wording, the pipeline-order text and description, the admissibility guard label, the round-four record stanza.

Headline counts recomputed from the code and agreeing: 51 controls, 22 guards, 71 symmetry variants.

P1 · definitional · target: the typing-only instrument's availability sentence in Part 5 · STRUCTURAL
Mechanism: the sentence says that on an admissible reading the instrument lists no token the face decision cannot reach. Executed: on the 2x3 law with registration asserted the adjudicator emits the sealed token, and the typing-only instrument lists the sealed token and [X]; on an independent law with the same assertion the adjudicator emits [X] and the instrument lists the same pair. On each of these admissible readings exactly one token is reachable, and the instrument lists two. The sentence reads availability per reading, while the instrument types availability per face.
Minimal falsifier: type the 2x3 registration reading and compare its listed tokens with what that reading can emit.

P2 · kinematic · target: the output-battery sentence in Part 4 · STRUCTURAL
Mechanism: the sentence says the typing-only instrument lists the emitted token on "all twenty-two controls that reach a face decision or the admissibility of its instrument". Executed, the controls that reach a face decision or an admissibility check number 24: nineteen face decisions, the absent-law control, the three admissibility controls at the first admissibility check, and the work cap. The battery checks 22 of them. The class described is not the class counted.
Minimal falsifier: count the controls labelled at a face decision or at an admissibility check.

P3 · definitional · target: the typing stage's fifth typing · STRUCTURAL
Mechanism: the sentence says that on the uniqueness, exteriority, and no-exterior-agent faces the grade depends on whether D names a supplied fixed point or the world-domain. Executed: uniqueness carries analytic fixed and premise at the world, but exteriority and no-exterior-agent carry premise at both readings. For two of the three faces the grade does not depend on the reading; the decision does.
Minimal falsifier: emit the exteriority and no-exterior-agent verdicts at both readings and compare their grades.

P4 · definitional · target: the face table's registration row against the availability sentence · STRUCTURAL
Mechanism: the availability sentence says the typing-only row follows the face table "the exchangeability guard included". The table's registration row lists exact and sampled tokens and never mentions the guard, while the typing-only instrument returns "[?] until the draws are declared exchangeable" on undeclared draws. The table the instrument is said to follow does not contain what the instrument follows.
Minimal falsifier: search the registration row for the guard.

P5 · kinematic · target: the fail-safe law, "no crash" · LOAD-BEARING
Mechanism: the deletion fuzz removes keys and never supplies a key with an explicit null. Executed: setting each key of each of the eight positive controls to null, 148 substitutions, crashed the engine 27 times, TypeError on domain and relata, AttributeError on claim and screen. A supplied reading carrying one null value raises rather than routing under-determined. The fuzz also reported seals standing on keys the face reads, a count this pass could not separate from its own lookup of the irrelevant-key table and so files only as the crash.
Minimal falsifier: run the no-exterior-agent control with its domain set to null.

P6 · slip found in passing · target: the pipeline section
Mechanism: "Seal G runs the fourteen gates". The gate table has twelve rows and twelve directed edges.
Minimal falsifier: count the table's rows.

P7 · drift found in passing · target: the typing stage's second typing
Mechanism: "where a face means one side of the claim-slot triangle". A face is defined as the claim type, nine of them, and here the word names a side of a triangle.
Minimal falsifier: compare with the routing supply paragraph's list of faces.

P8 · scope found in passing · target: the second-order blindness row
Mechanism: "on every law, finite or not, the exact complement instrument decides the case at theorem grade". The exact instrument reads supplied finite laws in exact fractions and cannot read an infinite law.
Minimal falsifier: ask what exact table an infinite law supplies.

Targets examined without finding: trace recording and the sampled-path order, the world uniqueness aperture emission and its scoping text, the floor wording, the pipeline-order text and description, the admissibility guard label, the round-four record stanza.
