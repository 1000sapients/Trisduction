# Default Audit · round 6 · registers kinematic and definitional · re-run of the voided round-5 pass
Object: the seeded copy of the relation-claim engine deck v1.0.4, a self-contained universe. Mandatory targets carried from round 4: trace recording and the sampled-path order, the world uniqueness aperture emission and its scoping text, the typing-only instrument's availability and its Part 5 sentence, the output batteries and their Part 4 sentence, the floor wording, the pipeline-order text and description, the admissibility guard label, the round-four record stanza.

Headline counts recomputed from the code and agreeing: 51 controls, 22 guards, 71 symmetry variants.

P1 · definitional · target: the typing-only instrument's availability sentence in Part 5 · STRUCTURAL
Mechanism: the sentence says that on an admissible reading the instrument lists no token the face decision cannot reach. Executed: with registration asserted on the 2x3 law the adjudicator emits the sealed token and the instrument lists the sealed token and [X]; on an independent law the adjudicator emits [X] and the instrument lists the same pair. Each admissible reading can reach exactly one of the two, so the sentence reads availability per reading where the instrument types it per face.
Minimal falsifier: type the 2x3 registration reading and compare its listed tokens with what that reading can emit.

P2 · kinematic · target: the output-battery sentence in Part 4 · STRUCTURAL
Mechanism: the sentence describes the battery's class as "all twenty-two controls that reach a face decision or the admissibility of its instrument". Executed, controls labelled at a face decision or an admissibility check number 24; the battery checks 22, leaving out the absent-law and the inadmissible-law controls.
Minimal falsifier: count the controls labelled at a face decision or at an admissibility check.

P3 · definitional · target: the typing stage's fifth typing · STRUCTURAL
Mechanism: the sentence says that on the uniqueness, exteriority, and no-exterior-agent faces the grade depends on whether D names a supplied fixed point or the world-domain. Executed, uniqueness grades analytic and premise, while exteriority and no-exterior-agent grade premise at both readings. For those two faces the decision depends on the reading, not the grade.
Minimal falsifier: emit both exteriority faces at both readings and compare grades.

P4 · definitional · target: the face table's registration row · STRUCTURAL
Mechanism: the availability sentence says the typing-only row follows the face table including the exchangeability guard. The registration row never mentions the guard, while the typing-only instrument returns "[?] until the draws are declared exchangeable" on undeclared draws.
Minimal falsifier: search the registration row for the guard.

P5 · kinematic · target: the fail-safe law's "no crash" · LOAD-BEARING
Mechanism: the fuzz removes keys but never supplies malformed values. Executed on the eight positive controls: an explicit null on single keys, 148 substitutions, crashed 27 times (TypeError on domain and relata, AttributeError on claim and screen); values of the wrong type, 592 substitutions, crashed 79 times, adding rows and stated_grade. A single malformed value raises instead of routing under-determined. Paired against deleting the same key, no null sealed where deletion does not.
Minimal falsifier: run the no-exterior-agent control with its domain set to null.

P6 · kinematic · target: the absence gate's basis read · LOAD-BEARING
Mechanism: paired against deletion, a wrong-type basis on an absence claim sealed where deleting the basis does not: 12 substitutions across the exact independence, disjoint-block closure, and fixed-point controls, with basis set to "x", 7, a list, or a dict. The gate breaks named lower-order bases and routes an absent basis under-determined, but any other value passes as if it named an admissible basis. An unread basis buys the seal.
Minimal falsifier: run the exact independence control with basis "x".

P7 · slip found in passing · target: the registration-at-the-law row
Mechanism: "I = 0.251629167388 bits" on rows (1/6, 1/4, 1/12) and (1/6, 1/12, 1/4). From the printed cell ratios, two cells give zero bits, two give log2(3/2) at weight 1/4, two give minus one bit at weight 1/12: 0.5 log2(1.5) − 1/6 = 0.125815. The printed value is twice that.
Minimal falsifier: sum the six cell terms.

P8 · drift found in passing · target: the face table's aperture paragraph
Mechanism: "the aperture here being the exact work cap". The aperture sentence is defined in the same paragraph as the location of a non-exhibitional deciding input outside the axiom's reach, and the work cap is defined in the census as an enumeration bound. One word names two unrelated objects.
Minimal falsifier: compare the two definitions.

P9 · scope found in passing · target: the availability rows
Mechanism: "No seal on sampled independence, on the resolving-power floor [theorem]". The resolving-power floor is typed structural where the sampled instrument is described, and no theorem is cited for it.
Minimal falsifier: compare with the sampled instrument's paragraph.

Targets examined without finding: trace recording and the sampled-path order, the world uniqueness aperture emission and its scoping text, the floor wording, the pipeline-order text and description, the admissibility guard label, the round-four record stanza.
