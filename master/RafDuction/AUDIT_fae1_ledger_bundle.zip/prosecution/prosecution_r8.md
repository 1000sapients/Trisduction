# Default Audit · round 8 · registers kinematic and definitional
Object: the seeded copy of the relation-claim engine deck v1.0.6, a self-contained universe. Mandatory targets from round 7: the absence gate's basis vocabulary, the supply paragraph's claim fields and bridge flag, the round-seven record stanza.

Recomputed and agreeing: the five basis names return the tokens the gate row promises and any other name returns [?]; every key and claim field the adjudicator reads is named in the supply paragraph; the counts 51, 22, 19, 71, 221, 148 and 592, eight, and nine agree with the boot; the census values agree with the code; the census, the D0 digest, the Bartlett figures, the margin gate's smallest margin, and the FORGE row's not-reached line are printed where the text says.

P1 · kinematic · target: the census paragraph's printed margins · STRUCTURAL
Mechanism: the paragraph says every recorded verdict resting on a threshold clears it by a printed margin, naming the sampled seal at I = 0.526249 bits against η* = 0.016899 and the second-order seal at Bartlett 19.7385 against 11.3449. The recorded boot prints the Bartlett pair. It prints the sampled row's token, label, and grade and neither the sampled I nor its floor anywhere. One of the two margins called printed is not printed.
Minimal falsifier: search the recorded boot output for 0.526249 and 0.016899.

P2 · arithmetic slip found in passing · target: the reach law's first router bit
Mechanism: "invariant under variation of its members and therefore of entropy one bit". A quantity invariant under every variation of its members carries no uncertainty, entropy zero; invariance does not give one bit.
Minimal falsifier: compute the entropy of a variable that takes one value.

P3 · drift found in passing · target: the pipeline section
Mechanism: "the Form here meaning the supplied joint law". The same section names the screening stage as the stage that screens; here the word names the law under test.
Minimal falsifier: compare with the section's own list of stages.

P4 · scope found in passing · target: the exact instrument
Mechanism: "The magnitude is exact on every supplied law". Mutual information of a finite law is a sum of rational multiples of base-two logarithms of rational ratios, exact in the document's fractions only when every ratio is a power of two; otherwise it is floating evidence.
Minimal falsifier: compute the exact value on the 2x3 law, whose ratios include 3/2.

Targets examined without finding: the basis vocabulary, the supply paragraph, the round-seven record stanza.
