# Default Audit · round 11 · registers kinematic and definitional
Object: the seeded copy of the relation-claim engine deck v1.0.9, a self-contained universe. Mandatory targets from round 10: the census clause on the zero-variance floor, the limit battery's translations, the margin gate at 32 and its chain sentence, the round-ten record stanza.

Recomputed and agreeing: the gate's count of 32; the limit battery's printed translations, 1e9 [LOCK] and 1e13 zero-variance; the round-ten record stanza.

P1 · kinematic · target: the census clause on the zero-variance floor · STRUCTURAL
Mechanism: the clause says a row can be pushed below the floor "by scale or by offset". The floor is a row's standard deviation over its largest magnitude, and rescaling multiplies both. Executed on the recorded Gaussian rows: the ratio reads 4.502367838e-01 at scales 1e-13, 1, and 1e13 alike, while offsets move it to 7.1e-10 at 1e9 and 7.1e-14 at 1e13. Within the range where the squares neither underflow nor overflow, no rescaling reaches the floor; the document's own symmetry battery holds every kernel control under rescaling by 1e-13 and 1e13. Outside that range the mechanism is underflow, not scale: rows rescaled by 1e-300 read zero-variance because their squares vanish.
Minimal falsifier: compute the ratio for the recorded rows at scales 1e-13 and 1e13.

P2 · definitional · target: the malformed-value route's reason · STRUCTURAL
Mechanism: executed, the second-order registration control with its rows rescaled by 1e300 returns [?] at L0 with "reading malformed: LinAlgError raised on a supplied value". The reading is well formed, a triad of finite rows; its arithmetic overflows. The reason names malformation where the cause is range.
Minimal falsifier: rescale the registration control's rows by 1e300 and read the reason.

P3 · count slip found in passing · target: the formal-alone section
Mechanism: "Four strips define the register". The section then names three: no energy load, no arrow, no sign.
Minimal falsifier: count the named strips.

P4 · drift found in passing · target: the gate section's tetrahedron
Mechanism: "the seal here meaning the sealed token". The fourth vertex is the verdict vertex the twelve directed edges run to and from; the sealed token is one of three outputs, not a vertex.
Minimal falsifier: compare with the gate table's edges from and to the seal.

P5 · scope found in passing · target: the reach law's second router bit
Mechanism: "and so no stationary system has any structure". Method-silence is a report about the instrument's reach; it licenses no claim about the object, which the same section says in so many words elsewhere.
Minimal falsifier: exhibit a stationary crystal lattice with structure and no interaction.

Targets examined without finding: the limit battery's translations, the margin gate and its chain sentence, the round-ten record stanza.
