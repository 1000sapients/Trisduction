# Default Audit · round 3 · registers limit and symmetry
Object: the seeded copy of the relation-claim engine deck v1.0.2, a self-contained universe. Mandatory targets from round 2: the census paragraph, the rank band, the independent channel, the height row's derivation and tool typing, the switch battery, the consistency-ledger sentences, the margin gate and chain sentences, the round-two record stanza.

P1 · limit · target: the fail-safe law, every supplied reading ends at a verdict or an honest under-determination · LOAD-BEARING
Mechanism: the uniqueness face enumerates every bipartition and subset of the supplied variables with no arity bound. Executed on copied-variable laws: 0.02 s at 8 variables, 0.08 s at 10, 0.42 s at 12, 0.86 s at 13, cost doubling per added variable. Extrapolated, a 30-variable law with two support cells holds the engine about 35 hours, and a 40-variable law about 4 years. A small supplied reading can deny any verdict in practical time.
Minimal falsifier: run the uniqueness face on 30 copied variables under a one-minute limit.

P2 · limit · target: the rank band added in round two · STRUCTURAL
Mechanism: at the declared 1000 permutations and level 0.99, the quantile rank is 989 and the upper band rank is 989 + 3·√(9.9) = 998.44. The code clamps it to index 999, the sample maximum (executed). The declared three-sigma band is truncated on the side that decides a seal, so it is no three-sigma band at these counts.
Minimal falsifier: compute the upper band rank at the declared counts and compare it with the largest index.

P3 · symmetry · target: the exhibition lemma's reach · STRUCTURAL
Mechanism: the lemma is proved for a record variable appended to a supplied law. The row then asserts that no exhibition can supply the uniqueness falsifier, a claim about the practice of exhibiting systems. No sentence maps an act of exhibition onto a record variable with positive mutual information, and none states that map's warrant. An abstract object and a practice are conflated without a stated bridge.
Minimal falsifier: locate the stated map from an exhibition to the appended variable and the grade it carries.

P4 · limit · target: the uniqueness falsifier quoted in the exhibition row · STRUCTURAL
Mechanism: the quoted falsifier is "two systems with zero mutual information and no chain connecting them". Executed on a law of one copied pair and an independent fair bit Z: I(Z; X1) = 0, and Z is a singleton block connected to nothing, yet the uniqueness face seals one domain on that law. Under the document's own membership rule, the falsifier as quoted is met by a law whose uniqueness the engine seals.
Minimal falsifier: run the uniqueness face on the copied pair with an independent bit and test the quoted condition on Z and X1.

P5 · symmetry · target: the no-energy strip · STRUCTURAL
Mechanism: the strip section reads that no energy loads any verdict. Executed: with an energy rider present gate twelve returns [X], and with the rider deleted the same reading returns the sealed token; the router also routes on declared energetic content. The verdict depends on the presence of energetic content by design. The strip's wording and the gate agree only if the strip excludes energy values and not the presence of energetic content, and the text never says so.
Minimal falsifier: run the gate-twelve reading with and without the rider.

P6 · limit · target: the sampled instrument's seal, and the fail-safe law behind it · LOAD-BEARING
Mechanism: the permutation null and Wilks' law both assume exchangeable draws. The sampled path reads no declaration of exchangeability. Executed on two independent three-valued chains that switch value at rate 0.02, N = 600, the sampled face sealed registration in 22 of 24 trials, against a nominal false-seal rate of at most one percent. An under-specified sample buys a seal.
Minimal falsifier: repeat the persistent-chain trials and count seals.

P7 · symmetry · target: the margin gate added in round two · STRUCTURAL
Mechanism: the gate recomputes the kernel's collapse floor from literals, unit roundoff written as a decimal and a row count of 24, instead of reading the floor the kernel actually used. If the row length changed, or the platform's epsilon differed, the gate would pass a margin against a floor the kernel never applied.
Minimal falsifier: change the row length of a gated exhibit and compare the gate's floor with the kernel's.

P8 · slip found in passing · target: the reach law's first router bit
Mechanism: "has entropy zero, and I(P;S) ≤ H(P) = 1, so it relates nothing". An entropy of zero gives a bound of zero, and a bound of one would not show that it relates nothing.
Minimal falsifier: substitute the stated entropy into the bound.

P9 · drift found in passing · target: the typing stage, first typing
Mechanism: "registration at the law, here called the single event". The single event is defined elsewhere as one cell of the law, the thing registration is not read at; here the phrase names the law itself.
Minimal falsifier: compare with the typing rule's own next clause.

P10 · scope found in passing · target: the supply paragraph
Mechanism: "adjudicates every relation claim about any system, supplied or not". The same paragraph and the reach law restrict the engine to supplied readings on supplied laws. The quantifier is widened past the instrument's reach.
Minimal falsifier: run the engine on a claim with no law supplied and read the token.

Targets examined without finding: the census paragraph's family description, the independent channel, the height row's derivation and tool typing, the switch battery, the consistency-ledger sentences, the round-two record stanza.
