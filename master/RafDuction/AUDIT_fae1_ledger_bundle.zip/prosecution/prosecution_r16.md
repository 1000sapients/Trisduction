# Default Audit · round 16 · registers parameter and provenance
Object: the seeded copy of the relation-claim engine deck v1.0.12, a self-contained universe. No additions were declared by round 15.

Parameter battery, run and agreeing: every numeric literal on the verdict path is a formula constant or a stated value, the typing count 3, Bartlett's (2p + 5)/6 with p = 3, the fifty-digit escalation, the work estimate's factor 3 and its overflow clamp, the quantile routine's 200 bisection steps; every census key is stated in the census paragraph; every battery parameter, the rescalings, the translations, the thirty-variable law, the 1000-permutation band test, is stated where the battery is described.
Provenance battery, run and agreeing: the chain recorded with the typing hook present equals the chain of a run in a directory with the hook absent, its row reading not reached; the sampled seal is typed conditional on the supplied exchangeability declaration in the text and in its emitted reason; the fallback route leaves the cause of a raise open; the calibration ledger is typed a consistency ledger at corroboration grade with no witness weight; the hook's row is typed session evidence and never hashed; a malformed exchangeability declaration is reported unread. No finding against the spine.

P1 · arithmetic slip found in passing · target: the exact instrument's domain count
Mechanism: "a law with b components carries 2^b nonempty domains". Domains are the unions of components, 2^b sets counting the empty union, so the nonempty ones number 2^b − 1; the same document's root screen counts four fixed points and three nonempty domains on two copied pairs.
Minimal falsifier: list the unions of two components.

P2 · drift found in passing · target: the supply paragraph
Mechanism: "a domain here meaning the joint law's alphabet". A domain is a set of systems closed under the membership rule; an alphabet is the value set of one variable.
Minimal falsifier: compare with the exact instrument's definition of a domain.

P3 · tier slip found in passing · target: the grounding section
Mechanism: "its universal extension theorem-grade". The same section and the grade paragraph carry the universal extension at premise grade, protected as premise by theorem and never promoted.
Minimal falsifier: compare with the grades paragraph.
