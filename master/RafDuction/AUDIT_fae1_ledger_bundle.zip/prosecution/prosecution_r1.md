# Default Audit · round 1 · registers kinematic and definitional
Object: the seeded copy of the relation-claim engine deck, read as a self-contained universe. Axioms held fixed; terminology not relitigated; only internal contradictions and arithmetic.

P1 · definitional · target: the constitution's statement of what its axiom is the face of · LOAD-BEARING
Mechanism: the front matter calls the axiom "the interaction face of the root" and the text uses "the root" in eleven places, yet no sentence names or defines the object the axiom is a face of. At the height row the text types "the root" as "premise-grade by theorem", a designation defined nowhere in the document and not the grade the constitution gives the axiom's one posit, which it calls a posit at premise. One word carries two referents, the axiom and an unnamed parent, and one of them is graded by an undefined phrase. Either the posit is silently upgraded or the referent silently switches.
Minimal falsifier: find in the document a definition of the parent object and of "premise-grade by theorem" consistent with the posit's stated grade.

P2 · definitional · target: the grades of the axiom's two exteriority consequences · LOAD-BEARING
Mechanism: the constitution says the no-exterior-agent and no-structured-exteriority consequences stand on the posit and that every grade is carried from the cited chapter unchanged. Executed on the copied-pairs law, the exteriority and no-exterior-agent faces emit grade "analytic" at a supplied fixed point, above the posit's level. The height row then calls this split "enforced by gate nine" in the same paragraph that lists it as a reading owed to a ruling. A grade the constitution fixes is emitted above it, and a reading declared unratified is live.
Minimal falsifier: run both faces on the copied-pairs law and compare the printed grade with "stand on the posit".

P3 · definitional · target: the word "domain"
Mechanism: under the document's membership rule with whole-outside closure, a domain is any set satisfying the rule. On two independent copied pairs the rule has three nonempty solutions, each pair and their union (executed by brute force in a second representation). The Number section and the uniqueness face call the finest blocks "domains" and report b = 2. One word names two objects. The uniqueness verdict survives only because 2^b - 1 equals 1 exactly when b = 1, which the document never states.
Minimal falsifier: count nonempty solutions on the copied-pairs law, 3, against "two domains".
Severity: STRUCTURAL.

P4 · kinematic · target: the self-indexing arithmetic
Mechanism: the calibration row "a 3-bit system indexes all its properties" prints "8 binary properties against 3 indices at k = 3". Three binary state variables give 2^3 = 8 distinguishable states and 2^8 = 256 binary properties of those states (executed). The printed pair counts the bits as the indices. The refusal survives at either count; the printed numbers do not follow from the label beside them.
Minimal falsifier: count subsets of the state set of a three-bit system.
Severity: STRUCTURAL.

P5 · definitional · target: the grade vocabulary
Mechanism: the document prints the grades "operational", "corroboration", and "theorem-conditional", and ranks "analytic" equal to "theorem" without defining it. The grade gate ranks only premise, structural, engineering, conditional, analytic, and theorem, so a claim stated at any of the first three routes "stated grade unread" (executed on a direction claim).
Minimal falsifier: run the grade gate on a direction claim stated at "corroboration".
Severity: STRUCTURAL.

P6 · definitional · target: the word "token"
Mechanism: "token" names a single event in the typing rule ("registration at the law not the token", "false at the token", "a claim reading registration off a token is broken") and names the emitted verdict symbol in the emission law ("prints the token, the label", "no direction token", "a routing token"). Read with the second sense, the typing rule forbids reading registration off a verdict symbol, a different rule.
Minimal falsifier: substitute the emission-law sense into the typing rule and read whether its meaning changes.
Severity: STRUCTURAL.

P7 · definitional · target: the exteriority decision's mechanism
Mechanism: the exteriority decision prints "registration places it inside" without testing whether the named D satisfies the membership rule. On the exhibitor control the named D is not closed, since its outside registers with it. On the 2x3 law a singleton D = {A} is no solution at all (executed). Both print "places it inside the domain". The verdict symbol survives; the mechanism names a domain the reading does not contain.
Minimal falsifier: run the exteriority face with D = {A} on the 2x3 law and test D against the membership rule.
Severity: STRUCTURAL.

P8 · kinematic · target: the control census in Part 4
Mechanism: eight, seven, twelve, three, and nineteen sum to 49 against the printed 47 (executed).
Minimal falsifier: add the five printed counts.
Severity: STRUCTURAL.

P9 · definitional · target: the typing stage, second rule
Mechanism: "the slots here being the three faces of the claim". "Face" is defined elsewhere as the claim type, nine of them. Here the word names the three claim-slots, an incompatible second sense introduced with no redefinition.
Minimal falsifier: count faces in the routing supply paragraph (nine) against "the three faces of the claim".
Severity: STRUCTURAL.

P10 · definitional · target: the exhibition row's grade on its random family
Mechanism: the exhibition row types its family of 120 random laws "theorem-grade on the family". The same document types the analogous random families at the coalition and uniqueness rows as corroboration. A sampled family is widened to theorem grade.
Minimal falsifier: compare the three family grades across the three rows.
Severity: STRUCTURAL.
