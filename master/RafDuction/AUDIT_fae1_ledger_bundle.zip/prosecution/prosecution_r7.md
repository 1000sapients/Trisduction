# Default Audit · round 7 · registers kinematic and definitional
Object: the seeded copy of the relation-claim engine deck v1.0.5, a self-contained universe. Mandatory targets from round 6: the typing-only availability sentence, the output-battery sentence, the fifth typing, the registration and gate-ten rows, the fail-safe wrappers and fuzz sentences, gate ten's basis vocabulary, the malformed fuzz and chain list, the round-six record stanza.

P1 · definitional · target: gate ten's basis vocabulary · STRUCTURAL
Mechanism: the gate-ten row names the lower-order bases "pairwise, per-outsider, or second-order" and says a basis the engine does not read routes [?]. Executed on an exact independence claim: "pairwise" [X], "second-order" [X], "atomic" [X], but "per-outsider" [?] "names no basis the engine reads". The row's own name for the per-system basis is one the engine refuses to read, while the name the engine reads, "atomic", appears in the coalition row's prose. The readable vocabulary, the two admissible bases complement and coalition beside the three lower-order ones, is stated nowhere, so the row's "a basis the engine does not read" has no stated referent.
Minimal falsifier: run an exact independence claim with basis "per-outsider" and compare the token with the row.

P2 · definitional · target: the supply paragraph · STRUCTURAL
Mechanism: the paragraph lists what the caller must supply and says that absent any of these the engine routes the stage under-determined. Executed against the keys the adjudicator reads: the claim itself, with its assertion, membership assertion, quantity, energy rider, lower bound, magnitude and partition fields, is not listed, and neither is the bridge flag gate twelve reads. A caller following the paragraph supplies no assertion and meets an under-determination the list never names.
Minimal falsifier: list the keys and claim fields the adjudicator reads and search the paragraph for each.

P3 · slip found in passing · target: the reach law's first router bit
Mechanism: "has entropy one bit, and I(P;S) ≤ H(P) = 0". An entropy of one bit gives a bound of one bit, not zero, and the zero bound is what the typing needs.
Minimal falsifier: substitute the stated entropy into the bound.

P4 · drift found in passing · target: the deletion fuzz sentence
Mechanism: "positive control, meaning a control whose expected token is [?]". The kill-matrix uses positive control for a control expected to seal; here the phrase names its opposite.
Minimal falsifier: compare with the controls the fuzz actually deletes from.

P5 · scope found in passing · target: the uniqueness row's grades
Mechanism: "Theorem-grade on the characterization and on the random family". A family of three hundred random laws corroborates; the same document types random families as corroboration elsewhere.
Minimal falsifier: compare with the coalition and exhibition rows' family grades.

Targets examined without finding: the typing-only availability sentence, the output-battery sentence, the fifth typing, the registration row, the fail-safe wrappers and fuzz sentences, the malformed fuzz and chain list, the round-six record stanza.
