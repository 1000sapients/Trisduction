# Default Audit · round 2 · registers parameter and provenance
Object: the seeded copy of the relation-claim engine deck v1.0.1, a self-contained universe. Mandatory targets from round 1: the parent-root paragraph of 1.1, the grade vocabulary of 1.4, the grade switch of the height row, the exteriority domain test with its new control, the round-one record stanza, the component and domain definition of 2.3.

P1 · parameter · target: the threshold and family census · STRUCTURAL
Mechanism: the sampled instrument's verdicts depend on a significance level, a permutation count, and a band multiplier; gate eight depends on a numeric tolerance; the second-order channel on a conditioning gate and a collapse floor; the random families on arity, alphabet, and generator. The prose states the band multiplier, the sampling floor, and the family sizes, and states no significance level, no permutation count, no tolerance, no conditioning constant, and no family arity. A reader cannot recompute the printed floor 0.016228 or the analytic floor behind it from the prose: at level 0.99 the analytic floor is 0.015962, at 0.95 it is 0.011407 (executed).
Minimal falsifier: reproduce the analytic floor of the sampled calibration row from the prose alone.

P2 · provenance · target: the sampled instrument's marginal band · STRUCTURAL
Mechanism: the prose declares "a three-standard-error Monte-Carlo band". The code computes the standard error from the asymptotic chi-square density at the analytic quantile, not from the permutation sample. On the sampled calibration row the code's band has width 0.005223 bits, while the distribution-free three-sigma rank band of the actual permutation sample has width 0.008200 (executed). The declared method and the operation diverge, and the operational band is narrower than the sample's own quantile uncertainty.
Minimal falsifier: compare the two band widths on the sampled calibration row.

P3 · provenance · target: the calibration ledger's evidential standing · STRUCTURAL
Mechanism: the ledger is presented as twelve instances "registered in the code before execution". Its first five instances re-read the four exhibit laws whose outcomes the root screen rows already analyse and print. Expectations written with those outcomes in view are retrodictive: the ledger checks the engine against its author's prior analysis, a closed loop, and carries no calibration weight beyond consistency.
Minimal falsifier: list the laws of calibration rows one to five and the screen rows that already print their outcomes.

P4 · provenance · target: corroboration of the fixed-point characterization and the exhibition lemma · STRUCTURAL
Mechanism: the three hundred, sixty, and one hundred twenty random-law counts are computed only by the block, fixed-point, and component routines, all built on the one factorization primitive that is also the object the counts corroborate. No independent channel recomputes a single decision in those loops. The corroboration is one road wearing three family sizes.
Minimal falsifier: recompute every factorization decision in the three families by an independent computation of the mutual information and count disagreements.

P5 · provenance · target: the height row's evidence for the first exteriority consequence being a restatement · STRUCTURAL
Mechanism: the row presents the external tool's refusal at its equivalence gate as the finding. The hook that calls the tool supplies the equivalence flag itself. The two-line derivation the flag stands for, substituting the registration biconditional into the closure axiom, is printed nowhere. The receipt echoes the author's input, and the argument that would carry it is absent.
Minimal falsifier: locate the printed equivalence derivation, or remove the flag and see what the tool returns.

P6 · parameter · target: the grade switch introduced in round one · STRUCTURAL
Mechanism: the height row asserts that flipping the switch re-runs three checks and moves the exteriority grades. No battery flips it, so the asserted behaviour is unexecuted, and a switch whose flip is never exercised can rot silently.
Minimal falsifier: flip the switch in a sandbox and read the exteriority grades and the boot counts.

P7 · kinematic slip found in passing · target: the typing stage's atomization rule
Mechanism: "I(A;A) = 2·H(A)". A variable's information with itself equals its entropy, not twice it.
Minimal falsifier: compute I(A;A) for a fair bit.

P8 · definitional drift found in passing · target: the gate section's vertex list
Mechanism: "the components S, Rg, Dm". Components are defined in the Number section as non-singleton finest blocks of a law; here the word names the claim-slots.
Minimal falsifier: compare the two definitions.

P9 · scope inflation found in passing · target: the reach law's first router bit
Mechanism: the bracket reads "theorem on the typing and on the bound". The typing of a determinate proposition as a zero-entropy variable is a typing, not a theorem; only the bound I ≤ H is theorem-grade.
Minimal falsifier: ask which theorem proves the typing.

Targets examined without finding: the 1.1 parent-root paragraph against the reach paragraph and the grade table; the 1.4 vocabulary against the Part 4 grade list; the exteriority domain test against the face table; the round-one stanza against the body; the component and domain definition against the coalition row.
