# Default Audit · round 15 · registers kinematic and definitional
Object: the seeded copy of the relation-claim engine deck v1.0.12, a self-contained universe. Mandatory targets from round 14: the trace wording in the output law and the output-battery sentence, the trace battery's raising-check assertion, the round-fourteen record stanza.

Recomputed against the code and the recorded boot, all agreeing: 51 controls by stage 8, 7, 12, 5, 19; 22 guards; 75 symmetry variants; 221 deletions; 148 null and 592 wrong-type substitutions; eight under-specified readings; 32 gated comparisons; the census values; the sampled seal's printed figures. The trace wording in both sentences names every check reached with the raising check included, and a list-valued claim's trace carries the fourth typing check second-to-last; the trace battery asserts it; the round-fourteen stanza describes exactly that change. No finding against the targets or the spine.

P1 · arithmetic slip found in passing · target: the typing stage's atomization check
Mechanism: "I(A;A) = 2H(A)". The mutual information of a variable with itself is its entropy, I(A;A) = H(A) − H(A|A) = H(A).
Minimal falsifier: compute I(A;A) for a fair bit, one bit.

P2 · drift found in passing · target: the pipeline section
Mechanism: "the grade, here meaning the firing check's position in the pipeline". The grade is the warrant tier from the fixed vocabulary, analytic, premise, engineering and the rest; the firing check is the label printed beside it.
Minimal falsifier: compare with the grade vocabulary.

P3 · scope found in passing · target: the no-sign strip
Mechanism: "gate seven breaks every claim about any dependence whatever". Gate seven breaks a claim that reads the sign; registration and independence claims pass it, as the face table shows.
Minimal falsifier: run a registration claim through gate seven.
