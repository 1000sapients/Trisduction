# Default Audit · round 12 · registers parameter and provenance
Object: the seeded copy of the relation-claim engine deck v1.0.10, a self-contained universe. Mandatory targets from round 11: the census clause on rescaling, offset, and underflow; the fallback route's reason texts; the round-eleven record stanza.

Recomputed and agreeing: the record stanza's ratio 0.450237; every census key stated in the census paragraph; gradual underflow as the clause says, the kernel locking at a scale of 1e-160 and reading zero-variance at 1e-170.

P1 · parameter · target: the census clause's rationale for the zero-variance floor · STRUCTURAL
Mechanism: the clause calls the floor of 10⁻¹² "the resolution of double arithmetic". The unit roundoff is 2.220446e-16, and the floor is 4503.6 times it. At the floor a row's spread is still resolved to about one part in 4504. The value is a tolerance set more than three orders above resolution; the stated rationale misstates the parameter it justifies.
Minimal falsifier: divide the census floor by the unit roundoff.

P2 · provenance · target: the fallback route's reason and the output law's sentences on it · STRUCTURAL
Mechanism: the fallback route catches every exception and its reason names two causes, a malformed reading or arithmetic outside the double range; the output law says a reading "whose value raises" routes there. Executed: with the factorization primitive replaced by one that raises, a well-formed registration reading returns [?] at L0 with "the reading is malformed or its arithmetic leaves the double range". A fault inside the engine is attributed to the supplied reading or to its range; the route cannot tell these causes apart and names only the supplier-side ones.
Minimal falsifier: inject a raising primitive and run a well-formed reading.

P3 · count slip found in passing · target: the verdict economy's grade sentence
Mechanism: "Grades travel in two fixed vocabulary". The section names one vocabulary and orders it; a second is never given.
Minimal falsifier: count the vocabularies the section lists.

P4 · drift found in passing · target: the uniqueness row
Mechanism: "a fixed point here meaning a single system". A fixed point of the membership rule is a set of systems, the unions of components that the same sentence counts.
Minimal falsifier: list the fixed points on two copied pairs.

P5 · scope found in passing · target: the no-arrow strip
Mechanism: "no direction is readable in any register whatever". The section scopes the claim to this register and names an arrow-bearing register as the supply for direction.
Minimal falsifier: compare with the same sentence's closing clause.

Targets examined without finding: the record stanza, the underflow clause.
