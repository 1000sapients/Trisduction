# Default Audit · round 4 · registers kinematic and definitional
Object: the seeded copy of the relation-claim engine deck v1.0.3, a self-contained universe. Mandatory targets from round 3: the exchangeability guard, the exact work cap and domain count, the band refusal and the 2000 count, the exhibition bridge and falsifier qualification, the isolated-system control, the energy-value sentence, the symmetry and limit batteries, the kernel floor reporting, the round-three record stanza.

Headline counts recomputed from the code: 51 controls (8, 7, 12, 5, 19), 22 guards, 71 symmetry variants, 2^51 = 2251799813685248, and the thirty-variable work 5368709120 above the cap: all agree with the prose. Near the cap, the uniqueness face on 18 copied variables (counted work 1.31e6 against 2e6) returned in 2.02 s: the cap bounds time.

P1 · kinematic · target: the sampling floor's stated inequality · STRUCTURAL
Mechanism: the sampled paragraph reads "a sampling floor at N ≥ 5rc routes [?]". Read as written, samples with N ≥ 5rc route under-determined. The code routes under-determined below the floor: executed at r = c = 3, N = 44 returns [?] at the floor and N = 45 proceeds to the statistic. The printed inequality states the admitted side as the refused side.
Minimal falsifier: run a 3-by-3 sample at N = 44 and at N = 45 and compare with the sentence.

P2 · definitional · target: the face table's aperture clause and the output law · STRUCTURAL
Mechanism: the face table and the output law both say every world-domain verdict on the uniqueness, exteriority, and no-exterior-agent faces carries exactly one aperture sentence with an afterimage fence behind it. Executed on all three world readings, the emitted reasons contain neither. The clause's content, a deciding input that is non-exhibitional and lies outside reach, also fits only the uniqueness verdict: the other two world verdicts rest on the axiom's own posit, which is inside the axiom and not outside its reach.
Minimal falsifier: emit the three world verdicts and search their reasons for the aperture sentence.

P3 · definitional · target: the output law's trace · STRUCTURAL
Mechanism: the output law promises "the trace of reached checks". Executed on a sealed registration reading, the trace is a single entry, the firing label. Nothing records the checks the reading passed, so the promised trace does not exist.
Minimal falsifier: print the trace of any sealed reading.

P4 · definitional · target: the typing-only instrument after round three · STRUCTURAL
Mechanism: the face table now lists the uniqueness face as "fixed [sealed] [X], above the cap [?]", and the sampled path cannot seal without an exchangeability declaration. Executed, the typing-only instrument still reports "[sealed] [X]" for a thirty-variable uniqueness law, where only [?] is reachable, and "[sealed] [?]" for a sampled registration reading with no declaration, where only [?] is reachable. The two instruments' availability rows disagree on the same readings.
Minimal falsifier: type the thirty-variable uniqueness reading and the undeclared sampled reading, and compare with what the adjudicator can emit.

P5 · kinematic slip found in passing · target: the supply paragraph
Mechanism: "the four claim-slots". The typing stage requires and counts three claim-slots.
Minimal falsifier: count the slots in the typing stage.

P6 · definitional drift found in passing · target: the reach law's second router bit
Mechanism: "A stationary system, meaning a law that factorizes". A stationary system is one in which nothing interacts over time. A factorizing law is independence of relata, a different predicate that the registration face already decides.
Minimal falsifier: exhibit a stationary system whose law does not factorize.

P7 · scope inflation found in passing · target: the no-sign strip
Mechanism: "no information-theoretic quantity whatever carries a sign". Pointwise information, which the typing stage itself calls negative inside a registering law, carries a sign, and so does interaction information. The universal claim contradicts the document.
Minimal falsifier: compute one pointwise value of minus one bit on the document's own 2x3 law.

Targets examined without finding: the exchangeability guard, the work cap and its domain count, the band refusal and the 2000 count, the exhibition bridge and falsifier qualification, the isolated-system control, the energy-value sentence, the symmetry and limit batteries, the kernel floor reporting, and the round-three record stanza, apart from P4.
