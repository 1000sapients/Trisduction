# Default Audit · round 13 · registers kinematic and definitional
Object: the seeded copy of the relation-claim engine deck v1.0.11, a self-contained universe. Mandatory targets from round 12: the census tolerance clause and the limit sentence, the fallback reason texts and the output law's sentences on them, the fault-injection battery and its sentence, the round-twelve record stanza.

Recomputed and agreeing: the floor at 4503.6 times the unit roundoff, a spread at the floor resolved to one part in 4504, "about 4500" in both census and record; the fault-injection battery true; the fallback reason naming three causes it does not tell apart.

P1 · definitional · target: the output law's trace sentence and the output-battery sentence · STRUCTURAL
Mechanism: both sentences say a raising reading's trace keeps "the checks it passed". Executed on a registration reading whose claim is a list: the engine raises AttributeError at the typing stage's fourth check, inside that check, after the trace recorded it as reached. The trace ends [L0, L1, L2, L3, L4, then the fallback label]: the fourth check is in the trace and was not passed. The trace keeps the checks reached, the raising one among them.
Minimal falsifier: run a registration reading with claim ["x"] and compare its trace with the sentence.

P2 · arithmetic slip found in passing · target: the kill-matrix paragraph
Mechanism: "nine at Seal L, seven at the router, twelve at the gates, five at admissibility, nineteen at the face decisions". The parts sum to 52 against the fifty-one controls the same sentence counts.
Minimal falsifier: add the five parts.

P3 · drift found in passing · target: the no-sign strip
Mechanism: "the sign of a dependence, here meaning its mutual information". Mutual information is the quantity that stays invariant under relabeling; the sign is the quantity that flips.
Minimal falsifier: relabel one alphabet of a two-by-two law and compare the mutual information and the covariance sign.

P4 · scope found in passing · target: the sampled instrument
Mechanism: "can seal registration on any draws, declared or not". The same paragraph routes undeclared draws to [?] before any statistic is computed.
Minimal falsifier: run a sampled registration reading with no exchangeability declaration.

Targets examined without finding: the census tolerance clause, the limit sentence, the fallback reason texts, the fault-injection battery, the round-twelve record stanza.
