# Default Audit · round 9 · registers parameter and provenance
Object: the seeded copy of the relation-claim engine deck v1.0.7, a self-contained universe. Mandatory targets from round 8: the boot line printing the sampled seal's margin, the census clause naming margins the boot prints, the round-eight record stanza.

Recomputed and agreeing: the boot line's figures equal the calibration row's own verdict figures, I = 0.526249 against η* = 0.016899 with both calibrations; the census clause's two margins are both printed; the round-eight stanza matches the change.

P1 · provenance · target: the sampled instrument's seal and its grade · STRUCTURAL
Mechanism: the permutation null and Wilks' law rest on exchangeable draws, and the document makes exchangeability a declaration the caller supplies. The instrument cannot check the declaration. Executed: twelve pairs of independent three-valued chains that switch value at rate 0.02, N = 600, declared exchangeable, sealed registration twelve times of twelve at grade engineering. No sentence, table cell, or emitted reason types the sampled seal as conditional on the supplied declaration; the seal's warrant silently includes a self-supplied flag the instrument trusts.
Minimal falsifier: run persistent independent chains declared exchangeable and read the token, the grade, and the reason.

P2 · provenance · target: the exchangeability guard's report · STRUCTURAL
Mechanism: executed, a declaration of False, of "yes", and of 1 all return "non-exchangeable draws: the permutation null does not hold on them". Only the first is a negative declaration; the other two are declarations the guard cannot read, reported as a statement the caller never made.
Minimal falsifier: supply exchangeable="yes" on a sampled reading and read the reason.

P3 · parameter · target: the parameter census and the kernel's zero-variance floor · STRUCTURAL
Mechanism: the census says every threshold is fixed in code and printed at boot. The second-order kernel refuses any row whose standard deviation is below the literal 1e-12, a threshold absent from the census and absolute in the row's units. The kernel reads the correlation matrix, which is invariant under rescaling a row, so the floor makes the verdict depend on the units: rows that vary at a scale near 1e-13 are refused as zero-variance while the same rows at unit scale lock.
Minimal falsifier: scale the recorded Gaussian rows by 1e-13 and read the kernel's state.

P4 · arithmetic slip found in passing · target: the reach law's first router bit
Mechanism: "I(P;S) ≤ H(P) − H(S) = 0". Mutual information is bounded by the smaller of the two entropies, never by their difference, which can be negative; the zero bound follows from H(P) = 0 alone.
Minimal falsifier: take S with one bit of entropy and P with zero, and evaluate the printed bound.

P5 · drift found in passing · target: the face table's uniqueness row
Mechanism: "a component here meaning any domain". A component is defined as a non-singleton block of the finest independence partition and a domain as any union of components; the row now names every union a component.
Minimal falsifier: count components and nonempty domains on the two copied pairs, 2 and 3.

P6 · scope found in passing · target: the grade vocabulary
Mechanism: "on every law, supplied or not, it carries at theorem rank". The exact instrument reads only supplied finite laws; an unsupplied law is read at nothing.
Minimal falsifier: ask what exact table an unsupplied law provides.

Targets examined without finding: the boot line, the census clause, the round-eight record stanza.
