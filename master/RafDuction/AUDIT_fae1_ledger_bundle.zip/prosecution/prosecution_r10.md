# Default Audit · round 10 · registers limit and symmetry
Object: the seeded copy of the relation-claim engine deck v1.0.8, a self-contained universe. Mandatory targets from round 9: the conditional typing of the sampled seal, the malformed-declaration report, the relative zero-variance floor and its census line, the symmetry rescaling, the extended margin gate and its chain sentence, the round-nine record stanza.

Recomputed and agreeing: every sampled seal's reason names its condition; False reads negative and "yes" reads unread; the symmetry battery holds 75 of 75; the chain sentence's count of 27 matches the gate. Permuting the variables of every exact control's law with indices remapped, 62 variants, holds token, label, and grade in all 62.

P1 · symmetry · target: the relative zero-variance floor added in round nine · STRUCTURAL
Mechanism: the second-order channel reads correlations of centred rows, a quantity invariant under translating any row. The new floor compares each row's standard deviation with its largest magnitude, which translation changes. Executed on the recorded Gaussian rows: translated by 1e3 and by 1e9 the kernel locks and registers; translated by 1e13 it refuses the rows as zero-variance. The XOR rows behave the same. The previous absolute floor was translation-invariant and scale-dependent; the replacement is scale-invariant and translation-dependent, and no sentence names translation, offset, or the floor's rationale.
Minimal falsifier: translate the recorded Gaussian rows by 1e13 and read the kernel's state.

P2 · numeric slip found in passing · target: the verdict economy's routing tokens
Mechanism: "[ROUTE-707]". The reach law routes the closure position to the coordinate at index 0706, and the router emits the route under that index.
Minimal falsifier: compare with the reach law's closure-position clause.

P3 · drift found in passing · target: the coalition row
Mechanism: "Tested as a coalition, here meaning any single outside system, it fails". The row's own contrast is between the coalition, the whole outside tested jointly, and the per-system reading; here the coalition is named the per-system reading, and the per-system reading passes.
Minimal falsifier: run closure on the copied-pair law per outside system and as a coalition.

P4 · scope found in passing · target: the face table's uniqueness row
Mechanism: "fixed [sealed] [X] at any size". Above the exact work cap the uniqueness face returns [?] at the cap before any enumeration.
Minimal falsifier: run the uniqueness face on thirty copied variables.

Targets examined without finding: the conditional typing of the sampled seal, the malformed-declaration report, the symmetry rescaling, the extended margin gate and its chain sentence, the round-nine record stanza.
