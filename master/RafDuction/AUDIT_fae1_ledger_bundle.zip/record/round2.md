# ROUND 2 · cycle fae1 · registers parameter + provenance
Header. Artifact fae_v1_0_1.md. Control commitment 9c5989e656764dd7, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata block: no incorrect finding filed by the auditing seats in round 1. Declared targets from round 1: A1 RA paragraph 1.1, A2 grade vocabulary 1.4, A3 RRS.5 switch and C1C3_FIXED_GRADE, A4 EXT domain test and control, A5 RECORD v1.0.1 stanza, A6 component and domain definition 2.3; all prosecuted, no finding against the spine.
Leak-scan: CLEAN.

| id | register | claim | mechanism | severity | minimal falsifier |
|---|---|---|---|---|---|
| F-10 | parameter | NONE | census unstated in prose, eight thresholds as code literals | STRUCTURAL | reproduce the analytic floor from prose: 0.015962 at 0.99, 0.011407 at 0.95 |
| F-11 | provenance | NONE | declared Monte-Carlo band used the asymptotic SE | STRUCTURAL | band widths 0.005223 against the rank band 0.008200 |
| F-12 | provenance | NONE | calibration re-reads laws the screen already analyses | STRUCTURAL | list rows one to five against the screen rows |
| F-13 | provenance | NONE | random-family corroboration single-channel | STRUCTURAL | recompute every decision independently |
| F-14 | provenance | LB6 | FORGE receipt echoes a self-supplied flag, derivation absent | STRUCTURAL | locate the printed derivation |
| F-15 | parameter | NONE | grade switch never executed | STRUCTURAL | flip in a sandbox |
| F-16 | parameter | NONE | read-time joint: census says four binary variables, exhibition cases carry a fifth of alphabet 2^b | STRUCTURAL | count the exhibitor's values |
| F-17 | provenance | LB10 | read-time joint: "environment-invariant facts only" beside committed float-decided counts, no gate | STRUCTURAL | list committed facts decided in floating point |

Defense, booted, live at seed 20260622 on v1.0.1: significance level, permutation count, gate-eight tolerance, conditioning constant, family arity each stated 0 times in prose; analytic floor 0.015962 at 0.99, 0.011407 at 0.95; rank band 0.008200 against code band 0.005223, ratio 1.570; calibration rows one to five read XOR3, XOR3, DIS4, EXH5, SYN4; random-family loops factorization-only; hook supplies equiv_to_target=True, derivation printed 0 times; switch flipped in no battery. No refusal available without posture.

| id | disposition | reason |
|---|---|---|
| F-10 | EARNED | census stated and wired; setting the gate to 1.0 turns the lock ILL-CONDITIONED |
| F-11 | EARNED | distribution-free rank band widened to the analytic quantile |
| F-12 | SCOPED | consistency ledger at corroboration grade |
| F-13 | EARNED | independent channel agrees 300/300, 60/60, 120/120 |
| F-14 | SCOPED | warrant relocated to the printed derivation, tool typed as adding the disposition |
| F-15 | EARNED | sandbox battery flips, reads, restores |
| F-16 | EARNED | census names the exhibitor's alphabet |
| F-17 | SCOPED | margin gate executed: 9 comparisons, smallest 0.59, 18465 channel zeros exact; load-bearing at an impossible gate |

Integration. Sweeps F-10 through F-17: pre PASS, post PASS; round-one sweeps F-1 through F-9 re-verified PASS on v1.0.2. End-to-end read attested: title, 2.3 whole, RRS.2 through RRS.6 whole, Part 4 whole, RECORD v1.0.2, engine regions for the band, both channels, the fixed-point predicates, the root-screen loops, the margin gate, the switch battery, the boot prints and chain; the read caught F-16 and F-17 and one error in the new stanza (two literals where there were eight), corrected before landing. Removal rulings: F-11, F-12, F-14, F-17 REMOVED. Engine v1.0.2: kill-matrix 48/48, ablation 21/21, calibration 12/12, second channel 480/480, margin gate True, switch battery True, chain D0 4ca7bee98be2 → D4 f5593e796804, invariant across hash seeds, hook absence, repeat runs; replay equals embedded first light.
Additions declared, mandatory targets for round 3: B1 census paragraph with exhibitor alphabet and margin gate; B2 rank band sentence and code; B3 independent channel code and prose; B4 RRS.5 derivation and FORGE typing; B5 switch battery code and prose; B6 consistency-ledger sentences; B7 margin gate code and chain sentences; B8 RECORD v1.0.2 stanza.

Control reveal: CAUGHT C1 ARITH §7, CAUGHT C2 DRIFT §8, CAUGHT C3 SCOPE §4 · detection 3/3 · SELF aperture.
Statistic: admitted 8 · EARNED 5 · SCOPED 3 · refused 0 · aperture 0 · FATAL 0 · debt yes · mass-bearing 8 · prereg hits 2 · repeats 0 · tier raised 0.
New version: fae_v1_0_2.md.
VERDICT CONTINUE-PREREG-BLOCK: 2 mass-bearing finding(s) on a pre-registered claim and 0 mass-bearing FATAL; the round incurs debt, and 2 consecutive clean valid rounds are required before any seal issues.
