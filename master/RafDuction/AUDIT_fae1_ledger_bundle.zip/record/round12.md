# ROUND 12 · cycle fae1 · registers parameter + provenance
Header. Artifact fae_v1_0_10.md. Control commitment 787bcf1a0142034c, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata: the auditing seat's successor guard first misread three superseded markers as failures, its banned-at-zero test matching the sweep's own summary line; corrected and re-run, no genuine prior failure. Yield per valid round: parameter and provenance 5.5, kinematic and definitional 5.0, limit and symmetry 4.0.
Leak-scan: CLEAN. Recomputed and agreeing: census keys all stated; gradual underflow as stated, lock at 1e-160 and zero-variance at 1e-170; RECORD v1.0.10 ratio.
| F-50 | parameter | NONE | floor called the resolution of double arithmetic; it is 4503.6 u | STRUCTURAL |
| F-51 | provenance | NONE | fallback route attributes an injected engine fault to the reading or its range | STRUCTURAL |
Defense live on the unseeded v1.0.10: floor / u = 4503.6; injected fault reported as malformed or range. Both EARNED.
Integration. Sweeps F-50, F-51 pre and post PASS; superseded markers of F-40, F-47, F-49 rewritten by this round, banned phrases at zero, successors PASS; every other prior spec PASS; replay equals first light. End-to-end read attested: census clause, limit sentence, Part 5 fallback and FSIG sentences, Part 4 battery sentence, RECORD v1.0.11, engine catch-all texts and the fault-injection battery. Engine v1.0.11: kill-matrix 51/51, ablation 22/22, output batteries True with fault injection, null and type fuzz 0 crashes, margin gate 32, chain D0 bd7a163b50d9 → D4 8b8cd474a8ba, invariant.
Additions declared, mandatory targets for round 13: K1 the census tolerance clause and the limit sentence; K2 the fallback reason texts, the Part 5 sentences, the fault-injection battery and its sentence; K3 RECORD v1.0.11.
Control reveal: CAUGHT C1 count §1.4, CAUGHT C2 DRIFT Part 3, CAUGHT C3 SCOPE §1.2 · detection 3/3 · SELF aperture.
Statistic: admitted 2 · EARNED 2 · mass-bearing 2 · prereg hits 0 · repeats 0.
New version: fae_v1_0_11.md.
VERDICT CONTINUE: mass-bearing findings remain; run the next round.
