# ROUND 10 · cycle fae1 · registers limit + symmetry
Header. Artifact fae_v1_0_8.md. Control commitment becb70a994255830, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata: the auditing seat's first arithmetic plant search found no numeral word in §1.3's successor section 1.4 and aborted before writing; the plant was re-chosen mechanically and landed on a route index. The permutation probe's first run crashed on a control carrying a deliberately out-of-range index; re-run excluding it. Yield per valid round: limit and symmetry 7.0, kinematic and definitional 5.6, parameter and provenance 5.5.
Leak-scan: CLEAN. Recomputed and agreeing: variable permutations of the exact controls 62/62; round-nine additions hold.
| F-47 | symmetry | NONE | relative floor makes the translation-invariant kernel reading refuse rows translated by 1e13 | STRUCTURAL |
Defense live on the unseeded v1.0.8: offsets 0 and 1e9 [LOCK], 1e13 zero-variance row. SCOPED.
Integration. Sweep F-47 pre and post PASS; round-9 F-46's required count superseded by this repair, banned phrases at zero, successor PASS; every other prior spec PASS on v1.0.9; replay equals first light. End-to-end read attested: census, limit battery sentence, chain paragraph, RECORD v1.0.9, engine regions for the limit battery and the margin gate. Engine v1.0.9: kill-matrix 51/51, ablation 22/22, symmetry 75/75, limit battery with translations, margin gate 32 facts smallest 0.59, chain D0 f5f43178dcea → D4 eff510fe3373, invariant.
Additions declared, mandatory targets for round 11: I1 the census clause typing the floor; I2 the limit battery's translations; I3 the margin gate at 32 and its chain sentence; I4 RECORD v1.0.9.
Control reveal: CAUGHT C1 ARITH §1.4, CAUGHT C2 DRIFT Part 3, CAUGHT C3 SCOPE §2.4 · detection 3/3 · SELF aperture.
Statistic: admitted 1 · SCOPED 1 · mass-bearing 1 · prereg hits 0 · repeats 0.
New version: fae_v1_0_9.md.
VERDICT CONTINUE: mass-bearing findings remain; run the next round.
