# ROUND 13 · cycle fae1 · registers kinematic + definitional · VOID-LEAK
Header. Artifact fae_v1_0_11.md. Control commitment e7d1781272362657, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Declared targets from round 12: K1 through K3.
Leak-scan: LEAK line 11, "Seal L", quoted from the planted kill-matrix slip inside the prosecution text, the round-5 failure repeated. The pass was not blind; the round closes with --leak and the prosecution re-runs in round 14.
Errata, auditing seats: the Defense did not run, being chained behind the scan, but the Engineer's patch and boot ran on unchained command lines after the leaked pass and produced an engine v1.0.12. Nothing lands from a void round: the file is set aside as void_r13_engine_v1_0_12.py, unlanded, and any re-raised finding is re-engineered in round 14 from v1.0.11.
Findings retained as record text, not dispositioned: P1 a raising reading's trace said to keep the checks it passed, while it keeps every check reached, the fourth typing check during which a list-valued claim raises included. Planted controls found: C1 ARITH Part 4, C2 DRIFT §1.2, C3 SCOPE §2.3.
Control reveal: CAUGHT C1, C2, C3 · detection 3/3 · SELF aperture.
Statistic: admitted 0 · mass-bearing 0 · prereg hits 0.
New version: none; fae_v1_0_11.md unchanged.
VERDICT VOID-LEAK: framework vocabulary appeared in the framework-blind pass; re-run the round.
