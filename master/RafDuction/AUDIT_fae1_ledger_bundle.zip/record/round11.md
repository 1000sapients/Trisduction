# ROUND 11 · cycle fae1 · registers kinematic + definitional
Header. Artifact fae_v1_0_9.md. Control commitment 2594f3f790cb0091, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata: the auditing seat's ratio helper overflowed at scale 1e300 in its first run, a probe fault, re-run with normalised arithmetic. Yield per valid round: kinematic and definitional 5.6 then, parameter and provenance 5.5, limit and symmetry 4.0.
Leak-scan: CLEAN. Recomputed and agreeing: gate count 32, limit battery translations, RECORD v1.0.9.
| F-48 | kinematic | NONE | census clause says scale pushes a row below a scale-invariant floor | STRUCTURAL |
| F-49 | definitional | NONE | catch-all names a range overflow a malformed supplied value | STRUCTURAL |
Defense live on the unseeded v1.0.9: kernel [LOCK] at 1e-13 and 1e13, zero-variance at 1e-300; rows at 1e300 reported "reading malformed". Both EARNED.
Integration. Sweeps F-48, F-49 pre and post PASS; round-10 F-47's first required phrase superseded, successor PASS; every other prior spec PASS on v1.0.10; replay equals first light. End-to-end read attested: census clause, RECORD v1.0.10, engine catch-all reasons in the adjudicator and FSIG. Engine v1.0.10: kill-matrix 51/51, ablation 22/22, null and type fuzz 0 crashes, output batteries True, margin gate 32, chain D0 e91dbc75c232 → D4 34d68066d0f1, invariant.
Additions declared, mandatory targets for round 12: J1 the census clause on rescaling, offset and underflow; J2 the catch-all reason texts; J3 RECORD v1.0.10.
Control reveal: CAUGHT C1 count §1.2, CAUGHT C2 DRIFT §2.2, CAUGHT C3 SCOPE §1.3 · detection 3/3 · SELF aperture.
Statistic: admitted 2 · EARNED 2 · mass-bearing 2 · prereg hits 0 · repeats 0.
New version: fae_v1_0_10.md.
VERDICT CONTINUE: mass-bearing findings remain; run the next round.
