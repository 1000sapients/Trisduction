# ROUND 3 · cycle fae1 · registers limit + symmetry
Header. Artifact fae_v1_0_2.md. Control commitment 8ff8718b763432ef, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata block: no incorrect finding filed by the auditing seats in rounds 1 and 2. Declared targets from round 2: B1 census, B2 rank band, B3 independent channel, B4 derivation and FORGE typing, B5 switch battery, B6 consistency ledger, B7 margin gate, B8 RECORD v1.0.2; B2 and B7 yielded findings, the rest none.
Leak-scan: CLEAN.

| id | register | claim | mechanism | severity | minimal falsifier |
|---|---|---|---|---|---|
| F-18 | limit | LB1 | uniqueness enumeration unbounded, cost doubling per variable | LOAD-BEARING | 30 copied variables under a 60 s limit |
| F-19 | limit | NONE | rank band upper rank 998.44 clamps to the sample maximum at 1000 permutations | STRUCTURAL | compute the upper rank |
| F-20 | symmetry | LB5 | exhibition lemma asserted of the act with no bridge to the record | STRUCTURAL | locate the stated map and its grade |
| F-21 | limit | NONE | quoted falsifier met by an isolated bit while uniqueness seals | STRUCTURAL | copied pair plus independent bit |
| F-22 | symmetry | LB9 | no-energy strip unqualified while gate twelve reads the rider's presence | STRUCTURAL | gate-twelve reading with and without the rider |
| F-23 | limit | LB1 | exchangeability never read; persistent independent chains seal 22/24 | LOAD-BEARING | repeat the persistent-chain trials |
| F-24 | symmetry | NONE | margin gate's collapse floor from literals, not the kernel's | STRUCTURAL | change row length, compare floors |

Defense, booted, live at seed 20260622 on v1.0.2: 30-variable uniqueness run killed at 60 s; upper band rank 998.44 → index 999 = maximum, 1992.35 of 1999 at 2000; RRS.4 states no act-to-record map and names no RA; isolated Z: UNI [⟀], I(Z;X1) = 0.0, Z block (2,); rider present [X] G12, deleted [⟀] M-IX, energy values mentioned 0 times; fresh-stream persistent chains sealed 12/12; gate floor 5.329e-13 against kernel floor 1.066e-12 at 48 rows. No refusal available without posture.

| id | disposition | reason |
|---|---|---|
| F-18 | EARNED | work cap at M3 before enumeration; domains counted from components |
| F-19 | EARNED | 2000 permutations; refusal at the extreme order statistic |
| F-20 | SCOPED | analytic on record variables, structural on the stated bridge: to exhibit is to register, the act a deed on RA's floor |
| F-21 | EARNED | falsifier qualified to members, b ≥ 2; isolated-system control seated |
| F-22 | SCOPED | strip forbids energy values; presence read at R3 and G12 by design |
| F-23 | EARNED | exchangeable draws a guarding check at M1 |
| F-24 | EARNED | kernel reports its floor; gate reads it |

Integration. Sweeps F-18 through F-24: pre PASS, post PASS; round-two sweeps F-10 through F-17 PASS on v1.0.3; round-one sweeps PASS except F-3's required marker, whose code string F-18 rewrote: every F-3 banned phrase at zero, successor marker PASS, recorded as a verification-joint note, not a regression. End-to-end read attested: description, title, supply paragraph, 1.2, 1.5, 2.3 whole with census, 2.4 UNI row, RRS.4 whole, Part 4 whole, RECORD v1.0.3, engine regions for the band refusal, the exchangeability guard, the work cap, the kernel floor, the margin gate, the controls, the nullity reading, the symmetry and limit batteries, the boot prints and chain. Removal rulings: F-18, F-19, F-20, F-24 REMOVED. Engine v1.0.3: kill-matrix 51/51, ablation 22/22, nullity 8/8, symmetry 71/71, limit battery True, fuzz 221 with 0 crashes, adversarial 9/9, calibration 12/12, second channel 480/480, margin gate True, switch True, chain D0 6e7f5d782cf2 → D4 91abca77aee6, invariant across hash seeds, hook absence, repeat runs; replay equals embedded first light.
Additions declared, mandatory targets for round 4: C1 exchangeability guard and prose; C2 exact work cap, domain count, and prose; C3 band refusal and the 2000 count; C4 exhibition bridge, falsifier qualification, grades; C5 isolated-system control; C6 energy-value sentence; C7 symmetry and limit batteries; C8 kernel floor reporting; C9 RECORD v1.0.3.

Control reveal: CAUGHT C1 ARITH §4, CAUGHT C2 DRIFT §7, CAUGHT C3 SCOPE §1 · detection 3/3 · SELF aperture.
Statistic: admitted 7 · EARNED 5 · SCOPED 2 · refused 0 · aperture 0 · FATAL 0 · debt yes · mass-bearing 7 · prereg hits 4 · repeats 0 · tier raised 0. Coverage 6/6.
New version: fae_v1_0_3.md.
VERDICT CONTINUE-PREREG-BLOCK: 4 mass-bearing finding(s) on a pre-registered claim and 0 mass-bearing FATAL; the round incurs debt, and 2 consecutive clean valid rounds are required before any seal issues.
