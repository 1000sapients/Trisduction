# ROUND 14 · cycle fae1 · registers kinematic + definitional · re-run of the voided round-13 pass
Header. Artifact fae_v1_0_11.md. Control commitment 6ecd94539a2ed048, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata: none new; plants placed in phrases quotable without framework tokens, the prosecution text generated from the probe's live output, leak-scan chained strictly ahead of the Defense and the Engineer. Yield per valid round: kinematic and definitional 4.43, parameter and provenance 4.33, limit and symmetry 4.0. Declared targets carried from round 12: K1 through K3.
Leak-scan: CLEAN. Recomputed and agreeing: floor at 4503.6 u, a part in 4504; fault-injection battery true; fallback reason's three causes; RECORD v1.0.11 figures.
| F-52 | definitional | NONE | trace said to keep checks passed; it keeps checks reached, the raising check included | STRUCTURAL |
Defense live on the unseeded v1.0.11: trace [L0, L1, L2, L3, L4, L0], second-to-last ("L4", "reached"). EARNED.
Integration. Sweep F-52 pre and post PASS; F-39's marker superseded by this repair, banned phrases at zero, successor PASS; every other latest spec PASS on v1.0.12; replay equals first light. The engine repair was re-derived in this valid round from v1.0.11 and reproduces the quarantined void-round chain exactly, as determinism requires. End-to-end read attested: Part 4 battery sentence, Part 5 fallback sentence, RECORD v1.0.12, the trace battery assertion. Engine v1.0.12: kill-matrix 51/51, ablation 22/22, output batteries True, chain D0 3e50675c7d5d → D4 3d17fd53278d, invariant.
Additions declared, mandatory targets for round 15: L1 the trace wording in Parts 4 and 5; L2 the trace battery's raising-check assertion; L3 RECORD v1.0.12.
Control reveal: CAUGHT C1 count §1.5, CAUGHT C2 DRIFT §1.1, CAUGHT C3 SCOPE §2.1 · detection 3/3 · SELF aperture.
Statistic: admitted 1 · EARNED 1 · mass-bearing 1 · prereg hits 0 · repeats 0.
New version: fae_v1_0_12.md.
VERDICT CONTINUE: mass-bearing findings remain; run the next round.
