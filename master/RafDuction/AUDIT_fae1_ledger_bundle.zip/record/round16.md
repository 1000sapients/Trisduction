# ROUND 16 · cycle fae1 · registers parameter + provenance · SEALED-ROUND
Header. Artifact fae_v1_0_12.md. Control commitment 247fb387912cbf1e, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata: none. Yield per valid round: parameter and provenance 4.33, limit and symmetry 4.0, kinematic and definitional 3.9. No additions declared by round 15.
Leak-scan: CLEAN.
Parameter battery, nine checks agreeing: verdict-path literals are formula constants or stated values; census keys all stated; battery parameters stated. Provenance battery agreeing: chain with the typing hook absent, in a directory holding no hook, equals the recorded chain D0 3e50675c7d5d → D4 3d17fd53278d, its row reading not reached; the sampled seal conditional on the supplied declaration in text and reason; the fallback cause open; the calibration ledger a consistency ledger at corroboration grade; the hook's row session evidence; a malformed declaration unread. No finding. Planted slips found: C1 ARITH §2.3, C2 DRIFT §0, C3 SCOPE §1.1.
Control reveal: CAUGHT C1, C2, C3 · detection 3/3 · SELF aperture.
Statistic: admitted 0 · mass-bearing 0 · prereg hits 0 · clean streak 2/2.
VERDICT SEALED-ROUND: zero mass-bearing findings, full control detection, round floor and six-register coverage met; control-grade floor SELF, single-substrate aperture open and stamped on the seal.
