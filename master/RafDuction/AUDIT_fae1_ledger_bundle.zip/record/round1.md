# ROUND 1 · cycle fae1 · registers kinematic + definitional
Header. Artifact fae_v1_0_0.md (sha256 fd1f032ae237). Control commitment 4755690524bba65b, SELF. Defense boot chain D0 fb8900b5cf42 → D1 364d1cdb9227 → D2 8a5dc7f98105 → D3 1e2b2d2adb14. Errata block: none, first round. Declared targets: none, first round.
Leak-scan: CLEAN.

| id | register | claim | mechanism | severity | minimal falsifier |
|---|---|---|---|---|---|
| F-1 | definitional | LB11 | "the root" names RAF, RA never named, "premise-grade by theorem" undefined and not RAF-2's grade | LOAD-BEARING | find a definition of the parent and of the designation consistent with the posit's grade |
| F-2 | definitional | LB11 | exteriority verdicts at a fixed point emitted analytic against "stand on the posit" | LOAD-BEARING | run EXT and NOEXT on copied pairs, read the grade |
| F-3 | definitional | NONE | "domain" names a rule solution and a finest block; 3 nonempty against b = 2 | STRUCTURAL | count nonempty solutions on copied pairs |
| F-4 | kinematic | NONE | 3 bits give 8 states and 256 properties, printed 8 against 3 | STRUCTURAL | count subsets of a 3-bit state set |
| F-5 | definitional | NONE | printed grades unreadable at the grade gate, analytic undefined | STRUCTURAL | grade gate on corroboration |
| F-6 | definitional | NONE | "token" names a single event and a verdict symbol | STRUCTURAL | substitute the symbol sense into the typing rule |
| F-7 | definitional | NONE | "places it inside the domain" printed where D is no domain | STRUCTURAL | EXT with D = {A} on the 2x3 law |
| F-8 | kinematic | LB2 | integration collision: F-2 masked the L5 guard's control, ablation 20/21 | STRUCTURAL | ablate L5 on the candidate |
| F-9 | definitional | NONE | integration collision: Part 3 opening adopts a reading RRS.5 now holds behind a switch | STRUCTURAL | read the opening against RRS.5 |

Defense, booted, live at seed 20260622 on the entry version: RA occurs 0 times in the prose and "premise-grade by theorem" once with no definition; EXT fixed [X] and NOEXT fixed [⟀] both emit analytic; copied pairs carry nonempty fixed points 3 with components b = 2; three binary state variables give 8 states and 256 properties while the engine prints 8 against 3; a direction claim at corroboration returns [?] G9 "stated grade unread"; "token" 8 event-sense and 11 symbol-sense; EXT on D = {A} prints "places it inside" with {A} no fixed point. No refusal available without posture.

| id | disposition | reason |
|---|---|---|
| F-1 | EARNED | falsifier confirmed; RA named the one root, RAF its interaction face, grade sentence retyped |
| F-2 | SCOPED theorem → premise | chapter 10 B governs by Codex-First; the analytic split kept as a named off switch |
| F-3 | EARNED | components distinguished from domains, 2^b − 1 stated |
| F-4 | EARNED | index count replaces bit count |
| F-5 | EARNED | vocabulary declared and ranked |
| F-6 | EARNED | single event replaces the event sense of token |
| F-7 | EARNED | D tested as a domain before one is named |
| F-8 | EARNED | control restated at premise, ablation 21/21 |
| F-9 | EARNED | opening excepts the switched split |

Integration. Sweeps pre on v1.0.0 all PASS; post on v1.0.1 all PASS after two propagation residues were caught and repaired: F-3 "one connected domain" live in the closing seal, F-6 "the token reading" live in RRS.1's ruling clause; the end-to-end read then caught F-1's equivalent phrasing "An engine rooted on RAF" in the intro, spec extended, PASS. End-to-end read attested: front matter, title, intro, supply paragraph, 1.1, 1.4, 2.1, 2.3, 2.4 with the UNI, EXT, NOEXT joint, Part 3 opening, RRS.1, RRS.3, RRS.4, RRS.5, the rulings paragraph, Part 4, Part 6, RECORD, closing seal. Removal rulings: F-1, F-2, F-3, F-6, F-7 REMOVED. Engine v1.0.1: kill-matrix 48/48, ablation 21/21, calibration 12/12, chain D0 a9f543e93c71 → D4 db0c00d6ef0c, invariant across hash seeds, hook absence, repeat runs; fence extraction byte-identical; replay equals embedded first light.
Additions declared, mandatory targets for round 2: A1 the RA paragraph in 1.1; A2 the grade vocabulary in 1.4; A3 the RRS.5 switch sentences and C1C3_FIXED_GRADE; A4 the EXT domain test and control M-EXT named D not a domain; A5 the RECORD v1.0.1 stanza; A6 the component and domain definition in 2.3.

Control reveal: CAUGHT C1 ARITH §12, CAUGHT C2 DRIFT §7, CAUGHT C3 SCOPE §11 · detection 3/3 · SELF aperture.
Statistic: admitted 9 · EARNED 8 · SCOPED 1 · refused 0 · aperture 0 · FATAL 0 · debt yes · mass-bearing 9 · prereg hits 3 · repeats 0 · tier raised 0.
New version: fae_v1_0_1.md.
VERDICT CONTINUE-PREREG-BLOCK: 3 mass-bearing finding(s) on a pre-registered claim and 0 mass-bearing FATAL; the round incurs debt, and 2 consecutive clean valid rounds are required before any seal issues.
