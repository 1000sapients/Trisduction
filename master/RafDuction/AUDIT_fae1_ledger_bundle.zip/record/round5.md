# ROUND 5 · cycle fae1 · registers kinematic + definitional · VOID-LEAK
Header. Artifact fae_v1_0_4.md. Control commitment e88cdfeda29df7b1, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata block: none. Declared targets from round 4: D1 through D8.
Leak-scan: LEAK line 27, "Seal G", quoted from the planted pipeline-section defect inside the prosecution text. The pass was not blind; the round closes with --leak and the prosecution re-runs in round 6.
Findings retained as record text, not dispositioned, no repair landed: P1 the typing-only availability sentence read per reading while the instrument types per face; P2 the output-battery sentence's class counts 24 against the 22 it checks; P3 the fifth typing says the grade depends on the D-reading while exteriority and no-exterior-agent carry premise at both readings; P4 the registration row omits the exchangeability guard the availability sentence says the table includes; P5 null values on single keys of the positive controls crashed the engine 27 times in 148 substitutions. Planted controls found: C1 ARITH §1.5, C2 DRIFT §2.1, C3 SCOPE Part 3.
Control reveal: CAUGHT C1, C2, C3 · detection 3/3 · SELF aperture.
Statistic: admitted 0 · mass-bearing 0 · prereg hits 0.
New version: none; fae_v1_0_4.md unchanged.
VERDICT VOID-LEAK: framework vocabulary appeared in the framework-blind pass; re-run the round.
