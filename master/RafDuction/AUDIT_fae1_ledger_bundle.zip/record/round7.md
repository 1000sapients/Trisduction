# ROUND 7 · cycle fae1 · registers kinematic + definitional
Header. Artifact fae_v1_0_5.md. Control commitment b058cd48f4ef4d19, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata: none. Declared targets from round 6: E1 through E8; E6 and the supply paragraph yielded findings.
Leak-scan: CLEAN.
| id | register | claim | mechanism | severity |
|---|---|---|---|---|
| F-41 | definitional | NONE | gate-ten row names per-outsider, the engine reads atomic: [?] where [X] promised; vocabulary unstated | STRUCTURAL |
| F-42 | definitional | NONE | supply paragraph omits the claim fields and bridge flag the adjudicator reads | STRUCTURAL |
Defense live on the unseeded v1.0.5: per-outsider [?], atomic [X]; claim and bridge absent from the paragraph. Both EARNED.
Integration. Sweeps F-41, F-42 pre and post PASS. Prior-round specs on v1.0.6 PASS except round-6 F-38, whose required prose marker F-41 rewrote: its banned code phrase at zero, successor spec PASS, a verification-joint note and not a regression. The ledger writes ran before this diagnosis because the sweep loop did not gate them; the diagnosis was completed before round 8 opened. End-to-end read attested: the supply paragraph whole, the gate-ten row, RECORD v1.0.6. Engine v1.0.6, version string only: kill-matrix 51/51, ablation 22/22, null and type fuzz 0 crashes, output batteries True, chain D0 b6e627781c46 → D4 4ffaea40d96c, invariant across hash seeds.
Additions declared, mandatory targets for round 8: F1 gate-ten vocabulary; F2 supply paragraph fields; F3 RECORD v1.0.6.
Control reveal: CAUGHT C1 ARITH §1.3, CAUGHT C2 DRIFT Part 4, CAUGHT C3 SCOPE Part 3 · detection 3/3 · SELF aperture.
Statistic: admitted 2 · EARNED 2 · mass-bearing 2 · prereg hits 0 · repeats 0.
New version: fae_v1_0_6.md.
VERDICT CONTINUE: mass-bearing findings remain; run the next round.
