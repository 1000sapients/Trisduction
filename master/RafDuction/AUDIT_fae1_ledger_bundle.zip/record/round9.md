# ROUND 9 · cycle fae1 · registers parameter + provenance · run past the autorun cap on the architect's order
Header. Artifact fae_v1_0_7.md. Control commitment 0d6409ae15e68f91, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata block, register plan: A3 restates "the register pair with the highest historical yield" and never defines yield; rounds 4 through 8 read it as total mass-bearing per pair, which only favours the pair run most. From round 9 it is read per valid round: parameter and provenance 8.0, limit and symmetry 7.0, kinematic and definitional 5.6. Under that reading rounds 7 and 8 would have run parameter and provenance; the record states it and moves no verdict. Declared targets from round 8: G1 the sampled-seal boot line, G2 the census clause, G3 RECORD v1.0.7; none yielded a finding.
Leak-scan: CLEAN.
| id | register | claim | mechanism | severity |
|---|---|---|---|---|
| F-44 | provenance | NONE | sampled seal rides on an unverifiable supplied exchangeability flag, typed plain engineering; declared persistent chains seal 12/12 | STRUCTURAL |
| F-45 | provenance | NONE | malformed declaration reported as a negative declaration | STRUCTURAL |
| F-46 | parameter | NONE | absolute zero-variance floor 1e-12 outside the census; units decide a scale-invariant reading | STRUCTURAL |
Literals inspected without finding: 200 bisection steps in the chi-square quantile, the stated fifty-digit escalation, the 10^12 clamp in the work estimate, which only ever errs toward refusal.
Defense live on the unseeded v1.0.7: declared persistent chains sealed 6/6 with no conditional in the reason; False and "yes" both reported non-exchangeable; unit rows [LOCK], rows x 1e-13 zero-variance. F-44 SCOPED, F-45 and F-46 EARNED.
Integration. Sweeps F-44 through F-46 pre and post PASS; prior-round specs PASS on v1.0.8, round-6 F-38 through its round-7 successor. End-to-end read attested: 2.3 sampled paragraph, census, registration row, Part 4 battery sentences, chain paragraph, grades, RECORD v1.0.8, engine regions for the relative floor, the guard's messages, the sampled seal's reason, the symmetry rescaling, the extended margin gate, and the declaration battery; the read caught the symmetry battery's boot print omitting the rescalings, corrected before landing. Engine v1.0.8: kill-matrix 51/51, ablation 22/22, symmetry 75/75, output batteries True, null and type fuzz 0 crashes, margin gate 27 facts smallest 0.59, chain D0 3dcc34d42d7f → D4 511b49fcafdf, invariant; replay equals first light.
Additions declared, mandatory targets for round 10: H1 the conditional typing of the sampled seal; H2 the malformed-declaration report; H3 the relative floor and its census line; H4 the symmetry rescaling; H5 the extended margin gate and its chain sentence; H6 RECORD v1.0.8.
Control reveal: CAUGHT C1 ARITH §1.3, CAUGHT C2 DRIFT §2.4, CAUGHT C3 SCOPE §1.4 · detection 3/3 · SELF aperture.
Statistic: admitted 3 · EARNED 2 · SCOPED 1 · mass-bearing 3 · prereg hits 0 · repeats 0.
New version: fae_v1_0_8.md.
VERDICT CONTINUE: mass-bearing findings remain; run the next round.
