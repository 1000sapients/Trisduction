# ROUND 4 · cycle fae1 · registers kinematic + definitional (highest historical yield)
Header. Artifact fae_v1_0_3.md. Control commitment ae349f67c833e3f3, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata block: no incorrect finding filed in rounds 1 to 3. Declared targets from round 3: C1 exchangeability guard, C2 work cap and domain count, C3 band refusal and 2000 count, C4 exhibition bridge and falsifier qualification, C5 isolated-system control, C6 energy-value sentence, C7 symmetry and limit batteries, C8 kernel floor, C9 RECORD v1.0.3; C7 via FSIG yielded F-28, the rest none.
Leak-scan: CLEAN. Headline counts recomputed and agreeing: 51 controls (8, 7, 12, 5, 19), 22 guards, 71 symmetry variants, 2^51, work 5368709120 above cap; work cap bounds time, 18 variables at counted work 1.31e6 in 2.02 s.

| id | register | claim | mechanism | severity | minimal falsifier |
|---|---|---|---|---|---|
| F-25 | kinematic | NONE | floor sentence states the admitted side as refused | STRUCTURAL | 3x3 sample at N = 44 and 45 |
| F-26 | definitional | NONE | aperture sentence promised on every world verdict, emitted on none; content fits uniqueness only | STRUCTURAL | emit the three world verdicts |
| F-27 | definitional | NONE | promised trace of reached checks carries the firing label only | STRUCTURAL | print a sealed trace |
| F-28 | definitional | NONE | FSIG lists seals unreachable after round three | STRUCTURAL | type the capped and undeclared readings |
| F-29 | definitional | NONE | read-time joint: guard traced under undeclared label M1X | STRUCTURAL | trace a sampled reading |
| F-30 | definitional | NONE | read-time joint: new FSIG sentence false on inadmissible readings | STRUCTURAL | type an inadmissible law |
| F-31 | definitional | NONE | read-time joint: stated pipeline order contradicts the executed trace; sampled path M2 before M1 | STRUCTURAL | compare 1.5 with a trace |
| F-32 | kinematic | NONE | read-time joint: twenty-two "face-decision" controls against nineteen face decisions | STRUCTURAL | count the battery's controls |

Defense, booted, live at seed 20260622 on v1.0.3: N = 44 [?] M1, N = 45 [?] M-IX with the sentence unchanged; world UNI, EXT, NOEXT reasons carry neither aperture nor Ghost; sealed and absence traces [('M-IX', 'SEAL')]; FSIG omits the emitted [?] on the capped control. No refusal available without posture.

| id | disposition | reason |
|---|---|---|
| F-25 | EARNED | sentence names a sample below the floor |
| F-26 | EARNED | aperture on world uniqueness only, exteriority names the posit |
| F-27 | EARNED | every reached check traced, L0, R0, Seal M included |
| F-28 | EARNED | FSIG follows the face table, battery 22/22 |
| F-29 | EARNED | guard at M1 |
| F-30 | EARNED | scoped to admissible readings |
| F-31 | EARNED | order stated as it runs, description propagated, sampled path reordered |
| F-32 | EARNED | count named for what it counts |

Integration. Sweeps F-25 through F-32 pre and post PASS; every prior-round spec PASS on v1.0.4 (F-3 via its successor marker). End-to-end read attested: description, 1.5, 2.3 floor sentence, 2.4 aperture paragraph, Part 4 battery sentences, Part 5 whole, RECORD v1.0.4, engine regions for trace recording, the reordered conditions, the Seal M block, the sampled path, uni_work, FSIG, the output batteries; the read caught F-29 through F-32 and an overstatement in the F-31 record line, corrected before landing. Removal rulings: F-25 through F-32 REMOVED. Engine v1.0.4: kill-matrix 51/51, ablation 22/22, nullity 8/8, symmetry 71/71, output batteries True, limit True, fuzz 221/0, adversarial 9/9, calibration 12/12, second channel 480/480, margin gate True, switch True, chain D0 bb30d0ff1bff → D4 79b0453d3352, invariant across hash seeds, hook absence, repeat runs; replay equals embedded first light.
Additions declared, mandatory targets for round 5: D1 trace recording and the sampled-path order; D2 world uniqueness aperture emission and scoping text; D3 FSIG availability, uni_work, the Part 5 FSIG sentence; D4 output batteries and their Part 4 sentence; D5 floor wording; D6 pipeline-order text and description; D7 the M1 guard label; D8 RECORD v1.0.4.

Control reveal: CAUGHT C1 ARITH §1, CAUGHT C2 DRIFT §4, CAUGHT C3 SCOPE §3 · detection 3/3 · SELF aperture.
Statistic: admitted 8 · EARNED 8 · SCOPED 0 · refused 0 · aperture 0 · FATAL 0 · debt no · mass-bearing 8 · prereg hits 0 · repeats 0 · tier raised 0.
New version: fae_v1_0_4.md.
VERDICT CONTINUE: mass-bearing findings remain; run the next round.
