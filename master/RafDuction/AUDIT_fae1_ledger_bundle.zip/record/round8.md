# ROUND 8 · cycle fae1 · registers kinematic + definitional · the autorun cap
Header. Artifact fae_v1_0_6.md. Control commitment fd96b20aaf7fd6fd, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata: none. Declared targets from round 7: F1 basis vocabulary, F2 supply paragraph fields, F3 RECORD v1.0.6; none yielded a finding.
Leak-scan: CLEAN. Recomputed and agreeing: basis tokens per the row, supply paragraph complete against every key read, counts 51, 22, 19, 71, 221, 148/592, 8, 9, census values, and every printed claim but one.
| F-43 | kinematic | NONE | census called the sampled seal's margin printed; the boot printed only its token, label, grade | STRUCTURAL |
Defense live on the unseeded v1.0.6: engine computes I = 0.526249, eta* = 0.016899; recorded boot contains neither. EARNED.
Integration. Sweep F-43 pre and post PASS; every prior-round spec PASS on v1.0.7, round-6 F-38 through its round-7 successor. End-to-end read: the census sentence, the new boot line, RECORD v1.0.7. Engine v1.0.7: kill-matrix 51/51, ablation 22/22, null and type fuzz 0 crashes, chain D0 4367bfeea2da → D4 d13b6829e3e1, invariant across hash seeds and repeat runs. Arbiter: REWORDED on the census clause, the printed claim now true by the added line.
Additions landing in round 8, carried open at the cap with no post-landing round: G1 the sampled-seal boot line; G2 the census clause; G3 RECORD v1.0.7.
Control reveal: CAUGHT C1 ARITH §1.3, CAUGHT C2 DRIFT §1.5, CAUGHT C3 SCOPE §2.3 · detection 3/3 · SELF aperture.
Statistic: admitted 1 · EARNED 1 · mass-bearing 1 · prereg hits 0 · repeats 0.
New version: fae_v1_0_7.md.
VERDICT CONTINUE: mass-bearing findings remain. AUTORUN CAP REACHED at eight rounds with no terminal verdict: the cycle is OPEN, debt from round 6 undischarged (two consecutive clean rounds owed), round-8 additions unprosecuted. The Pre-Forge Digest emits with the cycle marked open; nothing is forged.
