# ROUND 6 · cycle fae1 · registers kinematic + definitional · re-run of the voided round-5 pass
Header. Artifact fae_v1_0_4.md. Control commitment 652f8dbaa44383f7, SELF. Defense boot chain D0 fb8900b5cf42 → D3 1e2b2d2adb14. Errata block: the round-5 probe's count of 7 seals on read keys was an artifact of its own irrelevant-key lookup; paired against deletion the count is 0, and it was never filed. Declared targets carried from round 4: D1 through D8.
Leak-scan: CLEAN.

| id | register | claim | mechanism | severity |
|---|---|---|---|---|
| F-33 | definitional | NONE | FSIG availability read per reading, typed per face | STRUCTURAL |
| F-34 | kinematic | NONE | battery class of 24 counted as 22 | STRUCTURAL |
| F-35 | definitional | LB11 | fifth typing splits exteriority grades by D-reading, repeat of F-2 | STRUCTURAL |
| F-36 | definitional | NONE | registration row omits the exchangeability guard | STRUCTURAL |
| F-37 | kinematic | LB1 | nulls crash 27/148, wrong types 79/592; FSIG raises | LOAD-BEARING |
| F-38 | kinematic | LB1 | garbage basis seals 12 absence claims where deletion routes [?] | LOAD-BEARING |
| F-39 | definitional | NONE | integration joint: catch-all discarded the reached trace | STRUCTURAL |
| F-40 | definitional | NONE | read-time joint: malformed-reading sentences overgeneral | STRUCTURAL |

Defense live on the unseeded v1.0.4: FSIG pairs [('[⟀]', '[⟀] [X]'), ('[X]', '[⟀] [X]')]; class 24, battery (22, 22); EXT and NOEXT premise at both readings; guard absent from the registration row; null domain raises TypeError; basis 'x' seals exact independence. All dispositions EARNED; F-35 --repeat-of F-2.
Integration. Sweeps F-33 through F-40 pre and post PASS; every prior-round spec PASS on v1.0.5 except round-4 F-30 and F-32, whose required markers F-33 and F-34 rewrote: banned phrases at zero, successor specs PASS. End-to-end read attested: 2.1 L5, the gate-ten row, the registration row, Part 4 kill-matrix, nullity and fuzz paragraphs, the chain paragraph, Part 5 whole, RECORD v1.0.4 and v1.0.5, engine regions for the fail-safe wrappers, the trace across exceptions, gate ten's vocabulary, the malformed fuzz, the output batteries. Removal rulings: F-33, F-34, F-35, F-40 REMOVED. Engine v1.0.5: kill-matrix 51/51, ablation 22/22, nullity 8/8, symmetry 71/71, output True, null and type fuzz 148 + 592 with 0 crashes and 0 seals, deletion fuzz 221/0, adversarial 9/9, calibration 12/12, margin gate True, chain D0 bd1b30991355 → D4 cac154144947, invariant; replay equals first light.
Additions declared, mandatory targets for round 7: E1 FSIG sentence; E2 battery sentence; E3 fifth typing; E4 registration and gate-ten rows; E5 fail-safe wrappers and fuzz sentences; E6 gate ten's basis vocabulary; E7 malformed fuzz and chain list; E8 RECORD v1.0.5 and the v1.0.4 phrase.
Control reveal: CAUGHT C1 ARITH Part 3, CAUGHT C2 DRIFT §2.4, CAUGHT C3 SCOPE Part 4 · detection 3/3 · SELF aperture.
Statistic: admitted 8 · EARNED 8 · mass-bearing 8 · prereg hits 3 · repeats 1 · tier raised 0.
New version: fae_v1_0_5.md.
VERDICT CONTINUE-PREREG-BLOCK: 3 mass-bearing finding(s) on a pre-registered claim and 0 mass-bearing FATAL; the round incurs debt, and 2 consecutive clean valid rounds are required before any seal issues.
